# ======================================================================================================================
# Abatement (input displacing and end of pipe abatement)
# ======================================================================================================================
# Variable definition
# ======================================================================================================================

$IF %stage% == "variables":

#Define parameters (explanations below...)
parameters
  switch_abatement
  switch_forward_looking
  switch_sluggish
  switch_ID_sluggish
  switch_ID
  switch_CCS[techCCS]
  rhoID[techID]
  #  rhoCCS[techCCS]
  T_CCS
  rCCS_max_sh[techCCS]  "Maximum annual adoption rate of CCS (sluggish adoption)"
  epsilon_CCS           "Degree of smoothing for sluggish adoption of CCS"
  T_ID
  switch_ID_frontloading
  switch_CCS_frontloading
  lambda_ID
;

### VARIABLES FOR OVERALL ABATEMENT
$GROUP G_abatement_other_endo
  pREa[purpose,energy19a,s,t]$(tx0[t] and (sum(techID, d1thetaID_k[techID,purpose,energy19a,s,t]) or sum(techCCS, sum(emm, d1thetaCCS[techCCS,purpose,energy19a,s,t,emm]))))                     "Correction term (= 0) when abatement module is not active"
;


### VARIABLES FOR INPUT-DISPLACING ABATEMENT

$GROUP G_ID_quantities_endo
  qREE[purpose,energy19a,energy19,s,t]$(tx0[t] and d1qREE[purpose,energy19a,energy19,s,t])   "Energy-input (peta-Joule) split on purpose and energy-type"
  qREgj[purpose,energy19,r,t]$(tx0[t] and sum(techID, sum(energy19a, d1thetaID[techID,purpose,energy19a,energy19,r,t])))          "Correction term  (=0 if abatement is not active)"
  qI_ID_levelized[i,sp,t]$(tx0[t] and sameas(i,'iM') and sum(techID, sum(purpose, sum(energy19a, d1thetaID_k[techID,purpose,energy19a,sp,t]))))                              "Non-energy costs of input displacing technologies" 
  qK_ID_demand[i,sp,t]$(tx0[t] and sameas(i,'iM') and (sum(techID, sum(purpose, sum(energy19a, d1thetaID_k[techID,purpose,energy19a,sp,t+1]))) or (tend[t] and sum(techID, sum(purpose, sum(energy19a, d1thetaID_k[techID,purpose,energy19a,sp,t])))))) ""
  qI_ID_tilde[sp,t]$(tx0[t] and sum(techID, sum(purpose, sum(energy19a, d1thetaID_k[techID,purpose,energy19a,sp,t])))) ""
  qI_ID_actual[i,s,t]$(tx0[t] and sameas(i,'iM') and not sameas[s,'off'] and sum(techID, sum(purpose, sum(energy19a, sum(tt, d1thetaID_k[techID,purpose,energy19a,s,t]))))) ""
; 

$GROUP G_ID_quantities_exo
  j_qI_ID_baseline[sp,t]$(tx0[t] and sum(techID, sum(purpose, sum(energy19a, d1thetaID_k[techID,purpose,energy19a,sp,t]))))        "Adjustement term to ensure zero technology costs in baseline"
;

$GROUP G_ID_other_endo
  rID_gains[techID,purpose,energy19a,s,t]$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t])      "Gains from ID-adoption through reduced energy input (existing energy input), billions DKK per PJ"
  rID_costs[techID,purpose,energy19a,s,t]$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t])      "Cost of ID-adoption through increased energy input (new energy input) and capital costs, billions DKK per PJ"
  rID[techID,purpose,energy19a,s,t]$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t])            "Share of input displacing technology penetration (naive)"
  rID_preferred[techID,purpose,energy19a,s,t]$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t])  "Share of input displacing technology penetration (preferred)"
  rID_actual[techID,purpose,energy19a,s,t]$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t] and d1switchID)     "Share of input displacing technology penetration (actual)"

  uREE[purpose,energy19a,energy19,s,t]$(tx0[t] and sum(techID, d1thetaID[techID,purpose,energy19a,energy19,s,t])) "Scale parameter for qREE in the production function"
  thetaID_KMean[techID,purpose,energy19a,s,t]$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t])  "Gennemsnitsomkostning for det subset af virksomheder, der bruger en teknologi (slået fra pt.)"
  vI_ID_levelized[i,sp,t]$(tx0[t] and sameas[i,'iM'] and sum(techID, sum(purpose, sum(energy19a, d1thetaID_k[techID,purpose,energy19a,sp,t])))) ""
  pK_ID[i,sp,t]$(tx1[t] and sameas(i,'iM') and sum(techID, sum(purpose, sum(energy19a, d1thetaID_k[techID,purpose,energy19a,sp,t]))))     "User cost of abatement capital"
;

$GROUP G_ID_other_exo
  uREExID[purpose,energy19a,energy19,s,t]$(tx0[t] and sum(techID, d1thetaID[techID,purpose,energy19a,energy19,s,t]))                    "Scale parameter for qREE in the production function in the absence of ID technology"
  thetaID[techID,purpose,energy19a,energy19,s,t]$(tx0[t] and d1thetaID[techID,purpose,energy19a,energy19,s,t])   "Potential for Input displacing technologies"
  thetaID_K[techID,purpose,energy19a,s,t]$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t])                 "Capital quantity costs for Input displacing technologies - costs per reduced energy unit"
  sigmaID[techID]$(sum(purpose, sum(energy19a, sum(s, sum(t, d1thetaID_k[techID,purpose,energy19a,s,t])))))      "Smoother for input displacing technologies"
  uIDscalar[techID,t]$(tx0[t] and sum(purpose, sum(energy19a, sum(s, d1thetaID_k[techID,purpose,energy19a,s,t])))) "cost scalar to control input displacing technologies"
  uIDt[techID,purpose,energy19a,s,t]$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t])                      "cost shadow tax to control input displacing technologies"
  uIDbeta                                                                                                        "Control degree of forward-lookingness (beta=0 => no forward-looking behavior)"
  j_rID[techID,purpose,energy19a,s,t]$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t])                     "Small adjustment term to ensure zero technology use in baseline (where this is the case)"
  j_qK_ID_demand_tDataEnd[sp,t]$(tx0[t]) "" 
  rDepr_ID[sp,t]$(tx0[t])                 "Afskrivningsrate for ID-investeringer"
;

### VARIABLES FOR CCS ABATEMENT

$GROUP G_CCS_quantities_endo
  qI_CCS_levelized[i,s,t]$(tx0[t] and sameas(i,'iM') and (sum(techCCS, sum(emm, sum(purpose,sum(energy19, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])) or d1thetaCCSxE[techCCS,s,t,emm])))) ""
  qK_CCS_demand[i,sp,t]$(tx0[t] and sameas(i,'iM') and (sum(techCCS, sum(emm, sum(purpose,sum(energy19, d1thetaCCS[techCCS,purpose,energy19,sp,t+1,emm])) or d1thetaCCSxE[techCCS,sp,t+1,emm])) or (tend[t] and sum(techCCS, sum(emm, sum(purpose,sum(energy19, d1thetaCCS[techCCS,purpose,energy19,sp,t,emm])) or d1thetaCCSxE[techCCS,sp,t,emm]))))) ""
  qI_CCS_tilde[sp,t]$(tx0[t] and sum(techCCS, sum(tt, sum(emm, sum(purpose,sum(energy19, d1thetaCCS[techCCS,purpose,energy19,sp,tt,emm])) or d1thetaCCSxE[techCCS,sp,tt,emm])))) ""
  qI_CCS_actual[i,s,t]$(tx0[t] and sameas(i,'iM') and (sum(techCCS, sum(emm, sum(tt, sum(purpose, sum(energy19, d1thetaCCS[techCCS,purpose,energy19,s,tt,emm])) or d1thetaCCSxE[techCCS,s,tt,emm]))))) ""
  qLEVC_CCS_EmmxE[s,t,emm]$(tx0[t] and d1EmmProdxE[s,t,emm] and sum(techCCS, d1thetaCCSxE[techCCS,s,t,emm]) and sameas[emm,'CO2ubio'])                                                                        "Levelised costs from CCS on non-energy emissions"
  qLEVC_CCS_EmmE_RE[purpose,energy19a,s,t,emm]$(tx0[t] and sum(energy19, d1qREE[purpose,energy19a,energy19,s,t] and sum(techCCS, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])) and (sameas[emm,'CO2ubio'] or sameas[emm,'CO2bio']))    "Levelised costs from CCS on emissions from energy activity (qREa)"
  vSubsidy_CCS_EmmxE[s,t,emm]$(tx0[t] and d1EmmProdxE[s,t,emm] and sameas[emm,'CO2ubio'])                                                                     "Subsidies to CCS on non-energy emissions"
  vSubsidy_CCS_EmmE_RE[purpose,energy19a,s,t,emm]$(tx0[t] and sum(energy19, d1qREE[purpose,energy19a,energy19,s,t] and sum(techCCS, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])) and (sameas[emm,'CO2ubio'] or sameas[emm,'CO2bio'])) "Subsidies to CCS on emissions from energy activity (qREa)"
; 

$GROUP G_CCS_quantities_exo
  qI_CCS_tilde_baseline[sp,t]$(tx0[t] and sum(techCCS, sum(tt, sum(emm, sum(purpose,sum(energy19, d1thetaCCS[techCCS,purpose,energy19,sp,tt,emm])) or d1thetaCCSxE[techCCS,sp,tt,emm])))) ""
  qI_CCS_actual_baseline[i,s,t]$(tx0[t] and sameas(i,'iM') and (sum(techCCS, sum(emm, sum(tt, sum(purpose,sum(energy19, d1thetaCCS[techCCS,purpose,energy19,s,tt,emm])) or d1thetaCCSxE[techCCS,s,tt,emm]))))) ""
; 

$GROUP G_CCS_prices_endo
  pCCS_qRE[s,energy19a,purpose,t]$(tx0[t] and d1pREa[purpose,energy19a,s,t] and sum(techCCS, sum(emm, d1thetaCCS[techCCS,purpose,energy19a,s,t,emm]))) ""# CCS costs entering in CES price of energy activities

  CCSSubsidy[techCCS,s,purpose,t,emm]$(tx0[t] and sum(energy19, d1thetaCCS[techCCS,purpose,energy19,s,t,emm]) and d1switchCCS)  "Subsidy for CCS, energy related (Inflation adjusted)"
  CCSxESubsidy[techCCS,s,t,emm]$(tx0[t] and d1thetaCCSxE[techCCS,s,t,emm] and d1switchCCS)                                      "Subsidy for CCS, non-energy related (Inflation adjusted)"
;

$GROUP G_CCS_prices_exo
  # E_rCCS_gains
  tSubsidy_CCS_maks[techCCS,s,purpose,t,emm]$(tx0[t] and sum(energy19, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])) ""
  tSubsidy_CCSxE_maks[techCCS,s,t,emm]$(tx0[t] and sum(purpose, sum(energy19, d1thetaCCS[techCCS,purpose,energy19,s,t,emm]))) ""

  CCSPrice[techCCS,s,t]$(tx0[t] and sum(purpose, sum(energy19, sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,t,emm]))))   "Technology cost of CCS"
;

$GROUP G_CCS_other_endo
  #  thetaCCS_kMean[techCCS,purpose,energy19,s,t,emm]$(d1thetaCCS[techCCS,purpose,energy19,s,t,emm])                                      "Gennemsnitsomkostning for det subset af virksomheder, der bruger en teknologi (slået fra pt.)"
  vCCS_gains_tax[techCCS,s,purpose,t]$(tCCS[t] and sum(energy19, sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,t,emm] and d1EmmProdE[s,t,emm,purpose,energy19])) and (sum(energy19, sum(emm, d1CO2_REmarg[purpose,energy19,s,t,emm])) or sum(emm, d1CO2_ProdxE[s,t,emm]))) "Potential gains through reduced carbon tax payments, billions DKK"
	vCCS_gains_ETS[techCCS,s,purpose,t]$(tCCS[t] and sum(energy19, sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,t,emm] and d1EmmProdE[s,t,emm,purpose,energy19])) and (sum(energy19, d1tCO2_ETS_marg[purpose,energy19,s,t]) or d1CO2_ETS[s,t])) "Potential gains through reduced ETS1-payments, billions DKK"
  vCCS_gains_subsidy[techCCS,s,purpose,t]$(tCCS[t] and sum(energy19, sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,t,emm] and d1EmmProdE[s,t,emm,purpose,energy19]))) "Potential gains through subsidies for CCS, billions DKK"
  vCCS_gains[techCCS,s,purpose,t]$(tCCS[t] and sum(energy19, sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,t,emm] and d1EmmProdE[s,t,emm,purpose,energy19]))) "Total potential gains from CCS, billions DKK"
  qEmmCCSPot[techCCS,s,purpose,t]$(tCCS[t] and sum(energy19, sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,t,emm] and d1EmmProdE[s,t,emm,purpose,energy19]))) "Potential emission reductions from CCS, ktCO2"
  rCCS_gains[techCCS,s,purpose,t]$(tCCS[t] and sum(energy19, sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])) and sum(energy19, sum(emm, d1EmmProdE[s,t,emm,purpose,energy19]))) "Unit gain of implementing CCS technology, DKK per tCO2"
  rCCS_costs[techCCS,s,purpose,t]$(tCCS[t] and sum(energy19, sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])))         "Unit cost of implementing CCS technology, DKK per tCO2"
  rCCS_input[techCCS,s,purpose,t]$(tCCS[t] and sum(energy19, sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])))         "Input for calculating share of CCS technology penetration"
  rCCS[techCCS,s,purpose,t]$(tCCS[t] and sum(energy19, sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])))               "Share of CCS technology penetration (naive)"
  rCCS_preferred[techCCS,s,purpose,energy19,t]$(tCCS[t] and sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,t,emm]))           "Share of CCS technology penetration (preferred)"
  rCCS_actual[techCCS,purpose,energy19,s,t,emm]$(tCCS[t] and d1thetaCCS[techCCS,purpose,energy19,s,t,emm] and d1switchCCS)                    "Share of CCS technology penetration (actual)"
  rCCSxE[techCCS,s,t,emm]$(tCCS[t] and d1thetaCCSxE[techCCS,s,t,emm])                                                  "Share of CCS technology penetration, non-energy related (naive)"  
  rCCSxE_actual[techCCS,s,t,emm]$(tCCS[t] and d1thetaCCSxE[techCCS,s,t,emm] and d1switchCCS)                                                  "Share of CCS technology penetration, non-energy related (actual)"
  pK_CCS[i,s,t]$(tx0[t] and sameas(i,'iM') and not sameas(s,'off'))                                               "User cost of CCS capital"
  vI_CCS_levelized[i,sp,t]$(tx0[t] and sameas(i,'iM') and (sum(techCCS, sum(emm, sum(purpose,sum(energy19, d1thetaCCS[techCCS,purpose,energy19,sp,t,emm])) or d1thetaCCSxE[techCCS,sp,t,emm])))) "Levelised investment costs (value)"
  uEOPProdE[purpose,energy19,s,t,emm]$(tx0[t] and sum(techCCS, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])) "Adjustment term to calculate net emissions after EOP abatement (energy related emissions)"
  uEOPProdxE[s,t,emm]$(tx0[t] and sum(techCCS, d1thetaCCSxE[techCCS,s,t,emm])) "Adjustment term to calculate net emissions after EOP abatement (non energy related emissions)"
;

$GROUP G_CCS_other_exo
  thetaCCS[techCCS,purpose,energy19,s,t,emm]$(tx0[t] and d1thetaCCS[techCCS,purpose,energy19,s,t,emm])  "CCS-potential energy related (share of current emissions)"
  thetaCCSxE[techCCS,s,t,emm]$(tx0[t] and d1thetaCCSxE[techCCS,s,t,emm])                                "CCS-potential non-energy related (share of current emissions)"
  # E_rCCS_costs
  uCCSscalar[techCCS,s,purpose,t]$(tx0[t] and sum(energy19, sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])))  "Cost scalar to control CCS technologies"
  # E_rCCS_input
  uCCSt[techCCS,s,purpose,t]$(tx0[t] and sum(energy19, sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])))       "Cost shadow tax to control CCS technologies"
  sigmaCCS[techCCS]                                                                                                   "Smoother for CCS technologies"
  # E_rCCS
  j_rCCS[techCCS,s,purpose,t]$(tx0[t] and sum(energy19, sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])))      "Small adjustment term to ensure zero technology use in baseline (where this is the case)"   
  # E_rCCS_preferred
  uCCSbeta                                                                                                            "Control degree of forward-lookingness (beta=0 => no forward-looking behavior)"
  # E_qI_CCS_accum
  rDepr_CCS[sp,t]$(tx0[t])                                                                                                     "Depreciation rate for CCS-investments"

  #  thetaCCS_k[techCCS, t]$(tx0[t])                                            "CCS-omkostning (pr. bruttoton)"
  #  j_qK_CCS_demand_tDataEnd[sp,t] ""
;

### AGGREGATE GROUPS

$GROUP G_abatement_quantities
  G_ID_quantities_endo
  G_CCS_quantities_endo
  G_ID_quantities_exo
  G_CCS_quantities_exo
;

$GROUP G_abatement_prices
  G_CCS_prices_endo
  G_CCS_prices_exo
;

$GROUP G_abatement_other
  G_ID_other_exo
  G_CCS_other_exo
	G_abatement_other_endo
  G_ID_other_endo
  G_CCS_other_endo
;

$ENDIF

# ======================================================================================================================
# Group compilation
# ======================================================================================================================
$IF %stage% == "groupcompilation":

  $GROUP G_abatement_shared_endo
    G_abatement_other_endo
  ;

  $GROUP G_abatement_shared_exo
    # E_j_pREa
    pREgj$(tx0[t] and d1pREgj[purpose,energy19,r,t])
    pI_s$(tx0[t] and sameas(i_,'iM'))
  ;

  $GROUP G_ID_endo
    G_ID_quantities_endo
    G_ID_other_endo
  ;

  $GROUP G_ID_exo
    G_ID_quantities_exo
    G_ID_other_exo
    
    # E_rID_gains and E_rID_costs
    pREgj$(tx0[t] and d1pREgj[purpose,energy19,r,t] and sum(techID, sum(energy19a, d1thetaID[techID,purpose,energy19a,energy19,r,t])))
    # E_rID_actual
    rID_actual$((t0[t] and d1thetaID_k[techID,purpose,energy19a,s,t]) or (not d1thetaID_k[techID,purpose,energy19a,s,t] and d1thetaID_k[techID,purpose,energy19a,s,t+1])) 
    # E_qREE
    uREE$(tx0[t] and d1qREE[purpose,energy19a,energy19,s,t] and not sum(techID, d1thetaID[techID,purpose,energy19a,energy19,s,t]))
    qREa$(tx0[t] and d1pREa[purpose,energy19a,s,t])
    qREa$(tx0[t] and sum(energy19, d1qREE[purpose,energy19a,energy19,s,t]) and not d1pREa[purpose,energy19a,s,t])
    # E_qK_ID_demand and E_qK_ID_demand_terminal
    qK_ID_demand$(t0[t] and sameas(i,'iM') and sum(techID, sum(purpose, sum(energy19a, d1thetaID_k[techID,purpose,energy19a,sp,t]))))
    qK_ID_demand$(sameas(i,'iM') and sum(techID, sum(purpose, sum(energy19a, d1thetaID_k_end[techID,purpose,energy19a,sp,t]))))
    qK_ID_demand$(sameas(i,'iM') and sum(techID, sum(purpose, sum(energy19a, d1thetaID_k[techID,purpose,energy19a,sp,t+1]))) and not sum(techID, sum(purpose, sum(energy19a, d1thetaID_k[techID,purpose,energy19a,sp,t]))))
    # E_qI_ID_actual
    qI_ID_levelized$(tx0[t] and sameas[i,'iM'] and sum(techID, sum(purpose, sum(energy19a, sum(tt, d1thetaID_k[techID,purpose,energy19a,sp,tt])))) and not sum(techID, sum(purpose, sum(energy19a, d1thetaID_k[techID,purpose,energy19a,sp,t]))))
    qI_ID_tilde$(tx0[t] and sum(techID, sum(purpose, sum(energy19a, sum(tt, d1thetaID_k[techID,purpose,energy19a,sp,tt])))) and not sum(techID, sum(purpose, sum(energy19a, d1thetaID_k[techID,purpose,energy19a,sp,t]))))
    # E_pK_ID 
    pI_s$(tx0[t] and sameas(i_,'iM'))
    EKtax$(tx0[t] and sameas(k,'iM'))
    rFirms$(tx0[t])
    tK$(tx0[t] and sameas(k,'iM'))
    tCorp$(tx0[t])
    rBonds$(tx0[t])
    sDebt2k$(tx0[t] and sameas(k,'iM'))
  ;

  $GROUP G_CCS_endo
    G_CCS_quantities_endo
    G_CCS_prices_endo
    G_CCS_other_endo
  ;

  $GROUP G_CCS_exo
    G_CCS_quantities_exo
    G_CCS_prices_exo
    G_CCS_other_exo

    # E_rCCS_gains
    tCO2_REmarg$(tx0[t] and d1CO2_REmarg[purpose,energy19,r,t,emm_eq])
    qEmmProdE$(tx0[t] and d1EmmProdE[s,t,emm_eq,purpose,energy19])
    vtCO2_ETS_marg$(tx0[t] and sum(techCCS, sum(purpose, sum(emm, d1thetaCCS[techCCS,purpose,energy19,r,t,emm]))) and sum(purpose, d1tCO2_ETS_marg[purpose,energy19,r,t]))
    tCO2_ProdxE$(tx0[t] and d1CO2_ProdxE[s,t,emm] and sameas[emm,'CO2ubio'])
    qEmmProdxE$(tx0[t] and d1EmmProdxE[s,t,emm_eq])
    vtCO2_ETSxE_marg$(tx0[t] and d1CO2_ETS[r,t])
    # E_rCCS_input
    rCCS_gains$(tx0[t] and sum(energy19, sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])) and not sum(energy19, sum(emm, d1EmmProdE[s,t,emm,purpose,energy19])))
    # E_rCCSxE_actual
    rCCSxE_actual$(((t0[t] or (tx0[t] and not tCCS[t])) and d1thetaCCSxE[techCCS,s,t,emm]) or (not d1thetaCCSxE[techCCS,s,t,emm] and d1thetaCCSxE[techCCS,s,t+1,emm]))
    # E_rCCS_actual
    rCCS_actual$(((t0[t] or (tx0[t] and not tCCS[t])) and d1thetaCCS[techCCS,purpose,energy19,s,t,emm]) or (not d1thetaCCS[techCCS,purpose,energy19,s,t,emm] and d1thetaCCS[techCCS,purpose,energy19,s,t+1,emm]))
    # E_CCSSubsidy and E_CCSxEsubsidy
    rCCS_gains$((tx0[t] and not tCCS[t]) and sum(energy19, sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])) and sum(energy19, sum(emm, d1EmmProdE[s,t,emm,purpose,energy19])))
    rCCS_costs$((tx0[t] and not tCCS[t]) and sum(energy19, sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])))
    # E_qLEVC_CCS_EmmE_RE and E_Subsidy_CCS_EmmE_RE
    qGrossEmmE_REE$(tx0[t] and d1qREE[purpose,energy19a,energy19,s,t] and d1EmmProdE[s,t,emm,purpose,energy19] and sum(techCCS, d1thetaCCS[techCCS,purpose,energy19,s,t,emm]))
    # E_qLEVC_CCS_EmmxE and E_Subsidy_CCS_EmmxE
    qGrossEmmxE$(tx0[t] and sum(techCCS, d1thetaCCSxE[techCCS,s,t,emm]))
    # E_pCCS_qRE
    qREa$(tx0[t] and d1pREa[purpose,energy19a,s,t] and sum(techCCS, sum(emm, d1thetaCCS[techCCS,purpose,energy19a,s,t,emm])))
    # E_qK_CCS_demand and E_qK_CCS_demand_terminal
    qK_CCS_demand$(t0[t] and sameas(i,'iM') and (sum(techCCS, sum(emm, sum(purpose,sum(energy19, d1thetaCCS[techCCS,purpose,energy19,sp,t,emm])) or d1thetaCCSxE[techCCS,sp,t,emm]))))
    qK_CCS_demand$(t0[t] and sameas(i,'iM') and (sum(techCCS, sum(purpose, sum(energy19, sum(tt, sum(emm, d1thetaCCS[techCCS,purpose,energy19,sp,tt,emm]))))) or sum(techCCS, sum(tt, sum(emm, d1thetaCCSxE[techCCS,sp,tt,emm])))))
    qK_CCS_demand$(sameas(i,'iM') and (sum(techCCS, sum(emm, sum(purpose,sum(energy19, d1thetaCCS_end[techCCS,purpose,energy19,sp,t,emm])) or d1thetaCCSxE_end[techCCS,sp,t,emm]))))
    qK_CCS_demand$(sameas(i,'iM') and (sum(techCCS, sum(emm, sum(purpose, sum(energy19, d1thetaCCS[techCCS,purpose,energy19,sp,t+1,emm])) or d1thetaCCSxE[techCCS,sp,t+1,emm]))) and not (sum(techCCS, sum(emm, sum(purpose, sum(energy19, d1thetaCCS[techCCS,purpose,energy19,sp,t,emm])) or d1thetaCCSxE[techCCS,sp,t,emm]))))
    # E_qI_CCS_tilde
    qK_CCS_demand$(tx0[t])
    rDepr_CCS$(tx0[t])
    # E_qI_CCS_actual
    qI_CCS_levelized$(tx0[t] and sameas[i,'iM'] and (sum(techCCS, sum(emm, sum(tt, sum(purpose, sum(energy19, d1thetaCCS[techCCS,purpose,energy19,s,tt,emm])) or d1thetaCCSxE[techCCS,s,tt,emm])))) and not sum(techCCS, sum(emm, sum(purpose,sum(energy19, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])) or d1thetaCCSxE[techCCS,s,t,emm])))
    qI_CCS_tilde$(tx0[t] and (sum(techCCS, sum(emm, sum(tt, sum(purpose, sum(energy19, d1thetaCCS[techCCS,purpose,energy19,sp,tt,emm])) or d1thetaCCSxE[techCCS,sp,tt,emm])))) and not sum(techCCS, sum(emm, sum(purpose,sum(energy19, d1thetaCCS[techCCS,purpose,energy19,sp,t,emm])) or d1thetaCCSxE[techCCS,sp,t,emm])))
    # E_pK_CCS
    pI_s$(tx0[t] and sameas(i_,'iM'))
    EKtax$(tx0[t] and sameas(k,'iM'))
    rFirms$(tx0[t])
    tK$(tx0[t] and sameas(k,'iM'))
    tCorp$(tx0[t])
    rBonds$(tx0[t])
    sDebt2k$(tx0[t] and sameas(k,'iM'))
    #Other
    rID_actual$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t] and not d1switchID)
    CCSSubsidy$(tx0[t] and sum(energy19, d1thetaCCS[techCCS,purpose,energy19,s,t,emm]) and not d1switchCCS)
    CCSxESubsidy$(tx0[t] and d1thetaCCSxE[techCCS,s,t,emm] and not d1switchCCS)
    rCCS_actual$(tCCS[t] and d1thetaCCS[techCCS,purpose,energy19,s,t,emm] and not d1switchCCS)
    rCCSxE_actual$(tCCS[t] and d1thetaCCSxE[techCCS,s,t,emm] and not d1switchCCS)
  ;


# Assembling endo and exo groups for the whole module
  $GROUP G_abatement_endo
    G_abatement_shared_endo
    G_ID_endo
    G_CCS_endo
  ;

  #  $GROUP G_abatement_endo 
  #    G_abatement_endo$(tx0[t])
  #  ;

  $GROUP G_abatement_exo
    G_abatement_shared_exo
    G_ID_exo
    G_CCS_exo
  ;


  $PGROUP PGROUP_Abatement_NonFlat_Dummies
    d1thetaID_k[techID,purpose,energy19a,s,t]
    d1thetaID[techID,purpose,energy19a,energy19,s,t]
  ;


$ENDIF

# ======================================================================================================================
# Equations
# ======================================================================================================================
$IF %stage% == "equations":


	$BLOCK B_abatement_energy_activities
    # ------------------------------------------------------------------------------------------------------------------
    # Split of energy activties into energy goods (RE to REE)
    # ------------------------------------------------------------------------------------------------------------------

    # CES price of energy activities:
    E_j_pREa[purpose,energy19a,s,t]$(tx0[t] and (sum(techID, d1thetaID_k[techID,purpose,energy19a,s,t]) or sum((techCCS,emm), d1thetaCCS[techCCS,purpose,energy19a,s,t,emm]))).. 
    	pREa[purpose,energy19a,s,t] =E= 
      #Energy costs:
      sum(energy19$(sum(techID, d1thetaID[techID,purpose,energy19a,energy19,s,t])), uREE[purpose,energy19a,energy19,s,t]*pREgj[purpose,energy19,s,t])
      #Capital costs from ID:
      + sum(techID$(d1thetaID_k[techID,purpose,energy19a,s,t]), rID_actual[techID,purpose,energy19a,s,t] * thetaID_KMean[techID,purpose,energy19a,s,t]
          * sum(energy19$(d1thetaID[techID,purpose,energy19a,energy19,s,t] and sameas(energy19,energy19a)),-thetaID[techID,purpose,energy19a,energy19,s,t]) 
          * pI_s['iM',s,t])
      # Energy costs in absence of ID-abatement
      + pREgj[purpose,energy19a,s,t]$(sum((techCCS,emm), d1thetaCCS[techCCS,purpose,energy19a,s,t,emm]) and not sum((techID,energy19), d1thetaID[techID,purpose,energy19a,energy19,s,t]))
      #Capital costs from CCS:
      + pCCS_qRE[s,energy19a,purpose,t]$(sum((techCCS,emm), d1thetaCCS[techCCS,purpose,energy19a,s,t,emm]));

	$ENDBLOCK

  # Input-displacing abatement
  $BLOCK B_abatement_ID

  ## ---------------------------------------------------------------------------------------------
  # Adoption of technologies
  ## ---------------------------------------------------------------------------------------------

  # Gains from ID-adoption through reduced energy input (existing energy input), billions DKK per PJ
  E_rID_gains[techID,purpose,energy19a,s,t]$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t])..
    rID_gains[techID,purpose,energy19a,s,t] =E= 
      # Energy costs (existing energy input)
      sum(energy19$(d1thetaID[techID,purpose,energy19a,energy19,s,t] and sameas[energy19,energy19a]), -thetaID[techID,purpose,energy19a,energy19,s,t]*pREgj[purpose,energy19,s,t]);

  # Cost of ID-adoption through increased energy input (new energy input) and capital costs, billions DKK per PJ
  E_rID_costs[techID,purpose,energy19a,s,t]$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t])..
    rID_costs[techID,purpose,energy19a,s,t] =E= 
      # Energy costs (new energy input)
      sum(energy19$(d1thetaID[techID,purpose,energy19a,energy19,s,t] and not sameas[energy19,energy19a]), thetaID[techID,purpose,energy19a,energy19,s,t]*pREgj[purpose,energy19,s,t]) 
      # Capital costs
      + pI_s['iM',s,t]*thetaID_k[techID,purpose,energy19a,s,t]
        * sum(energy19$(d1thetaID[techID,purpose,energy19a,energy19,s,t] and sameas(energy19,energy19a)), -thetaID[techID,purpose,energy19a,energy19,s,t]);

  # Instantanous technology adoption rate (without forward-looking or sluggsihness)
  E_rID[techID,purpose,energy19a,s,t]$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t])..
    rID[techID,purpose,energy19a,s,t] =E=  switch_abatement * switch_ID * (
                                            @cdfLogNorm(rID_gains[techID,purpose,energy19a,s,t],rID_costs[techID,purpose,energy19a,s,t],sigmaID[techID])
                                            + j_rID[techID,purpose,energy19a,s,t]);

  # Technology adoption with forward-looking mechanism (if switch_forward_looking = 1)
  E_rID_preferred[techID,purpose,energy19a,s,t]$(tx0[t] and not d1thetaID_k_end[techID,purpose,energy19a,s,t] and d1thetaID_k[techID,purpose,energy19a,s,t])..
  rID_preferred[techID,purpose,energy19a,s,t] =E= (1-switch_forward_looking)*rID[techID,purpose,energy19a,s,t] + switch_forward_looking*( (1-uIDbeta)*rID[techID,purpose,energy19a,s,t]+(uIDbeta)*rID_preferred[techID,purpose,energy19a,s,t+1]);

  # Terminal condition for forward-looking mechanism
  E_rID_preferred_terminal_condition[techID,purpose,energy19a,s,t]$(tx0[t] and d1thetaID_k_end[techID,purpose,energy19a,s,t] and d1thetaID_k[techID,purpose,energy19a,s,t])..
     rID_preferred[techID,purpose,energy19a,s,t] =E= rID[techID,purpose,energy19a,s,t];

  # Actual technology adoption (with sluggishness, if switch_ID_sluggish = 1)
  E_rID_actual[techID,purpose,energy19a,s,t]$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t] and d1switchID)..
       rID_actual[techID,purpose,energy19a,s,t] =E=  
       (1-switch_ID_sluggish)*rID_preferred[techID,purpose,energy19a,s,t]
      + switch_ID_sluggish*( exp(-sqr(rID_preferred[techID,purpose,energy19a,s,t] - rID_actual[techID,purpose,energy19a,s,t-1])/rhoID[techID]) * (rID_preferred[techID,purpose,energy19a,s,t]) + (1-exp(-sqr(rID_preferred[techID,purpose,energy19a,s,t] - rID_actual[techID,purpose,energy19a,s,t-1])/rhoID[techID])) * rID_actual[techID,purpose,energy19a,s,t-1]);

  ## ---------------------------------------------------------------------------------------------
  # Change in energy input
  ## ---------------------------------------------------------------------------------------------

  # Endogenous Leontief shares
  E_uREE[purpose,energy19a,energy19,s,t]$(tx0[t] and sum(techID, d1thetaID[techID,purpose,energy19a,energy19,s,t]))..
    uREE[purpose,energy19a,energy19,s,t] =E= uREExID[purpose,energy19a,energy19,s,t] 
       + sum(techID$(d1thetaID[techID,purpose,energy19a,energy19,s,t]), rID_actual[techID,purpose,energy19a,s,t]*thetaID[techID,purpose,energy19a,energy19,s,t]);

    # Leontief demand:
    E_qREE[purpose,energy19a,energy19,s,t]$(tx0[t] and d1qREE[purpose,energy19a,energy19,s,t]).. 
      qREE[purpose,energy19a,energy19,s,t] =E= uREE[purpose,energy19a,energy19,s,t] * qREa[purpose,energy19a,s,t];

    # Energy demand by sector and purpose (endogenises j_qREgj in E_qRE in aggregates.gms, hence determining qREgj)
    E_j_qREgj[purpose,energy19,s,t]$(tx0[t] and sum((techID,energy19a), d1thetaID[techID,purpose,energy19a,energy19,s,t])).. 
      qREgj[purpose,energy19,s,t] =E= 
      sum(energy19a$(d1qREE[purpose,energy19a,energy19,s,t]), 
        qREE[purpose,energy19a,energy19,s,t]);

  ## ---------------------------------------------------------------------------------------------
  # Change in investments and capital
  ## ---------------------------------------------------------------------------------------------

  # Calculating average capital unit cost for the subset of firms choosing to implement a technology:
  #  E_thetaID_KMean[techID,purpose,energy19a,s,t]$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t]).. thetaID_KMean[techID,purpose,energy19a,s,t] =E= 
  #    errorf(rID_input[techID,purpose,energy19a,s,t])*thetaID_K[techID,purpose,energy19a,s,t] - (exp(-sqr(rID_input[techID,purpose,energy19a,s,t]))/(2*sqrt(2*pi)))*sigmaID[techID];

  # Setting the average capital unit cost for the subset of firms choosing to implement a technology equal to the overall average cost in data:
  E_thetaID_KMean[techID,purpose,energy19a,s,t]$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t]).. thetaID_KMean[techID,purpose,energy19a,s,t] =E= thetaID_K[techID,purpose,energy19a,s,t];

  # Definition of user cost without installation costs and calibrated adjustment term:
  E_pK_ID[sp,t]$(tx0E[t] and d1K['iM',sp,t] and sum((techID,purpose,energy19a), d1thetaID_k[techID,purpose,energy19a,sp,t+1]))..  
          pK_ID['iM',sp,t+1]*fp * (1-tCorp[t+1]) =E=  
        # Tobin's q today and tomorrow
         (pI_s['iM',sp,t] - pI_s['iM',sp,t]*EKtax['iM',sp,t])* (1+rFirms[sp,t+1]) - (1 - rDepr_ID[sp,t]) * (pI_s['iM',sp,t+1] - pI_s['iM',sp,t+1]*EKtax['iM',sp,t+1])*fp
        # Production tax on capital
        + (1-tCorp[t+1]) * tK['iM',sp,t+1] * pI_s['iM',sp,t+1]*fp
        # Tax shield on collateral value on capital
        - (rFirms[sp,t+1] - rBonds[sp,t+1] * (1-tCorp[t+1])) * sDebt2k['iM',sp,t] * pI_s['iM',sp,t];

  # Additonal investment demand (levelized)
  E_qI_ID_levelized[sp,t]$(tx0[t] and sum((techID,purpose,energy19a), d1thetaID_k[techID,purpose,energy19a,sp,t]))..
    qI_ID_levelized['iM',sp,t] =E= sum((techID,purpose,energy19a)$(d1thetaID_k[techID,purpose,energy19a,sp,t]), rID_actual[techID,purpose,energy19a,sp,t] * thetaID_KMean[techID,purpose,energy19a,sp,t]
                                    *sum(energy19$(d1thetaID[techID,purpose,energy19a,energy19,sp,t] and sameas(energy19,energy19a)),-thetaID[techID,purpose,energy19a,energy19,sp,t])
                                    *qREa[purpose,energy19a,sp,t]);

  # Value of additonal investment demand (levelized)
  E_vI_ID_levelized[sp,t]$(tx0[t] and sum((techID,purpose,energy19a), d1thetaID_k[techID,purpose,energy19a,sp,t]))..
    vI_ID_levelized['iM',sp,t] =E= qI_ID_levelized['iM',sp,t]*pI_s['iM',sp,t];

  # Total capital demand, implied by levelized investment demand and user cost:
  E_qK_ID_demand[sp,t]$(tx0[t] and not t1[t] and sum((techID,purpose,energy19a), d1thetaID_k[techID,purpose,energy19a,sp,t])).. #If there was an initial capital-stock user-cost would be determiend as the shadow-price. But initially both LHS and RHS are pinned at zero, and pK can't be determined as shadow-price
    vI_ID_levelized['iM',sp,t] =E= pK_ID['iM',sp,t]*qK_ID_demand['iM',sp,t-1] + j_qK_ID_demand_tDataEnd[sp,t]; #For some reason qI_ID_levelized, even without technology, differs marginally from zero in 2019. With capital locked at zero this gives pivot too small error. For that reason a J-term is added. This is not pretty...

  # Terminal condition:
  E_qK_ID_demand_terminal[sp,t]$(tend[t] and sum((techID,purpose,energy19a), d1thetaID_k[techID,purpose,energy19a,sp,t]))..
    qK_ID_demand['iM',sp,t] =E= qK_ID_demand['iM',sp,t-1];

  # Investment necessary to cover total capital demand:
  E_qI_ID_tilde[sp,t]$(tx0[t] and sum((techID,purpose,energy19a), d1thetaID_k[techID,purpose,energy19a,sp,t])).. 
    qI_ID_tilde[sp,t] =E= qK_ID_demand['iM',sp,t] - (1 - rDepr_ID[sp,t]) * qK_ID_demand['iM',sp,t-1]/fq;

  # Spread necessary investments evenly over T_ID periods preceeding year of capital demand (if front-loading is activated):
  E_qI_ID_actual_start[sp,t]$(tx0[t] and (t.val<=(t0.val+T_ID)) and sum((techID,purpose,energy19a,ttt), d1thetaID_k[techID,purpose,energy19a,sp,ttt]))..
    qI_ID_actual['iM',sp,t] =E= (1-switch_ID_frontloading)*qI_ID_levelized['iM',sp,t]
                               + switch_ID_frontloading * sum(tt$(tt.val >= t.val and tt.val < t.val + T_ID and not tt.val=t0.val), 
                                                              qI_ID_tilde[sp,tt]/(min[(tt.val - t0.val),T_ID]));

  E_qI_ID_actual[sp,t]$(tx0[t] and (t.val>(t0.val+T_ID)) and (t.val<=(tend.val-T_ID)) and sum((techID,purpose,energy19a,ttt), d1thetaID_k[techID,purpose,energy19a,sp,ttt]))..
    qI_ID_actual['iM',sp,t] =E= (1-switch_ID_frontloading)*qI_ID_levelized['iM',sp,t]
                               + switch_ID_frontloading * sum(tt$(tt.val >= t.val and tt.val < t.val + T_ID and not tt.val=t0.val), 
                                                              qI_ID_tilde[sp,tt]/T_ID);

  E_qI_ID_actual_terminal[sp,t]$(tx0[t] and (t.val>(tend.val-T_ID)) and sum((techID,purpose,energy19a,ttt), d1thetaID_k[techID,purpose,energy19a,sp,ttt]))..
    qI_ID_actual['iM',sp,t] =E= (1-switch_ID_frontloading)*qI_ID_levelized['iM',sp,t]
                               + switch_ID_frontloading * sum(tt$(tt.val >= t.val and tt.val < t.val + T_ID and not tt.val=t0.val),
                                                              qI_ID_tilde[sp,tt])/T_ID*(T_ID/(tend.val - t.val + 1));

  $ENDBLOCK

  #CCS abatement
  $BLOCK B_abatement_CCS

  ## ---------------------------------------------------------------------------------------------
  # Adoption of technologies
  ## ---------------------------------------------------------------------------------------------

  # Potential gains through reduced carbon tax payments, billions DKK
  E_vCCS_gains_tax[techCCS,s,purpose,t]$(tCCS[t] and sum((energy19,emm), d1thetaCCS[techCCS,purpose,energy19,s,t,emm]) and sum((energy19,emm), d1EmmProdE[s,t,emm,purpose,energy19]) and (sum((energy19,emm), d1CO2_REmarg[purpose,energy19,s,t,emm]) or sum(emm, d1CO2_ProdxE[s,t,emm]))).. 
      vCCS_gains_tax[techCCS,s,purpose,t] =E= 
          sum((energy19,emm)$(d1thetaCCS[techCCS,purpose,energy19,s,t,emm] and d1CO2_REmarg[purpose,energy19,s,t,emm]), 
              thetaCCS[techCCS,purpose,energy19,s,t,emm]*tCO2_REmarg[purpose,energy19,s,t,emm]*qEmmProdE[s,t,emm,purpose,energy19]*growth_factor[t]*10**(-6))

        + sum(emm$(d1thetaCCSxE[techCCS,s,t,emm] and d1CO2_ProdxE[s,t,emm] and sameas[emm,'CO2ubio']), 
              thetaCCSxE[techCCS,s,t,emm]*tCO2_ProdxE[s,t,emm]*qEmmProdxE[s,t,emm]*growth_factor[t]*10**(-6))$(sameas[purpose,'in_ETS']);

  # Potential gains through reduced ETS1-payments, billions DKK
  E_vCCS_gains_ETS[techCCS,s,purpose,t]$(tCCS[t] and sum((energy19,emm), d1thetaCCS[techCCS,purpose,energy19,s,t,emm]) and sum((energy19,emm), d1EmmProdE[s,t,emm,purpose,energy19]) and (sum(energy19, d1tCO2_ETS_marg[purpose,energy19,s,t]) or d1CO2_ETS[s,t])).. 
      vCCS_gains_ETS[techCCS,s,purpose,t] =E= 
          sum((energy19,emm)$(d1thetaCCS[techCCS,purpose,energy19,s,t,emm] and d1tCO2_ETS_marg[purpose,energy19,s,t] and (sameas[emm,'CO2ubio'])),# or (sameas[emm,'CO2bio'] and sameas[energy19,'Natural gas incl. biongas']))), 
              thetaCCS[techCCS,purpose,energy19,s,t,emm]*vtCO2_ETS_marg[energy19,s,t])
        + sum(emm$(d1thetaCCSxE[techCCS,s,t,emm] and d1CO2_ETS[s,t] and (sameas[emm,'CO2ubio'])),# or (sameas[emm,'CO2bio'] and sameas[energy19,'Natural gas incl. biongas']))), 
              thetaCCSxE[techCCS,s,t,emm]*vtCO2_ETSxE_marg[s,t])$(sameas[purpose,'in_ETS']);


  # Potential gains through subsidies for CCS, billions DKK
  E_vCCS_gains_subsidy[techCCS,s,purpose,t]$(tCCS[t] and sum((energy19,emm), d1thetaCCS[techCCS,purpose,energy19,s,t,emm]) and sum((energy19,emm), d1EmmProdE[s,t,emm,purpose,energy19])).. 
      vCCS_gains_subsidy[techCCS,s,purpose,t] =E= 
          sum((energy19,emm)$(d1thetaCCS[techCCS,purpose,energy19,s,t,emm] and d1EmmProdE[s,t,emm,purpose,energy19]), 
              thetaCCS[techCCS,purpose,energy19,s,t,emm]*tSubsidy_CCS_maks[techCCS,s,purpose,t,emm]*qEmmProdE[s,t,emm,purpose,energy19]*growth_factor[t]*10**(-6))
        + sum(emm$(d1thetaCCSxE[techCCS,s,t,emm]), 
              thetaCCSxE[techCCS,s,t,emm]*tSubsidy_CCSxE_maks[techCCS,s,t,emm]*qEmmProdxE[s,t,emm]*growth_factor[t]*10**(-6))$(sameas[purpose,'in_ETS']);

  # Total potential gains from CCS, billions DKK
  E_vCCS_gains[techCCS,s,purpose,t]$(tCCS[t] and sum((energy19,emm), d1thetaCCS[techCCS,purpose,energy19,s,t,emm]) and sum((energy19,emm), d1EmmProdE[s,t,emm,purpose,energy19])).. 
      vCCS_gains[techCCS,s,purpose,t] =E= vCCS_gains_tax[techCCS,s,purpose,t]$(sum((energy19,emm), d1CO2_REmarg[purpose,energy19,s,t,emm]) or sum(emm, d1CO2_ProdxE[s,t,emm]))
                                        + vCCS_gains_ETS[techCCS,s,purpose,t]$(sum(energy19, d1tCO2_ETS_marg[purpose,energy19,s,t]) or d1CO2_ETS[s,t])
                                        + vCCS_gains_subsidy[techCCS,s,purpose,t];

  # Potential emission reductions from CCS, ktCO2
  E_qEmmCCSPot[techCCS,s,purpose,t]$(tCCS[t] and sum((energy19,emm), d1thetaCCS[techCCS,purpose,energy19,s,t,emm]) and sum((energy19,emm), d1EmmProdE[s,t,emm,purpose,energy19])).. 
      qEmmCCSPot[techCCS,s,purpose,t] =E= sum((energy19,emm)$(d1thetaCCS[techCCS,purpose,energy19,s,t,emm] and d1EmmProdE[s,t,emm,purpose,energy19]), 
                  							thetaCCS[techCCS,purpose,energy19,s,t,emm]*qEmmProdE[s,t,emm,purpose,energy19])
           							  + sum(emm$(d1thetaCCSxE[techCCS,s,t,emm] and d1EmmProdxE[s,t,emm]), 
                  							thetaCCSxE[techCCS,s,t,emm]*qEmmProdxE[s,t,emm])$(sameas[purpose,'in_ETS']);

  # Unit gain of implementing CCS technology, DKK per tCO2
  E_rCCS_gains[techCCS,s,purpose,t]$(tCCS[t] and sum((energy19,emm), d1thetaCCS[techCCS,purpose,energy19,s,t,emm]) and sum((energy19,emm), d1EmmProdE[s,t,emm,purpose,energy19])).. 
      rCCS_gains[techCCS,s,purpose,t] =E= vCCS_gains[techCCS,s,purpose,t]
                                            / (qEmmCCSPot[techCCS,s,purpose,t]*growth_factor[t])
                                            *10**6;


  # Unit cost of implementing CCS technology, DKK per tCO2
  E_rCCS_costs[techCCS,s,purpose,t]$(tCCS[t] and sum((energy19,emm), d1thetaCCS[techCCS,purpose,energy19,s,t,emm])).. 
      rCCS_costs[techCCS,s,purpose,t] =E= CCSPrice[techCCS,s,t]*uCCSscalar[techCCS,s,purpose,t]*pI_s['iM',s,t];

  # Input for calculating instantaneous adoption rate (assuming normally distributed costs)
  E_rCCS_input[techCCS,s,purpose,t]$(tCCS[t] and sum((energy19,emm), d1thetaCCS[techCCS,purpose,energy19,s,t,emm])).. 
      rCCS_input[techCCS,s,purpose,t] =E= rCCS_gains[techCCS,s,purpose,t] - rCCS_costs[techCCS,s,purpose,t];

  #  # Input for calculating instantaneous adoption rate (log-normally distributed costs instead of normally distributed costs)
  #  E_rCCS_input[techCCS,purpose,energy19,s,t,emm]$(tx0[t]).. rCCS_input[techCCS,purpose,energy19,s,t,emm] =E=
  #    switch_abatement * switch_CCS[techCCS] * errorf(
  #        (log(sum(s$(d1_tech_s_CCS[techCCS,s]), (vtCO2_RxE[s,t]
  #                                              +sum((purpose,energy19)$(d1EmmProdE[s,t,'CO2ubio', purpose,energy19]), vtCO2_RE[purpose,energy19,s,t]))
  #              /inf_growth_factor[t]/qEmmProdS[s,t,'CO2e','UNFCCC']) + epsCCS)
  #        -log(thetaCCS_K[techCCS,purpose,energy19,s,t,emm]*sum(s$(d1_tech_s_CCS[techCCS,s]), pI_s['iM',s,t])*uCCSscalar[techCCS,purpose,energy19,s,t,emm])-uCCSt[techCCS,purpose,energy19,s,t,emm]
  #        -sigmaCCS[techCCS]**2/2)
  #    / sigmaCCS[techCCS]) + j_rCCS[techCCS,purpose,energy19,s,t,emm];

  # Instantanous technology adoption rate (without forward-looking or sluggsihness)
  E_rCCS[techCCS,s,purpose,t]$(tCCS[t] and sum((energy19,emm), d1thetaCCS[techCCS,purpose,energy19,s,t,emm]))..
      rCCS[techCCS,s,purpose,t] =E=
          switch_abatement * switch_CCS[techCCS] * (errorf(rCCS_input[techCCS,s,purpose,t]/sigmaCCS[techCCS]) + j_rCCS[techCCS,s,purpose,t]);

  # Technology adoption with forward-looking mechanism (if switch_forward_looking = 1)
  E_rCCS_preferred[techCCS,s,purpose,energy19,t]$(tCCS[t] and not sum(emm, d1thetaCCS_end[techCCS,purpose,energy19,s,t,emm]) and sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,t,emm]))..
      rCCS_preferred[techCCS,s,purpose,energy19,t] =E= 
          (1-switch_forward_looking)*rCCS[techCCS,s,purpose,t] 
          + switch_forward_looking*( (1-uCCSbeta)*rCCS[techCCS,s,purpose,t]+(uCCSbeta)*rCCS_preferred[techCCS,s,purpose,energy19,t+1]);

  # Terminal condition for forward-looking mechanism
  E_rCCS_preferred_terminal_condition[techCCS,s,purpose,energy19,t]$(tCCS[t] and sum(emm, d1thetaCCS_end[techCCS,purpose,energy19,s,t,emm]) and sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,t,emm]))..
      rCCS_preferred[techCCS,s,purpose,energy19,t] =E= rCCS[techCCS,s,purpose,t];

  #  Actual technology adoption (with sluggishness, if switch_sluggish = 1)
  E_rCCS_actual[techCCS,purpose,energy19,s,t,emm]$(tCCS[t] and d1thetaCCS[techCCS,purpose,energy19,s,t,emm] and d1switchCCS)..
    rCCS_actual[techCCS,purpose,energy19,s,t,emm] =E=  
       (1-switch_sluggish)*rCCS_preferred[techCCS,s,purpose,energy19,t]  
      + switch_sluggish*(@slugger(rCCS_preferred[techCCS,s,purpose,energy19,t],rCCS_actual[techCCS,purpose,energy19,s,t-1,emm],rCCS_max_sh[techCCS],epsilon_CCS));

  # Actual technology adoption (with sluggishness, if switch_sluggish = 1)
  E_rCCSxE[techCCS,s,t,emm]$(tCCS[t] and d1thetaCCSxE[techCCS,s,t,emm])..
    rCCSxE[techCCS,s,t,emm] =E= rCCS[techCCS,s,'in_ETS',t];

  # Actual technology adoption (with sluggishness, if switch_sluggish = 1)
  E_rCCSxE_actual[techCCS,s,t,emm]$(tCCS[t] and d1thetaCCSxE[techCCS,s,t,emm] and d1switchCCS)..
    rCCSxE_actual[techCCS,s,t,emm] =E=  
       (1-switch_sluggish)*rCCSxE[techCCS,s,t,emm]  
      + switch_sluggish*(@slugger(rCCSxE[techCCS,s,t,emm],rCCSxE_actual[techCCS,s,t-1,emm],rCCS_max_sh[techCCS],epsilon_CCS));
      
  ## ---------------------------------------------------------------------------------------------
  # Change in emission coefficients
  ## ---------------------------------------------------------------------------------------------

  # Update emission coefficients:
  E_uEOPProdE[purpose,energy19,s,t,emm]$(tx0[t] and sum(techCCS, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])).. 
    uEOPProdE[purpose,energy19,s,t,emm] =E= 1-sum(techCCS$(d1thetaCCS[techCCS,purpose,energy19,s,t,emm]), rCCS_actual[techCCS,purpose,energy19,s,t,emm]*thetaCCS[techCCS,purpose,energy19,s,t,emm]);

  E_uEOPProdxE[s,t,emm]$(tx0[t] and sum(techCCS, d1thetaCCSxE[techCCS,s,t,emm])).. 
    uEOPProdxE[s,t,emm] =E= 1-sum(techCCS$(d1thetaCCSxE[techCCS,s,t,emm]), rCCSxE_actual[techCCS,s,t,emm]*thetaCCSxE[techCCS,s,t,emm]);

  ## ---------------------------------------------------------------------------------------------
  # Levelized costs and subsidies
  ## ---------------------------------------------------------------------------------------------

  # Calculating average capital unit cost for the subset of firms choosing to implement a technology:
  #  E_thetaCCS_kMean[techCCS,purpose,energy19,s,t,emm]$(tx0[t]).. thetaCCS_kMean[techCCS,purpose,energy19,s,t,emm] =E= errorf(rCCS_input[techCCS,purpose,energy19,s,t,emm])*thetaCCS_k[techCCS,purpose,energy19,s,t,emm] - (exp(-sqr(rCCS_input[techCCS,purpose,energy19,s,t,emm]))/(2*sqrt(2*pi)))*sigmaCCS[techCCS];

  # Setting the average capital unit cost for the subset of firms choosing to implement a technology equal to the overall average cost in data:
  #  E_thetaCCS_kMean[techCCS,purpose,energy19,s,t,emm]$(tx0[t] and d1thetaCCS[techCCS,purpose,energy19,s,t,emm]).. 
  #    thetaCCS_kMean[techCCS,purpose,energy19,s,t,emm] =E= thetaCCS_k[techCCS,purpose,energy19,s,t,emm];

  # Total LEVC on energy related CCS (energy activity)
  E_qLEVC_CCS_EmmE_RE[purpose,energy19a,s,t,emm]$(tx0[t] and sum(energy19, d1qREE[purpose,energy19a,energy19,s,t] and sum(techCCS, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])) and (sameas[emm,'CO2ubio'] or sameas[emm,'CO2bio']))..
    qLEVC_CCS_EmmE_RE[purpose,energy19a,s,t,emm] =E= sum((techCCS,energy19)$(d1qREE[purpose,energy19a,energy19,s,t] and d1EmmProdE[s,t,emm,purpose,energy19] and d1thetaCCS[techCCS,purpose,energy19,s,t,emm] and (sameas[emm,'CO2ubio'] or sameas[emm,'CO2bio'])), 
                                                         qGrossEmmE_REE[purpose,energy19a,energy19,s,t,emm]*growth_factor[t]
                                                       * CCSPrice[techCCS,s,t]*10**(3)*10**(-9) * thetaCCS[techCCS,purpose,energy19,s,t,emm]*rCCS_actual[techCCS,purpose,energy19,s,t,emm]); 

  # Total LEVC on non-energy related CCS
  E_qLEVC_CCS_EmmxE[s,t,emm]$(tx0[t] and d1EmmProdxE[s,t,emm] and sum(techCCS, d1thetaCCSxE[techCCS,s,t,emm]) and sameas[emm,'CO2ubio'])..
    qLEVC_CCS_EmmxE[s,t,emm] =E= qGrossEmmxE[s,t,emm]*growth_factor[t]*sum(techCCS$(d1thetaCCSxE[techCCS,s,t,emm]), CCSPrice[techCCS,s,t]*10**(3)*10**(-9) * thetaCCSxE[techCCS,s,t,emm]*rCCSxE_actual[techCCS,s,t,emm]); 

  # Subsidies are "perfect" in the sense that they equal marginal costs with marginal benefits
  E_CCSSubsidy[techCCS,s,purpose,t,emm]$(tx0[t] and sum(energy19, d1thetaCCS[techCCS,purpose,energy19,s,t,emm]) and d1switchCCS)..
    CCSSubsidy[techCCS,s,purpose,t,emm] =E= max[0,rCCS_costs[techCCS,s,purpose,t] - (rCCS_gains[techCCS,s,purpose,t] - tSubsidy_CCS_maks[techCCS,s,purpose,t,emm])];

  E_CCSxEsubsidy[techCCS,s,t,emm]$(tx0[t] and d1thetaCCSxE[techCCS,s,t,emm] and d1switchCCS)..
    CCSxEsubsidy[techCCS,s,t,emm] =E= max[0,rCCS_costs[techCCS,s,'in_ETS',t] - (rCCS_gains[techCCS,s,'in_ETS',t] - tSubsidy_CCSxE_maks[techCCS,s,t,emm])];


  # Total subsidies to energy related CCS (energy activity)
  E_vSubsidy_CCS_EmmE_RE[purpose,energy19a,s,t,emm]$(tx0[t] and sum(energy19, d1qREE[purpose,energy19a,energy19,s,t] and sum(techCCS, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])) and (sameas[emm,'CO2ubio'] or sameas[emm,'CO2bio']))..
    vSubsidy_CCS_EmmE_RE[purpose,energy19a,s,t,emm] =E= sum((techCCS,energy19)$(d1qREE[purpose,energy19a,energy19,s,t] and d1EmmProdE[s,t,emm,purpose,energy19] and d1thetaCCS[techCCS,purpose,energy19,s,t,emm] and (sameas[emm,'CO2ubio'] or sameas[emm,'CO2bio'])), 
                                                            qGrossEmmE_REE[purpose,energy19a,energy19,s,t,emm]*growth_factor[t]
                                                          * CCSSubsidy[techCCS,s,purpose,t,emm]*10**(3)*10**(-9) * thetaCCS[techCCS,purpose,energy19,s,t,emm]*rCCS_actual[techCCS,purpose,energy19,s,t,emm]); 

  # Total subsidies to non-energy related CCS
  E_vSubsidy_CCS_EmmxE[s,t,emm]$(tx0[t] and d1EmmProdxE[s,t,emm] and sum(techCCS, d1thetaCCSxE[techCCS,s,t,emm]) and sameas[emm,'CO2ubio'])..
    vSubsidy_CCS_EmmxE[s,t,emm] =E= qGrossEmmxE[s,t,emm]*growth_factor[t]*sum(techCCS$(d1thetaCCSxE[techCCS,s,t,emm]), CCSxEsubsidy[techCCS,s,t,emm]*10**(3)*10**(-9) * thetaCCSxE[techCCS,s,t,emm]*rCCSxE_actual[techCCS,s,t,emm]); 

  # Levelized capital cost entering production function. All costs are allocated under energy activities proportionally with CO2-emissions in each activity.
  E_pCCS_qRE[s,energy19a,purpose,t]$(tx0[t] and d1pREa[purpose,energy19a,s,t] and sum((techCCS,emm), d1thetaCCS[techCCS,purpose,energy19a,s,t,emm])).. 
    pCCS_qRE[s,energy19a,purpose,t] =E= (sum(emm$(sum(energy19, d1qREE[purpose,energy19a,energy19,s,t] and sum(techCCS, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])) and (sameas[emm,'CO2ubio'] or sameas[emm,'CO2bio'])), 
                                              qLEVC_CCS_EmmE_RE[purpose,energy19a,s,t,emm]*pI_s['iM',s,t] # Value of cost of CCS on energy related emissions
                                            - vSubsidy_CCS_EmmE_RE[purpose,energy19a,s,t,emm]))           # Subsidy to CCS on energy related emissions 
                                       / qREa[purpose,energy19a,s,t];  

  ## ---------------------------------------------------------------------------------------------
  # Change in investments and capital
  ## ---------------------------------------------------------------------------------------------

  # Definition of user cost without installation costs and calibrated adjustment term:
  E_pK_CCS[sp,t]$(tx0E[t] and d1K['iM',sp,t])..  
          pK_CCS['iM',sp,t+1]*fp * (1-tCorp[t+1]) =E=  
        # Tobin's q today and tomorrow
         (pI_s['iM',sp,t] - pI_s['iM',sp,t]*EKtax['iM',sp,t])* (1+rFirms[sp,t+1]) - (1 - rDepr_CCS[sp,t]) * (pI_s['iM',sp,t+1] - pI_s['iM',sp,t+1]*EKtax['iM',sp,t+1])*fp
        # Production tax on capital
        + (1-tCorp[t+1]) * tK['iM',sp,t+1] * pI_s['iM',sp,t+1]*fp
        # Tax shield on collateral value on capital
        - (rFirms[sp,t+1] - rBonds[sp,t+1] * (1-tCorp[t+1])) * sDebt2k['iM',sp,t] * pI_s['iM',sp,t];

  # Investment costs are total LEVC on CCS (both non-energy and energy)
  E_qI_CCS_levelized[s,t]$(tx0[t] and (sum((techCCS,purpose,energy19,emm), d1thetaCCS[techCCS,purpose,energy19,s,t,emm]) or sum((techCCS,emm), d1thetaCCSxE[techCCS,s,t,emm])))..
    qI_CCS_levelized['iM',s,t] =E= sum((purpose,energy19a,emm)$(sum(energy19, d1qREE[purpose,energy19a,energy19,s,t] and sum(techCCS, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])) and (sameas[emm,'CO2ubio'] or sameas[emm,'CO2bio'])), 
                                        qLEVC_CCS_EmmE_RE[purpose,energy19a,s,t,emm]) # Cost of CCS on energy related emissions
                                 + sum(emm$(d1EmmProdxE[s,t,emm] and sum(techCCS, d1thetaCCSxE[techCCS,s,t,emm]) and sameas[emm,'CO2ubio']), 
                                        qLEVC_CCS_EmmxE[s,t,emm]); # Cost of CCS on non-energy related emissions

  # Value of additonal investment demand (levelized)
  E_vI_CCS_levelized[sp,t]$(tx0[t] and (sum((techCCS,purpose,energy19,emm), d1thetaCCS[techCCS,purpose,energy19,sp,t,emm]) or sum((techCCS,emm), d1thetaCCSxE[techCCS,sp,t,emm])))..
    vI_CCS_levelized['iM',sp,t] =E= qI_CCS_levelized['iM',sp,t]*pI_s['iM',sp,t];

  # Total capital demand, implied by levelized investment demand and user cost:
  E_qK_CCS_demand[sp,t]$(tx0[t] and not t1[t] and (sum((techCCS,purpose,energy19,emm), d1thetaCCS[techCCS,purpose,energy19,sp,t,emm]) or sum((techCCS,emm), d1thetaCCSxE[techCCS,sp,t,emm])))..
    vI_CCS_levelized['iM',sp,t] =E= pK_CCS['iM',sp,t]*qK_CCS_demand['iM',sp,t-1]; 

  # Terminal condition:
  E_qK_CCS_demand_terminal[sp,t]$(tend[t] and (sum((techCCS,purpose,energy19,emm), d1thetaCCS[techCCS,purpose,energy19,sp,t,emm]) or sum((techCCS,emm), d1thetaCCSxE[techCCS,sp,t,emm])))..
    qK_CCS_demand['iM',sp,t] =E= qK_CCS_demand['iM',sp,t-1];

  # Investment necessary to cover total capital demand:
  E_qI_CCS_tilde[sp,t]$(tx0[t] and (sum((techCCS,purpose,energy19,tt,emm), d1thetaCCS[techCCS,purpose,energy19,sp,tt,emm]) or sum((techCCS,tt,emm), d1thetaCCSxE[techCCS,sp,tt,emm])))..
    qI_CCS_tilde[sp,t] =E= qK_CCS_demand['iM',sp,t] - (1 - rDepr_CCS[sp,t]) * qK_CCS_demand['iM',sp,t-1]/fq 
                         - qI_CCS_tilde_baseline[sp,t]; # We subtract frontloaded investments in baseline in order to fix the investment profiles for technologies that are adopted in the baseline, when moving shock year

  # Spread necessary investments evenly over T_CCS periods preceeding year of capital demand (if front-loading is activated):
  E_qI_CCS_actual_start[sp,t]$(tx0[t] and (t.val<=(t0.val+T_CCS)) and (sum((techCCS,purpose,energy19,ttt,emm), d1thetaCCS[techCCS,purpose,energy19,sp,ttt,emm]) or sum((techCCS,ttt,emm), d1thetaCCSxE[techCCS,sp,ttt,emm])))..
    qI_CCS_actual['iM',sp,t] =E= (1-switch_CCS_frontloading)*qI_CCS_levelized['iM',sp,t]
                                + switch_CCS_frontloading * (sum(tt$(tt.val >= t.val and tt.val < t.val + T_CCS and not tt.val=t0.val), 
                                                                qI_CCS_tilde[sp,tt]/(min[(tt.val - t0.val),T_CCS]))
                                                             + qI_CCS_actual_baseline['iM',sp,t]); # We add frontloaded investments in baseline in order to fix the investment profiles for technologies that are adopted in the baseline, when moving shock year

  E_qI_CCS_actual[sp,t]$(tx0[t] and (t.val>(t0.val+T_CCS)) and (t.val<=(tend.val-T_CCS)) and (sum((techCCS,purpose,energy19,ttt,emm), d1thetaCCS[techCCS,purpose,energy19,sp,ttt,emm]) or sum((techCCS,ttt,emm), d1thetaCCSxE[techCCS,sp,ttt,emm])))..
    qI_CCS_actual['iM',sp,t] =E= (1-switch_CCS_frontloading)*qI_CCS_levelized['iM',sp,t]
                                + switch_CCS_frontloading * (sum(tt$(tt.val >= t.val and tt.val < t.val + T_CCS and not tt.val=t0.val), 
                                                                qI_CCS_tilde[sp,tt])/T_CCS
                                                            + qI_CCS_actual_baseline['iM',sp,t]);

  E_qI_CCS_actual_terminal[sp,t]$(tx0[t] and (t.val>(tend.val-T_CCS)) and (sum((techCCS,purpose,energy19,ttt,emm), d1thetaCCS[techCCS,purpose,energy19,sp,ttt,emm]) or sum((techCCS,ttt,emm), d1thetaCCSxE[techCCS,sp,ttt,emm])))..
    qI_CCS_actual['iM',sp,t] =E= (1-switch_CCS_frontloading)*qI_CCS_levelized['iM',sp,t]
                                + switch_CCS_frontloading * (sum(tt$(tt.val >= t.val and tt.val < t.val + T_CCS and not tt.val=t0.val), 
                                                                qI_CCS_tilde[sp,tt])/T_CCS*(T_CCS/(tend.val - t.val + 1))
                                                            + qI_CCS_actual_baseline['iM',sp,t]);

  $ENDBLOCK

	$MODEL M_abatement
		B_abatement_energy_activities
    B_abatement_ID
    B_abatement_CCS
	;	

$ENDIF

# ======================================================================================================================
# Exogenous variables and data assignment
# ======================================================================================================================
$IF %stage% == "exogenous_values":

############################################################################
############ Exogeneous values and initial values for solver ###############
############################################################################

qREE.l[purpose,energy19a,energy19,r,t]$((qREgj.l[purpose,energy19,r,t]) and sameas(energy19,energy19a)) = EN_qRE[purpose,energy19,r,t];

# Set initial values:
pK_ID.l['iM',sp,t]  = pK.l['im',sp,t];
pK_CCS.l['iM',sp,t] = pK.l['im',sp,t];

# Set dummies (d1qREE is in "Update_dummies.gms:

d1thetaID[techID,purpose,energy19a,energy19,s,t] = no;
d1thetaID_k[techID,purpose,energy19a,s,t] = no;
d1switchID = yes;
d1thetaCCS[techCCS,purpose,energy19,s,t,emm] = no;
d1thetaCCSxE[techCCS,s,t,emm] = no;
d1switchCCS = yes;


###################################################################
############ General abatement parameters and values ##############
###################################################################

switch_abatement = 1; #This controls whether abatement is activated

# These switches control whether abatement forward looking and/or sluggish. Should be set to 0 (not forward-looking or sluggish) or 1
switch_forward_looking = 1; # Perhaps this should be controlled individually for ID and CCS...
switch_sluggish = 1; # Perhaps this should be controlled individually for ID and CCS...
switch_ID_sluggish = 0;

# Depreciation rate of abatement technologies:
rDepr_ID.l[sp,tData] = 0.10;
rDepr_CCS.l[sp,tData] = 0.05;

# Techbnology penetration (excl. j-term) may not be above 1% in baseline:
parameter max_baseline_adoption_error;
max_baseline_adoption_error = switch_abatement*0.01;


###################################################################
############ Input-displacing parameters and values ###############
###################################################################

switch_ID = 1; #Activate ID abatement
sigmaID.l[techID]$(sum((purpose,energy19a,s,t), d1thetaID_k[techID,purpose,energy19a,s,t])) = 0.0005; # Set smoother for ID technologies

# Set initial adoption (for calibration purposes, see premodel below)
rID.l[techID,purpose,energy19a,s,t]$((tx0[t] or t0[t]) and d1thetaID_k[techID,purpose,energy19a,s,t]) = max_baseline_adoption_error;  
rID_actual.l[techID,purpose,energy19a,s,t]$(tx0[t]) = rID.l[techID,purpose,energy19a,s,t];
rID_preferred.l[techID,purpose,energy19a,s,t]$(tx0[t]) = rID.l[techID,purpose,energy19a,s,t];

uREExID.l[purpose,energy19a,energy19,s,t]$(sameas(energy19a,energy19) and tx0[t]) = 1; # Set baseline leontief shares to 1 where energy19a = energy19 (0 elsewhere)
uIDbeta.l = 0.5; #This parameter controls the degree of forward-lookingness for ID technologies
rhoID[techID] = 0.8; #This parameter controls the degree of sluggishness for ID technologies
uIDscalar.l[techID,tData] = 1; # HACK: Arbitrary extra costs for now - awaiting info from ENS

#This parameter may be used to introduce a hurdle rate in the ID technology adoption (not currently used)
#  lambda_ID = 0.585361; # Calibrated from TIMES technology data (average difference between capital costs and user costs)
lambda_ID=0;

# This switch controls whether investments should be front-loaded, or follow levelized costs:
#  switch_ID_frontloading = 1;
switch_ID_frontloading = 0;

# Number of investment periods prior to implementation of technologies (if front-loaded investments are activated):
T_ID = 2;

############################################################
############    CCS parameters and values    ###############
############################################################

switch_CCS[techCCS] = 1; # Activate CCS abatement (may be technology-specific)

# Set initial adoption (for calibration purposes, see premodel below)
rCCS.l[techCCS,s,purpose,t]$(tx0[t] and sum((energy19,emm), d1thetaCCS[techCCS,purpose,energy19,s,t,emm])) = max_baseline_adoption_error;

sigmaCCS.l[techCCS] = 0.1;   # Set smoother for CCS technologies
uCCSbeta.l = 0.5;            # This parameter controls the degree of forward-lookingness for CCS technologies
#  rhoCCS[techCCS] = 0.8;       # This parameter controls the degree of sluggishness for CCS technologies
uCCSscalar.l[techCCS,s,purpose,t]$(tx0[t] and sum((energy19,emm), d1thetaCCS[techCCS,purpose,energy19,s,t,emm])) = 1; # Set parameter for scaling perceived costs. May be set different from >1, to introduce a hurdle rate for CCS technologies
rCCS_max_sh[techCCS]$(sum((purpose,energy19,s,t,emm), d1thetaCCS[techCCS,purpose,energy19,s,t,emm]))     = 0.2; # Determines that a maximum of 20 pct. of CCS can be adopted each year (sluggish adoption)
epsilon_CCS = 0.0001;       # Determines the degree of smoothing in the smoothed minimum function for sluggish adoption


# This switch controls whether investments should be front-loaded, or follow levelized costs:
switch_CCS_frontloading = 1;
# Number of investment periods prior to implementation of technologies (if front-loaded investments are activated):
T_CCS = 5;

#  parameter epsCCS;
#  epsCCS = 0.0000001; #Parameter der skal indgå, hvis man bruger log-normalfordelte omkostninger i stedet for normalfordelte (for at undgå log(0)-fejl)

$ENDIF

# ======================================================================================================================
# Static calibration
# ======================================================================================================================
$IF %stage% == "static_calibration":

  # Check that we do not use energy where there are no prices.
    parameters missing_prices[purpose,energy19,s,t], tjek_mp;
    missing_prices[purpose,energy19,s,t]$(tx0[t] and sum((techID,energy19a)$(d1thetaID[techID,purpose,energy19a,energy19,s,t]), thetaID.l[techID,purpose,energy19a,energy19,s,t])) = yes;
    missing_prices[purpose,energy19,s,t]$(tx0[t] and d1tRE[purpose,energy19,s,t]) = no;
    tjek_mp = sum((purpose,energy19,s,t),missing_prices[purpose,energy19,s,t]);
    ABORT$(abs(tjek_mp) gt 1e-6) missing_prices, "Technologies employ energy sources where prices are missing"

 # Shadow taxes are calibrated for ID and CCS technologies in the premodels below, ensuring baseline adoption (excl. j-terms) between 0% and 1%.
 # j-terms are calibrated later as part of the full model calibration, ensuring that the actual baseline adoption is exactly 0 (see G_abatement_static_calibration and G_abatement_calib)

 #  Small model to ensure zero technology adoption in data years (START)
  # $MODEL rID_calib
  #   E_rID_input
  #   E_rID; 
  # $GROUP G_rID_calib_endo 
  #   rID_input$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t])
  #   uIDt$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t]);
  # $GROUP G_rID_calib_exo
  #   rID$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t])
  #   thetaID$(tx0[t] and d1thetaID[techID,purpose,energy19a,energy19,s,t])
  #   pI_s$(tx0[t] and sameas(i_,'iM'))
  #   thetaID_K$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t])
  #   uIDscalar$(tx0[t] and sum(purpose, sum(energy19a, sum(s, d1thetaID_k[techID,purpose,energy19a,s,t]))))
  #   uIDt$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t])
  #   sigmaID$(sum(purpose, sum(energy19a, sum(s, sum(t, d1thetaID_k[techID,purpose,energy19a,s,t])))))
  #   j_rID$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t]);
 #  Small model to ensure zero technology adoption in data years (END)

 #  Small model to ensure zero CCS technology adoption in data years (START)
  #  $MODEL rCCS_calib
  #    #  E_rCCS_gains
  #    #  E_rCCS_costs
  #    #  E_rCCS_input
  #    E_rCCS;
  # $GROUP G_rCCS_calib_endo
    #  rCCS_gains[techCCS,purpose,energy19,s,t,emm]$(tx0[t] and sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,t,emm]))
    #  rCCS_costs[techCCS,purpose,energy19,s,t,emm]$(tx0[t] and sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,t,emm]))
    #  rCCS_input[techCCS,purpose,energy19,s,t,emm]$(tx0[t] and sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,t,emm]))
    #  uCCSt[techCCS,purpose,energy19,s,t,emm]$(tx0[t] and d1thetaCCS[techCCS,purpose,energy19,s,t,emm]);
# ;
  #Heavy over-exogenization
  # $GROUP G_rCCS_calib_exo
  #   rCCS
  #   vtCO2_REmarg$(d1CO2_RE[purpose,energy19,r,t])
  #   #  uCCSt
  #   thetaCCS
  #   #  thetaCCS_K
  #   pI_s$(tx0[t] and sameas(i_,'iM'))
  #   #  uCCSscalar
  #   sigmaCCS
  #   #  j_rCCS
  #   qEmmProdS
  # ;
 #  Small model to ensure zero CCS technology adoption in data years (END)

#  $FIX G_rCCS_calib_exo;
#  $UNFIX G_rCCS_calib_endo;
#  @solve(rCCS_calib);


#  rCCS.l[techCCS,purpose,energy19,s,t,emm]$(uCCSt.l[techCCS,purpose,energy19,s,t,emm]<0) = 0;
#  uCCSt.l[techCCS,purpose,energy19,s,t,emm]$(uCCSt.l[techCCS,purpose,energy19,s,t,emm]<0) = 0; #If the shadow tax is negative, baseline adoption (excl. j_term) i already below 1%, and we don't need a shadow tax.
#  j_rCCS.l[techCCS,purpose,energy19,s,t,emm] = -rCCS.l[techCCS,purpose,energy19,s,t,emm]; #
#What is the point of the above dollar condition if everything is set to zero here below???
# rCCS.l[techCCS,s,purpose,t] = 0;

  $GROUP G_abatement_static_calibration 
  	  G_abatement_endo
      # - rID$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t]), j_rID$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t])
      # #  - rCCS$(tx0[t] and d1thetaCCS[techCCS,purpose,energy19,s,t,emm]), j_rCCS$(tx0[t] and d1thetaCCS[techCCS,purpose,energy19,s,t,emm])
  	  # uREExID$(tx0[t] and d1qREE[purpose,energy19a,energy19,s,t])
  	  # - qREE$(tx0[t] and d1qREE[purpose,energy19a,energy19,s,t])
      # j_qI_ID_baseline[sp,t], -qI_ID_levelized[i,sp,t]$(sameas(i,'iM'))
      -pK_ID
      -pK_CCS
      -qK_ID_demand
      -qK_CCS_demand
   ;

  $GROUP G_abatement_static_calibration_exo 
      G_abatement_exo
    #   rID$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t]), -j_rID$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t])
    #   #  rCCS$(tx0[t] and d1thetaCCS[techCCS,purpose,energy19,s,t,emm]), -j_rCCS$(tx0[t] and d1thetaCCS[techCCS,purpose,energy19,s,t,emm])
	  # - uREExID$(tx0[t] and d1qREE[purpose,energy19a,energy19,s,t])
  	#   qREE$(tx0[t] and d1qREE[purpose,energy19a,energy19,s,t])
    #   -j_qI_ID_baseline[sp,t], qI_ID_levelized[i,sp,t]$(sameas(i,'iM'))
      pK_ID
      pK_CCS
      qK_ID_demand
      qK_CCS_demand
   ;



  $MODEL M_abatement_static_calibration
  M_abatement
  -E_pK_ID
  -E_qK_ID_demand_terminal
  -E_qK_ID_demand #In a usual CES-calibration this equation would be kept to calibrate the CES-share. However, as there is no CES-share the equation is redundant and does not determine any variable 
  -E_qI_ID_actual_terminal # The terminal condition doesn't work when we only calibrate one year


  -E_pK_CCS
  -E_qK_CCS_demand
  -E_qK_CCS_demand_terminal
  ;

$ENDIF



# ======================================================================================================================
# Dynamic calibration
# ======================================================================================================================
$IF %stage% == "dynamic_calibration":

# rID.l[techID,purpose,energy19a,s,t]$(d1thetaID_k[techID,purpose,energy19a,s,t]) = max_baseline_adoption_error;

# $FIX G_rID_calib_exo;
# $UNFIX G_rID_calib_endo;
# @solve(rID_calib);

# Remove shadow taxes if they are in fact shadow subsidies (i.e. if no shadow tax is required to minimize baseline adoption)
# rID.l[techID,purpose,energy19a,s,t]$(uIDt.l[techID,purpose,energy19a,s,t]<0) = 0;
# uIDt.l[techID,purpose,energy19a,s,t]$(uIDt.l[techID,purpose,energy19a,s,t]<0) = 0;
# j_rID.l[techID,purpose,energy19a,s,t] = -rID.l[techID,purpose,energy19a,s,t];
# rID.l[techID,purpose,energy19a,s,t] = 0; # Baseline adoption is 

#  rCCS.l[techCCS,purpose,energy19,s,t,emm] = max_baseline_adoption_error;

#  $FIX G_rCCS_calib_exo;
#  $UNFIX G_rCCS_calib_endo;
#  @solve(rCCS_calib);

# Remove shadow taxes if they are in fact shadow subsidies (i.e. if no shadow tax is required to minimize baseline adoption)
#  rCCS.l[techCCS,purpose,energy19,s,t,emm]$(uCCSt.l[techCCS,purpose,energy19,s,t,emm]<0) = 0;
#  uCCSt.l[techCCS,purpose,energy19,s,t,emm]$(uCCSt.l[techCCS,purpose,energy19,s,t,emm]<0) = 0;
#  j_rCCS.l[techCCS,purpose,energy19,s,t,emm] = -rCCS.l[techCCS,purpose,energy19,s,t,emm];
#  rCCS.l[techCCS,purpose,energy19,s,t,emm] = 0;

	$GROUP G_abatement_calib
    G_abatement_endo
      # Baseline adoption is exogenized (rID, rCCS = 0) and the j-terms are endogenized in the calibration. Giving: -1 <= j-term < 0. 
      -rID$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t]), j_rID$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t])
      #  -rCCS$(tx0[t] and d1thetaCCS[techCCS,purpose,energy19,s,t,emm]), j_rCCS$(tx0[t] and d1thetaCCS[techCCS,purpose,energy19,s,t,emm])
      -qK_ID_demand$(t1[t]) #To pin down ID-investments capital stock ultimo last data year is fixed (at zero currently)  
      #  -qK_CCS_demand$(t1[t])
      j_qK_ID_demand_tDataEnd$(tx1[t])
      #  j_qK_CCS_demand_tDataEnd$(tx1[t])
  ;


  $GROUP G_abatement_calib_exo
    G_abatement_exo
      rID$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t]), -j_rID$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t])
      rID$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t+1])
      #  rCCS$(tx0[t] and d1thetaCCS[techCCS,purpose,energy19,s,t,emm]), -j_rCCS$(tx0[t] and d1thetaCCS[techCCS,purpose,energy19,s,t,emm])
      qK_ID_demand$(t1[t]) 
      #  qK_CCS_demand$(t1[t])
      -j_qK_ID_demand_tDataEnd$(tx1[t])
      #  -j_qK_CCS_demand_tDataEnd$(tx1[t])
  ;

  $BLOCK B_abatement_calib
    E_j_qK_ID_demand_tDataEnd[sp,t]$(t.val > t2.val and d1k['im',sp,t]).. #The tiniest amount of ID (~10^(-20)) enters in baseline and hence necessetates a J-term. 
      j_qK_ID_demand_tDataEnd[sp,t] =E= 0*j_qK_ID_demand_tDataEnd[sp,t-1];

    #  E_j_qK_CCS_demand_tDataEnd[sp,t]$(t.val > t2.val and d1k['im',sp,t] and sum((techCCS,purpose,energy19,tt,emm), rCCS.l[techCCS,purpose,energy19,sp,tt,emm])).. #If rCCS <> 0 then there is CCS in baseline. Otherwise the J-term is redundant and should not enter calibration
    #    j_qK_CCS_demand_tDataEnd[sp,t] =E= 0*j_qK_CCS_demand_tDataEnd[sp,t-1];


  $ENDBLOCK


  $MODEL M_abatement_calib
  M_abatement
  B_abatement_calib
  ;

$ENDIF