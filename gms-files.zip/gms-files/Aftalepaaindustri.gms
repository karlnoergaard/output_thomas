#====================================================================================================================================================================================================================#
# GENINDFØRSEL AF AFTALE PÅ INDUSTRI OG GRØN TREPART
#====================================================================================================================================================================================================================#

	#Først laves der nye baseline-values
	$IMPORT create_baseline_values.gms;
	$SETGLOBAL shockmodel 1 #option in report.gms 
	$SETGLOBAL sanitycheckendoland 1
	$SETGLOBAL negativafgiftskov 1

	#SÆTTER AFGIFTER
	d1BotdedCO2post25 =0;

	$OnMultiR
		$call gdxxrw.exe I="%MargTaxesAfter2022Corrected%.xlsx" O="%MargTaxesAfter2022Corrected%.gdx" par=tEAFG_REmarg_SKM_in rng=Energi!A1:S20 par=tSO2_REmarg_SKM_in rng=SO2_done!A1:O29 par=tCO2_REmarg_SKM_in rng=CO2_done!A1:T25
		$gdxin "%MargTaxesAfter2022Corrected%.gdx"
		$onUNDF
		$load tEAFG_REmarg_SKM_in tSO2_REmarg_SKM_in tCO2_REmarg_SKM_in
		$gdxin
	$OffMulti

	$SETGLOBAL saerbehandl_mineralogi 1

	@set_marginaltaxes();

	$FIX G_exo;
	$UNFIX G_endo;
	#  @SOLVE(M_shock_GSRdel1);


	#Mineralogi ikke-energirelateret
	tCO2_ProdxE.l[s,t,'CO2ubio'] = 0;
    tCO2_ProdxE.l['23001',t,'CO2ubio'] =  tCO2_REmarg_SKM.l['cement_ETS',t];   #sum((categoryENS,GSR_ag,tREbase_SKM)$(sum((energy19,purpose),sENS2GR(categoryENS, GSR_ag, purpose, energy19, s)) and sum(energy19,tREbase_SKM_2_ENS(tREbase_SKM,categoryENS,GSR_ag,energy19)) and EM_NER[emm,s,'2019']), tCO2_REmarg_SKM.l[tREbase_SKM,t])/GWP_UN_obs[emm];
    tCO2_ProdxE.l[s,t,'CO2ubio']$(sum((purpose,energy19), mapGrREFORM2GSR[purpose,energy19,s,'Mineralogi_oevrig',t])) =  tCO2_REmarg_SKM.l['cement_ETS',t];

    #F-gasser 
    tCO2_ProdxE.l[s,t,emm]$(t.val >=2027 and d1EmmProdxE[s,t,emm] and (sameas[emm,'HFC'] or sameas[emm,'PFC'] or sameas[emm,'SF6'])) = 750 * inf_factor['2023']; #Der indsættes 750 kroners afgift, men hvad var udgangsunktet?

    d1CO2_ProdxE[s,t,emm]              = yes$(tCO2_ProdxE.l[s,t,emm]);

	#Raffinaderier
    qY_CET.l[out,s,t] $(d1ExoProduction[out,s]) = qY_CET.l[out,s,t] * (1-ShutdownStructRaff*tImplement[t]);

    #Fiskeri
    qY_CET.l['out_other','03000',t] = qY_CET.l['out_other','03000',t]  * (1-ShutdownStructFish * tImplement[t]);

	#  Cement
	qY_CET.l['out_other','23001',t] = qY_CET.l['out_other','23001',t] * (1-ShutdownStructCement*tImplement[t]);

	$IMPORT STRUKTUREFFEKTER.GMS 


$GROUP G_exo 
    G_EXO
    #Cement
    qY_CET$(tx0[t] and sameas[out,'out_other'] and sameas[s,'23001']), -markup$(tx0[t] and sameas[out,'out_other'] and sameas[s,'23001'])
    pY_CET$(tx0[t] and sameas[out,'out_other'] and sameas[s,'23001']), -sX_y$(tx0[t] and sameas[x,'xOth'] and sameas[s,'23001'])
;

$GROUP G_endo 
    G_ENDO
    #Cement
    -qY_CET$(tx0[t] and sameas[out,'out_other'] and sameas[s,'23001']), markup$(tx0[t] and sameas[out,'out_other'] and sameas[s,'23001'])
    -pY_CET$(tx0[t] and sameas[out,'out_other'] and sameas[s,'23001']), sX_y$(tx0[t] and sameas[x,'xOth'] and sameas[s,'23001'])
;





	$FIX G_exo;
	$UNFIX G_endo;
	@SOLVE(M_shock_GSRdel1);


	$IMPORT report.gms
	$IMPORT sanitycheck.gms
	execute_unload 'output\aftalepaaindustri.gdx';
	$SETGLOBAL shockmodel 0;
	#  @check_vBoP();

