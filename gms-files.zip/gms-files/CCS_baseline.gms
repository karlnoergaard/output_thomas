

    parameter
        totalCCSSubsidy[t]
        ;


$IF '%EA_data%'=='yes':

    ## ---------------------------------------------------------------------------------------------------------
    ## Setting up the partial model
    ## ---------------------------------------------------------------------------------------------------------

    $MODEL M_abatement_partial_alt
        M_abatement_partial
        ;

    $GROUP G_abatement_partial_endo
        G_abatement_partial_endo
        ;

    $GROUP G_abatement_partial_exo
        G_abatement_partial_exo
        ;

$ENDIF


# ----------------------------------------------------------------------------------------------------------------------
# Setting up the model
# ----------------------------------------------------------------------------------------------------------------------

$MODEL M_CCS_baseline
    M_calib_abatement
;

$GROUP G_endo
    G_endo
;

$GROUP G_exo
    G_exo
;

$IF '%EA_data%'=='yes':
    ##================================================================================================================
    # Solve model with CCS in 2030-baseline
    ##================================================================================================================

    #Now we move start year to 2023 
    $SETGLOBAL start_shock_year 2022 #Year where we start the shock
    set_time_periods(%start_shock_year%,%terminal_year%);

    qI_CCS_tilde_baseline.l[sp,t]   = 0;
    qI_CCS_actual_baseline.l[i,s,t] = 0;

    # Maximum subsidy for CCS
    tSubsidy_CCS_maks.l[techCCS,s,purpose,t,emm]$(t.val > 2025 and t.val <= 2030 and sum((energy19,tt), d1thetaCCS[techCCS,purpose,energy19,s,tt,emm])) = 550;
    tSubsidy_CCSxE_maks.l[techCCS,s,t,emm]$(t.val > 2025 and t.val <= 2030 and sum(tt, d1thetaCCSxE[techCCS,s,tt,emm]))                                 = 550;

    tSubsidy_CCS_maks.l[techCCS,s,purpose,t,emm]$(t.val >= 2031 and sum((energy19,tt), d1thetaCCS[techCCS,purpose,energy19,s,tt,emm])) = 340;
    tSubsidy_CCSxE_maks.l[techCCS,s,t,emm]$(t.val >= 2031 and sum(tt, d1thetaCCSxE[techCCS,s,tt,emm]))                                 = 340;

    tSubsidy_CCS_maks.l[techCCS,s,purpose,t,emm]$(t.val > 2030 and t.val < 2035 and sum(energy19, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])) 
                    = tSubsidy_CCS_maks.l[techCCS,s,purpose,'2030',emm] + (tSubsidy_CCS_maks.l[techCCS,s,purpose,'2035',emm] - tSubsidy_CCS_maks.l[techCCS,s,purpose,'2030',emm])/5*(t.val - 2030);
    tSubsidy_CCSxE_maks.l[techCCS,s,t,emm]$(t.val > 2030 and t.val < 2035 and d1thetaCCSxE[techCCS,s,t,emm])                                     
                    = tSubsidy_CCSxE_maks.l[techCCS,s,'2030',emm] + (tSubsidy_CCSxE_maks.l[techCCS,s,'2035',emm] - tSubsidy_CCSxE_maks.l[techCCS,s,'2030',emm])/5*(t.val - 2030);

    # Solve partial abatement model (including partial energy price model)
    $FIX G_abatement_partial_exo;
    $UNFIX G_abatement_partial_endo;
    @SOLVE(M_abatement_partial_alt);

$ENDIF 

# Solve the full model with exogenous ID
d1switchID = 0;

$FIX G_exo;
$UNFIX G_endo;
#  execute_unloaddi 'Output\Pre_CCS_baseline.gdx';
@SOLVE(M_CCS_baseline);

# Solve the full model with endogenous CCS and ID
d1switchID = 1;
    
$FIX G_exo;
$UNFIX G_endo;
# execute_unloaddi 'Output\Pre_CCS_baseline.gdx';
@SOLVE(M_CCS_baseline);

qI_CCS_tilde_baseline.l[sp,t]   = qI_CCS_tilde.l[sp,t];
qI_CCS_actual_baseline.l[i,s,t] = qI_CCS_actual.l[i,s,t];

qEmmCCStot[t] = sum(s, sumqEmmCCSbio.l[s,t] + sumqEmmCCSubio.l[s,t]);

totalCCSSubsidy[t] = (sum((s,emm), vSubsidy_CCS_EmmxE.l[s,t,emm]) + sum((purpose,energy19a,s,emm), vSubsidy_CCS_EmmE_RE.l[purpose,energy19a,s,t,emm]))/growth_factor[t];


# $import report_all.gms
execute_unloaddi 'Output\CCS_baseline.gdx';
@check_vBoP();

$IF '%EA_data%'=='yes':
    # Check that CCS reductions are approximately the same as in KF in 2030
    tjek = qEmmCCStot['2030'] + 2900;
    # ABORT$(abs(tjek) > 100) tjek, "CCS reductions deviates from KF in 2030";
$ENDIF 

#Testing total emissions and setting J-term in total emissions exogenous

    $GROUP G_endo
        G_endo 
        -jEmmTot_UNFCCC_LULUCF_Calib2KF, qEmmtot[t,'CO2e','UNFCCC_Lulucf']
    ;

    $GROUP G_exo 
        G_exo 
        jEmmTot_UNFCCC_LULUCF_Calib2KF, -qEmmtot[t,'CO2e','UNFCCC_Lulucf']
    ;

    @test_emm_unfccc_lulucf_aftercalibID_and_CCS(10);
