
parameter
    totalCCSSubsidy[t]
    ;



$BLOCK B_equation_change

## --------------------------------------------------------------------------------------
# Anderledes indtrængningsprofil (CCS-abatement)
## --------------------------------------------------------------------------------------

  # Actual technology adoption is based on linear implementation in four years (DØRS assumption)
  E_rCCS_actual_NoAdoption2030[techCCS,purpose,energy19,s,t,emm]$(tx0[t] and d1thetaCCS[techCCS,purpose,energy19,s,t,emm])..
       rCCS_actual[techCCS,purpose,energy19,s,t,emm] =E=  
       (1-switch_sluggish)*rCCS_preferred[techCCS,s,purpose,energy19,t]  
      + switch_sluggish*(min[rCCS_actual[techCCS,purpose,energy19,s,t-1,emm]+0.25*rCCS_preferred[techCCS,s,purpose,energy19,t],1]) ;

  # Actual technology adoption (with sluggishness, if switch_sluggish = 1)
  E_rCCSxE_actual_NoAdoption2030[techCCS,s,t,emm]$(tx0[t] and d1thetaCCSxE[techCCS,s,t,emm])..
       rCCSxE_actual[techCCS,s,t,emm] =E=  
       (1-switch_sluggish)*rCCSxE[techCCS,s,t,emm]  
      + switch_sluggish*(min[rCCSxE_actual[techCCS,s,t-1,emm]+0.25*rCCSxE[techCCS,s,t,emm],1]);

$ENDBLOCK

#  ## --------------------------------------------------------------------------------------
#  # Fremadskuethed ved CCS-puljer
#  ## --------------------------------------------------------------------------------------

parameter
    T_CCS_adoption
    ;

T_CCS_adoption = 15;

$GROUP G_CCS_adoption
    rCCS_input_alt[techCCS,s,purpose,t]$(tCCS[t] and sum(energy19, sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])))
;


$BLOCK B_CCS_adoption

    # Input for calculating instantaneous adoption rate (assuming normally distributed costs)
    E_rCCS_input_alt[techCCS,s,purpose,t]$(tCCS[t] and (t.val<=(tend.val-T_CCS_adoption)) and sum((energy19,emm), d1thetaCCS[techCCS,purpose,energy19,s,t,emm])).. 
        rCCS_input[techCCS,s,purpose,t] =E= (sum(tt$(tt.val >= t.val and tt.val < t.val + T_CCS_adoption),
                                                            (rCCS_gains[techCCS,s,purpose,tt] - rCCS_costs[techCCS,s,purpose,tt] - uCCSt[techCCS,s,purpose,tt]) / ((1.07)**(tt.val-t.val))) 
                                                            /T_CCS_adoption)
                                                / sigmaCCS[techCCS];
    
# 1) Diskontering og 2) vægtet med antal reduktioner

    # Input for calculating instantaneous adoption rate (assuming normally distributed costs)
    E_rCCS_input_terminal_alt[techCCS,s,purpose,t]$(tCCS[t] and (t.val>(tend.val-T_CCS_adoption)) and sum((energy19,emm), d1thetaCCS[techCCS,purpose,energy19,s,t,emm])).. 
        rCCS_input[techCCS,s,purpose,t] =E= (sum(tt$(tt.val >= t.val and tt.val < t.val + T_CCS_adoption),
                                                            (rCCS_gains[techCCS,s,purpose,tt] - rCCS_costs[techCCS,s,purpose,tt] - uCCSt[techCCS,s,purpose,tt]) / ((1.07)**(tt.val-t.val))) 
                                                            /T_CCS_adoption*(T_CCS_adoption/(tend.val - t.val + 1)))
                                                / sigmaCCS[techCCS];

$ENDBLOCK


## ---------------------------------------------------------------------------------------------------------
## Setting up the partial model
## ---------------------------------------------------------------------------------------------------------

$MODEL M_abatement_partial_alt
    M_abatement_partial

    #  -E_rCCS_input, B_CCS_adoption
    ;

$GROUP G_abatement_partial_endo
    G_abatement_partial_endo

    #  G_CCS_adoption
    ;

$GROUP G_abatement_partial_exo
    G_abatement_partial_exo

    #  rCCS_gains[techCCS,s,purpose,tt]$(tCCS[t] and sum(energy19, sum(tt, sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,tt,emm]))) and not sum(energy19, sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])))
    #  rCCS_costs[techCCS,s,purpose,tt]$(tCCS[t] and sum(energy19, sum(tt, sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,tt,emm]))) and not sum(energy19, sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])))
    #  uCCSt[techCCS,s,purpose,tt]$(tCCS[t] and sum(energy19, sum(tt, sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,tt,emm]))) and not sum(energy19, sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])))
    ;

$FIX G_abatement_partial_exo;
$UNFIX G_abatement_partial_endo;
@SOLVE(M_abatement_partial_alt);



# ----------------------------------------------------------------------------------------------------------------------
# Setting up the model
# ----------------------------------------------------------------------------------------------------------------------

$MODEL M_CCS_baseline
    M_calib_CCS

    #  -E_rCCS_input, B_CCS_adoption
;

$GROUP G_endo
    G_endo

    #  G_CCS_adoption
;

$GROUP G_exo
    G_exo

    #  rCCS_gains[techCCS,s,purpose,tt]$(tCCS[t] and sum(energy19, sum(tt, sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,tt,emm]))) and not sum(energy19, sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])))
    #  rCCS_costs[techCCS,s,purpose,tt]$(tCCS[t] and sum(energy19, sum(tt, sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,tt,emm]))) and not sum(energy19, sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])))
    #  uCCSt[techCCS,s,purpose,tt]$(tCCS[t] and sum(energy19, sum(tt, sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,tt,emm]))) and not sum(energy19, sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])))
  ;


##================================================================================================================
# Solve model with CCS in 2030-baseline
##================================================================================================================

#Now we move start year to 2023 
#  $SETGLOBAL start_shock_year 2022 #Year where we start the shock
#  set_time_periods(%start_shock_year%,%terminal_year%);

qI_CCS_tilde_baseline.l[sp,t]   = 0;
qI_CCS_actual_baseline.l[i,s,t] = 0;

# Maximum subsidy for CCS
tSubsidy_CCS_maks.l[techCCS,s,purpose,t,emm]$(t.val > 2025 and t.val <= 2030 and sum((energy19,tt), d1thetaCCS[techCCS,purpose,energy19,s,tt,emm])) = 550;
tSubsidy_CCSxE_maks.l[techCCS,s,t,emm]$(t.val > 2025 and t.val <= 2030 and sum(tt, d1thetaCCSxE[techCCS,s,tt,emm]))                                 = 550;

# Solve partial abatement model (including partial energy price model)
$FIX G_abatement_partial_exo;
$UNFIX G_abatement_partial_endo;
@SOLVE(M_abatement_partial_alt);

rID.l[techID,purpose,energy19a,s,t]$(d1thetaID_k[techID,purpose,energy19a,s,t])                                                   = 0;
rID.l[techID,purpose,energy19a,s,t]$(rID_input.l[techID,purpose,energy19a,s,t] > 0 and d1thetaID_k[techID,purpose,energy19a,s,t]) = 1;

# Solve the full model
$FIX G_exo;
$UNFIX G_endo;
execute_unloaddi 'Output\Pre_CCS_baseline_2035.gdx';
@SOLVE(M_CCS_baseline);

qI_CCS_tilde_baseline.l[sp,t]   = qI_CCS_tilde.l[sp,t];
qI_CCS_actual_baseline.l[i,s,t] = qI_CCS_actual.l[i,s,t];

qEmmCCStot[t] = sum(s, sumqEmmCCSbio.l[s,t] + sumqEmmCCSubio.l[s,t]);

totalCCSSubsidy[t] = (sum((s,emm), vSubsidy_CCS_EmmxE.l[s,t,emm]) + sum((purpose,energy19a,s,emm), vSubsidy_CCS_EmmE_RE.l[purpose,energy19a,s,t,emm]))/growth_factor[t];


$import report_all.gms
execute_unloaddi 'Output\CCS_baseline_2035.gdx';
@check_vBoP();

# Check that CCS reductions are approximately the same as in KF in 2030
#  tjek = qEmmCCStot['2030'] + 2900;
#  ABORT$(abs(tjek) > 100) tjek, "CCS reductions deviates from KF in 2030";