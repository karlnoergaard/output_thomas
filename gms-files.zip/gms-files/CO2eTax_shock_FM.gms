
#====================================================================================================================================================================================================================#
 #  Stødfil hvor eksisterende CO2e-afgift hæves. Stødet kan styres via de generelle double dash parameters (dem der starter med --).
 #  --t0 bestemmer hvornår stødet skal starte og annonceres. Afgiften indfases lineært fra og med t1.
 #  --tX1 --tX2 --tX3 --sX1 --sX2 og --sX3 angiver afgiftssatsen og støttesatsen i del 1, 2 og 3.
 #  --landbrug_dy --landbrug_plante og --industri angiver hvilke afgiftsgrundlag som rammes af afgiftsstigningen 
 #  --CCS --CCS_sub --ID --Stru --Pyrolyse angiver hvilke reduktionsmekanismer som er inkluderet i beregningerne
#====================================================================================================================================================================================================================#

Parameter
	CCS_tot[t]
	;


tXprofil2.l[t] = 0;
tXprofil2.l['2031'] = 1/5;
tXprofil2.l['2032'] = 2/5;
tXprofil2.l['2033'] = 3/5;
tXprofil2.l['2034'] = 4/5;
tXprofil2.l[t]$(t.val ge 2035)  = 1;



$IF %start_shock_year% LT %t0%:
      vEquity_baseline.l[sp,t] = vEquity.l[sp,t];
$ENDIF              


# Set your start year for the shock   
$SETGLOBAL start_shock_year %t0% #Year where we start the 0-shock
set_time_periods(%start_shock_year%,%terminal_year%);

# Hvis der lægges yderligere afgift på landbrugets ikke-energirelaterede udledninger, så reduceres bundfradraget til 50 pct. og der er derved ingen afgiftsfritagelse
$IF (%landbrug_dy% or %landbrug_plante%):
	sSizeBottomDed.l[emmtype,ani_sectors,animals,t,emm]$(d1EmmAgrAni[emmtype,ani_sectors,animals,t,emm]) = 0.50;
	andelanimalsk_ejafgiftsfritaget[ani_sectors,ani_,t] = 1;
$ENDIF

$IF %frontload_inv% = 1:
	switch_Pyrolyse_frontloading = 1;
$ENDIF

$IF %frontload_inv% = 0:
	switch_Pyrolyse_frontloading = 0;
$ENDIF

parameter
	loop_pyrolyse[*,PyrolyseTech,t]
	loop_pyrolyse2[*,t]
	loop_CCS[*,*,techCCS,s,purpose,energy19,t]
	loop_CCS2[*,*,s,t]
	rCCS_last[techCCS,s,purpose,energy19,t]
	qEmmCCS_last[s,t]
	;

rCCS_last[techCCS,s,purpose,energy19,t] = rCCS.l[techCCS,s,purpose,energy19,t];
qEmmCCS_last[s,t] = sumqEmmCCSbio.l[s,t] + sumqEmmCCSubio.l[s,t];
#  parameter
#  	tXtot2030 "den samlede skattestigning i stødet i 2030 i 2022-priser"	
#  	tXtot2035 "den samlede skattestigning i stødet i 2035 i 2022-priser"	
#  	loop_output_EV "Output-parameter som samler en række EV-variable i hvert loop"
#  	sumqEmmCCSbio_baseline[s,t] 
#  	qEmmTot_pre[t]
#  	qEmm_loop_dekomp_pre, qEmm_loop_dekomp, loop_qEmm_s, loop_qEmm, loop_qEmm_brancher
#  	reduction2035_last, CO2e_base2035, reductionWeighted_last, CO2e_baseWeighted, MAT_last, EV_last
#  	loop_MAC, loop_EV, EV0
#  	;



#  qEmmTot_pre[t] = qEmmTot.l[t,'CO2e','UNFCCC_lulucf'];


tXtot2030 = 0;
tXtot2035 = 0;


#  sumqEmmCCSbio_baseline[s,t] 	= sumqEmmCCSbio.l[s,t];
#  sumqEmmCCSubio_baseline.l[s,t]	= sumqEmmCCSubio.l[s,t];


#  $import report_qEmm.gms
#  $import report_EV.gms
#  EV0[set_EV_all,opgjort] = EV[set_EV_all,opgjort];

#  qEmm_loop_dekomp_pre['qemm',s,t] = output_qEmm_s[s,'Transport',t]+output_qEmm_s[s,'ExT',t]+output_qEmm_s[s,'xE',t];
#  qEmm_loop_dekomp_pre['qY',s,t] = qY.l[s,t];
#  qEmm_loop_dekomp_pre['qY',s,t]$Plant_sectors_s(s) = sum(Plant_sectors$map_plantsectors2s(Plant_sectors,s), qPlant_CET.l[Plant_sectors,'netprod',t]);
#  qEmm_loop_dekomp_pre['qY',s,t]$Ani_sectors_s(s) = sum(Ani_sectors$map_Anisectors2s(Ani_sectors,s), qAni_CET.l[Ani_sectors,'out_other',t]);
#  qEmm_loop_dekomp_pre['CCS',s,t] = -(sumqEmmCCSbio.l[s,t] + sumqEmmCCSubio.l[s,t]);
#  output_qEmm_pre[set_qEmm_output,t] = output_qEmm[set_qEmm_output,t];
#  output_qEmm_produktion_pre[set_qEmm_output,t] = output_qEmm_produktion[set_qEmm_output,t];


#  CO2e_base2035 = output_qEmm['0 Ialt','2035'];
#  CO2e_baseWeighted = sum(t,output_qEmm['0 Ialt',t]*EVt['vaegt',t])/sum(t,EVt['vaegt',t]);

#  reduction2035_last=CO2e_base2035-output_qEmm['0 Ialt','2035'];
#  reductionWeighted_last=CO2e_baseWeighted-sum(t,output_qEmm['0 Ialt',t]*EVt['vaegt',t])/sum(t,EVt['vaegt',t]);
#  EV_last['EV_DK','yearly']= EV['EV_DK','yearly'];
#  EV_last['EV_inklUdl','yearly']= EV['EV_inklUdl','yearly'];
#  MAT_last = tXtot2035;


loop_MAC['80A', 'Reduction','2035'] =  (qEmmTot_pre['2035']-78350*0.2)/1000;
loop_MAC['80A', '80 pct. reduktion','2035'] =  0.1;
loop_MAC['80B', 'Reduction','2035'] =  (qEmmTot_pre['2035']-78350*0.2)/1000;
loop_MAC['80B', '80 pct. reduktion','2035'] =  3000;
loop_MAC['85A', 'Reduction','2035'] =  (qEmmTot_pre['2035']-78350*0.15)/1000;
loop_MAC['85A', '85 pct. reduktion','2035'] =  0.1;
loop_MAC['85B', 'Reduction','2035'] =  (qEmmTot_pre['2035']-78350*0.15)/1000;
loop_MAC['85B', '85 pct. reduktion','2035'] =  3000;
loop_MAC['90A', 'Reduction','2035'] =  (qEmmTot_pre['2035']-78350*0.1)/1000;
loop_MAC['90A', '90 pct. reduktion','2035'] =  0.1;
loop_MAC['90B', 'Reduction','2035'] =  (qEmmTot_pre['2035']-78350*0.1)/1000;
loop_MAC['90B', '90 pct. reduktion','2035'] =  3000;



# Selve stødet inkl. adfærd baseret på tX2030 og tX2035
tX2035.l = 0;
$import CO2eTax_shock_calc.gms


$SETGLOBAL indsaet 0B
$import report_qEmm.gms
$import report_EV.gms
loop_EV['%indsaet%',set_EV_all] = EV[set_EV_all,'yearly']-EV0[set_EV_all,'yearly'];
$IF (%landbrug_dy% or %landbrug_plante%):
	$import loop_MAC.gms
$ENDIF
$import loop_CCS.gms
$import loop_qEmm_dekomp.gms
execute_unload 'Output\CO2eTax_shock_steps_temp.gdx';



#  Del 1 80 pct. reduktion

tX2035.l = %tX1%/3;
$import CO2eTax_shock_calc.gms

$SETGLOBAL indsaet del1_1
$import report_qEmm.gms
$import report_EV.gms
$import report_SKM_teknisk.gms
$import loop_MAC.gms
$import loop_CCS.gms
$import loop_pyrolyse.gms
$import loop_qEmm_dekomp.gms
#  execute_unload 'Output\CO2eTax_shock_steps_temp.gdx';
execute_unload 'Output\%gdxnavn%_del1_1.gdx';


tX2035.l = %tX1%/3;
$import CO2eTax_shock_calc.gms

$SETGLOBAL indsaet del1_2
$import report_qEmm.gms
$import report_EV.gms
$import report_SKM_teknisk.gms
$import loop_MAC.gms
$import loop_CCS.gms
$import loop_pyrolyse.gms
$import loop_qEmm_dekomp.gms
#  execute_unload 'Output\CO2eTax_shock_steps_temp.gdx';
execute_unload 'Output\%gdxnavn%_del1_2.gdx';


tX2035.l = %tX1%/3;
$import CO2eTax_shock_calc.gms

$SETGLOBAL indsaet del1_3
$import report_qEmm.gms
$import report_EV.gms
$import report_SKM_teknisk.gms
$import loop_MAC.gms
$import loop_CCS.gms
$import loop_pyrolyse.gms
$import loop_qEmm_dekomp.gms
#  execute_unload 'Output\CO2eTax_shock_steps_temp.gdx';
execute_unload 'Output\%gdxnavn%_del1_3.gdx';

$import report_all.gms;
CCS_tot[t] = sum(s, sumqEmmCCSubio.l[s,t]+sumqEmmCCSbio.l[s,t]);
execute_unload 'Output\%gdxnavn%_del1.gdx';



#  Del 2 85 pct. reduktion

tX2035.l = (%tX2%-%tX1%)/3;
$import CO2eTax_shock_calc.gms

$SETGLOBAL indsaet del2_1
$import report_qEmm.gms
$import report_EV.gms
$import report_SKM_teknisk.gms
$import loop_MAC.gms
$import loop_CCS.gms
$import loop_pyrolyse.gms
$import loop_qEmm_dekomp.gms
#  execute_unload 'Output\CO2eTax_shock_steps_temp.gdx';
execute_unload 'Output\%gdxnavn%_del2_1.gdx';

tX2035.l = (%tX2%-%tX1%)/3;
$import CO2eTax_shock_calc.gms

$SETGLOBAL indsaet del2_2
$import report_qEmm.gms
$import report_EV.gms
$import report_SKM_teknisk.gms
$import loop_MAC.gms
$import loop_CCS.gms
$import loop_pyrolyse.gms
$import loop_qEmm_dekomp.gms
#  execute_unload 'Output\CO2eTax_shock_steps_temp.gdx';
execute_unload 'Output\%gdxnavn%_del2_2.gdx';

tX2035.l = (%tX2%-%tX1%)/3;
$import CO2eTax_shock_calc.gms

$SETGLOBAL indsaet del2_3
$import report_qEmm.gms
$import report_EV.gms
$import report_SKM_teknisk.gms
$import loop_MAC.gms
$import loop_CCS.gms
$import loop_pyrolyse.gms
$import loop_qEmm_dekomp.gms
#  execute_unload 'Output\CO2eTax_shock_steps_temp.gdx';
execute_unload 'Output\%gdxnavn%_del2_3.gdx';

$import report_all.gms;
CCS_tot[t] = sum(s, sumqEmmCCSubio.l[s,t]+sumqEmmCCSbio.l[s,t]);
execute_unload 'Output\%gdxnavn%_del2.gdx';



#  Del 3 90 pct. reduktion

tX2035.l = (%tX3%-%tX2%)/3;
$import CO2eTax_shock_calc.gms

$SETGLOBAL indsaet del3_1
$import report_qEmm.gms
$import report_EV.gms
$import report_SKM_teknisk.gms
$import loop_MAC.gms
$import loop_CCS.gms
$import loop_qEmm_dekomp.gms
execute_unload 'Output\CO2eTax_shock_steps_temp.gdx';


tX2035.l = (%tX3%-%tX2%)/3;
$import CO2eTax_shock_calc.gms

$SETGLOBAL indsaet del3_2
$import report_qEmm.gms
$import report_EV.gms
$import report_SKM_teknisk.gms
$import loop_MAC.gms
$import loop_CCS.gms
$import loop_qEmm_dekomp.gms
execute_unload 'Output\CO2eTax_shock_steps_temp.gdx';


tX2035.l = (%tX3%-%tX2%)/3;
$import CO2eTax_shock_calc.gms

$SETGLOBAL indsaet del3_3
$import report_qEmm.gms
$import report_EV.gms
$import report_SKM_teknisk.gms
$import loop_MAC.gms
$import loop_CCS.gms
$import loop_qEmm_dekomp.gms
execute_unload 'Output\CO2eTax_shock_steps_temp.gdx';


$import report_all.gms;
CCS_tot[t] = sum(s, sumqEmmCCSubio.l[s,t]+sumqEmmCCSbio.l[s,t]);
execute_unload 'Output\%gdxnavn%_del3.gdx';





tX2035.l = 100;
$import CO2eTax_shock_calc.gms

$SETGLOBAL indsaet del4_100
$import report_qEmm.gms
$import report_EV.gms
$import report_SKM_teknisk.gms
$import loop_MAC.gms
$import loop_CCS.gms
$import loop_qEmm_dekomp.gms
execute_unload 'Output\%gdxnavn%_del4.gdx';

execute_unload 'Output\CO2eTax_shock_FM.gdx';
@check_vBoP();

