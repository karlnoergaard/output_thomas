## -------------------------------------------------------------------------------------
## Pre-model to determine tax path
## -------------------------------------------------------------------------------------

	$FIX G_CO2eTaxExo;
	$UNFIX G_CO2eTaxEndo;
	@SOLVE(M_CO2eTaxPre);

	tXtot[t] = tXtot[t] + tX.l[t]/inf_factor['2022'];

	tCO2_REmargPre[purpose,energy19,r,t,emm_eq] = tCO2_REmarg.l[purpose,energy19,r,t,emm_eq];

## -------------------------------------------------------------------------------------
## Setting tax increase
## -------------------------------------------------------------------------------------


#  Skattesatserne sættes ud fra tX
	$IF %industri%:
	## AFGIFT PÅ ENERGIRELATEREDE UDLEDNINGER
	tCO2_REmarg.l[purpose,energy19,r,t,emm_eq]$(tCO2_REmarg.l[purpose,energy19,r,t,emm_eq]) = tCO2_REmarg.l[purpose,energy19,r,t,emm_eq] + tX.l[t];
	# Der lægges ikke afgiftsstigninger på district heat i rumvarme
	tCO2_REmarg.l['heating','District heat',r,t,emm_eq] = tCO2_REmargPre['heating','District heat',r,t,emm_eq];
	# Der lægges ikke afgiftsstigninger på transportudledninger fra industrien
	tCO2_REmarg.l[purpose,energy19,s,t,emm_eq]$((sameas[purpose,'transport'] or sameas[purpose,'intern_trans']) and not (agri_sectors_s[s] or sameas[s,'02000'] or sameas[s,'03000'])) = tCO2_REmargPre[purpose,energy19,s,t,emm_eq]; 	
	# Der lægges ikke afgiftsstigninger på cementindustrien
	tCO2_REmarg.l[purpose,energy19,'23001',t,emm_eq] = tCO2_REmargPre[purpose,energy19,'23001',t,emm_eq]; 
	# Der lægges ikke afgiftsstigninger på nordsøen
	tCO2_REmarg.l[purpose,energy19,'0600a',t,emm_eq] = tCO2_REmargPre[purpose,energy19,'0600a',t,emm_eq]; 
	# Der lægges ikke afgiftsstigninger på afgiftsgrundlaget rumvarme
	tCO2_REmarg.l[purpose,energy19,s,t,emm_eq]$(mapGrREFORM2GSR[purpose,energy19,s,'Rumvarme',t]) = tCO2_REmargPre[purpose,energy19,s,t,emm_eq]; 
	# Der lægges ikke afgiftsstigninger på affaldsforbrænding
	tCO2_REmarg.l[purpose,energy19,'38393',t,emm_eq] = tCO2_REmargPre[purpose,energy19,'38393',t,emm_eq]; 
	## AFGIFT PÅ IKKE-ENERGIRELATEREDE UDLEDNINGER
	tCO2_ProdxE.l[s,t,'CO2ubio'] $(tCO2_ProdxE.l[s,t,'CO2ubio']) = tCO2_ProdxE.l[s,t,'CO2ubio'] + tX.l[t];
	# Der lægges ikke afgiftsstigninger på cementindustrien	
	tCO2_ProdxE.l['23001',t,'CO2ubio'] $(tCO2_ProdxE.l['23001',t,'CO2ubio']) = tCO2_ProdxEPre['23001',t,'CO2ubio']; 
	$ENDIF
	$IF %cement%:
	tCO2_REmarg.l[purpose,energy19,'23001',t,emm_eq]$(tCO2_REmarg.l[purpose,energy19,'23001',t,emm_eq]) = tCO2_REmarg.l[purpose,energy19,'23001',t,emm_eq] + tX.l[t]; # Der lægges igen afgiftsstigninger på cementindustrien	
	tCO2_ProdxE.l['23001',t,'CO2ubio']$(tCO2_ProdxE.l['23001',t,'CO2ubio']) = tCO2_ProdxE.l['23001',t,'CO2ubio'] + tX.l[t]; # Der lægges igen afgiftsstigninger på cementindustrien	
	$ENDIF
	$IF %nordsoen%:
	tCO2_REmarg.l[purpose,energy19,'0600a',t,emm_eq]$(tCO2_REmarg.l[purpose,energy19,'0600a',t,emm_eq]) = tCO2_REmarg.l[purpose,energy19,'0600a',t,emm_eq] + tX.l[t]; # Der lægges igen afgiftsstigninger på nordsøen
	$ENDIF
	$IF %rumvarme%:
	tCO2_REmarg.l[purpose,energy19,s,t,emm_eq]$(mapGrREFORM2GSR[purpose,energy19,s,'Rumvarme',t] and tCO2_REmarg.l[purpose,energy19,s,t,emm_eq]) = tCO2_REmarg.l[purpose,energy19,s,t,emm_eq] + tX.l[t]; # Der lægges igen afgiftsstigninger på afgiftsgrundlaget rumvarme
	tCO2_REmarg.l['heating','District heat',r,t,emm_eq] = tCO2_REmargPre['heating','District heat',r,t,emm_eq];
	$ENDIF
	$IF %affald%:
	tCO2_REmarg.l[purpose,energy19,'38393',t,emm_eq]$(tCO2_REmarg.l[purpose,energy19,'38393',t,emm_eq]) = tCO2_REmarg.l[purpose,energy19,'38393',t,emm_eq] + tX.l[t]; # Der lægges igen afgiftsstigninger på affaldsforbrænding
	$ENDIF
	$IF %landbrug_dy%:
	tCO2_emm_ani.l[Emmtype,ani_sectors,animals,t]$(tCO2_emm_ani.l[Emmtype,ani_sectors,animals,t]) = tCO2_emm_ani.l[Emmtype,ani_sectors,animals,t] + tX.l[t];
	$ENDIF
	$IF %landbrug_plante%:
	tCO2_emm_plant.l[plant_sectors,plant_,t]$(tCO2_emm_plant.l[plant_sectors,plant_,t]) = tCO2_emm_plant.l[plant_sectors,plant_,t] + tX.l[t];
	$ENDIF

## -------------------------------------------------------------------------------------
## Structural effects based on the SKM method
## -------------------------------------------------------------------------------------

	$IF %Stru%:
	# Struktureffekter p� SKM-metoden
	$import ..\struktur_SKM.gms
	$ENDIF

## -------------------------------------------------------------------------------------
## Biochar
## -------------------------------------------------------------------------------------

	$IF %Pyrolyse%:
	# Pyrolyse
	tSubsidy_Pyrolyse.l[PyrolyseTech,t] = tSubsidy_Pyrolyse.l[PyrolyseTech,t] + tX.l[t];
	$FIX G_Pyrolyse_exo;
	$FIX pI_s[i_,s,t]$(sameas[i_,'iM'] and sameas[s,'01011']);
	$UNFIX G_Pyrolyse_endo;
	@SOLVE(M_pyrolyse_partial);
	$ENDIF

## -------------------------------------------------------------------------------------
## Defining which abatement technologies are endogenous
## -------------------------------------------------------------------------------------

	d1switchID 	= 0;
	d1switchCCS = 0;
	
	#  CCS indtr�ngningen f�lger afgiftsstigningen og de perfekte subsidier genberegnes ift. reduceret st�ttebehov
	$IF1 (%CCS% or %CCS_sub% or %CCS_sub_biogas% or %CCS_sub_biomasse% or %CCS_sub_affald%):
		d1switchCCS = 1;
		$IF2 %CCS_sub%:
			tSubsidy_CCS_maks.l[techCCS,s,purpose,t,emm]$(tx0[t] and sum(energy19, d1thetaCCS[techCCS,purpose,energy19,s,t,emm]) and not (sameas[s,'35002'] or sameas[s,'35011'] or sameas[s,'38393'])) 
				= tSubsidy_CCS_maks.l[techCCS,s,purpose,t,emm] + tX.l[t];
			tSubsidy_CCSxE_maks.l[techCCS,s,t,emm]$(tx0[t] and d1thetaCCSxE[techCCS,s,t,emm] and not (sameas[s,'35002'] or sameas[s,'35011'])) 
				= tSubsidy_CCSxE_maks.l[techCCS,s,t,emm] + tX.l[t];
		$ENDIF2
		$IF2 %CCS_sub_biogas%:
			tSubsidy_CCS_maks.l[techCCS,s,purpose,t,emm]$(tx0[t] and sum(energy19, d1thetaCCS[techCCS,purpose,energy19,s,t,emm]) and sameas[s,'35002']) 
				= tSubsidy_CCS_maks.l[techCCS,s,purpose,t,emm] + tX.l[t];
			tSubsidy_CCSxE_maks.l[techCCS,s,t,emm]$(tx0[t] and d1thetaCCSxE[techCCS,s,t,emm] and sameas[s,'35002'] or sameas[s,'38393']) 
				= tSubsidy_CCSxE_maks.l[techCCS,s,t,emm] + tX.l[t];
		$ENDIF2
		$IF2 %CCS_sub_biomasse%:
			tSubsidy_CCS_maks.l[techCCS,s,purpose,t,emm]$(tx0[t] and sum(energy19, d1thetaCCS[techCCS,purpose,energy19,s,t,emm]) and sameas[s,'35011']) 
				= tSubsidy_CCS_maks.l[techCCS,s,purpose,t,emm] + tX.l[t];
			tSubsidy_CCSxE_maks.l[techCCS,s,t,emm]$(tx0[t] and d1thetaCCSxE[techCCS,s,t,emm] and sameas[s,'35011']) 
				= tSubsidy_CCSxE_maks.l[techCCS,s,t,emm] + tX.l[t];
		$ENDIF2
		$IF2 %CCS_sub_affald%:
			tSubsidy_CCS_maks.l[techCCS,s,purpose,t,emm]$(tx0[t] and sum(energy19, d1thetaCCS[techCCS,purpose,energy19,s,t,emm]) and sameas[s,'38393']) 
				= tSubsidy_CCS_maks.l[techCCS,s,purpose,t,emm] + tX.l[t];
			tSubsidy_CCSxE_maks.l[techCCS,s,t,emm]$(tx0[t] and d1thetaCCSxE[techCCS,s,t,emm] and sameas[s,'38393']) 
				= tSubsidy_CCSxE_maks.l[techCCS,s,t,emm] + tX.l[t];
		$ENDIF2
	$ENDIF1

	#  ID indtr�ngningen sl�es til
	$IF1 (%ID%):
		d1switchID = 1;
	$ENDIF1

	# Formodellen k�res, hvis der teknologi er sl�et til
	$IF1 (%ID% or %CCS% or %CCS_sub% or %CCS_sub_biogas% or %CCS_sub_biomasse% or %CCS_sub_affald%):

		$FIX G_abatement_partial_exo;
		$UNFIX G_abatement_partial_endo;
		@SOLVE(M_abatement_partial);

		# Midlertidig eksogenisering af ID-indtr�ngningen
		d1switchID 	= 0;

	$ENDIF1

## -------------------------------------------------------------------------------------
## Technical effects based on SKM
## -------------------------------------------------------------------------------------

	$IF %SKM_teknisk%:
	tCO2_SKM.l[purpose,energy19,s,t,emm]$(tx0[t] and d1TekniskSKM[purpose,energy19,s,t,emm]) = tCO2_SKM.l[purpose,energy19,s,t,emm]$(tx0[t] and d1TekniskSKM[purpose,energy19,s,t,emm]) + tX.l[t];
	tCO2xE_SKM.l[s,t,emm]$(tx0[t] and d1TekniskSKMxE[s,t,emm]) = tCO2xE_SKM.l[s,t,emm] + tX.l[t];
	$ENDIF


## -------------------------------------------------------------------------------------
## Solving the final model
## -------------------------------------------------------------------------------------

	$FIX G_endolandlinks_exo;
	$UNFIX G_endolandlinks_endo;
	@SOLVE(M_endolandlinks);

	$FIX G_exo;
	$UNFIX G_endo;
	@SOLVE(M_CO2eTax);
