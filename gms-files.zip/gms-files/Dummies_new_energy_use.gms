
# ------------------------------------------------------------------------------------------------------------------
# Check that there are energy prices and emissions factors for new energy use
# ------------------------------------------------------------------------------------------------------------------

Parameters 
    d1EmmProdE_ABnew[s,t,emm_eq,purpose,energy19]
    d1pRE_base_ABnew[purpose,energy19,s,t]
    # d1pRE_base_marg_ABnew[purpose,t]
    # d1pRE_base_marg[energy19,t]
;
$onMultiR
# $gdxin "..\..\..\Model_CGE\Model\Output\dynamic_calibration_KF.gdx"
#  $gdxin "Data\dynamic_calibration_KF_Bio.gdx"
# $load tx0 nonpricedenergy 
# $load d1EmmProdE d1qREgj d1pREgj d1vREgj d1pRE_base d1pRE_base_marg d1pREown d1EAFG_RE d1SO2_RE d1NOx_RE d1CO2_ETS d1CO2_ETS2 d1CO2_RE d1CO2_REmarg d1CO2_REmarg_sumemm d1DAV_RE d1CAV_RE d1tCO2_ETS_marg d1tRE, d1pRE_base_ABnew,d1pRE_base_marg_ABnew
# $load uEmmHardCoded tREbase_SKM_2_ENS tREbase_SKM tNOx_REomregner growth_factor
# $load uEmmProdE qEmmProdE uEOPProdE pREgj qREgj sBioNatgas sBioNatgasAvgAdj tEAFG_REmarg tEAFG_REmarg_SKM tCO2_REmarg 
# $load tCO2_REmarg_SKM tNOx_RE vtEAFG_RE qEAFG_REgj_ded jtEAFG_RE vtSO2_RE vtNOx_RE vtPSO_RE vtCO2_REmarg vEAV_RE vDAV_RE vCAV_RE adj_pRE_base_marg pRE_base_marg pREown
# $load tvREmarg pEtot pY0_CET pY_CET tVAT_RE tSO2_RE tPSO_RE tCO2_REmarg_GJ pEAV_RE pDAV_RE pCAV_RE tCALIBENS tCO2_ETS_GJ tCO2_ETS2_GJ
# $offMulti


    # ------------------------------------------------------------------------------------------------------------------
    # Check that there are energy prices and emissions factors for new energy use
    # ------------------------------------------------------------------------------------------------------------------
    PARAMETERS
        d1EmmProdE_ABnew[s,t,emm_eq,purpose,energy19]
    ;

    option clear = d1pRE_base_ABnew;
    # option clear = d1pRE_base_marg_ABnew;
    option clear = d1pREgj_ABnew;
    option clear = d1qREgj_ABnew;

    # tSO2_RE.l[purpose,energy19,r,t]$(not d1qREgj[purpose,energy19,r,t]) = 0; #Should be update in calibrate2ENS
    # tEAFG_REmarg.l[purpose,energy19,r,t]$(not d1qREgj[purpose,energy19,r,t]) = 0;
    # tCO2_REmarg.l[purpose,energy19,r,t,emm_eq]$(not d1qREgj[purpose,energy19,r,t]) = 0;
    # tNOX_RE.l[purpose,energy19,r,t]$(not d1qREgj[purpose,energy19,r,t]) = 0; 
    # fpEAV_RE.l[purpose,energy19,r,t]$(not d1qREgj[purpose,energy19,r,t]) = 0;
    # fpDAV_RE.l[purpose,energy19,r,t]$(not d1qREgj[purpose,energy19,r,t]) = 0;
    # fpCAV_RE.l[purpose,energy19,r,t]$(not d1qREgj[purpose,energy19,r,t]) = 0;
    # pEAV_RE.l[purpose,energy19,r,t]$(not d1qREgj[purpose,energy19,r,t]) = 0;
    # pDAV_RE.l[purpose,energy19,r,t]$(not d1qREgj[purpose,energy19,r,t]) = 0;
    # pCAV_RE.l[purpose,energy19,r,t]$(not d1qREgj[purpose,energy19,r,t]) = 0;
    # vEAV_RE.l[purpose,energy19,r,t]$(not d1qREgj[purpose,energy19,r,t]) = 0;
    # vDAV_RE.l[purpose,energy19,r,t]$(not d1qREgj[purpose,energy19,r,t]) = 0;
    # vCAV_RE.l[purpose,energy19,r,t]$(not d1qREgj[purpose,energy19,r,t]) = 0;
    # vtSO2_RE.l[purpose,energy19,r,t]$(not d1qREgj[purpose,energy19,r,t]) = 0;
    # Energy use

    #  d1qREgj_ABnew[purpose,energy19,s,t]$(sum((l,p_tau,e_tau), d1_uTE[l,purpose,p_tau,e_tau,energy19,s,t])
    #                                       and not d1qREgj[purpose,energy19,s,t]) = yes;


    d1qREgj_ABnew[purpose,energy19,s,t]$(d1_ab_energy19[s,purpose,energy19,t]
                                         and not d1qREgj[purpose,energy19,s,t]) = yes;


    d1qREgj[purpose,energy19,s,t]$(d1qREgj_ABnew[purpose,energy19,s,t]) = yes;

    # Emissions
    d1EmmProdE_ABnew[s,t,'CO2ubio',purpose,energy19]$(d1qREgj_ABnew[purpose,energy19,s,t]
                                                    and uEmmHardCoded['CO2ubio',energy19] 
                                                    and not d1EmmProdE[s,t,'CO2ubio',purpose,energy19]) = yes;

    d1EmmProdE_ABnew[s,t,'CO2bio',purpose,energy19]$(d1qREgj_ABnew[purpose,energy19,s,t]
                                                    and uEmmHardCoded['CO2bio',energy19] 
                                                    and not d1EmmProdE[s,t,'CO2bio',purpose,energy19]) = yes;

    d1EmmProdE_ABnew[s,t,'CO2e',purpose,energy19]$(d1EmmProdE_ABnew[s,t,'CO2ubio',purpose,energy19]) = yes;

    d1EmmProdE[s,t,emm_eq,purpose,energy19]$(d1EmmProdE_ABnew[s,t,emm_eq,purpose,energy19]) = yes; 

    # Update emission factors
    uEmmProdE.fx[s,t,'CO2ubio',energy19]$(sum(purpose, d1EmmProdE_ABnew[s,t,'CO2ubio',purpose,energy19]) and not uEmmProdE.l[s,t,'CO2ubio',energy19]) = uEmmHardCoded['CO2ubio',energy19]; 
    uEmmProdE.fx[s,t,'CO2bio',energy19]$(sum(purpose, d1EmmProdE_ABnew[s,t,'CO2bio',purpose,energy19]) and not uEmmProdE.l[s,t,'CO2bio',energy19])   = uEmmHardCoded['CO2bio',energy19]; 

    # Update CCS-factors
    uEOPProdE.fx[purpose,energy19,s,t,emm]$(d1EmmProdE_ABnew[s,t,emm,purpose,energy19] and not uEOPProdE.l[purpose,energy19,s,t,emm]) = 1; 

    # Energy prices
    d1pRE_base_ABnew[purpose,energy19,s,t]$(d1qREgj_ABnew[purpose,energy19,s,t]
                                            and not nonpricedenergy[energy19]) = yes;

    # d1pRE_base_marg_ABnew[energy19,t]$(sum((purpose,s), d1pRE_base_ABnew[purpose,energy19,s,t])) = yes;

    d1pRE_base[purpose,energy19,s,t]$(d1pRE_base_ABnew[purpose,energy19,s,t]) = yes;
    # d1pRE_base_marg[energy19,t]$(d1pRE_base_marg_ABnew[energy19,t]) = yes;

    #Opdaterer bionaturgasandele (£AKB: Mangler bionaturgas dummy)
    sBioNatgas.l[purpose,r,t]$(d1qREgj_ABnew[purpose,'natural gas incl. biongas',r,t]) = sBioNatgasAvgAdj.l[t];


    #### Update tax rates and dummies

    #  Marginal SO2-tax
    # tSO2_REmarg.l[purpose,energy19,r,t]$(d1qREgj_ABnew[purpose,energy19,r,t] and energy19_SKM[energy19]) 
    #     = sum(tREbase_SKM$(maptREbase_SKM2qRE(tREbase_SKM,r,purpose,energy19)), tSO2_REmarg_SKM.l(tREbase_SKM,t)); #Exogenous marginal tax

    #  Marginal energy tax
    tEAFG_REmarg.l[purpose,energy19,s,t]$(d1qREgj_ABnew[purpose,energy19,s,t]) 
    	= sum((categoryENS,GSR_ag,tREbase_SKM)$(sENS2GR(categoryENS, GSR_ag, purpose, energy19, s) 
    											and tREbase_SKM_2_ENS(tREbase_SKM,categoryENS,GSR_ag,energy19) 
    											and d1qREgj[purpose,energy19,s,t] 
    											and not sameas[energy19,'Jet petroleum']), tEAFG_REmarg_SKM.l[tREbase_SKM,t]);

    tEAFG_REmarg.l[purpose_xt,'electricity','64000',t]$(d1qREgj_ABnew[purpose_xt,'electricity','64000',t]) = tEAFG_REmarg_SKM.l['el_ikke-proces',t]; #Finansiel sektor (strengt taget momsfritagne/lønsumsomfattede vsh) betaler fuld elafgift, jf. mail fra Sebastian Lind SKM d. 22.5.2024. Kh AKB
    	  	
    #Test af indlæste energiafgifter 
    LOOP((purpose,energy19,s),
      tjek = tEAFG_REmarg.l[purpose,energy19,s,'2025'];
      ABORT$(tjek > smax(tREbase_SKM,tEAFG_REmarg_SKM.l(tREbase_SKM,'2025'))) tjek, "De indlæste energiafgifter må ikke overstige max i input fra data - hvis det gør er der fejl i mappingen tREbase_SKM_2_ENS";
     );

    #  Marginal CO2 tax
    tCO2_REmarg.l[purpose,energy19,s,t,'CO2ubio']$(d1qREgj_ABnew[purpose,energy19,s,t]) = sum((categoryENS,GSR_ag,tREbase_SKM)$(sENS2GR(categoryENS, GSR_ag, purpose, energy19, s) and tREbase_SKM_2_ENS(tREbase_SKM,categoryENS,GSR_ag,energy19) and qEmmProdE.l[s,t,'CO2ubio',purpose,energy19]), tCO2_REmarg_SKM.l[tREbase_SKM,t]);
    tCO2_REmarg.l[purpose,'Natural gas incl. biongas',s,t,'CO2bio']$(d1qREgj_ABnew[purpose,'Natural gas incl. biongas',s,t]) = sum((categoryENS,GSR_ag,tREbase_SKM)$(sENS2GR(categoryENS, GSR_ag, purpose, 'Natural gas incl. biongas', s) and tREbase_SKM_2_ENS(tREbase_SKM,categoryENS,GSR_ag,'Natural gas incl. biongas') and qEmmProdE.l[s,t,'CO2bio',purpose,'natural gas incl. biongas'] and qEmmProdE.l[s,t,'CO2ubio',purpose,'natural gas incl. biongas']), tCO2_REmarg_SKM.l[tREbase_SKM,t]);

    #Test af indlæste afgifter (vi laver stikprøve i 2025 - egentlig burde man nok køre over alle år)
      LOOP((purpose,energy19,s),
      #Tjek for CO2ubio
      tjek = tCO2_REmarg.l[purpose,energy19,s,'2025','CO2ubio'];
      ABORT$(tjek > smax(tREbase_SKM,tCO2_REmarg_SKM.l(tREbase_SKM,'2025'))) tjek, "De indlæste CO2-afgifter må ikke overstige max i input fra data - hvis det gør er der fejl i mappingen tREbase_SKM_2_ENS";
      #Tjek for CO2bio
      tjek = tCO2_REmarg.l[purpose,energy19,s,'2025','CO2bio'];
      ABORT$(tjek > smax(tREbase_SKM,tCO2_REmarg_SKM.l(tREbase_SKM,'2025'))) tjek, "De indlæste CO2-afgifter må ikke overstige max i input fra data - hvis det gør er der fejl i mappingen tREbase_SKM_2_ENS";
      );

    #NOx-afgift på ny energi
    tNOx_RE.l[purpose,energy19,r,t]$(d1qREgj_ABnew[purpose,energy19,r,t] and tNOx_REomregner[energy19] and not (sameas[r,'35001'] or sameas[r,'38393'])) #Vi antager at forbrændingsanlæggene har så meget røgteknologi at de slipper for NOx-afgift (grov antagelse, kh Asbjørn)
    	= 1/tNOx_REomregner[energy19];


    #Ad hoc løsning
    tVAT_RE.l[purpose,energy19,'64000',t]$(d1qREgj_ABnew[purpose,energy19,'64000',t]) = 0.25;
    tVAT_RE.l[purpose,energy19,'off',t]$(d1qREgj_ABnew[purpose,energy19,'off',t]) = 0.25;

    # 		#   $FUNCTION compute_initial_taxvalues():

    vtNOx_RE.l[purpose,energy19,r,t]$(d1qREgj_ABnew[purpose,energy19,r,t])  = tNOx_RE.l[purpose,energy19,r,t] * qREgj.l[purpose,energy19,r,t];


    #£AKB: Går det her godt?
    vtCO2_REmarg.l[purpose,energy19,r,t]$(d1qREgj_ABnew[purpose,energy19,r,t])                                       =  tCO2_REmarg.l[purpose,energy19,r,t,'CO2ubio'] * qEmmProdE.l[r,t,'CO2ubio',purpose,energy19]*growth_factor[t]/10**6;
    vtCO2_REmarg.l[purpose,'natural gas incl. biongas',r,t]$(d1qREgj_ABnew[purpose,'natural gas incl. biongas',r,t]) =  tCO2_REmarg.l[purpose,'natural gas incl. biongas',r,t,'CO2bio']  * qEmmProdE.l[r,t,'CO2bio',purpose,'natural gas incl. biongas']*growth_factor[t]/10**6;

    # TAXES 
    d1EAFG_RE[purpose,energy19,r,t]$(tEAFG_REmarg.l[purpose,energy19,r,t] and d1qREgj_ABnew[purpose,energy19,r,t]) = yes;
    d1SO2_RE[purpose,energy19,r,t] = yes$(vtSO2_RE.l[purpose,energy19,r,t] and d1qREgj[purpose,energy19,r,t]);
    # d1NOx_RE[purpose,energy19,r,t] = yes$(vtNOx_RE.l[purpose,energy19,r,t] and d1qREgj[purpose,energy19,r,t]);
    d1NOx_RE[purpose,energy19,r,t]$(tNOx_RE.l[purpose,energy19,r,t] and d1qREgj_ABnew[purpose,energy19,r,t]) = yes;


    # CO2
    d1CO2_RE[purpose,energy19,r,tForecast]            = yes$(sum(emm_eq, tCO2_REmarg.l[purpose,energy19,r,tForecast,emm_eq]) and d1qREgj[purpose,energy19,r,tForecast]); #I data favner vi begge muligheder
    d1CO2_REmarg[purpose,energy19,r,tForecast,emm_eq] = yes$(tCO2_REmarg.l[purpose,energy19,r,tForecast,emm_eq]);
    d1CO2_REmarg_sumemm[purpose,energy19,r,tForecast] = yes$(sum(emm_eq, d1CO2_REmarg[purpose,energy19,r,tForecast,emm_eq]));

    # RETAIL AND WHOLESALE ENERG MARGINS 
    #Vi lægger hele leveringsomkostningen på engrossalgssiden 
    pEAV_RE.l[purpose,energy19,r,t]$(d1qREgj_ABnew[purpose,energy19,r,t]) = KF25_CostDel_RE[energy19,r,t];
    fpEAV_RE.l[purpose,energy19,r,t]$(d1qREgj_ABnew[purpose,energy19,r,t]) = pEAV_RE.l[purpose,energy19,r,t]/pY_CET.l['WholeAndRetailSaleMarginE','46000',t] -1;
    fpEAV_RE.l[purpose,energy19,r,t]$(d1qREgj_ABnew[purpose,energy19,r,t] and t.val>tBF_calib_end.val) = fpEAV_RE.l[purpose,energy19,r,tBF_calib_End];
    d1EAV_RE[purpose,energy19,r,t]$(d1qREgj_ABnew[purpose,energy19,r,t] and fpEAV_RE.l[purpose,energy19,r,t]) = yes;

    # Update dummy on ETS quotas 
    d1tCO2_ETS_marg[purpose,energy19,r,t]$(d1qREgj_ABnew[purpose,energy19,r,t] and (d1EmmProdE[r,t,'CO2ubio',purpose,energy19] or (d1EmmProdE[r,t,'CO2bio',purpose,energy19] and sameas[energy19,'Natural gas incl. biongas'])) and d1CO2_ETS[r,t] and sameas[purpose,'in_ETS']) = yes;


    d1CO2_ETS2_marg[purpose,energy19,r,t]$(tCO2_ETS2.l[t] and not sLan[r] 
                                                    and d1qREgj_ABnew[purpose,energy19,r,t]
                                                    and not sameas[purpose,'in_ETS'] 
                                                    and (d1EmmProdE[r,t,'CO2ubio',purpose,energy19] or (d1EmmProdE[r,t,'CO2bio',purpose,energy19] and sameas[energy19,'Natural gas incl. biongas']))
                                                    and not sameas[energy19,'District heat']) = yes;
    d1CO2_ETS2[r,t]                         = yes$(sum((purpose,energy19),d1CO2_ETS2_marg[purpose,energy19,r,t]));


    #This needs to be updated after update of emissions 
    parameter d1tRE_new_aba[purpose,energy19,r,t];
    d1tRE_new_aba[purpose,energy19,r,t] = d1tRE[purpose,energy19,r,t];
    d1tRE[purpose,energy19,r,t]$(d1qREgj_ABnew[purpose,energy19,r,t] and (d1EAFG_RE[purpose,energy19,r,t] 
                                                                                          or d1SO2_RE[purpose,energy19,r,t] 
                                                                                          or d1PSO_RE[purpose,energy19,r,t] 
                                                                                          or d1NOx_RE[purpose,energy19,r,t] 
                                                                                          or d1CO2_RE[purpose,energy19,r,t] 
                                                                                          or d1VAT_RE[purpose,energy19,r,t] 
                                                                                          or d1tCO2_ETS_marg[purpose,energy19,r,t]
                                                                                          or d1CO2_ETS2_marg[purpose,energy19,r,t])) = yes;

    d1tRE_new_aba[purpose,energy19,r,t] = yes$(d1tRE[purpose,energy19,r,t] and not d1tRE_new_aba[purpose,energy19,r,t]);

    #We add elements to d1tRE to add calibENS to prices where there currently are no taxes on energy goods (i.e. cases where d1pRE_base is on, but d1tRE is not. Consider an alternative method of adding vtCalibENS to marginal prices directly)
    d1tRE[purpose,energy19,r,t]$(t.val > 2019 and t.val<%endhere% and thesesecon[r] and d1pREgj[purpose,energy19,r,t] and not eNotInEnergyNest[purpose,energy19,r,t] and theseLinearly[purpose,energy19,r,t]) = yes;


    d1pREgj_ABnew[purpose,energy19,r,t] = yes$(d1pREgj[purpose,energy19,r,t]);

    option clear = d1pREgj;
    d1pREgj[purpose,energy19,r,t]$(d1pRE_base[purpose,energy19,r,t] or d1tRE[purpose,energy19,r,t] or d1pREown[purpose,energy19,r,t]) = yes;
    d1pREgj_ABnew[purpose,energy19,r,t] = yes$(d1pREgj[purpose,energy19,r,t] and not sum(energy19a, d1vREE_transport[purpose,energy19a,energy19,r,t]) and not d1pREgj_ABnew[purpose,energy19,r,t]);

    d1vREgj[purpose,energy19,r,t]   = yes$(d1pREgj[purpose,energy19,r,t] and d1qREgj[purpose,energy19,r,t]);

execute_unload 'Output\dummy_update.gdx';

$import energy_price_partial.gms

