# ======================================================================================================================
# CONSTRUCTION OF MAC-CURVES
# ======================================================================================================================
# OBS: REMEMBER TO UPDATE EQUATIONS: The below calculations is based on equations from the modules Abatement.gms and emissions.gms but have the extra dimension techID 
# ======================================================================================================================

# ======================================================================================================================
# MECHANIC CHANGES FROM TECHNOLOGIES
# ======================================================================================================================
    # ------------------------------------------------------------------------------------------------------------------
    # Mechanic price change on energy activity
    # ------------------------------------------------------------------------------------------------------------------
    PARAMETERS
        uREE_Mech[techID,purpose,energy19a,energy19,s,t]        'Mechanic scale parameter for qREE with techID dimension'
        pREa_Mech[techID,purpose,energy19a,s,t]                 'Mechanic price of energy activity with techID dimension'
        pREa_MechCh[techID,purpose,energy19a,s,t]               'Mechanic price change of energy activity with techID dimension'
        vREa_MechCh[techID,purpose,energy19a,s,t]               'Mechanic change in value of energy activity with techID dimension'
    ;

    # Technology adoption is set to 1
    rID_actual.l[techID,purpose,energy19a,s,t]$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t]) = 1;

    # Endogenous Leontief shares (Corresponds to equation E_uREE in Abatement.gms, where techID dimension is not summed over)
    uREE_Mech[techID,purpose,energy19a,energy19,s,t]$(tx0[t] and d1thetaID[techID,purpose,energy19a,energy19,s,t]) 
                                                    = uREExID.l[purpose,energy19a,energy19,s,t] + rID_actual.l[techID,purpose,energy19a,s,t]*thetaID.l[techID,purpose,energy19a,energy19,s,t];

    # Average capital unit cost (Corresponds to equation E_thetaID_KMean in Abatement.gms)
    thetaID_KMean.l[techID,purpose,energy19a,s,t]$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t]) = thetaID_K.l[techID,purpose,energy19a,s,t];

    # Mechanic price of tehcnologies (Corresponds to equation E_j_pREa in Abatement.gms, where techID dimension is not summed over and without CCS)
    pREa_Mech[techID,purpose,energy19a,s,t]$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t]) = 
          #Energy costs:
          sum(energy19$(d1thetaID[techID,purpose,energy19a,energy19,s,t]), uREE_Mech[techID,purpose,energy19a,energy19,s,t]*pREgj.l[purpose,energy19,s,t])
          #Capital costs from ID:
          + rID_actual.l[techID,purpose,energy19a,s,t] * thetaID_KMean.l[techID,purpose,energy19a,s,t]
              * sum(energy19$(d1thetaID[techID,purpose,energy19a,energy19,s,t] and sameas(energy19,energy19a)),-thetaID.l[techID,purpose,energy19a,energy19,s,t]) 
              * pI_s.l['iM',s,t];

    # Mechanic change in price of tehcnologies (same equation as for pREa_Mech but with thetaID instead of uREE)
    pREa_MechCh[techID,purpose,energy19a,s,t]$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t]) =
          #Energy costs:
          sum(energy19$(d1thetaID[techID,purpose,energy19a,energy19,s,t]), thetaID.l[techID,purpose,energy19a,energy19,s,t]*pREgj.l[purpose,energy19,s,t])
          #Capital costs from ID:
          + rID_actual.l[techID,purpose,energy19a,s,t] * thetaID_KMean.l[techID,purpose,energy19a,s,t]
              * sum(energy19$(d1thetaID[techID,purpose,energy19a,energy19,s,t] and sameas(energy19,energy19a)),-thetaID.l[techID,purpose,energy19a,energy19,s,t]) 
              * pI_s.l['iM',s,t];

    vREa_MechCh[techID,purpose,energy19a,s,t]$(d1thetaID_k[techID,purpose,energy19a,s,t]) = pREa_MechCh[techID,purpose,energy19a,s,t] * qREa.l[purpose,energy19a,s,t]/growth_factor[t];


    # ------------------------------------------------------------------------------------------------------------------
    # Mechanic changes in energy use
    # ------------------------------------------------------------------------------------------------------------------
    PARAMETERS
        qREE_Mech[techID,purpose,energy19a,energy19,s,t]                'Mechanic energy use for each technology'
        qREgj_Mech[techID,purpose,energy19,s,t]                         'Mechanic energy demand for each technology'
        qREgj_MechCh[techID,purpose,energy19,s,t]                       'Mechanic change in energy demand for each technology'
        qREgj_tjek[GSR_ag,energy19,tMAC]                                'Check that thetaID gives the correct change in energy use'
        ;

    # Leontief demand (Corresponds to equation E_qREE in Abatement.gms, where techID dimension is not summed over)
    qREE_Mech[techID,purpose,energy19a,energy19,s,t]$(tx0[t] and d1thetaID[techID,purpose,energy19a,energy19,s,t]) 
                                                    = uREE_Mech[techID,purpose,energy19a,energy19,s,t] * qREa.l[purpose,energy19a,s,t];

    # Mechanic energy use (correspons to equation E_j_qREgj in Abatement.gms, where techID is not summed over)
    qREgj_Mech[techID,purpose,energy19,s,t]$(sum(energy19a, d1thetaID[techID,purpose,energy19a,energy19,s,t]))
                                                    = sum(energy19a$(d1qREE[purpose,energy19a,energy19,s,t]), qREE_Mech[techID,purpose,energy19a,energy19,s,t]);

    # Check that energy use doesn't become negative
    LOOP((purpose,energy19,s,t)$(tx0[t] and sum((techID,energy19a), d1thetaID[techID,purpose,energy19a,energy19,s,t])),
        tjek = sum(techID$(sum(energy19a, d1thetaID[techID,purpose,energy19a,energy19,s,t])), qREgj_Mech[techID,purpose,energy19,s,t]);
        ABORT$(tjek < 0) tjek, "Technology leads to negative energy use";
    );

    # Mechanic change in energy use (same equation as for qREgj_Mech but with thetaID instead of uREE to get change)
    qREgj_MechCh[techID,purpose,energy19,s,t]$(sum(energy19a, d1thetaID[techID,purpose,energy19a,energy19,s,t])) 
        = sum(energy19a$(d1qREE[purpose,energy19a,energy19,s,t]), thetaID.l[techID,purpose,energy19a,energy19,s,t]* qREa.l[purpose,energy19a,s,t]);

    # Check that thetaID gives the correct changes in energy use
    qREgj_tjek[GSR_ag,energy19,tMAC]$(sameas[tMAC,'2025'] or sameas[tMAC,'2030'] or sameas[tMAC,'2035']) 
        = sum((techID,energy19a), eInput_diff[techID,GSR_ag,energy19a,energy19,tMAC])
        - sum((techID,purpose,s)$(mapGrREFORM2GSR[purpose,energy19,s,GSR_ag,tMAC]), qREgj_MechCh[techID,purpose,energy19,s,tMAC]);


    # ------------------------------------------------------------------------------------------------------------------
    # Mechanic change in emissions
    # ------------------------------------------------------------------------------------------------------------------
    PARAMETERS
        qEmmProdE_MechCh_kt[techID,purpose,energy19,s,t,emm_eq]         'Mechanic change in emissions for technologies'
        qGrossEmmE_MechCh_kt[techID,purpose,energy19,s,t,emm]           'Mechanic change in total energy related emissions (excl. CCS)'
        qEmmProdE_MechCh_MAC[techID,purpose,energy19,s,t,MAC_emm]       'Mechanic change in emissions for technologies (MAC-dimensions)'
    ;

    # Change in emissions excluding natural gas (corresponds to equation E_qEmmProdE_exnatgas in emissions.gms but with the above calculated qREgj_MechCh instead of qREgj)            
    qEmmProdE_MechCh_kt[techID,purpose,energy19,s,t,emm]$(tx0[t] and sum(energy19a, d1thetaID[techID,purpose,energy19a,energy19,s,t]) and d1EmmProdE[s,t,emm,purpose,energy19] and not sameas[energy19,'Natural gas incl. biongas']) 
        = ((qREgj_MechCh[techID,purpose,energy19,s,t]/growth_factor[t]) * uEmmProdE.l[s,t,emm,energy19]*uEOPProdE.l[purpose,energy19,s,t,emm]);

    # Natural gas (incl. biongas) emissions 
    # Før 2023 (corresponds to equation E_qEmmProdE_natgas_before23 in emissions.gms but with the above calculated qREgj_MechCh instead of qREgj)
    qEmmProdE_MechCh_kt[techID,purpose,energy19,s,t,emm]$(tx0[t] and sum(energy19a, d1thetaID[techID,purpose,energy19a,energy19,s,t]) and d1EmmProdE[s,t,emm,purpose,energy19] and sameas[energy19,'Natural gas incl. biongas'] and t.val <= 2023) 
        = (qREgj_MechCh[techID,purpose,energy19,s,t]/growth_factor[t] * uEmmProdE.l[s,t,emm,energy19]*uEOPProdE.l[purpose,energy19,s,t,emm])$(not sameas[emm,'CO2ubio'] and not sameas[emm,'CO2bio'])
                                          +  ( sBioNatgas.l[purpose,s,t]   * qREgj_MechCh[techID,purpose,energy19,s,t]/growth_factor[t] * uEmmProdE.l[s,t,emm,energy19]*uEOPProdE.l[purpose,energy19,s,t,emm])$(sameas[emm,'CO2bio'])
                                          + ((1-sBioNatgas.l[purpose,s,t]) * qREgj_MechCh[techID,purpose,energy19,s,t]/growth_factor[t] * uEmmProdE.l[s,t,emm,energy19]*uEOPProdE.l[purpose,energy19,s,t,emm])$(sameas[emm,'CO2ubio']);

    # Efter 2023 (corresponds to equation E_qEmmProdE_natgas_after23 in emissions.gms but with the above calculated qREgj_MechCh instead of qREgj)
    qEmmProdE_MechCh_kt[techID,purpose,energy19,s,t,emm]$(tx0[t] and sum(energy19a, d1thetaID[techID,purpose,energy19a,energy19,s,t]) and d1EmmProdE[s,t,emm,purpose,energy19] and sameas[energy19,'Natural gas incl. biongas'] and t.val>2023) 
        = (qREgj_MechCh[techID,purpose,energy19,s,t]/growth_factor[t] * uEmmProdE.l[s,t,emm,energy19]*uEOPProdE.l[purpose,energy19,s,t,emm])$(not sameas[emm,'CO2ubio'] and not sameas[emm,'CO2bio'])
        + (qREgj_MechCh[techID,purpose,energy19,s,t]/growth_factor[t] * uEmmProdE.l[s,t,emm,energy19]*uEOPProdE.l[purpose,energy19,s,t,emm])$(sameas[emm,'CO2bio'] and d1sBioNatGas[purpose,s,t]) #If it's only bionatgas in the pipe
        + (qREgj_MechCh[techID,purpose,energy19,s,t]/growth_factor[t] * uEmmProdE.l[s,t,emm,energy19]*uEOPProdE.l[purpose,energy19,s,t,emm])$(sameas[emm,'CO2ubio'] and d1sBioNatGaszero[purpose,s,t]) #If it is only non-bionatgas in the pipe
        + (   sBioNatGasAvgAdj.l[t]  * qREgj_MechCh[techID,purpose,energy19,s,t]/growth_factor[t] * uEmmProdE.l[s,t,emm,energy19]*uEOPProdE.l[purpose,energy19,s,t,emm])$(sameas[emm,'CO2bio'] and not d1sBioNatGas[purpose,s,t])
        + ((1-sBioNatGasAvgAdj.l[t]) * qREgj_MechCh[techID,purpose,energy19,s,t]/growth_factor[t] * uEmmProdE.l[s,t,emm,energy19]*uEOPProdE.l[purpose,energy19,s,t,emm])$(sameas[emm,'CO2ubio'] and not d1sBioNatGaszero[purpose,s,t]);

    # Total energy related emissions (excl. CCS) (corresponds to equation E_qGrossEmmE in emissions.gms)
    qGrossEmmE_MechCh_kt[techID,purpose,energy19,s,t,emm]$(tx0[t] and sum(energy19a, d1thetaID[techID,purpose,energy19a,energy19,s,t]) and d1EmmProdE[s,t,emm,purpose,energy19] and (sameas[emm,'CO2ubio'] or sameas[emm,'CO2bio'])) 
        = qEmmProdE_MechCh_kt[techID,purpose,energy19,s,t,emm]/uEOPProdE.l[purpose,energy19,s,t,emm];

    # CCS on energy related CO2bio-emissions (corresponds to equation E_qEmmProdECCSbio in emissions.gms)
    qEmmProdE_MechCh_kt[techID,purpose,energy19,s,t,'CCSbio']$(tx0[t] and sum(energy19a, d1thetaID[techID,purpose,energy19a,energy19,s,t]) and d1CCSbio[purpose,energy19,s,t,'CCSbio'])
        = qEmmProdE_MechCh_kt[techID,purpose,energy19,s,t,'CO2bio'] - qGrossEmmE_MechCh_kt[techID,purpose,energy19,s,t,'CO2bio'];

    # CO2e (corresponds to equation E_qEmmProdE_CO2e in emissions.gms)
    qEmmProdE_MechCh_kt[techID,purpose,energy19,s,t,'CO2e']$(tx0[t] and sum(energy19a, d1thetaID[techID,purpose,energy19a,energy19,s,t]) and d1EmmProdE[s,t,'CO2e', purpose,energy19]) 
        = sum(emm$(d1EmmProdE[s,t,emm,purpose,energy19]), qEmmProdE_MechCh_kt[techID,purpose,energy19,s,t,emm]*GWP.l[emm])
        + qEmmProdE_MechCh_kt[techID,purpose,energy19,s,t,'CCSbio']$(d1CCSbio[purpose,energy19,s,t,'CCSbio']);


    # Mechanic change in emissions with dimensions used in MAC-curve
    qEmmProdE_MechCh_MAC[techID,purpose,energy19,s,t,'CO2e']$(tx0[t] and sum(energy19a, d1thetaID[techID,purpose,energy19a,energy19,s,t]) and d1EmmProdE[s,t,'CO2e', purpose,energy19])                     
                                                                    = qEmmProdE_MechCh_kt[techID,purpose,energy19,s,t,'CO2e'];
    qEmmProdE_MechCh_MAC[techID,purpose,energy19,s,t,'CO2ubio']$(tx0[t] and sum(energy19a, d1thetaID[techID,purpose,energy19a,energy19,s,t]) and d1EmmProdE[s,t,'CO2ubio', purpose,energy19])                  
                                                                    = qEmmProdE_MechCh_kt[techID,purpose,energy19,s,t,'CO2ubio'];
    qEmmProdE_MechCh_MAC[techID,purpose,energy19,s,t,'CO2ubio + NatGas_bio']$(tx0[t] and sum(energy19a, d1thetaID[techID,purpose,energy19a,energy19,s,t]) and (d1EmmProdE[s,t,'CO2ubio', purpose,energy19] or (d1EmmProdE[s,t,'CO2bio', purpose,energy19] and sameas[energy19,'Natural gas incl. biongas'])))     
                                                                    = qEmmProdE_MechCh_kt[techID,purpose,energy19,s,t,'CO2ubio'] 
                                                                    + qEmmProdE_MechCh_kt[techID,purpose,energy19,s,t,'CO2bio']$(sameas[energy19,'Natural gas incl. biongas']);

# ======================================================================================================================
# Construct MAC curves for each sector and purpose 
# ======================================================================================================================
    PARAMETERS
        qEmmProdE_MAC[s,t,MAC_emm,purpose,energy19a]                          'Baseline emissions with MAC dimensions'     
        MAC_curve_ID[techID,s,purpose,energy19a,t,MAC_emm,MAC_set]            'MAC curve for ID technologies'     
    ;
    # Baseline emissions with dimensions used in MAC-curve
    qEmmProdE_MAC[s,t,'CO2e',purpose,energy19a]$(d1EmmProdE[s,t,'CO2e',purpose,energy19a])      = qEmmProdE.l[s,t,'CO2e',purpose,energy19a];
    qEmmProdE_MAC[s,t,'CO2ubio',purpose,energy19a]$(d1EmmProdE[s,t,'CO2ubio',purpose,energy19a]) = qEmmProdE.l[s,t,'CO2ubio',purpose,energy19a];
    qEmmProdE_MAC[s,t,'CO2ubio + NatGas_bio',purpose,energy19a]$(d1EmmProdE[s,t,'CO2ubio',purpose,energy19a] or (d1EmmProdE[s,t,'CO2bio',purpose,energy19a] and sameas[energy19a,'Natural gas incl. biongas'])) 
                                                                                                = qEmmProdE.l[s,t,'CO2ubio',purpose,energy19a] 
                                                                                                + qEmmProdE.l[s,t,'CO2bio',purpose,energy19a]$(sameas[energy19a,'Natural gas incl. biongas']);

    # Reduction potential measured in ktCO2e for each technology, sector, purpose and existing energy good
    MAC_curve_ID[techID,s,purpose,energy19a,t,MAC_emm,'Reduction potential, ktCO2e']$(d1thetaID_k[techID,purpose,energy19a,s,t] and tMAC_report[t]) 
        = sum(energy19, qEmmProdE_MechCh_MAC[techID,purpose,energy19,s,t,MAC_emm]);

    # Reduction potential measured in pct. for each technology, sector, purpose and existing energy good
    MAC_curve_ID[techID,s,purpose,energy19a,t,MAC_emm,'Reduction potential, pct.']$(d1thetaID_k[techID,purpose,energy19a,s,t] and qEmmProdE_MAC[s,t,MAC_emm,purpose,energy19a] and tMAC_report[t]) 
        = MAC_curve_ID[techID,s,purpose,energy19a,t,MAC_emm,'Reduction potential, ktCO2e']/qEmmProdE_MAC[s,t,MAC_emm,purpose,energy19a];

    # Reduction cost measured in DKK/tCO2 for each technology, sector, purpose and existing energy good
    MAC_curve_ID[techID,s,purpose,energy19a,t,MAC_emm,'cost_DKK_pr_tCO2']$(MAC_curve_ID[techID,s,purpose,energy19a,t,MAC_emm,'Reduction potential, ktCO2e'] and d1thetaID_k[techID,purpose,energy19a,s,t] and tMAC_report[t]) 
        = -vREa_MechCh[techID,purpose,energy19a,s,t]/MAC_curve_ID[techID,s,purpose,energy19a,t,MAC_emm,'Reduction potential, ktCO2e']*10**6;


# ======================================================================================================================
# Construct MAC curves for GSR
# ======================================================================================================================
PARAMETERS
    qEmmProdE_GSR[GSR_ag,t,MAC_emm]                                       'Baseline emissions for each GSR'        
    qEmmProdE_GSR_tot[t,MAC_emm]                                          'Total baseline emissions'
    MAC_curve_ID_GSR[techID,GSR_ag,s,purpose,energy19a,t,MAC_emm,MAC_set] 'MAC curve for ID technologies (GSR)'
;
# Baseline emissions for each GSR
qEmmProdE_GSR[GSR_ag,t,MAC_emm] = sum((s,purpose,energy19)$(mapGrREFORM2GSR[purpose,energy19,s,GSR_ag,t] and qEmmProdE_MAC[s,t,MAC_emm,purpose,energy19]), 
                                                            qEmmProdE_MAC[s,t,MAC_emm,purpose,energy19]);
# Total baseline emissions
qEmmProdE_GSR_tot[t,MAC_emm] = sum(GSR_ag$(sum((techID,purpose,energy19a,s), d1thetaID_k[techID,purpose,energy19a,s,t] and mapGrREFORM2GSR[purpose,energy19a,s,GSR_ag,t])), 
                                                            qEmmProdE_GSR[GSR_ag,t,MAC_emm]);

# Reduction potential measured in ktCO2e
MAC_curve_ID_GSR[techID,GSR_ag,s,purpose,energy19a,t,MAC_emm,'Reduction potential, ktCO2e']$(d1thetaID_k[techID,purpose,energy19a,s,t] and tMAC_report[t])
    = MAC_curve_ID[techID,s,purpose,energy19a,t,MAC_emm,'Reduction potential, ktCO2e']$(mapGrREFORM2GSR[purpose,energy19a,s,GSR_ag,t] and d1thetaID_k[techID,purpose,energy19a,s,t]);

# Reduction potential measured in share of GSR
MAC_curve_ID_GSR[techID,GSR_ag,s,purpose,energy19a,t,MAC_emm,'Reduction potential, sh (GSR)']$(MAC_curve_ID_GSR[techID,GSR_ag,s,purpose,energy19a,t,MAC_emm,'Reduction potential, ktCO2e'] and qEmmProdE_GSR[GSR_ag,t,MAC_emm] and tMAC_report[t])
    = MAC_curve_ID_GSR[techID,GSR_ag,s,purpose,energy19a,t,MAC_emm,'Reduction potential, ktCO2e']/qEmmProdE_GSR[GSR_ag,t,MAC_emm];

# Reduction potential measured in share of total emissions
MAC_curve_ID_GSR[techID,GSR_ag,s,purpose,energy19a,t,MAC_emm,'Reduction potential, sh (Tot)']$(MAC_curve_ID_GSR[techID,GSR_ag,s,purpose,energy19a,t,MAC_emm,'Reduction potential, ktCO2e'] and qEmmProdE_GSR[GSR_ag,t,MAC_emm] and tMAC_report[t])
    = MAC_curve_ID_GSR[techID,GSR_ag,s,purpose,energy19a,t,MAC_emm,'Reduction potential, ktCO2e']/qEmmProdE_GSR_tot[t,MAC_emm];

# Reduction cost measured in DKK/tCO2
MAC_curve_ID_GSR[techID,GSR_ag,s,purpose,energy19a,t,MAC_emm,'cost_DKK_pr_tCO2']$(d1thetaID_k[techID,purpose,energy19a,s,t] and tMAC_report[t])
    = MAC_curve_ID[techID,s,purpose,energy19a,t,MAC_emm,'cost_DKK_pr_tCO2']$(mapGrREFORM2GSR[purpose,energy19a,s,GSR_ag,t]);



# ======================================================================================================================
# Reporting variable
# ======================================================================================================================
PARAMETER
    abatement_reporting[set_abatement_reporting,techID,purpose,energy19a,s,t]
;

#  abatement_reporting['Additional_costs_krprCO2',techID,purpose,energy19a,s,t]$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t])
#      = (thetaID_k.l[techID,purpose,energy19a,s,t]-pREa.l[purpose,energy19a,s,t])/sum(emm, uEmmProdE.l[s,t,emm,energy19a]*GWP.l[emm])*(10**6);

#  abatement_reporting['pREa',techID,purpose,energy19a,s,t]$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t]) 
#      = sum(energy19$(d1thetaID[techID,purpose,energy19a,energy19,s,t]), pREa.l[purpose,energy19,s,t]); 
 
#  abatement_reporting['thetaID_k',techID,purpose,energy19a,s,t]$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t]) 
#      = thetaID_k.l[techID,purpose,energy19a,s,t]; 
 
#  abatement_reporting['rID',techID,purpose,energy19a,s,t]$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t]) 
#      = rID.l[techID,purpose,energy19a,s,t];

#  abatement_reporting['rID_actual',techID,purpose,energy19a,s,t]$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t]) 
#      = rID_actual.l[techID,purpose,energy19a,s,t];

#  abatement_reporting['tCO2_REmarg',techID,purpose,energy19a,s,t]$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t]) 
#      = sum(emm_eq$(d1CO2_REmarg[purpose,energy19a,s,t,emm_eq]), tCO2_REmarg.l[purpose,energy19a,s,t,emm_eq]);