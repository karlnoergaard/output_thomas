# I dette modul sættes modellen op, så man eksogent kan styre produktionen i raffianderier (19000), cementindustrien (23001) og fikseri (03000).
# Længere nede vises det, hvorledes man styrer produktionen eksogent



parameter 
	cement_pre 'Cement produktion og efterspørgsel før ændring'
	cement_post 'Cement produktion og efterspørgsel efter ændring'
    qREa_pre[purpose,energy19,s,t] 'qREa før eksogen ændring'
    pMKE_pre[sp,t] 'pMKE før eksogen ændring'
	;

qREa_pre[purpose,energy19,s,t] = qREa.l[purpose,energy19,s,t];    
pMKE_pre[sp,t] = pMKE.l[sp,t];

#  Cementrapportering
cement_pre['qY_CET'] = 	qY_CET.l['out_other','23001','2035'];
cement_pre['qC_house'] = qC_y.l['cHou','23001','2035'];
cement_pre['qRxE_41430'] = qRxE_y.l['41430','23001','2035'];
cement_pre['qRxE_23001'] = qRxE_y.l['23001','23001','2035'];
cement_pre['qRxE_13150'] = qRxE_y.l['13150','23001','2035'];
cement_pre['qRxE_25000'] = qRxE_y.l['25000','23001','2035'];
cement_pre['qRxE_71000'] = qRxE_y.l['71000','23001','2035'];
cement_pre['qRxE_0600a'] = qRxE_y.l['0600a','23001','2035'];
cement_pre['qRxE_16000'] = qRxE_y.l['16000','23001','2035'];
cement_pre['qRxE_46000'] = qRxE_y.l['46000','23001','2035'];
cement_pre['qRxE_off'] = qRxE_y.l['off','23001','2035'];
cement_pre['qX'] = qX_y.l['xOth','23001','2035'];
cement_pre['q_other'] = cement_pre['qY_CET'] - (cement_pre['qC_house']+cement_pre['qRxE_41430']+cement_pre['qRxE_23001']+cement_pre['qRxE_13150']
	                                           +cement_pre['qRxE_25000']+cement_pre['qRxE_71000']+cement_pre['qRxE_0600a']+cement_pre['qRxE_16000']
	                                           +cement_pre['qRxE_46000']+cement_pre['qRxE_off']+cement_pre['qX']);
cement_pre['q_other_rela'] = cement_pre['q_other']/cement_pre['qY_CET'];

cement_pre['qC_house_m'] = qC_m.l['cHou','23001','2035'];
cement_pre['qRxE_41430_m'] = qRxE_m.l['41430','23001','2035'];
cement_pre['qRxE_23001_m'] = qRxE_m.l['23001','23001','2035'];
cement_pre['qRxE_13150_m'] = qRxE_m.l['13150','23001','2035'];
cement_pre['qRxE_25000_m'] = qRxE_m.l['25000','23001','2035'];
cement_pre['qRxE_71000_m'] = qRxE_m.l['71000','23001','2035'];
cement_pre['qRxE_0600a_m'] = qRxE_m.l['0600a','23001','2035'];
cement_pre['qRxE_16000_m'] = qRxE_m.l['16000','23001','2035'];
cement_pre['qRxE_46000_m'] = qRxE_m.l['46000','23001','2035'];
cement_pre['qRxE_off_m'] = qRxE_m.l['off','23001','2035'];




#  Angivelse af, hvilke raffianderiprodukter, som justeres eksogent
parameter d1ExoProdRaffi[out,s] "";
  d1ExoProdRaffi('Diesel for transport','19000')   = 1;
  d1ExoProdRaffi('Gasoline for transport','19000') = 1;
  d1ExoProdRaffi('Oil products','19000')           = 1;    
  d1ExoProdRaffi('Jet petroleum','19000')          = 1;
             


$GROUP G_exo 
    G_EXO
#Cement
    #  Efterspørgslen efter dansk produceret cement eksogeniseres i brancherne 
    qRxE_y$(tx0[t] and sameas[s,'23001'] and d1RxE_y[r,'23001',t] and d1RxE_m[r,'23001',t]), -sRxE_y$(tx0[t] and sameas[s,'23001'] and d1RxE_y[r,'23001',t] and d1RxE_m[r,'23001',t])
    #  Prisaggregatet for cement i brancherne holdes uændret ved at præferencen for udenlandsk cement stiger, når præferencen for dansk cement falder. Dermed har det ikke nævneværdige produktivitetseffekter at ændre i sRxE_y og sRxE_m 
    pRxE_ym$(tx0[t] and sameas[s,'23001'] and d1RxE_y[r,'23001',t] and d1RxE_m[r,'23001',t]), -sRxE_m$(tx0[t] and sameas[s,'23001'] and d1RxE_y[r,'23001',t] and d1RxE_m[r,'23001',t])    
    #  Den udenlandske efterspørgsel efter cement eksogeniseres
    qX_y$(tx0[t] and sameas[x,'xOth'] and sameas[s,'23001']), -sX_y$(tx0[t] and sameas[x,'xOth'] and sameas[s,'23001'])
    #  Efterspørgslen efter dansk produceret cement eksogeniseres i husholdningerne
    qC_y$(tx0[t] and sameas[c,'cHou'] and sameas[s,'23001']), -sC_y$(tx0[t] and sameas[c,'cHou'] and sameas[s,'23001'])
    #  Prisaggregatet for cement hos husholdningerne holdes uændret ved at præferencen for udenlandsk cement stiger, når præferencen for dansk cement falder. Dermed har det ikke nævneværdige nytteeffekter at ændre i sC_y og sC_m     
    pC_ym$(tx0[t] and sameas[c,'cHou'] and sameas[s,'23001']), -sC_m$(tx0[t] and sameas[c,'cHou'] and sameas[s,'23001'])
    #  Prisen på dansk cement holdes konstant via en lavere markup. 
    pY_CET$(t.val ge 2025 and sameas[s,'23001'] and sameas[out,'out_other']), -markup$(t.val ge 2025 and sameas[s,'23001'] and sameas[out,'out_other'])
#  Fiskeri
    #  Forbruget af diesel eksogeniseres
    qREa$(tx0[t] and sameas[purpose,'process_special'] and sameas[energy19a,'Diesel for transport'] and sameas[s,'03000'])
    -uRE$(tx0[t] and sameas[purpose,'process_special'] and sameas[energy19a,'Diesel for transport'] and sameas[s,'03000'])
    #  Prisaggregatet for maskinkapital og energi holdes ekosgent og maskinkapitalens produktivitet styres, så man får den ønskede MAC-kurve for grænsehandlen
    pMKE$(tx0[t] and sameas[sp,'03000']), -uIm$(tx0[t] and sameas[sp,'03000'])

;

$GROUP G_endo 
    G_ENDO
    #Cement
    -qRxE_y$(tx0[t] and sameas[s,'23001'] and d1RxE_y[r,'23001',t] and d1RxE_m[r,'23001',t]), sRxE_y$(tx0[t] and sameas[s,'23001'] and d1RxE_y[r,'23001',t] and d1RxE_m[r,'23001',t])
    -pRxE_ym$(tx0[t] and sameas[s,'23001'] and d1RxE_y[r,'23001',t] and d1RxE_m[r,'23001',t]), sRxE_m$(tx0[t] and sameas[s,'23001'] and d1RxE_y[r,'23001',t] and d1RxE_m[r,'23001',t])    
    -qX_y$(tx0[t] and sameas[x,'xOth'] and sameas[s,'23001']), sX_y$(tx0[t] and sameas[x,'xOth'] and sameas[s,'23001'])    
    -qC_y$(tx0[t] and sameas[c,'cHou'] and sameas[s,'23001']), sC_y$(tx0[t] and sameas[c,'cHou'] and sameas[s,'23001'])
    -pC_ym$(tx0[t] and sameas[c,'cHou'] and sameas[s,'23001']), sC_m$(tx0[t] and sameas[c,'cHou'] and sameas[s,'23001'])    
    -pY_CET$(t.val ge 2025 and sameas[s,'23001'] and sameas[out,'out_other']), markup$(t.val ge 2025 and sameas[s,'23001'] and sameas[out,'out_other'])    
    #Fiskeri
    -qREa$(tx0[t] and sameas[purpose,'process_special'] and sameas[energy19a,'Diesel for transport'] and sameas[s,'03000'])
    uRE$(tx0[t] and sameas[purpose,'process_special'] and sameas[energy19a,'Diesel for transport'] and sameas[s,'03000'])
    -pMKE$(tx0[t] and sameas[sp,'03000']), uIm$(tx0[t] and sameas[sp,'03000'])
;

parameter 
    cement_prod[t] 'Den eksogene produktion af cement ift. det forløb man kører på. 1 lig uændret produktion, 0,5 lig halvering af produktionen'
    raffi_prod[t] 'Den eksogene produktion af raffinaderiprodukter ift. det forløb man kører på.'
    fisk_prod[t] 'Det eksogene forbrug af brændstof i fiskeriproduktionen'
    tExoPhase[t] 'Indfasning af nedlukning'
    ;

#  Initialværdier
cement_prod[t] = 1;
raffi_prod[t] = 1;
fisk_prod[t] = 1;
tExoPhase['2026']=0.2;tExoPhase['2027']=0.4;tExoPhase['2028']=0.6;tExoPhase['2029']=0.8;



#  Pre settings for new MAC-curve
    CO2e_base2035 = output_qEmm['0 Ialt','2035'];
    reduction2035_last=CO2e_base2035-output_qEmm['0 Ialt','2035'];
    EV0[set_EV_all,'yearly'] = EV[set_EV_all,'yearly'];


#  Første stød

#  Angivelse af niveau for eksogen produktion
cement_prod[t]$(t.val ge 2030) = 1;
cement_prod[t]$(t.val lt 2030 and t.val gt 2025) = 1*(1-tExoPhase[t])+cement_prod['2030']*tExoPhase[t];
raffi_prod[t]$(t.val ge 2030) = 1;
raffi_prod[t]$(t.val lt 2030 and t.val gt 2025) = 1*(1-tExoPhase[t])+raffi_prod['2030']*tExoPhase[t];
fisk_prod[t]$(t.val ge 2030) = 1;
fisk_prod[t]$(t.val lt 2030 and t.val gt 2025) = 1*(1-tExoPhase[t])+fisk_prod['2030']*tExoPhase[t];

#  Her sættes de eksogene variable til deres nye niveauer
$import level_for_exo_production.gms

$FIX G_exo;
$UNFIX G_endo;
@SOLVE(M_CO2tax);



#  #  Cementrapportering
#      cement_post['qY_CET'] = 	qY_CET.l['out_other','23001','2035'];
#      cement_post['qC_house'] = qC_y.l['cHou','23001','2035'];
#      cement_post['qRxE_41430'] = qRxE_y.l['41430','23001','2035'];
#      cement_post['qRxE_23001'] = qRxE_y.l['23001','23001','2035'];
#      cement_post['qRxE_13150'] = qRxE_y.l['13150','23001','2035'];
#      cement_post['qRxE_25000'] = qRxE_y.l['25000','23001','2035'];
#      cement_post['qRxE_71000'] = qRxE_y.l['71000','23001','2035'];
#      cement_post['qRxE_0600a'] = qRxE_y.l['0600a','23001','2035'];
#      cement_post['qRxE_16000'] = qRxE_y.l['16000','23001','2035'];
#      cement_post['qRxE_46000'] = qRxE_y.l['46000','23001','2035'];
#      cement_post['qRxE_off'] = qRxE_y.l['off','23001','2035'];
#      cement_post['qX'] = qX_y.l['xOth','23001','2035'];
#      cement_post['q_other'] = cement_post['qY_CET'] - (cement_post['qC_house']+cement_post['qRxE_41430']+cement_post['qRxE_23001']+cement_post['qRxE_13150']
#  	                                              +cement_post['qRxE_25000']+cement_post['qRxE_71000']+cement_post['qRxE_0600a']+cement_post['qRxE_16000']
#  	                                               +cement_post['qRxE_46000']+cement_post['qRxE_off']+cement_post['qX']);
#      cement_post['q_other_rela'] = cement_post['q_other']/cement_post['qY_CET'];

#      cement_post['qC_house_m'] = qC_m.l['cHou','23001','2035'];
#      cement_post['qRxE_41430_m'] = qRxE_m.l['41430','23001','2035'];
#      cement_post['qRxE_23001_m'] = qRxE_m.l['23001','23001','2035'];
#      cement_post['qRxE_13150_m'] = qRxE_m.l['13150','23001','2035'];
#      cement_post['qRxE_25000_m'] = qRxE_m.l['25000','23001','2035'];
#      cement_post['qRxE_71000_m'] = qRxE_m.l['71000','23001','2035'];
#      cement_post['qRxE_0600a_m'] = qRxE_m.l['0600a','23001','2035'];
#      cement_post['qRxE_16000_m'] = qRxE_m.l['16000','23001','2035'];
#      cement_post['qRxE_46000_m'] = qRxE_m.l['46000','23001','2035'];
#      cement_post['qRxE_off_m']   = qRxE_m.l['off','23001','2035'];




#  #  MAC-kurve rapportering
#  $SETGLOBAL indsaet del50fisk
#  $import report_qEmm.gms
#  $import report_EV.gms
#  $import loop_MAC.gms
#  $import loop_qEmm_dekomp.gms

#  execute_unload 'Output\exo_production_tmp.gdx';



#  #  andet stød

#  cement_prod[t]$(t.val ge 2030) = 1;
#  cement_prod[t]$(t.val lt 2030 and t.val gt 2025) = 1*(1-tExoPhase[t])+cement_prod['2030']*tExoPhase[t];
#  raffi_prod[t]$(t.val ge 2030) = 1;
#  raffi_prod[t]$(t.val lt 2030 and t.val gt 2025) = 1*(1-tExoPhase[t])+raffi_prod['2030']*tExoPhase[t];
#  fisk_prod[t]$(t.val ge 2030) = 0.5;
#  fisk_prod[t]$(t.val lt 2030 and t.val gt 2025) = 1*(1-tExoPhase[t])+fisk_prod['2030']*tExoPhase[t];

#  #  Her sættes de eksogene variable til deres nye niveauer
#  $import level_for_exo_production.gms


#      $FIX G_exo;
#      $UNFIX G_endo;
#      @SOLVE(M_CO2tax);

#  $SETGLOBAL indsaet del75fisk
#  $import report_qEmm.gms
#  $import report_EV.gms
#  $import loop_MAC.gms
#  $import loop_qEmm_dekomp.gms

#  execute_unload 'Output\exo_demand_tmp.gdx';




#  #  Fjernelse af struktureffekterne fra GSR del 1 - industri
#  #  https://ens.dk/sites/ens.dk/files/Basisfremskrivning/skm_notat_om_effekter_af_aftale_om_groen_skattereform_for_industri_mv._til_kf23.pdf

#  tExoPhase['2025']=0.5;tExoPhase['2026']=0.6;tExoPhase['2027']=0.7;tExoPhase['2028']=0.8;tExoPhase['2029']=0.9;

#  cement_prod[t]$(t.val ge 2030) = 1/(1-0.38); 
#  cement_prod[t]$(t.val lt 2030 and t.val ge 2025) = 1*(1-tExoPhase[t])+cement_prod['2030']*tExoPhase[t];
#  raffi_prod[t]$(t.val ge 2030) = 1/(1-0.29); 
#  raffi_prod[t]$(t.val lt 2030 and t.val ge 2025) = 1*(1-tExoPhase[t])+raffi_prod['2030']*tExoPhase[t];
#  fisk_prod[t]$(t.val ge 2030) = 1/(1-0.23); 
#  fisk_prod[t]$(t.val lt 2030 and t.val ge 2025) = 1*(1-tExoPhase[t])+fisk_prod['2030']*tExoPhase[t];

#  #  Her sættes de eksogene variable til deres nye niveauer
#  $import level_for_exo_production.gms


#      $FIX G_exo;
#      $UNFIX G_endo;
#      @SOLVE(M_CO2tax);



$import report_all.gms;

execute_unload 'Output\exo_production.gdx';


