# =====================================================================================================================
# Government  (Will be split in 3: Government, GovRevenues, and GovExpenses)
# =====================================================================================================================

# =====================================================================================================================
# Variable definition
# =====================================================================================================================
$IF %stage% == "variables":
  $GROUP G_Government_prices
    pGxDepr[t]$(tx0[t])                                  "Total public consumption minus depreciations"
  ;
  
  $GROUP G_Government_quantities_endo
    qG[g_,t]$(d1G[g_,t])                                 "Public consumption <G_t>"
    qGxDepr[t]                                           "Total public consumption minus depreciations"
    qI_s_vaadlaeglavbund[t]                              "Government subsidized wetting of lavbund"                             
  ;

  $GROUP G_Government_quantities_exo
  ;

  $GROUP G_Government_quantities    
    G_Government_quantities_endo
    G_Government_quantities_exo                           
  ;

  $GROUP G_Government_values_endo
    vGovPrimBalance[t]                                    "Primary budget balance (Statens primære saldo) <GovPrimBalance_t>"
    vGovExp[t]                                            "Public expenditures except interest payments (primære offentlige udgifter) <GovExp_t>"
    vGovRev[t]                                            "Public revenues (Primære offentlige indtægter) <GovRev_t>"
    vtIndirect[t]                                         "Revenue from indirect taxes (Indirekte skatter) <T_t^{Indirect}>"
    vtProduction[t]                                       "Revenue from taxation on production (Produktionsskatter)"
    vtProductionRest[t]                                   "Value of residual production taxes"
    vtDirect[t]                                           "Revenue from direct taxation (direkte skatter) <T_t^{Direct}>"
    vtSource[t]                                           "Revenue from income taxation (kildeskatter)"
    vtCorp[t]                                             "Revenue from corporate taxation"
    vtAM[t]                                               "Revenue from taxation on payroll to the labour market institutions (Arbejdsmarkedsbidrag)"     ##
    vtMedia[t]                                            "Revenue from public media contribution (Medielicens)" ##
    vtPersIncRest[t]                                      "Revenue from taxation on other personal income"
    vtCarWeight[t]                                        "Revenue from taxation on paid weight charge on cars (household, Vægtafgift fra husholdningerne)"
    vtPAL[t]                                              "PAL tax revenue" 
    vtEU[t]                                               "Indirect taxes to the EU"
    vGovInv[t]                                            "Government investments"
    vCont[t]                                              "Contributions (Bidrag til sociale ordninger)"

    vtBequest[t]                                          "Capital taxes on bequest (arveafgift)"
    vGovProfit[t]                                         "Profit from public corporation (Overskud af offentlig virksomhed)"
    vGovRent[t]                                           "Land rent (Jordrente)"
    vGovReceiveF[t]                                       "Payments from foreign countries (Overførsler fra udlandet)" 
    vGovReceiveHH[t]                                      "Payments from households (Overførsler fra den private sektor)"
    vGovReceiveFirms[t]                                   "Payments from domestic firms (Overførsler fra den private sektor)"    
    vGovRevRest[t]                                        "Other government revenues"
    vGovSub[t]                                            "Government subsidies"
    vSubProduction[t]                                     "Production subsidies (Produktionssubsidier)"
    vSubEU[t]                                             "Subsidies from EU"
    vCCSsubsidy[s,t]$(sum(techCCS, sum(emm, sum(purpose, sum(energy19, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])) or d1thetaccsxe[techCCS,s,t,emm]))) "Subsidies to CCS"
    vSubProductionRest[t]                                 "Production subsidies exluding wage subsidies"
    vGovLand[t]                                           "Purchase of land and rights (Køb af jord rettigheder netto)"
    vGov2Firms[t]                                         "Payments to domestic firms (Overførsler til virksomheder)"
    vGov2HH[t]                                            "Payments to households (Overførsler til husholdningerne)"
    vGov2Foreign[t]                                       "Payments to foreign countries (Overførsler til udlandet)"
    vGovExpRest[t]                                        "Other government expenditures"
    vGovNetWealth[t]                                      "Government net wealth"

    vGovAssets[t]                                         "Public assets (statens aktiver)"
    vInterestGovAssets[t]                                 "Interest payments on government assets"    
    vInterestGovDebt[t]                                   "Interest payments on government liabilities"
    vGovNetInterest[t]                                    "The government net interests"
    vGovBudget[t]                                         "The government budget"
    vGovDebt[t]                                           "Public debt (statens passiver)"
    vPersAllowance[t]                                     "Personal allowance (Personfradrag)"
    vtChurch[t]                                           "Revenue from taxation to churches"
    vtCorpNorth[t]                                        "Corporate taxes payed by the extraction sector"
    vBequest[t]                                           "Bequest received by household" 
    vHH[portfolio,t]$(sameas[portfolio,'Pension'])        "Household net-wealth"
    vPublicSales[t]                                       "Sales of public production to private sector"
    vGxDepr[t]                                            "Total public consumption minus depreciations"
    vVaadOmk[t]                                           "Total cost, bio. kr. wetting of organic soils"
    vKompOmk[t]                                           "Total cost, bio. kr. compensating farmers for their organic soils"
 ;

$GROUP G_Government_values_exo

    vGovAssets[t]$(t0[t])                                 "Public assets (statens aktiver)"
    vGovDebt[t]$(t0[t])                                   "Public debt (statens passiver)"
    vGovNetWealth[t]$(t0[t])                              "Government net wealth"
    vLumpsum[t]$(tx0[t])                                  "Lumpsum transfer from the household" #For at maintain indkomstkredsløbet
    vPersAllowance[t]$(t0[t])                           "Personal allowance (Personfradrag)"
    vHH[portfolio,t]$(t0[t] and sameas[portfolio,'Pension']) "Household net-wealth"   
    vGovReval[t]$(tx0[t])                                 "Government revaluations of assets and liabilities"    
    vtCO2_ETS_sales[t]$(tx0[t])                           "CO2-kvoter"
    vtCO2_LULUCF[t]$(tx0[t])                              "CO2-kvoter in LULUCF"
;

  $GROUP G_Government_values
  G_Government_values_exo
  G_Government_values_endo
  ;

$GROUP G_Government_other_exo
    uvGxDepr[t]$(tx0[t])                                 ""
    fdemoNeeds[t]$(tx0[t])                               "Demographic features"
    sG[g_,t]$(tx0[t] and sameas[g_,'g'])                 "Scale parameters in the public consumption nest"
    eG[g_]$(sameas[g_,'gTot'])                           "Elasticities of substitution in the public consumption nest"
    tAM[t]$(tx0[t])                                      "Tax rate on payroll to the labour market institutions (Arbejdsmarkedsbidragssats)"           
    tMedia[t]$(tx0[t])                                   "Tax rate of public media contribution"
    tCarWeight[t]$(tx0[t])                               "Tax rate on paid weight charge on cars"
    tPAL[t]$(tx0[t])                                     "PAL - tax rate" ##
    tBequest[t]$(tx0[t])                                 "Bequest tax"
    tGovRent[t]$(tx0[t])                                 "Land rent rate"
    tChurch[t]$(tx0[t])                                  "Church tax rate"
    tCorpNorth[t]$(tx0[t])                               "Tax rate North Sea production"
    fvtEU[t]$(tx0[t])                                    "Correction factor"
    rCont[t]$(tx0[t])                                    ""
    rvGovProfit2GDP[t]$(tx0[t])                          "Share of vGovProfit in GDP"
    rvGovReceiveF2GDP[t]$(tx0[t])                        "Share of vGovReceiveF in GDP" 
    rvGovReceiveHH2GDP[t]$(tx0[t])                       "Share of vGovReceiveHH in GDP"
    rvGovReceiveFirms2GDP[t]$(tx0[t])                    "Share of vGovReceiveFirms in GDP"     
    rvSubProduction2GVA[t]$(tx0[t])                      "Share of vSubProduction in GVA"
    rvSubEU2GDP[t]$(tx0[t])                              "Share of vSubEU in GDP"
    rGov2Foreign2GDP[t]$(tx0[t])                         "Share of Gov2Foreign in GDP" 
    rGov2HH2GDP[t]$(tx0[t])                              "Share of Gov2HH in GDP"
    rGov2Firms2GDP[t]$(tx0[t])                           "Share of Gov2Firms in GDP"
    rGovLand2GDP[t]$(tx0[t])                             "Share of GovLand in GDP"
    rGovAssets2GDP[t]$(tx0[t])                           "Government assets relative to GDPP"  
    rGovAssets[t]$(tx0[t])                               "Interest rate on government assets"
    rGovDebt[t]$(tx0[t])                                 "Interest rate on government debt"     
    rvBequest2GVA[t]$(tx0[t])                            "Share of vBequest in GVA"
    rvHH2GVA[t]$(tx0[t])                                 "Share of vHH in GVA"
    rPersIncRest2GVA[t]$(tx0[t])                         "Share of PersIncRest in GVA"  
    jvtCorp[t]$(tx0[t])                                  "Corporate tax-revenue is pulled from an external forecast and so is tCorp. To ensure the model hits the revenue without adjusting tCorp we introduce an exogenous j-term that takes the slack in calibration"
    jvPersAllowance[t]$(tx0[t])                          ""
    #  rEmploymentGap[t]$(tx0[t])                        "Structural employment gap"
    #  rOutputGap[t]$(tx0[t])                            "Output gap"
    jvtIndirect[t]$(tx0[t])                              "J-term for indirect taxes"
    sPublicSales[t]$(tx0[t])                             "Public sales going to private consumption as share of government consumption"
    vSubsidy_Pyrolyse[t]$(sum(PyrolyseTech, d1PyrolysePot[PyrolyseTech,t]))   ""
 ;

  $GROUP G_Government_other_endo
  ;



$ENDIF 

$IF %stage% == "groupcompilation":

  $GROUP G_Government_endo
    G_Government_prices
    G_Government_quantities_endo
    G_Government_values_endo
    G_Government_other_endo
  ;
  
  $GROUP G_Government_endo
    G_Government_endo$(tx0[t])  # Restrict endo group to tx0[t]
  ;

  $GROUP G_Government_exo
    G_Government_values_exo
    G_Government_quantities_exo
    G_Government_other_exo
    
    # E_vGxDepr
    w$(tx0[t])
    # qGxDepr
    qGovDepr$(tx0[t] and sameas[k_,'iTot'])

    # E_vtProductionRest
    vtNetProductionRest$(tx0[t] and sameas[s_,'tot'])
    vtCAP_tot$(tx0[t])
    vtLSubsidy$(tx0[t] and sameas[s_,'tot'])
    vtCO2_LULUCF$(tx0[t])
    vtCO2_organicinproduction$(tx0[t])
    vtCO2_organic_outofproduction$(tx0[t])
    # E_vtPAL
    rInterest$(tx0[t] and sameas[portfolio, 'Pension'])
    # E_vHH
    vGrossValAdd$(tx0[t] and sameas[s_,'tot'])
    # E_vtSource
    prod_a[t]$(tx0[t])
    rHHxAfk[t]$(tx0[t])
    t_r$(tx0[t])
    vWealth$(t0[t] or tx0E[t])
    Hours$(tx0[t])
    nEmployed$(tx0[t])
    tMargIncome$(tx0[t])
    # E_vGovExpRest
    vtPerHectareBottomDeduction$(plant_sectors_sp[sp] and tx0[t])   # tilføjet fuld betingelse
    vBotdedPerAnimal$(tx0[t] and ani_sectors_sp[sp])

    tAfforestationPerHa$(tx0[t])
    qLand_Nonproductive$((tx0[t] or t0[t]) and sameas[LandAllocation,'skov'])
    # E_qGxDepr
    pG$((t0[t] or tx0E[t]) and sameas[g_,'gTot'])
    # E_qG_tot
    pG$(tx0[t])
    # E_vGovExp
    vG$(tx0[t] and sameas[g_,'gTot'])
    # E_vGovRent
    vGrossValAdd$(tx0[t] and sameas[s_,'0600a'])
    # E_vtCorp
    vtCorpMain$(tx0[t] and s[s_] and not sameas[s_,'off'] and not sameas[s_,'0600a'])
    # E_vtIndirect
    vtCus$(tx0[t])
    vtDuty$(tx0[t])
    # E_vtProduction
    vtFirmsWeight$(tx0[t] and sameas[s_,'tot'])
    # E_vGovExp
    vTrans$(tx0[t])


    vtLAM$(tx0[t] and sameas[s_,'tot'])
    vtLand$(tx0[t] and sameas[s_,'tot'])
    vtLPayRoll$(tx0[t] and sameas[s_,'tot'])

    vtVAT$(tx0[t])
    
    qCHH$((t0[t] or txE[t]) and sameas[c_,'cCar'])
    
    
    sPublicSales$(tx0[t])
    pGxDepr[t]$(t0[t])
    pGovDepr$((tx0E[t] or t0[t]) and sameas[k_,'iTot'])
    vGDP$(tx0[t])
    vI_s$(itot[i_] and sameas[s,'off'] and tx0[t])
    nLaborForce$(tx0[t])
    vGovDepr$(tx0[t] and sameas[k_,'iTot'])
    nPop$(tx0[t])
    vEBITDA$(tx0[t] and sameas[s_,'0600a'])
    

    vSubsidy_CCS_EmmE_RE$(sum(energy19, d1qREE[purpose,energy19a,energy19,s,t] and sum(techCCS, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])) and (sameas[emm,'CO2ubio'] or sameas[emm,'CO2bio']))
    vSubsidy_CCS_EmmxE$(d1EmmProdxE[s,t,emm] and sum(techCCS, d1thetaCCSxE[techCCS,s,t,emm]) and sameas[emm,'CO2ubio'])


    #E_qI_s_vaadlaeglavbund 
    pI_r$(tx0[t] and sameas[i_,'iB']) # tilføjet betingelse om iB


    ;

  $GROUP G_Government_non_flat_initial_values_from_MAKRO
    vGovPrimBalance
    fdemoNeeds
    vtSource
    vtAM
    vtMedia
    vtPersIncRest
    vtCarWeight
    vtPAL
    vHH
    vtEU
    vCont
    vGovLand
    vInterestGovAssets
    vInterestGovDebt
    vtBequest
    vBequest
    vGovProfit
    vGovRent
    vGovReceiveF
    vGovReceiveHH
    vSubEU
    vSubProductionRest
    vGov2Foreign
    vGov2HH
    vGov2Firms
    vGovRev
    vGovAssets
    vGovDebt
    rGovDebt
    rGovAssets 
    vtChurch
    vtIndirect
    tCorp
    rFirms
    rBonds
  ;
  

$ENDIF


# =====================================================================================================================
# Equations
# =====================================================================================================================
$IF %stage% == "equations":
  $BLOCK B_Government

# ---------------------------------------------------------------------------------------------------------------------
# Public Consumption
# ---------------------------------------------------------------------------------------------------------------------
 # Aggregate public consumption excluding depreciations follows demographic needs and wage growth
    # This is because FM wants increased capital stock to give welfare improvements and increased public consumption on top of that from wages and demographic needs
    E_vGxDepr[t]$(tx0[t])..                    vGxDepr[t]                =E= uvGxDepr[t] * fdemoNeeds[t] * w[t];    
    E_qGxDepr[t]$(tx0[t])..                    qGxDepr[t] * pGxDepr[t-1]/fp =E= pG['gtot',t-1]/fp * qG['gtot',t] - pGovDepr['itot',t-1]/fp * qGovDepr['itot',t];
    E_pGxDepr[t]$(tx0[t])..                    pGxDepr[t] * qGxDepr[t]   =E= vGxDepr[t];
 
    E_qG_tot[t]$(tx0[t])..                     vGovDepr['itot',t]     =E= pG['gtot',t]*qG['gtot',t] - vGxDepr[t];

    # CES demand
    E_qG[g_,gNest,t]$(d1G[g_,t] and tx0[t] and gNest2g_(gNest,g_)).. qG[g_,t] =E= sG[g_,t] * (pG[gNest,t]/pG[g_,t])**eG[gNest] *qG[gNest,t];


# ----------------------------------------------------------------------------------------------------------------------
# Balance
# ----------------------------------------------------------------------------------------------------------------------
    E_vGovBudget[t]$(tx0[t])..                vGovBudget[t]           =E= vGovPrimBalance[t] + vGovNetInterest[t];
    
    E_vGovPrimBalance[t]$tx0[t]..             vGovPrimBalance[t]      =E= vGovRev[t] - vGovExp[t];

    E_vGovExp[t]$tx0[t]..                     vGovExp[t]              =E= vG['gtot',t] 
                                                                        + vTrans[t]
                                                                        + vGovInv[t] 
                                                                        + vGovSub[t] 
                                                                        + vGovExpRest[t];

    E_vGovRev[t]$tx0[t]..                     vGovRev[t]              =E= vtIndirect[t] 
                                                                        + vtDirect[t] 
                                                                        + vGovRevRest[t]
                                                                        + vLumpsum[t];

# ----------------------------------------------------------------------------------------------------------------------
# Indirect Taxes
# ----------------------------------------------------------------------------------------------------------------------
    E_vtIndirect[t]$tx0[t]..                  vtIndirect[t]           =E= vtVAT[t]
                                                                        + vtDuty[t]
                                                                        + vtProduction[t] 
                                                                        + vtCus[t]
                                                                        - vtEU[t]
                                                                        - sum(s$((sum((techCCS,purpose,energy19,emm), d1thetaCCS[techCCS,purpose,energy19,s,t,emm]) or sum((techCCS,emm), d1thetaccsxe[techCCS,s,t,emm]))),  
                                                                              vCCSsubsidy[s,t])
                                                                        + jvtIndirect[t]
                                                                        - vSubsidy_Pyrolyse[t]$(sum(PyrolyseTech, d1PyrolysePot[PyrolyseTech,t]))
                                                                        ;


    E_vtProductionRest[t]$(tx0[t])..          vtProductionRest[t]     =E= vtNetProductionRest['tot',t] + vtCAP_tot[t] - vtLSubsidy['tot',t] - vtCO2_LULUCF[t] #support for afforestation is assumed to be provided through CAP funds
                                                                                            + vtCO2_organicinproduction[t] + vtCO2_organic_outofproduction[t];
    
    E_vtProduction[t]$(tx0[t])..              vtProduction[t]         =E= vtLand['tot',t] 
                                                                        + vtFirmsWeight['tot',t] 
                                                                        + vtLPayRoll['tot',t] 
                                                                        + vtLAM['tot',t] 
                                                                        + vtProductionRest[t]
                                                                        + vtCO2_ETS_sales[t];


    E_vtEU[t]$tx0[t]..                        vtEU[t]                 =E= fvtEU[t] * vtCus[t];

# ----------------------------------------------------------------------------------------------------------------------
# Direkte skatter
# ----------------------------------------------------------------------------------------------------------------------
    E_vtDirect[t]$tx0[t]..                    vtDirect[t]             =E= vtSource[t] 
                                                                        + vtCorp[t]
                                                                        + vtAM[t]
                                                                        + vtMedia[t]
                                                                        + vtPersIncRest[t]
                                                                        + vtCarWeight[t]
                                                                        + vtPAL[t];
    
    E_vPersAllowance[t]$(tx0[t])..            vPersAllowance[t]       =E= vPersAllowance[t-1]  + jvPersAllowance[t];    

    E_vtSource[t]$(tx0[t])..                  vtSource[t]             =E= tMargIncome[t] * (w[t] * Hours[t] * prod_a[t] * nEmployed[t] + vTrans[t] - vPersAllowance[t])
                                                                        + t_r[t]*rHHxAfk[t]*vWealth[t-1]/fv;
                                                                        

    E_vtCorp[t]$(tx0[t])..                    vtCorp[t]               =E= sum(sp$(not sameas[sp,'0600a']), vtCorpMain[sp,t]) + vtCorpNorth[t] + jvtCorp[t];

    E_vtCorpNorth[t]$(tx0[t])..               vtCorpNorth[t]          =E= tCorpNorth[t] * vEBITDA['0600a',t];

    E_vtAM[t]$(tx0[t])..                      vtAM[t]                 =E= tAM[t] *(w[t] * Hours[t] * prod_a[t] * nEmployed[t]); 
    
    E_vtMedia[t]$(tx0[t])..                   vtMedia[t]              =E= tMedia[t] * nPop[t];

    E_vtPersIncRest[t]$(tx0[t])..             vtPersIncRest[t]        =E= rPersIncRest2GVA[t] * vGrossValAdd['tot',t];    

    E_vtCarWeigth[t]$(tx0[t])..               vtCarWeight[t]          =E= tCarWeight[t] * qCHH['cCar',t-1];

# The PAL-tax should be further developed if it is to make sense to have it described so specifically (as opposed to just following BVT)
# For example, wealth should be linked to the value of companies. /THN 
    E_vtPAL[t]$(tx0[t])..                     vtPAL[t]                =E= tPAL[t] * (rInterest['Pension',t]*vHH['Pension',t-1]/fv);

    E_vHH[portfolio,t]$(tx0[t] and sameas['Pension',portfolio]).. vHH['Pension',t] =E= rvHH2GVA[t] * vGrossValAdd['tot',t];

# ----------------------------------------------------------------------------------------------------------------------
# Other government revenues
# ----------------------------------------------------------------------------------------------------------------------
    E_vGovRevRest[t]$(tx0[t])..               vGovRevRest[t]          =E= vGovProfit[t] 
                                                                        + vGovRent[t] 
                                                                        + vGovReceiveF[t] 
                                                                        + vGovReceiveHH[t]
                                                                        + vGovReceiveFirms[t] 
                                                                        + vtBequest[t] 
                                                                        + vtChurch[t]
                                                                        + vCont[t]
                                                                        + vGovDepr['itot',t]; # + adj (MAKRO - documentation 2.2.4) 

#Perhaps it should follow the deliveries from the public sector to households. (which are modeled further down, I can see, but keep an eye on the income cycle when the change is made)  /THN
    E_vGovProfit[t]$(tx0[t])..                vGovProfit[t]           =E= rvGovProfit2GDP[t] * vGDP[t];

    E_vGovRent[t]$(tx0[t])..                  vGovRent[t]             =E= tGovRent[t] * vGrossValAdd['0600a',t];

    E_vGovReceiveF[t]$(tx0[t])..              vGovReceiveF[t]         =E= rvGovReceiveF2GDP[t] * vGDP[t];

    E_vGovReceiveHH[t]$(tx0[t])..             vGovReceiveHH[t]        =E= rvGovReceiveHH2GDP[t] * vGDP[t];    

    E_vGovReceiveFirms[t]$(tx0[t])..          vGovReceiveFirms[t]     =E= rvGovReceiveFirms2GDP[t] * vGDP[t];          

    E_vtBequest[t]$(tx0[t])..                 vtBequest[t]            =E= tBequest[t] * vBequest[t];
# Inheritamce cam certainly be modeled or linked better than this. Perhaps it should follow households' wealth /THN
    E_vBequest[t]$(tx0[t])..                  vBequest[t]             =E= rvBequest2GVA[t] * vGrossValAdd['tot',t];

    E_vtChurch[t]$(tx0[t])..                  vtChurch[t]             =E= tChurch[t] * (w[t] * Hours[t] * prod_a[t] * nEmployed[t] + vTrans[t] - vPersAllowance[t]);

    E_vCont[t]$(tx0[t])..                     vCont[t]                =E= rCont[t] * nLaborForce[t];
 
# ----------------------------------------------------------------------------------------------------------------------
# Public Investments
# ----------------------------------------------------------------------------------------------------------------------   
    E_vGovInv[t]$(tx0[t])..                   vGovInv[t]              =E= vI_s['itot','off',t]; 

# ----------------------------------------------------------------------------------------------------------------------
# Government net interests
# ----------------------------------------------------------------------------------------------------------------------   
# Interest income and expenses are affected by implicit interest rates (implicitte renter). Gross stock values (Brutto-stock-værdier) are affected by a share of GDP (BNP) (assets) 
# and revaluations (liabilities).

    E_vGovNetInterest[t]$(tx0[t])..          vGovNetInterest[t]      =E= vInterestGovAssets[t] - vInterestGovDebt[t];

    E_vInterestGovAssets[t]$(tx0[t])..        vInterestGovAssets[t]   =E= vGovAssets[t-1]/fv * rGovAssets[t];  ##Add equation for assets

    E_vInterestGovDebt[t]$(tx0[t])..          vInterestGovDebt[t]     =E= vGovDebt[t-1]/fv * rGovDebt[t];

    E_vGovAssets[t]$(tx0[t])..                vGovAssets[t]           =E= rGovAssets2GDP[t] * vGDP[t];

    E_vGovDebt[t]$(tx0[t])..                  vGovNetWealth[t]        =E= vGovAssets[t] - vGovDebt[t];

    E_vGovNetWealth[t]$(tx0[t])..             vGovNetWealth[t]        =E= vGovNetWealth[t-1]/fv  + vGovBudget[t]+ vGovReval[t];

# ----------------------------------------------------------------------------------------------------------------------
# Subsidies
# ----------------------------------------------------------------------------------------------------------------------   
    E_vGovSub[t]$(tx0[t])..                   vGovSub[t]              =E= vSubProduction[t] - vSubEU[t];
  
    E_vSubProduction[t]$(tx0[t])..            vSubProduction[t]       =E= vtLSubsidy['tot',t] + vSubProductionRest[t];
  
    E_vSubProductionRest[t]$(tx0[t])..        vSubProductionRest[t]   =E= rvSubProduction2GVA[t] * vGrossValAdd['tot',t];

    E_vSubEU[t]$(tx0[t])..                    vSubEU[t]               =E= vGDP[t] * rvSubEU2GDP[t];

    # Udgifter til CCS-subsidier for staten
    E_vCCSsubsidy[s,t]$(tx0[t] and (sum((techCCS,purpose,energy19,emm), d1thetaCCS[techCCS,purpose,energy19,s,t,emm]) or sum((techCCS,emm), d1thetaCCSxE[techCCS,s,t,emm])))..
                                              vCCSsubsidy[s,t]         =E= sum((purpose,energy19a,emm)$(sum(energy19, d1qREE[purpose,energy19a,energy19,s,t] and sum(techCCS, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])) and (sameas[emm,'CO2ubio'] or sameas[emm,'CO2bio'])), 
                                                                                vSubsidy_CCS_EmmE_RE[purpose,energy19a,s,t,emm])
                                                                          + sum(emm$(d1EmmProdxE[s,t,emm] and sum(techCCS, d1thetaCCSxE[techCCS,s,t,emm]) and sameas[emm,'CO2ubio']), 
                                                                                vSubsidy_CCS_EmmxE[s,t,emm]);
                   
# ----------------------------------------------------------------------------------------------------------------------
# Other government expenditures
# ----------------------------------------------------------------------------------------------------------------------   
    E_vGovExpRest[t]$(tx0[t])..               vGovExpRest[t]          =E= vGovLand[t]
                                                                        + vGov2Foreign[t]
                                                                        + vGov2HH[t]
                                                                        + vGov2Firms[t]
                                                                        #Expenses for lowlands
                                                                        + vVaadOmk[t] 
                                                                        + vKompOmk[t]
                                                                        + sum(plant_sectors, vtPerHectareBottomDeduction[plant_sectors,t])
                                                                        + sum(sp$(ani_sectors_sp[sp]), vBotdedPerAnimal[sp,t])
                                                                        + sum(plant_sectors,tAfforestationPerHa[plant_sectors,t] * (qLand_Nonproductive['skov',plant_sectors,t]-qLand_Nonproductive['skov',plant_sectors,t-1])) 
                                                                        ;

    E_vGovLand[t]$(tx0[t])..                  vGovLand[t]             =E= vGDP[t] * rGovLand2GDP[t];

    E_vGov2Foreign[t]$(tx0[t])..              vGov2Foreign[t]         =E= vGDP[t] * rGov2Foreign2GDP[t];

    E_vGov2HH[t]$(tx0[t])..                   vGov2HH[t]              =E= vGDP[t] * rGov2HH2GDP[t];

    E_vGov2Firms[t]$(tx0[t])..                vGov2Firms[t]           =E= vGDP[t] * rGov2Firms2GDP[t];


    #Lowlands
    E_qI_s_vaadlaeglavbund[t]$(tx0[t]).. qI_s_vaadlaeglavbund[t] * pI_r['iB',t] =E=  vVaadOmk[t];# sum((HaUdtag,lavbundsmodel)$(d1OptionsUdtag_xGrid[HaUdtag,lavbundsmodel]), (Effektandele[t]-Effektandele[t-1]) * VaadOmk[HaUdtag,lavbundsmodel]/1000);
                                                                                                                                                              #It must be assumed that costs in the baseline (35,000 hectares) are included in the projections, which are incorporated via FM into GrønREFORM. Therefore, only costs for additional wetland drainage beyond this should be included here.
    E_vVaadOmk[t]$(tx0[t]).. vVaadOmk[t] =E= sum((HaUdtag,lavbundsmodel)$(d1OptionsUdtag_xGrid[HaUdtag,lavbundsmodel]), (Effektandele[t]-Effektandele[t-1]) * (VaadOmk[HaUdtag,lavbundsmodel] - VaadOmk['35000','1']) /1000);
                                                                                                                                                              #It is assumed that costs in the baseline (35,000 hectares) are included
    E_vKompOmk[t]$(tx0[t]).. vKompOmk[t] =E= sum((HaUdtag,Lavbundsmodel)$(d1OptionsUdtag_xGrid[HaUdtag,lavbundsmodel]), (Effektandele[t]-Effektandele[t-1]) * (Komp120pct[HaUdtag,lavbundsmodel] - Komp120pct['35000','1'])/1000);


# ---------------------------------------------------------------------------------------------------------------------
# Public inputs in private investments and consumption
# ---------------------------------------------------------------------------------------------------------------------
    # Public sales to private consumption follow government consumption
    E_vPublicSales[t]$(tx0[t]).. vPublicSales[t] =E= sPublicSales[t] * vG['gtot',t];


  $ENDBLOCK

$MODEL M_government B_Government;

$ENDIF

$IF %stage% == "exogenous_values":
# =====================================================================================================================
# Exogenous variablespY
# =====================================================================================================================

# =====================================================================================================================
# Data management
# =====================================================================================================================
   # Government demand elasticities
    # This is the elasticity in the consumption function - currently irrelevant, as there is only one public consumption good
    eG.L(gNest)           = 0.3;
    # This is the elasticity between public consumption and private input - set close to 1 so that public consumption proportionally draws on public production in value.
    eG.L(g)               = 0.9; 
    # Elasticity between imports and domestic inputs set close to 1 to achieve a smooth transition as described above (cannot be 1 with CES formulation)
    eG_s.L(g,s)           = 1.1;

    qG.l[g_,t]            = IO_qG[g_,t];
    pG.l[g_,t]            = IO_pG[g_,t];

    vGovPrimBalance.l[t]  = ExtFor_vGovPrimBalance[t]/MAKRO_inf_growth_factor[t];
    vGovExp.l[t]          = IO_vG['gtot',t];   
    
    #Transfers in MAKRO are growth- and inflation-adjusted
    # Balance and interest rates
    vInterestGovAssets.l[t]              = ExtFor_vInterestGovAssets[t]/MAKRO_inf_growth_factor[t];
    vInterestGovDebt.l[t]                = ExtFor_vInterestGovDebt[t]/MAKRO_inf_growth_factor[t];
    vGovAssets.l[t]                      = (ExtFor_vGovAssets['Obl',t] + ExtFor_vGovAssets['IndlAktier',t] + ExtFor_vGovAssets['UdlAktier',t] + ExtFor_vGovAssets['Bank',t]) /MAKRO_inf_growth_factor[t];
    vGovDebt.l[t]                        = (ExtFor_vGovDebt['Obl',t] + ExtFor_vGovDebt['Bank',t] + ExtFor_vGovDebt['RealKred',t])/MAKRO_inf_growth_factor[t];

    # Direct Taxes
    vtSource.l[t]                        = ExtFor_vtSource[t]/MAKRO_inf_growth_factor[t];
    vPersAllowance.l[t]                  = ExtFor_vPersAllowance['tot',t]/MAKRO_inf_growth_factor[t];    
    vtAM.l[t]                            = ExtFor_vtAM['tot',t]/MAKRO_inf_growth_factor[t];
    vtMedia.l[t]                         = ExtFor_vtMedia[t]/MAKRO_inf_growth_factor[t];   
    vtPersIncRest.l[t]                   = ExtFor_vtPersIncRest['tot',t]/MAKRO_inf_growth_factor[t];
    vtCarWeight.l[t]                     = ExtFor_vtCarWeight['tot',t]/MAKRO_inf_growth_factor[t];
    vtPAL.l[t]                           = ExtFor_vtPAL[t]/MAKRO_inf_growth_factor[t];
    vHH.l['Pension',t]                   = ExtFor_vHHpens['penstot','tot',t]/MAKRO_inf_growth_factor[t]; #AKB, june 2025: We only load pension data into vHH now 
    rInterest.l['Pension',t]             = ExtFor_rInterest['Penstot',t];
    vtCorp.l[t]                          = ExtFor_vtCorp['tot',t]/MAKRO_inf_growth_factor[t];
    vtCorpNorth.l[t]                     = ExtFor_vtCorp['udv',t]/MAKRO_inf_growth_factor[t];

    # Indirect Taxes
    vtIndirect.l[t]                      = ExtFor_vtIndirect[t]/MAKRO_inf_growth_factor[t];
    vtEU.l[t]                            = ExtFor_vtEU[t]/MAKRO_inf_growth_factor[t];
    # Other/Further Income (Øvrig indkomst)
    vGovProfit.l[t]                      = ExtFor_vGovProfit[t]/MAKRO_inf_growth_factor[t];
    vGovRent.l[t]                        = ExtFor_vGovRent[t]/MAKRO_inf_growth_factor[t];
    vGovReceiveF.l[t]                    = ExtFor_vGovReceiveF[t]/MAKRO_inf_growth_factor[t];
    vGovReceiveHH.l[t]                   = ExtFor_vGovReceiveHH[t]/MAKRO_inf_growth_factor[t];
    vGovReceiveFirms.l[t]                = ExtFor_vGovReceiveFirms[t]/MAKRO_inf_growth_factor[t];    
    vtBequest.l[t]                       = ExtFor_vtBequest['tot',t]/MAKRO_inf_growth_factor[t];
    vBequest.l[t]                        = ExtFor_vBequest['tot',t]/MAKRO_inf_growth_factor[t]; # vBequest.l[t]$(vBequest.l[t]=0) = 1;
    vtChurch.l[t]                        = ExtFor_vtChurch['tot',t]/MAKRO_inf_growth_factor[t];
    vCont.l[t]                           = ExtFor_vCont['tot',t]/MAKRO_inf_growth_factor[t];
    # Expenses
    vSubProductionRest.l[t]              = ExtFor_vSubProductionRest['tot',t]/MAKRO_inf_growth_factor[t];
    vSubEU.l[t]                          = ExtFor_vSubEU[t]/MAKRO_inf_growth_factor[t];
    vGovLand.l[t]                        = ExtFor_vGovLand[t]/MAKRO_inf_growth_factor[t];
    vGov2Foreign.l[t]                    = ExtFor_vGov2Foreign[t]/MAKRO_inf_growth_factor[t];
    vGov2HH.l[t]                         = ExtFor_vGov2HH[t]/MAKRO_inf_growth_factor[t];  #vGov2HH.l[t]$(vGov2HH.l[t]=0) = 1;
    vGov2Firms.l[t]                      = ExtFor_vGov2Firms[t]/MAKRO_inf_growth_factor[t];



    #  For structural balance, which has not yet modeled
#    rOutputGap.l[t]                      = ExtFor_rOutputGap[t];
#    rEmploymentGap.l[t]                  = ExtFor_rEmploymentGap[t]; 
    
    vPublicSales.l[t] = sum(c, io_vC_ym[c,'OFF',t]);
    vGxDepr.l[t]  = IO_vG['gtot',t] - vGovDepr.l['itot',t]; #£AKB: As mentioned in production, MAKRO data doesn't seem to add up to the total. We replace it with a computed value.  #ExtFor_vOffAfskr('itot',t)/MAKRO_inf_growth_factor[t];
    pGxDepr.l[t]  = IO_pG['gtot',t];           
    qGxDepr.l[t]$pGxDepr.l[t] = vGxDepr.l[t]/pGxDepr.l[t];
    fdemoNeeds.l[t] = ExtFor_fdemotraek['tot',t];


    #CO2-quotas
    vtCO2_ETS_sales.l[t] =  sum(r$(d1CO2_ETS[r,t]), vtCO2_ETS.l[r,'2018']); #Until better data arrives states sales of quotas are fixed in value 

    $GROUP G_government_data 
      qG 
      pG 
      vGovDepr
      vGxDepr
      pGxDepr
      qGxDepr
      vGovDepr 
      qGovDepr 
      pGovDepr
      vtSource
      vtAM 
      vtMedia 
      vtPersIncRest 
      vtCarWeight
      vtPAL 
      vtEU 
      vCont 
      vGovProfit 
      vGovRent 
      vGovReceiveF 
      vGovReceiveHH 
      vGovReceiveFirms
      vSubEU 
      vSubProductionRest 
      vGovLand 
      vGov2Foreign
      vGov2HH 
      vGov2Firms 
      vGovAssets 
      vGovDebt 
      vInterestGovAssets 
      vInterestGovDebt 
      vGovPrimBalance 
      vtChurch 
      vBequest 
      vHH 
      vtIndirect 
      vPublicSales 
      vtCorp 
      vtCorpNorth 
    ;

    
$ENDIF





# =====================================================================================================================
# Static calibration
# =====================================================================================================================
$IF %stage% == "static_calibration":
  $GROUP G_Government_static_calibration
    G_Government_endo
    sG[g_,t]$(tx0[t] and sameas[g_,'g']), -qG[g_,t]
    uvGxDepr # This needs a comment. With qG['gtot'] fixed, E_qG_tot becomes an equation determining vGxDepr residually. This, in turn, means that uvGxDepr can be determined in its equation.
    #  uvGxDepr[t] ,-vGxDepr[t]
    -vtSource$(tx0[t]), tMargIncome$(tx0[t])
    -vtAM[t]$(tx0[t]), tAM[t]$(tx0[t])
    -vtMedia[t]$(tx0[t]), tMedia[t]$(tx0[t])
    -vtPersIncRest[t]$(tx0[t]), rPersIncRest2GVA[t]$(tx0[t])
    -vtCarWeight[t]$(tx0[t]), tCarWeight[t]$(tx0[t])
    -vtPAL[t]$(tx0[t]), tPAL[t]$(tx0[t])
    -vtEU[t]$(tx0[t]), fvtEU[t]$(tx0[t])
    -vCont[t]$(tx0[t]), rCont[t]$(tx0[t])
    -vGovProfit[t]$(tx0[t]), rvGovProfit2GDP[t]$(tx0[t])
    -vGovRent[t]$(tx0[t]), tGovRent[t]$(tx0[t])
    -vGovReceiveF[t]$(tx0[t]), rvGovReceiveF2GDP[t]$(tx0[t])
    -vGovReceiveHH[t]$(tx0[t]), rvGovReceiveHH2GDP[t]$(tx0[t])
    -vGovReceiveFirms[t]$(tx0[t]), rvGovReceiveFirms2GDP[t]$(tx0[t])    
    -vSubEU[t]$(tx0[t]), rvSubEU2GDP[t]$(tx0[t])
    -vSubProductionRest[t]$(tx0[t]), rvSubProduction2GVA[t]$(tx0[t])
    -vGovLand[t]$(tx0[t]), rGovLand2GDP[t]$(tx0[t])
    -vGov2Foreign[t]$(tx0[t]), rGov2Foreign2GDP[t]$(tx0[t])
    -vGov2HH[t]$(tx0[t]), rGov2HH2GDP[t]$(tx0[t])
    -vGov2Firms[t]$(tx0[t]), rGov2Firms2GDP[t]$(tx0[t])
    -vGovAssets[t]$(tx0[t]), rGovAssets2GDP[t]$(tx0[t])
    -vGovDebt[t]$(tx0[t]), vGovReval[t]$(tx0[t])
    -vInterestGovAssets[t]$(tx0[t]), rGovAssets[t]$(tx0[t])
    -vInterestGovDebt[t]$(tx0[t]), rGovDebt[t]$(tx0[t])
    -vGovPrimBalance[t]$(tx0[t]), vLumpsum[t]$(tx0[t])
    -vtChurch[t]$(tx0[t]), tChurch[t]$(tx0[t])
    -vBequest[t]$(tx0[t]), rvBequest2GVA[t]$(tx0[t])

    -vHH$(tx0[t]), rvHH2GVA[t]$(tx0[t])
    -vtIndirect$(tx0[t]), jvtIndirect$(tx0[t])
    sPublicSales$(tx0[t]), -vPublicSales
    -vtCorp, jvtCorp$(tx0[t]),
    -vtCorpNorth,tCorpNorth$(tx0[t])
;

  $GROUP G_Government_static_calibration_exo 
    G_government_exo 
    -uvGxDepr
    #  vGxDepr[t],-uvGxDepr[t]
    qG$(tx0[t] and d1G[g_,t]), -sG$(d1G[g_,t])
    vtSource$(tx0[t]), -tMargIncome$(tx0[t])
    vtAM[t]$(tx0[t]), -tAM[t]$(tx0[t])
    vtMedia[t]$(tx0[t]), -tMedia[t]$(tx0[t])
    vtPersIncRest[t]$(tx0[t]), -rPersIncRest2GVA[t]$(tx0[t])
    vtCarWeight[t]$(tx0[t]), -tCarWeight[t]$(tx0[t])
    vtPAL[t]$(tx0[t]), -tPAL[t]$(tx0[t])
    vtEU[t]$(tx0[t]), -fvtEU[t]$(tx0[t])
    vCont[t]$(tx0[t]), -rCont[t]$(tx0[t])
    vGovProfit[t]$(tx0[t]), -rvGovProfit2GDP[t]$(tx0[t])
    vGovRent[t]$(tx0[t]), -tGovRent[t]$(tx0[t])
    vGovReceiveF[t]$(tx0[t]), -rvGovReceiveF2GDP[t]$(tx0[t])
    vGovReceiveHH[t]$(tx0[t]), -rvGovReceiveHH2GDP[t]$(tx0[t])
    vGovReceiveFirms[t]$(tx0[t]), -rvGovReceiveFirms2GDP[t]$(tx0[t])    
    vSubEU[t]$(tx0[t]), -rvSubEU2GDP[t]$(tx0[t])
    vSubProductionRest[t]$(tx0[t]), -rvSubProduction2GVA[t]$(tx0[t])
    vGovLand[t]$(tx0[t]), -rGovLand2GDP[t]$(tx0[t])
    vGov2Foreign[t]$(tx0[t]), -rGov2Foreign2GDP[t]$(tx0[t])
    vGov2HH[t]$(tx0[t]), -rGov2HH2GDP[t]$(tx0[t])
    vGov2Firms[t]$(tx0[t]), -rGov2Firms2GDP[t]$(tx0[t])
    vGovAssets[t]$(tx0[t]), -rGovAssets2GDP[t]$(tx0[t])
    vGovDebt[t]$(tx0[t]), -vGovReval[t]$(tx0[t])
    vInterestGovAssets[t]$(tx0[t]), -rGovAssets[t]$(tx0[t])
    vInterestGovDebt[t]$(tx0[t]), -rGovDebt[t]$(tx0[t])
    vGovPrimBalance[t]$(tx0[t]), -vLumpsum[t]$(tx0[t])
    vtChurch[t]$(tx0[t]), -tChurch[t]$(tx0[t])
    vBequest[t]$(tx0[t]), -rvBequest2GVA[t]$(tx0[t])
    vHH$((t0[t] or tx0[t]) and sameas[portfolio,'Pension']), -rvHH2GVA[t]$(tx0[t])
    vtIndirect$(tx0[t]), -jvtIndirect$(tx0[t])
    -sPublicSales, vPublicSales$(tx0[t])
    vtCorp$(tx0[t]), -jvtCorp,
    vtCorpNorth$(tx0[t]),-tCorpNorth
  ;

  $MODEL M_Government_static_calibration
    B_Government
    #  -E_qG_tot

  ;

$ENDIF


# =====================================================================================================================
# Dynamic calibration
# =====================================================================================================================
$IF %stage% == "dynamic_calibration":
  $GROUP G_Government_calib
    G_Government_endo

# vGxDepr
# -qGxDepr
# -pGxDepr
# -qG
# Balance
# -vGovBudget
# -vGovPrimBalance
# -vGovExp
# -vGovRev
### Indirect taxes
# -vtIndirect
# -vtProductionRest
# -vtProduction
# -vtEU
### Direkte skatter
# -vtDirect
# -vPersAllowance
# -vtSource
# -vtCorp
# -vtCorpNorth
# -vtAM
# -vtMedia
# -vtPersIncRest
# -vtCarWeight
# vtPAL
# vHH
### Other government revenues
# -vGovRevRest
# -vGovProfit
# -vGovRent
# -vGovReceiveF
# -vGovReceiveHH
# -vGovReceiveFirms
# -vtBequest
# -vBequest
# -vtChurch
# -vCont
# Public Investments
# -vGovInv
# Government net interests
# -vGovNetInterest
# -vInterestGovAssets
# -vInterestGovDebt
# -vGovAssets
# -vGovDebt
# -vGovNetWealth
### Subsidies
# -vGovSub
# -vSubProduction
# -vSubProductionRest
# -vSubEU
# -vCCSsubsidy
# Other government expenditures
# -vGovExpRest
# -vGovLand
# -vGov2Foreign
# -vGov2HH
# -vGov2Firms
# -qI_s_vaadlaeglavbund
# -vVaadOmk
# -vKompOmk
# Public inputs in private investments and consumption
# -vPublicSales


    ### Balance
    -vGovPrimBalance[t]$(tx0[t]), vLumpsum[t]$(tx0[t])
    ### Indirect taxes
    -vtIndirect$(tx0[t]), jvtIndirect$(tx0[t])
    -vtEU[t]$(tx0[t]), fvtEU[t]$(tx0[t])
    ### Direkte skatter
    -vtSource$(tx0[t]), tMargIncome$(tx0[t])
    -vtCorp, jvtCorp$(tx0[t])
    -vtCorpNorth,tCorpNorth$(tx0[t])
    -vtAM[t]$(tx0[t]), tAM[t]$(tx0[t])
    -vtMedia[t]$(tx0[t]), tMedia[t]$(tx0[t])
    -vtPersIncRest[t]$(tx0[t]), rPersIncRest2GVA[t]$(tx0[t])
    -vtCarWeight[t]$(tx0[t]), tCarWeight[t]$(tx0[t])
    -vtPAL[t]$(tx0[t]), tPAL[t]$(tx0[t])
    -vHH$(tx0[t]), rvHH2GVA[t]$(tx0[t])
    ### Other government revenues
    -vGovProfit[t]$(tx0[t]), rvGovProfit2GDP[t]$(tx0[t])
    -vGovRent[t]$(tx0[t]), tGovRent[t]$(tx0[t])
    -vGovReceiveF[t]$(tx0[t]), rvGovReceiveF2GDP[t]$(tx0[t])
    -vGovReceiveHH[t]$(tx0[t]), rvGovReceiveHH2GDP[t]$(tx0[t])
    -vGovReceiveFirms[t]$(tx0[t]), rvGovReceiveFirms2GDP[t]$(tx0[t])
    -vBequest[t]$(tx0[t]), rvBequest2GVA[t]$(tx0[t])
    -vtChurch[t]$(tx0[t]), tChurch[t]$(tx0[t])
    -vCont[t]$(tx0[t]), rCont[t]$(tx0[t])
    ### Government net interests
    -vInterestGovAssets[t]$(tx0[t]), rGovAssets[t]$(tx0[t])
    -vInterestGovDebt[t]$(tx0[t]), rGovDebt[t]$(tx0[t])
    -vGovAssets[t]$(tx0[t]), rGovAssets2GDP[t]$(tx0[t])
    -vGovDebt[t]$(tx0[t]), vGovReval[t]$(tx0[t])
    ### Subsidies
    -vGovLand[t]$(tx0[t]), rGovLand2GDP[t]$(tx0[t])
    -vGov2Foreign[t]$(tx0[t]), rGov2Foreign2GDP[t]$(tx0[t])
    -vGov2HH[t]$(tx0[t]), rGov2HH2GDP[t]$(tx0[t])
    -vGov2Firms[t]$(tx0[t]), rGov2Firms2GDP[t]$(tx0[t])
    -vSubProductionRest[t]$(tx0[t]), rvSubProduction2GVA[t]$(tx0[t])
    -vSubEU[t]$(tx0[t]), rvSubEU2GDP[t]$(tx0[t])

  ;

  $GROUP G_Government_calib_exo
    G_Government_exo
    
    ### Balance
    vGovPrimBalance[t]$(tx0[t]), -vLumpsum[t]$(tx0[t])
    ### Indirect taxes
    vtIndirect$(tx0[t]), -jvtIndirect$(tx0[t])
    vtEU[t]$(tx0[t]), -fvtEU[t]$(tx0[t])
    ### Direkte skatter
    vtSource$(tx0[t]), -tMargIncome$(tx0[t])
    vtCorp$(tx0[t]), -jvtCorp
    vtCorpNorth$(tx0[t]), -tCorpNorth
    vtAM[t]$(tx0[t]), -tAM[t]$(tx0[t])
    vtMedia[t]$(tx0[t]), -tMedia[t]$(tx0[t])
    vtPersIncRest[t]$(tx0[t]), -rPersIncRest2GVA[t]$(tx0[t])
    vtCarWeight[t]$(tx0[t]), -tCarWeight[t]$(tx0[t])
    vtPAL[t]$(tx0[t]), -tPAL[t]$(tx0[t])
    vHH$(tx0[t] and sameas['Pension',portfolio]), -rvHH2GVA[t]$(tx0[t])
    ### Other government revenues
    vGovProfit[t]$(tx0[t]), -rvGovProfit2GDP[t]$(tx0[t])
    vGovRent[t]$(tx0[t]), -tGovRent[t]$(tx0[t])
    vGovReceiveF[t]$(tx0[t]), -rvGovReceiveF2GDP[t]$(tx0[t])
    vGovReceiveHH[t]$(tx0[t]), -rvGovReceiveHH2GDP[t]$(tx0[t])
    vGovReceiveFirms[t]$(tx0[t]), -rvGovReceiveFirms2GDP[t]$(tx0[t])
    vBequest[t]$(tx0[t]), -rvBequest2GVA[t]$(tx0[t])
    vtChurch[t]$(tx0[t]), -tChurch[t]$(tx0[t])
    vCont[t]$(tx0[t]), -rCont[t]$(tx0[t]) 
    ### Government net interests
    vInterestGovAssets[t]$(tx0[t]), -rGovAssets[t]$(tx0[t])
    vInterestGovDebt[t]$(tx0[t]), -rGovDebt[t]$(tx0[t])
    vGovAssets[t]$(tx0[t]), -rGovAssets2GDP[t]$(tx0[t])
    vGovDebt[t]$(tx0[t]), -vGovReval[t]$(tx0[t])
    ### Subsidies
    vGovLand[t]$(tx0[t]), -rGovLand2GDP[t]$(tx0[t])
    vGov2Foreign[t]$(tx0[t]), -rGov2Foreign2GDP[t]$(tx0[t])
    vGov2HH[t]$(tx0[t]), -rGov2HH2GDP[t]$(tx0[t])
    vGov2Firms[t]$(tx0[t]), -rGov2Firms2GDP[t]$(tx0[t])    
    vSubProductionRest[t]$(tx0[t]), -rvSubProduction2GVA[t]$(tx0[t])
    vSubEU[t]$(tx0[t]), -rvSubEU2GDP[t]$(tx0[t])
  ;  
   

  $MODEL M_Government_calib
    B_Government

# E_vGxDepr
# -E_qGxDepr
# -E_pGxDepr
# -E_qG_tot
# -E_qG
### Balance
# -E_vGovBudget
# -E_vGovPrimBalance
# -E_vGovExp
# -E_vGovRev
### Indirect taxes
# -E_vtIndirect
# -E_vtProductionRest
# -E_vtProduction
# -E_vtEU
### Direkte skatter
# -E_vtDirect
# -E_vPersAllowance
# -E_vtSource
# -E_vtCorp
# -E_vtCorpNorth
# -E_vtAM
# -E_vtMedia
# -E_vtPersIncRest
# -E_vtCarWeigth
# E_vtPAL
# E_vHH
### Other government revenues
# -E_vGovRevRest
# -E_vGovProfit
# -E_vGovRent
# -E_vGovReceiveF
# -E_vGovReceiveHH
# -E_vGovReceiveFirms
# -E_vtBequest
# -E_vBequest
# -E_vtChurch
# -E_vCont
### Public Investments
# -E_vGovInv
### Government net interests
# -E_vGovNetInterest
# -E_vInterestGovAssets
# -E_vInterestGovDebt
# -E_vGovAssets
# -E_vGovDebt
# -E_vGovNetWealth
### Subsidies
# -E_vGovSub
# -E_vSubProduction
# -E_vSubProductionRest
# -E_vSubEU
# -E_vCCSsubsidy
# Other government expenditures
# -E_vGovExpRest
# -E_vGovLand
# -E_vGov2Foreign
# -E_vGov2HH
# -E_vGov2Firms
# -E_qI_s_vaadlaeglavbund
# -E_vVaadOmk
# -E_vKompOmk
# Public inputs in private investments and consumption
# -E_vPublicSales    
  ;

$ENDIF