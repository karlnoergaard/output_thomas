# =====================================================================================================================
# Input Output system
# =====================================================================================================================
# This module handles the details of the IO system.
# The different demand components are satisfied with domestic production competing with imports.

# ========================================================================================================================
# Variable definition
# ========================================================================================================================

$IF %stage% == "variables":

  # ---------------------------------------------------------------------------------------------------------------------
  # EXPORTS
  # ---------------------------------------------------------------------------------------------------------------------
  $GROUP G_IO_export_prices
    pX_y[x,s,t]$(tx0[t] and d1X_y[x,s,t])     "Price of exports of domestic origin"
    pX_m[x,s,t]$(tx0[t] and d1X_m[x,s,t])     "Price of exports of foreign origin (Import for reexport)"
    # pX[x_,t]$(tx0[t] and sameas[x_,'xTur'])   "Price of exports aggregates"
  ;

  $GROUP G_IO_export_quantities
    qX[x_,t]$(tx0[t] and sameas[x_,'xTur'])   "Quantity of exports aggregate"
  ;

  $GROUP G_IO_export_values
    vX_y[x,s,t]$(tx0[t] and d1X_y[x,s,t])     "Value of exports of domestic origin"
    vX_m[x,s,t]$(tx0[t] and d1X_m[x,s,t])     "Value of exports of foreign origin (Import for reexport)"
    vX[x_,t]$(tx0[t] and sameas[x_,'xTur'])   "Value of exports aggregate"
  ;

  $GROUP G_IO_export_other
    eX_tur                                    "Export parameter to tourism"
    sX_tur[t]$(tx0[t])                        "Export parameter to tourism"
    pWoodproduct_markup[t]$(tx0[t])           "Price of woodproduct mark-up"  
  ;

  $GROUP G_IO_export_endo
    G_IO_export_prices
    G_IO_export_values
    G_IO_export_quantities
  ;

  $GROUP G_IO_export_endo G_IO_export_endo$(tx0[t]); # Restrict endo group to tx0[t]

  $GROUP G_IO_export_exo 
    G_IO_export_other 
  ;

  ;

  # ---------------------------------------------------------------------------------------------------------------------
  # Investments
  # ---------------------------------------------------------------------------------------------------------------------
  $GROUP G_IO_investments_prices
    pI_r[i_,t]$(sum(s, d1I_s[I_,s,t]) or sameas[i_,'itot'])   "Paasche chain price of investments."
    pI_s[i_,s,t]$(tx0[t] and d1I_s[i_,s,t] and i[i_])         "CES price of investment goods demanded by sector s"
    pI_ym[i,s,t]$(d1I_ym[i,s,t])                              "CES price of investment input from sector s"
    pI_y[i,s,t]$(d1I_y[i,s,t])                                "Price of investment input of domestic origin"
    pI_m[i,s,t]$(d1I_m[i,s,t])                                "Price of investment input of foreign origin"
  ;

  $GROUP G_IO_investments_quantities
    qI[i_,t]$(tx0[t] and (k_[i_] or (sum(s,d1I_s['invt',s,t]) and sameas[i_,'invt']))) ""
    qI_ym[i,s,t]$(d1I_ym[i,s,t])                              "Demand for investment input from sector s"
    qI_y[i,s,t]$(d1I_y[i,s,t])                                "Investment input of domestic origin"
    qI_m[i,s,t]$(d1I_m[i,s,t])                                "Investment input of foreign origin"
    qLE[purpose,energy19,t]$(tx0[t] and d1qLE[purpose,energy19,t])              "Quantity of energy-good demanded for inventories"
  ;
  $GROUP G_IO_investments_values
    vI_y[i,s,t]$(d1I_y[i,s,t])                                "Value of investment input of domestic origin"
    vI_m[i,s,t]$(d1I_m[i,s,t])                                "Value of investment input of foreign origin"
    vI_ym[i,s,t]$(d1I_ym[i,s,t])                              "Value of investment input from sector s"
    vI[i_,t]$(sum(s, d1I_s[I_,s,t]))                          "Value of investments"
    vI_s[i_,s,t]$(d1I_s[i_,s,t])                              "Value of investments demanded by sector s"
    vLE[purpose,energy19,t]$(tx0[t] and d1vLE[purpose,energy19,t])               "Value of energy-good demanded from inventories"
  ;
  $GROUP G_IO_investments_endo
    G_IO_investments_prices
    G_IO_investments_quantities,-qLE$(tx0[t] and d1qLE[purpose,energy19,t])
    G_IO_investments_values
  ;
  $GROUP G_IO_investments_endo G_IO_investments_endo$(tx0[t]); # Restrict endo group to tx0[t]

  $GROUP G_IO_investments_other
    sI_ym[i,s,t]$(tx0[t] and d1I_ym[i,s,t] and k_[i])             "CES scale parameters in the sectoral demand for investment goods by sector"
    sI_y[i,s,t]$(tx0[t] and d1I_y[i,s,t])                         "Scale parameter of sectoral demand for domestic investment goods by sector"
    sI_m[i,s,t]$(tx0[t] and d1I_m[i,s,t])                         "Scale parameter of sectoral demand for foreign investment goods by sector"
    eI(i)$(k_[i])                                                 "Elasticity of substitution between sectors in the sectoral demand for investment goods"
    eI_s[i,s]$(k_[i] and (sameas[i,'iM'] or sameas[i,'iB'] or sameas[i,'iT']))      "Elasticity of substitution between domestic and foreign goods in the sectoral demand for investment goods" # er usikker på denne
    fpI_s[i,s,t]$(tx0[t] and d1I_s[i,s,t] and k_[i])              "Correction parameter to take different sector specific investment prices into account"
    qI_ID_actual[i,s,t]$(tx0[t] and k_[i] and d1I_s[i,s,t] and sameas(i,'iM') and not sameas[s,'off'] and sum(techID, sum(purpose, sum(energy19a, sum(tt, d1thetaID_k[techID,purpose,energy19a,s,t])))))       "Additional investment demand from input-displacing abatement"
    qI_CCS_actual[i,s,t]$(tx0[t] and k_[i] and d1I_s[i,s,t] and sameas[i,'iM'] and (sum(techCCS, sum(emm, sum(tt, sum(purpose, sum(energy19, d1thetaCCS[techCCS,purpose,energy19,s,tt,emm])) or d1thetaCCSxE[techCCS,s,tt,emm])))))           "Additional investment demand from CCS abatement"
    qEOPcost[t]$(tx0[t])                                          "Additional investment demand from Agricultural EOP abatement"
  ;
  
  # ---------------------------------------------------------------------------------------------------------------------
  # Material inputs ([R]aw materialsxE and intermediate goods and services)
  # ---------------------------------------------------------------------------------------------------------------------
  $GROUP G_IO_materialsxE_prices
    pRxE[r_,t]$(tx0[t] and ((d1RxE[r_,t] and r[r_]) or sameas[r_,'tot']))    "Price of material inputs (CES prices, except the Paasche chain price of total material inputs)"
    pRxE_pgroup[r,pgroup,t]$(d1RxE_pgroup[r,pgroup,t])                       "CES price of material inputs for product groups in input nests"
    pRxE_ym[r,s,t]$(d1RxE_ym[r,s,t])                                         "CES price of materialsxE in sector r from sector s"
    pRxE_y[r,s,t]$(d1RxE_y[r,s,t])                                           "Price of material inputs of domestic origin"
    pRxE_m[r,s,t]$(d1RxE_m[r,s,t])                                           "Price of material inputs of foRxEign origin"
  ;
  $GROUP G_IO_materialsxE_quantities
    qRxE[r_,t]$(tx0[t] and sTot[r_])                                         "Material input in sector s (raw materialsxE and intermediate goods and services)"
    qRxE_pgroup[r,pgroup,t]$(d1RxE_pgroup[r,pgroup,t])                       "Material inputs for product groups in input nests"
    qRxE_ym[r,s,t]$(d1RxE_ym[r,s,t])                                         "Demand for material inputs in sector r from sector s"
    qRxE_y[r,s,t]$(d1RxE_y[r,s,t])                                           "Material input of domestic origin"
    qRxE_m[r,s,t]$(d1RxE_m[r,s,t])                                           "Material input of foRxEign origin"
  ;
  $GROUP G_IO_materialsxE_values
    vRxE[r_,t]$(tx0[t] and ((d1RxE[r_,t] and r[r_]) or sameas[r_,'tot']))    "Value of material inputs (raw materialsxE and intermediate goods and services )"
    vRxE_pgroup[r,pgroup,t]$(d1RxE_pgroup[r,pgroup,t])                       "Value of material inputs for product groups in input nests"
    vRxE_ym[r,s,t]$(d1RxE_ym[r,s,t])                                         "Value of material inputs by sector"
    vRxE_y[r,s,t]$(d1RxE_y[r,s,t])                                           "Value of material inputs of domestic origin"
    vRxE_m[r,s,t]$(d1RxE_m[r,s,t])                                           "Value of material inputs of foRxEign origin"
  ;
  $GROUP G_IO_materialsxE_endo
    G_IO_materialsxE_prices
    G_IO_materialsxE_quantities
    G_IO_materialsxE_values
  ;
  $GROUP G_IO_materialsxE_endo G_IO_materialsxE_endo$(tx0[t]); # Restrict endo group to tx0[t]

  $GROUP G_IO_materialsxE_other

    eRxE(r)         "Elasticity of substitution between sectors in the sectoral demand for materialsxE"

#  E_qRxE_pgroup_nest_fromtop
    eRxE_pgroup[r,pgroup]$(pgroup_top[pgroup] and sum(pgroup_nest, map_pgroup[pgroup,pgroup_nest])) "Elasticity of substitution between product groups in the sectoral demand for materialsxE"
#  E_qRxE_pgroup_nest
    eRxE_pgroup[r,pgroup]$(pgroup_nest[pgroup] and sum(pgroup_nest_a, map_pgroup[pgroup,pgroup_nest_a])) ""
#  E_qRxE_ym
    eRxE_pgroup[r,pgroup]$(pgroup_bot[pgroup] and sum(s, map_s2pgroup[pgroup,s,r])) ""


    eRxE_s[r,s]                                 "Elasticity of substitution between domestic and foRxEign goods in the sectoral demand for materialsxE"
    sRxE_pgroup[r,pgroup,t]$(tx0[t] and d1RxE_pgroup[r,pgroup,t] and (pgroup_top[pgroup] or pgroup_nest[pgroup]))   "CES scale parameters in the sectoral demand for product groups by sector"
    sRxE_ym[r,s,t]$(tx0[t] and d1RxE_ym[r,s,t]) "CES scale parameters in the sectoral demand for materialsxE by sector"
    sRxE_y[r,s,t]$(tx0[t] and d1RxE_y[r,s,t])   "Scale parameter of sectoral demand for domestic materialsxE by sector"
    sRxE_m[r,s,t]$(tx0[t] and d1RxE_m[r,s,t])   "Scale parameter of sectoral demand for foRxEign materialsxE by sector"
  ;


  # ---------------------------------------------------------------------------------------------------------------------
  # Inputs from the financial sector
  # ---------------------------------------------------------------------------------------------------------------------
  $GROUP G_IO_Fin_prices
    # pFin[k,r,t]$(tx0[t] and d1Fin[k,r,t])    "Price of inputs from the financial sector"  # 
    # pFin_y[k,r,t]$(d1Fin_y[k,r,t]) "Price of material inputs from the financial sector of domestic origin"
    # pFin_m[k,r,t]$(d1Fin_m[k,r,t]) "Price of material inputs from the financial sector of foreign origin"
    pFin_k[k,r,t]$(tx0[t] and d1Fin_k[k,r,t]) "Price of inputs from the financial sector"
    pFin[r,t]$(tx0[t] and d1Fin[r,t])     "Aggr. price of inputs from the financial sector"  # 
    pFin_y[r,t]$(d1Fin_y[r,t])            "Price of material inputs from the financial sector of domestic origin"
    pFin_m[r,t]$(d1Fin_m[r,t])            "Price of material inputs from the financial sector of foreign origin"
  ;
  $GROUP G_IO_Fin_quantities
    # qFin_y[k,r,t]$(d1Fin_y[k,r,t]) "Material inputs from the financial sector of domestic origin"
    # qFin_m[k,r,t]$(d1Fin_m[k,r,t]) "Material inputs from the financial sector of foreign origin"
    qFin[r,t]$(d1Fin[r,t])     "Aggr. material of inputs from the financial sector" 
    qFin_y[r,t]$(d1Fin_y[r,t]) "Material inputs from the financial sector of domestic origin"
    qFin_m[r,t]$(d1Fin_m[r,t]) "Material inputs from the financial sector of foreign origin"
    
  ;
  $GROUP G_IO_Fin_values
    # vFin[k,r,t]$(tx0[t] and d1Fin[k,r,t]) ""
    # vFin[k,r,t]$(d1Fin[k,r,t]) "Value of material inputs from the financial sector of domestic origin"
    # vFin_m[k,r,t]$(d1Fin_m[k,r,t]) "Value of material inputs from the financial sector of foreign origin"
    vFin[r,t]$(tx0[t] and d1Fin[r,t]) ""
    vFin_y[r,t]$(d1Fin_y[r,t]) "Value of material inputs from the financial sector of domestic origin"
    vFin_m[r,t]$(d1Fin_m[r,t]) "Value of material inputs from the financial sector of foreign origin"
 ;
  $GROUP G_IO_Fin_endo
    G_IO_Fin_prices
    G_IO_Fin_quantities
    G_IO_Fin_values
  ;
  $GROUP G_IO_Fin_endo G_IO_Fin_endo$(tx0[t]); # Restrict endo group to tx0[t]

  $GROUP G_IO_Fin_other
    # eFin_s[k,r]     "Elasticity of substitution between domestic and foreign goods in the sectoral demand for the financial sector"
    # sFin_y[k,r,t]$(tx0[t] and d1Fin_y[k,r,t])  "Scale parameter of sectoral demand for domestic input from the financial sector"
    # sFin_m[k,r,t]$(tx0[t] and d1Fin_m[k,r,t])  "Scale parameter of sectoral demand for foreign input from the financial sector"
    eFin_s[r]     "Elasticity of substitution between domestic and foreign goods in the sectoral demand for the financial sector"
    sFin_y[r,t]$(tx0[t] and d1Fin_y[r,t])  "Scale parameter of sectoral demand for domestic input from the financial sector"
    sFin_m[r,t]$(tx0[t] and d1Fin_m[r,t])  "Scale parameter of sectoral demand for foreign input from the financial sector"
  ;

  # ---------------------------------------------------------------------------------------------------------------------
  # Private consumption
  # ---------------------------------------------------------------------------------------------------------------------
  $GROUP G_IO_consumption_prices
    pC[c_,t]$(tx0[t] and (c[c_] or sameas[c_,'cTot']))    "CES price index of private consumption by consumption group"
    pC_ym[c,s,t]$(d1C_ym[c,s,t])                          "CES price index of aggregate private consumption by sector"
    pC_y[c,s,t]$(d1C_y[c,s,t])                            "Price of aggregate private consumption by sector of domestic origin"
    pC_m[c,s,t]$(d1C_m[c,s,t])                            "Price of aggregate private consumption by sector of foreign origin"
    pCtourist[c,t]$(tx0[t] and d1CTourist[c,t])           "Price of aggregate private consumption by tourists"    
    pCEPE[purpose,t]$(tx0[t] and d1vCEPE[purpose,t])      "CES-price of energy-good split on purposes, consumers"
  ;
  $GROUP G_IO_consumption_quantities
    qC[c_,t]$(tx0[t] and (c[c_] or sameas[c_,'cTot']))    "Private consumption. Tourist consumption is included in the consumption groups, but NOT in the total"
    qC_ym[c,s,t]$(d1C_ym[c,s,t])                          "Private consumption by sector"
    qC_y[c,s,t]$(d1C_y[c,s,t])                            "Private consumption by sector of domestic origin"
    qC_m[c,s,t]$(d1C_m[c,s,t])                            "Private consumption by sector of foreign origin"
    qCEPE[purpose,t]$(tx0[t] and d1vCEPE[purpose,t])                            "CES-aggregate of energy-good demanded for private consumption"
    qCE[purpose,energy19,t]$(tx0[t] and d1vCE[purpose,energy19,t])              "Quantity of energy-good demanded for private consumption"

  ;
  $GROUP G_IO_consumption_values
    vC[c_,t]$(tx0[t] and (sum(s,d1C_ym[c_,s,t] and c[c_]) or sameas[c_,'cHouEne'] or sameas[c_,'cCarEne'] or sameas[c_,'cTot']))  "Value of private consumption by consumption group"
    vC_ym[c,s,t]$(d1C_ym[c,s,t])                          "Value of private consumption by sector"
    vC_y[c,s,t]$(d1C_y[c,s,t])                            "Value of private consumption by sector of domestic origin"
    vC_m[c,s,t]$(d1C_m[c,s,t])                            "Value of private consumption by sector of foreign origin"
    vCtourist[c,t]$(d1CTourist[c,t])                      "Value of private consumtion by tourists"
    vCE[purpose,energy19,t]$(tx0[t] and d1vCE[purpose,energy19,t])               "Value of energy-good demanded for private consumption"
   
  ;
  $GROUP G_IO_consumption_endo
    G_IO_consumption_prices
    G_IO_consumption_quantities, -qC$(tx0[t] and sameas[c_,'cCar'])
    G_IO_consumption_values
  ;
  $GROUP G_IO_consumption_endo G_IO_consumption_endo$(tx0[t]); # Restrict endo group to tx0[t]

  $GROUP G_IO_consumption_other
    fpCtourist[c,t]$(tx0[t] and d1CTourist[c,t])      "Distributors mark-up on tourist, consumers"
    eC[c_]$(c[c_])                                    "Elasticities of substitution in the public consumption nest"
    eC_s[c,s]                                         "Elasticity of substitution between domestic and foreign goods in private consumption by sector"
    sC_ym[c,s,t]$(tx0[t] and d1C_ym[c,s,t])           "Scale parameter of consumption by sector"
    sC_y[c,s,t]$(tx0[t] and d1C_y[c,s,t])             "Scale parameter of consumption by sector"
    sC_m[c,s,t]$(tx0[t] and d1C_m[c,s,t])             "Scale parameter of consumption by sector"
    
    sCE[purpose,energy19,t]$(tx0[t] and d1vCE[purpose,energy19,t])               "Scale parameter in consumers utility function"
    sCEPE[purpose,t]$(tx0[t] and d1vCEPE[purpose,t])                             "Scale parameter in consumers utility function" 
    eCEPE[purpose]                                                               "Elasticity of substition between energy-goods for the consumer"    
    eCE                                                                          "Elasticity of substition between energy-purposes for the consumer" 
  ;



  # ---------------------------------------------------------------------------------------------------------------------
  # Government consumption
  # ---------------------------------------------------------------------------------------------------------------------
  $GROUP G_IO_government_prices
    pG_y[g,s,t]$(d1G_y[g,s,t])      "Price of public consumption by sector of domestic origin"
    pG_m[g,s,t]$(d1G_m[g,s,t])      "Price of public consumption by sector of foreign origin"
    pG_ym[g,s,t]$(d1G_ym[g,s,t])    "CES price of public consumption by sector"
    pG[g_,t]                        "Total public consumption"
  ;
  $GROUP G_IO_government_quantities
    qG_y[g,s,t]$(d1G_y[g,s,t])      "Public consumption by sector of domestic origin"
    qG_m[g,s,t]$(d1G_m[g,s,t])      "Public consumption by sector of foreign origin"
    qG_ym[g,s,t]$(d1G_ym[g,s,t])    "Public consumption by sector"
  ;
  $GROUP G_IO_government_values
    vG_y[g,s,t]$(d1G_y[g,s,t])      "Value of public consumption by sector of domestic origin"
    vG_m[g,s,t]$(d1G_m[g,s,t])      "Value of public consumption by sector of foreign origin"
    vG_ym[g,s,t]$(d1G_ym[g,s,t])    "Value of public consumption by sector"
    vG[g_,t]                        "Value of public consumption"
  ;
 $GROUP G_IO_government_endo
    G_IO_government_prices
    G_IO_government_quantities
    G_IO_government_values
  ;
  $GROUP G_IO_government_endo G_IO_government_endo$(tx0[t]); # Restrict endo group to tx0[t]

  $GROUP G_IO_government_other
    eg[g_]$(g[g_])                            "Elasticities of substitution in the public consumption nest"
    eG_s[g,s]                                 "Elasticity of substitution between domestic and foreign goods in public consumption by sector"

    sG_ym[g,s,t]$(tx0[t] and d1G_ym[g,s,t])   "Scale parameters of input to public consumption by sector"
    sG_y[g,s,t]$(tx0[t] and d1G_y[g,s,t])     "Scale parameter of domestic to public consumption by sector"
    sG_m[g,s,t]$(tx0[t] and d1G_m[g,s,t])     "Scale parameter of foreign to public consumption by sector"
  ;

$ENDIF 



$IF %stage% == "groupcompilation":
  # ---------------------------------------------------------------------------------------------------------------------
  # Combined IO groups
  # ---------------------------------------------------------------------------------------------------------------------

  $GROUP G_IO_prices
    G_IO_export_prices
    G_IO_materialsxE_prices
    G_IO_Fin_prices
    G_IO_investments_prices
    G_IO_consumption_prices
    G_IO_government_prices
  ;
  $GROUP G_IO_quantities
    G_IO_export_quantities
    G_IO_materialsxE_quantities
    G_IO_Fin_quantities
    G_IO_investments_quantities
    G_IO_consumption_quantities
    G_IO_government_quantities
  ;
  $GROUP G_IO_values
    G_IO_export_values
    G_IO_materialsxE_values
    G_IO_Fin_values
    G_IO_investments_values
    G_IO_consumption_values
    G_IO_government_values
  ;
  $GROUP G_IO_endo
    G_IO_export_endo
    G_IO_materialsxE_endo
    G_IO_Fin_endo
    G_IO_investments_endo
    G_IO_consumption_endo
    G_IO_government_endo
  ;
  $GROUP G_IO_other  
    G_IO_government_other
    G_IO_consumption_other 
    G_IO_materialsxE_other
    G_IO_Fin_other
    G_IO_investments_other
    G_IO_export_other
  ;
  $GROUP G_IO_exo
    G_IO_government_other
    G_IO_consumption_other
    G_IO_materialsxE_other
    G_IO_Fin_other
    G_IO_investments_other
    G_IO_export_other

    ## Export
    # E_pX_y
    pY_CET$(tx0[t] and sameas[out,'out_other'] and sum(x,d1X_y[x,s,t]))
    tX_y$(tx0[t] and d1X_y[x,s,t])
    # E_pX_m
    pM_CET$(tx0[t] and sameas[out,'out_other'] and sum(x,d1X_m[x,s,t]))
    tX_m$(tx0[t] and d1X_m[x,s,t])
    # E_vX_y
    qX_y$(tx0[t] and d1X_y[x,s,t])
    # E_vX_m
    qX_m$(tx0[t] and d1X_m[x,s,t])
    # E_qX_xTur
    pY$(tx0[t] and sameas[s_,'55560'])
    pXF$(tx0[t] and sameas[s,'55560'])
    tX_y$(tx0[t] and sameas[s,'55560'])
    
    ## Investments 
    pI_r$(t0[t] and not sameas[i_,'iTot'])
    pI_r$(t0[t] and sameas[I_,'itot'])

    pI_s$(t0[t] and d1I_s[i_,s,t] and i[i_]) 
    qI_s$(tx0[t] and d1I_s[i_,s,t] and i[i_])

    pI_r$(tx0[t] and not sum(s,d1I_s[I_,s,t])) # We kill stock-investments after data years. Therefore we exogenize summarizing variables if the dummy is non-existent. The dummy is more general than just the case of stock-investments
    vI$(tx0[t] and not sum(s,d1I_s[I_,s,t]))   # We kill stock-investments after data years. Therefore we exogenize summarizing variables if the dummy is non-existent. The dummy is more general than just the case of stock-investments
    qI$(tx0[t] and not sum(s,d1I_s[I_,s,t]))   # We kill stock-investments after data years. Therefore we exogenize summarizing variables if the dummy is non-existent. The dummy is more general than just the case of stock-investments

    qLE$(d1qLE[purpose,energy19,t])
    pLE$(d1vLE[purpose,energy19,t])

    qI_EOPCostAni_actual$(k_[i] and sameas[i,'iM'] and sum(emm, d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]))
    qI_EOPCostplant_actual$(sameas[i,'iM'] and sum(emm, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]))

    tI_m$(tx0[t] and d1I_m[i,s,t])
    tI_y$(tx0[t] and d1I_y[i,s,t])

    qI_s_afforestation$(tx0[t])
    qI_s_afforestation_inst$(tx0[t])
    qI_s_vaadlaeglavbund$(tx0[t]) 

    pY_CET$(tx0[t] and sameas[out,'out_other'] and sum(i,d1I_y[i,s,t]))
    pY_CET$((t0[t] or tx0[t]) and sameas[s,'02000'] and sameas[out,'out_other'])
    pM_CET$(tx0[t] and sameas[out,'out_other'] and sum(i,d1I_m[i,s,t]))
    qLE$(d1vLE[purpose,energy19,t])
    pLE$(t0[t] and d1vLE[purpose,energy19,t])

    ## Non-energy materials 
    pRxE$(t0[t] and d1RxE[r_,t] and not sameas[r_,'rTot'])
    pRxE[r_,t]$(t0[t] and ((d1RxE[r_,t] and r[r_]) or sameas[r_,'tot']))
    qRxE$(tx0[t] and d1RxE[r_,t] and r[r_])
    qRxE$(t0[t] and sTot[r_])
    tRxE_m$(tx0[t] and d1RxE_m[r,s,t])
    tRxE_y$(tx0[t] and d1RxE_y[r,s,t])
    pY_CET$(tx0[t] and sameas[out,'out_other'] and sum(r,d1RxE_y[r,s,t]))
    pM_CET$(tx0[t] and sameas[out,'out_other'] and sum(r,d1RxE_m[r,s,t]))

    # Input from the financial sector
    qFin_k$(tx0[t] and d1Fin_k[k,r,t])
    tFin_m[r,t]$(tx0[t] and d1Fin_m[r,t])
    tFin_y[r,t]$(tx0[t] and d1Fin_y[r,t])
    pY_CET$(tx0[t] and sameas[out,'out_other'] and sameas[s,'64000'])
    pM_CET$(tx0[t] and sameas[out,'out_other'] and sameas[s,'64000'])

    # Private consumption    

    qC$(tx0[t] and sameas[c_,'cCar'])
    pC$(t0[t] and d1C[c_,t] and (c[c_] or sameas[c_,'cTot']))
    pCE$(d1vCE[purpose,energy19,t])
    pCHh$((t0[t] or tx0E[t]) and d1C[c_,t] and c[c_])
    qCHh$(tx0[t] and c[c_])
    qCtourist$(tx0[t] and d1CTourist[c,t])
    pCtourist$(t0[t] and d1CTourist[c,t])
    tC_m$(tx0[t] and d1C_m[c,s,t])
    tC_y$(tx0[t] and d1C_y[c,s,t])
    pY_CET$(tx0[t] and sameas[out,'out_other'] and sum(c,d1C_y[c,s,t]))
    pM_CET$(tx0[t] and sameas[out,'out_other'] and sum(c,d1C_m[c,s,t]))

    ## Government consumption
    qG$(tx0[t])
    tG_m$(tx0[t] and d1G_m[g,s,t])
    tG_y$(tx0[t] and d1G_y[g,s,t])

    tI_m$(tx0[t] and d1I_m[i,s,t])
    tI_y$(tx0[t] and d1I_y[i,s,t])
    tRxE_m$(tx0[t] and d1RxE_m[r,s,t])
    tRxE_y$(tx0[t] and d1RxE_y[r,s,t])
    tX_m$(tx0[t] and d1X_m[x,s,t])
    tX_y$(tx0[t] and (d1X_y[x,s,t] or (sameas[x,'xTur'] and sameas[s,'55560'])))

    pY_CET$(tx0[t] and sameas[out,'out_other'] and sum(g,d1G_y[g,s,t]))
    pM_CET$(tx0[t] and sameas[out,'out_other'] and sum(g,d1G_m[g,s,t]))


    # pY_CET$(tx0[t] and ((sameas[out,'out_other'] and )) or (agri_sectors_s[s] and energy19[out] and sum(energy19, sum(r, mapownproduction(energy19,r,s))))))


    # Pyrolyse
    qI_Pyrolyse_actual[PyrolyseTech,t]$(tx0[t] and sum(tt, d1PyrolysePot[PyrolyseTech,tt])) ""


  ;

$ENDIF

$IF %stage% == "equations":
# ========================================================================================================================
# IO Equations  
# ========================================================================================================================

  # ---------------------------------------------------------------------------------------------------------------------
  # EXPORTS
  # ---------------------------------------------------------------------------------------------------------------------

  $BLOCK B_IO_export

    # Input determined prices
    E_pX_y[x,s,t]$(tx0[t] and d1X_y[x,s,t])..     pX_y[x,s,t]  =E= (1 + tX_y[x,s,t]) * (pWoodproduct_markup[t]$(sameas[s,'02000']) + pY_CET['out_other',s,t]);

    E_pX_m[x,s,t]$(tx0[t] and d1X_m[x,s,t])..     pX_m[x,s,t]  =E= (1 + tX_m[x,s,t]) * pM_CET['out_other',s,t];

    # Values
    E_vX_y[x,s,t] $(tx0[t] and d1X_y[x,s,t])..    vX_y[x,s,t] =E= pX_y[x,s,t] * qX_y[x,s,t];
    E_vX_m[x,s,t] $(tx0[t] and d1X_m[x,s,t])..    vX_m[x,s,t] =E= pX_m[x,s,t] * qX_m[x,s,t];

     # Tourists
    E_vX_xTur[t]$(tx0[t])..  vX['xTur',t] =E= sum(c$(d1CTourist[c,t]), vCtourist[c,t]);
    
        #  E_pX_xTur[t]$(tx0[t])..  pX['xTur',t]*qX['xTur',t] =E= vX['xTur',t];                                      
    
    E_qX_xTur[t]$(tx0[t])..  qX['xTur',t] =E= sX_tur[t] * ( (1+tX_y['xTur','55560',t]) * pY['55560',t] / pXF['55560',t])**eX_tur;

  $ENDBLOCK


  $BLOCK B_IO_investments

     # CES Quantities - top-down split given prices
    E_qI[i,t]$(tx0[t] and k_[i])..                        qI[i,t] * pI_r[i,t-1] =E=   sum(s$d1I_s[i,s,t], (qI_s[i,s,t] 
                                                                                                             + qI_ID_actual[i,s,t]$(sameas(i,'iM') and not sameas(s,'off') and sum((techID,purpose,energy19a,tt), d1thetaID_k[techID,purpose,energy19a,s,t]))
                                                                                                             + qI_CCS_actual[i,s,t]$(sameas(i,'iM') and (sum((techCCS,emm,tt,purpose,energy19), d1thetaCCS[techCCS,purpose,energy19,s,tt,emm]) or sum((techCCS,tt,emm), d1thetaCCSxE[techCCS,s,tt,emm])))
                                                                                                                )* pI_s[i,s,t-1]$(d1I_s[i,s,t-1]))
                                                                                    + sum((ani_sectors,TechAni,Emmtype,animals)$(sum(emm, d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm])), qI_EOPCostAni_actual[i,TechAni,Emmtype,ani_sectors,animals,t]$(sameas(i,'iM')) * pI_s[i,ani_sectors,t-1]$(d1I_s[i,ani_sectors,t-1]))
                                                                                    + sum((plant_sectors,Techplant,Emmtype)$(sum(emm, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm])), qI_EOPCostplant_actual[i,Techplant,Emmtype,plant_sectors,t]$(sameas(i,'iM')) * pI_s[i,plant_sectors,t-1]$(d1I_s[i,plant_sectors,t-1]))
                                                                                    + (sum(PyrolyseTech$(sum(tt, d1PyrolysePot[PyrolyseTech,tt])), qI_Pyrolyse_actual[PyrolyseTech,t])*pI_s['iM','01011',t-1])$(sameas[i,'iM'])
                                                                                    + (pI_r[i,t-1]* qEOPcost[t])$(sameas(i,'iM'))
                                                                                    + (pI_r[i,t-1]*qI_s_vaadlaeglavbund[t])$(sameas[i,'iB'])
                                                                                    ;
                                                                 
    E_qI_ym[i,s,t]$(tx0[t] and d1I_ym[i,s,t] and k_(i)).. qI_ym[i,s,t]     =E= sI_ym[i,s,t] * (pI_r[i,t] / pI_ym[i,s,t])**eI(i)   * qI[i,t];

    E_qI_y[i,s,t]$(tx0[t] and d1I_y[i,s,t] and k_[i])..   qI_y[i,s,t]      =E= sI_y[i,s,t] * (pI_ym[i,s,t] / pI_y[i,s,t])**eI_s[i,s] * qI_ym[i,s,t];

    E_qI_m[i,s,t]$(tx0[t] and d1I_m[i,s,t] and k_[i])..   qI_m[i,s,t]      =E= sI_m[i,s,t] * (pI_ym[i,s,t] / pI_m[i,s,t])**eI_s[i,s] * qI_ym[i,s,t];

    # Quantities for inventory investments
    E_qI_inv[t]$(tx0[t] and sum(s,d1I_s['invt',s,t]))..   qI['invt',t] * pI_r['invt',t-1] =E= sum(s$(d1I_s['invt',s,t]), pI_s['invt',s,t-1]$(d1I_s['invt',s,t-1]) * qI_s['invt',s,t]);

    E_qI_Inv_ym[s,t]$(tx0[t] and d1I_ym['invt',s,t])..    qI_ym['invt',s,t] =E= qI_s['invt',s,t];

    E_qI_Inv_y[s,t]$(tx0[t] and d1I_y['invt',s,t])..      qI_y['invt',s,t]  =E= sI_y['invt',s,t] * qI_ym['invt',s,t];

    E_qI_Inv_m[s,t]$(tx0[t] and d1I_m['invt',s,t])..      qI_m['invt',s,t]  =E= sI_m['invt',s,t] * qI_ym['invt',s,t];

    # Energy 
    E_vLE[purpose,energy19,t]$(tx0[t] and d1vLE[purpose,energy19,t]).. vLE[purpose,energy19,t] =E= pLE[purpose,energy19,t] * qLE[purpose,energy19,t];

    # Input determined prices
    E_pI_y[i,s,t]$(tx0[t] and d1I_y[i,s,t])..    pI_y[i,s,t] =E= (1 + tI_y[i,s,t]) * pY_CET['out_other',s,t];

    E_pI_m[i,s,t]$(tx0[t] and d1I_m[i,s,t])..    pI_m[i,s,t] =E= (1 + tI_m[i,s,t]) * pM_CET['out_other',s,t];

    # Values
    E_vI_y[i,s,t] $(tx0[t] and d1I_y[i,s,t])..   vI_y[i,s,t]     =E= pI_y[i,s,t] * qI_y[i,s,t];
    
    E_vI_m[i,s,t] $(tx0[t] and d1I_m[i,s,t])..   vI_m[i,s,t]     =E= pI_m[i,s,t] * qI_m[i,s,t];

    E_vI_ym[i,s,t] $(tx0[t] and d1I_ym[i,s,t]).. vI_ym[i,s,t]    =E= vI_m[i,s,t]$(d1I_m[i,s,t]) + vI_y[i,s,t]$(d1I_y[i,s,t]);

    E_vI_i_tot[i,t]$(tx0[t])..                   vI[i,t]         =E= sum(s$d1I_ym[i,s,t], vI_ym[i,s,t]);

    E_vI[i,s,t]$(tx0[t] and d1I_s[i,s,t])..      vI_s[i,s,t]     =E= qI_s[i,s,t] * pI_s[i,s,t];


    # Prices for aggregates
    E_pI_ym[i,s,t]$(tx0[t] and d1I_ym[i,s,t])..            pI_ym[i,s,t] * qI_ym[i,s,t] =E= vI_ym[i,s,t];  # Do not divide by qI_ym, as it could be close to zero

    E_pI_i_tot[i,t]$(tx0[t] and sum(s,d1I_s[i,s,t]))..     pI_r[i,t] * qI[i,t] =E= vI[i,t];

    E_pI[i,s,t]$(tx0[t] and d1I_s[i,s,t] and k_[i])..      pI_s[i,s,t] =E= fpI_s[i,s,t] * pI_r[i,t];

    E_pI_inventory[s,t]$(tx0[t] and d1I_s['invt',s,t])..   pI_s['invt',s,t] =E= pI_ym['invt',s,t];

    # Aggregates based on chain-indices
    E_qI_tot_tot[t]$(tx0[t])..  qI['itot',t] * pI_r['itot',t-1] =E= sum(i, pI_r[i,t-1] * qI[i,t]) 
                                                                  + sum((purpose,energy19)$(d1vLE[purpose,energy19,t] and d1vLE[purpose,energy19,t-1]), pLE[purpose,energy19,t-1]*qLE[purpose,energy19,t])
                                                                  + pY_CET['out_other','02000',t-1]*qI_s_afforestation[t]
                                                                  + pY_CET['out_other','02000',t-1]*qI_s_afforestation_inst[t]
                                                                  # £: Her mangler en mængde for
                                                                  ;

    E_vI_tot_tot[t]$(tx0[t])..                     vI['itot',t] =E= sum(i, vI[i,t]) 
                                                                  + sum((purpose,energy19)$(d1vLE[purpose,energy19,t]), vLE[purpose,energy19,t])
                                                                  + pY_CET['out_other','02000',t]*qI_s_afforestation[t]
                                                                  + pY_CET['out_other','02000',t]*qI_s_afforestation_inst[t]
                                                                  #  + vV3[t] - vV3[t-1] # change in value of forrest stock
                                                                  ;

    E_pI_tot_tot[t]$(tx0[t])..    pI_r['itot',t] * qI['itot',t] =E= vI['itot',t];

    E_vI_tot_s[s,t]$(tx0[t])..    vI_s['itot',s,t] =E= sum(i$d1I_s[i,s,t], vI_s[i,s,t]);

  $ENDBLOCK

 
    # ---------------------------------------------------------------------------------------------------------------------
    # Material inputs ([R]aw materials and intermediate goods and services)
    # ---------------------------------------------------------------------------------------------------------------------
    $BLOCK B_IO_materialsxE
     
    # Top-layer nest: CES-split into product groups
    E_qRxE_pgroup_top[r,pgroup_top,t]$(tx0[t] and d1RxE_pgroup[r,pgroup_top,t]).. qRxE_pgroup[r,pgroup_top,t] =E= sRxE_pgroup[r,pgroup_top,t] * (pRxE[r,t]/pRxE_pgroup[r,pgroup_top,t]) ** eRxE[r] * qRxE[r,t]; 

    E_pRxE_pgroup_top[r,pgroup_top,t]$(tx0[t] and d1RxE_pgroup[r,pgroup_top,t]).. pRxE_pgroup[r,pgroup_top,t] * qRxE_pgroup[r,pgroup_top,t] =E= vRxE_pgroup[r,pgroup_top,t];

    E_vRxE_pgroup_top[r,pgroup_top,t]$(tx0[t] and d1RxE_pgroup[r,pgroup_top,t]).. vRxE_pgroup[r,pgroup_top,t] =E= (sum(pgroup_nest$(map_pgroup[pgroup_top,pgroup_nest] and d1RxE_pgroup[r,pgroup_nest,t]), vRxE_pgroup[r,pgroup_nest,t]))#$(sum(pgroup_nest,map_pgroup[pgroup_top,pgroup_nest]))
                                                                                                                  + (sum(s$(map_s2pgroup(pgroup_top,s,r) and d1RxE_ym[r,s,t]), vRxE_ym[r,s,t]))$(not sum(pgroup_nest,map_pgroup[pgroup_top,pgroup_nest]));

    # Middle-layer nests: In here an arbitrary number of nests can be modelled via the mapping map_pgroup. 
    E_qRxE_pgroup_nest_fromtop[r,pgroup_nest,pgroup_top,t]$(tx0[t] and d1RxE_pgroup[r,pgroup_nest,t] and map_pgroup[pgroup_top,pgroup_nest])..# and not map_pgroup[pgroup_nest,pgroup_nest_a])..
      qRxE_pgroup[r,pgroup_nest,t] =E=  sRxE_pgroup[r,pgroup_nest,t] * (pRxE_pgroup[r,pgroup_top,t]/pRxE_pgroup[r,pgroup_nest,t])**eRxE_pgroup[r,pgroup_top] * qRxE_pgroup[r,pgroup_top,t];

    E_qRxE_pgroup_nest[r,pgroup_nest,pgroup_nest_a,t]$(tx0[t] and d1RxE_pgroup[r,pgroup_nest,t] and d1RxE_pgroup[r,pgroup_nest_a,t] and map_pgroup[pgroup_nest,pgroup_nest_a])..
     qRxE_pgroup[r,pgroup_nest_a,t] =E= sRxE_pgroup[r,pgroup_nest_a,t] * (pRxE_pgroup[r,pgroup_nest,t]/pRxE_pgroup[r,pgroup_nest_a,t])**eRxE_pgroup[r,pgroup_nest] * qRxE_pgroup[r,pgroup_nest,t];       

    E_pRxE_pgroup_nest[r,pgroup_nest,t]$(tx0[t] and d1RxE_pgroup[r,pgroup_nest,t])..
      pRxE_pgroup[r,pgroup_nest,t] * qRxE_pgroup[r,pgroup_nest,t] =E= vRxE_pgroup[r,pgroup_nest,t];

    E_vRxE_pgroup_nest[r,pgroup_nest,t]$(tx0[t] and d1RxE_pgroup[r,pgroup_nest,t]).. vRxE_pgroup[r,pgroup_nest,t] =E= sum(s$(map_s2pgroup(pgroup_nest,s,r) and d1RxE_ym[r,s,t]), vRxE_ym[r,s,t]);

    # Bottom-layer nest: CES-split into aggregate import/domestic input supplied from each sector
    E_qRxE_ym[r,pgroup_bot,s,t]$(tx0[t] and d1RxE_ym[r,s,t] and map_s2pgroup[pgroup_bot,s,r])..
      qRxE_ym[r,s,t] =E= sRxE_ym[r,s,t] * (pRxE_pgroup[r,pgroup_bot,t]/pRxE_ym[r,s,t])**eRxE_pgroup[r,pgroup_bot] * qRxE_pgroup[r,pgroup_bot,t];

    E_pRxE_ym[r,s,t]$(tx0[t] and d1RxE_ym[r,s,t]).. pRxE_ym[r,s,t]*qRxE_ym[r,s,t] =E= vRxE_ym[r,s,t];

    E_vRxE_ym[r,s,t]$(tx0[t] and d1RxE_ym[r,s,t]).. vRxE_ym[r,s,t] =E= vRxE_y[r,s,t]$(d1RxE_y[r,s,t]) + vRxE_m[r,s,t]$(d1RxE_m[r,s,t]);

 # CES-split into import and domestic production   
    E_qRxE_y[r,s,t]$(tx0[t] and d1RxE_y[r,s,t])..   qRxE_y[r,s,t]  =E= sRxE_y[r,s,t] * (pRxE_ym[r,s,t] / pRxE_y[r,s,t])**eRxE_s[r,s] * qRxE_ym[r,s,t];
  
    E_qRxE_m[r,s,t]$(tx0[t] and d1RxE_m[r,s,t])..   qRxE_m[r,s,t]  =E= sRxE_m[r,s,t] * (pRxE_ym[r,s,t] / pRxE_m[r,s,t])**eRxE_s[r,s] * qRxE_ym[r,s,t];
   
    # Input determined prices
    E_pRxE_y[r,s,t]$(tx0[t] and d1RxE_y[r,s,t])..   pRxE_y[r,s,t]  =E= (1 + tRxE_y[r,s,t]) * (pY_CET['out_other',s,t] + pWoodproduct_markup[t]$((sameas[r,'16000'] or sameas[r,'13150'] or sameas[r,'41430']) and sameas[s,'02000']));
    
    E_pRxE_m[r,s,t]$(tx0[t] and d1RxE_m[r,s,t])..   pRxE_m[r,s,t]  =E= (1 + tRxE_m[r,s,t]) * pM_CET['out_other',s,t];
  
    # Values
    E_vRxE_y[r,s,t]$(tx0[t] and d1RxE_y[r,s,t])..   vRxE_y[r,s,t]  =E= pRxE_y[r,s,t] * qRxE_y[r,s,t];
 
    E_vRxE_m[r,s,t]$(tx0[t] and d1RxE_m[r,s,t])..   vRxE_m[r,s,t]  =E= pRxE_m[r,s,t] * qRxE_m[r,s,t];
  
    # AggRxEgates price and values
    
    E_vRxE[r,t]$(tx0[t] and d1RxE[r,t])..           vRxE[r,t]      =E= sum(s$d1RxE_ym[r,s,t], vRxE_ym[r,s,t]);

    E_pRxE[r,t]$(tx0[t] and d1RxE[r,t])..           pRxE[r,t]*qRxE[r,t] =E= vRxE[r,t];
  
    # AggRxEgates based on chain-indices
    E_qRxE_tot[t]$tx0[t]..                          pRxE['tot',t-1] * qRxE['tot',t]  =E= sum(r$d1RxE[r,t], pRxE[r,t-1]$(d1RxE[r,t-1]) * qRxE[r,t]);
  
    E_vRxE_tot[t]$(tx0[t])..                        vRxE['tot',t]  =E= sum(r$d1RxE[r,t], vRxE[r,t]);
  
    E_pRxE_tot[t]$(tx0[t])..                        pRxE['tot',t]*qRxE['tot',t] =E= vRxE['tot',t];
  $ENDBLOCK

  # ---------------------------------------------------------------------------------------------------------------------
  # Inputs from the financial sector
  # ---------------------------------------------------------------------------------------------------------------------
  # $BLOCK B_IO_Fin

  #   # CES-split into import and domestic production for the financial sector  
  #   E_qFin_y[k,r,t]$(tx0[t] and d1Fin_y[k,r,t])..   qFin_y[k,r,t]  =E= sFin_y[k,r,t] * (pFin[k,r,t] / pFin_y[k,r,t])**eFin_s[k,r] * qFin[k,r,t];
  
  #   E_qFin_m[k,r,t]$(tx0[t] and d1Fin_m[k,r,t])..   qFin_m[k,r,t]  =E= sFin_m[k,r,t] * (pFin[k,r,t] / pFin_m[k,r,t])**eFin_s[k,r] * qFin[k,r,t];
   
  #   # Input determined prices for the financial sector
  #   E_pFin_y[k,r,t]$(tx0[t] and d1Fin_y[k,r,t])..   pFin_y[k,r,t]  =E= (1 + tFin_y[k,r,t]) * pY_CET['out_other','64000',t];
  
  #   E_pFin_m[k,r,t]$(tx0[t] and d1Fin_m[k,r,t])..   pFin_m[k,r,t]  =E= (1 + tFin_m[k,r,t]) * pM_CET['out_other','64000',t];
  
  #   # Values for the financial sector
  #   E_vFin_y[k,r,t]$(tx0[t] and d1Fin_y[k,r,t])..   vFin_y[k,r,t]  =E= pFin_y[k,r,t] * qFin_y[k,r,t];
 
  #   E_vFin_m[k,r,t]$(tx0[t] and d1Fin_m[k,r,t])..   vFin_m[k,r,t]  =E= pFin_m[k,r,t] * qFin_m[k,r,t];

  #   # Aggregates price and values
  #   E_vFin[k,r,t]$(tx0[t] and d1Fin[k,r,t])..       vFin[k,r,t]      =E= vFin_y[k,r,t]$(d1Fin_y[k,r,t]) + vFin_m[k,r,t]$(d1Fin_m[k,r,t]);

  #   E_pFin[k,r,t]$(tx0[t] and d1Fin[k,r,t])..       pFin[k,r,t]*qFin[k,r,t] =E= vFin[k,r,t];
  # $ENDBLOCK
# ---------------------------------------------------------------------------------------------------------------------
# Inputs from the financial sector (uafhængig af kapitaltype)
# ---------------------------------------------------------------------------------------------------------------------
$BLOCK B_IO_Fin

  # Nye relation - Total demand of financiel services
  E_qFin[r,t]$(tx0[t] and d1Fin[r,t])..           qFin[r,t] =E= sum(k$d1Fin_k[k,r,t], qFin_k[k,r,t]);

  E_pFin_k[k,r,t]$(tx0[t] and d1Fin_k[k,r,t])..   pFin_k[k,r,t] =E= pFin[r,t];

  # Aggr. CES-split into import and domestic production for the financial sector
  E_qFin_y[r,t]$(tx0[t] and d1Fin_y[r,t])..      qFin_y[r,t] =E= sFin_y[r,t] * (pFin[r,t] / pFin_y[r,t])**eFin_s[r] * qFin[r,t];

  E_qFin_m[r,t]$(tx0[t] and d1Fin_m[r,t])..      qFin_m[r,t] =E= sFin_m[r,t] * (pFin[r,t] / pFin_m[r,t])**eFin_s[r] * qFin[r,t];
  # Input determined prices for the financial sector
  E_pFin_y[r,t]$(tx0[t] and d1Fin_y[r,t])..     pFin_y[r,t] =E= (1 + tFin_y[r,t]) * pY_CET['out_other','64000',t];

  E_pFin_m[r,t]$(tx0[t] and d1Fin_m[r,t])..     pFin_m[r,t] =E= (1 + tFin_m[r,t]) * pM_CET['out_other','64000',t];

  # Values for the financial sector
  E_vFin_y[r,t]$(tx0[t] and d1Fin_y[r,t])..     vFin_y[r,t] =E= pFin_y[r,t] * qFin_y[r,t];

  E_vFin_m[r,t]$(tx0[t] and d1Fin_m[r,t])..     vFin_m[r,t] =E= pFin_m[r,t] * qFin_m[r,t];

  # # Aggr. price and values
  E_vFin[r,t]$(tx0[t] and d1Fin[r,t])..         vFin[r,t] =E= vFin_y[r,t]$(d1Fin_y[r,t]) + vFin_m[r,t]$(d1Fin_m[r,t]);

  # E_pFin[r,t]$(tx0[t] and d1Fin[r,t])..         pFin[r,t] * qFin[r,t] =E= vFin[r,t];
  # E_pFin[r,t]$(tx0[t] and d1fin_y[r,t] and d1fin_m[r,t] and d1fin[r,t])..         pFin_y[r,t] * qFin_y[r,t] + pFin_m[r,t] * qFin_m[r,t] =E= vFin[r,t];
  E_pFin[r,t]$(tx0[t] and d1Fin[r,t])..         pFin[r,t] * qFin[r,t] =E= (pFin_y[r,t] * qFin_y[r,t]$(d1Fin_y[r,t])) + (pFin_m[r,t] * qFin_m[r,t]$(d1Fin_m[r,t]));

$ENDBLOCK

  # ---------------------------------------------------------------------------------------------------------------------
  # Private consumption
  # ---------------------------------------------------------------------------------------------------------------------

  $BLOCK B_IO_consumption
    # Consumption is chain-aggregate of household and tourist consumption
    E_qC[c,t]$(tx0[t] and not sameas[c,'cCar']).. qC[c,t] * pC[c,t-1] =E= pCHh[c,t-1] * qCHh[c,t] + pCtourist[c,t-1] * qCtourist[c,t]$(d1CTourist[c,t]);


    # CES Quantities - top-down split
    E_qC_ym[c,s,t]$(tx0[t] and d1C_ym[c,s,t])..        qC_ym[c,s,t]     =E= sC_ym[c,s,t] * (pC[c,t] / pC_ym[c,s,t])**eC[c] * qC[c,t];    

    E_qC_y[c,s,t]$(tx0[t] and d1C_y[c,s,t])..          qC_y[c,s,t]      =E= sC_y[c,s,t] * (pC_ym[c,s,t] / pC_y[c,s,t])**eC_s[c,s] * qC_ym[c,s,t];

    E_qC_m[c,s,t]$(tx0[t] and d1C_m[c,s,t])..          qC_m[c,s,t]      =E= sC_m[c,s,t] * (pC_ym[c,s,t] / pC_m[c,s,t])**eC_s[c,s] * qC_ym[c,s,t];

    # Energy 
    #  E_qCEPE[purpose,t]$(tx0[t] and d1vCEPE[purpose,t]).. qCEPE[purpose,t] =E= sCEPE[purpose,t] * (pC['cENE',t]/pCEPE[purpose,t]) ** eCEPE[purpose] * qC['cENE',t];

    E_qCEPE_Hou[purpose,t]$(tx0[t] and d1vCEPE[purpose,t] and xTrans[purpose]).. qCEPE[purpose,t] =E= sCEPE[purpose,t] * (pC['cHouEne',t]/pCEPE[purpose,t]) ** eCEPE[purpose] * qC['cHouEne',t];

    E_qCEPE_Car[purpose,t]$(tx0[t] and d1vCEPE[purpose,t] and sameas[purpose, 'transport']).. qCEPE[purpose,t] =E= sCEPE[purpose,t] * (pC['cCarEne',t]/pCEPE[purpose,t]) ** eCEPE[purpose] * qC['cCarEne',t];  

    E_pCEPE[purpose,t]$(tx0[t] and d1vCEPE[purpose,t]).. pCEPE[purpose,t] * qCEPE[purpose,t] =E= sum(energy19$d1vCE[purpose,energy19,t], pCE[purpose,energy19,t] * qCE[purpose,energy19,t]);
    
    E_qCE[purpose,energy19,t]$(tx0[t] and d1vCE[purpose,energy19,t]).. qCE[purpose,energy19,t] =E= sCE[purpose,energy19,t] * (pCEPE[purpose,t]/pCE[purpose,energy19,t]) ** eCE * qCEPE[purpose,t];

    E_vCE[purpose,energy19,t]$(tx0[t] and d1vCE[purpose,energy19,t]).. vCE[purpose,energy19,t] =E= pCE[purpose,energy19,t] * qCE[purpose,energy19,t];
   
    # Price is in energy_io block

    # Input determined prices
    E_pC_y[c,s,t]$(tx0[t] and d1C_y[c,s,t])..  pC_y[c,s,t]  =E= (1 + tC_y[c,s,t]) * pY_CET['out_other',s,t];

    E_pC_m[c,s,t]$(tx0[t] and d1C_m[c,s,t])..  pC_m[c,s,t]  =E= (1 + tC_m[c,s,t]) * pM_CET['out_other',s,t];

    # Values
    E_vC_y[c,s,t]$(tx0[t] and d1C_y[c,s,t])..   vC_y[c,s,t]  =E= pC_y[c,s,t] * qC_y[c,s,t];

    E_vC_m[c,s,t]$(tx0[t] and d1C_m[c,s,t])..   vC_m[c,s,t]  =E= pC_m[c,s,t] * qC_m[c,s,t];

    E_vC_ym[c,s,t]$(tx0[t] and d1C_ym[c,s,t]).. vC_ym[c,s,t] =E= vC_y[c,s,t]$(d1C_y[c,s,t]) + vC_m[c,s,t]$(d1C_m[c,s,t]);

    # Energy
    E_vC[c,t]$(tx0[t] and sum(s,d1C_ym[c,s,t]))..     vC[c,t] =E= sum(s$d1C_ym[c,s,t], vC_ym[c,s,t]); 

    #  E_vC_ene[t]$(tx0[t])..                      vC['cENE',t] =E= sum((purpose,energy19)$d1vCE[purpose,energy19,t], vCE[purpose,energy19,t]);

    E_pCtourist[c,t]$(tx0[t] and d1CTourist[c,t]) ..    pCtourist[c,t] =E= fpCtourist[c,t] * pC[c,t]$(d1CTourist[c,t]);
    E_vC_Houene[t]$(tx0[t])..                      vC['cHouEne',t] =E= sum((purpose,energy19)$(d1vCE[purpose,energy19,t] and xTrans[purpose]), vCE[purpose,energy19,t]);
    E_vC_Carene[t]$(tx0[t])..                      vC['cCarEne',t] =E= sum((purpose,energy19)$(d1vCE[purpose,energy19,t] and sameas[purpose, 'transport']), vCE[purpose,energy19,t]);

    E_vCtourist[c,t]$(tx0[t] and d1CTourist[c,t])..     vCtourist[c,t] =E= pCtourist[c,t] * qCtourist[c,t]; 

    # Prices for aggregates
    E_pC_ym[c,s,t]$(tx0[t] and d1C_ym[c,s,t]).. pC_ym[c,s,t] * qC_ym[c,s,t] =E= vC_ym[c,s,t];

    E_pC[c,t]$tx0[t]..                          pC[c,t] * qC[c,t] =E= vC[c,t];

    # Aggregates based on chain-indices
    E_qC_tot[t]$(tx0[t])..  qC['cTot',t] * pC['cTot',t-1] =E= sum(c$d1C[c,t], pC[c,t-1]$(d1C[c,t-1]) * qC[c,t] - (pCtourist[c,t-1] * qCtourist[c,t])$(d1CTourist[c,t]));

    E_vC_tot[t]$(tx0[t])..  vC['cTot',t]  =E= sum(c$d1C[c,t], vC[c,t] - vCtourist[c,t]$(d1CTourist[c,t]));

    E_pC_tot[t]$(tx0[t])..  pC['ctot',t] * qC['ctot',t] =E= vC['ctot',t];
  $ENDBLOCK

  # ---------------------------------------------------------------------------------------------------------------------
  # Government consumption
  # ---------------------------------------------------------------------------------------------------------------------
  $BLOCK B_IO_government
    # CES Quantities - top-down split given prices
    E_qG_ym[g,s,t]$(tx0[t] and d1G_ym[g,s,t]).. qG_ym[g,s,t] =E= sG_ym[g,s,t] * (pG[g,t] / pG_ym[g,s,t])**eG[g]        * qG[g,t]; #sG_ym

    E_qG_y[g,s,t]$(tx0[t] and d1G_y[g,s,t])..   qG_y[g,s,t]  =E= sG_y[g,s,t] * (pG_ym[g,s,t] / pG_y[g,s,t])**eG_s[g,s] * qG_ym[g,s,t]; #sG_y

    E_qG_m[g,s,t]$(tx0[t] and d1G_m[g,s,t])..   qG_m[g,s,t]  =E= sG_m[g,s,t] * (pG_ym[g,s,t] / pG_m[g,s,t])**eG_s[g,s] * qG_ym[g,s,t]; #sG_m

    # Input determined prices
    E_pG_y[g,s,t]$(tx0[t] and d1G_y[g,s,t])..   pG_y[g,s,t]  =E= (1 + tG_y[g,s,t]) * pY_CET['out_other',s,t];  #pG_y

    E_pG_m[g,s,t]$(tx0[t] and d1G_m[g,s,t])..   pG_m[g,s,t]  =E= (1 + tG_m[g,s,t]) * pM_CET['out_other',s,t]; #pG_m

    # Values
    E_vG_y[g,s,t]$(tx0[t] and d1G_y[g,s,t])..   vG_y[g,s,t]  =E= pG_y[g,s,t] * qG_y[g,s,t]; #vG_y

    E_vG_m[g,s,t]$(tx0[t] and d1G_m[g,s,t])..   vG_m[g,s,t]  =E= pG_m[g,s,t] * qG_m[g,s,t]; #vG_m

    E_vG_ym[g,s,t]$(tx0[t] and d1G_ym[g,s,t]).. vG_ym[g,s,t] =E= vG_y[g,s,t]$(d1G_y[g,s,t]) + vG_m[g,s,t]$(d1G_m[g,s,t]); #vG_ym

    E_vG[g,t]$(tx0[t])..                        vG[g,t]      =E= sum(s$d1G_ym[g,s,t], vG_ym[g,s,t]); #vG[g,t]  

    E_vG_dgu[gNest,t]$(d1G[gNest,t] and tx0[t])..     vG[gNest,t]     =E= sum(g_$(d1G[g_,t] and gNest2g_(gNest,g_)), vG[g_,t]); #vG

    # Prices for aggregates
    E_pG_ym[g,s,t]$(tx0[t] and d1G_ym[g,s,t]).. pG_ym[g,s,t]*qG_ym[g,s,t] =E= vG_ym[g,s,t]; #pG_ym

    E_pG[g_,t]$(tx0[t])..                       pG[g_,t]*qG[g_,t]     =E= vG[g_,t]; #pG
 
 $ENDBLOCK

  $MODEL M_IO
    B_IO_export
    B_IO_investments
    B_IO_materialsxE
    B_IO_Fin
    B_IO_consumption
    B_IO_government
  ;
$ENDIF


$IF %stage% == "exogenous_values":
# ========================================================================================================================
# Exogenous variables
# ========================================================================================================================

  # Exports
  eX_tur.l  = 2;

  # Investments
  eI.L(i)         = 0;
  eI_s.l(i,s) = 0.5 * eXF_s[s]; # Rule of a half

  # Materials
  eRxE.L(r)         = 0;
  eRxE_pgroup.l[r,pgroup] = 0;
  
  eRxE_pgroup.l['10011','induspecific_agr'] = 2.75;
  eRxE_pgroup.l['10012','induspecific_agr'] = 2.75;
  eRxE_pgroup.l['10013','induspecific_agr'] = 2.75;
  eRxE_pgroup.l['10030','induspecific_agr'] = 2.75;
  eRxE_pgroup.l['10013','induspecific_agr'] = 2.75;
  eRxE_pgroup.l['10030','induspecific_agr'] = 2.75;
  eRxE_pgroup.l['10040','induspecific_agr'] = 2.75;
  eRxE_pgroup.l['10120','induspecific_agr'] = 2.75;

  eRxE_s.l[r,s] = 0.5 * eXF_s[s];
  eFin_s.l[r] = 0.5 * eXF_s['64000'];
 
  # Consumers (substitution within a group is zero)
  eC.L(c)         = 0;

  #  eC_s.L(c,s)     = 2;
  eC_s.l(c,s)       = 0.5 * eXF_s[s]; # Rule of a half

  # Government demand elasticities
  # This is the elasticity in the consumtion function and is irrelevant atm since there is only one public consumtion good. 
  eG.L(gNest)       = 0.3;
  # This is the elasticity between public consumption and private input - is set close to 1 to ensure that public consumption draws proportionally on public production in value
  eG.L(g)           = 0.9; 
  # This is the elasticity between import and domestic input - is set close to 1 to ensure a clean transition as described above (cannot be 1 due to CES)
  eG_s.L(g,s)       = 1.1;

  # Energy
  eCEPE.l[purpose]  = 0.5;
  eCE.l       = 0.5;

# ========================================================================================================================
# Data assignment
# ========================================================================================================================

  $GROUP G_IO_data  # Variables covered by data
    G_IO_prices
    G_IO_quantities
    G_IO_values

;

  # Read IO data
  $GROUP G_load
    G_IO_data,-qLE,-qCE, -qCEPE, -pXE, -pCE, -pCEPE,-pLE,-pREa,-pREgj,-pXE_base,-pCE_base,-pRE_base,-pRE_base_marg, -pREown,-pLE_base,-vLE, -vCE
   -pI_r, -qI, -vI, -qRxE_pgroup, -pRxE_pgroup, -vRxE_pgroup,-vEAV_CE,-vEAV_RE,-vDAV_CE,-vDAV_RE,-vCAV_CE,-vCAV_RE,-vOtherDistributionProfits_EAV,-vOtherDistributionProfits_DAV,-vOtherDistributionProfits_CAV
   -pEAV_RE,-pEAV_CE,-pDAV_RE,-pDAV_CE,-pCAV_RE,-pCAV_CE, -pfin_k,-qfin_k
  ;
  pM.l[s_,t] = IO_pM[s_,t];
  vX.l[x_,t] = IO_vX[x_,t];
  qCtourist.l[c,t] = IO_qCtourist[c,t];

  $LOOP G_load:
    {name}.l{sets} = IO_{name}{sets};
  $ENDLOOP

  # Data assignment of product groups (input aggregates)
  qRxE_pgroup.l[r,pgroup,t] = sum(s$map_s2pgroup[pgroup,s,r], IO_qRxE_ym[r,s,t]);
  vRxE_pgroup.l[r,pgroup,t] = sum(s$map_s2pgroup[pgroup,s,r], IO_vRxE_ym[r,s,t]);
  pRxE_pgroup.l[r,pgroup,t]$(qRxE_pgroup.l[r,pgroup,t]) = vRxE_pgroup.l[r,pgroup,t] / qRxE_pgroup.l[r,pgroup,t];

  # Investments
  pI_r.l[i_,t] = IO_pI_s[i_,'tot',t];
  qI.l[i_,t]   = IO_qI_s[i_,'tot',t];
  vI.l[i_,t]   = IO_vI_s[i_,'tot',t];

  qLE.l[purpose,energy19,t] = EN_qLE[purpose,energy19,t];
  pLE.l[purpose,energy19,t] = EN_pLE[purpose,energy19,t];
  vLE.l[purpose,energy19,t] = pLE.l[purpose,energy19,t] * qLE.l[purpose,energy19,t];


  qCE.l[purpose,energy19,t] = EN_qCE[purpose,energy19,t];

  vCE.l[purpose,energy19,t] = EN_vnCE[purpose,energy19,t] + EN_vSO2_CE[purpose,energy19,t] + EN_vCO2_CE[purpose,energy19,t] + EN_vEAFG_CE[purpose,energy19,t] + EN_vMOMS_CE[purpose,energy19,t] + EN_vPSO_CE[purpose,energy19,t] + EN_vNOx_CE[purpose,energy19,t] + EN_vEAV_CE[purpose,energy19,t] + EN_vDAV_CE[purpose,energy19,t] + EN_vCAV_CE[purpose,energy19,t];
  pCE.l[purpose,energy19,t]$(vCE.l[purpose,energy19,t]) = vCE.l[purpose,energy19,t]/qCE.l[purpose,energy19,t];

  qCEPE.l[purpose,t] = sum(energy19, qCE.l[purpose,energy19,t]);
  pCEPE.l[purpose,t]$(sum(energy19,qCE.l[purpose,energy19,t])) = sum(energy19, pCE.l[purpose,energy19,t] * qCE.l[purpose,energy19,t])/sum(energy19,qCE.l[purpose,energy19,t]);


parameter min_cell_size;
min_cell_size = 0.00001;
#  min_cell_size = 0.000001;

    d1x_y[x,s,t]  = yes$(abs(vX_y.l[x,s,t]) > min_cell_size);
    d1x_m[x,s,t]  = yes$(abs(vX_m.l[x,s,t]) > min_cell_size);
    d1x_ym[x,s,t]   = d1x_y[x,s,t] or d1x_m[x,s,t];
#    d1x[x,t] = sum(s, d1x_ym[x,s,t]);
    d1x[x,t]    = yes$(abs(vX.l[x,t]) > min_cell_size);

    d1C_y[c,s,t]  = yes$(abs(vC_y.l[c,s,t]) > min_cell_size);
    d1c_m[c,s,t]  = yes$(abs(vC_m.l[c,s,t]) > min_cell_size);
    d1c_ym[c,s,t]   = d1C_y[c,s,t] or d1c_m[c,s,t];
    d1c[c,t]    = sum(s, d1C_ym[c,s,t]);
    # "Hack" - energi is pulled from the normal IO-matrices due to the energi statistic taking over
   # d1c['cENE',t]   =  yes;
    d1c['cHouEne',t] =  yes;
    d1c['cCarEne',t] =  yes;
    d1c['cTot',t]=yes;
    d1CTourist[c,t] = yes$(abs(vCtourist.l[c,t]) > min_cell_size); 

    d1RxE_y[r,s,t]  = yes$(abs(qRxE_y.l[r,s,t]) > min_cell_size);
    d1RxE_m[r,s,t]  = yes$(abs(qRxE_m.l[r,s,t]) > min_cell_size);
    d1RxE_ym[r,s,t] = d1RxE_y[r,s,t] or d1RxE_m[r,s,t];
    d1RxE_pgroup[r,pgroup,t] = yes$(abs(qRxE_pgroup.l[r,pgroup,t]) > min_cell_size);  
    d1RxE[r,t]    = sum(s, d1RxE_ym[r,s,t]);

    d1Fin_y[r,t] = yes$(abs(qFin_y.l[r,t]) > min_cell_size);
    d1Fin_m[r,t] = yes$(abs(qFin_m.l[r,t]) > min_cell_size);
    d1Fin[r,t]   = yes$(d1Fin_y[r,t] or d1Fin_m[r,t]);

    d1G_y[g,s,t] = yes$(abs(vG_y.l[g,s,t]) > min_cell_size);
    d1G_m[g,s,t] = yes$(abs(vG_m.l[g,s,t]) > min_cell_size);
    d1G_ym[g,s,t] = d1G_y[g,s,t] or d1G_m[g,s,t];
    d1G[g,t] = sum(s, d1G_ym[g,s,t]);
    d1G[gNest,t] = yes$sum(g_$(d1G[g_,t] and gNest2g_(gNest,g_)), vG.l[g_,t]);

  d1I_y[i,s,t]    = yes$(abs(qI_y.l[i,s,t]) > min_cell_size);
  d1I_m[i,s,t]    = yes$(abs(qI_m.l[i,s,t]) > min_cell_size);
  d1I_ym[i,s,t]   = d1I_y[i,s,t] or d1I_m[i,s,t];
  d1I_s[i_,s,t]   = yes$(abs(qI_s.l[i_,s,t]) > min_cell_size);

  # Energy 

  # The change in stock for 'straw for energy purposes' must stay (even though not valued) to enter on the energy market. This must be interpreted as the farmers selling their stocks 

  #  d1vLE['unspecified','Straw for energy purposes',t] = yes; #No stock of straws in the latest data (íngen halmlagre i seneste data)
  d1vCEPE[purpose,t]        = yes$(pCEPE.l[purpose,t]);

  d1qLE[purpose,energy19,t] = yes$(EN_qLE[purpose,energy19,t]);
  d1qCE[purpose,energy19,t] = yes$(EN_qCE[purpose,energy19,t]);
  d1qCEPE[purpose,t]        = yes$(qCEPE.l[purpose,t]);
  d1qXE[purpose,energy19,t] = yes$(EN_qXE[purpose,energy19,t]);

  # Dummy for endo/exo efficiency
  d1pY0_CET[energy19,s,t]   = yes$(sum(r,mapownproduction(energy19,r,s)));
$ENDIF

# =====================================================================================================================
# Static calibration
# =====================================================================================================================
$IF %stage% == "static_calibration":
  $GROUP G_IO_static_calibration
     G_IO_endo
     sI_ym$(d1I_ym[i,s,t] and k_[i]),-qI_ym$(k_[i]) 
     sI_y$(d1I_y[i,s,t]),-qI_y 
     sI_m$(d1I_m[i,s,t]),-qI_m 

    sC_ym$(d1C_ym[c,s,t]),-qC_ym 
    sC_y$(d1C_y[c,s,t]),-qC_y 
    sC_m$(d1C_m[c,s,t]),-qC_m 
    fpCtourist$(d1CTourist[c,t]), -pCtourist
  
    sG_ym$(d1G_ym[g,s,t]),-qG_ym 
    sG_y$(d1G_y[g,s,t]),-qG_y 
    sG_m$(d1G_m[g,s,t]),-qG_m 
    
    sRxE_ym$(d1RxE_ym[r,s,t]),-qRxE_ym 
    sRxE_pgroup$(d1RxE_pgroup[r,pgroup,t]),-qRxE_pgroup
    sRxE_y$(d1RxE_y[r,s,t]),-qRxE_y 
    sRxE_m$(d1RxE_m[r,s,t]),-qRxE_m 

    sFin_y$(d1Fin_y[r,t]),-qFin_y 
    sFin_m$(d1Fin_m[r,t]),-qFin_m
    -qFin_k$(d1Fin_k[k,r,t])
   

    -pI_s$(k_[i_] and i[i_]), fpI_s$(k_[i])

    # Energy
    sCE, -qCE
    sCEPE,-qCEPE
    sX_tur , -qX$(sameas[x_,'xTur'])
  ;

    $GROUP G_IO_static_calibration_exo
    G_IO_exo
     qI_ym$(d1I_ym[i,s,t] and k_[i]), -sI_ym$(d1I_ym[i,s,t] and k_[i]) 
     qI_y$(d1I_y[i,s,t]), -sI_y$(d1I_y[i,s,t]) 
     qI_m$(d1I_m[i,s,t]), -sI_m$(d1I_m[i,s,t]) 

     qC_ym$(d1C_ym[c,s,t]), -sC_ym$(d1C_ym[c,s,t]) 
     qC_y$(d1C_y[c,s,t]), -sC_y$(d1C_y[c,s,t]) 
     qC_m$(d1C_m[c,s,t]), -sC_m$(d1C_m[c,s,t]) 
     pCtourist$(d1CTourist[c,t]),-fpCtourist

     qG_ym$(d1G_ym[g,s,t]), -sG_ym$(d1G_ym[g,s,t]) 
     qG_y$(d1G_y[g,s,t]), -sG_y$(d1G_y[g,s,t]) 
     qG_m$(d1G_m[g,s,t]), -sG_m$(d1G_m[g,s,t]) 
 
     qRxE_ym$(d1RxE_ym[r,s,t]), -sRxE_ym$(d1RxE_ym[r,s,t]) 
     qRxE_pgroup$(d1RxE_pgroup[r,pgroup,t]),-sRxE_pgroup$(d1RxE_pgroup[r,pgroup,t])
     qRxE_y$(d1RxE_y[r,s,t]), -sRxE_y$(d1RxE_y[r,s,t]) 
     qRxE_m$(d1RxE_m[r,s,t]), -sRxE_m$(d1RxE_m[r,s,t]) 

     qFin_y$(d1Fin_y[r,t]), -sFin_y$(d1Fin_y[r,t]) 
     qFin_m$(d1Fin_m[r,t]), -sFin_m$(d1Fin_m[r,t])
     qFin_k$(d1Fin_k[k,r,t])


     pI_s$(d1I_s[i_,s,t] and k_[i_] and i[i_]), -fpI_s$(k_[i])
     
     # Energy
     qCE, - sCE
     qCEPE,-sCEPE
     -sX_tur , qX$(sameas[x_,'xTur'])
  ;

  $MODEL M_IO_static_calibration
    M_IO
    # B_IO_Fin
  ;

$ENDIF


# =====================================================================================================================
# Dynamic calibration
# =====================================================================================================================
$IF %stage% == "dynamic_calibration":
  $GROUP G_IO_calib
        G_IO_endo
  ;

  $GROUP G_IO_calib_exo
        G_IO_exo
  ;

  $MODEL M_IO_calib
        M_IO
  ;

$ENDIF
