
#----------------------------------------------------------------------------------------------------------------------
# IO-data (midlertidig placering)
#----------------------------------------------------------------------------------------------------------------------

	set_data_periods(2012,2019);


  #--------------------------------------------------------------------------------------------------------------------
  #  IO-consumption 
  #--------------------------------------------------------------------------------------------------------------------

  PARAMETER #2017-2019, for non-energy 2014-2019
            vCP_y[ns146_r,IO_146_c,t], vCP_m[ns146_r,IO_146_c,t], vCP_a[a_rows,IO_146_c,t]
            vDCP_y[ns146_r,IO_146_c,t], vDCP_m[ns146_r,IO_146_c,t], vDCP_a[a_rows,IO_146_c,t],
            vCPE_y[ns146_r,IO_146_c,t], vCPE_m[ns146_r,IO_146_c,t], vCPE_a[a_rows,IO_146_c,t],
            vDCPE_y[ns146_r,IO_146_c,t], vDCPE_m[ns146_r,IO_146_c,t], vDCPE_a[a_rows,IO_146_c,t],



            #2014-2016
            vCPE_14_16_y[ns142_r,IO_142_c,t], vCPE_14_16_m[ns142_r,IO_142_c,t], vCPE_14_16_a[a_rows,IO_142_c,t],
            vDCPE_14_16_y[ns142_r,IO_142_c,t], vDCPE_14_16_m[ns142_r,IO_142_c,t], vDCPE_14_16_a[a_rows,IO_142_c,t]

            #Customs part of private consumption
            vCP_cus_146[ns146_r,IO_146_c,t], vDCP_cus_146[ns146_r,IO_146_c,t], vCPE_cus_146[ns146_r,IO_146_c,t], vCPE_cus_142_14_16[ns142_r,IO_142_c,t], vCPE_cus_146_14_16[ns146_r,IO_142_c,t]

            #2012-2013
            vCP_12_13_y[ns117_r,IO_117_c,t], vCP_12_13_m[ns117_r,IO_117_c,t], vCP_12_13_a[a_rows,IO_117_c,t]
            vDCP_12_13_y[ns117_r,IO_117_c,t], vDCP_12_13_m[ns117_r,IO_117_c,t], vDCP_12_13_a[a_rows,IO_117_c,t]
            ;

  execute_loaddc "../Data/IOdata/IO_PrivateConsumption.gdx", vCP_y = cp_y.l, vCP_m = cp_m.l, vCP_a = cp_a.l, vDCP_y = dcp_y.l, vDCP_m = dcp_m.l, vDCP_a = dcp_a.l, vCPE_y = cpe_y.l, vCPE_m = cpe_m.l, vCPE_a = cpe_a.l, vDCPE_y = dcpe_y.l, vDCPE_m = dcpe_m.l, vDCPE_a = dcpe_a.l;
  execute_loaddc "../Data/IOdata/IO_PrivateConsumption.gdx", vCPE_14_16_y = cpe_14_16_y.l, vCPE_14_16_m = cpe_14_16_m.l, vCPE_14_16_a = cpe_14_16_a.l, vDCPE_14_16_y = dcpe_14_16_y.l, vDCPE_14_16_m = dcpe_14_16_m.l, vDCPE_14_16_a = dcpe_14_16_a.l;
  execute_loaddc "../Data/IOdata/IO_PrivateConsumption.gdx", vCP_cus_146 = cp_told.l, vDCP_cus_146 = dcp_told.l, vCPE_cus_146 = cpe_told.l, vCPE_cus_146_14_16 = cpe_14_16_told.l;
  execute_loaddc "../Data/IOdata/IO_PrivateConsumption.gdx", vCP_12_13_y = cp_12_13_y.l, vCP_12_13_m = cp_12_13_m.l, vCP_12_13_a = cp_12_13_a.l, vDCP_12_13_y = dcp_12_13_y.l, vDCP_12_13_m = dcp_12_13_m.l, vDCP_12_13_a = dcp_12_13_a.l;

  #GAMS is insisting that "cpe_14_16_told" is defined on 146_r. One can go to the gdx file and see it's clearly not. So we circumvent stupid GAMS by reading into 146-version of it before reading into 142 version with mappingsbelow. Fucking ridiculous
  #By inspecting the matrices we can see the mapping wont cause any issues since there are no energy customs on split sections 142 <-> 146.
  vCPE_cus_142_14_16[ns142_r,IO_142_c,t] = sum(ns146_r$(IO142_2_IO146(ns142_r,ns146_r)), vCPE_cus_146_14_16[ns146_r,IO_142_c,t]);

  #--------------------------------------------------------------------------------------------------------------------
  #  IO-customs  
  #--------------------------------------------------------------------------------------------------------------------

  PARAMETER 
          vIO_cus_146[ns146_r,IO_146_c,t], vDIO_cus_146[ns146_r,IO_146_c,t], vEIO_cus_146[ns146_r,IO_146_c,t], vEIO_cus_142_14_16[ns142_r,IO_142_c,t]
  ;

  execute_loaddc '../Data/IOdata/customs.gdx' vIO_cus_146 = told.l, vDIO_cus_146 = dtold.l, vEIO_cus_146 = tolde.l, vEIO_cus_142_14_16 = tolde_14_16.l;

          #Læser opsplittet privatforbrugstold ind i toldmatricerne 
          vIO_cus_146[ns146_r,nc74ny,t]$(tData[t])            = vCP_cus_146[ns146_r,nc74ny,t];       
          vDIO_cus_146[ns146_r,nc74ny,t]$(tData[t])           = vDIO_cus_146[ns146_r,nc74ny,t];
          vEIO_cus_146[ns146_r,nc74ny,t]$(tData[t])           = vCPE_cus_146[ns146_r,nc74ny,t];
          vEIO_cus_142_14_16[ns142_r,nc74ny_142,t]$(tData[t]) = vCPE_cus_142_14_16[ns142_r,nc74ny_142,t];
          
  #--------------------------------------------------------------------------------------------------------------------
  #  IO-data (2012-2013) (117-sectors)
  #--------------------------------------------------------------------------------------------------------------------
  PARAMETERS
                vIO_y_2012_2013_ns117[ns117_r,IO_117_c,t]         "Production IO 2012-2013"
                vIO_m_2012_2013_ns117[ns117_r,IO_117_c,t]         "Import IO 2012-2013"
                vIO_a_2012_2013_ns117[a_rows,IO_117_c,t]          "Other IO 2012-2013"
  ;
  execute_loaddc "..\Data\IOdata\IOdata_2012_2013.gdx", vIO_y_2012_2013_ns117 = vIO_y_2012_2013.l, vIO_m_2012_2013_ns117 = vIO_m_2012_2013.l, vIO_a_2012_2013_ns117 = vIO_a_2012_2013.l;
  #--------------------------------------------------------------------------------------------------------------------
  #  IO-data (2014-2019)
  #--------------------------------------------------------------------------------------------------------------------
  PARAMETERS
                vIO_y_2014_2019_ns146[ns146_,IO_146_c_,t]         "Production IO 2014-2019"
                vIO_m_2014_2019_ns146[ns146_,IO_146_c_,t]         "Import IO 2014-2019"
                vIO_a_2014_2019_ns146[a_rows,IO_146_c_,t]         "Other IO 2014-2019"
  ;

  execute_loaddc "../Data/IOdata/IOdata.gdx", vIO_y_2014_2019_ns146 = vIO_y.l, vIO_m_2014_2019_ns146 = vIO_m.l, vIO_a_2014_2019_ns146 = vIO_a.l;

  #Læser opsplittet privatforbrug ind i IO-data
                vIO_y_2014_2019_ns146[ns146_r,nc74ny,t] = vCP_y[ns146_r,nc74ny,t];
                vIO_m_2014_2019_ns146[ns146_r,nc74ny,t] = vCP_m[ns146_r,nc74ny,t];
                vIO_a_2014_2019_ns146[a_rows,nc74ny,t]  = vCP_a[a_rows,nc74ny,t];

                #Fjerner søjlen med totalen, nu hvor det er opsplittet.
                vIO_y_2014_2019_ns146[ns146_r,'privatForb',t] = 0;
                vIO_m_2014_2019_ns146[ns146_r,'privatForb',t] = 0;
                vIO_a_2014_2019_ns146[a_rows, 'privatForb',t] = 0;


  #--------------------------------------------------------------------------------------------------------------------
  # DIO-data (2012-2013) (117-sectors)
  #--------------------------------------------------------------------------------------------------------------------
  PARAMETERS
                vDIO_y_2012_2013_ns117[ns117_r,IO_117_c,t]        "Production DIO 2012-2013"
                vDIO_m_2012_2013_ns117[ns117_r,IO_117_c,t]        "Import DIO 2012-2013"
                vDIO_a_2012_2013_ns117[a_rows,IO_117_c,t]         "Other DIO 2012-2013"
  ;
  execute_loaddc "../Data/IOdata/DIOdata_2012_2013.gdx", vDIO_y_2012_2013_ns117 = vDIO_y_2012_2013.l, vDIO_m_2012_2013_ns117 = vDIO_m_2012_2013.l, vDIO_a_2012_2013_ns117 = vDIO_a_2012_2013.l;
  #--------------------------------------------------------------------------------------------------------------------
  # DIO-data (2014-2019)
  #--------------------------------------------------------------------------------------------------------------------
  
  PARAMETERS
                vDIO_y_2014_2019_ns146[ns146_,IO_146_c_,t]         "Production DIO 2014-2019"
                vDIO_m_2014_2019_ns146[ns146_,IO_146_c_,t]         "Import DIO 2014-2019"
                vDIO_a_2014_2019_ns146[a_rows,IO_146_c_,t]         "Other DIO 2014-2019"
  ;

  execute_loaddc "../Data/IOdata/DIOdata.gdx", vDIO_y_2014_2019_ns146 = vDIO_y.l, vDIO_m_2014_2019_ns146 = vDIO_m.l, vDIO_a_2014_2019_ns146 = vDIO_a.l;

  #Læser opsplittet privatforbrug ind i IO-data
                vDIO_y_2014_2019_ns146[ns146_r,nc74ny,t] = vDCP_y[ns146_r,nc74ny,t];
                vDIO_m_2014_2019_ns146[ns146_r,nc74ny,t] = vDCP_m[ns146_r,nc74ny,t];
                vDIO_a_2014_2019_ns146[a_rows,nc74ny,t]  = vDCP_a[a_rows,nc74ny,t];

                vDIO_y_2014_2019_ns146[ns146_r,'privatForb',t] = 0;
                vDIO_m_2014_2019_ns146[ns146_r,'privatForb',t] = 0;
                vDIO_a_2014_2019_ns146[a_rows, 'privatForb',t] = 0;


  #--------------------------------------------------------------------------------------------------------------------
  # Energy IO-data (2014-2016) (142-sectors)
  #--------------------------------------------------------------------------------------------------------------------
  PARAMETERS
                vEIO_y_2014_2016_ns142[ns142_r,IO_142_c,t]        "Production energy IO 2014-2016"
                vEIO_m_2014_2016_ns142[ns142_r,IO_142_c,t]        "Import energy IO 2014-2016"
                vEIO_a_2014_2016_ns142[a_rows,IO_142_c,t]         "Other energy IO 2014-2016"
  ;              

  execute_loaddc "../Data/IOdata/Energi_IOdata.gdx", vEIO_y_2014_2016_ns142 = vEIO_y_2014_2016.l, vEIO_m_2014_2016_ns142 = vEIO_m_2014_2016.l, vEIO_a_2014_2016_ns142 = vEIO_a_2014_2016.l;

  #Læser opsplittet privatforbrug ind i IO-data
                vEIO_y_2014_2016_ns142[ns142_r,nc74ny_142,t] = vCPE_14_16_y[ns142_r,nc74ny_142,t];
                vEIO_m_2014_2016_ns142[ns142_r,nc74ny_142,t] = vCPE_14_16_m[ns142_r,nc74ny_142,t];
                vEIO_a_2014_2016_ns142[a_rows,nc74ny_142,t]  = vCPE_14_16_a[a_rows,nc74ny_142,t];

                vEIO_y_2014_2016_ns142[ns142_r,'privatForb',t] = 0;
                vEIO_m_2014_2016_ns142[ns142_r,'privatForb',t] = 0;
                vEIO_a_2014_2016_ns142[a_rows, 'privatForb',t] = 0;

                #Hack: manglende EIO15 for landbrug
                vEIO_y_2014_2016_ns142[ns142_r,ns142_agr,'2015'] = 0.5 *vEIO_y_2014_2016_ns142[ns142_r,ns142_agr,'2014'] + 0.5 * vEIO_y_2014_2016_ns142[ns142_r,ns142_agr,'2016'];
                vEIO_m_2014_2016_ns142[ns142_r,ns142_agr,'2015'] = 0.5 *vEIO_m_2014_2016_ns142[ns142_r,ns142_agr,'2014'] + 0.5 * vEIO_m_2014_2016_ns142[ns142_r,ns142_agr,'2016'];
                vEIO_a_2014_2016_ns142[a_rows,ns142_agr,'2015']  = 0.5 *vEIO_a_2014_2016_ns142[a_rows,ns142_agr,'2014']  + 0.5 * vEIO_a_2014_2016_ns142[a_rows,ns142_agr,'2016'] ;




  #--------------------------------------------------------------------------------------------------------------------
  # Energy IO-data (2017-2019) (146-sectors)
  #--------------------------------------------------------------------------------------------------------------------
  PARAMETERS
                vEIO_y_2017_2019_ns146[ns146_,IO_146_c_,t]        "Production energy IO 2017-2019"
                vEIO_m_2017_2019_ns146[ns146_,IO_146_c_,t]        "Import energy IO 2017-2019"
                vEIO_a_2017_2019_ns146[a_rows,IO_146_c_,t]         "Other energy IO 2017-2019"
  ;              
  execute_loaddc "../Data/IOdata/Energi_IOdata.gdx", vEIO_y_2017_2019_ns146 = vEIO_y_2017_2019.l, vEIO_m_2017_2019_ns146 = vEIO_m_2017_2019.l, vEIO_a_2017_2019_ns146 = vEIO_a_2017_2019.l;;

  #Læser opsplittet privatforbrug ind i IO-data
                vEIO_y_2017_2019_ns146[ns146_r,nc74ny,t] = vCPE_y[ns146_r,nc74ny,t];
                vEIO_m_2017_2019_ns146[ns146_r,nc74ny,t] = vCPE_m[ns146_r,nc74ny,t];
                vEIO_a_2017_2019_ns146[a_rows,nc74ny,t]  = vCPE_a[a_rows,nc74ny,t];

                vEIO_y_2017_2019_ns146[ns146_r,'privatForb',t] = 0;
                vEIO_m_2017_2019_ns146[ns146_r,'privatForb',t] = 0;
                vEIO_a_2017_2019_ns146[a_rows, 'privatForb',t] = 0;

  #I 2019 laves energiIO-korrektioner for bioethanol og biodiesel                                                                                 #(ENS-pris på bioethanol)
                #Bioethanol
                #  vEIO_m_2017_2019_ns146['190000',ns146,'2019']   = vEIO_m_2017_2019_ns146['190000',ns146,'2019']   
                #       +  sum(brch$ns146_2_brch(ns146,brch), pbioethan2019 * sum(purpose, ANV_qRE.l[purpose,'43',brch,'2019'])); #Heldigvis passer enhederne samme pris i 1000 kroner per GJ og input-data i GJ
                #                                #Formoder det er i 07220 (Benzin og olie til køretøjer) at bioethanol skal hentes 
                #  vEIO_m_2017_2019_ns146['190000','07220','2019'] = vEIO_m_2017_2019_ns146['190000','07220','2019'] 
                #      +  pbioethan2019 * sum(purpose, ANV_qCE.l[purpose,'43','2019']);

                #Vi antager at indkøbet af biodiesel fra engros kommer fra udenlandsk engros 

                #  PARAMETER bioethan2engros, bioethanol_kemi_m, bioethanol_andenfoedevare_m, biodiesel2raff_kemi_y, biodiesel2raff_andenfoedevare_y, biodiesel2raff_kemi_m, biodiesel2raff_andenfoedevare_m;
                #  bioethan2engros = 0.5 * pbioethan2019 * TIL_qE_m.l['43','2019'];
                #  vEIO_m_2017_2019_ns146['460000','460000','2019'] = vEIO_m_2017_2019_ns146['460000','460000','2019'] + bioethan2engros;

                #  #Biodiesel_raff 
                #  vEIO_m_2017_2019_ns146['100050','190000','2019'] = vIO_m_2014_2019_ns146['100050','190000','2019']; #Antager hele cellen er biodiesel eller bioethanol     
                #  vEIO_m_2017_2019_ns146['200010','190000','2019'] = vIO_m_2014_2019_ns146['200010','190000','2019']; #Antager hele cellen er biodiesel eller bioethanol     

                #  bioethanol_andenfoedevare_m      =  0.5 * vIO_m_2014_2019_ns146['100050','190000','2019'];
                #  bioethanol_kemi_m                =  0.5 * vIO_m_2014_2019_ns146['200010','190000','2019'];

                #  biodiesel2raff_andenfoedevare_m =  0.5 * vIO_m_2014_2019_ns146['100050','190000','2019'];
                #  biodiesel2raff_kemi_m           =  0.5 * vIO_m_2014_2019_ns146['200010','190000','2019'];


                #  vEIO_y_2017_2019_ns146['100050','190000','2019'] = vIO_y_2014_2019_ns146['100050','190000','2019'];  
                #  vEIO_y_2017_2019_ns146['200010','190000','2019'] = vIO_y_2014_2019_ns146['200010','190000','2019'];  

                #  biodiesel2raff_andenfoedevare_y = vIO_y_2014_2019_ns146['100050','190000','2019'];
                #  biodiesel2raff_kemi_y = vIO_y_2014_2019_ns146['200010','190000','2019'];

                # £OLD
                #  vEIO_m_2017_2019_ns146['100050','190000','2019'] =      0.2 * 0.5 * pbiodies2019 * TIL_qE_y.l['42','190000','2019']; #20 pct. importeres. Det antages at importen, ligesom for indenlandsk tilgang stammer 50% fra udenlandsk fødevare og 50% fra udenlandsk kemi"
                #  vEIO_m_2017_2019_ns146['200010','190000','2019'] =      0.2 * 0.5 * pbiodies2019 * TIL_qE_y.l['42','190000','2019']; #20 pct. importeres. Det antages at importen, ligesom for indenlandsk tilgang stammer 50% fra udenlandsk fødevare og 50% fra udenlandsk kemi"

                #  vEIO_y_2017_2019_ns146['100050','190000','2019'] = 0.8 * 0.5 * pbiodies2019 * TIL_qE_y.l['42','190000','2019']; 
                #  vEIO_y_2017_2019_ns146['200010','190000','2019'] = 0.8 * 0.5 * pbiodies2019 * TIL_qE_y.l['42','190000','2019']; 


  #--------------------------------------------------------------------------------------------------------------------
  # Energy DIO-data (2014-2016) (142-sectors)
  #--------------------------------------------------------------------------------------------------------------------
  PARAMETERS
                vDEIO_y_2014_2016_ns142[ns142_r,IO_142_c,t]        "Production energy DIO 2014-2016"
                vDEIO_m_2014_2016_ns142[ns142_r,IO_142_c,t]        "Import energy DIO 2014-2016"
                vDEIO_a_2014_2016_ns142[a_rows,IO_142_c,t]         "Other energy DIO 2014-2016"
  ;              
  execute_loaddc "../Data/IOdata/Energi_DIOdata.gdx", vDEIO_y_2014_2016_ns142 = vEDIO_y_2014_2016.l, vDEIO_m_2014_2016_ns142 = vEDIO_m_2014_2016.l, vDEIO_a_2014_2016_ns142 = vEDIO_a_2014_2016.l;

    #Læser opsplittet privatforbrug ind i IO-data
                vDEIO_y_2014_2016_ns142[ns142_r,nc74ny_142,t] = vDCPE_14_16_y[ns142_r,nc74ny_142,t];
                vDEIO_m_2014_2016_ns142[ns142_r,nc74ny_142,t] = vDCPE_14_16_m[ns142_r,nc74ny_142,t];
                vDEIO_a_2014_2016_ns142[a_rows,nc74ny_142,t]  = vDCPE_14_16_a[a_rows,nc74ny_142,t];

                vDEIO_y_2014_2016_ns142[ns142_r,'privatForb',t] = 0;
                vDEIO_m_2014_2016_ns142[ns142_r,'privatForb',t] = 0;
                vDEIO_a_2014_2016_ns142[a_rows, 'privatForb',t] = 0;

                #Hack: manglende EIO15 for landbrug
                vDEIO_y_2014_2016_ns142[ns142_r,ns142_agr,'2015'] = 0.5 *vDEIO_y_2014_2016_ns142[ns142_r,ns142_agr,'2014'] + 0.5 * vDEIO_y_2014_2016_ns142[ns142_r,ns142_agr,'2016'];
                vDEIO_m_2014_2016_ns142[ns142_r,ns142_agr,'2015'] = 0.5 *vDEIO_m_2014_2016_ns142[ns142_r,ns142_agr,'2014'] + 0.5 * vDEIO_m_2014_2016_ns142[ns142_r,ns142_agr,'2016'];
                vDEIO_a_2014_2016_ns142[a_rows,ns142_agr,'2015']  = 0.5 *vDEIO_a_2014_2016_ns142[a_rows,ns142_agr,'2014']  + 0.5 * vDEIO_a_2014_2016_ns142[a_rows,ns142_agr,'2016'] ;


  #--------------------------------------------------------------------------------------------------------------------
  # Energy DIO-data (2017-2019) (146-sectors)
  #--------------------------------------------------------------------------------------------------------------------
  PARAMETERS
                vDEIO_y_2017_2019_ns146[ns146_,IO_146_c_,t]        "Production energy DIO 2017-2019"
                vDEIO_m_2017_2019_ns146[ns146_,IO_146_c_,t]        "Import energy DIO 2017-2019"
                vDEIO_a_2017_2019_ns146[a_rows,IO_146_c_,t]         "Other energy DIO 2017-2019"
  ;
  execute_loaddc "../Data/IOdata/Energi_DIOdata.gdx", vDEIO_y_2017_2019_ns146 = vEDIO_y_2017_2019.l, vDEIO_m_2017_2019_ns146 = vEDIO_m_2017_2019.l, vDEIO_a_2017_2019_ns146 = vEDIO_a_2017_2019.l;;

                #Læser opsplittet privatforbrug ind i IO-data
                vDEIO_y_2017_2019_ns146[ns146_r,nc74ny,t] = vDCPE_y[ns146_r,nc74ny,t];
                vDEIO_m_2017_2019_ns146[ns146_r,nc74ny,t] = vDCPE_m[ns146_r,nc74ny,t];
                vDEIO_a_2017_2019_ns146[a_rows,nc74ny,t]  = vDCPE_a[a_rows,nc74ny,t];

                vDEIO_y_2017_2019_ns146[ns146_r,'privatForb',t] = 0;
                vDEIO_m_2017_2019_ns146[ns146_r,'privatForb',t] = 0;
                vDEIO_a_2017_2019_ns146[a_rows, 'privatForb',t] = 0;


                #  vDEIO_m_2017_2019_ns146['460000','460000','2019']   = vDEIO_m_2017_2019_ns146['460000','460000','2019'] + 0.98*bioethan2engros;

                #  #Biodiesel_raff 
                #  vDEIO_m_2017_2019_ns146['100050','190000','2019'] = vDIO_m_2014_2019_ns146['100050','190000','2019']; #Antager hele cellen er biodiesel eller bioethanol     
                #  vDEIO_m_2017_2019_ns146['200010','190000','2019'] = vDIO_m_2014_2019_ns146['200010','190000','2019']; #Antager hele cellen er biodiesel eller bioethanol     

                #  vDEIO_y_2017_2019_ns146['100050','190000','2019'] = vDIO_y_2014_2019_ns146['100050','190000','2019'];  
                #  vDEIO_y_2017_2019_ns146['200010','190000','2019'] = vDIO_y_2014_2019_ns146['200010','190000','2019'];  


                #OLD
                #Biodiesel og bioethanol
                # (Antager 2% prisstigningstakt - der ganges emed 0.98 - ift. IO)
                #  vDEIO_m_2017_2019_ns146['190000',ns146,'2019']   = vDEIO_m_2017_2019_ns146['190000',ns146,'2019']   +  sum(brch$ns146_2_brch(ns146,brch), pbioethan2019 * 0.98 * sum(purpose, ANV_qRE.l[purpose,'43',brch,'2019'])); #Heldigvis passer enhederne samme pris i 1000 kroner per GJ og input-data i GJ
                #  #                                #Formoder det er i 07220 (Benzin og olie til køretøjer) at bioethanol skal hentes 
                #  vDEIO_m_2017_2019_ns146['190000','07220','2019'] = vDEIO_m_2017_2019_ns146['190000','07220','2019'] +  pbioethan2019 * 0.98 * sum(purpose, ANV_qCE.l[purpose,'43','2019']);

                #Biodiesel_raff
                #  vDEIO_m_2017_2019_ns146['100050','190000','2019'] = 0.2 * 0.5 * pbiodies2019 * 0.98 *  TIL_qE_y.l['42','190000','2019']; #20 pct. importeres. Det antages at importen, ligesom for indenlandsk tilgang stammer 50% fra udenlandsk fødevare og 50% fra udenlandsk kemi"
                #  vDEIO_m_2017_2019_ns146['200010','190000','2019'] = 0.2 * 0.5 * pbiodies2019 * 0.98 * TIL_qE_y.l['42','190000','2019']; #20 pct. importeres. Det antages at importen, ligesom for indenlandsk tilgang stammer 50% fra udenlandsk fødevare og 50% fra udenlandsk kemi"

                #  vDEIO_y_2017_2019_ns146['100050','190000','2019'] = 0.8 * 0.5 * pbiodies2019 * 0.98 * TIL_qE_y.l['42','190000','2019']; 
                #  vDEIO_y_2017_2019_ns146['200010','190000','2019'] = 0.8 * 0.5 * pbiodies2019 * 0.98 * TIL_qE_y.l['42','190000','2019']; 

#--------------------------------------------------------------------------------------------------------------------
#  Produktafgifter og afgifter (2019)
#--------------------------------------------------------------------------------------------------------------------

  PARAMETERS 
    vAfg_146_y[ns146_r,IO_146_c,afgsub,t]
    vAfg_146_m[ns146_r,IO_146_c,afgsub,t]
    vSub_146_y[ns146_r,IO_146_c,afgsub,t]
    vSub_146_m[ns146_r,IO_146_c,afgsub,t]

    vAfg_56_y[s56_,IO_56_c_,afgsub,t]
    vAfg_56_m[s56_,IO_56_c_,afgsub,t]
    vSub_56_y[s56_,IO_56_c_,afgsub,t]
    vSub_56_m[s56_,IO_56_c_,afgsub,t]

    vAfgxE_56_y[s56_,IO_56_c_,afgsub,t]
    vAfgxE_56_m[s56_,IO_56_c_,afgsub,t]
    vSubxE_56_y[s56_,IO_56_c_,afgsub,t]
    vSubxE_56_m[s56_,IO_56_c_,afgsub,t]
  ;

  execute_loaddc '../Data/IOdata/Afgiftslagkage/produktafgifterogsubsidier.gdx' vAfg_146_y = pafgifter_y.l; 
  execute_loaddc '../Data/IOdata/Afgiftslagkage/produktafgifterogsubsidier.gdx' vAfg_146_m = pafgifter_m.l;
  execute_loaddc '../Data/IOdata/Afgiftslagkage/produktafgifterogsubsidier.gdx' vSub_146_y = psubsidier_y.l;
  execute_loaddc '../Data/IOdata/Afgiftslagkage/produktafgifterogsubsidier.gdx' vSub_146_m = psubsidier_m.l;

  #Mapper til 56-brancher
  vAfg_56_y[s56,IO_56_c,afgsub,t]$(tData[t]) = sum((ns146_r,IO_146_c)$(ns146_2_s56(ns146_r,s56) and IO146_2_IOs(IO_146_c,IO_56_c)),     vAfg_146_y[ns146_r,IO_146_c,afgsub,t])/10**6;
  vAfg_56_m[s56,IO_56_c,afgsub,t]$(tData[t]) = sum((ns146_r,IO_146_c)$(ns146_2_s56(ns146_r,s56) and IO146_2_IOs(IO_146_c,IO_56_c)),     vAfg_146_m[ns146_r,IO_146_c,afgsub,t])/10**6;
  vSub_56_y[s56,IO_56_c,afgsub,t]$(tData[t]) = sum((ns146_r,IO_146_c)$(ns146_2_s56(ns146_r,s56) and IO146_2_IOs(IO_146_c,IO_56_c)),     vSub_146_y[ns146_r,IO_146_c,afgsub,t])/10**6;
  vSub_56_m[s56,IO_56_c,afgsub,t]$(tData[t]) = sum((ns146_r,IO_146_c)$(ns146_2_s56(ns146_r,s56) and IO146_2_IOs(IO_146_c,IO_56_c)),     vSub_146_m[ns146_r,IO_146_c,afgsub,t])/10**6; 

  #Laver totaler 
  vAfg_56_y['tot',IO_56_c,afgsub,t]$(tData[t]) = sum(s56, vAfg_56_y[s56,IO_56_c,afgsub,t]);
  vAfg_56_m['tot',IO_56_c,afgsub,t]$(tData[t]) = sum(s56, vAfg_56_m[s56,IO_56_c,afgsub,t]);
  vSub_56_y['tot',IO_56_c,afgsub,t]$(tData[t]) = sum(s56, vSub_56_y[s56,IO_56_c,afgsub,t]);
  vSub_56_m['tot',IO_56_c,afgsub,t]$(tData[t]) = sum(s56, vSub_56_m[s56,IO_56_c,afgsub,t]);

  vAfg_56_y[s56,'tot',afgsub,t]$(tData[t])     = sum(IO_56_c, vAfg_56_y[s56,IO_56_c,afgsub,t]);
  vAfg_56_m[s56,'tot',afgsub,t]$(tData[t])     = sum(IO_56_c, vAfg_56_m[s56,IO_56_c,afgsub,t]);
  vSub_56_y[s56,'tot',afgsub,t]$(tData[t])     = sum(IO_56_c, vSub_56_y[s56,IO_56_c,afgsub,t]);
  vSub_56_m[s56,'tot',afgsub,t]$(tData[t])     = sum(IO_56_c, vSub_56_m[s56,IO_56_c,afgsub,t]);

  #Laver ikke-energi
  vAfgxE_56_y[s56_,IO_56_c_,afgsub,t]$(not afgsub_ene[afgsub] and tData[t]) =  vAfg_56_y[s56_,IO_56_c_,afgsub,t];
  vAfgxE_56_m[s56_,IO_56_c_,afgsub,t]$(not afgsub_ene[afgsub] and tData[t]) =  vAfg_56_m[s56_,IO_56_c_,afgsub,t];
  vSubxE_56_y[s56_,IO_56_c_,afgsub,t]$(not afgsub_ene[afgsub] and tData[t]) =  vSub_56_y[s56_,IO_56_c_,afgsub,t];
  vSubxE_56_m[s56_,IO_56_c_,afgsub,t]$(not afgsub_ene[afgsub] and tData[t]) =  vSub_56_m[s56_,IO_56_c_,afgsub,t];



#--------------------------------------------------------------------------------------------------------------------
#  Produktionsskatter - og subsidier
#--------------------------------------------------------------------------------------------------------------------
  PARAMETERS 
    vpSkatSub_146[art,ns146_r,t]
    vpSkatSub_56[art,s56,t]
  ;

  execute_loaddc '../Data/IOdata/Produktionsskatter og subsidier/produktionsskatter_og_subsidier.gdx' vpSkatSub_146 = produktionsskatter.l; 

  vpSkatSub_56[art,s56,t]$(tData[t]) = sum((ns146_c)$(ns146_2_s56(ns146_c,s56)), vpSkatSub_146[art,ns146_c,t])/10**6;


#--------------------------------------------------------------------------------------------------------------------
#  Kapital og investering
#--------------------------------------------------------------------------------------------------------------------
  PARAMETERS nabk69[vtype,komponent,itype,ns69,t], 
            vIO_I_69[i,ns69,t], vDIO_I_69[i,ns69,t], vIO_K_69[i,ns69,t], vDIO_K_69[i,ns69,t], 
            vIO_Itype_69[itype,ns69,t], vDIO_Itype_69[itype,ns69,t],
            vIO_I_146[i,ns146,t], vDIO_I_146[i,ns146,t], vIO_K_146[i,ns146,t], vDIO_K_146[i,ns146,t], 
            
            vIO_I[i,s56,t], vDIO_I[i,s56,t], vIO_K[i,s56,t], vDIO_K[i,s56,t];
  execute_loaddc '../Data/IOdata/Kapital_og_investering/nabk69.gdx' nabk69 = nabk69.l;
  execute_loaddc '../Data/IOdata/Kapital_og_investering/investments.gdx' vIO_Itype_69 = vIO_I_69.l, vDIO_Itype_69 = vDIO_I_69.l;

  #Vi kunne egentlig få priserne (næsten) direkte fra NABK69, men vi opstiller i samme format som resten af data med forrige års priser først 

  #  vIO_I_69[i,ns69,t]$(tData[t])  = sum(itype$mapitype2i(itype,i), nabk69['v','inv',itype,ns69,t])/1000;
  #  vDIO_I_69[i,ns69,t]$(tData[t]) 
  #                                 = sum(itype$(mapitype2i(itype,i) and nabk69['q','inv',itype,ns69,t-1]), nabk69['v','inv',itype,ns69,t-1]/nabk69['q','inv',itype,ns69,t-1]*nabk69['q','inv',itype,ns69,t])/1000;


  vIO_I_69[i,ns69,t]$(tData[t])  = sum(itype$(mapitype2i(itype,i)), vIO_Itype_69[itype,ns69,t])/10**6;
  vDIO_I_69[i,ns69,t]$(tData[t]) = sum(itype$(mapitype2i(itype,i)), vDIO_Itype_69[itype,ns69,t])/10**6;


  vIO_K_69[i,ns69,t]$(tData[t])  = sum(itype$mapitype2i(itype,i), nabk69['v','kap',itype,ns69,t])/1000;
  vDIO_K_69[i,ns69,t]$(tData[t]) 
                                 = sum(itype$(mapitype2i(itype,i) and nabk69['q','kap',itype,ns69,t-1]), nabk69['v','kap',itype,ns69,t-1]/nabk69['q','kap',itype,ns69,t-1]*nabk69['q','kap',itype,ns69,t])/1000;


  vIO_I_146[i,ns146,t]$(tData[t])  = sum(ns69$ns69_2_ns146(ns69,ns146), vIO_I_69[i,ns69,t]);  
  vDIO_I_146[i,ns146,t]$(tData[t]) = sum(ns69$ns69_2_ns146(ns69,ns146), vDIO_I_69[i,ns69,t]);
  vIO_K_146[i,ns146,t]$(tData[t])  = sum(ns69$ns69_2_ns146(ns69,ns146), vIO_K_69[i,ns69,t]);
  vDIO_K_146[i,ns146,t]$(tData[t]) = sum(ns69$ns69_2_ns146(ns69,ns146), vDIO_K_69[i,ns69,t]);

  #Vi splitter med produktionsværdi 
  PARAMETER sI[ns146,ns69,t];

  sI[ns146,ns69,t]$(sum((ns146_a,IO_146_c)$(ns69_2_ns146(ns69,ns146_a) and not sameas[IO_146_c,'privatForb']), vIO_y_2014_2019_ns146[ns146_a,IO_146_c,t]) and ns69_2_ns146(ns69,ns146)) 
    =
     sum(IO_146_c$(not sameas[IO_146_c,'privatForb']), vIO_y_2014_2019_ns146[ns146,IO_146_c,t])/sum((ns146_a,IO_146_c)$(ns69_2_ns146(ns69,ns146_a) and not sameas[IO_146_c,'privatForb']), vIO_y_2014_2019_ns146[ns146_a,IO_146_c,t]);

  vIO_I[i,s56,t]$(tData[t])  = sum((ns146_r,ns69)$(ns146_2_s56(ns146_r,s56) and ns69_2_ns146(ns69,ns146_r)), sI[ns146_r,ns69,t] * vIO_I_146[i,ns146_r,t]);
  vDIO_I[i,s56,t]$(tData[t]) = sum((ns146_r,ns69)$(ns146_2_s56(ns146_r,s56) and ns69_2_ns146(ns69,ns146_r)), sI[ns146_r,ns69,t] * vDIO_I_146[i,ns146_r,t]);
  vIO_K[i,s56,t]$(tData[t])  = sum((ns146_r,ns69)$(ns146_2_s56(ns146_r,s56) and ns69_2_ns146(ns69,ns146_r)), sI[ns146_r,ns69,t] * vIO_K_146[i,ns146_r,t]);
  vDIO_K[i,s56,t]$(tData[t]) = sum((ns146_r,ns69)$(ns146_2_s56(ns146_r,s56) and ns69_2_ns146(ns69,ns146_r)), sI[ns146_r,ns69,t] * vDIO_K_146[i,ns146_r,t]);





  #--------------------------------------------------------------------------------------------------------------------
  # Mapping of IO-data
  #--------------------------------------------------------------------------------------------------------------------
      PARAMETERS
                vIO_y_2012_2013_ns146[ns146_,IO_146_c_,t]          "Production IO 2012-2013"
                vIO_m_2012_2013_ns146[ns146_,IO_146_c_,t]          "Import IO 2012-2013"
                vIO_a_2012_2013_ns146[a_rows,IO_146_c_,t]           "Other IO 2012-2013"
      ;
    #--------------------------------------------------------------------------------------------------------------------
    #  Mapping from 117-sectors to 146-sectors (2012-2013) 
    #--------------------------------------------------------------------------------------------------------------------
    vIO_y_2012_2013_ns146[ns146_,IO_146_c,t]$(tData[t]) = sum(IO_117_c$(IOns117_2_IOns146(IO_117_c,IO_146_c)), sum(ns117_r$(IOns117_2_IOns146(ns117_r,ns146_)), vIO_y_2012_2013_ns117[ns117_r,IO_117_c,t]));
    vIO_m_2012_2013_ns146[ns146_,IO_146_c,t]$(tData[t]) = sum(IO_117_c$(IOns117_2_IOns146(IO_117_c,IO_146_c)), sum(ns117_r$(IOns117_2_IOns146(ns117_r,ns146_)), vIO_m_2012_2013_ns117[ns117_r,IO_117_c,t]));
    vIO_a_2012_2013_ns146[a_rows,IO_146_c,t]$(tData[t]) = sum(IO_117_c$(IOns117_2_IOns146(IO_117_c,IO_146_c)), vIO_a_2012_2013_ns117[a_rows,IO_117_c,t]);


          #--------------------------------------------------------------------------------------------------------------------
          #  Special mapping for 146-sectors that are split of a 117-sector (2012-2013) - using the 2014-distribution 
          #--------------------------------------------------------------------------------------------------------------------
            # Dummy to check if there are splitted sectors, where there are positive values in 2012 and 2013, but zero value in 2014.  
            # This would be a problem, because we use the distribution in 2014 to split the 2012 and 2013 data. 
            PARAMETER 
                          IO_y_dummy[ns146_,IO_146_c_,t]
                          IO_m_dummy[ns146_,IO_146_c_,t]
                          IO_a_dummy[a_rows,IO_146_c_,t]
            ;
            $FOR1 {s_subset_r},{ss_subset_r} in [('s_010000_r','ss_010000_r'),('s_350010_r','ss_350010_r'),('s_383900_r','ss_383900_r'),('s_490010_r','ss_490010_r'),('s_490020_r','ss_490020_r'),
                                                ('s_490030_r','ss_490030_r'),('s_500000_r','ss_500000_r'),('s_510000_r','ss_510000_r'),('s_520000_r','ss_520000_r'),('s_530000_r','ss_530000_r')]:
              $FOR2 {s_subset_c},{ss_subset_c} in [('s_010000_c','ss_010000_c'),('s_350010_c','ss_350010_c'),('s_383900_c','ss_383900_c'),('s_490010_c','ss_490010_c'),('s_490020_c','ss_490020_c'),
                                                ('s_490030_c','ss_490030_c'),('s_500000_c','ss_500000_c'),('s_510000_c','ss_510000_c'),('s_520000_c','ss_520000_c'),('s_530000_c','ss_530000_c')]:
                IO_y_dummy[{s_subset_r},{s_subset_c},t]$(tData[t]) = yes$(vIO_y_2012_2013_ns146[{s_subset_r},{s_subset_c},t] and (sum(({ss_subset_r},{ss_subset_c}), vIO_y_2014_2019_ns146[{ss_subset_r},{ss_subset_c},'2014']))=0);
                IO_m_dummy[{s_subset_r},{s_subset_c},t]$(tData[t]) = yes$(vIO_m_2012_2013_ns146[{s_subset_r},{s_subset_c},t] and (sum(({ss_subset_r},{ss_subset_c}), vIO_m_2014_2019_ns146[{ss_subset_r},{ss_subset_c},'2014']))=0);
              $ENDFOR2
              IO_y_dummy[{s_subset_r},not_s_subset,t]$(tData[t])   = yes$(vIO_y_2012_2013_ns146[{s_subset_r},not_s_subset,t] and (sum({ss_subset_r}, vIO_y_2014_2019_ns146[{ss_subset_r},not_s_subset,'2014']))=0);
              IO_m_dummy[{s_subset_r},not_s_subset,t]$(tData[t])   = yes$(vIO_m_2012_2013_ns146[{s_subset_r},not_s_subset,t] and (sum({ss_subset_r}, vIO_m_2014_2019_ns146[{ss_subset_r},not_s_subset,'2014']))=0);
              IO_y_dummy[{s_subset_r},not_s_subset_c,t]$(tData[t]) = yes$(vIO_y_2012_2013_ns146[{s_subset_r},not_s_subset_c,t] and (sum({ss_subset_r}, vIO_y_2014_2019_ns146[{ss_subset_r},not_s_subset_c,'2014']))=0);
              IO_m_dummy[{s_subset_r},not_s_subset_c,t]$(tData[t]) = yes$(vIO_m_2012_2013_ns146[{s_subset_r},not_s_subset_c,t] and (sum({ss_subset_r}, vIO_m_2014_2019_ns146[{ss_subset_r},not_s_subset_c,'2014']))=0);
              IO_y_dummy[not_s_subset,{s_subset_r},t]$(tData[t])   = yes$(vIO_y_2012_2013_ns146[not_s_subset,{s_subset_r},t] and (sum({ss_subset_r}, vIO_y_2014_2019_ns146[not_s_subset,{ss_subset_r},'2014']))=0);
              IO_m_dummy[not_s_subset,{s_subset_r},t]$(tData[t])   = yes$(vIO_m_2012_2013_ns146[not_s_subset,{s_subset_r},t] and (sum({ss_subset_r}, vIO_m_2014_2019_ns146[not_s_subset,{ss_subset_r},'2014']))=0);
            $ENDFOR1 

            $FOR {s_subset_c},{ss_subset_c} in [('s_010000_c','ss_010000_c'),('s_350010_c','ss_350010_c'),('s_383900_c','ss_383900_c'),('s_490010_c','ss_490010_c'),('s_490020_c','ss_490020_c'),
                                                ('s_490030_c','ss_490030_c'),('s_500000_c','ss_500000_c'),('s_510000_c','ss_510000_c'),('s_520000_c','ss_520000_c'),('s_530000_c','ss_530000_c')]:
              IO_a_dummy[a_rows,{s_subset_c},t]$(tData[t])         = yes$(vIO_a_2012_2013_ns146[a_rows,{s_subset_c},t] and (sum({ss_subset_c}, vIO_a_2014_2019_ns146[a_rows,{ss_subset_c},'2014']))=0);
            $ENDFOR
            # For example the dummy (IO_y_dummy) shows that for the column-sector '5171' (Forskning og udvikling) there is a positive value for the NR117 row-sector 490010 ('490011', '490012') in   
            # 2012, but there are zero values for the sectors '490011' and '490012' in 2014. This means that we can't use the distribution in 2014 to split the values in 2012 for these sectors.

            #--------------------------------------------------------------------------------------------------------------------
            #  Special mapping for vIO_y_2012_2013 and vIO_m_2012_2013
            #--------------------------------------------------------------------------------------------------------------------
            # First we loop through the row-sectors that are split of a NR117-sector
            $FOR1 {s_subset_r},{ss_subset_r} in [('s_010000_r','ss_010000_r'),('s_350010_r','ss_350010_r'),('s_383900_r','ss_383900_r'),('s_490010_r','ss_490010_r'),('s_490020_r','ss_490020_r'),
                                                ('s_490030_r','ss_490030_r'),('s_500000_r','ss_500000_r'),('s_510000_r','ss_510000_r'),('s_520000_r','ss_520000_r'),('s_530000_r','ss_530000_r')]:
              # Then we loop through the column-sectors that are split of a NR117-sector
              $FOR2 {s_subset_c},{ss_subset_c} in [('s_010000_c','ss_010000_c'),('s_350010_c','ss_350010_c'),('s_383900_c','ss_383900_c'),('s_490010_c','ss_490010_c'),('s_490020_c','ss_490020_c'),
                                                ('s_490030_c','ss_490030_c'),('s_500000_c','ss_500000_c'),('s_510000_c','ss_510000_c'),('s_520000_c','ss_520000_c'),('s_530000_c','ss_530000_c')]:
                # For each combination of a split row-sector and a split column-sector, the value is calculated
                vIO_y_2012_2013_ns146[{s_subset_r},{s_subset_c},t]$(tData[t] and not IO_y_dummy[{s_subset_r},{s_subset_c},t])=vIO_y_2012_2013_ns146[{s_subset_r},{s_subset_c},t]*(vIO_y_2014_2019_ns146[{s_subset_r},{s_subset_c},'2014']/(sum(({ss_subset_r},{ss_subset_c}), vIO_y_2014_2019_ns146[{ss_subset_r},{ss_subset_c},'2014'])));
                vIO_m_2012_2013_ns146[{s_subset_r},{s_subset_c},t]$(tData[t] and not IO_m_dummy[{s_subset_r},{s_subset_c},t])=vIO_m_2012_2013_ns146[{s_subset_r},{s_subset_c},t]*(vIO_m_2014_2019_ns146[{s_subset_r},{s_subset_c},'2014']/(sum(({ss_subset_r},{ss_subset_c}), vIO_m_2014_2019_ns146[{ss_subset_r},{ss_subset_c},'2014'])));
                # We manually split the IO for the sectors where we can't use the distribution in 2014
                vIO_y_2012_2013_ns146[{s_subset_r},{s_subset_c},t]$(tData[t] and IO_y_dummy[{s_subset_r},{s_subset_c},t])=vIO_y_2012_2013_ns146[{s_subset_r},{s_subset_c},t]/(CARD({s_subset_r})*CARD({s_subset_c}));
                vIO_m_2012_2013_ns146[{s_subset_r},{s_subset_c},t]$(tData[t] and IO_m_dummy[{s_subset_r},{s_subset_c},t])=vIO_m_2012_2013_ns146[{s_subset_r},{s_subset_c},t]/(CARD({s_subset_r})*CARD({s_subset_c}));
              $ENDFOR2
            # For each combination of a split row-sector and a non-split column-sector, the value is calculated 
            vIO_y_2012_2013_ns146[{s_subset_r},not_s_subset,t]$(tData[t] and not IO_y_dummy[{s_subset_r},not_s_subset,t])=vIO_y_2012_2013_ns146[{s_subset_r},not_s_subset,t]*(vIO_y_2014_2019_ns146[{s_subset_r},not_s_subset,'2014']/(sum({ss_subset_r}, vIO_y_2014_2019_ns146[{ss_subset_r},not_s_subset,'2014'])));
            vIO_m_2012_2013_ns146[{s_subset_r},not_s_subset,t]$(tData[t] and not IO_m_dummy[{s_subset_r},not_s_subset,t])=vIO_m_2012_2013_ns146[{s_subset_r},not_s_subset,t]*(vIO_m_2014_2019_ns146[{s_subset_r},not_s_subset,'2014']/(sum({ss_subset_r}, vIO_m_2014_2019_ns146[{ss_subset_r},not_s_subset,'2014'])))$(sum({ss_subset_r}, vIO_m_2014_2019_ns146[{ss_subset_r},not_s_subset,'2014']));
            vIO_y_2012_2013_ns146[{s_subset_r},not_s_subset_c,t]$(tData[t] and not IO_y_dummy[{s_subset_r},not_s_subset_c,t])=vIO_y_2012_2013_ns146[{s_subset_r},not_s_subset_c,t]*(vIO_y_2014_2019_ns146[{s_subset_r},not_s_subset_c,'2014']/(sum({ss_subset_r}, vIO_y_2014_2019_ns146[{ss_subset_r},not_s_subset_c,'2014'])))$(sum({ss_subset_r}, vIO_y_2014_2019_ns146[{ss_subset_r},not_s_subset_c,'2014']));
            vIO_m_2012_2013_ns146[{s_subset_r},not_s_subset_c,t]$(tData[t] and not IO_m_dummy[{s_subset_r},not_s_subset_c,t])=vIO_m_2012_2013_ns146[{s_subset_r},not_s_subset_c,t]*(vIO_m_2014_2019_ns146[{s_subset_r},not_s_subset_c,'2014']/(sum({ss_subset_r}, vIO_m_2014_2019_ns146[{ss_subset_r},not_s_subset_c,'2014'])))$(sum({ss_subset_r}, vIO_m_2014_2019_ns146[{ss_subset_r},not_s_subset_c,'2014']));
            # We manually split the IO for the sectors where we can't use the distribution in 2014
            vIO_y_2012_2013_ns146[{s_subset_r},not_s_subset,t]$(tData[t] and IO_y_dummy[{s_subset_r},not_s_subset,t])=vIO_y_2012_2013_ns146[{s_subset_r},not_s_subset,t]/CARD({s_subset_r});
            vIO_m_2012_2013_ns146[{s_subset_r},not_s_subset,t]$(tData[t] and IO_m_dummy[{s_subset_r},not_s_subset,t])=vIO_m_2012_2013_ns146[{s_subset_r},not_s_subset,t]/CARD({s_subset_r});
            vIO_y_2012_2013_ns146[{s_subset_r},not_s_subset_c,t]$(tData[t] and IO_y_dummy[{s_subset_r},not_s_subset_c,t])=vIO_y_2012_2013_ns146[{s_subset_r},not_s_subset_c,t]/CARD({s_subset_r});
            vIO_m_2012_2013_ns146[{s_subset_r},not_s_subset_c,t]$(tData[t] and IO_m_dummy[{s_subset_r},not_s_subset_c,t])=vIO_m_2012_2013_ns146[{s_subset_r},not_s_subset_c,t]/CARD({s_subset_r});
            $ENDFOR1
            # For each combination of a non-split row-sector and a split column-sector, the value is calculated
            $FOR {s_subset_c},{ss_subset_c} in [('s_010000_c','ss_010000_c'),('s_350010_c','ss_350010_c'),('s_383900_c','ss_383900_c'),('s_490010_c','ss_490010_c'),('s_490020_c','ss_490020_c'),
                                                ('s_490030_c','ss_490030_c'),('s_500000_c','ss_500000_c'),('s_510000_c','ss_510000_c'),('s_520000_c','ss_520000_c'),('s_530000_c','ss_530000_c')]:
                vIO_y_2012_2013_ns146[not_s_subset,{s_subset_c},t]$(tData[t] and not IO_y_dummy[not_s_subset,{s_subset_c},t])=vIO_y_2012_2013_ns146[not_s_subset,{s_subset_c},t]*(vIO_y_2014_2019_ns146[not_s_subset,{s_subset_c},'2014']/(sum({ss_subset_c}, vIO_y_2014_2019_ns146[not_s_subset,{ss_subset_c},'2014'])))$(sum({ss_subset_c}, vIO_y_2014_2019_ns146[not_s_subset,{ss_subset_c},'2014']));
                vIO_m_2012_2013_ns146[not_s_subset,{s_subset_c},t]$(tData[t] and not IO_m_dummy[not_s_subset,{s_subset_c},t])=vIO_m_2012_2013_ns146[not_s_subset,{s_subset_c},t]*(vIO_m_2014_2019_ns146[not_s_subset,{s_subset_c},'2014']/(sum({ss_subset_c}, vIO_m_2014_2019_ns146[not_s_subset,{ss_subset_c},'2014'])))$(sum({ss_subset_c}, vIO_m_2014_2019_ns146[not_s_subset,{ss_subset_c},'2014']));
              vIO_y_2012_2013_ns146[not_s_subset,{s_subset_c},t]$(tData[t] and IO_y_dummy[not_s_subset,{s_subset_c},t])=vIO_y_2012_2013_ns146[not_s_subset,{s_subset_c},t]/CARD({s_subset_c});
            vIO_m_2012_2013_ns146[not_s_subset,{s_subset_c},t]$(tData[t] and IO_m_dummy[not_s_subset,{s_subset_c},t])=vIO_m_2012_2013_ns146[not_s_subset,{s_subset_c},t]/CARD({s_subset_c});
            $ENDFOR

            #--------------------------------------------------------------------------------------------------------------------
            #  Special mapping for vIO_a_2012_2013
            #--------------------------------------------------------------------------------------------------------------------
            $FOR {s_subset_c},{ss_subset_c} in [('s_010000_c','ss_010000_c'),('s_350010_c','ss_350010_c'),('s_383900_c','ss_383900_c'),('s_490010_c','ss_490010_c'),('s_490020_c','ss_490020_c'),
                                                ('s_490030_c','ss_490030_c'),('s_500000_c','ss_500000_c'),('s_510000_c','ss_510000_c'),('s_520000_c','ss_520000_c'),('s_530000_c','ss_530000_c')]:
              vIO_a_2012_2013_ns146[a_rows,{s_subset_c},t]$(not IO_a_dummy[a_rows,{s_subset_c},t]) = vIO_a_2012_2013_ns146[a_rows,{s_subset_c},t]*(vIO_a_2014_2019_ns146[a_rows,{s_subset_c},'2014']/sum({ss_subset_c},vIO_a_2014_2019_ns146[a_rows,{ss_subset_c},'2014']))$(sum({ss_subset_c},vIO_a_2014_2019_ns146[a_rows,{ss_subset_c},'2014']));
              # We manually split the IO for the sectors where we can't use the distribution in 2014
              vIO_a_2012_2013_ns146[a_rows,{s_subset_c},t]$(IO_a_dummy[a_rows,{s_subset_c},t]) = vIO_a_2012_2013_ns146[a_rows,{s_subset_c},t]/CARD({s_subset_c});
            $ENDFOR

          #--------------------------------------------------------------------------------------------------------------------
          #  Merging the 2012-2013 146-sector data with the 2014-2019 146-sector data 
          #--------------------------------------------------------------------------------------------------------------------
          vIO_y_2014_2019_ns146[ns146_r,IO_146_c,'2012'] = vIO_y_2012_2013_ns146[ns146_r,IO_146_c,'2012'];
          vIO_y_2014_2019_ns146[ns146_r,IO_146_c,'2013'] = vIO_y_2012_2013_ns146[ns146_r,IO_146_c,'2013'];
          vIO_m_2014_2019_ns146[ns146_r,IO_146_c,'2012'] = vIO_m_2012_2013_ns146[ns146_r,IO_146_c,'2012'];
          vIO_m_2014_2019_ns146[ns146_r,IO_146_c,'2013'] = vIO_m_2012_2013_ns146[ns146_r,IO_146_c,'2013'];  
          vIO_a_2014_2019_ns146[a_rows,IO_146_c,'2012']  = vIO_a_2012_2013_ns146[a_rows,IO_146_c,'2012'];
          vIO_a_2014_2019_ns146[a_rows,IO_146_c,'2013']  = vIO_a_2012_2013_ns146[a_rows,IO_146_c,'2013'];

          #--------------------------------------------------------------------------------------------------------------------
          # Mapping from 146-sectors to 56-model sectors 
          #--------------------------------------------------------------------------------------------------------------------
          $PGROUP G_IO
                vIO_y[s56_,IO_56_c_,t]                         "Production IO 2012-2019"
                vIO_m[s56_,IO_56_c_,t]                         "Import IO 2012-2019"
                vIO_a[a_rows_,IO_56_c_,t]                      "Other IO 2012-2019"
                vIO_cus[s56_,IO_56_c_,t]                       "Customs 2014-2019"

                IO_vC_y_2012_2013[ns117_r,c56,t]               "Consumption IO 2012-2013"
                IO_vC_m_2012_2013[ns117_r,c56,t]               "Import consumption IO 2012-2013"
                IO_vC_a_2012_2013[a_rows,c56,t]                "Other consumption IO 2012-2013"
            ; 

          vIO_y[s56,IO_56_c,t]$(tData[t])     = sum((ns146_r,IO_146_c)$(ns146_2_s56(ns146_r,s56) and IO146_2_IOs(IO_146_c,IO_56_c)), vIO_y_2014_2019_ns146[ns146_r,IO_146_c,t])/10**6;                            
          vIO_m[s56,IO_56_c,t]$(tData[t])     = sum((ns146_r,IO_146_c)$(ns146_2_s56(ns146_r,s56) and IO146_2_IOs(IO_146_c,IO_56_c)), vIO_m_2014_2019_ns146[ns146_r,IO_146_c,t])/10**6;                   
          vIO_a[a_rows,IO_56_c,t]$(tData[t])  = sum(IO_146_c$(IO146_2_IOs(IO_146_c,IO_56_c)), vIO_a_2014_2019_ns146[a_rows,IO_146_c,t])/10**6;  

          # Mapping of consumption for 2012-2013 (note: rows are 117-sectors and not 146-sectors)
          IO_vC_y_2012_2013[ns117_r,c56,t]      = sum(nc74_117$(nc74_117_2_c56[nc74_117,c56]), vCP_12_13_y[ns117_r,nc74_117,t])/10**6;
        	IO_vC_y_2012_2013[ns117_r,'cSer',t]   = IO_vC_y_2012_2013[ns117_r,'cSer',t] + vIO_y_2012_2013_ns117[ns117_r,'NPISH',t]/10**6; #Tilføjer NPISH til services
          IO_vC_m_2012_2013[ns117_r,c56,t]      = sum(nc74_117$(nc74_117_2_c56[nc74_117,c56]), vCP_12_13_m[ns117_r,nc74_117,t])/10**6;
      	    IO_vC_m_2012_2013[ns117_r,'cSer',t]   = IO_vC_m_2012_2013[ns117_r,'cSer',t] + vIO_m_2012_2013_ns117[ns117_r,'NPISH',t]/10**6; #Tilføjer NPISH til services

          IO_vC_a_2012_2013[a_rows,c56,t]       = sum(nc74_117$(nc74_117_2_c56[nc74_117,c56]), vCP_12_13_a[a_rows,nc74_117,t])/10**6;
	        IO_vC_a_2012_2013[a_rows,'cSer',t]   = IO_vC_a_2012_2013[a_rows,'cSer',t] + vIO_a_2012_2013_ns117[a_rows,'NPISH',t]/10**6; #Tilføjer NPISH til services

          # Totaler 
          vIO_y['tot',IO_56_c,t]$(tData[t])   = sum(s56, vIO_y[s56,IO_56_c,t]);
          vIO_m['tot',IO_56_c,t]$(tData[t])   = sum(s56, vIO_m[s56,IO_56_c,t]);
          vIO_cus['tot',IO_56_c,t]$(tData[t]) = sum(s56, vIO_cus[s56,IO_56_c,t]);


          vIO_y[s56,'tot',t]$(tData[t])       = sum(IO_56_c, vIO_y[s56,IO_56_c,t]);
          vIO_m[s56,'tot',t]$(tData[t])       = sum(IO_56_c, vIO_m[s56,IO_56_c,t]);
          vIO_a[a_rows,'tot',t]$(tData[t])    = sum(IO_56_c, vIO_a[a_rows,IO_56_c,t]);
          vIO_cus[s56,'tot',t]$(tData[t])     = sum(IO_56_c, vIO_cus[s56,IO_56_c,t]);


        #--------------------------------------------------------------------------------------------------------------------
        # Mapping of DIO-data
        #--------------------------------------------------------------------------------------------------------------------
            PARAMETERS
                        vDIO_y_2012_2013_ns146[ns146_,IO_146_c_,t]              "Production DIO 2012-2013"
                        vDIO_m_2012_2013_ns146[ns146_,IO_146_c_,t]              "Import DIO 2012-2013"
                        vDIO_a_2012_2013_ns146[a_rows,IO_146_c_,t]               "Other DIO 2012-2013"
          ;
          #--------------------------------------------------------------------------------------------------------------------
          #  Mapping from 117-sectors to 146-sectors (2012-2013) 
          #--------------------------------------------------------------------------------------------------------------------
          vDIO_y_2012_2013_ns146[ns146_r,IO_146_c,t]$(tData[t]) = sum(IO_117_c$(IOns117_2_IOns146(IO_117_c,IO_146_c)), sum(ns117_r$(IOns117_2_IOns146(ns117_r,ns146_r)), vDIO_y_2012_2013_ns117[ns117_r,IO_117_c,t]));
          vDIO_m_2012_2013_ns146[ns146_r,IO_146_c,t]$(tData[t]) = sum(IO_117_c$(IOns117_2_IOns146(IO_117_c,IO_146_c)), sum(ns117_r$(IOns117_2_IOns146(ns117_r,ns146_r)), vDIO_m_2012_2013_ns117[ns117_r,IO_117_c,t]));
          vDIO_a_2012_2013_ns146[a_rows,IO_146_c,t]$(tData[t])  = sum(IO_117_c$(IOns117_2_IOns146(IO_117_c,IO_146_c)), vDIO_a_2012_2013_ns117[a_rows,IO_117_c,t]);

          #--------------------------------------------------------------------------------------------------------------------
          #  Special mapping for 146-sectors that are split of a 117-sector (2012-2013) - using the 2014-distribution 
          #--------------------------------------------------------------------------------------------------------------------
            # Dummy to check if there are splitted sectors, where there are positive values in 2012 and 2013, but zero value in 2014.  
            # This would be a problem, because we use the distribution in 2014 to split the 2012 and 2013 data. 
            PARAMETER 
                          DIO_y_dummy[ns146_,IO_146_c_,t]
                          DIO_m_dummy[ns146_,IO_146_c_,t]
                          DIO_a_dummy[a_rows,IO_146_c_,t]
            ;
            $FOR1 {s_subset_r},{ss_subset_r} in [('s_010000_r','ss_010000_r'),('s_350010_r','ss_350010_r'),('s_383900_r','ss_383900_r'),('s_490010_r','ss_490010_r'),('s_490020_r','ss_490020_r'),
                                                ('s_490030_r','ss_490030_r'),('s_500000_r','ss_500000_r'),('s_510000_r','ss_510000_r'),('s_520000_r','ss_520000_r'),('s_530000_r','ss_530000_r')]:
              $FOR2 {s_subset_c},{ss_subset_c} in [('s_010000_c','ss_010000_c'),('s_350010_c','ss_350010_c'),('s_383900_c','ss_383900_c'),('s_490010_c','ss_490010_c'),('s_490020_c','ss_490020_c'),
                                                ('s_490030_c','ss_490030_c'),('s_500000_c','ss_500000_c'),('s_510000_c','ss_510000_c'),('s_520000_c','ss_520000_c'),('s_530000_c','ss_530000_c')]:
                DIO_y_dummy[{s_subset_r},{s_subset_c},t]$(tData[t]) = yes$(vDIO_y_2012_2013_ns146[{s_subset_r},{s_subset_c},t] and (sum(({ss_subset_r},{ss_subset_c}), vDIO_y_2014_2019_ns146[{ss_subset_r},{ss_subset_c},'2014']))=0);
                DIO_m_dummy[{s_subset_r},{s_subset_c},t]$(tData[t]) = yes$(vDIO_m_2012_2013_ns146[{s_subset_r},{s_subset_c},t] and (sum(({ss_subset_r},{ss_subset_c}), vDIO_m_2014_2019_ns146[{ss_subset_r},{ss_subset_c},'2014']))=0);
              $ENDFOR2
              DIO_y_dummy[{s_subset_r},not_s_subset,t]$(tData[t]) = yes$(vDIO_y_2012_2013_ns146[{s_subset_r},not_s_subset,t] and (sum({ss_subset_r}, vDIO_y_2014_2019_ns146[{ss_subset_r},not_s_subset,'2014']))=0);
              DIO_m_dummy[{s_subset_r},not_s_subset,t]$(tData[t]) = yes$(vDIO_m_2012_2013_ns146[{s_subset_r},not_s_subset,t] and (sum({ss_subset_r}, vDIO_m_2014_2019_ns146[{ss_subset_r},not_s_subset,'2014']))=0);
              DIO_y_dummy[{s_subset_r},not_s_subset_c,t]$(tData[t]) = yes$(vDIO_y_2012_2013_ns146[{s_subset_r},not_s_subset_c,t] and (sum({ss_subset_r}, vDIO_y_2014_2019_ns146[{ss_subset_r},not_s_subset_c,'2014']))=0);
              DIO_m_dummy[{s_subset_r},not_s_subset_c,t]$(tData[t]) = yes$(vDIO_m_2012_2013_ns146[{s_subset_r},not_s_subset_c,t] and (sum({ss_subset_r}, vDIO_m_2014_2019_ns146[{ss_subset_r},not_s_subset_c,'2014']))=0);
              DIO_y_dummy[not_s_subset,{s_subset_r},t]$(tData[t])   = yes$(vDIO_y_2012_2013_ns146[not_s_subset,{s_subset_r},t] and (sum({ss_subset_r}, vDIO_y_2014_2019_ns146[not_s_subset,{ss_subset_r},'2014']))=0);
              DIO_m_dummy[not_s_subset,{s_subset_r},t]$(tData[t])   = yes$(vDIO_m_2012_2013_ns146[not_s_subset,{s_subset_r},t] and (sum({ss_subset_r}, vDIO_m_2014_2019_ns146[not_s_subset,{ss_subset_r},'2014']))=0);
            $ENDFOR1 

            $FOR {s_subset_c},{ss_subset_c} in [('s_010000_c','ss_010000_c'),('s_350010_c','ss_350010_c'),('s_383900_c','ss_383900_c'),('s_490010_c','ss_490010_c'),('s_490020_c','ss_490020_c'),
                                                ('s_490030_c','ss_490030_c'),('s_500000_c','ss_500000_c'),('s_510000_c','ss_510000_c'),('s_520000_c','ss_520000_c'),('s_530000_c','ss_530000_c')]:
              DIO_a_dummy[a_rows,{s_subset_c},t]$(tData[t])         = yes$(vDIO_a_2012_2013_ns146[a_rows,{s_subset_c},t] and (sum({ss_subset_c}, vDIO_a_2014_2019_ns146[a_rows,{ss_subset_c},'2014']))=0);
            $ENDFOR


            #--------------------------------------------------------------------------------------------------------------------
            #  Special mapping for vDIO_y_2012_2013 and vDIO_m_2012_2013
            #--------------------------------------------------------------------------------------------------------------------
            # First we loop through the row-sectors that are split of a NR117-sector
            $FOR1 {s_subset_r},{ss_subset_r} in [('s_010000_r','ss_010000_r'),('s_350010_r','ss_350010_r'),('s_383900_r','ss_383900_r'),('s_490010_r','ss_490010_r'),('s_490020_r','ss_490020_r'),
                                                ('s_490030_r','ss_490030_r'),('s_500000_r','ss_500000_r'),('s_510000_r','ss_510000_r'),('s_520000_r','ss_520000_r'),('s_530000_r','ss_530000_r')]:
              # Then we loop through the column-sectors that are split of a NR117-sector
              $FOR2 {s_subset_c},{ss_subset_c} in [('s_010000_c','ss_010000_c'),('s_350010_c','ss_350010_c'),('s_383900_c','ss_383900_c'),('s_490010_c','ss_490010_c'),('s_490020_c','ss_490020_c'),
                                                ('s_490030_c','ss_490030_c'),('s_500000_c','ss_500000_c'),('s_510000_c','ss_510000_c'),('s_520000_c','ss_520000_c'),('s_530000_c','ss_530000_c')]:
                # For each combination of a split row-sector and a split column-sector, the value is calculated
                vDIO_y_2012_2013_ns146[{s_subset_r},{s_subset_c},t]$(tData[t] and not DIO_y_dummy[{s_subset_r},{s_subset_c},t])=vDIO_y_2012_2013_ns146[{s_subset_r},{s_subset_c},t]*(vDIO_y_2014_2019_ns146[{s_subset_r},{s_subset_c},'2014']/(sum(({ss_subset_r},{ss_subset_c}), vDIO_y_2014_2019_ns146[{ss_subset_r},{ss_subset_c},'2014'])));
                vDIO_m_2012_2013_ns146[{s_subset_r},{s_subset_c},t]$(tData[t] and not DIO_m_dummy[{s_subset_r},{s_subset_c},t])=vDIO_m_2012_2013_ns146[{s_subset_r},{s_subset_c},t]*(vDIO_m_2014_2019_ns146[{s_subset_r},{s_subset_c},'2014']/(sum(({ss_subset_r},{ss_subset_c}), vDIO_m_2014_2019_ns146[{ss_subset_r},{ss_subset_c},'2014'])));
                # We manually split the DIO for the sectors where we can't use the distribution in 2014
                vDIO_y_2012_2013_ns146[{s_subset_r},{s_subset_c},t]$(tData[t] and DIO_y_dummy[{s_subset_r},{s_subset_c},t])=vDIO_y_2012_2013_ns146[{s_subset_r},{s_subset_c},t]/(CARD({s_subset_r})*CARD({s_subset_c}));
                vDIO_m_2012_2013_ns146[{s_subset_r},{s_subset_c},t]$(tData[t] and DIO_m_dummy[{s_subset_r},{s_subset_c},t])=vDIO_m_2012_2013_ns146[{s_subset_r},{s_subset_c},t]/(CARD({s_subset_r})*CARD({s_subset_c}));
              $ENDFOR2
            # For each combination of a split row-sector and a non-split column-sector, the value is calculated 
            vDIO_y_2012_2013_ns146[{s_subset_r},not_s_subset,t]$(tData[t] and not DIO_y_dummy[{s_subset_r},not_s_subset,t])=vDIO_y_2012_2013_ns146[{s_subset_r},not_s_subset,t]*(vDIO_y_2014_2019_ns146[{s_subset_r},not_s_subset,'2014']/(sum({ss_subset_r}, vDIO_y_2014_2019_ns146[{ss_subset_r},not_s_subset,'2014'])));
            vDIO_m_2012_2013_ns146[{s_subset_r},not_s_subset,t]$(tData[t] and not DIO_m_dummy[{s_subset_r},not_s_subset,t])=vDIO_m_2012_2013_ns146[{s_subset_r},not_s_subset,t]*(vDIO_m_2014_2019_ns146[{s_subset_r},not_s_subset,'2014']/(sum({ss_subset_r}, vDIO_m_2014_2019_ns146[{ss_subset_r},not_s_subset,'2014'])))$(sum({ss_subset_r}, vDIO_m_2014_2019_ns146[{ss_subset_r},not_s_subset,'2014']));
            vDIO_y_2012_2013_ns146[{s_subset_r},not_s_subset_c,t]$(tData[t] and not DIO_y_dummy[{s_subset_r},not_s_subset_c,t])=vDIO_y_2012_2013_ns146[{s_subset_r},not_s_subset_c,t]*(vDIO_y_2014_2019_ns146[{s_subset_r},not_s_subset_c,'2014']/(sum({ss_subset_r}, vDIO_y_2014_2019_ns146[{ss_subset_r},not_s_subset_c,'2014'])))$(sum({ss_subset_r}, vDIO_y_2014_2019_ns146[{ss_subset_r},not_s_subset_c,'2014']));
            vDIO_m_2012_2013_ns146[{s_subset_r},not_s_subset_c,t]$(tData[t] and not DIO_m_dummy[{s_subset_r},not_s_subset_c,t])=vDIO_m_2012_2013_ns146[{s_subset_r},not_s_subset_c,t]*(vDIO_m_2014_2019_ns146[{s_subset_r},not_s_subset_c,'2014']/(sum({ss_subset_r}, vDIO_m_2014_2019_ns146[{ss_subset_r},not_s_subset_c,'2014'])))$(sum({ss_subset_r}, vDIO_m_2014_2019_ns146[{ss_subset_r},not_s_subset_c,'2014']));
            # We manually split the DIO for the sectors where we can't use the distribution in 2014
            vDIO_y_2012_2013_ns146[{s_subset_r},not_s_subset,t]$(tData[t] and DIO_y_dummy[{s_subset_r},not_s_subset,t])=vDIO_y_2012_2013_ns146[{s_subset_r},not_s_subset,t]/CARD({s_subset_r});
            vDIO_m_2012_2013_ns146[{s_subset_r},not_s_subset,t]$(tData[t] and DIO_m_dummy[{s_subset_r},not_s_subset,t])=vDIO_m_2012_2013_ns146[{s_subset_r},not_s_subset,t]/CARD({s_subset_r});
            vDIO_y_2012_2013_ns146[{s_subset_r},not_s_subset_c,t]$(tData[t] and DIO_y_dummy[{s_subset_r},not_s_subset_c,t])=vDIO_y_2012_2013_ns146[{s_subset_r},not_s_subset_c,t]/CARD({s_subset_r});
            vDIO_m_2012_2013_ns146[{s_subset_r},not_s_subset_c,t]$(tData[t] and DIO_m_dummy[{s_subset_r},not_s_subset_c,t])=vDIO_m_2012_2013_ns146[{s_subset_r},not_s_subset_c,t]/CARD({s_subset_r});
            $ENDFOR1
            # For each combination of a non-split row-sector and a split column-sector, the value is calculated
            $FOR {s_subset_c},{ss_subset_c} in [('s_010000_c','ss_010000_c'),('s_350010_c','ss_350010_c'),('s_383900_c','ss_383900_c'),('s_490010_c','ss_490010_c'),('s_490020_c','ss_490020_c'),
                                                ('s_490030_c','ss_490030_c'),('s_500000_c','ss_500000_c'),('s_510000_c','ss_510000_c'),('s_520000_c','ss_520000_c'),('s_530000_c','ss_530000_c')]:
                vDIO_y_2012_2013_ns146[not_s_subset,{s_subset_c},t]$(tData[t] and not DIO_y_dummy[not_s_subset,{s_subset_c},t])=vDIO_y_2012_2013_ns146[not_s_subset,{s_subset_c},t]*(vDIO_y_2014_2019_ns146[not_s_subset,{s_subset_c},'2014']/(sum({ss_subset_c}, vDIO_y_2014_2019_ns146[not_s_subset,{ss_subset_c},'2014'])))$(sum({ss_subset_c}, vDIO_y_2014_2019_ns146[not_s_subset,{ss_subset_c},'2014']));
                vDIO_m_2012_2013_ns146[not_s_subset,{s_subset_c},t]$(tData[t] and not DIO_m_dummy[not_s_subset,{s_subset_c},t])=vDIO_m_2012_2013_ns146[not_s_subset,{s_subset_c},t]*(vDIO_m_2014_2019_ns146[not_s_subset,{s_subset_c},'2014']/(sum({ss_subset_c}, vDIO_m_2014_2019_ns146[not_s_subset,{ss_subset_c},'2014'])))$(sum({ss_subset_c}, vDIO_m_2014_2019_ns146[not_s_subset,{ss_subset_c},'2014']));
              vDIO_y_2012_2013_ns146[not_s_subset,{s_subset_c},t]$(tData[t] and DIO_y_dummy[not_s_subset,{s_subset_c},t])=vDIO_y_2012_2013_ns146[not_s_subset,{s_subset_c},t]/CARD({s_subset_c});
            vDIO_m_2012_2013_ns146[not_s_subset,{s_subset_c},t]$(tData[t] and DIO_m_dummy[not_s_subset,{s_subset_c},t])=vDIO_m_2012_2013_ns146[not_s_subset,{s_subset_c},t]/CARD({s_subset_c});
            $ENDFOR

            #--------------------------------------------------------------------------------------------------------------------
            #  Special mapping for vDIO_a_2012_2013
            #--------------------------------------------------------------------------------------------------------------------
            $FOR {s_subset_c},{ss_subset_c} in [('s_010000_c','ss_010000_c'),('s_350010_c','ss_350010_c'),('s_383900_c','ss_383900_c'),('s_490010_c','ss_490010_c'),('s_490020_c','ss_490020_c'),
                                                ('s_490030_c','ss_490030_c'),('s_500000_c','ss_500000_c'),('s_510000_c','ss_510000_c'),('s_520000_c','ss_520000_c'),('s_530000_c','ss_530000_c')]:
              vDIO_a_2012_2013_ns146[a_rows,{s_subset_c},t]$(tData[t] and not DIO_a_dummy[a_rows,{s_subset_c},t]) = vDIO_a_2012_2013_ns146[a_rows,{s_subset_c},t]*(vDIO_a_2014_2019_ns146[a_rows,{s_subset_c},'2014']/sum({ss_subset_c},vDIO_a_2014_2019_ns146[a_rows,{ss_subset_c},'2014']))$(sum({ss_subset_c},vDIO_a_2014_2019_ns146[a_rows,{ss_subset_c},'2014']));
              # We manually split the DIO for the sectors where we can't use the distribution in 2014
              vDIO_a_2012_2013_ns146[a_rows,{s_subset_c},t]$(tData[t] and DIO_a_dummy[a_rows,{s_subset_c},t]) = vDIO_a_2012_2013_ns146[a_rows,{s_subset_c},t]/CARD({s_subset_c});
            $ENDFOR

          #--------------------------------------------------------------------------------------------------------------------
          #  Merging the 2012-2013 146-sector data with the 2014-2019 146-sector data 
          #--------------------------------------------------------------------------------------------------------------------
          vDIO_y_2014_2019_ns146[ns146_r,IO_146_c,'2012'] = vDIO_y_2012_2013_ns146[ns146_r,IO_146_c,'2012'];
          vDIO_y_2014_2019_ns146[ns146_r,IO_146_c,'2013'] = vDIO_y_2012_2013_ns146[ns146_r,IO_146_c,'2013'];
          vDIO_m_2014_2019_ns146[ns146_r,IO_146_c,'2012'] = vDIO_m_2012_2013_ns146[ns146_r,IO_146_c,'2012'];
          vDIO_m_2014_2019_ns146[ns146_r,IO_146_c,'2013'] = vDIO_m_2012_2013_ns146[ns146_r,IO_146_c,'2013'];  
          vDIO_a_2014_2019_ns146[a_rows,IO_146_c,'2012']  = vDIO_a_2012_2013_ns146[a_rows,IO_146_c,'2012'];
          vDIO_a_2014_2019_ns146[a_rows,IO_146_c,'2013']  = vDIO_a_2012_2013_ns146[a_rows,IO_146_c,'2013'];

          #--------------------------------------------------------------------------------------------------------------------
          # Mapping from 146-sectors to 56-model sectors 
          #--------------------------------------------------------------------------------------------------------------------
          $PGROUP DIO
                        vDIO_y[s56_,IO_56_c_,t]                 "Production DIO 2012-2019"
                        vDIO_m[s56_,IO_56_c_,t]                 "Import DIO 2012-2019"
                        vDIO_a[a_rows_,IO_56_c_,t]              "Other DIO 2012-2019"
                        vDIO_cus[s56_,IO_56_c_,t]               "Customs on IO, last years prices, 2014-2019"

                        DIO_vC_y_2012_2013[ns117_r,c56,t]       "Consumption DIO 2012-2013"
                        DIO_vC_m_2012_2013[ns117_r,c56,t]       "Import consumption DIO 2012-2013"
                        DIO_vC_a_2012_2013[a_rows,c56,t]        "Other consumption DIO 2012-2013"
          ;
          vDIO_y[s56,IO_56_c,t]$(tData[t])     = sum((ns146_r,IO_146_c)$(ns146_2_s56(ns146_r,s56) and IO146_2_IOs(IO_146_c,IO_56_c)), vDIO_y_2014_2019_ns146[ns146_r,IO_146_c,t])/10**6;                   
          vDIO_m[s56,IO_56_c,t]$(tData[t])     = sum((ns146_r,IO_146_c)$(ns146_2_s56(ns146_r,s56) and IO146_2_IOs(IO_146_c,IO_56_c)), vDIO_m_2014_2019_ns146[ns146_r,IO_146_c,t])/10**6;                   
          vDIO_a[a_rows,IO_56_c,t]$(tData[t])  = sum(IO_146_c$(IO146_2_IOs(IO_146_c,IO_56_c)), vDIO_a_2014_2019_ns146[a_rows,IO_146_c,t])/10**6;  

          vDIO_cus[s56,IO_56_c,t]$(tData[t])   = sum((ns146_r,IO_146_c)$(ns146_2_s56(ns146_r,s56) and IO146_2_IOs(IO_146_c,IO_56_c)), vDIO_cus_146[ns146_r,IO_146_c,t])/10**6;

          # Mapping of consumption for 2012-2013 (note: rows are 117-sectors and not 146-sectors)
          DIO_vC_y_2012_2013[ns117_r,c56,t]      = sum(nc74_117$(nc74_117_2_c56[nc74_117,c56]), vDCP_12_13_y[ns117_r,nc74_117,t])/10**6;
          DIO_vC_m_2012_2013[ns117_r,c56,t]      = sum(nc74_117$(nc74_117_2_c56[nc74_117,c56]), vDCP_12_13_m[ns117_r,nc74_117,t])/10**6;
          DIO_vC_a_2012_2013[a_rows,c56,t]       = sum(nc74_117$(nc74_117_2_c56[nc74_117,c56]), vDCP_12_13_a[a_rows,nc74_117,t])/10**6;

          #Totaler 
          vDIO_y['tot',IO_56_c,t]$(tData[t])   = sum(s56, vDIO_y[s56,IO_56_c,t]);
          vDIO_m['tot',IO_56_c,t]$(tData[t])   = sum(s56, vDIO_m[s56,IO_56_c,t]);
          vDIO_cus['tot',IO_56_c,t]$(tData[t]) = sum(s56, vDIO_cus[s56,IO_56_c,t]);


          vDIO_y[s56,'tot',t]$(tData[t])       = sum(IO_56_c, vDIO_y[s56,IO_56_c,t]);
          vDIO_m[s56,'tot',t]$(tData[t])       = sum(IO_56_c, vDIO_m[s56,IO_56_c,t]);
          vDIO_a[a_rows,'tot',t]$(tData[t])    = sum(IO_56_c, vDIO_a[a_rows,IO_56_c,t]);
          vDIO_cus[s56,'tot',t]$(tData[t])     = sum(IO_56_c, vDIO_cus[s56,IO_56_c,t]);

          
        #--------------------------------------------------------------------------------------------------------------------
        # Mapping of Energy IO-data
        #--------------------------------------------------------------------------------------------------------------------
          PARAMETERS
                        vEIO_y_2014_2016_ns146[ns146_,IO_146_c_,t]          "Production Energy IO 2014-2016"
                        vEIO_m_2014_2016_ns146[ns146_,IO_146_c_,t]          "Import Energy IO 2014-2016"
                        vEIO_a_2014_2016_ns146[a_rows,IO_146_c_,t]          "Other Energy IO 2014-2016"
                        vEIO_cus_2014_2016_ns146[ns146_,IO_146_c_,t]        "Customs on energy 2014-2016"
           ;
          #--------------------------------------------------------------------------------------------------------------------
          #  Mapping from 142-sectors to 146-sectors (2014-2016)  
          #--------------------------------------------------------------------------------------------------------------------
          vEIO_y_2014_2016_ns146[ns146_r,IO_146_c,t]$(tData[t])   = sum(IO_142_c$(IO142_2_IO146(IO_142_c,IO_146_c)), sum(ns142_r$(IO142_2_IO146(ns142_r,ns146_r)), vEIO_y_2014_2016_ns142[ns142_r,IO_142_c,t]));
          vEIO_m_2014_2016_ns146[ns146_r,IO_146_c,t]$(tData[t])   = sum(IO_142_c$(IO142_2_IO146(IO_142_c,IO_146_c)), sum(ns142_r$(IO142_2_IO146(ns142_r,ns146_r)), vEIO_m_2014_2016_ns142[ns142_r,IO_142_c,t]));
          vEIO_a_2014_2016_ns146[a_rows,IO_146_c,t]$(tData[t])    = sum(IO_142_c$(IO142_2_IO146(IO_142_c,IO_146_c)), vEIO_a_2014_2016_ns142[a_rows,IO_142_c,t]);
          vEIO_cus_2014_2016_ns146[ns146_r,IO_146_c,t]$(tData[t]) = sum(IO_142_c$(IO142_2_IO146(IO_142_c,IO_146_c)), sum(ns142_r$(IO142_2_IO146(ns142_r,ns146_r)), vEIO_cus_142_14_16[ns142_r,IO_142_c,t]));



          # Dummy to check if there are splitted sectors, where there are positive values in 2014-2016, but zero value in 2017.  
          # This would be a problem, because we use the distribution in 2017 to split the 2014-2016 data. 
          PARAMETER 
                        EIO_y_dummy[ns146_,IO_146_c_,t]
                        EIO_m_dummy[ns146_,IO_146_c_,t]
                        EIO_a_dummy[a_rows,IO_146_c_,t]
          ;
          $FOR1 {s_subset_r},{ss_subset_r} in [('s_350010_r','ss_350010_r'),('s_490030_r','ss_490030_r'),('s_500000_r','ss_500000_r'),('s_510000_r','ss_510000_r')]:
            $FOR2 {s_subset_c},{ss_subset_c} in [('s_350010_c','ss_350010_c'),('s_490030_c','ss_490030_c'),('s_500000_c','ss_500000_c'),('s_510000_c','ss_510000_c')]:
              EIO_y_dummy[{s_subset_r},{s_subset_c},t]$(tData[t]) = yes$(vEIO_y_2014_2016_ns146[{s_subset_r},{s_subset_c},t] and (sum(({ss_subset_r},{ss_subset_c}), vEIO_y_2017_2019_ns146[{ss_subset_r},{ss_subset_c},'2017']))=0);
              EIO_m_dummy[{s_subset_r},{s_subset_c},t]$(tData[t]) = yes$(vEIO_m_2014_2016_ns146[{s_subset_r},{s_subset_c},t] and (sum(({ss_subset_r},{ss_subset_c}), vEIO_m_2017_2019_ns146[{ss_subset_r},{ss_subset_c},'2017']))=0);
            $ENDFOR2
            EIO_y_dummy[{s_subset_r},not_s_subset_142,t]$(tData[t]) = yes$(vEIO_y_2014_2016_ns146[{s_subset_r},not_s_subset_142,t] and (sum({ss_subset_r}, vEIO_y_2017_2019_ns146[{ss_subset_r},not_s_subset_142,'2017']))=0);
            EIO_m_dummy[{s_subset_r},not_s_subset_142,t]$(tData[t]) = yes$(vEIO_m_2014_2016_ns146[{s_subset_r},not_s_subset_142,t] and (sum({ss_subset_r}, vEIO_m_2017_2019_ns146[{ss_subset_r},not_s_subset_142,'2017']))=0);
            EIO_y_dummy[{s_subset_r},not_s_subset_c,t]$(tData[t])   = yes$(vEIO_y_2014_2016_ns146[{s_subset_r},not_s_subset_c,t] and (sum({ss_subset_r}, vEIO_y_2017_2019_ns146[{ss_subset_r},not_s_subset_c,'2017']))=0);
            EIO_m_dummy[{s_subset_r},not_s_subset_c,t]$(tData[t])   = yes$(vEIO_m_2014_2016_ns146[{s_subset_r},not_s_subset_c,t] and (sum({ss_subset_r}, vEIO_m_2017_2019_ns146[{ss_subset_r},not_s_subset_c,'2017']))=0);
            EIO_y_dummy[not_s_subset_142,{s_subset_r},t]$(tData[t]) = yes$(vEIO_y_2014_2016_ns146[not_s_subset_142,{s_subset_r},t] and (sum({ss_subset_r}, vEIO_y_2017_2019_ns146[not_s_subset_142,{ss_subset_r},'2017']))=0);
            EIO_m_dummy[not_s_subset_142,{s_subset_r},t]$(tData[t]) = yes$(vEIO_m_2014_2016_ns146[not_s_subset_142,{s_subset_r},t] and (sum({ss_subset_r}, vEIO_m_2017_2019_ns146[not_s_subset_142,{ss_subset_r},'2017']))=0);
          $ENDFOR1 
          $FOR {s_subset_c},{ss_subset_c} in [('s_350010_c','ss_350010_c'),('s_490030_c','ss_490030_c'),('s_500000_c','ss_500000_c'),('s_510000_c','ss_510000_c')]:
            EIO_a_dummy[a_rows,{s_subset_c},t]$(tData[t])         = yes$(vEIO_a_2014_2016_ns146[a_rows,{s_subset_c},t] and (sum({ss_subset_c}, vEIO_a_2017_2019_ns146[a_rows,{ss_subset_c},'2017']))=0);
          $ENDFOR
          

          #--------------------------------------------------------------------------------------------------------------------
          #  vEIO_y_2014_2016 and vEIO_m_2014_2016
          #--------------------------------------------------------------------------------------------------------------------
          # First we loop through the row-sectors that are split of a NR117-sector
          $FOR1 {s_subset_r},{ss_subset_r} in [('s_350010_r','ss_350010_r'),('s_490030_r','ss_490030_r'),('s_500000_r','ss_500000_r'),('s_510000_r','ss_510000_r')]:
            # Then we loop through the column-sectors that are split of a NR117-sector
            $FOR2 {s_subset_c},{ss_subset_c} in [('s_350010_c','ss_350010_c'),('s_490030_c','ss_490030_c'),('s_500000_c','ss_500000_c'),('s_510000_c','ss_510000_c')]:
              # For each combination of a split row-sector and a split column-sector, the value is calculated
              vEIO_y_2014_2016_ns146[{s_subset_r},{s_subset_c},t]$(tData[t] and not EIO_y_dummy[{s_subset_r},{s_subset_c},t])=vEIO_y_2014_2016_ns146[{s_subset_r},{s_subset_c},t]*(vEIO_y_2017_2019_ns146[{s_subset_r},{s_subset_c},'2017']/(sum(({ss_subset_r},{ss_subset_c}), vEIO_y_2017_2019_ns146[{ss_subset_r},{ss_subset_c},'2017'])));
              vEIO_m_2014_2016_ns146[{s_subset_r},{s_subset_c},t]$(tData[t] and not EIO_m_dummy[{s_subset_r},{s_subset_c},t])=vEIO_m_2014_2016_ns146[{s_subset_r},{s_subset_c},t]*(vEIO_m_2017_2019_ns146[{s_subset_r},{s_subset_c},'2017']/(sum(({ss_subset_r},{ss_subset_c}), vEIO_m_2017_2019_ns146[{ss_subset_r},{ss_subset_c},'2017'])));
              vEIO_cus_2014_2016_ns146[{s_subset_r},{s_subset_c},t]$(tData[t] and not EIO_y_dummy[{s_subset_r},{s_subset_c},t])      = vEIO_cus_2014_2016_ns146[{s_subset_r},{s_subset_c},t]*(vEIO_m_2017_2019_ns146[{s_subset_r},{s_subset_c},'2017']/(sum(({ss_subset_r},{ss_subset_c}), vEIO_m_2017_2019_ns146[{ss_subset_r},{ss_subset_c},'2017'])));

              # We manually split the IO for the sectors where we can't use the distribution in 2014
              vEIO_y_2014_2016_ns146[{s_subset_r},{s_subset_c},t]$(tData[t] and EIO_y_dummy[{s_subset_r},{s_subset_c},t])=vEIO_y_2014_2016_ns146[{s_subset_r},{s_subset_c},t]/(CARD({s_subset_r})*CARD({s_subset_c}));
              vEIO_m_2014_2016_ns146[{s_subset_r},{s_subset_c},t]$(tData[t] and EIO_m_dummy[{s_subset_r},{s_subset_c},t])=vEIO_m_2014_2016_ns146[{s_subset_r},{s_subset_c},t]/(CARD({s_subset_r})*CARD({s_subset_c}));
              vEIO_cus_2014_2016_ns146[{s_subset_r},{s_subset_c},t]$(tData[t] and EIO_y_dummy[{s_subset_r},{s_subset_c},t]) = vEIO_cus_2014_2016_ns146[{s_subset_r},{s_subset_c},t]*(vEIO_m_2017_2019_ns146[{s_subset_r},{s_subset_c},'2017']/(sum(({ss_subset_r},{ss_subset_c}), vEIO_m_2017_2019_ns146[{ss_subset_r},{ss_subset_c},'2017'])));

            $ENDFOR2
          # For each combination of a split row-sector and a non-split column-sector, the value is calculated 
          vEIO_y_2014_2016_ns146[{s_subset_r},not_s_subset_142,t]$(tData[t] and not EIO_y_dummy[{s_subset_r},not_s_subset_142,t])=vEIO_y_2014_2016_ns146[{s_subset_r},not_s_subset_142,t]*(vEIO_y_2017_2019_ns146[{s_subset_r},not_s_subset_142,'2017']/(sum({ss_subset_r}, vEIO_y_2017_2019_ns146[{ss_subset_r},not_s_subset_142,'2017'])));
          vEIO_m_2014_2016_ns146[{s_subset_r},not_s_subset_142,t]$(tData[t] and not EIO_m_dummy[{s_subset_r},not_s_subset_142,t])=vEIO_m_2014_2016_ns146[{s_subset_r},not_s_subset_142,t]*(vEIO_m_2017_2019_ns146[{s_subset_r},not_s_subset_142,'2017']/(sum({ss_subset_r}, vEIO_m_2017_2019_ns146[{ss_subset_r},not_s_subset_142,'2017'])))$(sum({ss_subset_r}, vEIO_m_2017_2019_ns146[{ss_subset_r},not_s_subset_142,'2017']));
          vEIO_cus_2014_2016_ns146[{s_subset_r},not_s_subset_142,t]$(tData[t] and not EIO_m_dummy[{s_subset_r},not_s_subset_142,t])=vEIO_cus_2014_2016_ns146[{s_subset_r},not_s_subset_142,t]*(vEIO_m_2017_2019_ns146[{s_subset_r},not_s_subset_142,'2017']/(sum({ss_subset_r}, vEIO_m_2017_2019_ns146[{ss_subset_r},not_s_subset_142,'2017'])))$(sum({ss_subset_r}, vEIO_m_2017_2019_ns146[{ss_subset_r},not_s_subset_142,'2017']));
            

          vEIO_y_2014_2016_ns146[{s_subset_r},not_s_subset_c,t]$(tData[t] and not EIO_y_dummy[{s_subset_r},not_s_subset_c,t])=vEIO_y_2014_2016_ns146[{s_subset_r},not_s_subset_c,t]*(vEIO_y_2017_2019_ns146[{s_subset_r},not_s_subset_c,'2017']/(sum({ss_subset_r}, vEIO_y_2017_2019_ns146[{ss_subset_r},not_s_subset_c,'2017'])))$(sum({ss_subset_r}, vEIO_y_2017_2019_ns146[{ss_subset_r},not_s_subset_c,'2017']));
          vEIO_m_2014_2016_ns146[{s_subset_r},not_s_subset_c,t]$(tData[t] and not EIO_m_dummy[{s_subset_r},not_s_subset_c,t])=vEIO_m_2014_2016_ns146[{s_subset_r},not_s_subset_c,t]*(vEIO_m_2017_2019_ns146[{s_subset_r},not_s_subset_c,'2017']/(sum({ss_subset_r}, vEIO_m_2017_2019_ns146[{ss_subset_r},not_s_subset_c,'2017'])))$(sum({ss_subset_r}, vEIO_m_2017_2019_ns146[{ss_subset_r},not_s_subset_c,'2017']));
          vEIO_cus_2014_2016_ns146[{s_subset_r},not_s_subset_c,t]$(tData[t] and not EIO_m_dummy[{s_subset_r},not_s_subset_c,t])=vEIO_cus_2014_2016_ns146[{s_subset_r},not_s_subset_c,t]*(vEIO_m_2017_2019_ns146[{s_subset_r},not_s_subset_c,'2017']/(sum({ss_subset_r}, vEIO_m_2017_2019_ns146[{ss_subset_r},not_s_subset_c,'2017'])))$(sum({ss_subset_r}, vEIO_m_2017_2019_ns146[{ss_subset_r},not_s_subset_c,'2017']));
 
          # We manually split the IO for the sectors where we can't use the distribution in 2014
          vEIO_y_2014_2016_ns146[{s_subset_r},not_s_subset_142,t]$(tData[t] and EIO_y_dummy[{s_subset_r},not_s_subset_142,t])=vEIO_y_2014_2016_ns146[{s_subset_r},not_s_subset_142,t]/CARD({s_subset_r});
          vEIO_m_2014_2016_ns146[{s_subset_r},not_s_subset_142,t]$(tData[t] and EIO_m_dummy[{s_subset_r},not_s_subset_142,t])=vEIO_m_2014_2016_ns146[{s_subset_r},not_s_subset_142,t]/CARD({s_subset_r});
          vEIO_cus_2014_2016_ns146[{s_subset_r},not_s_subset_142,t]$(tData[t] and EIO_m_dummy[{s_subset_r},not_s_subset_142,t])=vEIO_cus_2014_2016_ns146[{s_subset_r},not_s_subset_142,t]/CARD({s_subset_r});
 
          vEIO_y_2014_2016_ns146[{s_subset_r},not_s_subset_c,t]$(tData[t] and EIO_y_dummy[{s_subset_r},not_s_subset_c,t])=vEIO_y_2014_2016_ns146[{s_subset_r},not_s_subset_c,t]/CARD({s_subset_r});
          vEIO_m_2014_2016_ns146[{s_subset_r},not_s_subset_c,t]$(tData[t] and EIO_m_dummy[{s_subset_r},not_s_subset_c,t])=vEIO_m_2014_2016_ns146[{s_subset_r},not_s_subset_c,t]/CARD({s_subset_r});
          vEIO_cus_2014_2016_ns146[{s_subset_r},not_s_subset_c,t]$(tData[t] and EIO_m_dummy[{s_subset_r},not_s_subset_c,t])=vEIO_cus_2014_2016_ns146[{s_subset_r},not_s_subset_c,t]/CARD({s_subset_r});

          $ENDFOR1
          # For each combination of a non-split row-sector and a split column-sector, the value is calculated
          $FOR {s_subset_c},{ss_subset_c} in [('s_350010_c','ss_350010_c'),('s_490030_c','ss_490030_c'),('s_500000_c','ss_500000_c'),('s_510000_c','ss_510000_c')]:
              vEIO_y_2014_2016_ns146[not_s_subset_142,{s_subset_c},t]$(tData[t] and not EIO_y_dummy[not_s_subset_142,{s_subset_c},t])=vEIO_y_2014_2016_ns146[not_s_subset_142,{s_subset_c},t]*(vEIO_y_2017_2019_ns146[not_s_subset_142,{s_subset_c},'2017']/(sum({ss_subset_c}, vEIO_y_2017_2019_ns146[not_s_subset_142,{ss_subset_c},'2017'])))$(sum({ss_subset_c}, vEIO_y_2017_2019_ns146[not_s_subset_142,{ss_subset_c},'2017']));
              vEIO_m_2014_2016_ns146[not_s_subset_142,{s_subset_c},t]$(tData[t] and not EIO_m_dummy[not_s_subset_142,{s_subset_c},t])=vEIO_m_2014_2016_ns146[not_s_subset_142,{s_subset_c},t]*(vEIO_m_2017_2019_ns146[not_s_subset_142,{s_subset_c},'2017']/(sum({ss_subset_c}, vEIO_m_2017_2019_ns146[not_s_subset_142,{ss_subset_c},'2017'])))$(sum({ss_subset_c}, vEIO_m_2017_2019_ns146[not_s_subset_142,{ss_subset_c},'2017']));
              vEIO_cus_2014_2016_ns146[not_s_subset_142,{s_subset_c},t]$(tData[t] and not EIO_m_dummy[not_s_subset_142,{s_subset_c},t])=vEIO_cus_2014_2016_ns146[not_s_subset_142,{s_subset_c},t]*(vEIO_m_2017_2019_ns146[not_s_subset_142,{s_subset_c},'2017']/(sum({ss_subset_c}, vEIO_m_2017_2019_ns146[not_s_subset_142,{ss_subset_c},'2017'])))$(sum({ss_subset_c}, vEIO_m_2017_2019_ns146[not_s_subset_142,{ss_subset_c},'2017']));
 
              vEIO_y_2014_2016_ns146[not_s_subset_142,{s_subset_c},t]$(tData[t] and EIO_y_dummy[not_s_subset_142,{s_subset_c},t])=vEIO_y_2014_2016_ns146[not_s_subset_142,{s_subset_c},t]/CARD({s_subset_c});
              vEIO_m_2014_2016_ns146[not_s_subset_142,{s_subset_c},t]$(tData[t] and EIO_m_dummy[not_s_subset_142,{s_subset_c},t])=vEIO_m_2014_2016_ns146[not_s_subset_142,{s_subset_c},t]/CARD({s_subset_c});
              vEIO_cus_2014_2016_ns146[not_s_subset_142,{s_subset_c},t]$(tData[t] and EIO_m_dummy[not_s_subset_142,{s_subset_c},t])=vEIO_cus_2014_2016_ns146[not_s_subset_142,{s_subset_c},t]/CARD({s_subset_c});

          $ENDFOR

          #--------------------------------------------------------------------------------------------------------------------
          #  vEIO_a_2012_2013
          #--------------------------------------------------------------------------------------------------------------------
          $FOR {s_subset_c},{ss_subset_c} in [('s_350010_c','ss_350010_c'),('s_490030_c','ss_490030_c'),('s_500000_c','ss_500000_c'),('s_510000_c','ss_510000_c')]:
            vEIO_a_2014_2016_ns146[a_rows,{s_subset_c},t]$(tData[t] and not EIO_a_dummy[a_rows,{s_subset_c},t]) = vEIO_a_2014_2016_ns146[a_rows,{s_subset_c},t]*(vEIO_a_2017_2019_ns146[a_rows,{s_subset_c},'2017']/sum({ss_subset_c},vEIO_a_2017_2019_ns146[a_rows,{ss_subset_c},'2017']))$(sum({ss_subset_c},vEIO_a_2017_2019_ns146[a_rows,{ss_subset_c},'2017']));
            # We manually split the IO for the sectors where we can't use the distribution in 2014
            vEIO_a_2014_2016_ns146[a_rows,{s_subset_c},t]$(tData[t] and EIO_a_dummy[a_rows,{s_subset_c},t]) = vEIO_a_2014_2016_ns146[a_rows,{s_subset_c},t]/CARD({s_subset_c});
          $ENDFOR

          #--------------------------------------------------------------------------------------------------------------------
          #  Merging the 2014-2016 146-sector data with the 2017-2019 146-sector data 
          #--------------------------------------------------------------------------------------------------------------------
          vEIO_y_2017_2019_ns146[ns146_r,IO_146_c,'2014'] = vEIO_y_2014_2016_ns146[ns146_r,IO_146_c,'2014'];
          vEIO_y_2017_2019_ns146[ns146_r,IO_146_c,'2015'] = vEIO_y_2014_2016_ns146[ns146_r,IO_146_c,'2015'];
          vEIO_y_2017_2019_ns146[ns146_r,IO_146_c,'2016'] = vEIO_y_2014_2016_ns146[ns146_r,IO_146_c,'2016'];
          vEIO_m_2017_2019_ns146[ns146_r,IO_146_c,'2014'] = vEIO_m_2014_2016_ns146[ns146_r,IO_146_c,'2014'];
          vEIO_m_2017_2019_ns146[ns146_r,IO_146_c,'2015'] = vEIO_m_2014_2016_ns146[ns146_r,IO_146_c,'2015']; 
          vEIO_m_2017_2019_ns146[ns146_r,IO_146_c,'2016'] = vEIO_m_2014_2016_ns146[ns146_r,IO_146_c,'2016']; 
          vEIO_a_2017_2019_ns146[a_rows,IO_146_c,'2014']  = vEIO_a_2014_2016_ns146[a_rows,IO_146_c,'2014'];
          vEIO_a_2017_2019_ns146[a_rows,IO_146_c,'2015']  = vEIO_a_2014_2016_ns146[a_rows,IO_146_c,'2015'];
          vEIO_a_2017_2019_ns146[a_rows,IO_146_c,'2016']  = vEIO_a_2014_2016_ns146[a_rows,IO_146_c,'2016'];
          vEIO_cus_146[ns146_r,IO_146_c,'2014']           = vEIO_cus_146[ns146_r,IO_146_c,'2014'];
          vEIO_cus_146[ns146_r,IO_146_c,'2015']           = vEIO_cus_146[ns146_r,IO_146_c,'2015']; 
          vEIO_cus_146[ns146_r,IO_146_c,'2016']           = vEIO_cus_146[ns146_r,IO_146_c,'2016']; 
  

          #--------------------------------------------------------------------------------------------------------------------
          # Mapping from 146-sectors to 56-model sectors 
          #--------------------------------------------------------------------------------------------------------------------
          $PGROUP EIO
                     vEIO_y[s56_,IO_56_c_,t]                      "Production energy IO 2014-2019"
                     vEIO_m[s56_,IO_56_c_,t]                      "Import energy IO 2014-2019"
                     vEIO_a[a_rows_,IO_56_c_,t]                   "Other energy IO 2014-2019"
                     vEIO_cus[s56_,IO_56_c_,t]                     "Customs on energy 2014-2019"
           ;
          vEIO_y[s56,IO_56_c,t]$(tData[t])        = sum((ns146_r,IO_146_c)$(ns146_2_s56(ns146_r,s56) and IO146_2_IOs(IO_146_c,IO_56_c)), vEIO_y_2017_2019_ns146[ns146_r,IO_146_c,t])/10**6;                   
          vEIO_m[s56,IO_56_c,t]$(tData[t])        = sum((ns146_r,IO_146_c)$(ns146_2_s56(ns146_r,s56) and IO146_2_IOs(IO_146_c,IO_56_c)), vEIO_m_2017_2019_ns146[ns146_r,IO_146_c,t])/10**6;                   
          vEIO_a[a_rows,IO_56_c,t]$(tData[t])     = sum(IO_146_c$(IO146_2_IOs(IO_146_c,IO_56_c)), vEIO_a_2017_2019_ns146[a_rows,IO_146_c,t])/(10**6);        
          vEIO_cus[s56,IO_56_c,t]$(tData[t])      = sum((ns146_r,IO_146_c)$(ns146_2_s56(ns146_r,s56) and IO146_2_IOs(IO_146_c,IO_56_c)), vEIO_cus_146[ns146_r,IO_146_c,t])/10**6;           

          #Totaler 
          vEIO_y['tot',IO_56_c,t]$(tData[t])      = sum(s56, vEIO_y[s56,IO_56_c,t]);
          vEIO_m['tot',IO_56_c,t]$(tData[t])      = sum(s56, vEIO_m[s56,IO_56_c,t]);
          vEIO_cus['tot',IO_56_c,t]$(tData[t])    = sum(s56, vEIO_cus[s56,IO_56_c,t]);
 
          vEIO_y[s56,'tot',t]$(tData[t])          = sum(IO_56_c, vEIO_y[s56,IO_56_c,t]);
          vEIO_m[s56,'tot',t]$(tData[t])          = sum(IO_56_c, vEIO_m[s56,IO_56_c,t]);
          vEIO_cus[s56,'tot',t]$(tData[t])        = sum(IO_56_c, vEIO_cus[s56,IO_56_c,t]);
          vEIO_a[a_rows,'tot',t]$(tData[t])       = sum(IO_56_c, vEIO_a[a_rows,IO_56_c,t]);


        #--------------------------------------------------------------------------------------------------------------------
        # Mapping of Energy DIO-data
        #--------------------------------------------------------------------------------------------------------------------
          PARAMETERS
                        vDEIO_y_2014_2016_ns146[ns146_,IO_146_c_,t]          "Production Energy DIO 2014-2016"
                        vDEIO_m_2014_2016_ns146[ns146_,IO_146_c_,t]          "Import Energy DIO 2014-2016"
                        vDEIO_a_2014_2016_ns146[a_rows,IO_146_c_,t]           "Other Energy DIO 2014-2016"
           ;
          #--------------------------------------------------------------------------------------------------------------------
          #  Mapping from 142-sectors to 146-sectors (2014-2016)  
          #--------------------------------------------------------------------------------------------------------------------
          vDEIO_y_2014_2016_ns146[ns146_r,IO_146_c,t]$(tData[t]) = sum(IO_142_c$(IO142_2_IO146(IO_142_c,IO_146_c)), sum(ns142_r$(IO142_2_IO146(ns142_r,ns146_r)), vDEIO_y_2014_2016_ns142[ns142_r,IO_142_c,t]));
          vDEIO_m_2014_2016_ns146[ns146_r,IO_146_c,t]$(tData[t]) = sum(IO_142_c$(IO142_2_IO146(IO_142_c,IO_146_c)), sum(ns142_r$(IO142_2_IO146(ns142_r,ns146_r)), vDEIO_m_2014_2016_ns142[ns142_r,IO_142_c,t]));
          vDEIO_a_2014_2016_ns146[a_rows,IO_146_c,t]$(tData[t])  = sum(IO_142_c$(IO142_2_IO146(IO_142_c,IO_146_c)), vDEIO_a_2014_2016_ns142[a_rows,IO_142_c,t]);

          # Dummy to check if there are splitted sectors, where there are positive values in 2014-2016, but zero value in 2017.  
          # This would be a problem, because we use the distribution in 2017 to split the 2014-2016 data. 
          PARAMETER 
                        EDIO_y_dummy[ns146_,IO_146_c_,t]
                        EDIO_m_dummy[ns146_,IO_146_c_,t]
                        EDIO_a_dummy[a_rows,IO_146_c_,t]
          ;
          $FOR1 {s_subset_r},{ss_subset_r} in [('s_350010_r','ss_350010_r'),('s_490030_r','ss_490030_r'),('s_500000_r','ss_500000_r'),('s_510000_r','ss_510000_r')]:
            $FOR2 {s_subset_c},{ss_subset_c} in [('s_350010_c','ss_350010_c'),('s_490030_c','ss_490030_c'),('s_500000_c','ss_500000_c'),('s_510000_c','ss_510000_c')]:
              EDIO_y_dummy[{s_subset_r},{s_subset_c},t]$(tData[t]) = yes$(vDEIO_y_2014_2016_ns146[{s_subset_r},{s_subset_c},t] and (sum(({ss_subset_r},{ss_subset_c}), vDEIO_y_2017_2019_ns146[{ss_subset_r},{ss_subset_c},'2017']))=0);
              EDIO_m_dummy[{s_subset_r},{s_subset_c},t]$(tData[t]) = yes$(vDEIO_m_2014_2016_ns146[{s_subset_r},{s_subset_c},t] and (sum(({ss_subset_r},{ss_subset_c}), vDEIO_m_2017_2019_ns146[{ss_subset_r},{ss_subset_c},'2017']))=0);
            $ENDFOR2
            EDIO_y_dummy[{s_subset_r},not_s_subset_142,t]$(tData[t]) = yes$(vDEIO_y_2014_2016_ns146[{s_subset_r},not_s_subset_142,t] and (sum({ss_subset_r}, vDEIO_y_2017_2019_ns146[{ss_subset_r},not_s_subset_142,'2017']))=0);
            EDIO_m_dummy[{s_subset_r},not_s_subset_142,t]$(tData[t]) = yes$(vDEIO_m_2014_2016_ns146[{s_subset_r},not_s_subset_142,t] and (sum({ss_subset_r}, vDEIO_m_2017_2019_ns146[{ss_subset_r},not_s_subset_142,'2017']))=0);
            EDIO_y_dummy[{s_subset_r},not_s_subset_c,t]$(tData[t])   = yes$(vDEIO_y_2014_2016_ns146[{s_subset_r},not_s_subset_c,t] and (sum({ss_subset_r}, vDEIO_y_2017_2019_ns146[{ss_subset_r},not_s_subset_c,'2017']))=0);
            EDIO_m_dummy[{s_subset_r},not_s_subset_c,t]$(tData[t])   = yes$(vDEIO_m_2014_2016_ns146[{s_subset_r},not_s_subset_c,t] and (sum({ss_subset_r}, vDEIO_m_2017_2019_ns146[{ss_subset_r},not_s_subset_c,'2017']))=0);
            EDIO_y_dummy[not_s_subset_142,{s_subset_r},t]$(tData[t]) = yes$(vDEIO_y_2014_2016_ns146[not_s_subset_142,{s_subset_r},t] and (sum({ss_subset_r}, vDEIO_y_2017_2019_ns146[not_s_subset_142,{ss_subset_r},'2017']))=0);
            EDIO_m_dummy[not_s_subset_142,{s_subset_r},t]$(tData[t]) = yes$(vDEIO_m_2014_2016_ns146[not_s_subset_142,{s_subset_r},t] and (sum({ss_subset_r}, vDEIO_m_2017_2019_ns146[not_s_subset_142,{ss_subset_r},'2017']))=0);
          $ENDFOR1 
          $FOR {s_subset_c},{ss_subset_c} in [('s_350010_c','ss_350010_c'),('s_490030_c','ss_490030_c'),('s_500000_c','ss_500000_c'),('s_510000_c','ss_510000_c')]:
            EDIO_a_dummy[a_rows,{s_subset_c},t]$(tData[t])         = yes$(vDEIO_a_2014_2016_ns146[a_rows,{s_subset_c},t] and (sum({ss_subset_c}, vDEIO_a_2017_2019_ns146[a_rows,{ss_subset_c},'2017']))=0);
          $ENDFOR
          

          #--------------------------------------------------------------------------------------------------------------------
          #  vEIO_y_2014_2016 and vEIO_m_2014_2016
          #--------------------------------------------------------------------------------------------------------------------
          # First we loop through the row-sectors that are split of a NR117-sector
          $FOR1 {s_subset_r},{ss_subset_r} in [('s_350010_r','ss_350010_r'),('s_490030_r','ss_490030_r'),('s_500000_r','ss_500000_r'),('s_510000_r','ss_510000_r')]:
            # Then we loop through the column-sectors that are split of a NR117-sector
            $FOR2 {s_subset_c},{ss_subset_c} in [('s_350010_c','ss_350010_c'),('s_490030_c','ss_490030_c'),('s_500000_c','ss_500000_c'),('s_510000_c','ss_510000_c')]:
              # For each combination of a split row-sector and a split column-sector, the value is calculated
              vDEIO_y_2014_2016_ns146[{s_subset_r},{s_subset_c},t]$(tData[t] and not EDIO_y_dummy[{s_subset_r},{s_subset_c},t])=vDEIO_y_2014_2016_ns146[{s_subset_r},{s_subset_c},t]*(vDEIO_y_2017_2019_ns146[{s_subset_r},{s_subset_c},'2017']/(sum(({ss_subset_r},{ss_subset_c}), vDEIO_y_2017_2019_ns146[{ss_subset_r},{ss_subset_c},'2017'])));
              vDEIO_m_2014_2016_ns146[{s_subset_r},{s_subset_c},t]$(tData[t] and not EDIO_m_dummy[{s_subset_r},{s_subset_c},t])=vDEIO_m_2014_2016_ns146[{s_subset_r},{s_subset_c},t]*(vDEIO_m_2017_2019_ns146[{s_subset_r},{s_subset_c},'2017']/(sum(({ss_subset_r},{ss_subset_c}), vDEIO_m_2017_2019_ns146[{ss_subset_r},{ss_subset_c},'2017'])));
              # We manually split the IO for the sectors where we can't use the distribution in 2014
              vDEIO_y_2014_2016_ns146[{s_subset_r},{s_subset_c},t]$(tData[t] and EDIO_y_dummy[{s_subset_r},{s_subset_c},t])=vDEIO_y_2014_2016_ns146[{s_subset_r},{s_subset_c},t]/(CARD({s_subset_r})*CARD({s_subset_c}));
              vDEIO_m_2014_2016_ns146[{s_subset_r},{s_subset_c},t]$(tData[t] and EDIO_m_dummy[{s_subset_r},{s_subset_c},t])=vDEIO_m_2014_2016_ns146[{s_subset_r},{s_subset_c},t]/(CARD({s_subset_r})*CARD({s_subset_c}));
            $ENDFOR2
          # For each combination of a split row-sector and a non-split column-sector, the value is calculated 
          vDEIO_y_2014_2016_ns146[{s_subset_r},not_s_subset_142,t]$(tData[t] and not EDIO_y_dummy[{s_subset_r},not_s_subset_142,t])=vDEIO_y_2014_2016_ns146[{s_subset_r},not_s_subset_142,t]*(vDEIO_y_2017_2019_ns146[{s_subset_r},not_s_subset_142,'2017']/(sum({ss_subset_r}, vDEIO_y_2017_2019_ns146[{ss_subset_r},not_s_subset_142,'2017'])));
          vDEIO_m_2014_2016_ns146[{s_subset_r},not_s_subset_142,t]$(tData[t] and not EDIO_m_dummy[{s_subset_r},not_s_subset_142,t])=vDEIO_m_2014_2016_ns146[{s_subset_r},not_s_subset_142,t]*(vDEIO_m_2017_2019_ns146[{s_subset_r},not_s_subset_142,'2017']/(sum({ss_subset_r}, vDEIO_m_2017_2019_ns146[{ss_subset_r},not_s_subset_142,'2017'])))$(sum({ss_subset_r}, vDEIO_m_2017_2019_ns146[{ss_subset_r},not_s_subset_142,'2017']));
          vDEIO_y_2014_2016_ns146[{s_subset_r},not_s_subset_c,t]$(tData[t] and not EDIO_y_dummy[{s_subset_r},not_s_subset_c,t])=vDEIO_y_2014_2016_ns146[{s_subset_r},not_s_subset_c,t]*(vDEIO_y_2017_2019_ns146[{s_subset_r},not_s_subset_c,'2017']/(sum({ss_subset_r}, vDEIO_y_2017_2019_ns146[{ss_subset_r},not_s_subset_c,'2017'])))$(sum({ss_subset_r}, vDEIO_y_2017_2019_ns146[{ss_subset_r},not_s_subset_c,'2017']));
          vDEIO_m_2014_2016_ns146[{s_subset_r},not_s_subset_c,t]$(tData[t] and not EDIO_m_dummy[{s_subset_r},not_s_subset_c,t])=vDEIO_m_2014_2016_ns146[{s_subset_r},not_s_subset_c,t]*(vDEIO_m_2017_2019_ns146[{s_subset_r},not_s_subset_c,'2017']/(sum({ss_subset_r}, vDEIO_m_2017_2019_ns146[{ss_subset_r},not_s_subset_c,'2017'])))$(sum({ss_subset_r}, vDEIO_m_2017_2019_ns146[{ss_subset_r},not_s_subset_c,'2017']));
          # We manually split the IO for the sectors where we can't use the distribution in 2014
          vDEIO_y_2014_2016_ns146[{s_subset_r},not_s_subset_142,t]$(tData[t] and EDIO_y_dummy[{s_subset_r},not_s_subset_142,t])=vDEIO_y_2014_2016_ns146[{s_subset_r},not_s_subset_142,t]/CARD({s_subset_r});
          vDEIO_m_2014_2016_ns146[{s_subset_r},not_s_subset_142,t]$(tData[t] and EDIO_m_dummy[{s_subset_r},not_s_subset_142,t])=vDEIO_m_2014_2016_ns146[{s_subset_r},not_s_subset_142,t]/CARD({s_subset_r});
          vDEIO_y_2014_2016_ns146[{s_subset_r},not_s_subset_c,t]$(tData[t] and EIO_y_dummy[{s_subset_r},not_s_subset_c,t])=vDEIO_y_2014_2016_ns146[{s_subset_r},not_s_subset_c,t]/CARD({s_subset_r});
          vDEIO_m_2014_2016_ns146[{s_subset_r},not_s_subset_c,t]$(tData[t] and EIO_m_dummy[{s_subset_r},not_s_subset_c,t])=vDEIO_m_2014_2016_ns146[{s_subset_r},not_s_subset_c,t]/CARD({s_subset_r});
          $ENDFOR1
          # For each combination of a non-split row-sector and a split column-sector, the value is calculated
          $FOR {s_subset_c},{ss_subset_c} in [('s_350010_c','ss_350010_c'),('s_490030_c','ss_490030_c'),('s_500000_c','ss_500000_c'),('s_510000_c','ss_510000_c')]:
              vDEIO_y_2014_2016_ns146[not_s_subset_142,{s_subset_c},t]$(tData[t] and not EDIO_y_dummy[not_s_subset_142,{s_subset_c},t])=vDEIO_y_2014_2016_ns146[not_s_subset_142,{s_subset_c},t]*(vDEIO_y_2017_2019_ns146[not_s_subset_142,{s_subset_c},'2017']/(sum({ss_subset_c}, vDEIO_y_2017_2019_ns146[not_s_subset_142,{ss_subset_c},'2017'])))$(sum({ss_subset_c}, vDEIO_y_2017_2019_ns146[not_s_subset_142,{ss_subset_c},'2017']));
              vDEIO_m_2014_2016_ns146[not_s_subset_142,{s_subset_c},t]$(tData[t] and not EDIO_m_dummy[not_s_subset_142,{s_subset_c},t])=vDEIO_m_2014_2016_ns146[not_s_subset_142,{s_subset_c},t]*(vDEIO_m_2017_2019_ns146[not_s_subset_142,{s_subset_c},'2017']/(sum({ss_subset_c}, vDEIO_m_2017_2019_ns146[not_s_subset_142,{ss_subset_c},'2017'])))$(sum({ss_subset_c}, vDEIO_m_2017_2019_ns146[not_s_subset_142,{ss_subset_c},'2017']));
              vDEIO_y_2014_2016_ns146[not_s_subset_142,{s_subset_c},t]$(tData[t] and EDIO_y_dummy[not_s_subset_142,{s_subset_c},t])=vDEIO_y_2014_2016_ns146[not_s_subset_142,{s_subset_c},t]/CARD({s_subset_c});
              vDEIO_m_2014_2016_ns146[not_s_subset_142,{s_subset_c},t]$(tData[t] and EDIO_m_dummy[not_s_subset_142,{s_subset_c},t])=vDEIO_m_2014_2016_ns146[not_s_subset_142,{s_subset_c},t]/CARD({s_subset_c});
          $ENDFOR

          #--------------------------------------------------------------------------------------------------------------------
          #  vEIO_a_2012_2013
          #--------------------------------------------------------------------------------------------------------------------
          $FOR {s_subset_c},{ss_subset_c} in [('s_350010_c','ss_350010_c'),('s_490030_c','ss_490030_c'),('s_500000_c','ss_500000_c'),('s_510000_c','ss_510000_c')]:
            vDEIO_a_2014_2016_ns146[a_rows,{s_subset_c},t]$(tData[t] and not EDIO_a_dummy[a_rows,{s_subset_c},t]) = vDEIO_a_2014_2016_ns146[a_rows,{s_subset_c},t]*(vDEIO_a_2017_2019_ns146[a_rows,{s_subset_c},'2017']/sum({ss_subset_c},vDEIO_a_2017_2019_ns146[a_rows,{ss_subset_c},'2017']))$(sum({ss_subset_c},vDEIO_a_2017_2019_ns146[a_rows,{ss_subset_c},'2017']));
            # We manually split the IO for the sectors where we can't use the distribution in 2014
            vDEIO_a_2014_2016_ns146[a_rows,{s_subset_c},t]$(tData[t] and EDIO_a_dummy[a_rows,{s_subset_c},t]) = vDEIO_a_2014_2016_ns146[a_rows,{s_subset_c},t]/CARD({s_subset_c});
          $ENDFOR

          #--------------------------------------------------------------------------------------------------------------------
          #  Merging the 2014-2016 146-sector data with the 2017-2019 146-sector data 
          #--------------------------------------------------------------------------------------------------------------------
          vDEIO_y_2017_2019_ns146[ns146_r,IO_146_c,'2014'] = vDEIO_y_2014_2016_ns146[ns146_r,IO_146_c,'2014'];
          vDEIO_y_2017_2019_ns146[ns146_r,IO_146_c,'2015'] = vDEIO_y_2014_2016_ns146[ns146_r,IO_146_c,'2015'];
          vDEIO_y_2017_2019_ns146[ns146_r,IO_146_c,'2016'] = vDEIO_y_2014_2016_ns146[ns146_r,IO_146_c,'2016'];
          vDEIO_m_2017_2019_ns146[ns146_r,IO_146_c,'2014'] = vDEIO_m_2014_2016_ns146[ns146_r,IO_146_c,'2014'];
          vDEIO_m_2017_2019_ns146[ns146_r,IO_146_c,'2015'] = vDEIO_m_2014_2016_ns146[ns146_r,IO_146_c,'2015']; 
          vDEIO_m_2017_2019_ns146[ns146_r,IO_146_c,'2016'] = vDEIO_m_2014_2016_ns146[ns146_r,IO_146_c,'2016']; 
          vDEIO_a_2017_2019_ns146[a_rows,IO_146_c,'2014']  = vDEIO_a_2014_2016_ns146[a_rows,IO_146_c,'2014'];
          vDEIO_a_2017_2019_ns146[a_rows,IO_146_c,'2015']  = vDEIO_a_2014_2016_ns146[a_rows,IO_146_c,'2015'];
          vDEIO_a_2017_2019_ns146[a_rows,IO_146_c,'2016']  = vDEIO_a_2014_2016_ns146[a_rows,IO_146_c,'2016'];

          #--------------------------------------------------------------------------------------------------------------------
          # Mapping from 146-sectors to 56-model sectors 
          #--------------------------------------------------------------------------------------------------------------------
          $PGROUP DEIO
                     vDEIO_y[s56_,IO_56_c_,t]                    "Production energy DIO 2014-2019"
                     vDEIO_m[s56_,IO_56_c_,t]                    "Import energy DIO 2014-2019"
                     vDEIO_a[a_rows_,IO_56_c_,t]                  "Other energy DIO 2014-2019"
           ;

          vDEIO_y[s56,IO_56_c,t]$(tData[t])                = sum((ns146_r,IO_146_c)$(ns146_2_s56(ns146_r,s56) and IO146_2_IOs(IO_146_c,IO_56_c)), vDEIO_y_2017_2019_ns146[ns146_r,IO_146_c,t])/(10**6);                   
          vDEIO_m[s56,IO_56_c,t]$(tData[t])                = sum((ns146_r,IO_146_c)$(ns146_2_s56(ns146_r,s56) and IO146_2_IOs(IO_146_c,IO_56_c)), vDEIO_m_2017_2019_ns146[ns146_r,IO_146_c,t])/(10**6);                   
          vDEIO_a[a_rows,IO_56_c,t]$(tData[t])             = sum(IO_146_c$(IO146_2_IOs(IO_146_c,IO_56_c)), vDEIO_a_2017_2019_ns146[a_rows,IO_146_c,t])/(10**6);                   

          #Totaler 
          vDEIO_y['tot',IO_56_c,t]$(tData[t])              = sum(s56, vDEIO_y[s56,IO_56_c,t]);
          vDEIO_m['tot',IO_56_c,t]$(tData[t])              = sum(s56, vDEIO_m[s56,IO_56_c,t]);

          vDEIO_y[s56,'tot',t]$(tData[t])                  = sum(IO_56_c, vDEIO_y[s56,IO_56_c,t]);
          vDEIO_m[s56,'tot',t]$(tData[t])                  = sum(IO_56_c, vDEIO_m[s56,IO_56_c,t]);
          vDEIO_a[a_rows,'tot',t]$(tData[t])               = sum(IO_56_c, vDEIO_a[a_rows,IO_56_c,t]);



        #--------------------------------------------------------------------------------------------------------------------
        # Construction of Energy IO in 2012-2013 (based on the IO in 2012-2013 and the relation between the IO and Energy IO in 2014)
        #--------------------------------------------------------------------------------------------------------------------
          vEIO_y_2017_2019_ns146[ns146_r,IO_146_c,'2012']$(vEIO_y_2017_2019_ns146[ns146_r,IO_146_c,'2014']) = (vEIO_y_2017_2019_ns146[ns146_r,IO_146_c,'2014']/vIO_y_2014_2019_ns146[ns146_r,IO_146_c,'2014'])*vIO_y_2014_2019_ns146[ns146_r,IO_146_c,'2012'];
          vEIO_y_2017_2019_ns146[ns146_r,IO_146_c,'2013']$(vEIO_y_2017_2019_ns146[ns146_r,IO_146_c,'2014']) = (vEIO_y_2017_2019_ns146[ns146_r,IO_146_c,'2014']/vIO_y_2014_2019_ns146[ns146_r,IO_146_c,'2014'])*vIO_y_2014_2019_ns146[ns146_r,IO_146_c,'2013'];
          vEIO_m_2017_2019_ns146[ns146_r,IO_146_c,'2012']$(vEIO_m_2017_2019_ns146[ns146_r,IO_146_c,'2014']) = (vEIO_m_2017_2019_ns146[ns146_r,IO_146_c,'2014']/vIO_m_2014_2019_ns146[ns146_r,IO_146_c,'2014'])*vIO_m_2014_2019_ns146[ns146_r,IO_146_c,'2012'];
          vEIO_m_2017_2019_ns146[ns146_r,IO_146_c,'2013']$(vEIO_m_2017_2019_ns146[ns146_r,IO_146_c,'2014']) = (vEIO_m_2017_2019_ns146[ns146_r,IO_146_c,'2014']/vIO_m_2014_2019_ns146[ns146_r,IO_146_c,'2014'])*vIO_m_2014_2019_ns146[ns146_r,IO_146_c,'2013'];
          vEIO_a_2017_2019_ns146[a_rows,IO_146_c,'2012']$(vEIO_a_2017_2019_ns146[a_rows,IO_146_c,'2014'])   = (vEIO_a_2017_2019_ns146[a_rows,IO_146_c,'2014']/vIO_a_2014_2019_ns146[a_rows,IO_146_c,'2014'])*vIO_a_2014_2019_ns146[a_rows,IO_146_c,'2012'];
          vEIO_a_2017_2019_ns146[a_rows,IO_146_c,'2013']$(vEIO_a_2017_2019_ns146[a_rows,IO_146_c,'2014'])   = (vEIO_a_2017_2019_ns146[a_rows,IO_146_c,'2014']/vIO_a_2014_2019_ns146[a_rows,IO_146_c,'2014'])*vIO_a_2014_2019_ns146[a_rows,IO_146_c,'2013'];
          
          vEIO_m[s56,IO_56_c,t]$(tData[t])      = sum((ns146_r,IO_146_c)$(ns146_2_s56(ns146_r,s56) and IO146_2_IOs(IO_146_c,IO_56_c)), vEIO_m_2017_2019_ns146[ns146_r,IO_146_c,t])/(10**6);                   
          vEIO_y[s56,IO_56_c,t]$(tData[t])      = sum((ns146_r,IO_146_c)$(ns146_2_s56(ns146_r,s56) and IO146_2_IOs(IO_146_c,IO_56_c)), vEIO_y_2017_2019_ns146[ns146_r,IO_146_c,t])/(10**6);             
          vEIO_a[a_rows,IO_56_c,t]$(tData[t])   = sum(IO_146_c$(IO146_2_IOs(IO_146_c,IO_56_c)), vEIO_a_2017_2019_ns146[a_rows,IO_146_c,t])/(10**6);                   


          vDEIO_y_2017_2019_ns146[ns146_r,IO_146_c,'2012']$(vDEIO_y_2017_2019_ns146[ns146_r,IO_146_c,'2014']) = (vDEIO_y_2017_2019_ns146[ns146_r,IO_146_c,'2014']/vDIO_y_2014_2019_ns146[ns146_r,IO_146_c,'2014'])*vDIO_y_2014_2019_ns146[ns146_r,IO_146_c,'2012'];
          vDEIO_y_2017_2019_ns146[ns146_r,IO_146_c,'2013']$(vDEIO_y_2017_2019_ns146[ns146_r,IO_146_c,'2014']) = (vDEIO_y_2017_2019_ns146[ns146_r,IO_146_c,'2014']/vDIO_y_2014_2019_ns146[ns146_r,IO_146_c,'2014'])*vDIO_y_2014_2019_ns146[ns146_r,IO_146_c,'2013'];
          vDEIO_m_2017_2019_ns146[ns146_r,IO_146_c,'2012']$(vDEIO_m_2017_2019_ns146[ns146_r,IO_146_c,'2014']) = (vDEIO_m_2017_2019_ns146[ns146_r,IO_146_c,'2014']/vDIO_m_2014_2019_ns146[ns146_r,IO_146_c,'2014'])*vDIO_m_2014_2019_ns146[ns146_r,IO_146_c,'2012'];
          vDEIO_m_2017_2019_ns146[ns146_r,IO_146_c,'2013']$(vDEIO_m_2017_2019_ns146[ns146_r,IO_146_c,'2014']) = (vDEIO_m_2017_2019_ns146[ns146_r,IO_146_c,'2014']/vDIO_m_2014_2019_ns146[ns146_r,IO_146_c,'2014'])*vDIO_m_2014_2019_ns146[ns146_r,IO_146_c,'2013'];
          vDEIO_a_2017_2019_ns146[a_rows,IO_146_c,'2012']$(vDEIO_a_2017_2019_ns146[a_rows,IO_146_c,'2014'])   = (vDEIO_a_2017_2019_ns146[a_rows,IO_146_c,'2014']/vDIO_a_2014_2019_ns146[a_rows,IO_146_c,'2014'])*vDIO_a_2014_2019_ns146[a_rows,IO_146_c,'2012'];
          vDEIO_a_2017_2019_ns146[a_rows,IO_146_c,'2013']$(vDEIO_a_2017_2019_ns146[a_rows,IO_146_c,'2014'])   = (vDEIO_a_2017_2019_ns146[a_rows,IO_146_c,'2014']/vDIO_a_2014_2019_ns146[a_rows,IO_146_c,'2014'])*vDIO_a_2014_2019_ns146[a_rows,IO_146_c,'2013'];
          
          vDEIO_y[s56,IO_56_c,t]$(tData[t])     = sum((ns146_r,IO_146_c)$(ns146_2_s56(ns146_r,s56) and IO146_2_IOs(IO_146_c,IO_56_c)), vDEIO_y_2017_2019_ns146[ns146_r,IO_146_c,t])/(10**6);                   
          vDEIO_m[s56,IO_56_c,t]$(tData[t])     = sum((ns146_r,IO_146_c)$(ns146_2_s56(ns146_r,s56) and IO146_2_IOs(IO_146_c,IO_56_c)), vDEIO_m_2017_2019_ns146[ns146_r,IO_146_c,t])/(10**6);                   
          vDEIO_a[a_rows,IO_56_c,t]$(tData[t])  = sum(IO_146_c$(IO146_2_IOs(IO_146_c,IO_56_c)), vDEIO_a_2017_2019_ns146[a_rows,IO_146_c,t])/(10**6);                   

  #==============================================================================================================================================================#
  # IO-behandling
  #==============================================================================================================================================================#
  
    $PGROUP IOxE
      vIOxE_y[s56_,IO_56_c_,t]  "Non-energy IO of domestic production"
      vIOxE_m[s56_,IO_56_c_,t]  ""
      vIOxE_a[a_rows_,IO_56_c_,t] "" 
      vIOxE_cus[s56_,IO_56_c_,t] ""

      testIOxE[s56_,t] ""
    
      vDIOxE_y[s56_,IO_56_c_,t] ""
      vDIOxE_m[s56_,IO_56_c_,t] ""
      vDIOxE_a[a_rows_,IO_56_c_,t] ""
      vDIOxE_cus[s56_,IO_56_c_,t] ""

    ;

    $PGROUP NonSense
      Nonsense_vIOxE_y[s56_,IO_56_c_,t] ""
      Nonsense_vIOxE_m[s56_,IO_56_c_,t] ""
    ;

   #Uspecificerede import fordeles på importbrancher
    vIO_m[r56,s56,t]$(tData[t])            = vIO_m[r56,s56,t] + sum(a_rows_num5$a_rows_num52s56(a_rows_num5,r56), vIO_a[a_rows_num5,s56,t]);
    vIO_a[a_rows_num5,s56,t]$(tData[t])    = 0;

    vDIO_m[r56,s56,t]$(tData[t])           = vDIO_m[r56,s56,t]            + sum(a_rows_num5$a_rows_num52s56(a_rows_num5,r56), vDIO_a[a_rows_num5,s56,t]);
    vDIO_a[a_rows_num5,s56,t]$(tData[t])   = 0;

    vEIO_m[r56,s56,t]$(tData[t])           = vEIO_m[r56,s56,t]             +  sum(a_rows_num5$a_rows_num52s56(a_rows_num5,r56), vEIO_a[a_rows_num5,s56,t]);
    vEIO_a[a_rows_num5,s56,t]$(tData[t])   = 0;

    vDEIO_m[r56,s56,t]$(tData[t])          = vDEIO_m[r56,s56,t] + sum(a_rows_num5$a_rows_num52s56(a_rows_num5,r56), vDEIO_a[a_rows_num5,s56,t]);
    vDEIO_a[a_rows_num5,s56,t]$(tData[t])  = 0;

    vIO_m[r56,IO_56_c_notS56,t]$(tData[t]) = vIO_m[r56,IO_56_c_notS56,t] + sum(a_rows_num5xTur$a_rows_num52s56(a_rows_num5xTur,r56), vIO_a[a_rows_num5xTur,IO_56_c_notS56,t]);
    vIO_a[a_rows_num5xTur,IO_56_c_notS56,t]$(tData[t])   = 0;

    vDIO_m[r56,IO_56_c_notS56,t]$(tData[t])           = vDIO_m[r56,IO_56_c_notS56,t]            + sum(a_rows_num5xTur$a_rows_num52s56(a_rows_num5xTur,r56), vDIO_a[a_rows_num5xTur,IO_56_c_notS56,t]);
    vDIO_a[a_rows_num5xTur,IO_56_c_notS56,t]$(tData[t])  = 0;

    vEIO_m[r56,IO_56_c_notS56,t]$(tData[t])           = vEIO_m[r56,IO_56_c_notS56,t]             +  sum(a_rows_num5xTur$a_rows_num52s56(a_rows_num5xTur,r56), vEIO_a[a_rows_num5xTur,IO_56_c_notS56,t]);
    vEIO_a[a_rows_num5xTur,IO_56_c_notS56,t]$(tData[t])  = 0;

    vDEIO_m[r56,IO_56_c_notS56,t]$(tData[t])          = vDEIO_m[r56,IO_56_c_notS56,t] + sum(a_rows_num5xTur$a_rows_num52s56(a_rows_num5xTur,r56), vDEIO_a[a_rows_num5xTur,IO_56_c_notS56,t]);
    vDEIO_a[a_rows_num5xTur,IO_56_c_notS56,t]$(tData[t]) = 0;


    # DATA check
    #  PARAMETERS IO_sum[t], DIO_sum[t], EIO_sum[t], EDIO_sum[t];
    #  IO_sum[t]   = sum((s56,IO_56_c), vIO_y[s56,IO_56_c,t] + vIO_m[s56,IO_56_c,t]) + sum((a_rows,IO_56_c), vIO_a[a_rows,IO_56_c,t]); 
    #  DIO_sum[t]  = sum((s56,IO_56_c), vDIO_y[s56,IO_56_c,t] + vDIO_m[s56,IO_56_c,t]) + sum((a_rows,IO_56_c), vDIO_a[a_rows,IO_56_c,t]); 
    #  EIO_sum[t]  = sum((s56,IO_56_c), vEIO_y[s56,IO_56_c,t] + vEIO_m[s56,IO_56_c,t]) + sum((a_rows,IO_56_c), vEIO_a[a_rows,IO_56_c,t]); 
    #  EDIO_sum[t] = sum((s56,IO_56_c), vDEIO_y[s56,IO_56_c,t] + vDEIO_m[s56,IO_56_c,t]) + sum((a_rows,IO_56_c), vDEIO_a[a_rows,IO_56_c,t]); 

    #  PARAMETERS IO_sum_data_2012_2013[t], DIO_sum_data_2012_2013[t], EIO_sum_data_2014_2016[t], EDIO_sum_data_2014_2016[t];
    #  IO_sum_data_2012_2013[t] = sum((ns117_r,IO_117_c), vIO_y_2012_2013_ns117[ns117_r,IO_117_c,t] + vIO_m_2012_2013_ns117[ns117_r,IO_117_c,t]) + sum((a_rows,IO_117_c), vIO_a_2012_2013_ns117[a_rows,IO_117_c,t]); 
    #  DIO_sum_data_2012_2013[t] = sum((ns117_r,IO_117_c), vDIO_y_2012_2013_ns117[ns117_r,IO_117_c,t] + vDIO_m_2012_2013_ns117[ns117_r,IO_117_c,t]) + sum((a_rows,IO_117_c), vDIO_a_2012_2013_ns117[a_rows,IO_117_c,t]); 
    #  EIO_sum_data_2014_2016[t] = sum((ns142_r,IO_142_c),  vEIO_y_2014_2016_ns142[ns142_r,IO_142_c,t] +  vEIO_m_2014_2016_ns142[ns142_r,IO_142_c,t]) + sum((a_rows,IO_142_c), vEIO_a_2014_2016_ns142[a_rows,IO_142_c,t]); 
    #  EDIO_sum_data_2014_2016[t] = sum((ns142_r,IO_142_c),  vDEIO_y_2014_2016_ns142[ns142_r,IO_142_c,t] +  vDEIO_m_2014_2016_ns142[ns142_r,IO_142_c,t]) + sum((a_rows,IO_142_c), vDEIO_a_2014_2016_ns142[a_rows,IO_142_c,t]);
    
    #  PARAMETERS IO_sum_data_2014_2019[t], DIO_sum_data_2014_2019[t], EIO_sum_data_2017_2019[t], EDIO_sum_data_2017_2019[t];
    #  IO_sum_data_2014_2019[t] = sum((ns146,IO_146_c), vIO_y_2014_2019_ns146[ns146,IO_146_c,t] + vIO_m_2014_2019_ns146[ns146,IO_146_c,t]) + sum((a_rows,IO_146_c), vIO_a_2014_2019_ns146[a_rows,IO_146_c,t]); 
    #  DIO_sum_data_2014_2019[t] = sum((ns146,IO_146_c), vDIO_y_2014_2019_ns146[ns146,IO_146_c,t] + vDIO_m_2014_2019_ns146[ns146,IO_146_c,t]) + sum((a_rows,IO_146_c), vDIO_a_2014_2019_ns146[a_rows,IO_146_c,t]); 
    #  EIO_sum_data_2017_2019[t] = sum((ns146,IO_146_c), vEIO_y_2017_2019_ns146[ns146,IO_146_c,t] + vEIO_m_2017_2019_ns146[ns146,IO_146_c,t]) + sum((a_rows,IO_146_c), vEIO_a_2017_2019_ns146[a_rows,IO_146_c,t]); 
    #  EDIO_sum_data_2017_2019[t] = sum((ns146,IO_146_c), vDEIO_y_2017_2019_ns146[ns146,IO_146_c,t] + vDEIO_m_2017_2019_ns146[ns146,IO_146_c,t]) + sum((a_rows,IO_146_c), vDEIO_a_2017_2019_ns146[a_rows,IO_146_c,t]); 


  #Turister særbehandles 
    $FOR {V} in ['v','vD']:
      $FOR1 {IO} in ['IO','EIO']:
        #Danske turisters forbrug i udlandet antages at trække på den udenlandske service sektor 
        {V}{IO}_m['55560','cTou',t] = {V}{IO}_a['Turisme','cTou',t]; {V}{IO}_a['Turisme','cTou',t] = 0;  #{V}{IO}_a['Turisme','tot',t] = 0;
      $ENDFOR1 
    $ENDFOR

  $IF %smaagrisesplit%:
  #Svin. Flytter al svinebrug til 01051  domænet. Denne total splittes derefter på smågrise (01051) og slagtesvin (01052)
    #  vIO_y[s56_,IO_56_c_,t]     
    #  vIO_m[s56_,IO_56_c_,t]     
    #  vIO_a[a_rows_,IO_56_c_,t]  
    #  vIO_cus[s56_,IO_56_c_,t]   
    #  vDIO_y[s56_,IO_56_c_,t]    
    #  vDIO_m[s56_,IO_56_c_,t]    
    #  vDIO_a[a_rows_,IO_56_c_,t] 
    #  vDIO_cus[s56_,IO_56_,t]   

     vIO_y['01051',IO_56_c_,t]     =      vIO_y['01051',IO_56_c_,t]     +vIO_y['01052',IO_56_c_,t]    ;vIO_y['01052',IO_56_c_,t]   = 0;
     vIO_m['01051',IO_56_c_,t]     =      vIO_m['01051',IO_56_c_,t]     +vIO_m['01052',IO_56_c_,t]    ;vIO_m['01052',IO_56_c_,t]   = 0;
    #  vIO_a[a_rows_,IO_56_c_,t]     =      vIO_a[a_rows_,IO_56_c_,t]     +vIO_a[a_rows_,IO_56_c_,t]    ;vIO_a[a_rows_,IO_56_c_,t]   = 0;
     vIO_cus['01051',IO_56_c_,t]   =      vIO_cus['01051',IO_56_c_,t]   +vIO_cus['01052',IO_56_c_,t]  ;vIO_cus['01052',IO_56_c_,t] = 0;
     vDIO_y['01051',IO_56_c_,t]    =      vDIO_y['01051',IO_56_c_,t]    +vDIO_y['01052',IO_56_c_,t]   ;vDIO_y['01052',IO_56_c_,t]  = 0;
     vDIO_m['01051',IO_56_c_,t]    =      vDIO_m['01051',IO_56_c_,t]    +vDIO_m['01052',IO_56_c_,t]   ;vDIO_m['01052',IO_56_c_,t]  = 0;
    #  vDIO_a[a_rows_,IO_56_c_,t]    =      vDIO_a[a_rows_,IO_56_c_,t]    +vDIO_a[a_rows_,IO_56_c_,t]   ;vDIO_a[a_rows_,IO_56_c_,t]  = 0;
    #  vDIO_cus['01051',IO_56_,t]    =      vDIO_cus['01051',IO_56_,t]    +vDIO_cus['01052',IO_56_,t]   ;vDIO_cus['01052',IO_56_,t]  = 0;

     vIO_y[s56_,'01051',t]     =      vIO_y[s56_,'01051',t]      +      vIO_y[s56_,'01052',t]     ; vIO_y[s56_,'01052',t]     = 0;
     vIO_m[s56_,'01051',t]     =      vIO_m[s56_,'01051',t]      +      vIO_m[s56_,'01052',t]     ; vIO_m[s56_,'01052',t]     = 0;
     vIO_a[a_rows_,'01051',t]  =      vIO_a[a_rows_,'01051',t]   +      vIO_a[a_rows_,'01052',t]  ; vIO_a[a_rows_,'01052',t]  = 0;
     vIO_cus[s56_,'01051',t]   =      vIO_cus[s56_,'01051',t]    +      vIO_cus[s56_,'01052',t]   ; vIO_cus[s56_,'01052',t]   = 0;
     vDIO_y[s56_,'01051',t]    =      vDIO_y[s56_,'01051',t]     +      vDIO_y[s56_,'01052',t]    ; vDIO_y[s56_,'01052',t]    = 0;
     vDIO_m[s56_,'01051',t]    =      vDIO_m[s56_,'01051',t]     +      vDIO_m[s56_,'01052',t]    ; vDIO_m[s56_,'01052',t]    = 0;
     vDIO_a[a_rows_,'01051',t] =      vDIO_a[a_rows_,'01051',t]  +      vDIO_a[a_rows_,'01052',t] ; vDIO_a[a_rows_,'01052',t] = 0;
    #  vDIO_cus[s56_,'01051',t]   =      vDIO_cus[s56_,'01051',t]  +      vDIO_cus[s56_,'01052',t]   ; vDIO_cus[s56_,'01052',t]  = 0;

     vEIO_y['01051',IO_56_c_,t]     =      vEIO_y['01051',IO_56_c_,t]     +vEIO_y['01052',IO_56_c_,t]    ;vEIO_y['01052',IO_56_c_,t]   = 0;
     vEIO_m['01051',IO_56_c_,t]     =      vEIO_m['01051',IO_56_c_,t]     +vEIO_m['01052',IO_56_c_,t]    ;vEIO_m['01052',IO_56_c_,t]   = 0;
    #  vEIO_a[a_rows_,IO_56_c_,t]     =      vEIO_a[a_rows_,IO_56_c_,t]     +vEIO_a[a_rows_,IO_56_c_,t]    ;vEIO_a[a_rows_,IO_56_c_,t]   = 0;
     vEIO_cus['01051',IO_56_c_,t]   =      vEIO_cus['01051',IO_56_c_,t]   +vEIO_cus['01052',IO_56_c_,t]  ;vEIO_cus['01052',IO_56_c_,t] = 0;
     vDEIO_y['01051',IO_56_c_,t]    =      vDEIO_y['01051',IO_56_c_,t]    +vDEIO_y['01052',IO_56_c_,t]   ;vDEIO_y['01052',IO_56_c_,t]  = 0;
     vDEIO_m['01051',IO_56_c_,t]    =      vDEIO_m['01051',IO_56_c_,t]    +vDEIO_m['01052',IO_56_c_,t]   ;vDEIO_m['01052',IO_56_c_,t]  = 0;
    #  vDEIO_a[a_rows_,IO_56_c_,t]    =      vDEIO_a[a_rows_,IO_56_c_,t]    +vDEIO_a[a_rows_,IO_56_c_,t]   ;vDEIO_a[a_rows_,IO_56_c_,t]  = 0;
    #  vDEIO_cus['01051',IO_56_,t]    =      vDEIO_cus['01051',IO_56_,t]    +vDEIO_cus['01052',IO_56_,t]   ;vDEIO_cus['01052',IO_56_,t]  = 0;

     vEIO_y[s56_,'01051',t]     =      vEIO_y[s56_,'01051',t]      +      vEIO_y[s56_,'01052',t]     ; vEIO_y[s56_,'01052',t]     = 0;
     vEIO_m[s56_,'01051',t]     =      vEIO_m[s56_,'01051',t]      +      vEIO_m[s56_,'01052',t]     ; vEIO_m[s56_,'01052',t]     = 0;
     vEIO_a[a_rows_,'01051',t]  =      vEIO_a[a_rows_,'01051',t]   +      vEIO_a[a_rows_,'01052',t]  ; vEIO_a[a_rows_,'01052',t]  = 0;
     vEIO_cus[s56_,'01051',t]   =      vEIO_cus[s56_,'01051',t]    +      vEIO_cus[s56_,'01052',t]   ; vEIO_cus[s56_,'01052',t]   = 0;
     vDEIO_y[s56_,'01051',t]    =      vDEIO_y[s56_,'01051',t]     +      vDEIO_y[s56_,'01052',t]    ; vDEIO_y[s56_,'01052',t]    = 0;
     vDEIO_m[s56_,'01051',t]    =      vDEIO_m[s56_,'01051',t]     +      vDEIO_m[s56_,'01052',t]    ; vDEIO_m[s56_,'01052',t]    = 0;
     vDEIO_a[a_rows_,'01051',t] =      vDEIO_a[a_rows_,'01051',t]  +      vDEIO_a[a_rows_,'01052',t] ; vDEIO_a[a_rows_,'01052',t] = 0;
    #  vDIO_cus[s56_,'01051',t]   =      vDIO_cus[s56_,'01051',t]    +      vDIO_cus[s56_,'01052',t]   ; vDIO_cus[s56_,'01052',t]  = 0;

     vIO_I[i,'01051',t]$(tData[t])  = vIO_I[i,'01051',t] + vIO_I[i,'01052',t]; vIO_I[i,'01052',t]= 0;
     vDIO_I[i,'01051',t]$(tData[t]) = vDIO_I[i,'01051',t] + vDIO_I[i,'01052',t]; vDIO_I[i,'01052',t]= 0;
     vIO_K[i,'01051',t]$(tData[t])  = vIO_K[i,'01051',t] + vIO_K[i,'01052',t]; vIO_K[i,'01052',t]= 0;
     vDIO_K[i,'01051',t]$(tData[t]) = vDIO_K[i,'01051',t] + vDIO_K[i,'01052',t]; vDIO_K[i,'01052',t]= 0;

     vAfgxE_56_y['01051',IO_56_c_,afgsub,t] = vAfgxE_56_y['01051',IO_56_c_,afgsub,t] + vAfgxE_56_y['01052',IO_56_c_,afgsub,t]; vAfgxE_56_y['01052',IO_56_c_,afgsub,t] = 0; 
     vAfgxE_56_m['01051',IO_56_c_,afgsub,t] = vAfgxE_56_m['01051',IO_56_c_,afgsub,t] + vAfgxE_56_m['01052',IO_56_c_,afgsub,t]; vAfgxE_56_m['01052',IO_56_c_,afgsub,t] = 0; 
     vSubxE_56_y['01051',IO_56_c_,afgsub,t] = vSubxE_56_y['01051',IO_56_c_,afgsub,t] + vSubxE_56_y['01052',IO_56_c_,afgsub,t]; vSubxE_56_y['01052',IO_56_c_,afgsub,t] = 0; 
     vSubxE_56_m['01051',IO_56_c_,afgsub,t] = vSubxE_56_m['01051',IO_56_c_,afgsub,t] + vSubxE_56_m['01052',IO_56_c_,afgsub,t]; vSubxE_56_m['01052',IO_56_c_,afgsub,t] = 0; 

     vAfgxE_56_y[s56_,'01051',afgsub,t] = vAfgxE_56_y[s56_,'01051',afgsub,t] + vAfgxE_56_y[s56_,'01052',afgsub,t]; vAfgxE_56_y[s56_,'01052',afgsub,t] = 0;  
     vAfgxE_56_m[s56_,'01051',afgsub,t] = vAfgxE_56_m[s56_,'01051',afgsub,t] + vAfgxE_56_m[s56_,'01052',afgsub,t]; vAfgxE_56_m[s56_,'01052',afgsub,t] = 0;  
     vSubxE_56_y[s56_,'01051',afgsub,t] = vSubxE_56_y[s56_,'01051',afgsub,t] + vSubxE_56_y[s56_,'01052',afgsub,t]; vSubxE_56_y[s56_,'01052',afgsub,t] = 0;  
     vSubxE_56_m[s56_,'01051',afgsub,t] = vSubxE_56_m[s56_,'01051',afgsub,t] + vSubxE_56_m[s56_,'01052',afgsub,t]; vSubxE_56_m[s56_,'01052',afgsub,t] = 0;  

     #Booster Slagtesvin (01051 -> 01052) cellen, jf.mail fra Asger 

     vIO_y['01051','01051',t] = 7.8;
     vDIO_y['01051','01051',t] = 7.8/1.01;


  $ENDIF

  #I energiIO er der nogle meget små leverancer af energi fra kemibranchen. Det er der ikke i energistatistikkerne. Dette flyttes derfor til ikke-energi IO 
    #Lav ikke-energi IO 
    vIOxE_y[s56_,IO_56_c_,t]$(tData[t])      = vIO_y[s56_,IO_56_c_,t]     - vEIO_y[s56_,IO_56_c_,t];  
    vIOxE_m[s56_,IO_56_c_,t]$(tData[t])      = vIO_m[s56_,IO_56_c_,t]     - vEIO_m[s56_,IO_56_c_,t]; 
    vIOxE_a[a_rows_,IO_56_c_,t]$(tData[t])   = vIO_a[a_rows_,IO_56_c_,t]  - vEIO_a[a_rows_,IO_56_c_,t];
    vIOxE_cus[s56_,IO_56_c_,t]$(tData[t])    = vIO_cus[s56_,IO_56_c_,t]   - vEIO_cus[s56_,IO_56_c_,t];

    #I forrige års priser
    vDIOxE_y[s56_,IO_56_c_,t]$(tData[t])     = vDIO_y[s56_,IO_56_c_,t]    - vDEIO_y[s56_,IO_56_c_,t];  
    vDIOxE_m[s56_,IO_56_c_,t]$(tData[t])     = vDIO_m[s56_,IO_56_c_,t]    - vDEIO_m[s56_,IO_56_c_,t]; 
    vDIOxE_a[a_rows_,IO_56_c_,t]$(tData[t])  = vDIO_a[a_rows_,IO_56_c_,t] - vDEIO_a[a_rows_,IO_56_c_,t];
    #  vDIOxE_Cus[s56_,IO_56_c_,t]$(tData[t])   = vDIO_cus[s56_,IO_56_,t]    - vEIO_cus[s56_,IO_56_,t];


   $FUNCTION computeIO(): 
    vIO_y[s56_,IO_56_c_,t]$(tData[t])      = vIOxE_y[s56_,IO_56_c_,t]     + vEIO_y[s56_,IO_56_c_,t];  
    vIO_m[s56_,IO_56_c_,t]$(tData[t])      = vIOxE_m[s56_,IO_56_c_,t]     + vEIO_m[s56_,IO_56_c_,t]; 
    vIO_a[a_rows_,IO_56_c_,t]$(tData[t])   = vIOxE_a[a_rows_,IO_56_c_,t]  +  vEIO_a[a_rows_,IO_56_c_,t];

    #I forrige års priser
    vDIO_y[s56_,IO_56_c_,t]$(tData[t])     = vDIOxE_y[s56_,IO_56_c_,t]    + vDEIO_y[s56_,IO_56_c_,t];  
    vDIO_m[s56_,IO_56_c_,t]$(tData[t])     = vDIOxE_m[s56_,IO_56_c_,t]    + vDEIO_m[s56_,IO_56_c_,t]; 
    vDIO_a[a_rows_,IO_56_c_,t]$(tData[t])  = vDIOxE_a[a_rows_,IO_56_c_,t] +  vDEIO_a[a_rows_,IO_56_c_,t];


    #Totaler
    vIO_y['tot',IO_56_c,t]$(tData[t])    = sum(s56, vIO_y[s56,IO_56_c,t]);
    vIO_m['tot',IO_56_c,t]$(tData[t])    = sum(s56, vIO_m[s56,IO_56_c,t]);
    vIO_a['tot',IO_56_c,t]$(tData[t])    = sum(a_rows, vIO_a[a_rows,IO_56_c,t]);

    vIO_y[s56,'tot',t]$(tData[t])        = sum(IO_56_c, vIO_y[s56,IO_56_c,t]);
    vIO_m[s56,'tot',t]$(tData[t])        = sum(IO_56_c, vIO_m[s56,IO_56_c,t]);
    vIO_a[a_rows,'tot',t]$(tData[t])     = sum(IO_56_c, vIO_a[a_rows,IO_56_c,t]);
 
    vDIO_y['tot',IO_56_c,t]$(tData[t])   = sum(s56, vDIO_y[s56,IO_56_c,t]);
    vDIO_m['tot',IO_56_c,t]$(tData[t])   = sum(s56, vDIO_m[s56,IO_56_c,t]);
    vDIO_a['tot',IO_56_c,t]$(tData[t])   = sum(a_rows, vDIO_a[a_rows,IO_56_c,t]);


    vDIO_y[s56,'tot',t]$(tData[t])       = sum(IO_56_c, vDIO_y[s56,IO_56_c,t]);
    vDIO_m[s56,'tot',t]$(tData[t])       = sum(IO_56_c, vDIO_m[s56,IO_56_c,t]);
    vDIO_a[a_rows,'tot',t]$(tData[t])    = sum(IO_56_c, vDIO_a[a_rows,IO_56_c,t]);
 
    vEIO_y['tot',IO_56_c,t]$(tData[t])   = sum(s56, vEIO_y[s56,IO_56_c,t]);
    vEIO_m['tot',IO_56_c,t]$(tData[t])   = sum(s56, vEIO_m[s56,IO_56_c,t]);
    vEIO_a['tot',IO_56_c,t]$(tData[t])   = sum(a_rows, vEIO_a[a_rows,IO_56_c,t]);


    vEIO_y[s56,'tot',t]$(tData[t])       = sum(IO_56_c, vEIO_y[s56,IO_56_c,t]);
    vEIO_m[s56,'tot',t]$(tData[t])       = sum(IO_56_c, vEIO_m[s56,IO_56_c,t]);
    vEIO_a[a_rows,'tot',t]$(tData[t])    = sum(IO_56_c, vEIO_a[a_rows,IO_56_c,t]);

    vDEIO_y['tot',IO_56_c,t]$(tData[t])  = sum(s56, vDEIO_y[s56,IO_56_c,t]);
    vDEIO_m['tot',IO_56_c,t]$(tData[t])  = sum(s56, vDEIO_m[s56,IO_56_c,t]);
    vDEIO_a['tot',IO_56_c,t]$(tData[t])  = sum(a_rows, vDEIO_a[a_rows,IO_56_c,t]);


    vDEIO_y[s56,'tot',t]$(tData[t])      = sum(IO_56_c, vDEIO_y[s56,IO_56_c,t]);
    vDEIO_m[s56,'tot',t]$(tData[t])      = sum(IO_56_c, vDEIO_m[s56,IO_56_c,t]);
    vDEIO_a[a_rows,'tot',t]$(tData[t])   = sum(IO_56_c, vDEIO_a[a_rows,IO_56_c,t]);

    vIOxE_y['tot',IO_56_c,t]$(tData[t])  = sum(s56, vIOxE_y[s56,IO_56_c,t]);
    vIOxE_m['tot',IO_56_c,t]$(tData[t])  = sum(s56, vIOxE_m[s56,IO_56_c,t]);
    vIOxE_a['tot',IO_56_c,t]$(tData[t])  = sum(a_rows, vIOxE_a[a_rows,IO_56_c,t]);

    vIOxE_y[s56,'tot',t]$(tData[t])      = sum(IO_56_c, vIOxE_y[s56,IO_56_c,t]);
    vIOxE_m[s56,'tot',t]$(tData[t])      = sum(IO_56_c, vIOxE_m[s56,IO_56_c,t]);
    vIOxE_a[a_rows,'tot',t]$(tData[t])   = sum(IO_56_c,  vIOxE_a[a_rows,IO_56_c,t]);

    
    vDIOxE_y['tot',IO_56_c,t]$(tData[t]) = sum(s56, vDIOxE_y[s56,IO_56_c,t]);
    vDIOxE_m['tot',IO_56_c,t]$(tData[t]) = sum(s56, vDIOxE_m[s56,IO_56_c,t]);
    vDIOxE_a['tot',IO_56_c,t]$(tData[t]) = sum(a_rows, vDIOxE_a[a_rows,IO_56_c,t]);

    vDIOxE_y[s56,'tot',t]$(tData[t])      = sum(IO_56_c, vDIOxE_y[s56,IO_56_c,t]);
    vDIOxE_m[s56,'tot',t]$(tData[t])      = sum(IO_56_c, vDIOxE_m[s56,IO_56_c,t]);
    vDIOxE_a[a_rows,'tot',t]$(tData[t])   = sum(IO_56_c,  vDIOxE_a[a_rows,IO_56_c,t]);


    Nonsense_vIOxE_y[s56_,IO_56_c_,t]$(tData[t] and vIO_y[s56_,IO_56_c_,t]<vEIO_y[s56_,IO_56_c_,t]) = 1; 
    Nonsense_vIOxE_m[s56_,IO_56_c_,t]$(tData[t] and vIO_m[s56_,IO_56_c_,t]<vEIO_m[s56_,IO_56_c_,t]) = 1; 


  $ENDFUNCTION 


  @computeIO();
  

  execute_unload 'Output/firstIO.gdx';
#---------------------------------------------------------------------------------------------
#  Opsplitter mineralogi
#---------------------------------------------------------------------------------------------

  $FOR {V} in ['v','vD']:
    $FOR1 {IO} in ['IOxE','EIO']:

    #INDENLANDSK
      #Produktionsværdier 
      {V}{IO}_y[sMineralogi56,'tot',t]$(tData[t])   = sYS56[sMineralogi56] * {V}{IO}_y['23001','tot',t];
      {V}{IO}_y[sMineralogi56,'xOth' ,t]$(tData[t]) = sXS56[sMineralogi56] * {V}{IO}_y['23001','xOth',t];

      #Mineralogibrancherne til sig selv på diagonalen 
      {V}{IO}_y[sMineralogi56,sMineralogi56_a,t]$(tData[t] and sameas[sMineralogi56,sMineralogi56_a]) = sYS56[sMineralogi56]        * {V}{IO}_y['23001','23001',t];


      #IMPORT 
      {V}{IO}_m[sMineralogi56,'tot',t]$(tData[t])  = sMS56[sMineralogi56] * {V}{IO}_m['23001','tot',t];

      #Mineralogibrancherne til sig selv på diagonalen 
      {V}{IO}_m[sMineralogi56,sMineralogi56_a,t]$(sameas[sMineralogi56,sMineralogi56_a]) = sMS56[sMineralogi56] * {V}{IO}_m['23001','23001',t];
      #  {V}{IO}_m['23002','23001',t]$(tData[t]) =  {V}{IO}_m['23001','23001',t]; {V}{IO}_m['23001','23001',t] = 0;




      $IF '{IO}' not in ['IOxE']: 
        #  {V}{IO}_y['tot',sMineralogi56,t]$(tData[t])    = sYS56[sMineralogi56]   * {V}{IO}_y['tot','23001',t];
        #  {V}{IO}_m['tot',sMineralogi56,t]$(tData[t])    = sYS56[sMineralogi56]   * {V}{IO}_m['tot','23001',t];
        #  {V}{IO}_a[a_rows,sMineralogi56,t]$(tData[t])   = sYS56[sMineralogi56]   * {V}{IO}_a[a_rows,'23001',t];   

        {V}{IO}_y['tot',sMineralogi56,t]$(tData[t])    = (0.25$(sameas[sMineralogi56,'23001']) + 0.75$(sameas[sMineralogi56,'23002']))   * {V}{IO}_y['tot','23001',t]; #AP uses roughly 25 pct. of energy 
        {V}{IO}_m['tot',sMineralogi56,t]$(tData[t])    = (0.25$(sameas[sMineralogi56,'23001']) + 0.75$(sameas[sMineralogi56,'23002']))   * {V}{IO}_m['tot','23001',t]; #AP uses roughly 25 pct. of energy 
        {V}{IO}_a[a_rows,sMineralogi56,t]$(tData[t])   = (0.25$(sameas[sMineralogi56,'23001']) + 0.75$(sameas[sMineralogi56,'23002']))   * {V}{IO}_a[a_rows,'23001',t];    #AP uses roughly 25 pct. of energy 


      $ENDIF 

      $IF '{IO}' in ['IOxE']:
        sCORR56['23001',t] = 0.063; sCORR56['23002',t] = 1-sCORR56['23001',t];
        {V}{IO}_y['tot',sMineralogi56,t]$(tData[t])  = sCORR56[sMineralogi56,t] * {V}{IO}_y['tot','23001',t];

        sCORR56['23001',t] = 0.063; sCORR56['23002',t] = 1-sCORR56['23001',t];
        {V}{IO}_m['tot',sMineralogi56,t]$(tData[t])  = sCORR56[sMineralogi56,t] * {V}{IO}_m['tot','23001',t];

        #  {V}{IO}_a['BVT','23002',t]$(tData[t])     = {V}{IO}_a['BVT','23001',t] -1.013776; {V}{IO}_a['BVT','23001',t]$(tData[t]) = 1.013776; 
        {V}{IO}_a['TURISME','23002',t]$(tData[t]) = {V}{IO}_a['TURISME','23001',t]; {V}{IO}_a['TURISME','23001',t]$(tData[t]) = 0;
        {V}{IO}_a['TaxSub','23002',t]$(tData[t])  = 0; 
        {V}{IO}_a['MOMS','23002',t]$(tData[t])    = {V}{IO}_a['MOMS','23001',t]; {V}{IO}_a['MOMS','23001',t]$(tData[t]) = 0;
        {V}{IO}_a['OthTax','23002',t]$(tData[t])  = {V}{IO}_a['OthTax','23001',t]-0.084*0.25; {V}{IO}_a['OthTax','23001',t]$(tData[t]) = 0.084*0.25; #25 pct. AP
        {V}{IO}_a['OthSub','23002',t]$(tData[t])  = {V}{IO}_a['OthSub','23001',t]; {V}{IO}_a['OthSub','23001',t]$(tData[t]) = 0;


        {V}{IO}_a['SalEmpl','23002',t]$(tData[t])    = {V}{IO}_a['SalEmpl','23002',t] + {V}{IO}_a['SalEmpl','23001',t] - 0.251;
        {V}{IO}_a['SalEmpl','23001',t]$(tData[t])    = 0.251;

        {V}{IO}_a['OvProd',sMineralogi56,t]$(tData[t])     = {V}{IO}_y[sMineralogi56,'tot',t] - {V}{IO}_y['tot',sMineralogi56,t] - {V}{IO}_m['tot',sMineralogi56,t] - sum(a_rows$(not sameas[a_rows,'OvProd']), {V}{IO}_a[a_rows,sMineralogi56,t]);

      $ENDIF

      #  {V}{IO}_a[a_rows,sMineralogi56,t]$(tData[t] and not sameas[a_rows,'SalEmpl']) = sYS56[sMineralogi56]   * {V}{IO}_a[a_rows,'23001',t];      
      #  {V}{IO}_a[a_rows,sMineralogi56,t]$(tData[t] and sameas[a_rows,'SalEmpl'])     = sLS56[sMineralogi56]   * {V}{IO}_a[a_rows,'23001',t];      


      #  {V}{IO}_a['tot',sMineralogi56,t]$(tData[t])  = sYS56[sMineralogi56]   * {V}{IO}_a['tot','23001',t];           
      #  {V}{IO}_a['tot',sMineralogi56,t]$(tData[t])  = sum(a_rows, {V}{IO}_a[a_rows,'23001',t]);           


      
      #Ud fra de her komponenter kan beregnes, hvilken andel de resterende IO-komponenter skal fordeles ift. for at rækkesummen passer 
        #Se eventuelt note "Afstemning af rækker i IO"
        #Korrigerer rækker af indenlandsk produktion fra mineralogi
        sCORR56[sMineralogi56,t]$(tDatax1[t] and (sum(IO_56_c_notMineralogiPlusEksport,{V}{IO}_y['23001',IO_56_c_notMineralogiPlusEksport,t]))) 
                           = ({V}{IO}_y[sMineralogi56,'tot',t] - sum(IO_56_c_MineralogiPlusEksport,{V}{IO}_y[sMineralogi56,IO_56_c_MineralogiPlusEksport,t]))
                            /(sum(IO_56_c_notMineralogiPlusEksport,{V}{IO}_y['23001',IO_56_c_notMineralogiPlusEksport,t]));  

        {V}{IO}_y[sMineralogi56,IO_56_c_notMineralogiPlusEksport,t]$(tDatax1[t]) = sCORR56[sMineralogi56,t] *  {V}{IO}_y['23001',IO_56_c_notMineralogiPlusEksport,t];


        #Herpå skal søjlerne afstemmes (Der er mange måder brøken kunne opstilles på med udgangspunkt i dataparametrene men nedenstående er valgt)
        #I tælleren er den totale søjlesum, minus mineralogi-til-mineralogi leverancer (dem rører vi ikke mere ved efter diagonalisering)
        #I nævneren er de totale leverancer, minus mineralogi-til-mineralogi.
        #I både tæller og nævner trækkes også lønsum ud, da vi vil fastholde denne til værdi fra nyt io-data, der skal indarbejdes i fremtidig modelversion
        #

        #  $IF '{V}'=='v':
        #  execute_unload 'output\pre.gdx';
        #  $ENDIF

        #  sCORR56[sMineralogi56,t]$(tDatax1[t]) = ({V}{IO}_y['tot',sMineralogi56,t] 
        #                                        +  {V}{IO}_m['tot',sMineralogi56,t]
        #                                        + sum(a_rows, {V}{IO}_a[a_rows,sMineralogi56,t]) 
        #                                        - sum(sMineralogi56_a, {V}{IO}_y[sMineralogi56_a,sMineralogi56,t])
        #                                        - sum(sMineralogi56_a, {V}{IO}_m[sMineralogi56_a,sMineralogi56,t])
                                             
        #                                       )
                                             
        #                                        /sum(sMineralogi56_a,(sum(sNotMineralogi56, {V}{IO}_y[sNotMineralogi56,sMineralogi56_a,t])
        #                                                           +  sum(sNotMineralogi56, {V}{IO}_m[sNotMineralogi56,sMineralogi56_a,t])
        #                                                           +  sum(a_rows, {V}{IO}_a[a_rows,sMineralogi56_a,t])
        #                                                             )
        #                                                           );
   

        $IF '{IO}' not in ['IOxE']:
          sCORR56[sMineralogi56,t]$(tDatax1[t]) = ({V}{IO}_y['tot',sMineralogi56,t] 
                                                +  {V}{IO}_m['tot',sMineralogi56,t]
                                                + sum(a_rows, {V}{IO}_a[a_rows,sMineralogi56,t]) 
                                                - sum(sMineralogi56_a, {V}{IO}_y[sMineralogi56_a,sMineralogi56,t])
                                                - sum(sMineralogi56_a, {V}{IO}_m[sMineralogi56_a,sMineralogi56,t])
                                                #  - {V}{IO}_a['SalEmpl',sMineralogi56,t]
                                               
                                               )
                                               
                                                /sum(sMineralogi56_a,(sum(sNotMineralogi56, {V}{IO}_y[sNotMineralogi56,sMineralogi56_a,t])
                                                                   +  sum(sNotMineralogi56, {V}{IO}_m[sNotMineralogi56,sMineralogi56_a,t])
                                                                   +  sum(a_rows, {V}{IO}_a[a_rows,sMineralogi56_a,t])
                                                                     )
                                                                   #  -   {V}{IO}_a['SalEmpl',sMineralogi56_a,t] 
                                                                   );


          {V}{IO}_y[sNotMineralogi56,sMineralogi56,t]$(tData[t]) = sCORR56[sMineralogi56,t] * {V}{IO}_y[sNotMineralogi56,'23001',t];
          {V}{IO}_m[sNotMineralogi56,sMineralogi56,t]$(tData[t]) = sCORR56[sMineralogi56,t] * {V}{IO}_m[sNotMineralogi56,'23001',t];           
          {V}{IO}_a[a_rows,sMineralogi56,t]$(tData[t])           = sCORR56[sMineralogi56,t] * {V}{IO}_a[a_rows,'23001',t]; # sum(sMineralogi56_a, {V}{IO}_a[a_rows,sMineralogi56_a,t]);  
        $ENDIF
     
        $IF '{IO}' in ['IOxE']:
          sCORR56[sMineralogi56,t]$(tDatax1[t]) = ({V}{IO}_y['tot',sMineralogi56,t] 
                                                +  {V}{IO}_m['tot',sMineralogi56,t]
                                                #  + sum(a_rows, {V}{IO}_a[a_rows,sMineralogi56,t]) 
                                                - sum(sMineralogi56_a, {V}{IO}_y[sMineralogi56_a,sMineralogi56,t])
                                                - sum(sMineralogi56_a, {V}{IO}_m[sMineralogi56_a,sMineralogi56,t])
                                                #  - {V}{IO}_a['SalEmpl',sMineralogi56,t]
                                               
                                               )
                                               
                                                /sum(sMineralogi56_a,(sum(sNotMineralogi56, {V}{IO}_y[sNotMineralogi56,sMineralogi56_a,t])
                                                                   +  sum(sNotMineralogi56, {V}{IO}_m[sNotMineralogi56,sMineralogi56_a,t])
                                                                   #  +  sum(a_rows, {V}{IO}_a[a_rows,sMineralogi56_a,t])
                                                                     )
                                                                   #  -   {V}{IO}_a['SalEmpl',sMineralogi56_a,t] 
                                                                   );


          {V}{IO}_y[sNotMineralogi56,sMineralogi56,t]$(tData[t]) = sCORR56[sMineralogi56,t] * {V}{IO}_y[sNotMineralogi56,'23001',t];
          {V}{IO}_m[sNotMineralogi56,sMineralogi56,t]$(tData[t]) = sCORR56[sMineralogi56,t] * {V}{IO}_m[sNotMineralogi56,'23001',t];           
          #  {V}{IO}_a[a_rows,sMineralogi56,t]$(tData[t])           = sCORR56[sMineralogi56,t] * {V}{IO}_a[a_rows,'23001',t]; # sum(sMineralogi56_a, {V}{IO}_a[a_rows,sMineralogi56_a,t]);  
        $ENDIF
     
                                                                                                                          


        #  {V}{IO}_y[sNotMineralogi56,sMineralogi56,t]$(tData[t]) = sCORR56[sMineralogi56,t] * {V}{IO}_y[sNotMineralogi56,'23001',t];
        #  {V}{IO}_m[sNotMineralogi56,sMineralogi56,t]$(tData[t]) = sCORR56[sMineralogi56,t] * {V}{IO}_m[sNotMineralogi56,'23001',t];           
        #  {V}{IO}_a[a_rows,sMineralogi56,t]$(tData[t])           = sCORR56[sMineralogi56,t] * {V}{IO}_a[a_rows,'23001',t]; # sum(sMineralogi56_a, {V}{IO}_a[a_rows,sMineralogi56_a,t]);  
        #  {V}{IO}_a[a_rows,sMineralogi56,t]$(tData[t] and not sameas[a_rows,'SalEmpl']) = sCORR56[sMineralogi56,t] * sum(sMineralogi56_a, {V}{IO}_a[a_rows,sMineralogi56_a,t]);  


      #   $IF '{IO}'=='IOxE':
      #    {V}{IO}_a['OvProd','23002',t] = {V}{IO}_a['OvProd','23002',t] + 0.251 -{V}{IO}_a['SalEmpl','23001',t];
      #    {V}{IO}_a['OvProd','23001',t] = {V}{IO}_a['OvProd','23001',t] + {V}{IO}_a['SalEmpl','23001',t] - 0.251;

      #    {V}{IO}_a['SalEmpl','23002',t] = {V}{IO}_a['SalEmpl','23002',t] + {V}{IO}_a['SalEmpl','23001',t] - 0.251;
      #    {V}{IO}_a['SalEmpl','23001',t] = 0.251;
      #  $ENDIF

        #Vi genbruger korrektionsvariablen sCORR (Det her er leverancer fra udenlandsk mineralogi branche til indland)
          sCORR56[sMineralogi56,t]$(tDatax1[t] and (sum(IO_56_c_notMineralogi,{V}{IO}_m['23001',IO_56_c_notMineralogi,t]))) 
                      = ({V}{IO}_m[sMineralogi56,'tot',t] - sum(sMineralogi56_a,{V}{IO}_m[sMineralogi56,sMineralogi56_a,t]))
                        /(sum(IO_56_c_notMineralogi,{V}{IO}_m['23001',IO_56_c_notMineralogi,t]));     


          {V}{IO}_m[sMineralogi56,IO_56_c_notMineralogi,t]$(tDatax1[t]) = sCORR56[sMineralogi56,t] * {V}{IO}_m['23001',IO_56_c_notMineralogi,t];



    #I 2019 bliver vi også nødt til at opsplitte afgiftslagkagen
    $IF ('{V}'=='v') & ('{IO}'=='IOxE'):
        $FOR4 {afg} in ['vAfgxE_56_y','vSubxE_56_y']:
          {afg}[sMineralogi56,IO_56_c,afgsub,t]$(t.val=2019)= vIOxE_y[sMineralogi56,IO_56_c,t]/sum(sMineralogi56_a, vIOxE_y[sMineralogi56_a,IO_56_c,t]) * {afg}['23001',IO_56_c,afgsub,t];
          {afg}[sNotMineralogi56,sMineralogi56,afgsub,t]$(t.val=2019)= vIOxE_y[sNotMineralogi56,sMineralogi56,t]/sum(sMineralogi, vIOxE_y[sNotMineralogi56,sMineralogi56,t]) * {afg}[sNotMineralogi56,'23001',afgsub,t];
      $ENDFOR4
    $ENDIF


    #I 2019 bliver vi også nødt til at opsplitte afgiftslagkagen
    $IF ('{V}'=='v') & ('{IO}'=='IOxE'):
        $FOR4 {afg} in ['vAfgxE_56_m','vSubxE_56_m']:
          {afg}[sMineralogi56,IO_56_c,afgsub,t]$(t.val=2019)= vIOxE_m[sMineralogi56,IO_56_c,t]/sum(sMineralogi56_a, vIOxE_m[sMineralogi56_a,IO_56_c,t]) * {afg}['23001',IO_56_c,afgsub,t];
          {afg}[sNotMineralogi56,sMineralogi56,afgsub,t]$(t.val=2019)= vIOxE_m[sNotMineralogi56,sMineralogi56,t]/sum(sMineralogi, vIOxE_m[sNotMineralogi56,sMineralogi56,t]) * {afg}[sNotMineralogi56,'23001',afgsub,t];
      $ENDFOR4
    $ENDIF
      
    $ENDFOR1

    {V}IO_I[i,sMineralogi56,t]$(tData[t]) = sYS56[sMineralogi56] * {V}IO_I[i,'23001',t]; #{V}IO_I['it','23002',t] = {V}IO_I['it','23001',t]; {V}IO_I['it','23001',t] = 0;
    {V}IO_K[i,sMineralogi56,t]$(tData[t]) = sYS56[sMineralogi56] * {V}IO_K[i,'23001',t]; #{V}IO_K['it','23002',t] = {V}IO_K['it','23001',t]; {V}IO_K['it','23001',t] = 0;

  $ENDFOR

  @computeIO()


  #Opsplitning af told. Vi bruger de implicitte nøgler, der ligger i de udsplittede matricer. Det giver muligvis ikke række/søjle-totaler, der passer for told, men det må RAS-afstemningen råde bod på.

  vIOxE_cus[sMineralogi56,IO_56_c,t]$(tData[t] and sum(IO_56_c_a, vIOxE_m[sMineralogi56,IO_56_c_a,t]))                = vIOxE_cus['23001',IO_56_c,t]     * vIOxE_m[sMineralogi56,IO_56_c,t]/sum(IO_56_c_a, vIOxE_m[sMineralogi56,IO_56_c_a,t]);
  vIOxE_cus[sNotMineralogi56,sMineralogi56,t]$(tData[t] and sum(sNotMineralogi56_a, vIOxE_m[sNotMineralogi56_a,sMineralogi56,t])) = vIOxE_cus[sNotMineralogi56,'23001',t] * vIOxE_m[sNotMineralogi56,sMineralogi56,t]/sum(sNotMineralogi56_a, vIOxE_m[sNotMineralogi56_a,sMineralogi56,t]); 
  
  vIOxE_cus['tot',IO_56_c,t]$(tData[t]) = sum(s56,     vIOxE_cus[s56,IO_56_c,t]);
  vIOxE_cus[s56,'tot',t]$(tData[t])     = sum(IO_56_c, vIOxE_cus[s56,IO_56_c,t]);

  #Opsplitning af produktionsskatter- og subsidier
  vpSkatSub_56[artsub,sMineralogi56,t]$(sum(sMineralogi56_a, vIOxE_a['othSub',sMineralogi56_a,t]))   = vpSkatSub_56[artsub,sMineralogi56,t] * vIOxE_a['othSub',sMineralogi56,t]/sum(sMineralogi56_a, vIOxE_a['othSub',sMineralogi56_a,t]);
  vpSkatSub_56[artskat,sMineralogi56,t]$(sum(sMineralogi56_a, vIOxE_a['othTax',sMineralogi56_a,t]))  = vpSkatSub_56[artskat,sMineralogi56,t] * vIOxE_a['othTax',sMineralogi56,t]/sum(sMineralogi56_a, vIOxE_a['othTax',sMineralogi56_a,t]);

$IF %smaagrisesplit%:
#---------------------------------------------------------------------------------------------
#  Opsplitter svinebrug
#---------------------------------------------------------------------------------------------

  $FOR {V} in ['v','vD']:
    $FOR1 {IO} in ['IOxE','EIO']:

    #INDENLANDSK
      #Produktionsværdier 
      {V}{IO}_y[sSvin56,'tot',t]$(tData[t])   = sYS56[sSvin56] * {V}{IO}_y['01051','tot',t];
      {V}{IO}_y[sSvin56,'xOth' ,t]$(tData[t]) = sXS56[sSvin56] * {V}{IO}_y['01051','xOth',t];

      #
      $IF1 '{IO}'=='IOxE':
        {V}{IO}_y['01051','01052',t]$(tData[t]) =  {V}{IO}_y['01051','01051',t]; {V}{IO}_y['01051','01051',t] = 0;
      $ENDIF1

      $IF1 '{IO}'!='IOxE':      
      {V}{IO}_y[sSvin56,sSvin56_a,t]$(tData[t] and sameas[sSvin56,sSvin56_a]) = sYS56[sSvin56]        * {V}{IO}_y['01051','01051',t];
      $ENDIF1

      #IMPORT 
      {V}{IO}_m[sSvin56,'tot',t]$(tData[t])  = sMS56[sSvin56] * {V}{IO}_m['01051','tot',t];

      #Svinbrancherne til sig selv på diagonalen 
      {V}{IO}_m[sSvin56,sSvin56_a,t]$(sameas[sSvin56,sSvin56_a]) = sMS56[sSvin56] * {V}{IO}_m['01051','01051',t];




      {V}{IO}_y['tot',sSvin56,t]$(tData[t])    = sYS56[sSvin56]   * {V}{IO}_y['tot','01051',t];
      {V}{IO}_m['tot',sSvin56,t]$(tData[t])    = sYS56[sSvin56]   * {V}{IO}_m['tot','01051',t];
      {V}{IO}_a[a_rows,sSvin56,t]$(tData[t])   = sYS56[sSvin56]   * {V}{IO}_a[a_rows,'01051',t];   
      {V}{IO}_a['tot',sSvin56,t]$(tData[t])    = sYS56[sSvin56]   * {V}{IO}_a['tot','01051',t];   

     
      #Ud fra de her komponenter kan beregnes, hvilken andel de resterende IO-komponenter skal fordeles ift. for at rækkesummen passer 
        #Se eventuelt note "Afstemning af rækker i IO"
        #Korrigerer rækker af indenlandsk produktion fra Svin
        sCORR56[sSvin56,t]$(tDatax1[t] and (sum(IO_56_c_notSvinPlusEksport,{V}{IO}_y['01051',IO_56_c_notSvinPlusEksport,t]))) 
                           = ({V}{IO}_y[sSvin56,'tot',t] - sum(IO_56_c_SvinPlusEksport,{V}{IO}_y[sSvin56,IO_56_c_SvinPlusEksport,t]))
                            /(sum(IO_56_c_notSvinPlusEksport,{V}{IO}_y['01051',IO_56_c_notSvinPlusEksport,t]));  

        {V}{IO}_y[sSvin56,IO_56_c_notSvinPlusEksport,t]$(tDatax1[t]) = sCORR56[sSvin56,t] *  {V}{IO}_y['01051',IO_56_c_notSvinPlusEksport,t];


        #Herpå skal søjlerne afstemmes (Der er mange måder brøken kunne opstilles på med udgangspunkt i dataparametrene men nedenstående er valgt)
        #I tælleren er den totale søjlesum, minus Svin-til-Svin leverancer (dem rører vi ikke mere ved efter diagonalisering)
        #I nævneren er de totale leverancer, minus Svin-til-Svin.
        #I både tæller og nævner trækkes også lønsum ud, da vi vil fastholde denne til værdi fra nyt io-data, der skal indarbejdes i fremtidig modelversion
        #

          sCORR56[sSvin56,t]$(tDatax1[t])       = ({V}{IO}_y['tot',sSvin56,t] 
                                                +  {V}{IO}_m['tot',sSvin56,t]
                                                + sum(a_rows, {V}{IO}_a[a_rows,sSvin56,t]) 
                                                - sum(sSvin56_a, {V}{IO}_y[sSvin56_a,sSvin56,t])
                                                - sum(sSvin56_a, {V}{IO}_m[sSvin56_a,sSvin56,t])
                                                #  - {V}{IO}_a['SalEmpl',sSvin56,t]
                                               
                                               )
                                               
                                                /sum(sSvin56_a,(sum(sNotSvin56, {V}{IO}_y[sNotSvin56,sSvin56_a,t])
                                                                   +  sum(sNotSvin56, {V}{IO}_m[sNotSvin56,sSvin56_a,t])
                                                                   +  sum(a_rows, {V}{IO}_a[a_rows,sSvin56_a,t])
                                                                     )
                                                                   #  -   {V}{IO}_a['SalEmpl',sSvin56_a,t] 
                                                                   );

          # execute_unload 'output\pre_{V}{IO}.gdx';

          {V}{IO}_y[sNotSvin56,sSvin56,t]$(tData[t]) = sCORR56[sSvin56,t] * {V}{IO}_y[sNotSvin56,'01051',t];
          {V}{IO}_m[sNotSvin56,sSvin56,t]$(tData[t]) = sCORR56[sSvin56,t] * {V}{IO}_m[sNotSvin56,'01051',t];           


        #Vi genbruger korrektionsvariablen sCORR (Det her er leverancer fra udenlandsk Svin branche til indland)
          sCORR56[sSvin56,t]$(tDatax1[t] and (sum(IO_56_c_notSvin,{V}{IO}_m['01051',IO_56_c_notSvin,t]))) 
                      = ({V}{IO}_m[sSvin56,'tot',t] - sum(sSvin56_a,{V}{IO}_m[sSvin56,sSvin56_a,t]))
                        /(sum(IO_56_c_notSvin,{V}{IO}_m['01051',IO_56_c_notSvin,t]));     

        # execute_unload 'output\here_{V}{IO}.gdx';
          {V}{IO}_m[sSvin56,IO_56_c_notSvin,t]$(tDatax1[t]) = sCORR56[sSvin56,t] * {V}{IO}_m['01051',IO_56_c_notSvin,t];


    #I 2019 bliver vi også nødt til at opsplitte afgiftslagkagen
    $IF1 ('{V}'=='v') & ('{IO}'=='IOxE'):
        $FOR4 {afg} in ['vAfgxE_56_y','vSubxE_56_y']:
          {afg}[sSvin56,IO_56_c,afgsub,t]$(t.val=2019)= vIOxE_y[sSvin56,IO_56_c,t]/sum(sSvin56_a, vIOxE_y[sSvin56_a,IO_56_c,t]) * {afg}['01051',IO_56_c,afgsub,t];
          {afg}[sNotSvin56,sSvin56,afgsub,t]$(t.val=2019)= vIOxE_y[sNotSvin56,sSvin56,t]/sum(sSvin, vIOxE_y[sNotSvin56,sSvin56,t]) * {afg}[sNotSvin56,'01051',afgsub,t];
      $ENDFOR4
    $ENDIF1


    #I 2019 bliver vi også nødt til at opsplitte afgiftslagkagen
    $IF1 ('{V}'=='v') & ('{IO}'=='IOxE'):
        $FOR4 {afg} in ['vAfgxE_56_m','vSubxE_56_m']:
          {afg}[sSvin56,IO_56_c,afgsub,t]$(t.val=2019)= vIOxE_m[sSvin56,IO_56_c,t]/sum(sSvin56_a, vIOxE_m[sSvin56_a,IO_56_c,t]) * {afg}['01051',IO_56_c,afgsub,t];
          {afg}[sNotSvin56,sSvin56,afgsub,t]$(t.val=2019)= vIOxE_m[sNotSvin56,sSvin56,t]/sum(sSvin, vIOxE_m[sNotSvin56,sSvin56,t]) * {afg}[sNotSvin56,'01051',afgsub,t];
      $ENDFOR4
    $ENDIF1
      
    $ENDFOR1

    {V}IO_I[i,sSvin56,t]$(tData[t]) = sYS56[sSvin56] * {V}IO_I[i,'01051',t]; #{V}IO_I['it','01052',t] = {V}IO_I['it','01051',t]; {V}IO_I['it','01051',t] = 0;
    {V}IO_K[i,sSvin56,t]$(tData[t]) = sYS56[sSvin56] * {V}IO_K[i,'01051',t]; #{V}IO_K['it','01052',t] = {V}IO_K['it','01051',t]; {V}IO_K['it','01051',t] = 0;

  $ENDFOR

  @computeIO()


  #Opsplitning af told. Vi bruger de implicitte nøgler, der ligger i de udsplittede matricer. Det giver muligvis ikke række/søjle-totaler, der passer for told, men det må RAS-afstemningen råde bod på.

  vIOxE_cus[sSvin56,IO_56_c,t]$(tData[t] and sum(IO_56_c_a, vIOxE_m[sSvin56,IO_56_c_a,t]))                = vIOxE_cus['01051',IO_56_c,t]     * vIOxE_m[sSvin56,IO_56_c,t]/sum(IO_56_c_a, vIOxE_m[sSvin56,IO_56_c_a,t]);
  vIOxE_cus[sNotSvin56,sSvin56,t]$(tData[t] and sum(sNotSvin56_a, vIOxE_m[sNotSvin56_a,sSvin56,t])) = vIOxE_cus[sNotSvin56,'01051',t] * vIOxE_m[sNotSvin56,sSvin56,t]/sum(sNotSvin56_a, vIOxE_m[sNotSvin56_a,sSvin56,t]); 
  
  vIOxE_cus['tot',IO_56_c,t]$(tData[t]) = sum(s56,     vIOxE_cus[s56,IO_56_c,t]);
  vIOxE_cus[s56,'tot',t]$(tData[t])     = sum(IO_56_c, vIOxE_cus[s56,IO_56_c,t]);

  #Opsplitning af produktionsskatter- og subsidier
  vpSkatSub_56[artsub,sSvin56,t]$(sum(sSvin56_a, vIOxE_a['othSub',sSvin56_a,t]))   = vpSkatSub_56[artsub,sSvin56,t] * vIOxE_a['othSub',sSvin56,t]/sum(sSvin56_a, vIOxE_a['othSub',sSvin56_a,t]);
  vpSkatSub_56[artskat,sSvin56,t]$(sum(sSvin56_a, vIOxE_a['othTax',sSvin56_a,t]))  = vpSkatSub_56[artskat,sSvin56,t] * vIOxE_a['othTax',sSvin56,t]/sum(sSvin56_a, vIOxE_a['othTax',sSvin56_a,t]);
  
  $ENDIF

#---------------------------------------------------------------------------------------------
#  Opsplitter slagterier (slagteri skal komme efter opsplitning af svinebrug)
#---------------------------------------------------------------------------------------------

  $FOR {V} in ['v','vD']:
    $FOR1 {IO} in ['IOxE','EIO']:

    #INDENLANDSK
      #Produktionsværdier 
      {V}{IO}_y[sSlagteri56,'tot',t]$(tData[t])   = sYS56[sSlagteri56] * {V}{IO}_y['10011','tot',t];
      {V}{IO}_y[sSlagteri56,'xOth' ,t]$(tData[t]) = sXS56[sSlagteri56] * {V}{IO}_y['10011','xOth',t];

      #Slagteribrancherne til sig selv på diagonalen 
      {V}{IO}_y[sSlagteri56,sSlagteri56_a,t]$(tData[t] and sameas[sSlagteri56,sSlagteri56_a]) = sYS56[sSlagteri56]        * {V}{IO}_y['10011','10011',t];


      #Slagteri fra landbrugsbrancherne
      {V}{IO}_y['01031','10011',t]$(tData[t]) = {V}{IO}_y['01031','10011',t];
      {V}{IO}_y['01032','10011',t]$(tData[t]) = {V}{IO}_y['01032','10011',t];

      {V}{IO}_y['01051','10012',t]$(tData[t]) = {V}{IO}_y['01051','10011',t];
      {V}{IO}_y['01052','10012',t]$(tData[t]) = {V}{IO}_y['01052','10011',t];

      {V}{IO}_y['01061','10013',t]$(tData[t]) = {V}{IO}_y['01061','10011',t];
      {V}{IO}_y['01062','10013',t]$(tData[t]) = {V}{IO}_y['01062','10011',t];

      {V}{IO}_y['01051','10011',t]$(tData[t]) = 0;
      {V}{IO}_y['01052','10011',t]$(tData[t]) = 0;

      {V}{IO}_y['01061','10011',t]$(tData[t]) = 0;
      {V}{IO}_y['01062','10011',t]$(tData[t]) = 0;


      #IMPORT 
      {V}{IO}_m[sSlagteri56,'tot',t]$(tData[t])  = sMS56[sSlagteri56] * {V}{IO}_m['10011','tot',t];

      #Slagteribrancherne til sig selv på diagonalen 
      #  {V}{IO}_m[sSlagteri56,sSlagteri56_a,t]$(sameas[sSlagteri56,sSlagteri56_a]) = sMS56[sSlagteri56] * {V}{IO}_m['10011','10011',t];
      {V}{IO}_m['10012','10011',t]$(tData[t]) =  {V}{IO}_m['10011','10011',t]; {V}{IO}_m['10011','10011',t] = 0;


      #Slagteri fra landbrugsbrancherne
      {V}{IO}_m['01031','10011',t]$(tData[t]) = {V}{IO}_m['01031','10011',t];
      {V}{IO}_m['01032','10011',t]$(tData[t]) = {V}{IO}_m['01032','10011',t];

      {V}{IO}_m['01051','10012',t]$(tData[t]) = {V}{IO}_m['01051','10011',t];
      {V}{IO}_m['01052','10012',t]$(tData[t]) = {V}{IO}_m['01052','10011',t];

      {V}{IO}_m['01061','10013',t]$(tData[t]) = {V}{IO}_m['01061','10011',t];
      {V}{IO}_m['01062','10013',t]$(tData[t]) = {V}{IO}_m['01062','10011',t];

      {V}{IO}_m['01051','10011',t]$(tData[t]) = 0;
      {V}{IO}_m['01052','10011',t]$(tData[t]) = 0;

      {V}{IO}_m['01061','10011',t]$(tData[t]) = 0;
      {V}{IO}_m['01062','10011',t]$(tData[t]) = 0;


      {V}{IO}_y['tot',sSlagteri56,t]$(tData[t])  = sYS56[sSlagteri56]   * {V}{IO}_y['tot','10011',t];
      {V}{IO}_m['tot',sSlagteri56,t]$(tData[t])  = sYS56[sSlagteri56]   * {V}{IO}_m['tot','10011',t];
      {V}{IO}_a[a_rows,sSlagteri56,t]$(tData[t]) = sYS56[sSlagteri56]   * {V}{IO}_a[a_rows,'10011',t];           
      {V}{IO}_a['tot',sSlagteri56,t]$(tData[t])  = sYS56[sSlagteri56]   * {V}{IO}_a['tot','10011',t];           

      
      #Ud fra de her komponenter kan beregnes, hvilken andel de resterende IO-komponenter skal fordeles ift. for at rækkesummen passer 
        #Se eventuelt note "Afstemning af rækker i IO"
        #Korrigerer rækker af indenlandsk produktion fra slagterier
        sCORR56[sSlagteri56,t]$(tDatax1[t] and (sum(IO_56_c_notSlagterPlusEksport,{V}{IO}_y['10011',IO_56_c_notSlagterPlusEksport,t]))) 
                           = ({V}{IO}_y[sSlagteri56,'tot',t] - sum(IO_56_c_SlagterPlusEksport,{V}{IO}_y[sSlagteri56,IO_56_c_SlagterPlusEksport,t]))
                            /(sum(IO_56_c_notSlagterPlusEksport,{V}{IO}_y['10011',IO_56_c_notSlagterPlusEksport,t]));               

        {V}{IO}_y[sSlagteri56,IO_56_c_notSlagterPlusEksport,t]$(tDatax1[t]) = sCORR56[sSlagteri56,t] *  {V}{IO}_y['10011',IO_56_c_notSlagterPlusEksport,t];


        #NY
        #Korrigerer søjler til at ramme total 
        sCORR56[sSlagteri56,t]$(tDatax1[t]) = ({V}{IO}_y['tot',sSlagteri56,t] 
                                             + {V}{IO}_m['tot',sSlagteri56,t]
                                             + sum(a_rows, {V}{IO}_a[a_rows,sSlagteri56,t])
                                             - sum(sSlagterPlusPrimaer_r, {V}{IO}_y[sSlagterPlusPrimaer_r,sSlagteri56,t])
                                             - sum(sPrimaer, {V}{IO}_m[sPrimaer,sSlagteri56,t])
                                             )
                                             
                                              /sum(sSlagteri56_a,(sum(sNotSlagterPlusPrimaer_r, {V}{IO}_y[sNotSlagterPlusPrimaer_r,sSlagteri56_a,t])
                                                               +  sum(sNotPrimaer,              {V}{IO}_m[sNotPrimaer,sSlagteri56_a,t])
                                                               +  sum(a_rows,                   {V}{IO}_a[a_rows,sSlagteri56_a,t])));
   
        {V}{IO}_y[sNotSlagterPlusPrimaer_r,sSlagteri56,t]$(tData[t]) = sCORR56[sSlagteri56,t] * {V}{IO}_y[sNotSlagterPlusPrimaer_r,'10011',t];
        {V}{IO}_m[sNotPrimaer,sSlagteri56,t]$(tData[t])              = sCORR56[sSlagteri56,t] * {V}{IO}_m[sNotPrimaer,'10011',t];           
        {V}{IO}_a[a_rows,sSlagteri56,t]$(tData[t])                   = sCORR56[sSlagteri56,t] * sum(sSlagteri56_a, {V}{IO}_a[a_rows,sSlagteri56_a,t]);  

        #Vi genbruger korrektionsvariablen sCORR 
        sCORR56[sSlagteri56,t]$(tDatax1[t] and (sum(sNotSlagteri_c,{V}{IO}_m['10011',sNotSlagteri_c,t]))) 
                      = ({V}{IO}_m[sSlagteri56,'tot',t] - sum(sSlagteri56_a,{V}{IO}_m[sSlagteri56,sSlagteri56_a,t]))
                      /(sum(sNotSlagteri_c,{V}{IO}_m['10011',sNotSlagteri_c,t]));     


        {V}{IO}_m[sSlagteri56,sNotSlagteri_c,t]$(tDatax1[t]) = sCORR56[sSlagteri56,t] * {V}{IO}_m['10011',sNotSlagteri_c,t];


    #I 2019 bliver vi også nødt til at opsplitte afgiftslagkagen
    $IF ('{V}'=='v') & ('{IO}'=='IOxE'):
        $FOR4 {afg} in ['vAfgxE_56_y','vSubxE_56_y']:
          {afg}[sSlagteri56,IO_56_c,afgsub,t]$(t.val=2019)= vIOxE_y[sSlagteri56,IO_56_c,t]/sum(sSlagteri56_a, vIOxE_y[sSlagteri56_a,IO_56_c,t]) * {afg}['10011',IO_56_c,afgsub,t];
          {afg}[sNotSlagteri,sSlagteri_c,afgsub,t]$(t.val=2019)= vIOxE_y[sNotSlagteri,sSlagteri_c,t]/sum(sSlagteri56_a, vIOxE_y[sNotSlagteri,sSlagteri56_a,t]) * {afg}[sNotSlagteri,'10011',afgsub,t];
      $ENDFOR4
    $ENDIF


    #I 2019 bliver vi også nødt til at opsplitte afgiftslagkagen
    $IF ('{V}'=='v') & ('{IO}'=='IOxE'):
        $FOR4 {afg} in ['vAfgxE_56_m','vSubxE_56_m']:
          {afg}[sSlagteri56,IO_56_c,afgsub,t]$(t.val=2019)= vIOxE_m[sSlagteri56,IO_56_c,t]/sum(sSlagteri56_a, vIOxE_m[sSlagteri56_a,IO_56_c,t]) * {afg}['10011',IO_56_c,afgsub,t];
          {afg}[sNotSlagteri,sSlagteri_c,afgsub,t]$(t.val=2019)= vIOxE_m[sNotSlagteri,sSlagteri_c,t]/sum(sSlagteri56_a, vIOxE_m[sNotSlagteri,sSlagteri56_a,t]) * {afg}[sNotSlagteri,'10011',afgsub,t];
      $ENDFOR4
    $ENDIF

      
    $ENDFOR1

    {V}IO_I[i,sSlagteri56,t]$(tData[t]) = sYS56[sSlagteri56] * {V}IO_I[i,'10011',t]; 
    {V}IO_K[i,sSlagteri56,t]$(tData[t]) = sYS56[sSlagteri56] * {V}IO_K[i,'10011',t];

  $ENDFOR

  @computeIO()


  #Opsplitning af told. Vi bruger de implicitte nøgler, der ligger i de udsplittede matricer. Det giver muligvis ikke række/søjle-totaler, der passer for told, men det må RAS-afstemningen råde bod på.

  vIOxE_cus[sSlagteri56,IO_56_c,t]$(tData[t] and sum(IO_56_c_a, vIOxE_m[sSlagteri56,IO_56_c_a,t]))                = vIOxE_cus['10011',IO_56_c,t]     * vIOxE_m[sSlagteri56,IO_56_c,t]/sum(IO_56_c_a, vIOxE_m[sSlagteri56,IO_56_c_a,t]);
  vIOxE_cus[sNotSlagteri,sSlagteri56,t]$(tData[t] and sum(sNotSlagteri_a, vIOxE_m[sNotSlagteri_a,sSlagteri56,t])) = vIOxE_cus[sNotSlagteri,'10011',t] * vIOxE_m[sNotSlagteri,sSlagteri56,t]/sum(sNotSlagteri_a, vIOxE_m[sNotSlagteri_a,sSlagteri56,t]); 
  
  vIOxE_cus['tot',IO_56_c,t]$(tData[t]) = sum(s56,     vIOxE_cus[s56,IO_56_c,t]);
  vIOxE_cus[s56,'tot',t]$(tData[t])     = sum(IO_56_c, vIOxE_cus[s56,IO_56_c,t]);


  #Opsplitning af produktionsskatter- og subsidier
  
  vpSkatSub_56[artsub,sSlagteri56,t]$(sum(sSlagteri56_a, vIOxE_a['othSub',sSlagteri56_a,t]))   = vpSkatSub_56[artsub,sSlagteri56,t]  * vIOxE_a['othSub',sSlagteri56,t]/sum(sSlagteri56_a, vIOxE_a['othSub',sSlagteri56_a,t]);
  vpSkatSub_56[artskat,sSlagteri56,t]$(sum(sSlagteri56_a, vIOxE_a['othTax',sSlagteri56_a,t]))  = vpSkatSub_56[artskat,sSlagteri56,t] * vIOxE_a['othTax',sSlagteri56,t]/sum(sSlagteri56_a, vIOxE_a['othTax',sSlagteri56_a,t]);



#---------------------------------------------------------------------------------------------
#  Laver nye forbrugskategorier - cFoodCow er placeholder for totalen af slagtekød og æg, jf. mapping i sets
#---------------------------------------------------------------------------------------------
      
    #Mangler kød i 11, så ændrer perioder
    set_data_periods(2014,2019);

    $FOR {v} in ['v','vD']:

      #Der er nogle meget små udgange af fisk og mejeriprodukter fra slagterierne. De flyttes til kødsgruppen
      {v}IOxE_y['10012','cFoodPig',t]$(tData[t])  = {v}IOxE_y['10012','cFoodCow',t] + {v}IOxE_y['10012','cFoodFish',t] + {v}IOxE_y['10012','cFoodDairy',t]; {v}IOxE_y['10012','cFoodCow',t] = 0; {v}IOxE_y['10012','cFoodFish',t] = 0; {v}IOxE_y['10012','cFoodDairy',t] = 0;
      {v}IOxE_y['10013','cFoodPoul',t]$(tData[t]) = {v}IOxE_y['10013','cFoodCow',t] + {v}IOxE_y['10013','cFoodFish',t] + {v}IOxE_y['10013','cFoodDairy',t]; {v}IOxE_y['10013','cFoodCow',t] = 0; {v}IOxE_y['10013','cFoodFish',t] = 0; {v}IOxE_y['10013','cFoodDairy',t] = 0;
      {v}IOxE_y['01061','cFoodPoul',t]$(tData[t]) = {v}IOxE_y['01061','cFoodCow',t] + {v}IOxE_y['01061','cFoodFish',t] + {v}IOxE_y['01061','cFoodDairy',t]; {v}IOxE_y['01061','cFoodCow',t] = 0; {v}IOxE_y['01061','cFoodFish',t] = 0; {v}IOxE_y['01061','cFoodDairy',t] = 0; #Der er store direkte leverancer af særligt æg fra fjerkræbrancherne
      {v}IOxE_y['01062','cFoodPoul',t]$(tData[t]) = {v}IOxE_y['01062','cFoodCow',t] + {v}IOxE_y['01062','cFoodFish',t] + {v}IOxE_y['01062','cFoodDairy',t]; {v}IOxE_y['01062','cFoodCow',t] = 0; {v}IOxE_y['01062','cFoodFish',t] = 0; {v}IOxE_y['01062','cFoodDairy',t] = 0;
      {v}IOxE_y['10011','cFoodCow',t]$(tData[t])  = {v}IOxE_y['10011','cFoodCow',t] + {v}IOxE_y['10011','cFoodFish',t] + {v}IOxE_y['10011','cFoodDairy',t]; {v}IOxE_y['10011','cFoodFish',t]= 0; {v}IOxE_y['10011','cFoodDairy',t]= 0;


      {v}IOxE_m['10012','cFoodPig',t]$(tData[t])  = {v}IOxE_m['10012','cFoodCow',t] + {v}IOxE_m['10012','cFoodFish',t] + {v}IOxE_m['10012','cFoodDairy',t]; {v}IOxE_m['10012','cFoodCow',t] = 0; {v}IOxE_m['10012','cFoodFish',t] = 0; {v}IOxE_m['10012','cFoodDairy',t] = 0;
      {v}IOxE_m['10013','cFoodPoul',t]$(tData[t]) = {v}IOxE_m['10013','cFoodCow',t] + {v}IOxE_m['10013','cFoodFish',t] + {v}IOxE_m['10013','cFoodDairy',t]; {v}IOxE_m['10013','cFoodCow',t] = 0; {v}IOxE_m['10013','cFoodFish',t] = 0; {v}IOxE_m['10013','cFoodDairy',t] = 0;
      {v}IOxE_m['01061','cFoodPoul',t]$(tData[t]) = {v}IOxE_m['01061','cFoodCow',t] + {v}IOxE_m['01061','cFoodFish',t] + {v}IOxE_m['01061','cFoodDairy',t]; {v}IOxE_m['01061','cFoodCow',t] = 0; {v}IOxE_m['01061','cFoodFish',t] = 0; {v}IOxE_m['01061','cFoodDairy',t] = 0; #Der er store direkte leverancer af særligt æg fra fjerkræbrancherne
      {v}IOxE_m['01062','cFoodPoul',t]$(tData[t]) = {v}IOxE_m['01062','cFoodCow',t] + {v}IOxE_m['01062','cFoodFish',t] + {v}IOxE_m['01062','cFoodDairy',t]; {v}IOxE_m['01062','cFoodCow',t] = 0; {v}IOxE_m['01062','cFoodFish',t] = 0; {v}IOxE_m['01062','cFoodDairy',t] = 0;
      {v}IOxE_m['10011','cFoodCow',t]$(tData[t])  = {v}IOxE_m['10011','cFoodCow',t] + {v}IOxE_m['10011','cFoodFish',t] + {v}IOxE_m['10011','cFoodDairy',t]; {v}IOxE_m['10011','cFoodFish',t]= 0; {v}IOxE_m['10011','cFoodDairy',t]= 0;



      #Der skal også flyttes MOMS og engros- og detailavancer (for sidstnævnte behøves kun indelandsk, da det er indenlandske brancher, der lægger avancer på før forbrugeren)
      {v}IOxE_y['46000','cFoodPig',t]$(tData[t]) = {v}IOxE_y['46000','cFoodCow',t] * ({v}IOxE_y['10012','cFoodPig',t]  + {v}IOxE_m['10012','cFoodPig',t])                                                                                                                                      /({v}IOxE_y['10011','cFoodCow',t] + {v}IOxE_m['10011','cFoodCow',t] + {v}IOxE_y['10012','cFoodPig',t] + {v}IOxE_m['10012','cFoodPig',t] + {v}IOxE_y['10013','cFoodPoul',t] + {v}IOxE_m['10013','cFoodPoul',t] + {v}IOxE_y['01061','cFoodPoul',t] + {v}IOxE_m['01061','cFoodPoul',t] + {v}IOxE_y['01062','cFoodPoul',t] + {v}IOxE_m['01062','cFoodPoul',t]);
      {v}IOxE_y['46000','cFoodPoul',t]$(tData[t])= {v}IOxE_y['46000','cFoodCow',t] * ({v}IOxE_y['10013','cFoodPoul',t] + {v}IOxE_m['10013','cFoodPoul',t] + {v}IOxE_y['01061','cFoodPoul',t] + {v}IOxE_m['01061','cFoodPoul',t] + {v}IOxE_y['01062','cFoodPoul',t] + {v}IOxE_m['01062','cFoodPoul',t])/({v}IOxE_y['10011','cFoodCow',t] + {v}IOxE_m['10011','cFoodCow',t] + {v}IOxE_y['10012','cFoodPig',t] + {v}IOxE_m['10012','cFoodPig',t] + {v}IOxE_y['10013','cFoodPoul',t] + {v}IOxE_m['10013','cFoodPoul',t] + {v}IOxE_y['01061','cFoodPoul',t] + {v}IOxE_m['01061','cFoodPoul',t] + {v}IOxE_y['01062','cFoodPoul',t] + {v}IOxE_m['01062','cFoodPoul',t]); 
      {v}IOxE_y['46000','cFoodCow',t]$(tData[t]) = {v}IOxE_y['46000','cFoodCow',t] - {v}IOxE_y['46000','cFoodPig',t]   - {v}IOxE_y['46000','cFoodPoul',t];
   
      {v}IOxE_y['47000','cFoodPig',t]$(tData[t]) = {v}IOxE_y['47000','cFoodCow',t] * ({v}IOxE_y['10012','cFoodPig',t]  + {v}IOxE_m['10012','cFoodPig',t])                                                                                                                                      /({v}IOxE_y['10011','cFoodCow',t] + {v}IOxE_m['10011','cFoodCow',t] + {v}IOxE_y['10012','cFoodPig',t] + {v}IOxE_m['10012','cFoodPig',t] + {v}IOxE_y['10013','cFoodPoul',t] + {v}IOxE_m['10013','cFoodPoul',t] + {v}IOxE_y['01061','cFoodPoul',t] + {v}IOxE_m['01061','cFoodPoul',t] + {v}IOxE_y['01062','cFoodPoul',t] + {v}IOxE_m['01062','cFoodPoul',t]);
      {v}IOxE_y['47000','cFoodPoul',t]$(tData[t])= {v}IOxE_y['47000','cFoodCow',t] * ({v}IOxE_y['10013','cFoodPoul',t] + {v}IOxE_m['10013','cFoodPoul',t] + {v}IOxE_y['01061','cFoodPoul',t] + {v}IOxE_m['01061','cFoodPoul',t] + {v}IOxE_y['01062','cFoodPoul',t] + {v}IOxE_m['01062','cFoodPoul',t])/({v}IOxE_y['10011','cFoodCow',t] + {v}IOxE_m['10011','cFoodCow',t] + {v}IOxE_y['10012','cFoodPig',t] + {v}IOxE_m['10012','cFoodPig',t] + {v}IOxE_y['10013','cFoodPoul',t] + {v}IOxE_m['10013','cFoodPoul',t] + {v}IOxE_y['01061','cFoodPoul',t] + {v}IOxE_m['01061','cFoodPoul',t] + {v}IOxE_y['01062','cFoodPoul',t] + {v}IOxE_m['01062','cFoodPoul',t]); 
      {v}IOxE_y['47000','cFoodCow',t]$(tData[t]) = {v}IOxE_y['47000','cFoodCow',t] - {v}IOxE_y['47000','cFoodPig',t]   - {v}IOxE_y['47000','cFoodPoul',t];


      {v}IOxE_a[a_rows,'cFoodPig',t]$(tData[t])  = {v}IOxE_a[a_rows,'cFoodCow',t] * ({v}IOxE_y['10012','cFoodPig',t]  + {v}IOxE_m['10012','cFoodPig',t])                                                                                                                                      /({v}IOxE_y['10011','cFoodCow',t] + {v}IOxE_m['10011','cFoodCow',t] + {v}IOxE_y['10012','cFoodPig',t] + {v}IOxE_m['10012','cFoodPig',t] + {v}IOxE_y['10013','cFoodPoul',t] + {v}IOxE_m['10013','cFoodPoul',t] + {v}IOxE_y['01061','cFoodPoul',t] + {v}IOxE_m['01061','cFoodPoul',t] + {v}IOxE_y['01062','cFoodPoul',t] + {v}IOxE_m['01062','cFoodPoul',t]); 
      {v}IOxE_a[a_rows,'cFoodPoul',t]$(tData[t]) = {v}IOxE_a[a_rows,'cFoodCow',t] * ({v}IOxE_y['10013','cFoodPoul',t] + {v}IOxE_m['10013','cFoodPoul',t] + {v}IOxE_y['01061','cFoodPoul',t] + {v}IOxE_m['01061','cFoodPoul',t] + {v}IOxE_y['01062','cFoodPoul',t] + {v}IOxE_m['01062','cFoodPoul',t])/({v}IOxE_y['10011','cFoodCow',t] + {v}IOxE_m['10011','cFoodCow',t] + {v}IOxE_y['10012','cFoodPig',t] + {v}IOxE_m['10012','cFoodPig',t] + {v}IOxE_y['10013','cFoodPoul',t] + {v}IOxE_m['10013','cFoodPoul',t] + {v}IOxE_y['01061','cFoodPoul',t] + {v}IOxE_m['01061','cFoodPoul',t] + {v}IOxE_y['01062','cFoodPoul',t] + {v}IOxE_m['01062','cFoodPoul',t]); 
      {v}IOxE_a[a_rows,'cFoodCow',t]$(tData[t])  = {v}IOxE_a[a_rows,'cFoodCow',t] - {v}IOxE_a[a_rows,'cFoodPig',t]    - {v}IOxE_a[a_rows,'cFoodPoul',t];



  #---------------------------------------------------------------------------------------------
  #  Ad hoc justeringer af forbrugsgrupper 
  #---------------------------------------------------------------------------------------------
      {v}IOxE_y['10011','cFoodCow',t]$(tData[t]) = {v}IOxE_y['10011','cFoodCow',t] + {v}IOxE_y['10011','cFoodBev',t] + {v}IOxE_y['10011','cFoodVeg',t]; {v}IOxE_y['10011','cFoodBev',t] = 0; {v}IOxE_y['10011','cFoodVeg',t] = 0; 
      {v}IOxE_y['10012','cFoodPig',t]$(tData[t]) = {v}IOxE_y['10012','cFoodPig',t] + {v}IOxE_y['10012','cFoodBev',t] + {v}IOxE_y['10012','cFoodVeg',t]; {v}IOxE_y['10012','cFoodBev',t] = 0; {v}IOxE_y['10012','cFoodVeg',t] = 0; 
      {v}IOxE_y['10013','cFoodPoul',t]$(tData[t])= {v}IOxE_y['10013','cFoodPoul',t]+ {v}IOxE_y['10013','cFoodBev',t] + {v}IOxE_y['10013','cFoodVeg',t]; {v}IOxE_y['10013','cFoodBev',t] = 0; {v}IOxE_y['10013','cFoodVeg',t] = 0; 

      {v}IOxE_m['10011','cFoodCow',t]$(tData[t]) = {v}IOxE_m['10011','cFoodCow',t] + {v}IOxE_m['10011','cFoodBev',t] + {v}IOxE_m['10011','cFoodVeg',t]; {v}IOxE_m['10011','cFoodBev',t] = 0; {v}IOxE_m['10011','cFoodVeg',t] = 0; 
      {v}IOxE_m['10012','cFoodPig',t]$(tData[t]) = {v}IOxE_m['10012','cFoodPig',t] + {v}IOxE_m['10012','cFoodBev',t] + {v}IOxE_m['10012','cFoodVeg',t]; {v}IOxE_m['10012','cFoodBev',t] = 0; {v}IOxE_m['10012','cFoodVeg',t] = 0; 
      {v}IOxE_m['10013','cFoodPoul',t]$(tData[t])= {v}IOxE_m['10013','cFoodPoul',t]+ {v}IOxE_m['10013','cFoodBev',t] + {v}IOxE_m['10013','cFoodVeg',t]; {v}IOxE_m['10013','cFoodBev',t] = 0; {v}IOxE_m['10013','cFoodVeg',t] = 0; 


      {v}IOxE_y['01031','cSer',t]$(tData[t])  = {v}IOxE_y['01031','cSer',t] + {v}IOxE_y['01031','cFoodDairy',t]; {v}IOxE_y['01031','cFoodDairy',t] = 0; #Ekstremt små overførsler af direkte mejeriprodukter fra primær
      {v}IOxE_y['01032','cSer',t]$(tData[t])  = {v}IOxE_y['01032','cSer',t] + {v}IOxE_y['01032','cFoodDairy',t]; {v}IOxE_y['01032','cFoodDairy',t] = 0;

      {v}IOxE_y['01051','cSer',t]$(tData[t])  = {v}IOxE_y['01051','cSer',t] + {v}IOxE_y['01051','cFoodCow',t] + {v}IOxE_y['01051','cFoodFish',t]; {v}IOxE_y['01051','cFoodCow',t] = 0; {v}IOxE_y['01051','cFoodFish',t] = 0; #Ekstremt små overførsler af direkte mejeriprodukter fra primær
      {v}IOxE_y['01052','cSer',t]$(tData[t])  = {v}IOxE_y['01052','cSer',t] + {v}IOxE_y['01052','cFoodCow',t] + {v}IOxE_y['01052','cFoodFish',t]; {v}IOxE_y['01052','cFoodCow',t] = 0; {v}IOxE_y['01052','cFoodFish',t] = 0;

      {v}IOxE_m['01031','cSer',t]$(tData[t])  = {v}IOxE_m['01031','cSer',t] + {v}IOxE_m['01031','cFoodDairy',t]; {v}IOxE_m['01031','cFoodDairy',t] = 0; #Ekstremt små overførsler af direkte mejeriprodukter fra primær
      {v}IOxE_m['01032','cSer',t]$(tData[t])  = {v}IOxE_m['01032','cSer',t] + {v}IOxE_m['01032','cFoodDairy',t]; {v}IOxE_m['01032','cFoodDairy',t] = 0;

      {v}IOxE_m['01051','cSer',t]$(tData[t])  = {v}IOxE_m['01051','cSer',t] + {v}IOxE_m['01051','cFoodCow',t] + {v}IOxE_m['01051','cFoodFish',t]; {v}IOxE_m['01051','cFoodCow',t] = 0; {v}IOxE_m['01051','cFoodFish',t] = 0; #Ekstremt små overførsler af direkte mejeriprodukter fra primær
      {v}IOxE_m['01052','cSer',t]$(tData[t])  = {v}IOxE_m['01052','cSer',t] + {v}IOxE_m['01052','cFoodCow',t] + {v}IOxE_m['01052','cFoodFish',t]; {v}IOxE_m['01052','cFoodCow',t] = 0; {v}IOxE_m['01052','cFoodFish',t] = 0;

      {v}IOxE_y['10030','cFoodBev',t]$(tData[t]) = {v}IOxE_y['10030','cFoodBev',t] + {v}IOxE_y['10030','cFoodCow',t] + {v}IOxE_y['10030','cNonFood',t]; {v}IOxE_y['10030','cFoodCow',t] = 0; {v}IOxE_y['10030','cNonFood',t] = 0;
      {v}IOxE_m['10030','cFoodBev',t]$(tData[t]) = {v}IOxE_m['10030','cFoodBev',t] + {v}IOxE_m['10030','cFoodCow',t] + {v}IOxE_m['10030','cNonFood',t]; {v}IOxE_m['10030','cFoodCow',t] = 0; {v}IOxE_m['10030','cNonFood',t] = 0;

      {v}IOxE_y['10040','cFoodVeg',t]$(tData[t]) = {v}IOxE_y['10040','cFoodVeg',t] + {v}IOxE_y['10040','cFoodCow',t] + {v}IOxE_y['10040','cFoodBev',t]; {v}IOxE_y['10040','cFoodCow',t] = 0; {v}IOxE_y['10040','cFoodBev',t] = 0;
      {v}IOxE_m['10040','cFoodVeg',t]$(tData[t]) = {v}IOxE_m['10040','cFoodVeg',t] + {v}IOxE_m['10040','cFoodCow',t] + {v}IOxE_m['10040','cFoodBev',t]; {v}IOxE_m['10040','cFoodCow',t] = 0; {v}IOxE_m['10040','cFoodBev',t] = 0;

      {v}IOxE_y['10120','cFoodBev',t]$(tData[t]) = {v}IOxE_y['10120','cFoodBev',t] + {v}IOxE_y['10120','cFoodCow',t] + {v}IOxE_y['10120','cFoodFish',t] + {v}IOxE_y['10120','cFoodDairy',t]; {v}IOxE_y['10120','cFoodCow',t] = 0; {v}IOxE_y['10120','cFoodFish',t] = 0; {v}IOxE_y['10120','cFoodDairy',t] = 0;
      {v}IOxE_m['10120','cFoodBev',t]$(tData[t]) = {v}IOxE_m['10120','cFoodBev',t] + {v}IOxE_m['10120','cFoodCow',t] + {v}IOxE_m['10120','cFoodFish',t] + {v}IOxE_y['10120','cFoodDairy',t]; {v}IOxE_m['10120','cFoodCow',t] = 0; {v}IOxE_m['10120','cFoodFish',t] = 0; {v}IOxE_y['10120','cFoodDairy',t] = 0;

      {v}IOxE_y['20000','cFoodBev',t]$(tData[t]) = {v}IOxE_y['20000','cFoodBev',t] + {v}IOxE_y['20000','cFoodDairy',t] + {v}IOxE_y['20000','cFoodCow',t]; {v}IOxE_y['20000','cFoodDairy',t] = 0; {v}IOxE_y['20000','cFoodCow',t] = 0;    
      {v}IOxE_m['20000','cFoodBev',t]$(tData[t]) = {v}IOxE_m['20000','cFoodBev',t] + {v}IOxE_m['20000','cFoodDairy',t] + {v}IOxE_m['20000','cFoodCow',t]; {v}IOxE_m['20000','cFoodDairy',t] = 0; {v}IOxE_m['20000','cFoodCow',t] = 0;    

      {v}IOxE_y['01011','cNonFood',t]$(tData[t]) = {v}IOxE_y['01011','cNonFood',t] + {v}IOxE_y['01011','cSer',t]; {v}IOxE_y['01011','cSer',t] = 0;
      {v}IOxE_m['01011','cNonFood',t]$(tData[t]) = {v}IOxE_m['01011','cNonFood',t] + {v}IOxE_m['01011','cSer',t]; {v}IOxE_m['01011','cSer',t] = 0;

      {v}IOxE_y['01012','cFoodVeg',t]$(tData[t]) = {v}IOxE_y['01012','cFoodVeg',t] + {v}IOxE_y['01012','cNonFood',t];  {v}IOxE_y['01012','cNonFood',t] = 0;
      {v}IOxE_m['01012','cFoodVeg',t]$(tData[t]) = {v}IOxE_m['01012','cFoodVeg',t] + {v}IOxE_m['01012','cNonFood',t];  {v}IOxE_m['01012','cNonFood',t] = 0;

      {v}IOxE_y['01070','cNonFood',t]$(tData[t]) = {v}IOxE_y['01070','cNonFood',t] + {v}IOxE_y['01070','cSer',t];  {v}IOxE_y['01070','cSer',t] = 0;
      {v}IOxE_m['01070','cNonFood',t]$(tData[t]) = {v}IOxE_m['01070','cNonFood',t] + {v}IOxE_m['01070','cSer',t];  {v}IOxE_m['01070','cSer',t] = 0;

      {v}IOxE_y['03000','cNonFood',t]$(tData[t]) = {v}IOxE_y['03000','cNonFood',t] + {v}IOxE_y['03000','cSer',t];  {v}IOxE_y['03000','cSer',t] = 0;
      {v}IOxE_m['03000','cNonFood',t]$(tData[t]) = {v}IOxE_m['03000','cNonFood',t] + {v}IOxE_m['03000','cSer',t];  {v}IOxE_m['03000','cSer',t] = 0;

      {v}IOxE_y['03000','cNonFood',t]$(tData[t]) = {v}IOxE_y['03000','cNonFood',t] + {v}IOxE_y['03000','cSer',t];  {v}IOxE_y['03000','cSer',t] = 0;
      {v}IOxE_m['03000','cNonFood',t]$(tData[t]) = {v}IOxE_m['03000','cNonFood',t] + {v}IOxE_m['03000','cSer',t];  {v}IOxE_m['03000','cSer',t] = 0;


    $ENDFOR

    @computeIO()



  #---------------------------------------------------------------------------------------------
  #  Laver ikke-energi IO
  #---------------------------------------------------------------------------------------------


    PARAMETER rowsum_y[s56_,t], rowsum_m[s56_,t], rowsum_a[a_rows_,t], colsum[IO_56_c_,t], diff_y[s56,t], diff_m[s56,t], diff_a[a_rows,t];
    $FUNCTION compute_row_and_col_check():

      rowsum_y[s56,t]$(tData[t])      = sum(IO_56_c, vIOxE_y[s56,IO_56_c,t]    + vEIO_y[s56,IO_56_c,t]);
      rowsum_m[s56,t]$(tData[t])      = sum(IO_56_c, vIOxE_m[s56,IO_56_c,t]    + vEIO_m[s56,IO_56_c,t]);
      rowsum_a[a_rows,t]$(tData[t])   = sum(IO_56_c, vIOxE_a[a_rows,IO_56_c,t] + vEIO_a[a_rows,IO_56_c,t]);

      colsum[IO_56_c,t]$(tData[t])    = sum(s56, vIOxE_y[s56,IO_56_c,t] + vEIO_y[s56,IO_56_c,t])
                                      + sum(s56, vIOxE_m[s56,IO_56_c,t] + vEIO_m[s56,IO_56_c,t])
                                      + sum(a_rows, vIOxE_a[a_rows,IO_56_c,t] + vEIO_a[a_rows,IO_56_c,t]);

      diff_y[s56,t]$(tData[t])        = rowsum_y[s56,t]    - colsum[s56,t];         
      diff_m[s56,t]$(tData[t])        = rowsum_m[s56,t]    - vIO_m[s56,'tot',t];
      diff_a[a_rows,t]$(tData[t])     = rowsum_a[a_rows,t] - vIO_a[a_rows,'tot',t];
    $ENDFUNCTION
    @compute_row_and_col_check();

    #Hack. vent på dataopdatering for helt ordentligt.. Vi flytter overskud fra den branche, der mangler til den der ikke har
    vIOxE_a['tot','23001',t]        = vIOxE_a['tot','23001',t] +  diff_y['23001',t];
    vIOxE_a['tot','23002',t]        = vIOxE_a['tot','23002',t] +  diff_y['23002',t];
    vIOxE_a['OvProd','23001',t]     = vIOxE_a['OvProd','23001',t] +  diff_y['23001',t];
    vIOxE_a['OvProd','23002',t]     = vIOxE_a['OvProd','23002',t] +  diff_y['23002',t];

    #Hack. vent på dataopdatering for helt ordentligt..
      $IF %smaagrisesplit%:
        vIOxE_a['tot','01051',t]        = vIOxE_a['tot','01051',t] +  diff_y['01051',t];
        vIOxE_a['tot','01052',t]        = vIOxE_a['tot','01052',t] +  diff_y['01052',t];
        vIOxE_a['OvProd','01051',t]     = vIOxE_a['OvProd','01051',t] +  diff_y['01051',t];
        vIOxE_a['OvProd','01052',t]     = vIOxE_a['OvProd','01052',t] +  diff_y['01052',t];
      $ENDIF



    @computeIO()
    @compute_row_and_col_check();
    execute_unload 'Output/test1.gdx';

    set tTest[t]/2014*2019/;
    #Test af at rækker og søjler rammer i udgangspunktet 
    LOOP((s56,t)$(tTest[t]),

     #Checking domestic production equalling demand
      tjek = rowsum_y[s56,t] - colsum[s56,t];
    ABORT$(abs(tjek) gt 1e-5) tjek, "Demand not equal to supply in IO";

      tjek = rowsum_y[s56,t] - vIO_y[s56,'tot',t];
    ABORT$(abs(tjek) gt 1e-5) tjek, "Row sum (y) doesnt match input row-sum";

      tjek = rowsum_m[s56,t] - vIO_m[s56,'tot',t];
    ABORT$(abs(tjek) gt 1e-5) tjek, "Row sum (m) doesnt match input row-sum";
      ); 

    LOOP((a_rows,t)$(tTest[t]),
      tjek = rowsum_a[a_rows,t] - vIO_a[a_rows,'tot',t];
    ABORT$(abs(tjek) gt 1e-5) tjek, "Row sum (a) doesnt match input row-sum";
    );


  #---------------------------------------------------------------------------------------------
  #  Afstemning af energidata og energiIO, samt fjernelse af små celler
  #---------------------------------------------------------------------------------------------

    #  #Creates groups of auxiliary variables to adjust energy-data
    #  $GROUP G_energy_VQ 
    #     $LOOP G_energy_modellevel_V:
    #      {name}_VAR{sets} 
    #     $ENDLOOP 
    #     $LOOP G_energy_modellevel_Q:
    #      {name}_VAR{sets} 
    #     $ENDLOOP 
    #   ;

    #  $GROUP G_energy_V 
    #     $LOOP G_energy_modellevel_V:
    #      {name}_VAR{sets} 
    #     $ENDLOOP 
    #  ;

    #  $GROUP G_energy_Q
    #     $LOOP G_energy_modellevel_Q:
    #      {name}_VAR{sets} 
    #     $ENDLOOP
    #  ;

    #  $GROUP G_energy_taxes 
    #     $LOOP G_energy_modellevel_taxes:
    #      {name}_VAR{sets} 
    #     $ENDLOOP
    #  ;
    #  $GROUP G_obj obj;

    #  #Trim data 
    #  $SETLOCAL min_level_energy 0.0001
    #    EN_qCE[purpose,energy19,t]$(EN_qCE[purpose,energy19,t] < %min_level_energy%) = 0; 
    #    EN_qLE[purpose,energy19,t]$(abs(EN_qLE[purpose,energy19,t]) < %min_level_energy%) = 0;
    #    EN_qRE[purpose,energy19,r,t]$(EN_qRE[purpose,energy19,r,t] < %min_level_energy%) = 0; 
    #    EN_qXE[purpose,energy19,t]$(EN_qXE[purpose,energy19,t] < %min_level_energy%) = 0;

    #    EN_vnCE[purpose,energy19,t]$(not EN_qCE[purpose,energy19,t]) = 0;
    #    EN_vnLE[purpose,energy19,t]$(not EN_qLE[purpose,energy19,t]) = 0;
    #    EN_vnRE[purpose,energy19,r,t]$(not EN_qRE[purpose,energy19,r,t]) = 0;
    #    EN_vnXE[purpose,energy19,t]$(not EN_qXE[purpose,energy19,t]) = 0;

    #    EN_vCO2_CE[purpose,energy19,t]$(not EN_qCE[purpose,energy19,t])      = 0;
    #    EN_vCO2_RE[purpose,energy19,r,t]$(not EN_qRE[purpose,energy19,r,t])    = 0; 
    #    EN_vEAFG_CE[purpose,energy19,t]$(not EN_qCE[purpose,energy19,t])       = 0; 
    #    EN_vEAFG_RE[purpose,energy19,r,t]$(not EN_qRE[purpose,energy19,r,t])   = 0;
    #    EN_vEAFG_XE[purpose,energy19,t]$(not EN_qXE[purpose,energy19,t])       = 0;  
    #    EN_vSO2_CE[purpose,energy19,t]$(not EN_qCE[purpose,energy19,t])        = 0;
    #    EN_vSO2_RE[purpose,energy19,r,t]$(not EN_qRE[purpose,energy19,r,t])    = 0;
    #    EN_vPSO_CE[purpose,energy19,t]$(not EN_qCE[purpose,energy19,t])        = 0;
    #    EN_vPSO_RE[purpose,energy19,r,t]$(not EN_qRE[purpose,energy19,r,t])    = 0;
    #    EN_vPSO_XE[purpose,energy19,t]$(not EN_qXE[purpose,energy19,t])        = 0;
    #    EN_vNOx_CE[purpose,energy19,r]$(not EN_qCE[purpose,energy19,t])        = 0;
    #    EN_vNOx_RE[purpose,energy19,r,t]$(not EN_qRE[purpose,energy19,r,t])    = 0;
    #    EN_vMOMS_CE[purpose,energy19,t] $(not EN_qCE[purpose,energy19,t])      = 0;
    #    EN_vMOMS_RE[purpose,energy19,r,t]$(not EN_qRE[purpose,energy19,r,t])   = 0; 

    #  #Loads data into auxiliary variables
    #  $LOOP G_energy_modellevel_VQ:
    #  {name}_VAR.l{sets} = {name}{sets};
    #  $ENDLOOP 

    #    $GROUP G_s56energyvars 
    #      EN_vnRE_s56_VAR[purpose,energy19,s56,t]
    #      EN_vEAFG_RE_s56_VAR[purpose,energy19,s56,t]
    #      EN_vSO2_RE_s56_VAR[purpose,energy19,s56,t]
    #      EN_vPSO_RE_s56_VAR[purpose,energy19,s56,t]
    #      EN_vNOx_RE_s56_VAR[purpose,energy19,s56,t]
    #      EN_vCO2_RE_s56_VAR[purpose,energy19,s56,t]
    #      EN_vMOMS_RE_s56_VAR[purpose,energy19,s56,t]
    #    ;

    #    $PGROUP G_s56energyvars_dummies
    #      EN_vnRE_s56[purpose,energy19,s56,t]
    #      EN_vEAFG_RE_s56[purpose,energy19,s56,t]
    #      EN_vSO2_RE_s56[purpose,energy19,s56,t]
    #      EN_vPSO_RE_s56[purpose,energy19,s56,t]
    #      EN_vNOx_RE_s56[purpose,energy19,s56,t]
    #      EN_vCO2_RE_s56[purpose,energy19,s56,t]
    #      EN_vMOMS_RE_s56[purpose,energy19,s56,t]
    #    ;

    #    #Mapper til s56
    #      EN_vnRE_s56[purpose,energy19,s56,t]     = sum(s$maps2s56(s,s56), EN_vnRE[purpose,energy19,s,t]);
    #      EN_vEAFG_RE_s56[purpose,energy19,s56,t] = sum(s$maps2s56(s,s56), EN_vEAFG_RE[purpose,energy19,s,t]);
    #      EN_vSO2_RE_s56[purpose,energy19,s56,t]  = sum(s$maps2s56(s,s56), EN_vSO2_RE[purpose,energy19,s,t]);
    #      EN_vPSO_RE_s56[purpose,energy19,s56,t]  = sum(s$maps2s56(s,s56), EN_vPSO_RE[purpose,energy19,s,t]);
    #      EN_vNOx_RE_s56[purpose,energy19,s56,t]  = sum(s$maps2s56(s,s56), EN_vNOx_RE[purpose,energy19,s,t]);
    #      EN_vCO2_RE_s56[purpose,energy19,s56,t]  = sum(s$maps2s56(s,s56), EN_vCO2_RE[purpose,energy19,s,t]);
    #      EN_vMOMS_RE_s56[purpose,energy19,s56,t] = sum(s$maps2s56(s,s56), EN_vMOMS_RE[purpose,energy19,s,t]);

    #    #Skriver til variable
    #    $LOOP G_s56energyvars_dummies: {name}_VAR.l{sets} = {name}{sets}; $ENDLOOP



    #  $BLOCK B_AfstemvE
    #    E_vEIO_ANV_BAS[s56,t]$(vEIO_y['tot',s56,t] or vEIO_m['tot',s56,t]).. vEIO_y['tot',s56,t] + vEIO_m['tot',s56,t] =E= sum((purpose,energy19)$(EN_vnRE[purpose,energy19,s56,t]), EN_vnRE_56_VAR[purpose,energy19,s56,t]);

    #    E_vEIO_ANV_BAS_CE['cENE',t]$(vEIO_y['tot','cENE',t] or vEIO_m['tot','cENE',t]).. vEIO_y['tot','cENE',t] + vEIO_m['tot','cENE',t] =E= sum((purpose,energy19)$(EN_vnCE[purpose,energy19,t]), EN_vnCE_VAR[purpose,energy19,t]);

    #    E_vEIO_ANV_BAS_LE['INVT',t]$(vEIO_y['tot','INVT',t] or vEIO_m['tot','INVT',t]).. vEIO_y['tot','INVT',t] + vEIO_m['tot','INVT',t] =E= sum((purpose,energy19)$(EN_vnLE[purpose,energy19,t]), EN_vnLE_VAR[purpose,energy19,t]);

    #    E_vEIO_ANV_BAS_XE['xOth',t]$(vEIO_y['tot','xOth',t] or vEIO_m['tot','xOth',t]).. vEIO_y['tot','xOth',t] + vEIO_m['tot','xOth',t] =E= sum((purpose,energy19)$(EN_vnXE[purpose,energy19,t]), EN_vnXE_VAR[purpose,energy19,t]);

    #    E_vEIO_TIL_BAS_Y[s56,t]$(vEIO_y[s56,'tot',t]).. vEIO_y[s56,'tot',t] =E= sum(energy19$(EN_vE_y[energy19,s56,t]), EN_vE_y_VAR[energy19,s56,t]);

    #    E_vEIO_TIL_BAS_M[t]$(sum(s56,vEIO_m[s56,'tot',t])).. sum(s56,vEIO_m[s56,'tot',t]) =E= sum(energy19$(EN_vE_m[energy19,t]), EN_vE_m_VAR[energy19,t]);

    #    E_vEIO_TIL_CUS[,t]$(sum(s56,vEIO_cus[s56,'tot',t])).. sum(s56, vEIO_cus[s56,'tot',t]) =E= sum(energy19$(EN_vCUS[energy19,t]), EN_vCUS_VAR[energy19,t]);


    #    E_vEIO_ANV_RE_Produktskatter[s56,t]$(vEIO_a['TaxSub',s56,t])..  vEIO_a['TaxSub',s56,t] =E= sum((purpose,energy19), EN_vEAFG_RE_VAR[purpose,energy19,s56,t]$(EN_vEAFG_RE[purpose,energy19,s56,t]) 
    #                                                                                                                  + EN_vCO2_RE_VAR[purpose,energy19,s56,t]$(EN_vCO2_RE[purpose,energy19,s56,t])
    #                                                                                                                  + EN_vPSO_RE_VAR[purpose,energy19,s56,t]$(EN_vPSO_RE[purpose,energy19,s56,t])
    #                                                                                                                  + EN_vNOx_RE_VAR[purpose,energy19,s56,t]$(EN_vNOx_RE[purpose,energy19,s56,t])
    #                                                                                                                  + EN_vSO2_RE_VAR[purpose,energy19,s56,t]$(EN_vSO2_RE[purpose,energy19,s56,t]));

    #    E_vEIO_ANV_RE_MOMS[s56,t]$(vEIO_a['MOMS',s56,t])..  vEIO_a['MOMS',s56,t] =E= sum((purpose,energy19), EN_vMOMS_RE_VAR[purpose,energy19,s56,t]$(EN_vMOMS_RE[purpose,energy19,s56,t]));

    #    E_vEIO_ANV_CE_Produktskatter[t]$(vEIO_a['TaxSub','cENE',t])..  vEIO_a['TaxSub','cENE',t] =E= sum((purpose,energy19), EN_vEAFG_CE_VAR[purpose,energy19,t]$(EN_vEAFG_CE[purpose,energy19,t]) 
    #                                                                                                                       + EN_vCO2_CE_VAR[purpose,energy19,t]$(EN_vCO2_CE[purpose,energy19,t])
    #                                                                                                                       + EN_vPSO_CE_VAR[purpose,energy19,t]$(EN_vPSO_CE[purpose,energy19,t])
    #                                                                                                                       + EN_vNOx_CE_VAR[purpose,energy19,t]$(EN_vNOx_CE[purpose,energy19,t])
    #                                                                                                                       + EN_vSO2_CE_VAR[purpose,energy19,t]$(EN_vSO2_CE[purpose,energy19,t]));

    #    E_vEIO_ANV_CE_MOMS[t]$(vEIO_a['MOMS','cENE',t])..  vEIO_a['MOMS','cENE',t] =E= sum((purpose,energy19), EN_vVAT_CE_VAR[purpose,energy19,t]$(EN_vMOMS_CE[purpose,energy19,t]));

    #    E_vEIO_ANV_LE_Produktskatter[t]$(vEIO_a['TaxSub','invt',t])..  vEIO_a['TaxSub','invt',t] =E= sum((purpose,energy19), EN_vEAFG_LE_VAR[purpose,energy19,t]$(EN_vEAFG_LE[purpose,energy19,t]) 
    #                                                                                                                           + EN_vCO2_LE_VAR[purpose,energy19,t]$(EN_vCO2_LE[purpose,energy19,t])
    #                                                                                                                           + EN_vSO2_LE_VAR[purpose,energy19,t]$(EN_vSO2_LE[purpose,energy19,t]));

    #    E_vEIO_ANV_LE_MOMS[t]$(vEIO_a['MOMS','INVT',t])..  vEIO_a['MOMS','INVT',t] =E= sum((purpose,energy19), EN_vMOMS_LE_VAR[purpose,energy19,t]$(EN_vMOMS_LE[purpose,energy19,t]));


    #    E_vEIO_ANV_XE_Produktskatter[t]$(vEIO_a['TaxSub','xOth',t])..  vEIO_a['TaxSub','xOth't] =E= sum((purpose,energy19), EN_vEAFG_XE_VAR[purpose,energy19,t]$(EN_vEAFG_XE[purpose,energy19,t]) 
    #                                                                                                                      + EN_vCO2_XE_VAR[purpose,energy19,t]$(EN_vCO2_XE[purpose,energy19,t])
    #                                                                                                                      + EN_vPSO_XE_VAR[purpose,energy19,t]$(EN_vPSO_XE[purpose,energy19,t])
    #                                                                                                                      + EN_vSO2_XE_VAR[purpose,energy19,t]]$(EN_vSO2_XE[purpose,energy19,t]));

    #    E_vEIO_ANV_XE_MOMS[t]$(vEIO_a['MOMS','xOth',t])..  vEIO_a['MOMS','xOth',t] =E= sum((purpose,energy19), EN_vMOMS_XE_VAR[purpose,energy19,t]$(EN_vMOMS_XE[purpose,energy19,t]));


    #    E_qObjV..    obj =E= sum((purpose,energy19,r,t)$(EN_vnRE_VAR.l[purpose,energy19,r,t]), sqr(EN_vnRE_VAR[purpose,energy19,r,t]/EN_vnRE_VAR.l[purpose,energy19,r,t] -1)) 
    #                        +sum((purpose,energy19,t)$(EN_vnCE_VAR.l[purpose,energy19,t]), sqr(EN_vnCE_VAR[purpose,energy19,t]/EN_vnCE_VAR.l[purpose,energy19,t] -1))
    #                        +sum((purpose,energy19,t)$(EN_vnLE_VAR.l[purpose,energy19,t]), sqr(EN_vnLE_VAR[purpose,energy19,t]/EN_vnLE_VAR.l[purpose,energy19,t] -1))
    #                        +sum((purpose,energy19,t)$(EN_vnXE_VAR.l[purpose,energy19,t]), sqr(EN_vnXE_VAR[purpose,energy19,t]/EN_vnXE_VAR.l[purpose,energy19,t] -1))
    #                        +sum((energy19,r,t)$(EN_vE_y_VAR.l[energy19,r,t]), sqr(EN_vE_y_VAR[energy19,r,t]/EN_vE_y_VAR.l[energy19,r,t] -1))
    #                        +sum((energy19,t)$(EN_vE_m_VAR.l[energy19,t]), sqr(EN_vE_m_VAR[energy19,t]/EN_vE_m_VAR.l[energy19,t] - 1))
    #                        +sum((energy19,t)$(EN_vCUS_VAR.l[energy19,t]), sqr(EN_vCUS_VAR[energy19,t]/EN_vCUS_VAR.l[energy19,t] - 1));


    #  $ENDBLOCK 



    #  EN_qCE[purpose,energy19,t]$(EN_qCE[purpose,energy19,t] < %min_level_energy%) = 0; 
    #  EN_qLE[purpose,energy19,t]$(abs(EN_qLE[purpose,energy19,t]) < %min_level_energy%) = 0;
    #  EN_qRE[purpose,energy19,r,t]$(EN_qRE[purpose,energy19,r,t] < %min_level_energy%) = 0; 
    #  EN_qXE[purpose,energy19,t]$(EN_qXE[purpose,energy19,t] < %min_level_energy%) = 0;

    #  EN_vnCE[purpose,energy19,t]$(not EN_qCE[purpose,energy19,t]) = 0;
    #  EN_vnLE[purpose,energy19,t]$(not EN_qLE[purpose,energy19,t]) = 0;
    #  EN_vnRE[purpose,energy19,r,t]$(not EN_qRE[purpose,energy19,r,t]) = 0;
    #  EN_vnXE[purpose,energy19,t]$(not EN_qXE[purpose,energy19,t]) = 0;

    #  EN_vCO2_CE[purpose,energy19,t]$(not EN_qCE[purpose,energy19,t])      = 0;
    #  EN_vCO2_RE[purpose,energy19,r,t]$(not EN_qRE[purpose,energy19,r,t])    = 0; 
    #  EN_vEAFG_CE[purpose,energy19,t]$(not EN_qCE[purpose,energy19,t])       = 0; 
    #  EN_vEAFG_RE[purpose,energy19,r,t]$(not EN_qRE[purpose,energy19,r,t])   = 0;
    #  EN_vEAFG_XE[purpose,energy19,t]$(not EN_qXE[purpose,energy19,t])       = 0;  
    #  EN_vSO2_CE[purpose,energy19,t]$(not EN_qCE[purpose,energy19,t])        = 0;
    #  EN_vSO2_RE[purpose,energy19,r,t]$(not EN_qRE[purpose,energy19,r,t])    = 0;
    #  EN_vPSO_CE[purpose,energy19,t]$(not EN_qCE[purpose,energy19,t])        = 0;
    #  EN_vPSO_RE[purpose,energy19,r,t]$(not EN_qRE[purpose,energy19,r,t])    = 0;
    #  EN_vPSO_XE[purpose,energy19,t]$(not EN_qXE[purpose,energy19,t])        = 0;
    #  EN_vNOx_CE[purpose,energy19,t]$(not EN_qCE[purpose,energy19,t])        = 0;
    #  EN_vNOx_RE[purpose,energy19,r,t]$(not EN_qRE[purpose,energy19,r,t])    = 0;
    #  EN_vMOMS_CE[purpose,energy19,t] $(not EN_qCE[purpose,energy19,t])      = 0;
    #  EN_vMOMS_RE[purpose,energy19,r,t]$(not EN_qRE[purpose,energy19,r,t])   = 0; 





  #---------------------------------------------------------------------------------------------
  #  RAS-afstemning
  #---------------------------------------------------------------------------------------------

  set_data_periods(2014,2019);

  $GROUP G_ras   Entropy_RAS "Minimization criteria RAS";

  $GROUP G_RASxIO $LOOP IOxE: ,RAS_{name}{sets} "" $ENDLOOP;
  $LOOP IOxE: RAS_{name}.l{sets} = {name}{sets}; $ENDLOOP

  $PGROUP G_RAS_xIOchange $LOOP IOxE: ,RASchange_{name}{sets} "" $ENDLOOP ;
  $LOOP IOxE: RASchange_{name}{sets} = {name}{sets}; $ENDLOOP


  $PGROUP G_RAS_xIOpre $LOOP IOxE: ,RASpre_{name}{sets} "" $ENDLOOP;
  $LOOP IOxE: RASpre_{name}{sets} = {name}{sets}; $ENDLOOP


  $PGROUP G_RAS_xIOpost $LOOP IOxE: ,RASpost_{name}{sets} "" $ENDLOOP;
  $LOOP IOxE: RASpost_{name}{sets} = {name}{sets}; $ENDLOOP;


  $GROUP G_RASEIO $LOOP EIO: ,RAS_{name}{sets} "" $ENDLOOP;
  $LOOP EIO: RAS_{name}.l{sets} = {name}{sets}; $ENDLOOP


  
  $GROUP G_RAS_tax19
    RAS_vAfgxE_56_y[s56_,IO_56_c_,afgsub,t] ""
    RAS_vAfgxE_56_m[s56_,IO_56_c_,afgsub,t] ""
    RAS_vSubxE_56_y[s56_,IO_56_c_,afgsub,t] ""
    RAS_vSubxE_56_m[s56_,IO_56_c_,afgsub,t] ""

    RAS_tAfgxE_56_y[s56_,IO_56_c_,afgsub,t] ""
    RAS_tAfgxE_56_m[s56_,IO_56_c_,afgsub,t] ""
    RAS_tSubxE_56_y[s56_,IO_56_c_,afgsub,t] ""
    RAS_tSubxE_56_m[s56_,IO_56_c_,afgsub,t] ""

    RAS_vIOxE_cus[s56_,IO_56_c_,t] ""
 ;


  $BLOCK B_RAS_xIO
    E_entropy..
      Entropy_RAS =E= sum((s56,IO_56_c,t)$(vIOxE_y[s56,IO_56_c,t] and tDatax1[t]),    sqrt(sqr(RAS_vIOxE_y[s56,IO_56_c,t]))            * (log(sqrt(sqr(RAS_vIOxE_y[s56,IO_56_c,t]     /vIOxE_y[s56,IO_56_c,t]     )))-1))
                    + sum((s56,IO_56_c,t)$(vIOxE_m[s56,IO_56_c,t] and tDatax1[t]),    sqrt(sqr(RAS_vIOxE_m[s56,IO_56_c,t]))            * (log(sqrt(sqr(RAS_vIOxE_m[s56,IO_56_c,t]     /vIOxE_m[s56,IO_56_c,t]     )))-1))
                    + sum((IO_56_c,t)$(vIOxE_a['TaxSub',IO_56_c,t] and tData1[t]),    sqrt(sqr(RAS_vIOxE_a['TaxSub',IO_56_c,t]))       * (log(sqrt(sqr(RAS_vIOxE_a['TaxSub',IO_56_c,t]/vIOxE_a['TaxSub',IO_56_c,t])))-1))
                    + sum((IO_56_c,t)$(vIOxE_a['Moms',IO_56_c,t] and tData1[t]),      sqrt(sqr(RAS_vIOxE_a['Moms',IO_56_c,t]))         * (log(sqrt(sqr(RAS_vIOxE_a['Moms',IO_56_c,t]  /vIOxE_a['Moms',IO_56_c,t]  )))-1))
                    + sum((s56,IO_56_c,t)$(vIOxE_cus[s56,IO_56_c,t] and tData1[t]),   sqrt(sqr(RAS_vIOxE_cus[s56,IO_56_c,t]))          * (log(sqrt(sqr(RAS_vIOxE_cus[s56,IO_56_c,t]   /vIOxE_cus[s56,IO_56_c,t]   )))-1))
                    ;


    #Restrictions
      #Full IO
      E_rowsum_y[s56,t]$(tDatax1[t] and vIOxE_y[s56,'tot',t]).. 
        vIOxE_y[s56,'tot',t]
        =E= 
        sum(IO_56_c$vIOxE_y[s56,IO_56_c,t], RAS_vIOxE_y[s56,IO_56_c,t]);

      E_rowsum_m[s56,t]$(tDatax1[t] and vIOxE_m[s56,'tot',t]).. 
        vIOxE_m[s56,'tot',t]
        =E= 
        sum(IO_56_c$vIOxE_m[s56,IO_56_c,t], RAS_vIOxE_m[s56,IO_56_c,t]);

      E_rowsum_a[a_rows,t]$(tDatax1[t] and vIOxE_a[a_rows,'tot',t])..
            vIOxE_a[a_rows,'tot',t] 
            =E= RAS_vIOxE_a[a_rows,'tot',t]$(vIOxE_a[a_rows,'tot',t]);
            

      #Customs on non-energyy
      E_rowsum_cus[s56,t]$(tDatax1[t] and vIOxE_cus[s56,'tot',t])..
        vIOxE_cus[s56,'tot',t] =E= sum(IO_56_c$(vIOxE_cus[s56,IO_56_c,t]), RAS_vIOxE_cus[s56,IO_56_c,t]);

      #  E_colsum_cus[IO_56_c,t]$(tDatax1[t] and vIOxE_cus['tot',IO_56_c,t])..
      #    vIOxE_cus['tot',IO_56_c,t] =E= sum(s56$(vIOxE_cus[s56,IO_56_c,t]), RAS_vIOxE_cus[s56,IO_56_c,t]);



      #Bevarelse af søjletotaler
      E_colsum[IO_56_c,t]$(tDatax1[t] and (vIOxE_y['tot',IO_56_c,t] or vIOxE_m['tot',IO_56_c,t])).. # and not sameas[IO_56_c,'invt']).. 
        vIOxE_y['tot',IO_56_c,t] 
      + vIOxE_m['tot',IO_56_c,t] 
      + vIOxE_a['TaxSub',IO_56_c,t] 
      + vIOxE_a['Moms',IO_56_c,t]  
     
         =E=   
             sum(s56$(vIOxE_y[s56,IO_56_c,t]), RAS_vIOxE_y[s56,IO_56_c,t]) 
            + sum(s56$(vIOxE_m[s56,IO_56_c,t]), RAS_vIOxE_m[s56,IO_56_c,t])
            + RAS_vIOxE_a['TaxSub',IO_56_c,t]$(vIOxE_a['TaxSub',IO_56_c,t]) 
            + RAS_vIOxE_a['Moms',IO_56_c,t]$(vIOxE_a['Moms',IO_56_c,t]);


  $ENDBLOCK 

  $MODEL M_RAS
    B_RAS_xIO
  ;
  #Where's zero 


  PARAMETER RAS_min "Minimum cell-value for RAS";
  RAS_min = 10**6/10**9; #We set minimum cell-value to 1 mio. kr.

  #Randtotaler vi gerne vil ramme
    #  vIOxE_y['19000',IO_56_c,t] = 0; #Dræber raffinaderierne ikke-energi    
    #  vIOxE_m['19000',IO_56_c,t] = 0; #Dræber raffinaderierne ikke-energi
    
    #  vIOxE_y['38393',IO_56_c,t] = 0; #Affaldforbrændingernes ikke-energi
    #  vIOxE_m['38393',IO_56_c,t] = 0; #Affaldforbrændingernes ikke-energi     

    #  vIOxE_y['35002',IO_56_c,t] = 0; #Gasdistributionens ikke-energi
    #  vIOxE_m['35002',IO_56_c,t] = 0; #Gasdistributionens ikke-energi     
  
  #THere's the tiniest bit of energy left in non-energy IO. We move this to "goods" instead
  #  vIOxE_y[s56_,'cNonFood',t]$(tData[t] and  vIOxE_y[s56_,'cEne',t]) = vIOxE_y[s56_,'cNonFood',t] + vIOxE_y[s56_,'cEne',t];
  #  #  vEIO_y[s56_,'cENE',t]  = vEIO_y[s56_,'cENE',t] +  vIOxE_y[s56_,'cEne',t];
  vIOxE_y[s56_,'cNonFood',t]  = vIOxE_y[s56_,'cNonFood',t] + vIOxE_y[s56_,'cHouEne',t] + vIOxE_y[s56_,'cCarEne',t]; 
  vIOxE_y[s56_,'cHouEne',t]      = 0;
  vIOxE_y[s56_,'cCarEne',t]      = 0;

  #  vIOxE_m[s56_,'cNonFood',t]$(tData[t] and  vIOxE_m[s56_,'cEne',t]) = vIOxE_m[s56_,'cNonFood',t] + vIOxE_m[s56_,'cEne',t];
  vIOxE_m[s56_,'cNonFood',t]  = vIOxE_m[s56_,'cNonFood',t] + vIOxE_m[s56_,'cHouEne',t] + vIOxE_m[s56_,'cCarEne',t]; 
  vIOxE_m[s56_,'cHouEne',t]      = 0; 
  vIOxE_m[s56_,'cCarEne',t]      = 0; 

  #  vIOxE_cus[s56_,'cNonFood',t]$(tData[t] and  vIOxE_cus[s56_,'cEne',t]) = vIOxE_cus[s56_,'cNonFood',t] + vIOxE_cus[s56_,'cEne',t];
  vIOxE_cus[s56_,'cNonFood',t]  = vIOxE_cus[s56_,'cNonFood',t] + vIOxE_cus[s56_,'cHouEne',t] + vIOxE_cus[s56_,'cCarEne',t]; 
  vIOxE_cus[s56_,'cHouEne',t]      = 0;
  vIOxE_cus[s56_,'cCarEne',t]      = 0; 

  #  vIOxE_a[a_rows_,'cNonFood',t]$(tData[t] and  vIOxE_a[a_rows_,'cEne',t]) = vIOxE_a[a_rows_,'cNonFood',t] + vIOxE_a[a_rows_,'cEne',t];
  vIOxE_a[a_rows_,'cNonFood',t]  = vIOxE_a[a_rows_,'cNonFood',t] + vIOxE_a[a_rows_,'cHouEne',t] + vIOxE_a[a_rows_,'cCarEne',t];  
  vIOxE_a[a_rows_,'cHouEne',t]      = 0; 
  vIOxE_a[a_rows_,'cCarEne',t]      = 0;   

  #  vIOxE_y[s56,'tot',t]         = sum(IO_56_c, vIOxE_y[s56,IO_56_c,t]);
  #  vIOxE_m[s56,'tot',t]         = sum(IO_56_c, vIOxE_m[s56,IO_56_c,t]);
  #  vIOxE_a[a_rows,'tot',t]      = sum(IO_56_c, vIOxE_a[a_rows,IO_56_c,t]);


  #  vIOxE_y['tot',IO_56_c,t]     = sum(s56, vIOxE_y[s56,IO_56_c,t]);
  #  vIOxE_m['tot',IO_56_c,t]     = sum(s56, vIOxE_m[s56,IO_56_c,t]);
  #  vIOxE_a['tot',IO_56_c,t]     = sum(a_rows, vIOxE_a[a_rows,IO_56_c,t]);

  #Særbehandling: Gartneri, maskinstation til kvæg og foder til fjerkræ
     PARAMETER vIOxE_y_diff_tilnotat[s56,r56,t];
      vIOxE_y_diff_tilnotat[s56,r56,t] = vIOxE_y[s56,r56,t];

    #Udsæd
      vIOxE_y['01020','01020','2019'] = vIOxE_y['01020','01020','2019'] + (0.72-0.188); #Ca. en halv milliard udsæd. 
      vIOxE_y['01011','01011','2019'] = vIOxE_y['01011','01011','2019'] - (0.72-0.188); #Ca. en halv milliard udsæd. 

    #Emballage 
      vIOxE_y['46000','01020','2019'] = vIOxE_y['46000','01020','2019'] + 0.314; #340 mio. salgsemballage (ligger 26 mio. i forvejen)
      vIOxE_y['46000','01011','2019'] = vIOxE_y['46000','01011','2019'] - 0.314; #

    #Maskinstation 
      PARAMETER maskinstationkvaeg_foer[s56,t];
      maskinstationkvaeg_foer['01031','2019'] = vIOxE_y['01080','01031','2019'];
      maskinstationkvaeg_foer['01032','2019'] = vIOxE_y['01080','01032','2019'];

      vIOxE_y['01080','01011','2019'] = vIOxE_y['01080','01011','2019'] + 2/3*maskinstationkvaeg_foer['01031','2019']; #Det vurderes pba. af korrespondance m. DST at der er placeret ca. 2/3 for meget maskinstation hos kvægbrug
      vIOxE_y['01080','01012','2019'] = vIOxE_y['01080','01012','2019'] + 2/3*maskinstationkvaeg_foer['01032','2019'];
      vIOxE_y['01080','01031','2019'] = vIOxE_y['01080','01031','2019'] - 2/3*maskinstationkvaeg_foer['01031','2019']; 
      vIOxE_y['01080','01032','2019'] = vIOxE_y['01080','01032','2019'] - 2/3*maskinstationkvaeg_foer['01032','2019'];  
      

      #Maskinstationværdierne i IO er meget høje ift. regnskabsstatistikken. Vi flytter den 1.5 mia. "for meget" i IO til egenproduktion i maskinstationsbranchen. I landbrugsstatistikskontoret i DST opfatter man det sådan at maskinstation også bruges 
      #uden for landbruget, hvilket måske kan forklare forskelleni maskinstation
      #
      vIOxE_y['01080','01011','2019'] = vIOxE_y['01080','01011','2019'] - 21/23*1.5;
      vIOxE_y['01080','01012','2019'] = vIOxE_y['01080','01012','2019'] - 2/23*1.5;

      vIOxE_y['01080','01080','2019'] = vIOxE_y['01080','01080','2019'] + 1.5; 

    #Foder til animalsk
      PARAMETER fodertilkvaeg, fodertiloekokvaeg;
      fodertilkvaeg = vIOxE_y['01011','01031','2019']; fodertiloekokvaeg = vIOxE_y['01012','01032','2019'];

      vIOxE_y['01011','01031','2019'] = vIOxE_y['01011','01031','2019'] - 0.75*fodertilkvaeg;
      
      $IF %smaagrisesplit%!=1:
      vIOxE_y['01011','01051','2019'] = vIOxE_y['01011','01051','2019'] + (0.75 * fodertilkvaeg );
      $ENDIF 

      $IF %smaagrisesplit%==1:
      vIOxE_y['01011','01052','2019'] = vIOxE_y['01011','01052','2019'] + (0.75 * fodertilkvaeg );

      vIOxE_y['10120','01052','2019'] = vIOxE_y['10120','01052','2019'] + 1; #Flytter 1 mia. kroner fra smågrise -> slagtesvin for bedre at aligne med oversigtstabel
      vIOxE_y['10120','01051','2019'] = vIOxE_y['10120','01051','2019'] - 1; #Flytter 1 mia. kroner fra smågrise -> slagtesvin for bedre at aligne med oversigtstabel
      vIOxE_a['SalEmpl','01051','2019'] = vIOxE_a['SalEmpl','01051','2019'] + 0.6; #Flytter 0.6 mia. kroner fra slagtesvin -> smågrise, da de har højere lønomk.
      vIOxE_a['SalEmpl','01052','2019'] = vIOxE_a['SalEmpl','01052','2019'] - 0.6; #Flytter 0.6 mia. kroner fra slagtesvin -> smågrise, da de har højere lønomk. 
      $ENDIF

    #Det ændrer i randtotaler 
      vIOxE_y['tot','01020','2019'] = vIOxE_y['tot','01020','2019'] + (0.72-0.188); #Forbruget af Udsæd
      vIOxE_y['tot','01011','2019'] = vIOxE_y['tot','01011','2019'] - (0.72-0.188); #Forbruget af Udsæd

      vIOxE_y['tot','01011','2019'] = vIOxE_y['tot','01011','2019'] + 2/3*maskinstationkvaeg_foer['01031','2019']; #Maskinstation
      vIOxE_y['tot','01012','2019'] = vIOxE_y['tot','01012','2019'] + 2/3*maskinstationkvaeg_foer['01032','2019']; #Maskinstation
      vIOxE_y['tot','01031','2019'] = vIOxE_y['tot','01031','2019'] - 2/3*maskinstationkvaeg_foer['01031','2019']; #Maskinstation
      vIOxE_y['tot','01032','2019'] = vIOxE_y['tot','01032','2019'] - 2/3*maskinstationkvaeg_foer['01032','2019']; #Maskinstation

      vIOxE_y['tot','01011','2019'] = vIOxE_y['tot','01011','2019'] -21/23*1.5; #Maskinstation pt. 2
      vIOxE_y['tot','01012','2019'] = vIOxE_y['tot','01012','2019'] -2/23*1.5; #Maskinstation pt. 2
      vIOxE_y['tot','01080','2019'] = vIOxE_y['tot','01080','2019'] + 1.5;    #Maskinstation pt. 2

      vIOxE_y['01020','tot','2019'] = vIOxE_y['01020','tot','2019'] + (0.72-0.188); #Udsæd
      vIOxE_y['01011','tot','2019'] = vIOxE_y['01011','tot','2019'] - (0.72-0.188); #Udsæd

      vIOxE_y['tot','01011','2019'] = vIOxE_y['tot','01011','2019'] - 0.314; #Emballage 
      vIOxE_y['tot','01020','2019'] = vIOxE_y['tot','01020','2019'] + 0.314; #Emballage

      vIOxE_a['OvProd','01011','2019'] = vIOxE_a['OvProd','01011','2019'] + 0.314; #Emballage øger overskuddet
      vIOxE_a['OvProd','01020','2019'] = vIOxE_a['OvProd','01020','2019'] - 0.314; #Emballage, men sænker det i gartneri
      
      vIOxE_a['OvProd','01011','2019'] = vIOxE_a['OvProd','01011','2019'] - 2/3*maskinstationkvaeg_foer['01031','2019'];
      vIOxE_a['OvProd','01012','2019'] = vIOxE_a['OvProd','01012','2019'] - 2/3*maskinstationkvaeg_foer['01032','2019'];
      vIOxE_a['OvProd','01031','2019'] = vIOxE_a['OvProd','01031','2019'] + 2/3*maskinstationkvaeg_foer['01031','2019'];
      vIOxE_a['OvProd','01032','2019'] = vIOxE_a['OvProd','01032','2019'] + 2/3*maskinstationkvaeg_foer['01032','2019'];

      vIOxE_a['OvProd','01011','2019'] = vIOxE_a['OvProd','01011','2019'] + 21/23*1.5; 
      vIOxE_a['OvProd','01012','2019'] = vIOxE_a['OvProd','01012','2019'] + 2/23 *1.5;
      vIOxE_a['OvProd','01080','2019'] = vIOxE_a['OvProd','01080','2019'] - 1.5;

      vIOxE_a['tot','01011','2019'] = vIOxE_a['tot','01011','2019'] + 0.314; #Emballage 
      vIOxE_a['tot','01020','2019'] = vIOxE_a['tot','01020','2019'] - 0.314; #Emballage

      vIOxE_a['tot','01011','2019'] = vIOxE_a['tot','01011','2019'] - 2/3*maskinstationkvaeg_foer['01031','2019'];
      vIOxE_a['tot','01012','2019'] = vIOxE_a['tot','01012','2019'] - 2/3*maskinstationkvaeg_foer['01032','2019'];
      vIOxE_a['tot','01031','2019'] = vIOxE_a['tot','01031','2019'] + 2/3*maskinstationkvaeg_foer['01031','2019'];
      vIOxE_a['tot','01032','2019'] = vIOxE_a['tot','01032','2019'] + 2/3*maskinstationkvaeg_foer['01032','2019'];

      vIOxE_a['tot','01011','2019'] = vIOxE_a['tot','01011','2019'] + 21/23*1.5; 
      vIOxE_a['tot','01012','2019'] = vIOxE_a['tot','01012','2019'] + 2/23 *1.5;   
      vIOxE_a['tot','01080','2019'] = vIOxE_a['tot','01080','2019'] - 1.5;

      #FODER
      vIOxE_y['tot','01031','2019'] = vIOxE_y['tot','01031','2019'] - 0.75*fodertilkvaeg;
      #  vIOxE_y['tot','01032','2019'] = vIOxE_y['tot','01032','2019'] - 0.75*fodertiloekokvaeg;
      $IF %smaagrisesplit%!=1:
      vIOxE_y['tot','01051','2019'] = vIOxE_y['tot','01051','2019'] + (0.75*fodertilkvaeg);
      $ENDIF 

      #Hvis smågrisesplit flytter vi til 01052 som nu er slagtesvin
      $IF %smaagrisesplit%==1:
      vIOxE_y['tot','01052','2019'] = vIOxE_y['tot','01052','2019'] + (0.75*fodertilkvaeg) + 1;
      vIOxE_y['tot','01051','2019'] = vIOxE_y['tot','01051','2019'] - 1;
      $ENDIF 

      #  vIOxE_y['tot','01052','2019'] = vIOxE_y['tot','01052','2019'] + (0.75*fodertiloekokvaeg-0.01);
      #  vIOxE_y['tot','01052','2019'] = vIOxE_y['tot','01052','2019'] + 0.75*fodertiloekokvaeg;
      #  vIOxE_y['tot','01061','2019'] = vIOxE_y['tot','01061','2019'] + 0.05;
      #  vIOxE_y['tot','01062','2019'] = vIOxE_y['tot','01062','2019'] + 0.01;

      vIOxE_a['OvProd','01031','2019'] = vIOxE_a['OvProd','01031','2019'] + 0.75*fodertilkvaeg;
      #  vIOxE_a['OvProd','01032','2019'] = vIOxE_a['OvProd','01032','2019'] + 0.75*fodertiloekokvaeg;

      $IF %smaagrisesplit%!=1:
      vIOxE_a['OvProd','01051','2019'] = vIOxE_a['OvProd','01051','2019'] - (0.75*fodertilkvaeg);
      $ENDIF 

      $IF %smaagrisesplit%==1:
      vIOxE_a['OvProd','01052','2019'] = vIOxE_a['OvProd','01052','2019'] - (0.75*fodertilkvaeg) - 1 + 0.6;
      vIOxE_a['OvProd','01051','2019'] = vIOxE_a['OvProd','01051','2019'] + 1 - 0.6;

      $ENDIF 

      #  vIOxE_a['OvProd','01052','2019'] = vIOxE_a['OvProd','01052','2019'] - (0.75*fodertiloekokvaeg-0.01);
      #  vIOxE_a['OvProd','01052','2019'] = vIOxE_a['OvProd','01052','2019'] - 0.75*fodertiloekokvaeg;
      #  vIOxE_a['OvProd','01061','2019'] = vIOxE_a['OvProd','01061','2019'] - 0.05;
      #  vIOxE_a['OvProd','01062','2019'] = vIOxE_a['OvProd','01062','2019'] - 0.01;

      vIOxE_a['tot','01031','2019'] = vIOxE_a['tot','01031','2019'] + 0.75*fodertilkvaeg;
      #  vIOxE_a['tot','01032','2019'] = vIOxE_a['tot','01032','2019'] + 0.75*fodertiloekokvaeg;
      $IF %smaagrisesplit%!=1:
      vIOxE_a['tot','01051','2019'] = vIOxE_a['tot','01051','2019'] - (0.75*fodertilkvaeg);
      $ENDIF 

      $IF %smaagrisesplit%==1:
      vIOxE_a['tot','01052','2019'] = vIOxE_a['tot','01052','2019'] - (0.75*fodertilkvaeg) - 1;  #+ 0.6;
      vIOxE_a['tot','01051','2019'] = vIOxE_a['tot','01051','2019'] + 1; # -0.6;
      $ENDIF
      #  vIOxE_a['tot','01052','2019'] = vIOxE_a['tot','01052','2019'] - (0.75*fodertiloekokvaeg-0.01);
      #  vIOxE_a['tot','01052','2019'] = vIOxE_a['tot','01052','2019'] - 0.75*fodertiloekokvaeg;
      #  vIOxE_a['tot','01061','2019'] = vIOxE_a['tot','01061','2019'] - 0.05;
      #  vIOxE_a['tot','01062','2019'] = vIOxE_a['tot','01062','2019'] - 0.01;

      vIOxE_y_diff_tilnotat[s56,r56,t] = vIOxE_y[s56,r56,t]-vIOxE_y_diff_tilnotat[s56,r56,t];

      #Grundskyld
        #Grundskylden korrigeres for 2 forhold. 1) Produktionsgrensopsplitningen er ikke indgået i opsplitningen og der er for meget grunskyld på de ikke jordbrugende brancher. 2) I Nationalregnskabet figurerer en "opregningsfaktor" på grunskylden i landbruget. Denne gør at grundskylden overvurderes. 
        PARAMETER grundskyld19[s56], grundskyldagr_tot2019, vIOxE_a_before[a_rows_,s56_,t];
        grundskyld19[s56] = vpSkatSub_56['art4400',s56,'2019'];
        vIOxE_a_before[a_rows_,s56_,t] = vIOxE_a[a_rows_,s56_,t];

        grundskyldagr_tot2019 = vpSkatSub_56['art4400','01011','2019'] 
                              + vpSkatSub_56['art4400','01012','2019'] 
                              + vpSkatSub_56['art4400','01020','2019'] 
                              + vpSkatSub_56['art4400','01031','2019'] 
                              + vpSkatSub_56['art4400','01032','2019']
                              + vpSkatSub_56['art4400','01051','2019'] 
                              + vpSkatSub_56['art4400','01052','2019'] 
                              + vpSkatSub_56['art4400','01061','2019'] 
                              + vpSkatSub_56['art4400','01062','2019'] 
                              + vpSkatSub_56['art4400','01070','2019'] 
                              + vpSkatSub_56['art4400','01080','2019']; 
                                                                                  #Tabel EJDSK3 på Statistikbanken giver 0.933276 mia. kr. grundskyld i landbruget i 2019

                                                                                              #Tælleren = konventionl jord i drift+ ude for drift. Nævner = al jord
        vpSkatSub_56['art4400','01011','2019'] = 0; vpSkatSub_56['art4400','01011','2019'] = 0.933276 * (2.0427231212242   + 0.350454)/(2.0427231212242 + 0.350454  + 0.168782105384598 + 0.028957 + 0.035053); 
        vpSkatSub_56['art4400','01012','2019'] = 0; vpSkatSub_56['art4400','01012','2019'] = 0.933276 * (0.168782105384598 + 0.028957)/(2.0427231212242 + 0.350454  + 0.168782105384598 + 0.028957 + 0.035053); 
        vpSkatSub_56['art4400','01020','2019'] = 0; vpSkatSub_56['art4400','01020','2019'] = 0.933276 * (0.035053)                    /(2.0427231212242 + 0.350454  + 0.168782105384598 + 0.028957 + 0.035053); 
        vpSkatSub_56['art4400','01031','2019'] = 0;
        vpSkatSub_56['art4400','01032','2019'] = 0;
        vpSkatSub_56['art4400','01051','2019'] = 0;
        vpSkatSub_56['art4400','01052','2019'] = 0;
        vpSkatSub_56['art4400','01061','2019'] = 0;
        vpSkatSub_56['art4400','01062','2019'] = 0;
        vpSkatSub_56['art4400','01070','2019'] = 0; vpSkatSub_56['art4400','01070','2019'] = grundskyldagr_tot2019 - 0.933276; #Minkbranchen bliver "skraldespand" for 
        vpSkatSub_56['art4400','01080','2019'] = 0;

        #
        vIOxE_a['OthTax','01011','2019'] = sum(artskat, vpSkatSub_56[artskat,'01011','2019']);
        vIOxE_a['OthTax','01012','2019'] = sum(artskat, vpSkatSub_56[artskat,'01012','2019']);
        vIOxE_a['OthTax','01020','2019'] = sum(artskat, vpSkatSub_56[artskat,'01020','2019']);
        vIOxE_a['OthTax','01031','2019'] = sum(artskat, vpSkatSub_56[artskat,'01031','2019']);
        vIOxE_a['OthTax','01032','2019'] = sum(artskat, vpSkatSub_56[artskat,'01032','2019']);
        vIOxE_a['OthTax','01051','2019'] = sum(artskat, vpSkatSub_56[artskat,'01051','2019']);
        vIOxE_a['OthTax','01052','2019'] = sum(artskat, vpSkatSub_56[artskat,'01052','2019']);
        vIOxE_a['OthTax','01061','2019'] = sum(artskat, vpSkatSub_56[artskat,'01061','2019']);
        vIOxE_a['OthTax','01062','2019'] = sum(artskat, vpSkatSub_56[artskat,'01062','2019']);
        vIOxE_a['OthTax','01070','2019'] = sum(artskat, vpSkatSub_56[artskat,'01070','2019']);
        vIOxE_a['OthTax','01080','2019'] = sum(artskat, vpSkatSub_56[artskat,'01080','2019']);

        vIOxE_a['OvProd','01011','2019'] = vIOxE_a['OvProd','01011','2019'] + vIOxE_a['tot','01011','2019'] - sum(a_rows, vIOxE_a[a_rows,'01011','2019']);
        vIOxE_a['OvProd','01012','2019'] = vIOxE_a['OvProd','01012','2019'] + vIOxE_a['tot','01012','2019'] - sum(a_rows, vIOxE_a[a_rows,'01012','2019']);
        vIOxE_a['OvProd','01020','2019'] = vIOxE_a['OvProd','01020','2019'] + vIOxE_a['tot','01020','2019'] - sum(a_rows, vIOxE_a[a_rows,'01020','2019']);
        vIOxE_a['OvProd','01031','2019'] = vIOxE_a['OvProd','01031','2019'] + vIOxE_a['tot','01031','2019'] - sum(a_rows, vIOxE_a[a_rows,'01031','2019']);
        vIOxE_a['OvProd','01032','2019'] = vIOxE_a['OvProd','01032','2019'] + vIOxE_a['tot','01032','2019'] - sum(a_rows, vIOxE_a[a_rows,'01032','2019']);
        vIOxE_a['OvProd','01051','2019'] = vIOxE_a['OvProd','01051','2019'] + vIOxE_a['tot','01051','2019'] - sum(a_rows, vIOxE_a[a_rows,'01051','2019']);
        vIOxE_a['OvProd','01052','2019'] = vIOxE_a['OvProd','01052','2019'] + vIOxE_a['tot','01052','2019'] - sum(a_rows, vIOxE_a[a_rows,'01052','2019']);
        vIOxE_a['OvProd','01061','2019'] = vIOxE_a['OvProd','01061','2019'] + vIOxE_a['tot','01061','2019'] - sum(a_rows, vIOxE_a[a_rows,'01061','2019']);
        vIOxE_a['OvProd','01062','2019'] = vIOxE_a['OvProd','01062','2019'] + vIOxE_a['tot','01062','2019'] - sum(a_rows, vIOxE_a[a_rows,'01062','2019']);
        vIOxE_a['OvProd','01070','2019'] = vIOxE_a['OvProd','01070','2019'] + vIOxE_a['tot','01070','2019'] - sum(a_rows, vIOxE_a[a_rows,'01070','2019']);
        vIOxE_a['OvProd','01080','2019'] = vIOxE_a['OvProd','01080','2019'] + vIOxE_a['tot','01080','2019'] - sum(a_rows, vIOxE_a[a_rows,'01080','2019']);

        @computeIO()


  set s56incl(s56)/
            01011  "Plant production"
            01012  "Organic plant production"
            01020  "Horticulture"
            01031  "Cattle (incl. milk production)"
            01032  "Organic cattle (incl. milk production"
            01051  "Pig farmers"
            01052  "Organic pig farmers"
            01061  "Poulty"
            01062  "Organic poultry"
            01070  "Fur animals"
            01080  "Agricultural contractor"
            02000  "Forestry"
            03000  "Fishing"
            0600a  "Extration"
            10011 "Manufacture of bovine meat products"
            10012 "Manufacture of pig meat"
            10013 "Manufacture of poultry"
            10020 "Manufacture of fish products" #LBS
            10030 "Manufacture of dairy products" #LBS
            10040 "Manufacture of bread products" #LBS
            10120 "Manufacture of beverages and tobacco" #LBS
            13150  "Manufacture of machines and electronics"
            16000  "Manufacture of wood and wood products"
            19000  "Oil refinery etc."
            20000  "Manufacture of chemicals"
            21000  "Pharmaceuticals"
            23001  "Manufacture of other non-metallic mineral products"
            23002 
            25000  "Other manufacture industries"
            35011  "Electricity and heating production"
            35012  "Distribution, transmission and trade of electricity"
            35002  "Manufacture and distribution of gas"
            36000  "Water collection, purification and supply"
            37000  "Sewerage"
            38391  "Collection of non-harzardous and hazardous waste "
            38392  "Treatment and disposal of non-hazardous and hazardous waste"
            38393  "Disposal of energy waste"
            41430  "Construction"
            45000  "Wholesale and retail trade and repair of motor vehicles and motorcycles"
            46000  "Wholesale"
            47000  "Retail sale"
            49011  "Passenger transport by local and distance trains"
            #  49012  "Freight transport by train"
            #  49022  "Surburban trains (and metro)"
            49024  "Busses, local"
            #  49025  "Busses, distance"
            49031  "Road freight transport and transport via pipelines"
            50001  "Domestic passenger and freight transport on water"
            49509  "International transport by sea and land"
            51001  "Domestic passenger and freight transport by air plane"
            51009  "International passenger and freight transport by air plane"
            #  52000  "Support activities for transportation"
            53000  "Postal and courier activities"
            55560  "Services predominantly to private consumers"
            64000  "Financial sector"
            68203  "Housing sector"
            71000  "Services predominantly to business and exports  "
            off
            /;

  vIOxE_y[s56incl,IO_56_c,t]$(abs(vIOxE_y[s56incl,IO_56_c,t]) < RAS_min and not sameas[IO_56_c,'invt'])   = 0;



  vIOxE_cus[s56,IO_56_c,t]$(abs(vIOxE_m[s56,IO_56_c,t]) < RAS_min and not sameas[IO_56_c,'invt']) = 0; #Important customs go before removing m.
  vIOxE_m[s56,IO_56_c,t]$(abs(vIOxE_m[s56,IO_56_c,t]) < RAS_min and not sameas[IO_56_c,'invt'])   = 0;

  #  Der er udenlandske brancher, der producerer ekstremt lave værdier input som taber værdien i hele rækken. Vi flytter totalerne håndholdt til at andre brancher for at bevare BNP (hvis der kommer lign. tilfælde i fremtidigt data vil RAS-afstemningen slå ud, da den ikke kan ramme totalen for disse)
  vIOxE_m['38393',IO_56_c_,t]$(tData[t]) = 0;

  #  vIOxE_m['49012','tot',t]$(tData[t])  = vIOxE_m['49012','tot',t] + vIOxE_m['49022','tot',t];  vIOxE_m['49022','tot',t]$(tData[t]) = 0; 
  #  vIOxE_m['49012','tot',t]$(tData[t])  = vIOxE_m['49012','tot',t] + vIOxE_m['49024','tot',t];  vIOxE_m['49024','tot',t]$(tData[t]) = 0;
  vIOxE_m['01011','tot',t]$(tData[t])  = vIOxE_m['01011','tot',t] + vIOxE_m['01080','tot',t];  vIOxE_m['01080','tot',t]$(tData[t]) = 0;

  #  vIOxE_cus['49012','tot',t]$(tData[t])= vIOxE_cus['49012','tot',t] + vIOxE_cus['49022','tot',t];  vIOxE_cus['49022','tot',t]$(tData[t]) = 0; 
  #  vIOxE_cus['49012','tot',t]$(tData[t])= vIOxE_cus['49012','tot',t] + vIOxE_cus['49024','tot',t];  vIOxE_cus['49024','tot',t]$(tData[t]) = 0;
  vIOxE_cus['01011','tot',t]$(tData[t])= vIOxE_cus['01011','tot',t] + vIOxE_cus['01080','tot',t];  vIOxE_cus['01080','tot',t]$(tData[t]) = 0;

  #  vIO_m['49012','tot',t]$(tData[t])    = vIO_m['49012','tot',t] + vIO_m['49022','tot',t];  vIO_m['49022','tot',t] = 0; 
  #  vIO_m['49012','tot',t]$(tData[t])    = vIO_m['49012','tot',t] + vIO_m['49024','tot',t];  vIO_m['49024','tot',t] = 0;
  vIO_m['01011','tot',t]$(tData[t])    = vIO_m['01011','tot',t] + vIO_m['01080','tot',t];  vIO_m['01080','tot',t] = 0;



  #Der er ekstremt lavt input af energi fra udenlandsk affaldsforbrænding, 38393. Vi flytter det til udenlandsk energiforsyning, da rækkerne bliver sat til nul (ingen pointe i at have en række med så lave værdier).
  #  vIOxE_m['35011','tot',t]$(t.val = 2015 or t.val = 2016) = vIOxE_m['35011','tot',t] + vIOxE_m['38393','tot',t]; vIOxE_m['38393','tot',t]$(t.val = 2015 or t.val = 2016) = 0;
  #  vIO_m['35011','tot',t]$(t.val = 2015 or t.val = 2016)   = vIO_m['35011','tot',t]   + vIO_m['38393','tot',t]; vIO_m['38393','tot',t]$(t.val = 2015 or t.val = 2016) = 0;
  #  vEIO_m['35011','tot',t]$(t.val = 2015 or t.val = 2016)  = vEIO_m['35011','tot',t]  + vEIO_m['38393','tot',t]; vEIO_m['38393','tot',t]$(t.val = 2015 or t.val = 2016) = 0;


  #Indlæser i RAS-variable
  RAS_vIOxE_y.l[s56_,IO_56_c,t]$(tData[t])    = vIOxE_y[s56_,IO_56_c,t];# $(vIOxE_y[s56_,IO_56_c,t]     = 0) = 0;
  RAS_vIOxE_m.l[s56_,IO_56_c,t]$(tData[t])    = vIOxE_m[s56_,IO_56_c,t];# $(vIOxE_m[s56_,IO_56_c,t]     = 0) = 0;
  RAS_vIOxE_a.l[a_rows,IO_56_c,t]$(tData[t])  = vIOxE_a[a_rows,IO_56_c,t]; #$(vIOxE_a[a_rows,IO_56_c,t] = 0) = 0;  
  RAS_vIOxE_cus.l[s56,IO_56_c,t]$(tData[t])   = vIOxE_cus[s56,IO_56_c,t];

  RAS_vEIO_y.l[s56,IO_56_c,t]$(tData[t])      = vEIO_y[s56,IO_56_c,t];
  RAS_vEIO_m.l[s56,IO_56_c,t]$(tData[t])      = vEIO_m[s56,IO_56_c,t];

  RAS_vIOxE_y.lo[s56_,IO_56_c,t]$(tData[t] and RAS_vIOxE_y.l[s56_,IO_56_c,t] and not (sameas[IO_56_c,'invt'] or sameas[IO_56_c,'iM'] or sameas[IO_56_c,'iB'])) = 0.1 * RAS_vIOxE_y.l[s56_,IO_56_c,t];
  RAS_vIOxE_m.lo[s56_,IO_56_c,t]$(tData[t] and RAS_vIOxE_m.l[s56_,IO_56_c,t] and not (sameas[IO_56_c,'invt'] or sameas[IO_56_c,'iM'] or sameas[IO_56_c,'iB'])) = 0.1 * RAS_vIOxE_m.l[s56_,IO_56_c,t];
  RAS_vIOxE_y.fx[s56_,IO_56_c,t]$(tData[t] and not RAS_vIOxE_y.l[s56_,IO_56_c,t]) = 0;
  RAS_vIOxE_m.fx[s56_,IO_56_c,t]$(tData[t] and not RAS_vIOxE_m.l[s56_,IO_56_c,t]) = 0;

  #We dont want too much with taxes 
  RAS_vIOxE_a.up[a_rows,IO_56_c,t]$(tData[t] and RAS_vIOxE_a.l[a_rows,IO_56_c,t]<0) = 0.99*RAS_vIOxE_a.l[a_rows,IO_56_c,t]; #
  RAS_vIOxE_a.lo[a_rows,IO_56_c,t]$(tData[t] and RAS_vIOxE_a.l[a_rows,IO_56_c,t]<0) = 1.01*RAS_vIOxE_a.l[a_rows,IO_56_c,t];
  RAS_vIOxE_a.up[a_rows,IO_56_c,t]$(tData[t] and RAS_vIOxE_a.l[a_rows,IO_56_c,t]>0) = 1.01*RAS_vIOxE_a.l[a_rows,IO_56_c,t]; #
  RAS_vIOxE_a.lo[a_rows,IO_56_c,t]$(tData[t] and RAS_vIOxE_a.l[a_rows,IO_56_c,t]>0) = 0.99*RAS_vIOxE_a.l[a_rows,IO_56_c,t];


    
  #Bounds 
    RAS_vIOxE_a.fx['turisme',IO_56_c,t]$(tData[t]) = RAS_vIOxE_a.l['turisme',IO_56_c,t];
    RAS_vIOxE_a.fx['OthTax',IO_56_c,t]$(tData[t])  = RAS_vIOxE_a.l['OthTax',IO_56_c,t];
    RAS_vIOxE_a.fx['OthSub',IO_56_c,t]$(tData[t])  = RAS_vIOxE_a.l['OthSub',IO_56_c,t];
    RAS_vIOxE_a.fx['SalEmpl',IO_56_c,t]$(tData[t]) = RAS_vIOxE_a.l['SalEmpl',IO_56_c,t];
    RAS_vIOxE_a.fx['OvProd',IO_56_c,t]$(tData[t])  = RAS_vIOxE_a.l['OvProd',IO_56_c,t];

    #  #Vi fixer eksport fra indenlandsk produktion, da den driver modelresultater 
    RAS_vIOxE_y.fx[s56,'xOth',t] = RAS_vIOxE_y.l[s56,'xOth',t]; 

  set_data_periods(2017,2019);

  execute_unload 'Output/preRAS.gdx';
  Solve M_RAS using NLP minimizing Entropy_RAS;

  #Lægger raserede variable tilbage 
    $GROUP G_RASxIO $LOOP IOxE: ,RAS_{name}{sets} "" $ENDLOOP;
    $LOOP IOxE: {name}{sets}$(tData[t]) = 0; {name}{sets}$(tData[t]) = RAS_{name}.l{sets}; $ENDLOOP


    $GROUP G_RASEIO $LOOP EIO: ,RAS_{name}{sets} "" $ENDLOOP;
    $LOOP EIO: {name}{sets}$(tData[t]) = 0; {name}{sets}$(tData[t]) = RAS_{name}.l{sets}; $ENDLOOP

    vIOxE_cus[s56,IO_56_c,t]$(tData[t]) = RAS_vIOxE_cus.l[s56,IO_56_c,t];

  #Danner IO-indmad 
    @computeIO();

  #Test af hvor meget variable har ændret sig 
  RASchange_vIOxE_y[s56,IO_56_c,t]$(vIOxE_y[s56,IO_56_c,t])        = abs(RAS_vIOxE_y.l[s56,IO_56_c,t]/RASpre_vIOxE_y[s56,IO_56_c,t]-1);  
  #  RASchange_vIOxE_m[s56,IO_56_c,t]$(vIOxE_m[s56,IO_56_c,t])        = abs(RAS_vIOxE_m.l[s56,IO_56_c,t]/RASpre_vIOxE_m[s56,IO_56_c,t]-1);  

  RASchange_vIOxE_a[a_rows,IO_56_c,t]$(vIOxE_a[a_rows,IO_56_c,t])  = abs(RAS_vIOxE_a.l[a_rows,IO_56_c,t]/RASpre_vIOxE_a[a_rows,IO_56_c,t]-1);  
  
  RASchange_vIOxE_y[s56,IO_56_c,t]$(tData[t])    = RASchange_vIOxE_y[s56,IO_56_c,t]$(RASchange_vIOxE_y[s56,IO_56_c,t]>0.01);    
  RASchange_vIOxE_m[s56,IO_56_c,t]$(tData[t])    = RASchange_vIOxE_m[s56,IO_56_c,t]$(RASchange_vIOxE_m[s56,IO_56_c,t]>0.01);    
  RASchange_vIOxE_a[a_rows,IO_56_c,t]$(tData[t]) = RASchange_vIOxE_a[a_rows,IO_56_c,t]$(RASchange_vIOxE_a[a_rows,IO_56_c,t]>0.01); 
 
  @compute_row_and_col_check();

  execute_unload 'Output/postRAS.gdx';
#Vi tjekker kun 2017-2019. Der er et lille issue i 2014 og 2015 med ca. 18 mio. kr., der bliver flyttet i moms...

  #Test af at rækker og søjler rammer i udgangspunktet 
  LOOP((s56,t)$(tDatax1[t]),

   #Checking domestic production equalling demand
    tjek = rowsum_y[s56,t] - colsum[s56,t];
  ABORT$(abs(tjek) gt 1e-4) tjek, "Demand not equal to supply in IO";

    tjek = rowsum_y[s56,t] - vIO_y[s56,'tot',t];
  ABORT$(abs(tjek) gt 1e-4) tjek, "Row sum (y) doesnt match input row-sum";

    tjek = rowsum_m[s56,t] - vIO_m[s56,'tot',t];
  ABORT$(abs(tjek) gt 1e-4) tjek, "Row sum (m) doesnt match input row-sum";
    ); 

  LOOP((a_rows,t)$(tDatax1[t]),
    tjek = rowsum_a[a_rows,t] - vIO_a[a_rows,'tot',t];
  ABORT$(abs(tjek) gt 1e-4) tjek, "Row sum (a) doesnt match input row-sum";
  );

#Adjusting afgiftslagkage after 

vAfgxE_56_y[s56,IO_56_c_,afgsub,t]$(tData[t] and not vIOxE_y[s56,IO_56_c_,t]) =0;
vAfgxE_56_m[s56,IO_56_c_,afgsub,t]$(tData[t] and not vIOxE_m[s56,IO_56_c_,t]) =0;
vSubxE_56_y[s56,IO_56_c_,afgsub,t]$(tData[t] and not vIOxE_y[s56,IO_56_c_,t]) =0;
vSubxE_56_m[s56,IO_56_c_,afgsub,t]$(tData[t] and not vIOxE_m[s56,IO_56_c_,t]) =0;

PARAMETER total_afgiftslagkage[IO_56_c_,t], diff_afgiftslagkage[IO_56_c_,t], frac_afgiftslagkage[IO_56_c_,t];
total_afgiftslagkage[IO_56_c_,t] =  sum((s56,afgsub), vAfgxE_56_y[s56,IO_56_c_,afgsub,t])
                    + sum((s56,afgsub), vAfgxE_56_m[s56,IO_56_c_,afgsub,t])
                    + sum((s56,afgsub), vSubxE_56_y[s56,IO_56_c_,afgsub,t])
                    + sum((s56,afgsub), vSubxE_56_m[s56,IO_56_c_,afgsub,t]);

frac_afgiftslagkage[IO_56_c_,t]$(total_afgiftslagkage[IO_56_c_,t])
     = vIOxE_a['TaxSub',IO_56_c_,t]/total_afgiftslagkage[IO_56_c_,t];

#Vi justerer kun afgifterne (for ikke at både at vride i afgifter og subsidier samtidigt for at ramme totaler)
vAfgxE_56_y[s56,IO_56_c_,afgsub,t]$(tData[t] and vAfgxE_56_y[s56,IO_56_c_,afgsub,t]) = - vSubxE_56_y[s56,IO_56_c_,afgsub,t] +  (vAfgxE_56_y[s56,IO_56_c_,afgsub,t] + vSubxE_56_y[s56,IO_56_c_,afgsub,t]) * vIOxE_a['TaxSub',IO_56_c_,t]/total_afgiftslagkage[IO_56_c_,t];
vAfgxE_56_m[s56,IO_56_c_,afgsub,t]$(tData[t] and vAfgxE_56_m[s56,IO_56_c_,afgsub,t]) = - vSubxE_56_m[s56,IO_56_c_,afgsub,t] +  (vAfgxE_56_m[s56,IO_56_c_,afgsub,t] + vSubxE_56_m[s56,IO_56_c_,afgsub,t]) * vIOxE_a['TaxSub',IO_56_c_,t]/total_afgiftslagkage[IO_56_c_,t];

#Når der ikke er nogen afgift justeres subsidiet
vSubxE_56_y[s56,IO_56_c_,afgsub,t]$(tData[t] and not vAfgxE_56_y[s56,IO_56_c_,afgsub,t] and vSubxE_56_y[s56,IO_56_c_,afgsub,t]) = vSubxE_56_y[s56,IO_56_c_,afgsub,t] * vIOxE_a['TaxSub',IO_56_c_,t]/total_afgiftslagkage[IO_56_c_,t];
vSubxE_56_m[s56,IO_56_c_,afgsub,t]$(tData[t] and not vAfgxE_56_m[s56,IO_56_c_,afgsub,t] and vSubxE_56_m[s56,IO_56_c_,afgsub,t]) = vSubxE_56_m[s56,IO_56_c_,afgsub,t] * vIOxE_a['TaxSub',IO_56_c_,t]/total_afgiftslagkage[IO_56_c_,t];


diff_afgiftslagkage[IO_56_c_,t] =  sum((s56,afgsub), vAfgxE_56_y[s56,IO_56_c_,afgsub,t])
                    + sum((s56,afgsub), vAfgxE_56_m[s56,IO_56_c_,afgsub,t])
                    + sum((s56,afgsub), vSubxE_56_y[s56,IO_56_c_,afgsub,t])
                    + sum((s56,afgsub), vSubxE_56_m[s56,IO_56_c_,afgsub,t])
                    -vIOxE_a['taxsub',IO_56_c_,t];

Loop(IO_56_c, 
  abort$(abs(diff_afgiftslagkage[IO_56_c,'2019'])>1e-6) 'Afstemningen af afgiftslagkage matcher ikke totalen fra RAS-afstemt IO-tabel'
  );


  #Them parameters 

  $PGROUP NEW
      $FOR {v} in ['v','l','p','q']:
          IO_{v}Y[s_,t] ""
          IO_{v}M[s_,t] ""
          IO_{v}Y_CET[out,s_,t] ""          
          IO_{v}M_CET[out,s_,t] ""
          IO_{v}RxE[RxE_,t] ""
          IO_{v}RxE_ARIMA[rxe_arima_,t] ""
          IO_{v}Fin[fin_,t] ""
          IO_{v}RE[RE,t] ""
          IO_{v}G[g_,t] ""
          IO_{v}C[c_,t] ""
          IO_{v}I_s[i_,s_,t] ""
          IO_{v}I[i_,t] ""
          IO_{v}K[i_,s_,t] ""
          IO_{v}X[x_,t] ""
          IO_{v}GrossValAdd[s_,t] ""
          IO_{v}GDP[t] ""
      $ENDFOR

      #IO-indmad
      $FOR {item} in ['RxE','RE','X','C','I','G']:
        $FOR1 {ym} in ['y','m']:
            IO_vn{item}_{ym}[{item},s,t] ""
            IO_vtDuty_{item}_{ym}[{item},s,afgsub,t] ""
            IO_tDuty_{item}_{ym}[{item},s,afgsub,t] ""
            IO_tVAT_{item}_{ym}[{item},s,t] ""
            IO_vtSub_{item}_{ym}[{item},s,afgsub,t] ""
            IO_tSub_{item}_{ym}[{item},s,afgsub,t] ""
            IO_t{item}_{ym}[{item},s,t] ""
            IO_v{item}_{ym}[{item},s,t] ""
            IO_p{item}_{ym}[{item},s,t] ""
            IO_q{item}_{ym}[{item},s,t] ""
        $ENDFOR1
        
        IO_v{item}_ym[{item}_,s_,t] ""
        IO_l{item}_ym[{item}_,s_,t] ""
        IO_l{item}_ym0[{item}_,s_,t] ""
        IO_p{item}_ym[{item}_,s_,t] ""
        IO_q{item}_ym[{item}_,s_,t] ""
        IO_pl{item}_ym[{item}_,s_,t] ""
        IO_p{item}_ym0[{item}_,s_,t] ""

        IO_vtVAT_{item}[{item},t] ""

        IO_tCus_{item}_m[{item},s,t] ""
        IO_tCus_Fin_m[s_,t] ""
      $ENDFOR


      # Variabel for input fra den finansielle sektor
      $FOR {v} in ['v','p','q','t']:
        $FOR1 {ym} in ['y','m']:
          IO_{v}Fin_{ym}[s_,t] ""
          IO_tDuty_Fin_{ym}[s_,afgsub,t] ""
          IO_tSub_Fin_{ym}[s_,afgsub,t] ""
          IO_tVat_Fin_{ym}[s_,t] ""
          IO_vtDuty_Fin_{ym}[s_,afgsub,t] ""
          IO_vtSub_Fin_{ym}[s_,afgsub,t] ""
        $ENDFOR1

        IO_{v}Fin_k[k,s_,t] ""

      $ENDFOR

      IO_vC_etot[t] ""
      IO_lC_etot[t] ""
;

  set_data_periods(2011,2019);

  #PRODUKTION
  IO_vY[s,t]$(tData[t])     = sum(s56$maps2s56(s,s56),  sum(IO_56_c, vIO_y[s56,IO_56_c,t]));
  IO_lY[s,t]$(tData[t])     = sum(s56$maps2s56(s,s56),  sum(IO_56_c,vDIO_y[s56,IO_56_c,t]));
  IO_vY['tot',t]$(tData[t]) = sum(s, IO_vY[s,t]);
  IO_lY['tot',t]$(tData[t]) = sum(s, IO_lY[s,t]);

  IO_vY_CET['out_other',s,t]$(tData[t]) = sum(s56$maps2s56(s,s56), sum(IO_56_c, vIOxE_y[s56,IO_56_c,t]));
  IO_lY_CET['out_other',s,t]$(tData[t]) = sum(s56$maps2s56(s,s56), sum(IO_56_c, vDIOxE_y[s56,IO_56_c,t]));

  IO_vM[s,t]$(tData[t])     =  sum(s56$maps2s56(s,s56), sum(IO_56_c, vIO_m[s56,IO_56_c,t] - vIO_cus[s56,IO_56_c,t] ));
  IO_lM[s,t]$(tData[t])     =  sum(s56$maps2s56(s,s56), sum(IO_56_c, vDIO_m[s56,IO_56_c,t]- vDIO_cus[s56,IO_56_c,t]));
  IO_vM['tot',t]$(tData[t]) =  sum(s, IO_vM[s,t]);
  IO_lM['tot',t]$(tData[t]) =  sum(s, IO_lM[s,t]);


  IO_vM_CET['out_other',s,t]$(tData[t]) = sum(s56$maps2s56(s,s56), sum(IO_56_c, vIOxE_m[s56,IO_56_c,t]  - vIOxE_cus[s56,IO_56_c,t])); #Told ligger udenfor de normale IO-tabeller 
  IO_lM_CET['out_other',s,t]$(tData[t]) = sum(s56$maps2s56(s,s56), sum(IO_56_c, vDIOxE_m[s56,IO_56_c,t] - vDIOxE_cus[s56,IO_56_c,t])); #Told ligger udenfor de normale IO-tabeller 

  IO_vK[i,s,t]$(tData[t]) = sum(s56$maps2s56(s,s56), vIO_k[i,s56,t]);
  IO_lK[i,s,t]$(tData[t]) = sum(s56$maps2s56(s,s56), vDIO_k[i,s56,t]);

  #EFTERSPØRGSEL
  IO_vRxE[r,t]$(tData[t])    = sum(r56$maps2s56(r,r56), sum(s56, vIOxE_y[s56,r56,t] + vIOxE_m[s56,r56,t]) + vIOxE_a['TaxSub',r56,t] + vIOxE_a['MOMS',r56,t]);
  IO_lRxE[r,t]$(tData[t])    = sum(r56$maps2s56(r,r56), sum(s56, vDIOxE_y[s56,r56,t]+ vDIOxE_m[s56,r56,t])+ vDIOxE_a['TaxSub',r56,t] + vDIOxE_a['MOMS',r56,t]);

  IO_vRxE['tot',t]$(tData[t]) = sum(r, IO_vRxE[r,t]);
  IO_lRxE['tot',t]$(tData[t]) = sum(r, IO_lRxE[r,t]); 

  # Variabel til ARIMA-estimationerne, hvor input fra den finansielle sektor er trukket ud af materialeinputtet
  IO_vRxE_ARIMA[r,t]$(tData[t]) = IO_vRxE[r,t]-(sum(r56$maps2s56(r,r56), vIOxE_y['64000',r56,t] + vIOxE_m['64000',r56,t]))$(not sameas[r,'off']);
  IO_lRxE_ARIMA[r,t]$(tData[t]) = IO_lRxE[r,t]-(sum(r56$maps2s56(r,r56), vDIOxE_y['64000',r56,t]+ vDIOxE_m['64000',r56,t]))$(not sameas[r,'off']);


  IO_vRE[r,t]$(tData[t])     = sum(r56$maps2s56(r,r56), sum(s56, vEIO_y[s56,r56,t]  + vEIO_m[s56,r56,t])  + vEIO_a['TaxSub',r56,t] + vEIO_a['MOMS',r56,t]);
  IO_lRE[r,t]$(tData[t])     = sum(r56$maps2s56(r,r56), sum(s56, vDEIO_y[s56,r56,t] + vDEIO_m[s56,r56,t]) + vDEIO_a['TaxSub',r56,t] + vDEIO_a['MOMS',r56,t]);

  IO_vC[c,t]$(tData[t])      = sum(c56$mapc2c56(c,c56), sum(s56, vIO_y[s56,c56,t] + vIO_m[s56,c56,t]) + sum(a_rows, vIO_a[a_rows,c56,t]));
 
  IO_vC_etot[t] = IO_vC['cCarEne',t] + IO_vC['cHouEne',t]; 

  IO_vC['cCarEne',t]$(sum((purpose,energy19), EN_vnCE[purpose,energy19,t])) 
                      = sum((energy19),         EN_vnCE['transport',energy19,t] 
                                              + EN_vCO2_CE['transport',energy19,t] 
                                              + EN_vEAFG_CE['transport',energy19,t] 
                                              + EN_vSO2_CE['transport',energy19,t]
                                              + EN_vNOX_CE['transport',energy19,t]
                                              + EN_vPSO_CE['transport',energy19,t]
                                              + EN_vMOMS_CE['transport',energy19,t]
                                              + EN_vEAV_CE['transport',energy19,t]
                                              + EN_vDAV_CE['transport',energy19,t]
                                              + EN_vCAV_CE['transport',energy19,t])
                      /sum((purpose,energy19),  EN_vnCE[purpose,energy19,t]
                                              + EN_vCO2_CE[purpose,energy19,t] 
                                              + EN_vEAFG_CE[purpose,energy19,t] 
                                              + EN_vSO2_CE[purpose,energy19,t]
                                              + EN_vNOX_CE[purpose,energy19,t]
                                              + EN_vPSO_CE[purpose,energy19,t]
                                              + EN_vMOMS_CE[purpose,energy19,t]
                                              + EN_vEAV_CE[purpose,energy19,t]
                                              + EN_vDAV_CE[purpose,energy19,t]
                                              + EN_vCAV_CE[purpose,energy19,t]) * IO_vC_etot[t];

  IO_vC['cHouEne',t]$(sum((purpose,energy19), EN_vnCE[purpose,energy19,t])) 
                      = sum((purpose, energy19)$(xTrans[purpose]), EN_vnCE[purpose,energy19,t]
                                                                + EN_vCO2_CE[purpose,energy19,t]
                                                                + EN_vEAFG_CE[purpose,energy19,t]
                                                                + EN_vSO2_CE[purpose,energy19,t]
                                                                + EN_vNOX_CE[purpose,energy19,t]
                                                                + EN_vPSO_CE[purpose,energy19,t]
                                                                + EN_vMOMS_CE[purpose,energy19,t]
                                                                + EN_vEAV_CE[purpose,energy19,t]
                                                                + EN_vDAV_CE[purpose,energy19,t]
                                                                + EN_vCAV_CE[purpose,energy19,t])
                      /sum((purpose,energy19), EN_vnCE[purpose,energy19,t]
                                                                + EN_vCO2_CE[purpose,energy19,t]
                                                                + EN_vEAFG_CE[purpose,energy19,t]
                                                                + EN_vSO2_CE[purpose,energy19,t]
                                                                + EN_vNOX_CE[purpose,energy19,t]
                                                                + EN_vPSO_CE[purpose,energy19,t]
                                                                + EN_vMOMS_CE[purpose,energy19,t]
                                                                + EN_vEAV_CE[purpose,energy19,t]
                                                                + EN_vDAV_CE[purpose,energy19,t]
                                                                + EN_vCAV_CE[purpose,energy19,t]) * IO_vC_etot[t];

  # Consumption IO for 2012-2013 (note: rows are 117-sectors and not 146-sectors)
  IO_vC[c,t]$(t.val =2012 or t.val =2013)                 
                            = sum(c56$mapc2c56(c,c56), sum(ns117_r, IO_vC_y_2012_2013[ns117_r,c56,t] + IO_vC_m_2012_2013[ns117_r,c56,t]) + sum(a_rows, IO_vC_a_2012_2013[a_rows,c56,t]));

  IO_vC['ctot',t]$(tData[t]) = sum(c, IO_vC[c,t]);
  
  IO_lC[c,t]$(tData[t])      = sum(c56$mapc2c56(c,c56), sum(s56, vDIO_y[s56,c56,t] + vDIO_m[s56,c56,t]) + sum(a_rows, vDIO_a[a_rows,c56,t]));
  IO_lC['ctot',t]$(tData[t]) = sum(c, IO_lC[c,t]);

  IO_lC_etot[t] = IO_lC['cCarEne',t] + IO_lC['cHouEne',t]; 

  IO_lC['cCarEne',t]$(sum((purpose,energy19), EN_vnCE[purpose,energy19,t]))
                      = sum((energy19),         EN_vnCE['transport',energy19,t] 
                                              + EN_vCO2_CE['transport',energy19,t] 
                                              + EN_vEAFG_CE['transport',energy19,t] 
                                              + EN_vSO2_CE['transport',energy19,t]
                                              + EN_vNOX_CE['transport',energy19,t]
                                              + EN_vPSO_CE['transport',energy19,t]
                                              + EN_vMOMS_CE['transport',energy19,t]
                                              + EN_vEAV_CE['transport',energy19,t]
                                              + EN_vDAV_CE['transport',energy19,t]
                                              + EN_vCAV_CE['transport',energy19,t])
                      /sum((purpose,energy19),  EN_vnCE[purpose,energy19,t]
                                              + EN_vCO2_CE[purpose,energy19,t] 
                                              + EN_vEAFG_CE[purpose,energy19,t] 
                                              + EN_vSO2_CE[purpose,energy19,t]
                                              + EN_vNOX_CE[purpose,energy19,t]
                                              + EN_vPSO_CE[purpose,energy19,t]
                                              + EN_vMOMS_CE[purpose,energy19,t]
                                              + EN_vEAV_CE[purpose,energy19,t]
                                              + EN_vDAV_CE[purpose,energy19,t]
                                              + EN_vCAV_CE[purpose,energy19,t])  * IO_lC_etot[t];

  IO_lC['cHouEne',t]$(sum((purpose,energy19), EN_vnCE[purpose,energy19,t]))
                      = sum((purpose, energy19)$(xTrans[purpose]), EN_vnCE[purpose,energy19,t]
                                                                + EN_vCO2_CE[purpose,energy19,t]
                                                                + EN_vEAFG_CE[purpose,energy19,t]
                                                                + EN_vSO2_CE[purpose,energy19,t]
                                                                + EN_vNOX_CE[purpose,energy19,t]
                                                                + EN_vPSO_CE[purpose,energy19,t]
                                                                + EN_vMOMS_CE[purpose,energy19,t]
                                                                + EN_vEAV_CE[purpose,energy19,t]
                                                                + EN_vDAV_CE[purpose,energy19,t]
                                                                + EN_vCAV_CE[purpose,energy19,t])
                      /sum((purpose,energy19), EN_vnCE[purpose,energy19,t]
                                                                + EN_vCO2_CE[purpose,energy19,t]
                                                                + EN_vEAFG_CE[purpose,energy19,t]
                                                                + EN_vSO2_CE[purpose,energy19,t]
                                                                + EN_vNOX_CE[purpose,energy19,t]
                                                                + EN_vPSO_CE[purpose,energy19,t]
                                                                + EN_vMOMS_CE[purpose,energy19,t]
                                                                + EN_vEAV_CE[purpose,energy19,t]
                                                                + EN_vDAV_CE[purpose,energy19,t]
                                                                + EN_vCAV_CE[purpose,energy19,t]) * IO_lC_etot[t];

  # Consumption IO for 2012-2013 (note: rows are 117-sectors and not 146-sectors)
  IO_lC[c,t]$(t.val =2012 or t.val =2013)
                              = sum(c56$mapc2c56(c,c56), sum(ns117_r, DIO_vC_y_2012_2013[ns117_r,c56,t] + DIO_vC_m_2012_2013[ns117_r,c56,t]) + sum(a_rows, DIO_vC_a_2012_2013[a_rows,c56,t]));

  # cTot for 2012-2013
  IO_lC['ctot',t]$(t.val =2012 or t.val =2013) 
                              = sum(c, IO_lC[c,t]);

  IO_vG['g',t]$(tData[t])     = sum(s56, vIO_y[s56,'g',t] + vIO_m[s56,'g',t]) + sum(a_rows, vIO_a[a_rows,'g',t]);
  IO_vG['gtot',t]$(tData[t])  = IO_vG['g',t];

  IO_lG['g',t]$(tData[t])     = sum(s56, vDIO_y[s56,'g',t] + vDIO_m[s56,'g',t]) + sum(a_rows, vDIO_a[a_rows,'g',t]);
  IO_lG['gtot',t]$(tData[t])  = IO_lG['g',t];


  IO_vI_s[i,s,t]$(tData[t])   = sum(s56$maps2s56(s,s56), vIO_I[i,s56,t]);
  IO_lI_s[i,s,t]$(tData[t])   = sum(s56$maps2s56(s,s56),vDIO_I[i,s56,t]);

  IO_vI_s['invt',s,t]$(tData[t]) = sum(s56$maps2s56(s,s56), vIO_y[s56,'invt',t] + vIO_m[s56,'invt',t])  + sum(a_rows, vIO_a[a_rows,'invt',t]); #HUSK MOMS OG AFGIFTER HER
  IO_lI_s['invt',s,t]$(tData[t]) = sum(s56$maps2s56(s,s56),vDIO_y[s56,'invt',t] + vDIO_m[s56,'invt',t]) + sum(a_rows, vDIO_a[a_rows,'invt',t]);

  IO_vI[i,t]$(tData[t]) = sum(s, IO_vI_s[i,s,t]);
  IO_lI[i,t]$(tData[t]) = sum(s, IO_lI_s[i,s,t]);

  IO_vX['xOth',t]$(tData[t]) = sum(s56, vIO_y[s56,'xOth',t]  + vIO_m[s56,'xOth',t])  + vIO_a['TaxSub','xOth',t];
  IO_lX['xOth',t]$(tData[t]) = sum(s56, vDIO_y[s56,'xOth',t] + vDIO_m[s56,'xOth',t]) + vDIO_a['TaxSub','xOth',t];

  IO_vX['xTur',t]$(tData[t]) = vIO_a['Turisme','xOth',t];
  IO_lX['xTur',t]$(tData[t]) = vDIO_a['Turisme','xOth',t];

  IO_vX['xTot',t]$(tData[t]) = IO_vX['xOth',t] + IO_vX['xTur',t];
  IO_lX['xTot',t]$(tData[t]) = IO_lX['xOth',t] + IO_lX['xTur',t];


  #BVT
  IO_vGrossValAdd[s,t]$(tData[t]) = IO_vY[s,t] - IO_vRxE[s,t] - IO_vRE[s,t];
  IO_lGrossValAdd[s,t]$(tData[t]) = IO_lY[s,t] - IO_lRxE[s,t] - IO_lRE[s,t];


  #IO-indmad
  IO_vnRxE_y[r,s,t]$(tData[t]) = sum((r56,s56)$(maps2s56(s,r56) and maps2s56(r,s56)), vIOxE_y[r56,s56,t]);
  IO_vnRxE_m[r,s,t]$(tData[t]) = sum((r56,s56)$(maps2s56(s,r56) and maps2s56(r,s56)), vIOxE_m[r56,s56,t] - vIOxE_cus[r56,s56,t]);

  IO_vnC_y[c,s,t]$(tData[t])   = sum((c56,r56)$(maps2s56(s,r56) and mapc2c56(c,c56)), vIOxE_y[r56,c56,t]);
  IO_vnC_m[c,s,t]$(tData[t])   = sum((c56,r56)$(maps2s56(s,r56) and mapc2c56(c,c56)), vIOxE_m[r56,c56,t] - vIOxE_cus[r56,c56,t]);

  IO_vnG_y['g',s,t]$(tData[t])      = sum(r56$(maps2s56(s,r56)), vIOxE_y[r56,'g',t]);
  IO_vnG_m['g',s,t]$(tData[t])      = sum(r56$(maps2s56(s,r56)), vIOxE_m[r56,'g',t] - vIOxE_cus[r56,'g',t]);

  IO_vnI_y[i,s,t]$(tData[t])        = sum((r56,i56)$(maps2s56(s,r56) and mapi2i56(i,i56)), vIOxE_y[r56,i56,t]);
  IO_vnI_m[i,s,t]$(tData[t])        = sum((r56,i56)$(maps2s56(s,r56) and mapi2i56(i,i56)), vIOxE_m[r56,i56,t]- vIOxE_cus[r56,i56,t]);

  IO_vnX_y['xOth',s,t]$(tData[t])   = sum(r56$(maps2s56(s,r56)), vIOxE_y[r56,'xOth',t]);
  IO_vnX_m['xOth',s,t]$(tData[t])   = sum(r56$(maps2s56(s,r56)), vIOxE_m[r56,'xOth',t] - vIOxE_cus[r56,'xOth',t]);


  #Beregner afgiftssatser
  #Indtil vi får implementeret afgiftslagkage bruges gennemsnitssats

    #Told
      IO_tCus_RxE_m[r,s,t]$(tData[t] and IO_vnRxE_m[r,s,t])
        = sum((r56,s56)$(maps2s56(s,r56) and maps2s56(r,s56)), vIOxE_cus[r56,s56,t])/IO_vnRxE_m[r,s,t];

      IO_tCus_C_m[c,s,t]$(tData[t] and IO_vnC_m[c,s,t])
        = sum((c56,r56)$(maps2s56(s,r56) and mapc2c56(c,c56)), vIOxE_cus[r56,c56,t])/IO_vnC_m[c,s,t];

      IO_tCus_G_m['g',s,t]$(tData[t] and IO_vnG_m['g',s,t])
        = sum(r56$(maps2s56(s,r56)), vIOxE_cus[r56,'g',t])/IO_vnG_m['g',s,t];

      IO_tCus_I_m[i,s,t]$(tData[t] and IO_vnI_m[i,s,t])
        = sum((r56,i56)$(maps2s56(s,r56) and mapi2i56(i,i56)), vIOxE_cus[r56,i56,t])/IO_vnI_m[i,s,t];

      IO_tCus_X_m['xOth',s,t]$(tData[t] and IO_vnX_m['xOth',s,t])
        = sum(r56$(maps2s56(s,r56)), vIOxE_cus[r56,'xOth',t])/IO_vnX_m['xOth',s,t];


    #Punktafgifter
      #B2B
      IO_vtDuty_RxE_y[r,s,afgsub,t]$(tDataEnd[t]) = sum((r56,s56)$(maps2s56(s,r56) and maps2s56(r,s56)), vAfgxE_56_y[r56,s56,afgsub,t]);
      IO_vtDuty_RxE_m[r,s,afgsub,t]$(tDataEnd[t]) = sum((r56,s56)$(maps2s56(s,r56) and maps2s56(r,s56)), vAfgxE_56_m[r56,s56,afgsub,t]);

      IO_tDuty_RxE_y[r,s,afgsub,t]$(tDataEnd[t] and IO_vtDuty_RxE_y[r,s,afgsub,t]) = IO_vtDuty_RxE_y[r,s,afgsub,t]/IO_vnRxE_y[r,s,t];
      IO_tDuty_RxE_m[r,s,afgsub,t]$(tDataEnd[t] and IO_vtDuty_RxE_m[r,s,afgsub,t]) = IO_vtDuty_RxE_m[r,s,afgsub,t]/IO_vnRxE_m[r,s,t];

      IO_vtSub_RxE_y[r,s,afgsub,t]$(tDataEnd[t]) = sum((r56,s56)$(maps2s56(s,r56) and maps2s56(r,s56)), vSubxE_56_y[r56,s56,afgsub,t]);
      IO_vtSub_RxE_m[r,s,afgsub,t]$(tDataEnd[t]) = sum((r56,s56)$(maps2s56(s,r56) and maps2s56(r,s56)), vSubxE_56_m[r56,s56,afgsub,t]);

      IO_tSub_RxE_y[r,s,afgsub,t]$(tDataEnd[t] and IO_vtSub_RxE_y[r,s,afgsub,t]) = IO_vtSub_RxE_y[r,s,afgsub,t]/IO_vnRxE_y[r,s,t];
      IO_tSub_RxE_m[r,s,afgsub,t]$(tDataEnd[t] and IO_vtSub_RxE_m[r,s,afgsub,t]) = IO_vtSub_RxE_m[r,s,afgsub,t]/IO_vnRxE_m[r,s,t];

      #Consumption
      IO_vtDuty_C_y[c,s,afgsub,t]$(tDataEnd[t]) = sum((c56,r56)$(maps2s56(s,r56) and mapc2c56(c,c56)), vAfgxE_56_y[r56,c56,afgsub,t]);
      IO_vtDuty_C_m[c,s,afgsub,t]$(tDataEnd[t]) = sum((c56,r56)$(maps2s56(s,r56) and mapc2c56(c,c56)), vAfgxE_56_m[r56,c56,afgsub,t]);

      IO_tDuty_C_y[c,s,afgsub,t]$(tDataEnd[t] and IO_vtDuty_C_y[c,s,afgsub,t]) = IO_vtDuty_C_y[c,s,afgsub,t]/IO_vnC_y[c,s,t];
      IO_tDuty_C_m[c,s,afgsub,t]$(tDataEnd[t] and IO_vtDuty_C_m[c,s,afgsub,t]) = IO_vtDuty_C_m[c,s,afgsub,t]/IO_vnC_m[c,s,t];

      IO_vtSub_C_y[c,s,afgsub,t] = sum((c56,r56)$(maps2s56(s,r56) and mapc2c56(c,c56)), vSubxE_56_y[r56,c56,afgsub,t]);
      IO_vtSub_C_m[c,s,afgsub,t] = sum((c56,r56)$(maps2s56(s,r56) and mapc2c56(c,c56)), vSubxE_56_m[r56,c56,afgsub,t]);

      IO_tSub_C_y[c,s,afgsub,t]$(tDataEnd[t] and IO_vtSub_C_y[c,s,afgsub,t]) = IO_vtSub_C_y[c,s,afgsub,t]/IO_vnC_y[c,s,t];
      IO_tSub_C_m[c,s,afgsub,t]$(tDataEnd[t] and IO_vtSub_C_m[c,s,afgsub,t]) = IO_vtSub_C_m[c,s,afgsub,t]/IO_vnC_m[c,s,t];

      #Public consumption
      IO_vtDuty_G_y['g',s,afgsub,t]$(tDataEnd[t]) = sum(r56$(maps2s56(s,r56)), vAfgxE_56_y[r56,'g',afgsub,t]);
      IO_vtDuty_G_m['g',s,afgsub,t]$(tDataEnd[t]) = sum(r56$(maps2s56(s,r56)), vAfgxE_56_m[r56,'g',afgsub,t]);

      IO_tDuty_G_y['g',s,afgsub,t]$(tDataEnd[t] and IO_vtDuty_G_y['g',s,afgsub,t]) = IO_vtDuty_G_y['g',s,afgsub,t]/IO_vnG_y['g',s,t];
      IO_tDuty_G_m['g',s,afgsub,t]$(tDataEnd[t] and IO_vtDuty_G_m['g',s,afgsub,t]) = IO_vtDuty_G_m['g',s,afgsub,t]/IO_vnG_m['g',s,t];

      IO_vtSub_G_y['g',s,afgsub,t]$(tDataEnd[t]) = sum(r56$(maps2s56(s,r56)), vSubxE_56_y[r56,'g',afgsub,t]);
      IO_vtSub_G_m['g',s,afgsub,t]$(tDataEnd[t]) = sum(r56$(maps2s56(s,r56)), vSubxE_56_m[r56,'g',afgsub,t]);

      IO_tSub_G_y['g',s,afgsub,t]$(tDataEnd[t] and IO_vtSub_G_y['g',s,afgsub,t]) = IO_vtSub_G_y['g',s,afgsub,t]/IO_vnG_y['g',s,t];
      IO_tSub_G_m['g',s,afgsub,t]$(tDataEnd[t] and IO_vtSub_G_m['g',s,afgsub,t]) = IO_vtSub_G_m['g',s,afgsub,t]/IO_vnG_m['g',s,t];

      #Investments
      IO_vtDuty_I_y[i,s,afgsub,t]$(tDAtaEnd[t]) = sum((r56,i56)$(maps2s56(s,r56) and mapi2i56(i,i56)), vAfgxE_56_y[r56,i56,afgsub,t]);
      IO_vtDuty_I_m[i,s,afgsub,t]$(tDAtaEnd[t]) = sum((r56,i56)$(maps2s56(s,r56) and mapi2i56(i,i56)), vAfgxE_56_m[r56,i56,afgsub,t]);

      IO_tDuty_I_y[i,s,afgsub,t]$(tDataEnd[t] and IO_vtDuty_I_y[i,s,afgsub,t])  = IO_vtDuty_I_y[i,s,afgsub,t]/IO_vnI_y[i,s,t];
      IO_tDuty_I_m[i,s,afgsub,t]$(tDataEnd[t] and IO_vtDuty_I_m[i,s,afgsub,t])  = IO_vtDuty_I_m[i,s,afgsub,t]/IO_vnI_m[i,s,t];    

      IO_vtSub_I_y[i,s,afgsub,t]$(tDataENd[t]) = sum((r56,i56)$(maps2s56(s,r56) and mapi2i56(i,i56)), vSubxE_56_y[r56,i56,afgsub,t]);
      IO_vtSub_I_m[i,s,afgsub,t]$(tDataENd[t]) = sum((r56,i56)$(maps2s56(s,r56) and mapi2i56(i,i56)), vSubxE_56_m[r56,i56,afgsub,t]);

      IO_tSub_I_y[i,s,afgsub,t]$(tDataEnd[t] and IO_vtSub_I_y[i,s,afgsub,t])  = IO_vtSub_I_y[i,s,afgsub,t]/IO_vnI_y[i,s,t];
      IO_tSub_I_m[i,s,afgsub,t]$(tDataEnd[t] and IO_vtSub_I_m[i,s,afgsub,t])  = IO_vtSub_I_m[i,s,afgsub,t]/IO_vnI_m[i,s,t];

      #Exports
      IO_vtDuty_x_y['xOth',s,afgsub,t]$(tDataEnd[t]) = sum(r56$(maps2s56(s,r56)), vAfgxE_56_y[r56,'g',afgsub,t]);
      IO_vtDuty_x_m['xOth',s,afgsub,t]$(tDataEnd[t]) = sum(r56$(maps2s56(s,r56)), vAfgxE_56_m[r56,'g',afgsub,t]);

      IO_tDuty_x_y['xOth',s,afgsub,t]$(tDataEnd[t] and IO_vtDuty_x_y['xOth',s,afgsub,t]) = IO_vtDuty_x_y['xOth',s,afgsub,t] /IO_vnx_y['xOth',s,t];
      IO_tDuty_x_m['xOth',s,afgsub,t]$(tDataEnd[t] and IO_vtDuty_x_m['xOth',s,afgsub,t]) = IO_vtDuty_x_m['xOth',s,afgsub,t] /IO_vnx_m['xOth',s,t]; 

      IO_vtSub_x_y['xOth',s,afgsub,t] = sum(r56$(maps2s56(s,r56)), vSubxE_56_y[r56,'xOth',afgsub,t]);
      IO_vtSub_x_m['xOth',s,afgsub,t] = sum(r56$(maps2s56(s,r56)), vSubxE_56_m[r56,'xOth',afgsub,t]);

      IO_tSub_x_y['xOth',s,afgsub,t]$(tDataEnd[t] and IO_vtSub_x_y['xOth',s,afgsub,t]) = IO_vtSub_x_y['xOth',s,afgsub,t] /IO_vnx_y['xOth',s,t];
      IO_tSub_x_m['xOth',s,afgsub,t]$(tDataEnd[t] and IO_vtSub_x_m['xOth',s,afgsub,t]) = IO_vtSub_x_m['xOth',s,afgsub,t] /IO_vnx_m['xOth',s,t]; 


  #Moms
    IO_vtVAT_RxE[r,t] = sum(s56$maps2s56(r,s56), vIOxE_a['MOMS',s56,t]);
    IO_vtVAT_C[c,t]   = sum(c56$mapc2c56(c,c56), vIOxE_a['MOMS',c56,t]);
    IO_vtVAT_G['g',t] = vIOxE_a['MOMS','g',t];
    IO_vtVAT_I[i,t]   = sum(i56$mapi2i56(i,i56), vIOxE_a['MOMS',i56,t]);
    IO_vtVAT_X['Xoth',t] = vIOxE_a['MOMS','xOth',t];

    IO_tVAT_RxE_y[r,s,t]$(IO_vRxE[r,t]) = IO_vtVAT_RxE[r,t]/(IO_vRxE[r,t]-IO_vtVAT_RxE[r,t]);
    IO_tVAT_RxE_m[r,s,t]$(IO_vRxE[r,t]) = IO_vtVAT_RxE[r,t]/(IO_vRxE[r,t]-IO_vtVAT_RxE[r,t]);

    IO_tVAT_C_y[c,s,t]$(IO_vC[c,t]) = IO_vtVAT_C[c,t]/(IO_vC[c,t]-IO_vtVAT_C[c,t]);
    IO_tVAT_C_m[c,s,t]$(IO_vC[c,t]) = IO_vtVAT_C[c,t]/(IO_vC[c,t]-IO_vtVAT_C[c,t]);

    IO_tVAT_G_y[g,s,t]$(IO_vG[g,t]) = IO_vtVAT_G[g,t]/(IO_vG[g,t]-IO_vtVAT_G[g,t]);
    IO_tVAT_G_m[g,s,t]$(IO_vG[g,t]) = IO_vtVAT_G[g,t]/(IO_vG[g,t]-IO_vtVAT_G[g,t]);

    IO_tVAT_I_y[i,s,t]$(IO_vI[i,t]) = IO_vtVAT_I[i,t]/(IO_vI[i,t]-IO_vtVAT_I[i,t]);
    IO_tVAT_I_m[i,s,t]$(IO_vI[i,t]) = IO_vtVAT_I[i,t]/(IO_vI[i,t]-IO_vtVAT_I[i,t]);

    IO_tVAT_X_y[x,s,t]$(IO_vX[x,t]) = IO_vtVAT_X[x,t]/(IO_vX[x,t]-IO_vtVAT_X[x,t]);
    IO_tVAT_X_m[x,s,t]$(IO_vX[x,t]) = IO_vtVAT_X[x,t]/(IO_vX[x,t]-IO_vtVAT_X[x,t]);


###HACK - justering af investeringer så tilgang/anvendelse stemmer 

# Samlede skatter på D
  io_tI_y[I,s,t]$(tData[t]) = (1+sum(afgsub,io_tDuty_I_y[I,s,afgsub,t] + io_tSub_I_y[I,s,afgsub,t])) * (1+io_tVAT_I_y[I,s,t]) - 1;
  io_tI_m[I,s,t]$(tData[t]) = (1+sum(afgsub,io_tDuty_I_m[I,s,afgsub,t] + io_tSub_I_m[I,s,afgsub,t])) * (1+io_tVAT_I_m[I,s,t]) * (1+io_tCus_I_m[I,s,t]) - 1;
# Efterspørgselskomponenterne i løbende priser inkl. skatter
  io_vI_y[I,s,t]$(tData[t]) = (1+io_tI_y[I,s,t]) * io_vnI_y[I,s,t];
  io_vI_m[I,s,t]$(tData[t]) = (1+io_tI_m[I,s,t]) * io_vnI_m[I,s,t];
                                          #Branche s' andel af I-efterpørgsel      # I_tot_supply
  io_vI_s[i,s_,t]$sum(s,io_vI_s[i,s,t]) = io_vI_s[i,s_,t] /sum(s,io_vI_s[i,s,t]) * sum(s,io_vI_y[I,s,t] +io_vI_m[I,s,t]);
  io_lI_s[i,s_,t]$sum(s,io_lI_s[i,s,t]) = io_lI_s[i,s_,t] /sum(s,io_lI_s[i,s,t]) * sum(s,io_vI_y[I,s,t] +io_vI_m[I,s,t]);

  io_vI_s[i,'tot',t]$(tData[t]) = sum(s,io_vI_s[i,s,t]);
  io_lI_s[i,'tot',t]$(tData[t]) = sum(s,io_lI_s[i,s,t]);

  io_vI_s['invt','tot',t]$(tData[t]) = io_vI_s['invt','tot',t]; 
  io_lI_s['invt','tot',t]$(tData[t]) = io_lI_s['invt','tot',t]; 

  IO_vI_s['itot',s_,t]$(tData[t]) = sum(i,IO_vI_s[i,s_,t]); 
  IO_lI_s['itot',s_,t]$(tData[t]) = sum(i,IO_lI_s[i,s_,t]); 

  #Til lagre lægges energilagre
  IO_vI_s['itot','tot',t]$(tdata[t]) = IO_vI_s['itot','tot',t] +  sum(s56,vEIO_y[s56,'invt',t]) + sum(s56, vEIO_m[s56,'invt',t]) + sum(a_rows, vEIO_a[a_rows,'invt',t]);
  IO_lI_s['itot','tot',t]$(tdata[t]) = IO_lI_s['itot','tot',t] +  sum(s56,vDEIO_y[s56,'invt',t]) + sum(s56, vDEIO_m[s56,'invt',t]) + sum(a_rows, vDEIO_a[a_rows,'invt',t]);



# =====================================================================================================================
#  Der dannes pris- og mængdeindeks for aggregaterne for r, C, G, X, I, Y, M, GrossValAdd, k, L og GDP 
# =====================================================================================================================
# ---------------------------------------------------------------------------------------------------------------------
# Priser og mængder for efterspørgselskomponenter og udbudskomponenter
# ---------------------------------------------------------------------------------------------------------------------
# Vi looper over par bestående af en komponent, {C}, og tilhørende set, {s}. Vi udnytter multi sets til investeringer og kapital, is[i,s] og ks[k,s].

  #HACK 

  IO_vM_CET['out_other','01052','2012'] = IO_lM_CET['out_other','01052','2012']*1.01;

$FOR {C}, {s} in [('Rxe','rxe'), ('RxE_ARIMA','rxe_arima'), ('G','g'), ('X','x'), ('C','c'), ('I_s','is'), ('K','ks'), ('Y','s'), ('M','s'), ('GrossValAdd','s'), ('Y_CET','outs'), ('M_CET','outs')]:

    #Her sættes p lig den relative prisudvikling. Det er først i loopet, der laves et egentligt prisindeks 
    IO_p{C}[{s}_,t]$(IO_l{C}[{s}_,t]) = IO_v{C}[{s}_,t]/IO_l{C}[{s}_,t];

    #Først beregnes prisudviklingen med første dataår som basisår
    IO_p{C}[{s}_,tData] = 1;

    LOOP(t$tDataX1[t],
        IO_p{C}[{s}_,t]$(IO_l{C}[{s}_,t]) = IO_p{C}[{s}_,t-1] * IO_v{C}[{s}_,t]/IO_l{C}[{s}_,t]; 
        );

    #Sætter basisår 
    IO_p{C}[{s}_,t]$(tDatax1[t] and IO_p{C}[{s}_,tBasis]) = IO_p{C}[{s}_,t]/IO_p{C}[{s}_,tBasis];

    #Beregner den tilhørende mængde 
    io_q{C}[{s}_,t]$(io_p{C}[{s}_,t]) = io_v{C}[{s}_,t]/io_p{C}[{s}_,t];
$ENDFOR

# ---------------------------------------------------------------------------------------------------------------------
#   Her beregnes alle IO-leverancer på nederste niveau inkl. afgifter
# ---------------------------------------------------------------------------------------------------------------------
# Overordnede komponenter io_v{D} og io_l{D} er givet ud fra randtotaler - her beregnes io_v{D}_y, io_v{D}_m og io_v{D}_ym samt deres priser og mængder
# vI_s antager, at alle randpriser er ens med CES-priser og Paasche-priser. Forskelle fanges i fordelingsled i kalibrering

# Her beregnes IO-celler inklusiv skatter og afgifter i værdi og mængde
$FOR {D} in ['Rxe','c','G','X', 'I']:
  # Samlede skatter på D
  #  io_t{D}_y[{D},s,t]$(tData[t]) = (1+(1/io_pY_CET['out_other',s,t])*sum(afgsub,io_tDuty_{D}_y[{D},s,afgsub,t])) * (1+io_tVAT_{D}_y[{D},s,t]) - 1;
  #  io_t{D}_m[{D},s,t]$(tData[t] and io_pM_CET['out_other',s,t]) = (1+(1/io_pM_CET['out_other',s,t])*sum(afgsub,io_tDuty_{D}_m[{D},s,afgsub,t])) * (1+io_tVAT_{D}_m[{D},s,t]) * (1+io_tCus_{D}_m[{D},s,t]) - 1;
  io_t{D}_y[{D},s,t]$(tData[t]) = (1+sum(afgsub,io_tDuty_{D}_y[{D},s,afgsub,t] + io_tSub_{D}_y[{D},s,afgsub,t])) * (1+io_tVAT_{D}_y[{D},s,t]) - 1;
  io_t{D}_m[{D},s,t]$(tData[t]) = (1+sum(afgsub,io_tDuty_{D}_m[{D},s,afgsub,t] + io_tSub_{D}_m[{D},s,afgsub,t])) * (1+io_tVAT_{D}_m[{D},s,t]) * (1+io_tCus_{D}_m[{D},s,t]) - 1;
  # Efterspørgselskomponenterne i løbende priser inkl. skatter
  io_v{D}_y[{D},s,t]$(tData[t]) = (1+io_t{D}_y[{D},s,t]) * io_vn{D}_y[{D},s,t];
  io_v{D}_m[{D},s,t]$(tData[t]) = (1+io_t{D}_m[{D},s,t]) * io_vn{D}_m[{D},s,t];
  # IO-priserne er lig outputpriser inkl. skatter - de normeres IKKE til 1 i basisåret
  io_p{D}_y[{D},s,t]$(tData[t]) = (1+io_t{D}_y[{D},s,t]) * io_pY_CET['out_other',s,t];
  io_p{D}_m[{D},s,t]$(tData[t]) = (1+io_t{D}_m[{D},s,t]) * io_pM_CET['out_other',s,t];
  # Mængderne er defineret på baggrund heraf
  io_q{D}_y[{D},s,t]$(tData[t]) = io_v{D}_y[{D},s,t]/io_p{D}_y[{D},s,t];
  io_q{D}_m[{D},s,t]$(io_p{D}_m[{D},s,t]) = io_v{D}_m[{D},s,t]/io_p{D}_m[{D},s,t];
$ENDFOR


# Materialeinput fra den finansielle sektor (branchen 64000) ind i sin egen variabel
    $FOR1 {ym} in ['y','m']:
      # IO_qFin_{ym}[k,rxe,t]$(IO_qK[k,rxe,t] and not sameas[rxe,'off'] and not sameas[rxe,'64000']) 
      #                                                         = (IO_qK[k,rxe,t]/sum(kk, IO_qK[kk,rxe,t]))*IO_qRxE_{ym}[rxe,'64000',t];
      IO_qFin_{ym}[rxe,t]$(not sameas[rxe,'off'] and not sameas[rxe,'64000']) 
                                                              = IO_qRxE_{ym}[rxe,'64000',t];
      # IO_qFin_{ym}[k,rxe,t]$(IO_qK[k,rxe,t] and sum((r,s), IO_qRxE_{ym}[r,s,t]) and sameas[rxe,'64000'])             
      #                                                         = (sum(r, IO_qRxE_{ym}[r,'64000',t])/sum((r,s), IO_qRxE_{ym}[r,s,t]))*(IO_qK[k,rxe,t]/sum(kk, IO_qK[kk,rxe,t]))*IO_qRxE_{ym}[rxe,'64000',t];

      #Branchen 64000 har et stort egetforbrug i IO-tabellen. Hvis vi fortolker alt dette som "finansiel service", der hører til kapitalapparat, kommer det til at se ud som om, branchen tager urealistisk høje 
      #priser fra sig selv, når de efterspørger finansiel service til kapitalapparat. Derfor benyttes nedenstående ad hoc nøgle til at tildele 64000 leverance af finansiel service
       IO_qFin_{ym}[rxe,t]$(sum((r,s), IO_qRxE_{ym}[r,s,t]) and sameas[rxe,'64000'])             
                                                              = (sum(r, IO_qRxE_{ym}[r,'64000',t])/sum((r,s), IO_qRxE_{ym}[r,s,t]))*IO_qRxE_{ym}[rxe,'64000',t];
      IO_pFin_{ym}[rxe,t]$(not sameas[rxe,'off'])           = IO_pRxE_{ym}[rxe,'64000',t];
      IO_tFin_{ym}[rxe,t]$(not sameas[rxe,'off'])           = IO_tRxE_{ym}[rxe,'64000',t];
      IO_tVat_Fin_{ym}[rxe,t]$(not sameas[rxe,'off'])       = IO_tVat_RxE_{ym}[rxe,'64000',t];
      IO_tDuty_Fin_{ym}[rxe,afgsub,t]$(not sameas[rxe,'off'])  = IO_tDuty_RxE_{ym}[rxe,'64000',afgsub,t];
      IO_tSub_Fin_{ym}[rxe,afgsub,t]$(not sameas[rxe,'off'])   = IO_tSub_RxE_{ym}[rxe,'64000',afgsub,t];
      IO_vtDuty_Fin_{ym}[rxe,afgsub,t]$(not sameas[rxe,'off']) = IO_vtDuty_RxE_{ym}[rxe,'64000',afgsub,t];
      IO_vtSub_Fin_{ym}[rxe,afgsub,t]$(not sameas[rxe,'off'])  = IO_vtSub_RxE_{ym}[rxe,'64000',afgsub,t];

      IO_tDuty_RxE_{ym}[rxe,'64000',afgsub,t]$(not sameas[rxe,'off']) = 0; #With financial scetors moved we set RxE parameters to 0
      IO_tSub_RxE_{ym}[rxe,'64000',afgsub,t]$(not sameas[rxe,'off']) = 0;
      IO_vtDuty_RxE_{ym}[rxe,'64000',afgsub,t]$(not sameas[rxe,'off']) = 0;
      IO_vtSub_RxE_{ym}[rxe,'64000',afgsub,t]$(not sameas[rxe,'off']) = 0;

      IO_vFin_{ym}[rxe,t]                                   = IO_pFin_{ym}[rxe,t] * IO_qFin_{ym}[rxe,t];
    $ENDFOR1

      IO_tCus_fin_m[rxe,t]$(not sameas[rxe,'off']) = IO_tCus_RxE_m[rxe,'64000',t];


    # Startværdi for aggregatet (den endelig værdi bliver regnet med et kædet prisindeks af selve modellen)
    IO_qFin[rxe,t]$(not sameas[rxe,'off']) = IO_qFin_y[rxe,t]*IO_pFin_y[rxe,t] + IO_qFin_m[rxe,t]*IO_pFin_m[rxe,t]; 
    IO_pFin[rxe,t]$(not sameas[rxe,'off']) = 1;
    IO_vFin[rxe,t]$(not sameas[rxe,'off']) = IO_qFin[rxe,t];

    #Fordeler finansiel service på k vha nøgle baseret på kapitalapparatsdata, IO_qK
    IO_qFin_k[k,rxe,t]$(not sameas[rxe,'off'] and IO_qK[k,rxe,t]) = IO_qK[k,rxe,t]/sum(kk, IO_qK[kk,rxe,t]) * IO_vFin[rxe,t];
    IO_vFin_k[k,rxe,t]$(not sameas[rxe,'off'] and IO_qK[k,rxe,t]) = IO_qK[k,rxe,t]/sum(kk, IO_qK[kk,rxe,t]) * IO_vFin[rxe,t]; 
    IO_pFin_k[k,rxe,t]$(not sameas[rxe,'off'] and IO_qK[k,rxe,t]) = 1;

     #  Input fra den finansielle sektor trækkes ud af materialeinputtet for de øvrige brancher
    $FOR {v} in ['v','p','q']:
      $FOR1 {ym} in ['y','m']:
        IO_{v}RxE_{ym}[rxe,s,t]$(sameas[s,'64000'] and not sameas[rxe,'off'] and not sameas[rxe,'64000']) = 0;
      $ENDFOR1
    $ENDFOR

    $FOR {ym} in ['y','m']:
      IO_qRxE_{ym}[rxe,s,t]$(sameas[s,'64000'] and sameas[rxe,'64000']) 
                                        = IO_qRxE_{ym}[rxe,s,t] - IO_qFin_{ym}[rxe,t];
      IO_vRxE_{ym}[rxe,s,t]$(sameas[s,'64000'] and sameas[rxe,'64000']) 
                                        = IO_pRxE_{ym}[rxe,s,t]*IO_qRxE_{ym}[rxe,s,t];
    $ENDFOR                                    


# ---------------------------------------------------------------------------------------------------------------------
#   Her beregnes alle aggregerede IO-leverancer inkl. afgifter (aggregerede som i aggregatet af indenlandsk og import). 
#   AKB: Overvej om ikke bare modellen skal beregne det her. 
# ---------------------------------------------------------------------------------------------------------------------
# Overordnede komponenter io_v{D} og io_l{D} er givet ud fra randtotaler - her beregnes io_v{D}_y, io_v{D}_m og io_v{D}_ym samt deres priser og mængder
# vI_s antager, at alle randpriser er ens med CES-priser og Paasche-priser. Forskelle fanges i fordelingsled i kalibrering

# Her beregnes IO-celler inklusiv skatter og afgifter i værdi og mængde
$FOR {D} in ['Rxe','C','G','X','I']:
  # Aggregatet af import og indenlandsk efterspørgsel efter vare s

  io_v{D}_ym[{D},s,t]$(tData[t])       = io_v{D}_y[{D},s,t] + io_v{D}_m[{D},s,t];
  io_v{D}_ym[{D},'tot',t]$(tData[t])   = sum(s, io_v{D}_ym[{D},s,t]);

$IF '{D}' in ['G','X','I','C']:
  io_v{D}_ym['{D}tot','tot',t]$(tData[t]) = sum({D}, io_v{D}_ym[{D},'tot',t]);
$ENDIF

  # Foregående års priser beregnes først naivt og afstemmes herefter til at passe med totalen for aggregatet
  io_l{D}_ym0[{D},s,t]$tdataX1[t]    = io_p{D}_y[{D},s,t-1] * io_q{D}_y[{D},s,t] + io_p{D}_m[{D},s,t-1] * io_q{D}_m[{D},s,t];

   $IF '{D}' != 'I':
     io_l{D}_ym[{D},s,t]$(tDataX1[t] and sum(ss, io_l{D}_ym0[{D},ss,t]) <> 0) = io_l{D}_ym0[{D},s,t] * io_l{D}[{D},t] / sum(ss, io_l{D}_ym0[{D},ss,t]);
   $ENDIF
   $IF '{D}' == 'I':
     io_l{D}_ym[{D},s,t]$(tDataX1[t] and sum(ss, io_l{D}_ym0[{D},ss,t]) <> 0) = io_l{D}_ym0[{D},s,t] * io_l{D}_s[{D},'tot',t] / sum(ss, io_l{D}_ym0[{D},ss,t]);
  $ENDIF

  # Priser normeres i startåret (som er et år senere for pl, da den beregnes med laggede værdier)
  io_p{D}_ym0[{D},s,t]$tdata1[t]                            = 1;
  io_pl{D}_ym[{D},s,t]$(tdataX1[t])                         = 1;

  # Prisen pl = v/l (svarer til p = v/q)
  io_pl{D}_ym[{D},s,t]$(tdataX1[t] and io_l{D}_ym[{D},s,t] <> 0) = io_v{D}_ym[{D},s,t]/io_l{D}_ym[{D},s,t];
  
  # Bruger pl = v/l = p*q/(p(-1) * q) = p/p(-1) giver p = pl*p(-1) 
  LOOP (t$tdataX1[t],
    io_p{D}_ym0[{D},s,t]                                    = io_pl{D}_ym[{D},s,t] * io_p{D}_ym0[{D},s,t-1];
  );

  # Normerer så p = 1 i basisåret
  io_p{D}_ym[{D},s,t]$(io_p{D}_ym0({D},s,tbasis) <> 0)      = io_p{D}_ym0[{D},s,t]/io_p{D}_ym0({D},s,tbasis);
  # Beregner mængden ved q=v/p
  io_q{D}_ym[{D},s,t]$(io_v{D}_ym[{D},s,t] <> 0)           = io_v{D}_ym[{D},s,t]/io_p{D}_ym[{D},s,t];


$ENDFOR

  #---------------------------------------------------------------------------------------------
  #  Andet bras
  #---------------------------------------------------------------------------------------------

$PGROUP NEWbras 
    IO_w[t] ""
    IO_vPayRoll[s,t] ""
    IO_tLPayRoll[s,t] ""
    IO_tLAM[s,t] ""
    IO_tLSubsidy[s,t] ""
    IO_vtL[s,t] ""
    IO_tL[s,t] ""

    IO_qL[s_,t] ""
    IO_pL[s_,t] ""
    IO_vL[s_,t] ""

    IO_FakDuty[s,t] "" 
    IO_FakDutyB_xh[s,t] ""
    IO_FakDutyEkso_v[s,t] ""
    IO_FakDuty_Ekso[s,t] ""
    IO_FakDutyL[s,t] ""
    IO_FakDutyL_am[s,t] ""
    IO_FakDutyL_aud[s,t] ""
    IO_FakDutyL_ul[s,t] ""
    IO_vtCAP[s,t] ""

    IO_vCtourist[c_,t] ""
    IO_lCtourist[c_,t] ""
    IO_pCtourist[c_,t] ""
    IO_qCtourist[c_,t] ""
    IO_vCHH[c_,t] ""
    IO_qCHH[c_,t] ""
    IO_lCHH[c_,t] ""
    IO_pCHH[c_,t] ""

    IO_tK[k,s,t] ""
    io_vtNetProductionRest[s_,t] ""
    io_vtNetProductionRestE[s,t] ""

;


# ---------------------------------------------------------------------------------------------------------------------
#  Lagerinvesteringer
# ---------------------------------------------------------------------------------------------------------------------
# Lagerinvesteringerne for hver branche sættes lig leverancerne fra hver branche
io_vI_s['invt',s,t]$(tData[t]) = io_vI_ym['invt',s,t];
io_qI_s['invt',s,t]$(tData[t]) = io_qI_ym['invt',s,t];
io_pI_s['invt',s,t]$(tData[t]) = io_pI_ym['invt',s,t];

io_vI_s['itot',s,t]$(tData[t]) = sum(i, io_vI_s[i,s,t]);


# ---------------------------------------------------------------------------------------------------------------------
# Beregner samlet forbrug
# ---------------------------------------------------------------------------------------------------------------------
io_vC['ctot',t]$(tData[t]) = io_vC['ctot',t] - io_VX['xTur',t];                        
io_lC['ctot',t]$(tData[t]) = io_lC['ctot',t] - io_lX['xTur',t];  

IO_pC['ctot',tData] = 1;

LOOP (t$tdataX1[t],
  io_pC['ctot',t] = io_pC['ctot',t-1] * IO_vC['ctot',t]/IO_lC['ctot',t];
);

io_pC['ctot',t]          = io_pC['ctot',t]/io_pC['ctot',tBasis];  # Normerer så p = 1 i basisåret
io_qC['ctot',t]$tData[t] = io_vC['ctot',t]/io_pC['ctot',t];        # Kapitalapparat i kædede værdier



# ---------------------------------------------------------------------------------------------------------------------
# GDP: Beregner BNP
# ---------------------------------------------------------------------------------------------------------------------
#Kun investeringer, der skal korrigeres, da totalerne for de andre anvendelser er dannet før energi er trukket ud.
io_vGDP[t]$(tData[t]) = io_vC['ctot',t] + io_vG['gtot',t] + io_vI_s['itot','tot',t] + io_vX['xtot',t] - io_vM['tot',t];# + sum((nz2,ns105x), YZE73V_t.l[ns105x,nz2,t] + MZE73V_t.l[ns105x,nz2,t])/correction_factor_values + sum(nz2, PZE73V_t.l['nTv',nz2,t] + PZE73V_t.l['nTp',nz2,t])/correction_factor_values;                        
io_lGDP[t]$(tData[t]) = io_lC['ctot',t] + io_lG['gtot',t] + io_lI_s['itot','tot',t] + io_lX['xtot',t] - io_lM['tot',t];# + sum((nz2,ns105x), YZE73D_t.l[ns105x,nz2,t] + MZE73D_t.l[ns105x,nz2,t])/correction_factor_values + sum(nz2, PZE73D_t.l['nTv',nz2,t] + PZE73D_t.l['nTp',nz2,t])/correction_factor_values;;                        

#Sætter initiale 1-taller
io_pGDP[tdata]    = 1;

LOOP (t$tdataX1[t],
  io_pGDP[t] = io_pGDP[t-1] * io_vGDP[t]/io_lGDP[t];
);

io_pGDP[t]          = io_pGDP[t]/io_pGDP[tbasis];  # Normerer så p = 1 i basisåret
io_qGDP[t]$tData[t] = io_vGDP[t]/io_pGDP[t];        # Kapitalapparat i kædede værdier


#Produktionsskatter- og susbidier 
  #Definerer total 
  IO_FakDuty[s,t]$(tData[t])           = sum((artskat,s56)$(maps2s56(s,s56)), vpSkatSub_56[artskat,s56,t]) - sum((artsub,s56)$(maps2s56(s,s56)), vpSkatSub_56[artsub,s56,t]);

  #Kapital- og arbejdskraftknyttede produktionsskatter- og subsidier
  IO_FakDutyEKso_v[s,t]$(tData[t])     = sum((art,s56)$(artDutyEkso_v(art) and maps2s56(s,s56)), vpSkatSub_56[art,s56,t]);
  IO_FakDutyB_xh[s,t]$(tData[t])       = sum((art,s56)$(artDutyB(art) and maps2s56(s,s56)), vpSkatSub_56[art,s56,t]);
  IO_FakDutyB_xh['68203',t]$(tData[t]) = 0; #Ejendomsværdiskatterne udgøres i høj grad af grundskyld, jf. https://www.dst.dk/da/Statistik/nyheder-analyser-publ/nyt/NytHtml?cid=34700. Derfor ikke knyttet til qK[ib]. Hvorfor vi alligevel tæller det med for vsh. ved jeg ikke, kh AKB

  IO_FakDutyL_am[s,t]$(tData[t])       = sum((art,s56)$(artDutyL_am(art) and maps2s56(s,s56)), vpSkatSub_56[art,s56,t]);
  IO_FakDutyL_aud[s,t]$(tData[t])      = sum((art,s56)$(artDutyL_aud(art) and maps2s56(s,s56)), vpSkatSub_56[art,s56,t]);
  IO_FakDutyL_ul[s,t]$(tData[t])       = sum((art,s56)$(artDutyL_uL(art) and maps2s56(s,s56)), vpSkatSub_56[art,s56,t]);
  IO_FakDutyL[s,t]$(tData[t])          = IO_FakDutyL_am[s,t] + IO_FakDutyL_aud[s,t] - IO_FakDutyL_ul[s,t];

  #CAP-budget 
  IO_vtCAP[s,t]$(tData[t])             = - sum((art,s56)$(artCAP(art) and maps2s56(s,s56)), vpSkatSub_56[art,s56,t]);

  #Lønsumsafgift?
  d1VATexempt[s,t] = yes$(sum(s56$(maps2s56(s,s56)), vpSkatSub_56['art5105',s56,t]));


#Da vi tager lønnen fra MAKRO går fra inflationskorrigeret til ikke-inflationskorrigeret størrelse
io_w[t]                         = ExtFor_w[t]/ExtFor_w['2019']/inf_factor[t];

IO_vPayRoll[s,t]$(tData[t])           = sum(s56$maps2s56(s,s56), vIO_a['SalEmpl',s56,t]);

# komponenter af io_tL beregnes
io_tLPayRoll[s,t]$(io_vPayroll[s,t])      = io_FakDutyL_am(s,t)  /  io_vPayroll[s,t];
io_tLAM[s,t]$(io_vPayroll[s,t] ne 0)      = io_FakDutyL_aud(s,t) / io_vPayroll[s,t];
io_tLSubsidy[s,t]$(io_vPayroll[s,t] ne 0) = io_FakDutyL_ul(s,t)  / io_vPayroll[s,t];
io_vtL[s,t] = io_tLPayRoll[s,t] * io_vPayroll[s,t] + io_tLAM[s,t] * io_vPayroll[s,t] - io_tLSubsidy[s,t] * io_vPayroll[s,t];
io_tL[s,t]$io_vPayroll[s,t] = io_vtL[s,t] / io_vPayroll[s,t];

io_qL[s,t]$io_w[t]              = io_vPayroll[s,t] / io_w[t];
io_pL[s,t]                      = (1 +  io_tL[s,t] ) * io_w[t];
io_vL[s,t]                      = io_pL[s,t] * io_qL[s,t];
io_vL['tot',t]                  = sum(s, io_vL[s,t]);
io_qL['tot',t]$io_w[t]          = sum(s, io_vPayroll[s,t]) / io_w[t];
io_pL['tot',t]$io_qL['tot',t]   = io_vL['tot',t] / io_qL['tot',t];


io_tK['ib',s,t]$(( io_pI_s['ib',s,t] * io_qK['ib',s,t] ) ne 0) 
                = io_FakDutyB_xh(s,t) / (io_pI_s['ib',s,t] * io_qK['ib',s,t] );

io_tK['im',s,t]$(( io_pI_s['im',s,t] * io_qK['im',s,t] ) ne 0) 
                = io_FakDutyEkso_v(s,t) / (io_pI_s['im',s,t] * io_qK['im',s,t] );

io_tK['it',s,t]$(( io_pI_s['it',s,t] * io_qK['it',s,t] ) ne 0) 
                = io_FakDutyEkso_v(s,t) / (io_pI_s['it',s,t] * io_qK['it',s,t] );


io_vtNetProductionRestE[s,t]$(tData[t]) = sum(ns105$(map1052five(s,ns105)), sum(nsGR$(nsGR2ns105(ns105,nsGR)), sum(brch$(brch2nsGR(brch,nsGR)), vkvote_data[brch,t])))/10**6;

io_vtNetProductionRestE[sSlagteri,t]$(tData[t])   = sYS[sSlagteri]*io_vtNetProductionRestE['10011',t];
io_vtNetProductionRestE[sMineralogi,t]$(tData[t]) = sYS_cement[sMineralogi]*io_vtNetProductionRestE['23001',t];

#Beregner rest produktionsskatter- og subsidier
io_vtNetProductionRest[s,t]$(tData[t]) = IO_FakDuty(s,t)            #
                                       - io_FakDutyL(s,t)           #
                                       - io_FakDutyB_xh(s,t) 
                                       - io_FakDutyEkso_v(s,t)
                                       - io_vtNetProductionRestE[s,t]
                                       - io_vtCAP[s,t];

io_vtNetProductionRest['tot',t]$(tData[t]) = sum(s, IO_vtNetProductionRest[s,t]);    
                               
  #---------------------------------------------------------------------------------------------
  #  Osplitning af turister og danske hush
  #---------------------------------------------------------------------------------------------

   #  io_vCtourist['cEne',t]$(tData[t])      = 0.06*io_VX['xTur',t];
   io_vCtourist['cHouEne',t]$(tData[t])      = 0.022*io_VX['xTur',t];
   io_vCtourist['cCarEne',t]$(tData[t])      = 0.038*io_VX['xTur',t];
   io_vCtourist['cNonFood',t]$(tData[t])     = 0.49*io_VX['xTur',t];
   io_vCtourist['cSer',t]$(tData[t])         = 0.45*io_VX['xTur',t];
   io_vCHH[c,t]$tDataX1[t]                   = io_vC[c,t] - io_vCtourist[c,t];
   
   #  io_lCtourist['cEne',t]$(tData[t])      = 0.06*io_lX['xTur',t];
   io_lCtourist['cHouEne',t]$(tData[t])      = 0.022*io_lX['xTur',t];
   io_lCtourist['cCarEne',t]$(tData[t])      = 0.038*io_lX['xTur',t];
   io_lCtourist['cNonFood',t]$(tData[t])     = 0.49*io_lX['xTur',t];
   io_lCtourist['cSer',t]$(tData[t])         = 0.45*io_lX['xTur',t];
   io_lCHH[c,t]$tDataX1[t]                   = io_lC[c,t] - io_lCtourist[c,t];
   
   io_vCtourist[cNest,t]$tDataX1[t] = sum(c$cNest2c[cNest,c], io_vCtourist[c,t]);
   io_vCHH[cNest,t]$tDataX1[t]      = sum(c$cNest2c[cNest,c], io_vCHH[c,t]);
   io_lCtourist[cNest,t]$tDataX1[t] = sum(c$cNest2c[cNest,c], io_lCtourist[c,t]);
   io_lCHH[cNest,t]$tDataX1[t]      = sum(c$cNest2c[cNest,c], io_lCHH[c,t]);


  $FOR {D} in ['Ctourist', 'CHH']:
    IO_p{D}[c_,tdata] = 1;

    LOOP(t$tDataX1[t],
      io_p{D}[c_,t]$(IO_l{D}[c_,t]) = io_p{D}[c_,t-1] * IO_v{D}[c_,t]/IO_l{D}[c_,t];
    );

    io_p{D}[c_,t]$(io_p{D}[c_,tBasis]) = io_p{D}[c_,t]/io_p{D}[c_,tBasis];
    io_q{D}[c_,t]$(io_p{D}[c_,t])      = io_v{D}[c_,t] / io_p{D}[c_,t];
  $ENDFOR


#---------------------------------------------------------------------------------------------
# Data for ARIMA-estimations to waste-module (used in "\Data\Affaldsdata\data_til_ARIMA")
#---------------------------------------------------------------------------------------------
PARAMETER
  #  pCHH_NonFood_Car[t]             "Price of the aggregate of non-food goods and cars"
  #  qCHH_NonFood_Car[t]             "Quantity of the aggregate of non-food goods and cars"
  #  pCHH_Food[t]                    "Price of the aggregate of food"
  #  qCHH_Food[t]                    "Quantity of the aggregate of food"
  #  pCHH_Good[t]                    "Price of the aggregate of goods"
  #  qCHH_Good[t]                    "Quantity of the aggregate of goods"

  qCHH_Good_arima[t]              "Private consumption of goods"
  qCHH_Food_arima[t]              "Private consumption of food"
  qCHH_NonFood_arima[t]           "Private consumption of non-food goods"
  #  qCHH_NonFood_Car_arima[t]       "Private consumption of non-food goods and cars"
;

#  # Calculate the aggregate of the consumption of non-food goods and cars
#  pCHH_NonFood_Car[tdata]               = 1;
#  pCHH_NonFood_Car[t]$(IO_lCHH['cNonFood',t] or IO_lCHH['cCar',t])              
#                                        = pCHH_NonFood_Car[t-1]*(IO_vCHH['cNonFood',t]+IO_vCHH['cCar',t])/(IO_lCHH['cNonFood',t]+IO_lCHH['cCar',t]);
#  pCHH_NonFood_Car[t]$(pCHH_NonFood_Car[tBasis])              
#                                        = pCHH_NonFood_Car[t]/pCHH_NonFood_Car[tBasis];
#  qCHH_NonFood_Car[t]$(pCHH_NonFood_Car[t-1])              
#                                        = (IO_vCHH['cNonFood',t]+IO_vCHH['cCar',t])/pCHH_NonFood_Car[t];

#  # Calculate the aggregate of the consumption of food
#  pCHH_Food[tdata]                      = 1;
#  pCHH_Food[t]$(IO_lCHH['cFoodDairy',t] or IO_lCHH['cFoodVeg',t] or IO_lCHH['cFoodBev',t] or IO_lCHH['cFoodPig',t] or IO_lCHH['cFoodCow',t] or IO_lCHH['cFoodFish',t] or IO_lCHH['cFoodPoul',t])              
#                                        = pCHH_Food[t-1]*(IO_vCHH['cFoodDairy',t]+IO_vCHH['cFoodVeg',t]+IO_vCHH['cFoodBev',t]+IO_vCHH['cFoodPig',t]+IO_vCHH['cFoodCow',t]+IO_vCHH['cFoodFish',t]+IO_vCHH['cFoodPoul',t])
#                                                                    /(IO_lCHH['cFoodDairy',t]+IO_lCHH['cFoodVeg',t]+IO_lCHH['cFoodBev',t]+IO_lCHH['cFoodPig',t]+IO_lCHH['cFoodCow',t]+IO_lCHH['cFoodFish',t]+IO_lCHH['cFoodPoul',t]);
#  pCHH_Food[t]$(pCHH_Food[tBasis])              
#                                        = pCHH_Food[t]/pCHH_Food[tBasis];
#  qCHH_Food[t]$(pCHH_Food[t-1])              
#                                        = (IO_lCHH['cFoodDairy',t]+IO_lCHH['cFoodVeg',t]+IO_lCHH['cFoodBev',t]+IO_lCHH['cFoodPig',t]+IO_lCHH['cFoodCow',t]+IO_lCHH['cFoodFish',t]+IO_lCHH['cFoodPoul',t])
#                                                /pCHH_Food[t-1];   

#  # Calculate the aggregate of the consumption of goods
#  pCHH_Good[tdata]                      = 1;
#  pCHH_Good[t]$(IO_lCHH['cNonFood',t] or IO_lCHH['cFoodDairy',t] or IO_lCHH['cFoodVeg',t] or IO_lCHH['cFoodBev',t] or IO_lCHH['cFoodPig',t] or IO_lCHH['cFoodCow',t] or IO_lCHH['cFoodFish',t] or IO_lCHH['cFoodPoul',t])              
#                                        = pCHH_Good[t-1]*(IO_vCHH['cNonFood',t]+IO_vCHH['cFoodDairy',t]+IO_vCHH['cFoodVeg',t]+IO_vCHH['cFoodBev',t]+IO_vCHH['cFoodPig',t]+IO_vCHH['cFoodCow',t]+IO_vCHH['cFoodFish',t]+IO_vCHH['cFoodPoul',t])
#                                                                    /(IO_lCHH['cNonFood',t]+IO_lCHH['cFoodDairy',t]+IO_lCHH['cFoodVeg',t]+IO_lCHH['cFoodBev',t]+IO_lCHH['cFoodPig',t]+IO_lCHH['cFoodCow',t]+IO_lCHH['cFoodFish',t]+IO_lCHH['cFoodPoul',t]);
#  pCHH_Good[t]$(pCHH_Good[tBasis])              
#                                        = pCHH_Good[t]/pCHH_Good[tBasis];
#  qCHH_Good[t]$(pCHH_Good[t-1])              
#                                        = (IO_lCHH['cNonFood',t]+IO_lCHH['cFoodDairy',t]+IO_lCHH['cFoodVeg',t]+IO_lCHH['cFoodBev',t]+IO_lCHH['cFoodPig',t]+IO_lCHH['cFoodCow',t]+IO_lCHH['cFoodFish',t]+IO_lCHH['cFoodPoul',t])
#                                                /pCHH_Good[t-1];                                   

# Consumptions used in ARIMA-estimations
qCHH_Good_arima[t]                    = IO_qCHH['cGoo',t];
qCHH_Food_arima[t]                    = IO_qCHH['cFood',t];
qCHH_NonFood_arima[t]                 = IO_qCHH['cNonFood',t];
#  qCHH_NonFood_Car_arima[t]             = qCHH_NonFood_Car[t];

execute_unload "Output/qRxE_qCHH_arima.gdx" qCHH_Good_arima, qCHH_Food_arima, qCHH_NonFood_arima, IO_qRxE_ARIMA;


set_time_periods(2016,2019);
set_data_periods(2016,2019);


#---------------------------------------------------------------------------------------------
#  LAV 117 - GR nøgle for 2019 
#---------------------------------------------------------------------------------------------

#  set map117_2_s56(ns117,s);
#  map117_2_s56(ns117,s) = sum(s56$maps2s56(s,s56), sum(ns146, ns146_2_s56(ns146,s56) and IOns117_2_IOns146(ns117,ns146)));
#  map117_2_s56('100010','10012') = yes;
#  map117_2_s56('100010','10013') = yes;


#  PARAMETER IO_vY_117[ns117,t], IO_GRpbakey117[s,t], key117_2_sGR(ns117,s), one_to_many_allocatedinstepone(ns117), help117(ns117), helps(s), helpmanytomany(ns117,s);
#  IO_vY_117[ns117,t] = sum((ns146,IO_146_c)$(IOns117_2_IOns146(ns117,ns146)), vIO_y_2014_2019_ns146[ns146,IO_146_c,t]); #Tjekket med IO online - passer i 2019 med afvigelse på 117 tusind kroner. Derudover stikprøver på branche niveau, der stort set passede.

#  alias(ns117,ns117a);
#  key117_2_sGR(ns117,s)$(map117_2_s56(ns117,s) and sum(ns117a, 1$map117_2_s56(ns117a,s))=1)  = IO_vY[s,'2019']/(IO_vY_117[ns117,'2019']/10**6);

#  helps(s)       = yes$(sum(ns117a, 1$map117_2_s56(ns117a,s))<>1); #Many på den ene led 
#  help117(ns117) = yes$(sum(s, 1$map117_2_s56(ns117,s))<>1);       #Many på den anden led
#  helpmanytomany(ns117,s) = yes$(help117(ns117) and helps(s) and map117_2_s56(ns117,s)); #Many-to-many

#  one_to_many_allocatedinstepone(ns117) = sum(s, key117_2_sGR(ns117,s)$(sum(r,helpmanytomany(ns117,r))));
#  #  one_to_many_allocatedinstepone(ns117)$(sum(ns117a, 1$map117_2_s56(ns117a,s))<>1)
#  key117_2_sGR(ns117,s)$(map117_2_s56(ns117,s) and sum(ns117a, 1$map117_2_s56(ns117a,s))<>1) = 1 - one_to_many_allocatedinstepone(ns117); #Hm, den her metode er vist ikke 110 pct. idiotsikker. For hvis man har to ns117 brancher, der mapper til samme 2 GR brancher bliver det her en ægte residualbestemmelse mere end afsløring af mappingen fra 146-GR
#  PARAMETER testo[ns117], thetest[ns117];
#  thetest[ns117]= sum(s, key117_2_sGR(ns117,s));
#  testo[ns117] =1$(sum(s, key117_2_sGR(ns117,s))<>1);

#  IO_GRpbakey117[s,t] = sum(ns117, key117_2_sGR(ns117,s) * IO_vY_117[ns117,'2019']);

#  execute_unload 'output\pre.gdx';


#  #Test
#  LOOP(ns117,
#    tjek = sum(s, key117_2_sGR(ns117,s));
#    ABORT$(tjek < 1-1e-5 or tjek> 1+1e-5) tjek, "Andele summer ikke til 1 i fordelingsnoegle af 117 til GR brancher";
#      );
