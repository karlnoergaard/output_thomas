
#====================================================================================================================================================================================================================#
# FORØGELSE AF ØKOLOGISTØTTEN
#====================================================================================================================================================================================================================#

Parameter
    vtSubOrganic_baseline[plant_sectors,t]
    tSubOrganic_baseline[plant_sectors,t]
    vtSubOrganic_mekanisk[plant_sectors,t]
    tHectareSubsidy_mekanisk[t]
    vtHectareSubsidy_prod_baseline[plant_sectors,t]
    vtHectareSubsidy_nonprod_baseline[plant_sectors,t]
    vtHectareSubsidy_prod_mekanisk[plant_sectors,t]
    vtHectareSubsidy_nonprod_mekanisk[plant_sectors,t]

    vPlant_CET_baseline[plant_sectors,plant_out,t]
    vAni_CET_baseline[ani_sectors,t]
    vRxE_nm_baseline[ani_sectors,plant_sectors,Agri_,t]
    vRxE_y_nm_baseline[r,plant_sectors,t]
    vRxE_y_nm_sh_baseline[r,plant_sectors,t]
    vC_y_baseline[plant_sectors,c,t]
    vSupplyUse_baseline[plant_sectors,*,t]

    vRxE_nm[ani_sectors,plant_sectors,Agri_,t]
    vSupplyUse[plant_sectors,*,t]

    pRxE_ym_baseline[r,plant_sectors,t]
    qRxE_ym_baseline[r,plant_sectors,t]
    vRxE_ym_baseline[r,plant_sectors,t]
    pRxE_y_baseline[r,plant_sectors,t]
    vRxE_y_baseline[r,plant_sectors,t]
    vRxE_m_baseline[r,plant_sectors,t]

    qX_s_baseline[plant_sectors,t]

    Aftagere[r,plant_sectors,*,t]
    Aftagere_nonMarket[ani_sectors,plant_sectors,*,t]
    Eksport[plant_sectors,*,t]
    InputSubstitution[r,plant_sectors,*,t]

    ;

tSubOrganic_baseline[plant_sectors,t]$(tx0[t])      = tSubOrganic.l[plant_sectors,t];
vtSubOrganic_baseline[plant_sectors,t]$(tx0[t])     = vtSubOrganic.l[plant_sectors,t];   
vtHectareSubsidy_prod_baseline[plant_sectors,t]$(tx0[t]) = vtHectareSubsidy_prod.l[plant_sectors,t];
vtHectareSubsidy_nonprod_baseline[plant_sectors,t]$(tx0[t]) = vtHectareSubsidy_nonprod.l[plant_sectors,t];

#  tSubOrganic.l['01012',t]$(t.val > 2023)      = tSubOrganic.l['01012',t] 
#                                                  + (3000-870)/(10**9)*(10**6) * inf_growth_factor[t]; 

vtSubOrganic_mekanisk[plant_sectors,t]              = - tSubOrganic.l[plant_sectors,t] * qPlant_baseline.l[plant_sectors,'Land',t-1];
tHectareSubsidy_mekanisk[t]$(tx0[t])                = tHectareSubsidy_baseline.l[t]
                                                      + sum(plant_sectors, vtSubOrganic_mekanisk[plant_sectors,t] - vtSubOrganic_baseline[plant_sectors,t])
                                                        / sum(plant_sectors, qPlant_baseline.l[plant_sectors,'Land',t-1] + sum(landallocation, qLand_nonproductive_baseline.l[landallocation,plant_sectors,t-1]));
vtHectareSubsidy_prod_mekanisk[plant_sectors,t]$(tx0[t]) = - tHectareSubsidy_mekanisk[t] * qPlant_baseline.l[plant_sectors,'Land',t-1];
vtHectareSubsidy_nonprod_mekanisk[plant_sectors,t]$(tx0[t]) = - sum(landallocation, tHectareSubsidy_mekanisk[t] * qLand_nonproductive_baseline.l[landallocation,plant_sectors,t-1]);

## Supply Use, Market ##
vPlant_CET_baseline[plant_sectors,plant_out,t]$(tx0[t]) = qPlant_CET_baseline.l[plant_sectors,plant_out,t]*pPlant_CET_baseline.l[plant_sectors,plant_out,t];
vAni_CET_baseline[ani_sectors,t]$(tx0[t]) = qAni_CET_baseline.l[ani_sectors,'out_other',t]*pAni_CET_baseline.l[ani_sectors,'out_other',t];

pRxE_ym_baseline[r,plant_sectors,t] = pRxE_ym.l[r,plant_sectors,t];
qRxE_ym_baseline[r,plant_sectors,t] = qRxE_ym.l[r,plant_sectors,t];
vRxE_ym_baseline[r,plant_sectors,t] = vRxE_ym.l[r,plant_sectors,t];

pRxE_y_baseline[r,plant_sectors,t] = pRxE_y.l[r,plant_sectors,t];
vRxE_y_baseline[r,plant_sectors,t] = vRxE_y.l[r,plant_sectors,t];

vRxE_m_baseline[r,plant_sectors,t] = vRxE_m.l[r,plant_sectors,t];

vRxE_nm_baseline[ani_sectors,plant_sectors,Agri_,t]$(tx0[t] and (sameas[agri_,'litter'] or sameas[agri_,'coarsefeed'])) 
    = qRxE_nm.l[ani_sectors,plant_sectors,Agri_,t]*pRxE_nm.l[ani_sectors,plant_sectors,Agri_,t];

vC_y_baseline[plant_sectors,c,t] = vC_y.l[c,plant_sectors,t];


vSupplyUse_baseline[plant_sectors,'vRxE_y',t]$(tx0[t])      = sum(r, vRxE_y_baseline[r,plant_sectors,t]);
vSupplyUse_baseline[plant_sectors,'vRxE_nm',t]$(tx0[t])     = sum((ani_sectors,agri_), vRxE_nm_baseline[ani_sectors,plant_sectors,Agri_,t]);
vSupplyUse_baseline[plant_sectors,'vX_y',t]$(tx0[t])        = sum(x, vX_y_baseline.l[x,plant_sectors,t]);
vSupplyUse_baseline[plant_sectors,'vC_y',t]$(tx0[t])        = sum(c, vC_y_baseline[plant_sectors,c,t]);
vSupplyUse_baseline[plant_sectors,'Total Use',t]$(tx0[t])   = vSupplyUse_baseline[plant_sectors,'vRxE_y',t]
                                                            + vSupplyUse_baseline[plant_sectors,'vX_y',t]
                                                            + vSupplyUse_baseline[plant_sectors,'vC_y',t];
vSupplyUse_baseline[plant_sectors,'Production',t]$(tx0[t])  = vPlant_CET_baseline[plant_sectors,'grain',t];

vSupplyUse_baseline[plant_sectors,'PrivateConsumption, %',t]$(tx0[t])  = vSupplyUse_baseline[plant_sectors,'vC_y',t]/vSupplyUse_baseline[plant_sectors,'Production',t]*100;
vSupplyUse_baseline[plant_sectors,'Eksports, %',t]$(tx0[t])  = vSupplyUse_baseline[plant_sectors,'vX_y',t]/vSupplyUse_baseline[plant_sectors,'Production',t]*100;
vSupplyUse_baseline[plant_sectors,'01031, %',t]$(tx0[t])  = vRxE_y_baseline['01031',plant_sectors,t]/vSupplyUse_baseline[plant_sectors,'Production',t]*100;
vSupplyUse_baseline[plant_sectors,'01032, %',t]$(tx0[t])  = vRxE_y_baseline['01032',plant_sectors,t]/vSupplyUse_baseline[plant_sectors,'Production',t]*100;
vSupplyUse_baseline[plant_sectors,'01051, %',t]$(tx0[t])  = vRxE_y_baseline['01051',plant_sectors,t]/vSupplyUse_baseline[plant_sectors,'Production',t]*100;
vSupplyUse_baseline[plant_sectors,'10040, %',t]$(tx0[t])  = vRxE_y_baseline['10040',plant_sectors,t]/vSupplyUse_baseline[plant_sectors,'Production',t]*100;
vSupplyUse_baseline[plant_sectors,'10120, %',t]$(tx0[t])  = vRxE_y_baseline['10120',plant_sectors,t]/vSupplyUse_baseline[plant_sectors,'Production',t]*100;

## IO-responses, Market
Aftagere[r,plant_sectors,'BudgetAndel_i_produktion',t]$(tx0[t] and (sameas[r,'10040'] or sameas[r,'10120'])) 
    = vRxE_y_baseline[r,plant_sectors,t]/vY_baseline.l[r,t]*100;
Aftagere[ani_sectors,plant_sectors,'BudgetAndel_i_produktion',t]$(tx0[t] and (sameas[ani_sectors,'01031'] or sameas[ani_sectors,'01032'] or sameas[ani_sectors,'01051'])) 
    = vRxE_y_baseline[ani_sectors,plant_sectors,t]/vAni_CET_baseline[ani_sectors,t]*100;

Aftagere[r,plant_sectors,'Eksportandel',t]$(tx0[t] and sameas[plant_sectors,'01012'] and (sameas[r,'10040'] or sameas[r,'10120'])) 
    = vX_y_baseline.l['xOth',r,t]/vY_baseline.l[r,t]*100;
Aftagere[ani_sectors,plant_sectors,'Eksportandel',t]$(tx0[t] and sameas[plant_sectors,'01012'] and (sameas[ani_sectors,'01031'] or sameas[ani_sectors,'01032'] or sameas[ani_sectors,'01051'])) 
    = vX_y_baseline.l['xOth',ani_sectors,t]/vAni_CET_baseline[ani_sectors,t]*100;

Aftagere[r,plant_sectors,'Eksportelasticitet',t]$(tx0[t] and sameas[plant_sectors,'01012'] and (sameas[r,'10040'] or sameas[r,'10120'] or sameas[r,'01031'] or sameas[r,'01032'] or sameas[r,'01051'])) 
    = eXF.l['xOth',r];

Aftagere[r,plant_sectors,'Importandel',t]$(tx0[t] and sameas[plant_sectors,'01012'] and (sameas[r,'10040'] or sameas[r,'10120'])) 
    = (1 - vRxE_y_baseline[r,plant_sectors,t]/vRxE_ym_baseline[r,plant_sectors,t])*100;

## IO-responses, Non-market
Aftagere_nonMarket[ani_sectors,plant_sectors,'BudgetAndel_i_produktion, litter',t]$(tx0[t] and (sameas[ani_sectors,'01031'] or sameas[ani_sectors,'01032'] or sameas[ani_sectors,'01051'])) 
    = vRxE_nm_baseline[ani_sectors,plant_sectors,'Litter',t]/vAni_CET_baseline[ani_sectors,t]*100;

Aftagere_nonMarket[ani_sectors,plant_sectors,'BudgetAndel_i_produktion, CoarseFeed',t]$(tx0[t] and (sameas[ani_sectors,'01031'] or sameas[ani_sectors,'01032'] or sameas[ani_sectors,'01051'])) 
    = vRxE_nm_baseline[ani_sectors,plant_sectors,'CoarseFeed',t]/vAni_CET_baseline[ani_sectors,t]*100;

## Export responses
Eksport[plant_sectors,'Eksportandel',t]$(tx0[t])        = 100;
Eksport[plant_sectors,'Eksportelasticitet',t]$(tx0[t])  = eXF.l['xOth',plant_sectors];
qX_s_baseline[plant_sectors,t] = qX_s.l[plant_sectors,t];


# EQUATIONS
$BLOCK B_org_subsidy

    E_tHectareSubsidy_alt[t]$(tx0[t])..
      tHectareSubsidy[t] =E= tHectareSubsidy_baseline[t] 
                            - sum(plant_sectors, vSubsidy_Fertilizer[plant_sectors,t])
                              / sum(plant_sectors, qPlant[plant_sectors,'Land',t-1] + sum(landallocation, qLand_nonproductive[landallocation,plant_sectors,t-1]))
                            + (sum(plant_sectors, vtSubOrganic[plant_sectors,t]) - sum(plant_sectors, vtSubOrganic_baseline[plant_sectors,t]))
                                / sum(plant_sectors, qPlant[plant_sectors,'Land',t-1] + sum(landallocation, qLand_nonproductive[landallocation,plant_sectors,t-1]));



$ENDBLOCK

$BLOCK B_equation_change
# Mekanisk prisstigning sfa. CO2e-afgift på landbrugets ikke-energirelaterede udledninger
	E_pPlant_mekanisk_new[plant_sectors,t]$(tx0[t])..
		pPlant_mekanisk[plant_sectors,t] 	=E= # Change in carbon tax
                                                (sum((plant_,emmtype)$(emmtype2plant_[emmtype,plant_] and d1EmmAgrxE[emmtype,plant_sectors,t,'CO2e']), tCO2_emm_plant[Plant_sectors,plant_,t] * (qEmmAgrxE_baseline[emmtype,Plant_sectors,t,'co2e']*growth_factor[t]) / 10**6)
												# Change in organic subsidy
                                                - (tSubOrganic[plant_sectors,t]-tSubOrganic_baseline[plant_sectors,t])*qPlant_baseline[plant_sectors,'Land',t-1]
                                                # Change in hectare subsidy
                                                - (tHectareSubsidy_mekanisk[t]-tHectareSubsidy_baseline[t])*qPlant_baseline[plant_sectors,'Land',t-1]
                                                )
                                                / (pPlant_CET_baseline[plant_sectors,'netprod',t]*qPlant_CET_baseline[plant_sectors,'netprod',t])
                                                ;
$ENDBLOCK


$GROUP G_neworg 
    vMaalSoegOrg[t] ""
    margDBII_2CGE_act_after3part[t]  ""
    qLandOrg[t] ""
    vMaalSoegOrg_perha[t] ""
    vDBII_input_baseline[t] ""
    vDBII_CGE_baseline[t] ""
    sChangeDBII_2CGE_act_duetoorg[t] ""
    ChangeDBII_2CGE_act_baseline[t]
;

$GROUP G_neworg_endo 
    vMaalSoegOrg$(tx0[t] and t.val>=2027)
    vMaalSoegOrg_perha$(tx0[t] and t.val>=2027)
    qLandOrg$(tx0[t])
    sChangeDBII_2CGE_act_duetoorg$(tx0[t])
;

$GROUP G_neworg_exo 
    vMaalSoegOrg$(tx0[t] and t.val<2027)
    vMaalSoegOrg_perha$(tx0[t] and t.val<2027)
    margDBII_2CGE_act_after3part
    vDBII_input_baseline
    vDBII_CGE_baseline
    ChangeDBII_2CGE_act_baseline
;

margDBII_2CGE_act_after3part.l[t] = margDBII_2CGE_act.l[t];
qLandOrg.l[t] = qPlant.l['01012','land',t-1] + sum(landallocation, qLand_nonproductive.l[landallocation,'01012',t-1]) + qLand_nonproductive.l['BRAK','01011',t-1];
vtSubOrganic_baseline[plant_sectors,t] = vtSubOrganic.l[plant_sectors,t];
vDBII_input_baseline.l[t] = vDBII_INPUT.l[t];
vDBII_CGE_baseline.l[t]   = vDBII_CGE.l[t];
ChangeDBII_2CGE_act_baseline.l[t] = ChangeDBII_2CGE_act.l[t];
#  tHectareSubsidy_baseline.l[t] = tHectareSubsidy.l[t]; Skal ikke gives ny baseline-værdi
PARAMETER iterateorganic;

iterateorganic = 0;

#  $BLOCK B_orgland_target 


#      E_tOrgSubsidy_30[t]$(tx0[t] and t.val=2030)..
#          tSubOrganic['01012',t] =E= tSubOrganic_baseline['01012',t] + vMaalSoegOrg_perha[t];  # (margDBII_2CGE_act[t] - margDBII_2CGE_act_after3part[t]);

#      E_tOrgSubsidy[t]$(tx0[t] and t.val>2030)..
#          tSubOrganic['01012',t] =E= tSubOrganic['01012','2030']*inf_growth_factor[t]/inf_growth_factor['2030'];

#      E_tOrgSubsidy_27[t]$(tx0[t] and t.val=2027)..
#          tSubOrganic['01012',t] =E= tSubOrganic_baseline['01012',t]*3/4 + tSubOrganic['01012','2030']*inf_growth_factor['2027']/inf_growth_factor['2030'] * 1/4;

#      E_tOrgSubsidy_28[t]$(tx0[t] and t.val=2028)..
#          tSubOrganic['01012',t] =E= tSubOrganic_baseline['01012',t]*2/4 + tSubOrganic['01012','2030']*inf_growth_factor['2028']/inf_growth_factor['2030']* 2/4;

#      E_tOrgSubsidy_29[t]$(tx0[t] and t.val=2029)..
#          tSubOrganic['01012',t] =E= tSubOrganic_baseline['01012',t]*1/4 + tSubOrganic['01012','2030']*inf_growth_factor['2029']/inf_growth_factor['2030']* 3/4;


#      E_vDBII_INPUT_alt[t]$(tx0E[t])..   vDBII_INPUT[t] =E= vDBII_CGE[t+1] + jvDBII_CGE[t] - vMaalSoegOrg[t+1]; 

#      E_vMaalSoegOrg_perha[t]$(tx0[t] and t.val>=2027).. vMaalSoegOrg_perha[t] =E=  vMaalSoegOrg[t]/10**6/qLandOrg[t];

#      E_qLandOrg[t]$(tx0[t]).. qLandOrg[t] =E= qPlant['01012','land',t-1] + sum(landallocation, qLand_nonproductive[landallocation,'01012',t-1]);

#      #Bestemmer vMaalSoegOrg i 2030
#      E_qLandOrg_2030[t]$(tx0[t] and t.val=2030)..  qLandOrg[t] =E= (1-iterateorganic) * qLandOrg.l[t] + iterateorganic * 0.45;


#      E_vMaalSoegOrg[t]$(tx0[t] and t.val>2030)..    vMaalSoegOrg[t] =E= vMaalSoegOrg['2030'];

#      E_vMaalSoegOrg_27[t]$(tx0[t] and t.val=2027).. vMaalSoegOrg[t] =E= 1/4* vMaalSoegOrg['2030'];

#      E_vMaalSoegOrg_28[t]$(tx0[t] and t.val=2028).. vMaalSoegOrg[t] =E= 2/4* vMaalSoegOrg['2030'];

#      E_vMaalSoegOrg_29[t]$(tx0[t] and t.val=2029).. vMaalSoegOrg[t] =E= 3/4* vMaalSoegOrg['2030'];

#  $ENDBLOCK 

$BLOCK B_orgland_target 
    E_sChangeDBII_2CGE_act_duetoorg[t]$(tx0[t] and t.val=2030).. 
        sChangeDBII_2CGE_act_duetoorg[t]*(vDBII_INPUT[t] - vDBII_input_baseline[t]) =E= vMaalSoegOrg[t];


    E_tOrgSubsidy_30[t]$(tx0[t] and t.val=2030)..
        tSubOrganic['01012',t] =E= tSubOrganic_baseline['01012',t] - (ChangeDBII_2CGE_act[t] - ChangeDBII_2CGE_act_baseline[t]) * sChangeDBII_2CGE_act_duetoorg[t];  # (margDBII_2CGE_act[t] - margDBII_2CGE_act_after3part[t]);

    E_tOrgSubsidy[t]$(tx0[t] and t.val>2030)..
        tSubOrganic['01012',t] =E= tSubOrganic['01012','2030']*inf_growth_factor[t]/inf_growth_factor['2030'];

    E_tOrgSubsidy_27[t]$(tx0[t] and t.val=2027)..
        tSubOrganic['01012',t] =E= tSubOrganic_baseline['01012',t]*3/4 + tSubOrganic['01012','2030']*inf_growth_factor['2027']/inf_growth_factor['2030']*1/4;

    E_tOrgSubsidy_28[t]$(tx0[t] and t.val=2028)..
        tSubOrganic['01012',t] =E= tSubOrganic_baseline['01012',t]*2/4 + tSubOrganic['01012','2030']*inf_growth_factor['2028']/inf_growth_factor['2030']* 2/4;

    E_tOrgSubsidy_29[t]$(tx0[t] and t.val=2029)..
        tSubOrganic['01012',t] =E= tSubOrganic_baseline['01012',t]*1/4 + tSubOrganic['01012','2030']*inf_growth_factor['2029']/inf_growth_factor['2030']* 3/4;


    E_vDBII_INPUT_alt[t]$(tx0E[t])..   vDBII_INPUT[t] =E= vDBII_CGE[t+1] + jvDBII_CGE[t] + vMaalSoegOrg[t+1]; 

    E_vMaalSoegOrg_perha[t]$(tx0[t] and t.val>=2027).. vMaalSoegOrg_perha[t] =E=  vMaalSoegOrg[t]/10**6/qLandOrg[t];

    E_qLandOrg[t]$(tx0[t]).. qLandOrg[t] =E= qPlant['01012','land',t-1] + sum(landallocation, qLand_nonproductive[landallocation,'01012',t-1]) + qLand_nonproductive['BRAK','01011',t-1];

    #Bestemmer vMaalSoegOrg i 2030
    E_qLandOrg_2030[t]$(tx0[t] and t.val=2030)..  qLandOrg[t] =E= (1-iterateorganic) * qLandOrg.l[t] + iterateorganic * 0.5;


    E_vMaalSoegOrg[t]$(tx0[t] and t.val>2030)..    vMaalSoegOrg[t] =E= vMaalSoegOrg['2030'];

    E_vMaalSoegOrg_27[t]$(tx0[t] and t.val=2027).. vMaalSoegOrg[t] =E= 1/4* vMaalSoegOrg['2030'];

    E_vMaalSoegOrg_28[t]$(tx0[t] and t.val=2028).. vMaalSoegOrg[t] =E= 2/4* vMaalSoegOrg['2030'];

    E_vMaalSoegOrg_29[t]$(tx0[t] and t.val=2029).. vMaalSoegOrg[t] =E= 3/4* vMaalSoegOrg['2030'];

$ENDBLOCK 


#Setting up model
$MODEL M_zerohock_org_sub 
	M_CO2tax
    -E_tHectareSubsidy, B_org_subsidy
    -E_vDBII_INPUT,     B_orgland_target

;


$GROUP G_endo 
	G_endo
    G_neworg_endo
    tHectareSubsidy$(tx0[t])
    tSubOrganic$(tx0[t] and t.val>=2027 and sameas[plant_sectors,'01012'])
;


$GROUP G_exo 
	G_exo 
    G_neworg_exo
    tHectareSubsidy_baseline
;



$MODEL M_test2 
    M_test 
    -E_vDBII_INPUT
    E_vDBII_INPUT_alt
    E_sChangeDBII_2CGE_act_duetoorg
;
vMaalSoegOrg.l[t+1]$(t.val>2028) = -1.5*10**6;
$FIX vMaalSoegOrg, vDBII_input_baseline;

$FIX G_endolandlinks_exo;
$UNFIX G_endolandlinks_endo;
@SOLVE(M_test2);

$FIX G_exo;
$UNFIX G_endo;

$ONECHO > conopt4.opt
  #  Keep searching for a solution even if a bound is hit (due to non linearities)
  lmmxsf = 1

  #  Time limit in seconds
  rvtime = 1000000
  reslim = 1000000

  #  Optimality tolerance for reduced gradient
  RTREDG = 1.e-9

  #  Absolute pivot tolerance, Range: [2.2e-16, 1.e-7], Default: 1.e-10
  #  RTPIVA = 1.e-15

  #  Relative pivot tolerance during basis factorizations, Range: [1.e-3, 0.9], Default: 0.05
  #  RTPIVR = 1.e-3

  #  Multi-threating
  Threads=8
  THREADF=8

  #  iterLim = 1 

  #Turn of autosv
  #Frq_Rescale = 0
$OFFECHO

#  $FIX G_exo;
#  $UNFIX G_endo;
#  M_zerohock_org_sub.optfile = 1;
#  M_zerohock_org_sub.holdFixed = 1;
#  M_zerohock_org_sub.workfactor = 2;
#  Solve M_zerohock_org_sub using CNS;

#  $LOOP M_zerohock_org_sub: 
#      PARAMETER {name}_infeas{sets};
#      {name}_infeas{sets}$({name}.infeas{sets}<>0 and {subsets}) = {name}.l{sets};
#      display {name}_infeas;
#  $ENDLOOP
#      $GROUP G_EndoAndExo 
#          G_endo 
#          G_exo
#      -sigmaID
#      -adjCO2_shadowCost
#      ;
#      @save(G_EndoAndExo);

# execute_unload 'output\pre.gdx';

#  $FOR {iterateorganic} in ['0.1','0.5','1']:
#  $FOR {iterateorganic} in ['0','1']:
$FOR {iterateorganic} in ['1']:

    iterateorganic = {iterateorganic};
    execute_unload 'output\pre.gdx_{iterateorganic}.gdx';
    @SOLVE(M_zerohock_org_sub);
    #  @assert_no_difference(G_EndoAndExo,1e-6);
    execute_unload 'output\Orgsub_{iterateorganic}.gdx';
$ENDFOR

$IMPORT report.gms;
$IMPORT sanitycheck.gms

parameter
    pPlant_mekanisk_hectare[plant_sectors,t]
    pPlant_mekanisk_hectare_land[plant_sectors,t]
    vPlant_CET[plant_sectors,plant_out,t]
    vtHectareSubsidy_prod_mekanisk_hectare[plant_sectors,t]
    ;

# Mekanisk prisstigning med hektarstøtte i ligevægt
pPlant_mekanisk_hectare[plant_sectors,t]$(tx0[t]) 	= 
    # Change in carbon tax
    (sum((plant_,emmtype)$(emmtype2plant_[emmtype,plant_] and d1EmmAgrxE[emmtype,plant_sectors,t,'CO2e']), tCO2_emm_plant.l[Plant_sectors,plant_,t] * (qEmmAgrxE_baseline.l[emmtype,Plant_sectors,t,'co2e']*growth_factor[t]) / 10**6)
	# Change in organic subsidy
    - (tSubOrganic.l[plant_sectors,t]-tSubOrganic_baseline[plant_sectors,t])*qPlant_baseline.l[plant_sectors,'Land',t-1]
    # Change in hectare subsidy
    - (tHectareSubsidy.l[t]-tHectareSubsidy_baseline.l[t])*qPlant_baseline.l[plant_sectors,'Land',t-1]
    )
    / (pPlant_CET_baseline.l[plant_sectors,'netprod',t]*qPlant_CET_baseline.l[plant_sectors,'netprod',t])
    ;

# Mekanisk prisstigning med hektarstøtte og jordmængde i ligevægt
pPlant_mekanisk_hectare_land[plant_sectors,t]$(tx0[t]) 	= 
    # Change in carbon tax
    (sum((plant_,emmtype)$(emmtype2plant_[emmtype,plant_] and d1EmmAgrxE[emmtype,plant_sectors,t,'CO2e']), tCO2_emm_plant.l[Plant_sectors,plant_,t] * (qEmmAgrxE_baseline.l[emmtype,Plant_sectors,t,'co2e']*growth_factor[t]) / 10**6)
	# Change in organic subsidy
    - (tSubOrganic.l[plant_sectors,t]-tSubOrganic_baseline[plant_sectors,t])*qPlant.l[plant_sectors,'Land',t-1]
    # Change in hectare subsidy
    - (tHectareSubsidy.l[t]-tHectareSubsidy_baseline.l[t])*qPlant.l[plant_sectors,'Land',t-1]
    )
    / (pPlant_CET_baseline.l[plant_sectors,'netprod',t]*qPlant_CET_baseline.l[plant_sectors,'netprod',t])
    ;


vPlant_CET[plant_sectors,plant_out,t]$(t.val>2018) = qPlant_CET.l[plant_sectors,plant_out,t]*pPlant_CET.l[plant_sectors,plant_out,t];

vtHectareSubsidy_prod_mekanisk_hectare[plant_sectors,t]$(tx0[t]) 	= - (tHectareSubsidy.l[t]-tHectareSubsidy_baseline.l[t])*qPlant_baseline.l[plant_sectors,'Land',t-1];

vRxE_nm[ani_sectors,plant_sectors,Agri_,t]$(tx0[t] and (sameas[agri_,'litter'] or sameas[agri_,'coarsefeed'])) 
    = qRxE_nm.l[ani_sectors,plant_sectors,Agri_,t]*pRxE_nm.l[ani_sectors,plant_sectors,Agri_,t];

vSupplyUse[plant_sectors,'vRxE_y',t]$(tx0[t])      = sum(r, vRxE_y.l[r,plant_sectors,t]);
vSupplyUse[plant_sectors,'vRxE_nm',t]$(tx0[t])     = sum((ani_sectors,agri_), vRxE_nm[ani_sectors,plant_sectors,Agri_,t]);
vSupplyUse[plant_sectors,'vX_y',t]$(tx0[t])        = sum(x, vX_y.l[x,plant_sectors,t]);
vSupplyUse[plant_sectors,'vC_y',t]$(tx0[t])        = sum(c, vC_y.l[c,plant_sectors,t]);
vSupplyUse[plant_sectors,'Total Use',t]$(tx0[t])   = vSupplyUse[plant_sectors,'vRxE_y',t]
                                                    + vSupplyUse[plant_sectors,'vX_y',t]
                                                    + vSupplyUse[plant_sectors,'vC_y',t];
vSupplyUse[plant_sectors,'Production',t]$(tx0[t])  = vPlant_CET[plant_sectors,'grain',t];

vSupplyUse[plant_sectors,'PrivateConsumption, %',t]$(tx0[t])  = vSupplyUse[plant_sectors,'vC_y',t]/vSupplyUse[plant_sectors,'Production',t]*100;
vSupplyUse[plant_sectors,'Eksports, %',t]$(tx0[t])  = vSupplyUse[plant_sectors,'vX_y',t]/vSupplyUse[plant_sectors,'Production',t]*100;
vSupplyUse[plant_sectors,'01031, %',t]$(tx0[t])  = vRxE_y.l['01031',plant_sectors,t]/vSupplyUse[plant_sectors,'Production',t]*100;
vSupplyUse[plant_sectors,'01032, %',t]$(tx0[t])  = vRxE_y.l['01032',plant_sectors,t]/vSupplyUse[plant_sectors,'Production',t]*100;
vSupplyUse[plant_sectors,'01051, %',t]$(tx0[t])  = vRxE_y.l['01051',plant_sectors,t]/vSupplyUse[plant_sectors,'Production',t]*100;
vSupplyUse[plant_sectors,'10040, %',t]$(tx0[t])  = vRxE_y.l['10040',plant_sectors,t]/vSupplyUse[plant_sectors,'Production',t]*100;
vSupplyUse[plant_sectors,'10120, %',t]$(tx0[t])  = vRxE_y.l['10120',plant_sectors,t]/vSupplyUse[plant_sectors,'Production',t]*100;


Aftagere[r,plant_sectors,'Ændring i produktionspris',t]$(tx0[t] and sameas[plant_sectors,'01012'] and (sameas[r,'10040'] or sameas[r,'10120'])) 
    = (pY.l[r,t]/pY_baseline.l[r,t] - 1)*100;
Aftagere[ani_sectors,plant_sectors,'Ændring i produktionspris',t]$(tx0[t] and sameas[plant_sectors,'01012'] and (sameas[ani_sectors,'01031'] or sameas[ani_sectors,'01032'] or sameas[ani_sectors,'01051'])) 
    = (pAni_CET.l[Ani_sectors,"out_other",t]/pAni_CET_baseline.l[Ani_sectors,"out_other",t] - 1)*100;

Aftagere[r,plant_sectors,'Ændring i produktionsmængde',t]$(tx0[t] and sameas[plant_sectors,'01012'] and (sameas[r,'10040'] or sameas[r,'10120'])) 
    = (qY.l[r,t]/qY_baseline.l[r,t] - 1)*100;
Aftagere[ani_sectors,plant_sectors,'Ændring i produktionsmængde',t]$(tx0[t] and sameas[plant_sectors,'01012'] and (sameas[ani_sectors,'01031'] or sameas[ani_sectors,'01032'] or sameas[ani_sectors,'01051'])) 
    = (qAni_CET.l[Ani_sectors,"out_other",t]/qAni_CET_baseline.l[Ani_sectors,"out_other",t] - 1)*100;

Aftagere[r,plant_sectors,'Ændring i inputpris, ym',t]$(tx0[t] and (sameas[r,'10040'] or sameas[r,'10120'])) 
    = (pRxE_ym.l[r,plant_sectors,t]/pRxE_ym_baseline[r,plant_sectors,t] - 1)*100;
Aftagere[r,plant_sectors,'Ændring i inputmængde, ym',t]$(tx0[t] and (sameas[r,'10040'] or sameas[r,'10120'])) 
    = (qRxE_ym.l[r,plant_sectors,t]/qRxE_ym_baseline[r,plant_sectors,t] - 1)*100;
Aftagere[r,plant_sectors,'Substitutionselasticitet, ym',t]$(tx0[t] and sameas[plant_sectors,'01012'] and (sameas[r,'10040'] or sameas[r,'10120'])) 
    = eRxE_pgroup.l[r,'induspecific_agr'];

Aftagere[r,plant_sectors,'Ændring i inputpris, y',t]$(tx0[t]and (sameas[r,'10040'] or sameas[r,'10120'])) 
    = (pRxE_y.l[r,plant_sectors,t]/pRxE_y_baseline[r,plant_sectors,t] - 1)*100;
Aftagere[r,plant_sectors,'Ændring i inputmængde, y',t]$(tx0[t] and (sameas[r,'10040'] or sameas[r,'10120'])) 
    = (qRxE_y.l[r,plant_sectors,t]/qRxE_y_baseline.l[r,plant_sectors,t] - 1)*100;
Aftagere[r,plant_sectors,'Substitutionselasticitet, y',t]$(tx0[t] and (sameas[r,'10040'] or sameas[r,'10120'])) 
    = eRxE_s.l[r,plant_sectors];



Eksport[plant_sectors,'Ændring i produktionsmængde',t]$(tx0[t]) 
    = (qX_s.l[plant_sectors,t]/qX_s_baseline[plant_sectors,t] - 1)*100;

execute_unload 'Output\organic_subsidy_3000.gdx';
@check_vBoP();

