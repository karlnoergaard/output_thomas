#====================================================================================================================================================================================================================#
# MODELLING BIOCHAR
#====================================================================================================================================================================================================================#

$IF %stage% == "variables":

# defining parameters
$PGROUP pyrolyse_parameters
    T_Pyrolyse ""
    switch_Pyrolyse_forward_looking ""
    switch_Pyrolyse_frontloading ""
    switch_Pyrolyse_sluggish ""
    rhoPyrolyse[PyrolyseTech] ""
    uT_Pyrolyse[t] ""
    uBetaPyrolyse ""
    shPyrolysePrice_type[PyrolyseTech,CostType_pyrolyse,t] ""
    pK_pyrolyse[t] ""
;

$GROUP pyrolyse_parameters2
    sigmaPyrolyse[PyrolyseTech] ""
;


d1PyrolysePot[PyrolyseTech,t] = no;

$ENDIF



$IF %stage% == "groupcompilation":


$GROUP G_Pyrolyse_endo
    rPyrolyse_gains[PyrolyseTech,t]$(tx0[t] and d1PyrolysePot[PyrolyseTech,t])                      "Unit gains of implementing technology"
    rPyrolyse_costs[PyrolyseTech,t]$(tx0[t] and d1PyrolysePot[PyrolyseTech,t])                      "Unit costs of implementing technology"
    rPyrolyse[PyrolyseTech,t]$(tx0[t] and d1PyrolysePot[PyrolyseTech,t])                            "Instantanous technology adoption rate (without forward-looking or sluggsihness)"
    rPyrolyse_preferred[PyrolyseTech,t]$(tx0[t] and d1PyrolysePot[PyrolyseTech,t])                  "Technology adoption with forward-looking mechanism (if switch_forward_looking = 1)"
    rPyrolyse_actual[PyrolyseTech,t]$(tx0[t] and d1PyrolysePot[PyrolyseTech,t])                     "Actual technology adoption (with sluggishness, if switch_sluggish = 1)"
    qEmmPyrolyse[PyrolyseTech,t]$(tx0[t] and d1PyrolysePot[PyrolyseTech,t])                         "Abated emmisions per technology"
    qEmmPyrolyse_tot[t]$(tx0[t] and sum(PyrolyseTech, d1PyrolysePot[PyrolyseTech,t]))               "Total abated emmisions"
    qI_Pyrolyse_levelized[PyrolyseTech,t]$(tx0[t] and d1PyrolysePot[PyrolyseTech,t])                "LCOE of capital (quantities)"
    vI_Pyrolyse_levelized[PyrolyseTech,t]$(tx0[t] and d1PyrolysePot[PyrolyseTech,t])                "LCOE of capital (values)"
    vPyrolyse_cost[PyrolyseTech,t]$(tx0[t] and d1PyrolysePot[PyrolyseTech,t]) 				              "Pyrolyse costs"
    qK_Pyrolyse_demand[PyrolyseTech,t]$((tx0[t] and d1PyrolysePot[PyrolyseTech,t+1]) or (tend[t] and d1PyrolysePot[PyrolyseTech,t]))       "Total capital demand, implied by levelized investment demand and user cost"
    qI_Pyrolyse_tilde[PyrolyseTech,t]$(tx0[t] and sum(tt, d1PyrolysePot[PyrolyseTech,tt]))          "Investment necessary to cover total capital demand"
    qI_Pyrolyse_actual[PyrolyseTech,t]$(tx0[t] and sum(tt, d1PyrolysePot[PyrolyseTech,tt]))         "Actual investments that drives investment demand"
    vBiomass_Pyrolyse[t]$(tx0[t] and sum(PyrolyseTech, d1PyrolysePot[PyrolyseTech,t]))              "Biomass demand (values)"
    qBiomass_Pyrolyse[t]$(tx0[t] and sum(PyrolyseTech, d1PyrolysePot[PyrolyseTech,t]))              "Biomass demand (quantities)"
    vLCOE_Pyrolyse[t]$(tx0[t] and sum(PyrolyseTech, d1PyrolysePot[PyrolyseTech,t]))                 "Total LCOE (values)"
    vSubsidy_Pyrolyse[t]$(tx0[t] and sum(PyrolyseTech, d1PyrolysePot[PyrolyseTech,t]))              "Total subsidies (values) "
;

$GROUP G_Pyrolyse_exo
    pyrolyse_parameters2 ""
    tSubsidy_Pyrolyse[PyrolyseTech,t]$(tx0[t] and d1PyrolysePot[PyrolyseTech,t]) ""
    pPyrolyse[PyrolyseTech,t]$(tx0[t] and d1PyrolysePot[PyrolyseTech,t]) ""
    pI_s[i_,s,t]$(sameas[i_,'iM'] and sameas[s,'01011']) ""
    j_rPyrolyse[PyrolyseTech,t]$(tx0[t] and d1PyrolysePot[PyrolyseTech,t]) ""
    rPyrolyse_actual[PyrolyseTech,t]$(t0[t] and d1PyrolysePot[PyrolyseTech,t]) ""
    PyrolysePot[PyrolyseTech,t]$(tx0[t] and d1PyrolysePot[PyrolyseTech,t]) ""
    rDepr_Pyrolyse[t]$(tx0[t] and sum(PyrolyseTech, d1PyrolysePot[PyrolyseTech,t])) ""
    qK_Pyrolyse_demand$((t0[t] or tx0[t]) and sum(tt, d1PyrolysePot[PyrolyseTech,tt])) ""
    pY_CET_baseline$(sameas[out,'Straw for energy purposes'] and sameas[s,'01011']) ""
;

$ENDIF

# ======================================================================================================================
# Equations
# ======================================================================================================================
$IF %stage% == "equations":

  $BLOCK B_pyrolyse

  # ADOPTION

  # Unit gains of implementing technology 
  E_rPyrolyse_gains[PyrolyseTech,t]$(tx0[t] and d1PyrolysePot[PyrolyseTech,t]).. 
    rPyrolyse_gains[PyrolyseTech,t] =E= @max(0.00001,tSubsidy_Pyrolyse[PyrolyseTech,t]);

  # Unit cost of implementing technology 
  E_rPyrolyse_costs[PyrolyseTech,t]$(tx0[t] and d1PyrolysePot[PyrolyseTech,t]).. 
      rPyrolyse_costs[PyrolyseTech,t] =E= shPyrolysePrice_type[PyrolyseTech,'Capital',t] * pPyrolyse[PyrolyseTech,t]*pI_s['iM','01011',t]
                                        + shPyrolysePrice_type[PyrolyseTech,'Biomass',t] * pPyrolyse[PyrolyseTech,t];

  # Instantanous technology adoption rate (without forward-looking or sluggsihness)
  E_rPyrolyse[PyrolyseTech,t]$(tx0[t] and d1PyrolysePot[PyrolyseTech,t]).. 
      rPyrolyse[PyrolyseTech,t] =E= @cdfLogNorm(rPyrolyse_gains[PyrolyseTech,t],rPyrolyse_costs[PyrolyseTech,t],sigmaPyrolyse[PyrolyseTech]);

  # Technology adoption with forward-looking mechanism (if switch_forward_looking = 1)
  E_rPyrolyse_preferred[PyrolyseTech,t]$(tx0E[t] and d1PyrolysePot[PyrolyseTech,t])..
      rPyrolyse_preferred[PyrolyseTech,t] =E= (1-switch_Pyrolyse_forward_looking)*rPyrolyse[PyrolyseTech,t] 
                                               + switch_Pyrolyse_forward_looking*( (1-uBetaPyrolyse)*rPyrolyse[PyrolyseTech,t]+(uBetaPyrolyse)*rPyrolyse_preferred[PyrolyseTech,t+1]);

  # Terminal condition for forward-looking mechanism
  E_rPyrolyse_preferred_terminal_condition[PyrolyseTech,t]$(tend[t] and d1PyrolysePot[PyrolyseTech,t])..
      rPyrolyse_preferred[PyrolyseTech,tend] =E= rPyrolyse[PyrolyseTech,tend];

  # Actual technology adoption (with sluggishness, if switch_sluggish = 1)
  E_rPyrolyse_actual[PyrolyseTech,t]$(tx0[t] and d1PyrolysePot[PyrolyseTech,t])..
      rPyrolyse_actual[PyrolyseTech,t] =E= 
          (1-switch_Pyrolyse_sluggish)*rPyrolyse_preferred[PyrolyseTech,t]  
          + switch_Pyrolyse_sluggish*( exp(-sqr(rPyrolyse_preferred[PyrolyseTech,t] - rPyrolyse_actual[PyrolyseTech,t-1])/rhoPyrolyse[PyrolyseTech])
          * (rPyrolyse_preferred[PyrolyseTech,t]) 
          + (1-exp(-sqr(rPyrolyse_preferred[PyrolyseTech,t] - rPyrolyse_actual[PyrolyseTech,t-1])/rhoPyrolyse[PyrolyseTech])) * rPyrolyse_actual[PyrolyseTech,t-1]);

  # EMISSIONS

  E_qEmmPyrolyse[PyrolyseTech,t]$(tx0[t] and d1PyrolysePot[PyrolyseTech,t])..
      qEmmPyrolyse[PyrolyseTech,t] =E= rPyrolyse_actual[PyrolyseTech,t]*PyrolysePot[PyrolyseTech,t];

  E_qEmmPyrolyse_tot[t]$(tx0[t] and sum(PyrolyseTech, d1PyrolysePot[PyrolyseTech,t]))..
      qEmmPyrolyse_tot[t] =E= sum(PyrolyseTech$(d1PyrolysePot[PyrolyseTech,t]), qEmmPyrolyse[PyrolyseTech,t]);
  
  # INVESTMENTS

  E_vPyrolyse_cost[PyrolyseTech,t]$(tx0[t] and d1PyrolysePot[PyrolyseTech,t]).. 
  	vPyrolyse_cost[PyrolyseTech,t] =E= - PyrolysePot[PyrolyseTech,t] * growth_factor[t] 
                                              * rPyrolyse_costs[PyrolyseTech,t]
                                              * @Int_cdfLogNorm(rPyrolyse_gains[PyrolyseTech,t],rPyrolyse_costs[PyrolyseTech,t],sigmaPyrolyse[PyrolyseTech])
                                              * 10**3 * 10**(-9);
                                              
  E_vI_Pyrolyse_levelized[PyrolyseTech,t]$(tx0[t] and d1PyrolysePot[PyrolyseTech,t])..
      vI_Pyrolyse_levelized[PyrolyseTech,t] =E= vPyrolyse_cost[PyrolyseTech,t]*shPyrolysePrice_type[PyrolyseTech,'Capital',t];

  E_qI_Pyrolyse_levelized[PyrolyseTech,t]$(tx0[t] and d1PyrolysePot[PyrolyseTech,t])..
      qI_Pyrolyse_levelized[PyrolyseTech,t] =E= vI_Pyrolyse_levelized[PyrolyseTech,t] / pI_s['iM','01011',t];

  # Total capital demand, implied by levelized investment demand and user cost
  E_qK_Pyrolyse_demand[PyrolyseTech,t]$(tx1[t] and d1PyrolysePot[PyrolyseTech,t])..
      qK_Pyrolyse_demand[PyrolyseTech,t-1] =E= vI_Pyrolyse_levelized[PyrolyseTech,t]/pK_pyrolyse[t];

  # Total capital demand, terminal condition
  E_qK_Pyrolyse_demand_terminal[PyrolyseTech,t]$(tend[t] and d1PyrolysePot[PyrolyseTech,t])..
      qK_Pyrolyse_demand[PyrolyseTech,t] =E= qK_Pyrolyse_demand[PyrolyseTech,t-1];

  # Investment necessary to cover total capital demand
  E_qI_Pyrolyse_tilde[PyrolyseTech,t]$(tx0[t] and sum(tt, d1PyrolysePot[PyrolyseTech,tt]))..
      qI_Pyrolyse_tilde[PyrolyseTech,t] =E= (qK_Pyrolyse_demand[PyrolyseTech,t] - (1 - rDepr_Pyrolyse[t]) * qK_Pyrolyse_demand[PyrolyseTech,t-1]/fq);

  # Spread necessary investments evenly over T_Pyrolyse periods preceeding year of capital demand (if front-loading is activated)
  E_qI_Pyrolyse_actual_start[PyrolyseTech,t]$(tx0[t] and (t.val<=(t0.val+T_Pyrolyse)) and sum(ttt, d1PyrolysePot[PyrolyseTech,ttt]))..
      qI_Pyrolyse_actual[PyrolyseTech,t] =E= (1-switch_Pyrolyse_frontloading)*qI_Pyrolyse_levelized[PyrolyseTech,t]
                                            + switch_Pyrolyse_frontloading * sum(tt$(tt.val >= t.val and tt.val < t.val + T_Pyrolyse and not tt.val=t0.val), 
                                                                                  qI_Pyrolyse_tilde[PyrolyseTech,tt]/(min[(tt.val - t0.val),T_Pyrolyse]));

  # Spread necessary investments evenly over T_Pyrolyse periods preceeding year of capital demand (if front-loading is activated)
  E_qI_Pyrolyse_actual[PyrolyseTech,t]$(tx0[t] and (t.val>(t0.val+T_Pyrolyse)) and (t.val<=(tend.val-T_Pyrolyse)) and sum(ttt, d1PyrolysePot[PyrolyseTech,ttt]))..
      qI_Pyrolyse_actual[PyrolyseTech,t] =E= (1-switch_Pyrolyse_frontloading)*qI_Pyrolyse_levelized[PyrolyseTech,t]
                                            + switch_Pyrolyse_frontloading * sum(tt$(tt.val >= t.val and tt.val < t.val + T_Pyrolyse and not tt.val=t0.val), 
                                                                                  qI_Pyrolyse_tilde[PyrolyseTech,tt])/T_Pyrolyse;

  # Spread necessary investments evenly over T_Pyrolyse periods preceeding year of capital demand (if front-loading is activated)
  E_qI_Pyrolyse_actual_terminal[PyrolyseTech,t]$(tx0[t] and (t.val>(tend.val-T_Pyrolyse)) and sum(ttt, d1PyrolysePot[PyrolyseTech,ttt]))..
      qI_Pyrolyse_actual[PyrolyseTech,t] =E= (1-switch_Pyrolyse_frontloading)*qI_Pyrolyse_levelized[PyrolyseTech,t]
                                            + switch_Pyrolyse_frontloading * sum(tt$(tt.val >= t.val and tt.val < t.val + T_Pyrolyse and not tt.val=t0.val), 
                                                                                  qI_Pyrolyse_tilde[PyrolyseTech,tt])/T_Pyrolyse*(T_Pyrolyse/(tend.val - t.val + 1));

  # BIOMASS USE

  E_vBiomass_Pyrolyse[t]$(tx0[t] and sum(PyrolyseTech, d1PyrolysePot[PyrolyseTech,t]))..
      vBiomass_Pyrolyse[t] =E= sum(PyrolyseTech$(d1PyrolysePot[PyrolyseTech,t]) ,vPyrolyse_cost[PyrolyseTech,t]*shPyrolysePrice_type[PyrolyseTech,'Biomass',t]);

  E_qBiomass_Pyrolyse[t]$(tx0[t] and sum(PyrolyseTech, d1PyrolysePot[PyrolyseTech,t]))..
      qBiomass_Pyrolyse[t] =E= vBiomass_Pyrolyse[t] / pY_CET_baseline['Straw for energy purposes','01011',t];

  # TOTAL COSTS AND SUBSIDIES

  E_vLCOE_Pyrolyse[t]$(tx0[t] and sum(PyrolyseTech, d1PyrolysePot[PyrolyseTech,t]))..
      vLCOE_Pyrolyse[t] =E= sum(PyrolyseTech$(d1PyrolysePot[PyrolyseTech,t]), vI_Pyrolyse_levelized[PyrolyseTech,t]) + vBiomass_Pyrolyse[t];

  E_vSubsidy_Pyrolyse[t]$(tx0[t] and sum(PyrolyseTech, d1PyrolysePot[PyrolyseTech,t]))..
      vSubsidy_Pyrolyse[t] =E= -sum(PyrolyseTech$(d1PyrolysePot[PyrolyseTech,t]), - vPyrolyse_cost[PyrolyseTech,t]);


  $ENDBLOCK


  $MODEL M_pyrolyse
    B_pyrolyse
  ;

$ENDIF


  # ======================================================================================================================
# Exogenous variables and data assignment
# ======================================================================================================================
$IF %stage% == "exogenous_values":

  #Setting parameters

  switch_Pyrolyse_forward_looking = 0;
  switch_Pyrolyse_sluggish        = 0;
  switch_Pyrolyse_frontloading    = 1;
  uT_Pyrolyse[t]                  = 0;
  uBetaPyrolyse                   = 0.5;
  rhoPyrolyse[PyrolyseTech]       = 0.8;
  T_Pyrolyse                      = 2; 
  shPyrolysePrice_type[PyrolyseTech,'Capital',t]$(tx0[t]) = 1; #0.513;
  shPyrolysePrice_type[PyrolyseTech,'Biomass',t]$(tx0[t]) = 1- shPyrolysePrice_type[PyrolyseTech,'Capital',t];
  pK_pyrolyse[t]                    = 0.07;

  d1PyrolysePot[PyrolyseTech,t]   = no;



  $MODEL M_pyrolyse_partial
    B_pyrolyse
  ;


$ENDIF



$IF %stage% == "static_calibration":

  $GROUP G_pyrolyse_static_calibration
    G_pyrolyse_endo
    -qK_Pyrolyse_demand
  ;

  $GROUP G_pyrolyse_static_calibration_exo
    G_Pyrolyse_exo
    qK_Pyrolyse_demand
  ;

  $MODEL M_pyrolyse_static_calibration
    M_pyrolyse
    -E_qK_pyrolyse_demand
    -E_qK_Pyrolyse_demand_terminal
  ;

$ENDIF



$IF %stage% == "dynamic_calibration":

  $GROUP G_pyrolyse_calib
    G_pyrolyse_endo
  ;

  $GROUP G_pyrolyse_calib_exo 
    G_pyrolyse_exo
  ;

  $MODEL M_pyrolyse_calib 
    M_pyrolyse
  ;

$ENDIF
