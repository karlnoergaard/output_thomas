# =====================================================================================================================
# Aggregates
# =====================================================================================================================
# This module calculates objects with ties to many other modules including market equilibrium conditions.


# =====================================================================================================================
# Variable definition
# =====================================================================================================================
$IF %stage% == "variables":
  $GROUP G_aggregates_prices
    pY[s_,t]$(tx0[t] and stot[s_])                                     "Domestic price level of final goods, aggregate of energy- and non-energy goods"
    pM[s_,t]$(tx0[t] and stot[s_])                                     "Import price level, aggregate of non-energy and energy-goods"
    pGDP[t]$(tx0[t])                                                 "Paasche chain price index of GDP (BNP-deflatoren)"
    pM_CET[out,s,t]$(d1vM_CET[out,s,t])                     "Import-price, of non-energy goods"
    pX[x_,t]$(tx0[t] and xtot[x_])                                     "Export-price, aggregate export price of non-energy and energy-goods"
    pX_s[s,t]$(tx0[t] and d1X_s[s,t])                                  "Export price, aggregate export price of non-energy and energy-goods, split by supplying sector"
    rForeignWealth[t]$(tx0[t] and tx1[t])                              "Avg. rate of return on net wealth in foreign countries"
  ;

  $GROUP G_aggregates_quantities
    qY[s_,t]$(stot[s_])                                     "Laspeyres chain index of total production"
    qM[s_,t]$(stot[s_])                                     "Laspeyres chain index of total imports"
    qX[x_,t]$(xtot[x_])                                     "Laspeyres chain index of total exports"
    qGDP[t]                                                 "Laspeyres chain index of GDP (BNP)"
    qY_CET[out,s,t]$(d1vY_CET[out,s,t])                     "Domestic production of various products and services - the set 'out' contains all out puts of the economy"
    qM_CET[out,s,t]$(d1vM_CET[out,s,t])                     "Import of various producets (out)"
    qX_s[s,t]$(d1X_s[s,t])                                  "Aggregate of total exports, split by supplying sector"
  ;

  $GROUP G_aggregates_values
    vGDP[t]$(tx0[t])                                                 "Aggregate nominal value of GDP in kr. bn (BNP)"
    vY[s_,t]$(tx0[t] and stot[s_])                                     "Value of aggregate production by sector"
    vM[s_,t]$(tx0[t] and stot[s_])                                     "Value of imports, split by sector"
    vX[x_,t]$(tx0[t] and xtot[x_])                                     "Value of exports, split by export component"
    vNFE[t]$(tx0[t])                                        "Nettofordringserhvervelsen" 
    vForeignWealth[t]$(tx0[t])                              "Net wealth in foreign countries (Udenlandske aktiver)" 
    vBoP[t]$(tx0[t])                                        "Balance of Payments (Betalingsbalancen)"    
  ;

#    $GROUP G_aggregates_other
#    ;

  
  $ENDIF 

  $IF %stage% == "groupcompilation":


  $GROUP G_aggregates_endo 
    G_aggregates_prices
    -pM_CET                  
    -pX_s$(d1X_s[s,t+1] and not d1X_s[s,t])
    qY[s_,t]$(tx0[t] and stot[s_])                                     "Laspeyres chain index of total production"
    qM[s_,t]$(tx0[t] and stot[s_])                                     "Laspeyres chain index of total imports"
    qX[x_,t]$(tx0[t] and xtot[x_])                                     "Laspeyres chain index of total exports"
    qGDP[t]$(tx0[t])                                                 "Laspeyres chain index of GDP (BNP)"
    qY_CET[out,s,t]$(d1vY_CET[out,s,t] and (sameas[out,'out_other'] or sameas[out,'WholeAndRetailSaleMarginE']))                     "Domestic production of various products and services - the set 'out' contains all out puts of the economy"
    qM_CET[out,s,t]$(d1vM_CET[out,s,t] and (sameas[out,'out_other'] or sameas[out,'WholeAndRetailSaleMarginE']))                     "Import of various producets (out)"
    qX_s[s,t]$(tx0[t] and d1X_s[s,t])                                  "Aggregate of total exports, split by supplying sector"


    G_aggregates_values
        
  ;

  $GROUP G_aggregates_endo G_aggregates_endo$(tx0[t]);
  

  $GROUP G_aggregates_exo
#      G_aggregates_other

    # E_qY_CET_other 
    qC_y$(tx0[t] and d1C_y[c,s,t])
    qI_y$(tx0[t] and d1I_y[i,s,t])
    qRxE_y$(tx0[t] and d1RxE_y[r,s,t])
    qG_y$(tx0[t] and d1G_y[g,s,t])
    qX_y$(tx0[t] and d1X_y[x,s,t])
    qFin_y$(tx0[t] and d1Fin_y[r,t])

    # E_qY_CET_WholeAndRetailSaleMarginE
    #  qREgj$(tx0[t])
    #  qCE$(tx0[t])
    qREgj$(tx0[t] and d1EAV_RE[purpose,energy19,r,t])
    qREgj$(tx0[t] and d1DAV_RE[purpose,energy19,r,t])

    qCE$(tx0[t] and d1EAV_CE[purpose,energy19,t])
    qCE$(tx0[t] and d1DAV_CE[purpose,energy19,t])


    # E_qM_CET_other
    qC_m$(tx0[t] and d1C_m[c,s,t])
    qI_m$(tx0[t] and d1I_m[i,s,t])
    qRxE_m$(tx0[t] and d1RxE_m[r,s,t])
    qG_m$(tx0[t] and d1G_m[g,s,t])
    qX_m$(tx0[t] and d1X_m[x,s,t])
    qFin_m$(tx0[t] and d1Fin_m[r,t])  

    # E_vM_tot 
    pM_CET$((tx0[t] or t0[t]) and d1vM_CET[out,s,t])
    qM_CET$(tx0[t] and d1vM_CET[out,s,t] and energy19[out])


    # E_qM_tot 
    pM$(stot[s_] and t0[t])
    pMNatgasNL$((tx0[t] or t0[t]) and t.val <=2019)
    qMNatgasNL$(tx0[t] and t.val <=2019)

    # E_pM_tot 

    # E_vY_tot 
    # E_vY_tot 
    vY$(s[s_] and tx0[t])

    # E_qY_tot
    pY$(((t0[t] or tx0E[t]) and s[s_]) or (t0[t] and stot[s_]))
    qY$(tx0[t] and s[s_])

    # E_vX_tot 
    vX_y$(tx0[t] and d1X_y[x,s,t] and sameas[x,'xOth'])
    vX_m$(tx0[t] and d1X_m[x,s,t] and sameas[x,'xOth'])
    pXE$((t0[t] or tx0[t]) and d1vXE[purpose,energy19,t])
    qXE$(tx0[t] and d1vXE[purpose,energy19,t])
    vX$(tx0[t] and sameas[x_,'xTur'])
    pXE_ELNl$((t0[t] or tx0[t]) and t.val <=2019)
    qXE_ElNl$(tx0[t] and t.val <=2019)

    # E_qX_tot 
    pX$(xtot[x_] and t0[t]) 
#      pX_y$(txE[t] and d1X_y[x,s,t-1] and sameas[x,'xOth'])                                                         

    pX_y$((t0[t] or tx0[t]) and d1x_s[s,t+1] and d1x_y['xOth',s,t] and d1x_y['xOth',s,t+1] and sameas[x,'xOth'])     # E_qX_s  
    pX_y$(tx0[t] and d1x_s[s,t] and d1x_y['xOth',s,t] and sameas[x,'xOth']) # E_pX_s                              

    pX_m$((t0[t] or tx0[t]) and d1x_m[x,s,t] and d1x_m[x,s,t+1] and sameas[x,'xOth'])  

    pX$((t0[t] or tx0E[t]) and sameas[x_,'xTur']) 
    qX$(tx0[t] and sameas[x_,'xTur'])

#      pY_CET$(tx0[t] and energy19[out] and d1vY_CET[out,s,t])                             
#      pY_CET$(tx0[t] and energy19[out] and d1vY_CET[out,s,t] and d1vM_CET[out,s,t])       

    # E_pX_tot

    # E_qX_s 
    pX_s$(t0[t] and d1X_s[s,t+1])
    pXE_bionatgas$(t0[t])


    # E_qGDP 
    pGDP$(t0[t])
    pC$((t0[t] or tx0E[t]) and ctot[c_])
    qC$(tx0[t] and ctot[c_])
    pG$((t0[t] or tx0E[t]) and gtot[g_])
    qG$(tx0[t] and gtot[g_])
    pI_r$((t0[t] or tx0E[t]) and itot[I_])
    qI$(tx0[t] and itot[I_])

    # E_pGDP

    # E_vGDP 
    vC$(tx0[t] and ctot[c_])
    vI$(tx0[t] and itot[i_])
    vG$(tx0[t] and gtot[g_])

    # E_vNFE 
    vtEU$(tx0[t])
    vtCO2_ETS_sales$(tx0[t])
    vtCO2_ETS$(tx0[t] and d1CO2_ETS[r,t])
    vtCO2_ETS2$(tx0[t] and d1CO2_ETS2[r,t])
    vtCO2_CE_ETS2$(tx0[t] and d1CO2_CE_ETS2[purpose,energy19,t])
    sDomesticEquity$(tx1[t])
    vWealth$(tx0[t])
    sForeignEquity$(tx1[t])
    rInvestor$(tx1[t])
    rBonds$(tx1[t] and sameas[s,'71000'])
    vEquity$(tx0[t] and s[s_] and not sameas[s_,'OFF'])
    vGovReceiveF$(tx0[t])
    vGov2Foreign$(tx0[t])
    rForeignWealth$(t1[t])
    
    # E_rForeignWealth 
    vFirmDebt$(tx0[t])
    vGovNetWealth$(tx0[t])
    vInterestGovAssets$(tx1[t])
    vInterestGovDebt$(tx1[t])

    # E_vBoP
    vGovReval$(tx0[t])
    vForeignWealth$(t0[t])
    JvWealth$((tx0[t] or t2[t]) and not t1[t])  # The t2 condition is added to ensure squareness during calibration
    JvWealth$(tx0[t])   

    #  qREa$(tx0[t] and d1pREa[purpose,energy19a,s,t])

    #  # E_qEtot
    #  qCE$(tx0[t] and d1vCE[purpose,energy19,t])
    #  qLE$(tx0[t] and d1vLE[purpose,energy19,t])
    #  qTL$(tx0[t] and d1TL[purpose,energy19,t])

    #  # E_vDistributionProfits
    #  pRE_base[purpose,energy19,r,t]$(tx0[t] and d1pRE_base[purpose,energy19,r,t])
    #  pCE_base[purpose,energy19,t]$(tx0[t] and d1vCE[purpose,energy19,t])
    #  pLE_base[purpose,energy19,t]$(tx0[t] and d1vLE[purpose,energy19,t])
    #  pXE_base[purpose,energy19,t]$(tx0[t] and d1vXE[purpose,energy19,t])

    #  qY_CET$(tx0[t] and d1vY_CET[out,s,t] and (sameas[out,'Natural gas (Extraction)'] or sameas[out,'Crude oil']))
    #  #  qY_CET$(tx0[t] and d1vY_CET[out,s,t] and energy19[out] and not sameas[out,'refinery gas'] and sameas[s,'19000'])  # Refinery productions is exogenous as a default. In shocks the sector is subject to special modelling   
    #  qY_CET$(d1vY_CET[out,s,t] and energy19[out] and (sameas[out,'Gasoline for transport'] or sameas[out,'Diesel for transport'] or sameas[out,'Jet petroleum'] or sameas[out,'Oil products'] or sameas[out,'Biodiesel']) and sameas[s,'19000'])  # Refinery productions is exogenous as a default. In shocks the sector is subject to special modelling   

    qRxEEOP_ani$(sum(Emmtype, sum(animals,d1vEOPCostAni[Emmtype,ani_sectors,s,animals,t])))
    qRxEEOP_plant$(sum(Emmtype,d1vEOPCostplant[Emmtype,plant_sectors,s,t]))


#      pXE$(d1vXE[purpose,energy19,t+1] and not d1vXE[purpose,energy19,t]) # For chain-indices in aggregates we exogenize last years prices when they are not determined  

    qI_s_afforestation$(tx0[t])   ""
    qI_s_afforestation_inst$(tx0[t])  ""

    pXE_bionatgas$(tx0[t])  ""
    qXE_bionatgas$(tx0[t])  ""

    # pyrolyse
    qBiomass_Pyrolyse[t]$(tx0[t] and sum(PyrolyseTech, d1PyrolysePot[PyrolyseTech,t])) ""
    pY_CET_baseline[out,s,t]$((t0[t] or tx0[t]) and sameas[out,'Straw for energy purposes'] and sameas[s,'01011'] and sum(PyrolyseTech, d1PyrolysePot[PyrolyseTech,t])) "" 

  ;
           
 $GROUP G_aggregates_data 
  G_aggregates_prices, -rForeignWealth
  G_aggregates_quantities,-pX_s,-qX_s
  G_aggregates_values, -vNFE, -vForeignWealth, -vBoP 
 ;
$ENDIF


# =====================================================================================================================
# Equations
# =====================================================================================================================
$IF %stage% == "equations":
  $BLOCK B_aggregates

   # Domestic supply set equal to domestic demand
    E_qY_CET_other[s,t]$(tx0[t] and d1vY_CET['out_other',s,t])..
      qY_CET['out_other',s,t] =E= sum(c$d1C_y[c,s,t], qC_y[c,s,t])
                                + sum(i$d1I_y[i,s,t], qI_y[i,s,t])
                                + sum(r$d1RxE_y[r,s,t], qRxE_y[r,s,t])
                                + sum(g$d1G_y[g,s,t], qG_y[g,s,t]) 
                                + sum(x$d1X_y[x,s,t], qX_y[x,s,t])
                                + sum(r$(d1Fin_y[r,t] and sameas[s,'64000']), qFin_y[r,t])
                                    + sum(ani_sectors$(sum((Emmtype,animals),d1vEOPCostAni[Emmtype,ani_sectors,s,animals,t])), qRxEEOP_ani[ani_sectors,s,t])
                                    + sum(plant_sectors$(sum(Emmtype,d1vEOPCostplant[Emmtype,plant_sectors,s,t])), qRxEEOP_plant[plant_sectors,s,t])
                                    + qI_s_afforestation[t]$(sameas[s,'02000'])
                                    + qI_s_afforestation_inst[t]$(sameas[s,'02000'])
                                ;


    E_qY_CET_WholeAndRetailSaleMarginE[s,t]$(tx0[t] and d1vY_CET['WholeAndRetailSaleMarginE',s,t])..
        qY_CET['WholeAndRetailSaleMarginE',s,t] =E=  
                                                  + sum((purpose,energy19,r)$(d1EAV_RE[purpose,energy19,r,t]), qREgj[purpose,energy19,r,t])$(sameas[s,'46000'])
                                                  + sum((purpose,energy19)$(d1EAV_CE[purpose,energy19,t]), qCE[purpose,energy19,t])$(sameas[s,'46000'])
                                                  + sum((purpose,energy19,r)$(d1DAV_RE[purpose,energy19,r,t]), qREgj[purpose,energy19,r,t])$(sameas[s,'47000'])
                                                  + sum((purpose,energy19)$(d1DAV_CE[purpose,energy19,t]), qCE[purpose,energy19,t])$(sameas[s,'47000'])
                                                  + sum((purpose,energy19,r)$(d1CAV_RE[purpose,energy19,r,t]), qREgj[purpose,energy19,r,t])$(sameas[s,'45000'])
                                                  + sum((purpose,energy19)$(d1CAV_CE[purpose,energy19,t]), qCE[purpose,energy19,t])$(sameas[s,'45000'])
                                                  ;

   # Imports set equal to domestic demand for imported non-energy goods and services
    E_qM_CET_other[s,t]$(tx0[t] and d1vM_CET['out_other',s,t]).. 
      qM_CET['out_other',s,t] =E=      sum(c$d1C_m[c,s,t], qC_m[c,s,t])
                                     + sum(i$d1I_m[i,s,t], qI_m[i,s,t]) 
                                     + sum(r$d1RxE_m[r,s,t], qRxE_m[r,s,t])
                                     + sum(g$d1G_m[g,s,t], qG_m[g,s,t]) 
                                     + sum(x$d1X_m[x,s,t], qX_m[x,s,t])
                                     + sum(r$(d1Fin_m[r,t] and sameas[s,'64000']), qFin_m[r,t])
                                     ;               

    E_vM_tot[t]$(tx0[t])..   vM['tot',t] =E= sum((out,s)$d1vM_CET[out,s,t], pM_CET[out,s,t] * qM_CET[out,s,t]) 
                                            + (pMNatgasNL[t] * qMNatgasNL[t])$(t.val <= 2019) # Ørsted
                                            + (qBiomass_Pyrolyse[t]$(sum(PyrolyseTech, d1PyrolysePot[PyrolyseTech,t])) * pY_CET_baseline['Straw for energy purposes','01011',t]) # biomass use
                                            ;                                            ; 

    E_qM_tot[t]$(tx0[t])..   qM['tot',t]*pM['tot',t-1] =E= sum((out,s)$d1vM_CET[out,s,t], pM_CET[out,s,t-1] * qM_CET[out,s,t]) 
                                            + (pMNatgasNL[t-1]*qMNatgasNL[t])$(t.val <= 2019) # Ørsted
                                            + qBiomass_Pyrolyse[t]$(sum(PyrolyseTech, d1PyrolysePot[PyrolyseTech,t])) * pY_CET_baseline['Straw for energy purposes','01011',t-1] # biomass use
                                            ;


    E_pM_tot[t]$(tx0[t])..   pM['tot',t] * qM['tot',t]   =E= vM['tot',t];


    E_vY_tot[t]$(tx0[t])..  vY['tot',t]                =E= sum(s, vY[s,t]); 
  
    # Laspeyres chain index of total production
    E_qY_tot[t]$(tx0[t]).. qY['tot',t] * pY['tot',t-1] =E= sum(s, pY[s,t-1]*qY[s,t]);
  
    # Paasche chain price index of total production
    E_pY_tot[t]$(tx0[t]).. pY['tot',t] * qY['tot',t]   =E= vY['tot',t];

    # Exports 
    E_vX_tot[t]$(tx0[t]).. vX['xtot',t] =E= sum(s$(d1X_y['xoth',s,t]), vX_y['xoth',s,t]) + sum(s$(d1X_m['xoth',s,t]), vX_m['xoth',s,t]) 
                                           +sum((purpose,energy19)$d1vXE[purpose,energy19,t], pXE[purpose,energy19,t] * qXE[purpose,energy19,t])
                                           +vX['xTur',t]
                                           + (pXE_ElNl[t]*qXE_ElNl[t])$(t.val <= 2019) # Ørsted 
                                           + pXE_bionatgas[t] * qXE_bionatgas[t]
                                           ;


    E_qX_tot[t]$(tx0[t]).. qX['xtot',t]*pX['xtot',t-1] =E= sum(s$(d1X_y['xoth',s,t]), pX_y['xoth',s,t-1]$(d1X_y['xoth',s,t-1]) * qX_y['xoth',s,t])
                                           +sum(s$(d1X_m['xoth',s,t]), pX_m['xoth',s,t-1]$(d1X_m['xoth',s,t-1]) * qX_m['xoth',s,t])
                                           +sum((purpose,energy19)$(d1vXE[purpose,energy19,t] and d1vXE[purpose,energy19,t-1]), pXE[purpose,energy19,t-1] * qXE[purpose,energy19,t])
                                           +pX['xTur',t-1]*qX['xTur',t]
                                           +(pXE_ElNl[t-1]*qXE_ElNl[t])$(t.val <=2019) # Ørsted
                                           +pXE_bionatgas[t-1] * qXE_bionatgas[t]
                                           ;

    E_pX_tot[t]$(tx0[t]).. pX['xtot',t]*qX['xtot',t] =E= vX['xtot',t];     


    E_qX_s[s,t]$(tx0[t] and d1x_s[s,t]).. 
      pX_s[s,t-1]*qX_s[s,t] =E= (pX_y['xOth',s,t-1]*qX_y['xOth',s,t])$(d1x_y['xOth',s,t] and d1x_y['xOth',s,t-1]) + (pX_s[s,t-1]*qX_y['xOth',s,t])$(d1x_y['xOth',s,t] and not d1x_y['xOth',s,t-1])
                                + sum(energy19$(d1vXE['unspecified',energy19,t] and d1Xe_y[energy19,s,t]), pXE['unspecified',energy19,t-1] *qXE['unspecified',energy19,t] *qY[s,t]/sum(ss$d1Xe_y[energy19,ss,t], qY[ss,t]))
                                + (pXE_ElNl[t-1]*qXE_ElNl[t])$(sameas[s,'35011'] and t.val <=2019) # Ørsted
                                + (pXE_bionatgas[t-1] * qXE_bionatgas[t])$(sameas[s,'35002'])
                                ;

    E_pX_s[s,t]$(tx0[t] and d1x_s[s,t]).. 
      pX_s[s,t] * qX_s[s,t] =E= pX_y['xOth',s,t]*qX_y['xOth',s,t]$(d1x_y['xOth',s,t]) 
                                + sum(energy19$(d1vXE['unspecified',energy19,t] and d1Xe_y[energy19,s,t]), pXE['unspecified',energy19,t]*qXE['unspecified',energy19,t] *qY[s,t]/sum(ss$d1Xe_y[energy19,ss,t], qY[ss,t]))
                                + (pXE_ElNl[t]*qXE_ElNl[t])$(sameas[s,'35011'] and t.val <=2019)  # Ørsted       
                                + (pXE_bionatgas[t] * qXE_bionatgas[t])$(sameas[s,'35002']) 
                                ;

    # Laspeyres chain index of Gross Domestic Product (BNP)
    E_qGDP[t]$(tx0[t])..
      qGDP[t] * pGDP[t-1] =E= ( pC['ctot',t-1] * qC['ctot',t]
                              + pG['Gtot',t-1] * qG['Gtot',t]
                              + pI_r['Itot',t-1] * qI['Itot',t]
                              + pX['xtot',t-1] * qX['xtot',t]
                              - pM['tot',t-1] * qM['tot',t] );


    # Paasche chain price index of GDP
    E_pGDP[t]$(tx0[t]).. pGDP[t] * qGDP[t]  =E= vGDP[t];

    E_vGDP[t]$(tx0[t])..   vGDP[t]     =E= vC['ctot',t] 
                                         + vI['Itot',t] 
                                         + vG['Gtot',t] 
                                         + vX['xTot',t]
                                         - vM['tot',t] ;


    #=====================================================================================================================================#
    # Circular flow of income (Indkomstkredsløb)
    #=====================================================================================================================================#

    # Danish households wealth abroad
    E_vForeignWealth[t]$(tx0[t]).. vForeignWealth[t] =E= vWealth[t] + vGovNetWealth[t] - sum(sp, vFirmDebt[sp,t]+vEquity[sp,t]);

    E_rForeignWealth[t]$(tx1[t])..  rForeignWealth[t]*vForeignWealth[t-1]/fv =E=
                                # Households return on foreign bonds
                                rBonds['71000',t] * (1-sDomesticEquity[t]-sForeignEquity[t])*vWealth[t-1]/fv
                                # Firms interest payments abroad
                              - rBonds['71000',t] * sum(sp,vFirmDebt[sp,t-1])/fv  
                                # Households return on foreign stocks
                              + sum(sp,rInvestor[sp,t]*vEquity[sp,t])/sum(sp,vEquity[sp,t]) *  sForeignEquity[t]*vWealth[t-1]/fv
                                # The governments returns on investments (all the states assets are abroad)
                              + vInterestGovAssets[t]
                                # Foreign retuns on government debt (all the governments debt is abroad)
                              - vInterestGovDebt[t]
                                # Foreign returns on domestic stocks (Stocks not owned domestically are owned abroad (housing plus share af vWealth))
                              - (sum(sp,rInvestor[sp,t]*vEquity[sp,t])/sum(sp,vEquity[sp,t]) * (sum(sp,vEquity[sp,t-1])/fv - sDomesticEquity[t]*vWealth[t-1]/fv) - rInvestor['68203',t]*vEquity['68203',t])
                              ;  

    E_vNFE[t]$(tx0[t])..       vNFE[t] =E= vX['xTot',t] - vM['tot',t] # The trade balance
                                # Toll, etc. to the EU
                                - vtEU[t]
                                # ETS-quotas
                                + vtCO2_ETS_sales[t] - sum(s$(d1CO2_ETS[s,t]), vtCO2_ETS[s,t]) - sum(s$d1CO2_ETS2[s,t], vtCO2_ETS2[s,t]) - sum((purpose,energy19)$(d1CO2_CE_ETS2[purpose,energy19,t]), vtCO2_CE_ETS2[purpose,energy19,t])
                                # Returns from abroad - foreigners returns in DK
                                + rForeignWealth[t]*vForeignWealth[t-1]/fv
                                # The governments transfers with abroud
                                + vGovReceiveF[t] - vGov2Foreign[t]
                                ;

    E_vBoP[t]$(tx0[t])..       vBoP[t] =E= vNFE[t] - (vForeignWealth[t] - vForeignWealth[t-1]/fv) + vGovReval[t] + JvWealth[t];
                                           



  $ENDBLOCK

   
$MODEL M_aggregates B_aggregates;


$ENDIF


$IF %stage% == "exogenous_values":

  #1) DATA

  pGDP.l[t]  = IO_pGDP[t];
  qGDP.l[t]  = IO_qGDP[t];
  vGDP.l[t]  = IO_vGDP[t];
  pM.l[s_,t] = IO_pM[s_,t];
  qM.l[s_,t] = IO_qM[s_,t];   
  vM.l[s_,t] = IO_vM[s_,t];
  vY.l[s_,t] = IO_vY[s_,t];
  qY.l[s_,t] = IO_qY[s_,t]; 
  pY.l[s_,t] = IO_pY[s_,t]; 
  vX.l[x_,t] = IO_vX[x_,t];
  qX.l[x_,t] = IO_qX[x_,t];
  pX.l[x_,t] = IO_pX[x_,t];

  pY_CET.l[out,s,t]$(not energy19[out])      = IO_pY_CET[out,s,t]; 
  qY_CET.l[out,s,t]$(not energy19[out])      = IO_qY_CET[out,s,t];
  pM_CET.l[out,s,t]$(not energy19[out])      = IO_pM_CET[out,s,t]; 
  qM_CET.l[out,s,t]$(not energy19[out])      = IO_qM_CET[out,s,t]; 

  #4) INITIAL VALUES 
    pX_s.l[s,t] = 1; qX_s.l[s,t] = 1; # Initial values

  # 5) DUMMIES
  d1M[s_,t]                     = yes$(abs(vM.l[s_,t]) > min_cell_size); 

$ENDIF


# =====================================================================================================================
# Static calibration
# =====================================================================================================================
$IF %stage% == "static_calibration":



  $GROUP G_aggregates_static_calibration
    G_aggregates_endo
#      qY_CET$(sameas[out,'out_other'])
#      qM_CET$(sameas[out,'out_other'])
#      qY_CET$(d1vY_CET[out,s,t] and sameas[out,'WholeAndRetailSaleMarginE'])
  ;

  $GROUP G_aggregates_static_calibration_exo
    G_aggregates_exo
    -JvWealth$(t2[t])
    -pX_m$(tx0[t])
  ;

  $MODEL M_aggregates_static_calibration
    B_aggregates
  ;
  
$ENDIF

# =====================================================================================================================
# Dynamic calibration
# =====================================================================================================================
$IF %stage% == "dynamic_calibration":


  $GROUP G_aggregates_calib    
    G_aggregates_endo
  ;

  $GROUP G_aggregates_calib_exo    
    G_aggregates_exo
  ;

  $MODEL M_aggregates_calib 
    B_aggregates
  ;



$ENDIF