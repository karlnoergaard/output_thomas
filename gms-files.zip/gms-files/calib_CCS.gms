#IMPORTANT: We re-introduce J-term in calibration of total emissions 
    PARAMETER endcalib_jEmmTot_UNFCCC_LULUCF_Calib2KF[t];
    endcalib_jEmmTot_UNFCCC_LULUCF_Calib2KF[t] = jEmmTot_UNFCCC_LULUCF_Calib2KF.l[t];

    $FUNCTION test_emm_unfccc_lulucf_aftercalibID_and_CCS({tolerance_ktCO2e}):
        loop(t$(t.val>=2025 and t.val<=tBF_calib_end.val),

            ABORT$(abs(jEmmTot_UNFCCC_LULUCF_Calib2KF.l[t] - endcalib_jEmmTot_UNFCCC_LULUCF_Calib2KF[t]) > {tolerance_ktCO2e}) 'Total emissions have changed more than tolerance of {tolerance_ktCO2e} after calibrating abatement';
        );
    $ENDFUNCTION 

    $GROUP G_endo
        G_endo 
        jEmmTot_UNFCCC_LULUCF_Calib2KF, -qEmmtot[t,'CO2e','UNFCCC_Lulucf']
    ;

    $GROUP G_exo 
        G_exo 
        -jEmmTot_UNFCCC_LULUCF_Calib2KF, qEmmtot[t,'CO2e','UNFCCC_Lulucf']
    ;


#
singleton set tMAC_start[t] /2025/;
singleton set tMAC_end[t] /2035/;
set tMAC[t] /2025*2035/;


$IF '%EA_data%'=='yes':
    # ======================================================================================================================
    # Trækker CCS ud af grundforløbet
    # ======================================================================================================================

    #Introducing CCS explicitly in the model we now remove it from the non-modelled emissions variable
    qEmmFromCRFnotinModel.l[t,emm_eq,accounts] = qEmmFromCRFnotinModel.l[t,emm_eq,accounts] - KF_emm_[emm_eq,"Carbon capture & storage",t]*1000;

    # $FIX G_exo;
    # $UNFIX G_endo;
    # @SOLVE(M_zeroshock);

    # execute_unloaddi 'Output\Pre_Calib_CCS_GR_excl_CCS.gdx';



    # ======================================================================================================================
    # INITIALIZATION 
    # ======================================================================================================================

    #Now we move start year to 2023 
    $SETGLOBAL start_shock_year 2022 #Year where we start the shock 
    set_time_periods(%start_shock_year%,%terminal_year%);

    switch_forward_looking = 0;
    switch_sluggish = 1;

    # ----------------------------------------------------------------------------------------------------------------------
    # CCS in EA Energianalyse (DORS)
    # ----------------------------------------------------------------------------------------------------------------------

    $import calib_CCS_EA.gms

    # ----------------------------------------------------------------------------------------------------------------------
    # CCS in Model 2 from Ekspertgruppen for en Gr�n Skattereform, delrapport 1
    # ----------------------------------------------------------------------------------------------------------------------

    #  $import calib_abatement_CCS_GSR.gms


    # ======================================================================================================================
    # Solving the model with abatement technologies
    # ======================================================================================================================

# $BLOCK B_rCCS_log_normal
#   # Instantanous technology adoption rate (without forward-looking or sluggsihness)
#   E_rCCS_lognormal[techCCS,s,purpose,t]$(tCCS[t] and sum((energy19,emm), d1thetaCCS[techCCS,purpose,energy19,s,t,emm]))..
#     rCCS[techCCS,s,purpose,t] =E= switch_abatement * switch_CCS[techCCS] * (
#                                     @cdfLogNorm(rCCS_gains[techCCS,s,purpose,t]+0.0001,rCCS_costs[techCCS,s,purpose,t],sigmaCCS[techCCS])
#                                     + j_rCCS[techCCS,s,purpose,t]);

#   E_qLEVC_CCS_EmmE_RE_alt[purpose,energy19a,s,t,emm]$(tx0[t] and sum(energy19, d1qREE[purpose,energy19a,energy19,s,t] and sum(techCCS, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])) and (sameas[emm,'CO2ubio'] or sameas[emm,'CO2bio']))..
#     qLEVC_CCS_EmmE_RE[purpose,energy19a,s,t,emm] =E= 
#         sum((techCCS,energy19)$(d1qREE[purpose,energy19a,energy19,s,t] and d1EmmProdE[s,t,emm,purpose,energy19] and d1thetaCCS[techCCS,purpose,energy19,s,t,emm] and (sameas[emm,'CO2ubio'] or sameas[emm,'CO2bio'])), 
#             thetaCCS[techCCS,purpose,energy19,s,t,emm] * qGrossEmmE_REE[purpose,energy19a,energy19,s,t,emm]*growth_factor[t]
#           * CCSPrice[techCCS,s,t]
#           * @cdfLogNorm(rCCS_gains[techCCS,s,purpose,t]+0.0001,rCCS_costs[techCCS,s,purpose,t],sigmaCCS[techCCS])
#         #   * (rCCS_actual[techCCS,purpose,energy19,s,t,emm]*rCCS[techCCS,s,purpose,t])
#           * 10**(3)*10**(-9)); 

  # Total LEVC on non-energy related CCS
#   E_qLEVC_CCS_EmmxE_alt[s,t,emm]$(tx0[t] and d1EmmProdxE[s,t,emm] and sum(techCCS, d1thetaCCSxE[techCCS,s,t,emm]) and sameas[emm,'CO2ubio'])..
#     qLEVC_CCS_EmmxE[s,t,emm] =E= sum(techCCS$(d1thetaCCSxE[techCCS,s,t,emm]), 
#                                     thetaCCSxE[techCCS,s,t,emm]*qGrossEmmxE[s,t,emm]*growth_factor[t]
#                                   * CCSPrice[techCCS,s,t] 
#                                   * rCCSxE_actual[techCCS,s,t,emm]
#                                   * 10**(3)*10**(-9)); 


# $ENDBLOCK

    sigmaCCS.l[techCCS]$(sum((purpose,energy19,s,t,emm), d1thetaCCS[techCCS,purpose,energy19,s,t,emm])) = 0.02;

    # Partial model to determine initial values for ID-gains and ID-costs (the partial model below does not run, if gains and costs don't have initial values)
    $MODEL M_CCS_gains_costs
        E_rCCS_gains
        E_rCCS_costs
    ;
    $GROUP G_CCS_gains_costs_endo
        rCCS_gains[techCCS,s,purpose,t]$(tCCS[t] and sum(energy19, sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])) and sum(energy19, sum(emm, d1EmmProdE[s,t,emm,purpose,energy19])))                                          "Gevinst pr. enhed CCS (kr. pr. ton)"
        rCCS_costs[techCCS,s,purpose,t]$(tCCS[t] and sum(energy19, sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])))         "Cost of CCS (DKK per tCO2)"
    ;

# ----------------------------------------------------------------------------------------------------------------------
# Running the partial abatement model
# ----------------------------------------------------------------------------------------------------------------------

    $import energy_price_partial.gms

    $MODEL M_abatement_partial
        M_Energy_price_partial
        M_abatement
        # E_rCCS_lognormal, -E_rCCS
        # E_qLEVC_CCS_EmmE_RE_alt, -E_qLEVC_CCS_EmmE_RE
    ;

    $GROUP G_abatement_partial_endo
        G_Energy_price_endo
        G_abatement_endo
    ;

    $GROUP G_abatement_partial_exo
        G_Energy_price_exo
        G_abatement_exo
    ;

    # $FIX G_abatement_partial_exo;
    # $UNFIX G_CCS_gains_costs_endo;
    # @SOLVE(M_CCS_gains_costs);


    rCCS_gains.l[techCCS,s,purpose,t]$(tCCS[t] and sum((energy19,emm), d1thetaCCS[techCCS,purpose,energy19,s,t,emm]) and sum((energy19,emm), d1EmmProdE[s,t,emm,purpose,energy19]))
        = 1;

    rCCS_costs.l[techCCS,s,purpose,t]$(tCCS[t] and sum((energy19,emm), d1thetaCCS[techCCS,purpose,energy19,s,t,emm]))
        = 1;

    $FIX G_abatement_partial_exo;
    $UNFIX G_abatement_partial_endo;
    execute_unloaddi 'Output\Pre_Calib_CCS.gdx';
    @SOLVE(M_abatement_partial);

    execute_unloaddi 'Output\Abatement_partial.gdx';

    # ======================================================================================================================
    # Construct MAC curves 
    # ======================================================================================================================

    # Initializing the MAC curves for CCS technologies
    qGrossEmmE.l[s,t,emm,purpose,energy19]  = qEmmProdE.l[s,t,emm,purpose,energy19];
    qGrossEmmxE.l[s,t,emm]                  = qEmmProdxE.l[s,t,emm];

    $import Report_and_steps\report_EV.gms
    $import Report_and_steps\report_Tech_MAC.gms

$ENDIF 

# ----------------------------------------------------------------------------------------------------------------------
# Running the full model
# ----------------------------------------------------------------------------------------------------------------------

$MODEL M_calib_abatement
    M_zeroshock
    -E_tRE_market # Vi hiver denne ud, da tvRE er en dead-end variabel
    # E_rCCS_lognormal, -E_rCCS
    # E_qLEVC_CCS_EmmE_RE_alt, -E_qLEVC_CCS_EmmE_RE
;
  
$GROUP G_endo
    G_endo
    -tvRE$(tx0[t] and d1tRE[purpose,energy19,r,t] and d1pRE_base[purpose,energy19,r,t]) # Vi hiver denne ud, da tvRE er en dead-end variabel
;
  
$GROUP G_exo
    G_exo
;

#Now we move start year to 2023 
$SETGLOBAL start_shock_year 2022 #Year where we start the shock
set_time_periods(%start_shock_year%,%terminal_year%);

## We first solve the model with exogenous CCS
d1switchCCS = 0;

$FIX G_exo;
$UNFIX G_endo;
# execute_unloaddi 'Output\Pre_Calib_CCS.gdx';
@SOLVE(M_calib_abatement);

## Solving the model with endogenous CCS
d1switchCCS = 1;

$FIX G_exo;
$UNFIX G_endo;
@SOLVE(M_calib_abatement);


PARAMETER
    qEmmCCStot[t]
;

qEmmCCStot[t] = sum(s, sumqEmmCCSbio.l[s,t] + sumqEmmCCSubio.l[s,t]);

execute_unload 'Output\Calib_CCS.gdx';
@test_emm_unfccc_lulucf_aftercalibID_and_CCS(10);
@check_vBoP();