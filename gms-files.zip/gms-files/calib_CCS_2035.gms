# ======================================================================================================================
# Trækker CCS ud af grundforløbet
# ======================================================================================================================

#Introducing CCS explicitly in the model we now remove it from the non-modelled emissions variable
qEmmFromCRFnotinModel.l[t,emm_eq,accounts] = qEmmFromCRFnotinModel.l[t,emm_eq,accounts] - KF_emm_[emm_eq,"Carbon capture & storage",t]*1000;

$FIX G_exo;
$UNFIX G_endo;
@SOLVE(M_zeroshock);

execute_unloaddi 'Output\Pre_Calib_CCS_GR_excl_CCS.gdx';


# ======================================================================================================================
# INITIALIZATION 
# ======================================================================================================================

#Now we move start year to 2023 
#  $SETGLOBAL start_shock_year 2022 
#  set_time_periods(%start_shock_year%,%terminal_year%);

switch_forward_looking = 0;
switch_sluggish = 1;


# ----------------------------------------------------------------------------------------------------------------------
# CCS for 2035 analysis (KEFM)
# ----------------------------------------------------------------------------------------------------------------------

 #  $import calib_CCS_KEFM.gms

# ----------------------------------------------------------------------------------------------------------------------
# CCS in EA Energianalyse (DORS)
# ----------------------------------------------------------------------------------------------------------------------

#  $import calib_CCS_EA.gms
 
 
# ----------------------------------------------------------------------------------------------------------------------
# CCS in Model 2 from Ekspertgruppen for en Gr�n Skattereform, delrapport 1
# ----------------------------------------------------------------------------------------------------------------------

#  $import calib_abatement_CCS_GSR.gms


# ======================================================================================================================
# Construct MAC curves 
# ======================================================================================================================

PARAMETER 
    MAC_curve_CCS[techCCS,s,purpose,energy19,t,emm,*] 'Mac curve for CCS technologies'
 ;

MAC_curve_CCS[techCCS,s,purpose,energy19,t,emm,'Reduction potential, ktCO2e']$(d1thetaCCS[techCCS,purpose,energy19,s,t,emm]) 
    = thetaCCS.l[techCCS,purpose,energy19,s,t,emm]*qEmmProdE.l[s,t,emm,purpose,energy19];

MAC_curve_CCS[techCCS,s,purpose,energy19,t,emm,'cost_DKK_pr_tCO2']$(d1thetaCCS[techCCS,purpose,energy19,s,t,emm])
    = CCSPrice.l[techCCS,s,t];

# ======================================================================================================================
# Fremadskuethed 
# ======================================================================================================================
#  $BLOCK B_CCS_adoption
    
    #  # Input for calculating instantaneous adoption rate (assuming normally distributed costs)
    #  E_rCCS_input_alt[techCCS,s,purpose,t]$(tCCS[t] and sum((energy19,emm), d1thetaCCS[techCCS,purpose,energy19,s,t,emm])).. 
    #      rCCS_input_alt[techCCS,s,purpose,t] =E= sum(tt$(tt.val >= t.val and tt.val < t.val + T_CCS_adoption)
    #                                                  (rCCS_gains[techCCS,s,purpose,t] - rCCS_costs[techCCS,s,purpose,t] - uCCSt[techCCS,s,purpose,t])) 
    #          / sigmaCCS[techCCS];

#    E_qI_CCS_actual_terminal[sp,t]$(tx0[t] and (t.val>(tend.val-T_CCS)) and (sum((techCCS,purpose,energy19,ttt,emm), d1thetaCCS[techCCS,purpose,energy19,sp,ttt,emm]) or sum((techCCS,ttt,emm), d1thetaCCSxE[techCCS,sp,ttt,emm])))..
#      qI_CCS_actual['iM',sp,t] =E= (1-switch_CCS_frontloading)*qI_CCS_levelized['iM',sp,t]
#                                  + switch_CCS_frontloading * (sum(tt$(tt.val >= t.val and tt.val < t.val + T_CCS and not tt.val=t0.val), 
#                                                                  qI_CCS_tilde[sp,tt])/T_CCS*(T_CCS/(tend.val - t.val + 1))
#                                                              + qI_CCS_actual_baseline['iM',sp,t]);


#  $ENDBLOCK

# ======================================================================================================================
# Solving the model with abatement technologies
# ======================================================================================================================

$import energy_price_partial.gms

$MODEL M_abatement_partial
    M_Energy_price_partial
    M_abatement
;

$GROUP G_abatement_partial_endo
    G_Energy_price_endo
    G_abatement_endo
;

$GROUP G_abatement_partial_exo
    G_Energy_price_exo
    G_abatement_exo
;

$FIX G_abatement_partial_exo;
$UNFIX G_abatement_partial_endo;
@SOLVE(M_abatement_partial);


# ----------------------------------------------------------------------------------------------------------------------
# Running the full model
# ----------------------------------------------------------------------------------------------------------------------

#Now we move start year to 2023 
#  $SETGLOBAL start_shock_year 2022 #Year where we start the shock
#  set_time_periods(%start_shock_year%,%terminal_year%);

## We first solve the model with exogenous CCS
#  $MODEL M_calib_CCS_exo_rCCS
#      M_zeroshock
#      -E_tRE_market # Vi hiver denne ud, da tvRE er en dead-end variabel
#      -E_rCCS    
#  ;
  
#  $GROUP G_endo
#      G_endo
#      -tvRE$(tx0[t] and d1tRE[purpose,energy19,r,t] and d1pRE_base[purpose,energy19,r,t]) # Vi hiver denne ud, da tvRE er en dead-end variabel
#      -rCCS$(tCCS[t] and sum(energy19, sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])))
#  ;
  
#  $GROUP G_exo
#      G_exo
#      rCCS$(tCCS[t] and sum(energy19, sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])))
#  ;

#  $FIX G_exo;
#  $UNFIX G_endo;
#   execute_unloaddi 'Output\Pre_Calib_CCS.gdx';
#  @SOLVE(M_calib_CCS_exo_rCCS);

## Solving the model with endogenous CCS
$MODEL M_calib_CCS
    M_zeroshock
    #  E_rCCS
;
  
$GROUP G_endo
    G_endo
    #  rCCS$(tCCS[t] and sum(energy19, sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])))
;
  
$GROUP G_exo
    G_exo
    #  -rCCS$(tCCS[t] and sum(energy19, sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])))
;


$FIX G_exo;
$UNFIX G_endo;
@SOLVE(M_calib_CCS);


PARAMETER
    qEmmCCStot[t]
;

qEmmCCStot[t] = sum(s, sumqEmmCCSbio.l[s,t] + sumqEmmCCSubio.l[s,t]);

execute_unloaddi 'Output\Calib_CCS_2035.gdx';
@check_vBoP();