# ======================================================================================================================
# Calibration of CCS potential
# ======================================================================================================================


# ------------------------------------------------------------------------------------------------------------------
# Set time indices
# ------------------------------------------------------------------------------------------------------------------

singleton set tCCS_data_start[t] /2025/;
singleton set tCCS_data_end[t] /2035/;

set tCCS_data[t] /2025*2035/;

# ------------------------------------------------------------------------------------------------------------------
# Import sets from data
# ------------------------------------------------------------------------------------------------------------------

$gdxIn '..\Data\Abatement\EA_KF25\EA_CCS_KF25.gdx'
Sets 
    s_cat
    ;

$load s_cat=s_cat

$gdxIn

alias(emm,emm_m);

# Create mapping of potentials to GreenREFORM dimensions
#£AKB: Industries removed to make it run
sets s_industry_CCS(s) /
    '10011'
    '10012'
    '10013'
    '10020'
    '10030'
    '10040'
    '10120'
    '13150'
    '16000'
    '20000'
    '21000'
    '25000'
    /;

set thesee19[energy19]/
	"Crude oil"    
	"Semi-refined oil"
	"LVN" 
	"Refinery gas" 							
	"Gasoline for transport"        
	"Jet petroleum"                       
	"Oil products"          			        
	"Bunkering of Danish operated vessels on foreign territory"                        
	"Diesel for transport" 			    	
	"Natural gas (Extraction)"                
	"Natural gas incl. biongas"        
	"Coal and coke"                           
	"Waste"           
	"Wood waste" 
	"Renewable energy"                        
	"Straw for energy purposes"               
	"Firewood and woodchips"                  
	"Wood pellets"   
	"Biogas"         
	"Biodiesel"
	"bioethanol"
	"Biooil" 
	"Heat pumps"                              

	# #  "Electricity"                             
	"District heat"
	"Bunkering of Danish operated planes on foreign territory"  
	"Bunkering of Danish operated trucks on foreign territory"
	"Waste oil"
	"Jet fuel, sustainable"
	"El from y and m"
	"electricity"
    /;

# Define mapping from s_cat to s, purpose and emm
Sets map_scat2s_purpose_emm(s_cat,s,purpose,energy19,emm_eq) /
    'Biogas'.'35002'.'process_special'.'Biogas'.'CO2bio'
    'Raffinaderi'.'19000'.'in_ETS'.'Refinery gas'.'CO2ubio'
    'Affald'.'38393'.'in_ETS'.'waste'.'CO2bio'
    'Affald'.'38393'.'in_ETS'.'waste'.'CO2ubio'
    /;

# Mapping of potentials that map to whole sets
#AKB£: Cement removed to make it run
map_scat2s_purpose_emm['Cement',s,purpose,energy19,emm_eq]$(sum(tCCS_data, qEmmProdE.l[s,tCCS_data,emm_eq,purpose,energy19]) 
                                                        and sameas[s,'23001']
                                                        and sameas[purpose,'in_ETS']
                                                        and thesee19[energy19]
                                                        and (sameas[emm_eq,'CO2bio'] or sameas[emm_eq,'CO2ubio'])) = yes;

map_scat2s_purpose_emm['Biomasse',s,purpose,energy19,emm_eq]$(sum(tCCS_data, qEmmProdE.l[s,tCCS_data,emm_eq,purpose,energy19]) 
                                                          and sameas[s,'35011']
                                                          and (sameas[energy19,'Straw for energy purposes'] or sameas[energy19,'Firewood and woodchips'] or sameas[energy19,'Wood pellets'])
                                                          and sameas[emm_eq,'CO2bio']) = yes;

map_scat2s_purpose_emm['Industri',s,purpose,energy19,emm_eq]$(sum(tCCS_data, qEmmProdE.l[s,tCCS_data,emm_eq,purpose,energy19]) 
                                                          and s_industry_CCS(s)
                                                          and (sameas[purpose,'process_normal'] or sameas[purpose,'in_ETS']) # or sameas[purpose,'process_special'] # Vi udelader process_special, da der er meget små udledninger herfra
                                                          and not sameas[energy19,'Wood waste']
                                                          and (sameas[emm_eq,'CO2bio'] or sameas[emm_eq,'CO2ubio'])) = yes;


# ------------------------------------------------------------------------------------------------------------------
# Read input-data
# ------------------------------------------------------------------------------------------------------------------

# Define parameters
Parameter
    CCSPot_data[techCCS,s_cat,t]
    # CCScost_Capital_data[techCCS_data,s_cat,t]
    # CCScost_Energy_data[techCCS_data,s_cat,t]
    CCSPrice_data[techCCS,s_cat,t]
    ;

# Read change in reduction potential (kt CO2) and costs (kr. pr. ton)
execute_loaddc '..\Data\Abatement\EA_KF25\EA_CCS_KF25.gdx' CCSPot_data = CO2_potential_kt.l;  
execute_loaddc '..\Data\Abatement\EA_KF25\EA_CCS_KF25.gdx' CCSPrice_data = tech_cost.l;  
# execute_loaddc '..\Data\Abatement\DORS_EA\25092024\CCS_til_GR_25092024.gdx' CCScost_Capital_data = tech_cost_capital.l;
# execute_loaddc '..\Data\Abatement\DORS_EA\25092024\CCS_til_GR_25092024.gdx' CCScost_Energy_data = tech_cost_energy.l;


# ------------------------------------------------------------------------------------------------------------------
# Defining reduction potentials
# ------------------------------------------------------------------------------------------------------------------

Parameter
    qEmmProdE_scat[s_cat,t]
    qEmmProdxE_scat[s_cat,t]
    pot_sh_CCS_scat[techCCS,s_cat,t]
    ;

qEmmProdE_scat[s_cat,t]     = sum((s,purpose,energy19,emm)$(map_scat2s_purpose_emm[s_cat,s,purpose,energy19,emm] 
                                                        and d1EmmProdE[s,t,emm,purpose,energy19]
                                                        and (sameas[emm,'CO2ubio'] or sameas[emm,'CO2bio'])), qEmmProdE.l[s,t,emm,purpose,energy19]);

qEmmProdxE_scat[s_cat,t]    = sum((s,emm)$(sum((purpose,energy19), map_scat2s_purpose_emm[s_cat,s,purpose,energy19,emm]) 
                                       and qEmmProdxE.l[s,t,emm]
                                       and (sameas[emm,'CO2ubio'] or sameas[emm,'CO2bio'])), qEmmProdxE.l[s,t,emm]);

#£AKB: Tilføjet qEmmProdE_scat i betingelse
pot_sh_CCS_scat[techCCS,s_cat,t]$(CCSPot_data[techCCS,s_cat,t] and not sameas[s_cat,'Cement'] and qEmmProdE_scat[s_cat,t])    = CCSPot_data[techCCS,s_cat,t] / qEmmProdE_scat[s_cat,t];
pot_sh_CCS_scat[techCCS,s_cat,t]$(CCSPot_data[techCCS,s_cat,t] and sameas[s_cat,'Cement'] and qEmmProdE_scat[s_cat,t])        = CCSPot_data[techCCS,s_cat,t] / (qEmmProdE_scat[s_cat,t] + qEmmProdxE_scat[s_cat,t]);

# Interpolate potentials between 2030 and 2035
pot_sh_CCS_scat[techCCS,s_cat,t]$(t.val > 2030 and t.val < 2035)
            = pot_sh_CCS_scat[techCCS,s_cat,'2030'] + 
            (pot_sh_CCS_scat[techCCS,s_cat,'2035'] - pot_sh_CCS_scat[techCCS,s_cat,'2030'])/5 * (t.val - 2030);

# We assume that CCS potentials in 2025-2029 are equal to the potential in 2030
pot_sh_CCS_scat[techCCS,s_cat,t]$(t.val > 2024 and t.val < 2030) = pot_sh_CCS_scat[techCCS,s_cat,'2030'];
# ------------------------------------------------------------------------------------------------------------------
# Defining costs
# ------------------------------------------------------------------------------------------------------------------

# set CCScostGroup / 
#     Kapital
#     Energi
# /;

 #  Parameter
#     shCCSPrice_group_data[techCCS_data,s_cat,CCScostGroup,t]
   #  ;

# CCS costs are aggregates of capital and energy costs (in data prices are measured in 1000 kr/tonnes CO2 - in the model they are measured as kr/tonnes)
#  CCSPrice_data[techCCS,s_cat,t] = (CCScost_Capital_data[techCCS,s_cat,t] + CCScost_Energy_data[techCCS,s_cat,t])*1000;

# Costs are split into capital and energy shares
# shCCSPrice_group_data[techCCS_data,s_cat,'Kapital',t]$(CCSPot_data[techCCS_data,s_cat,t]) = CCScost_Capital_data[techCCS_data,s_cat,t]*1000 / CCSPrice_data[techCCS_data,s_cat,t];
# shCCSPrice_group_data[techCCS_data,s_cat,'Energi',t]$(CCSPot_data[techCCS_data,s_cat,t]) = 1 - shCCSPrice_group_data[techCCS_data,s_cat,'Kapital',t];

# Setting values when prices are 0 and hence eliminating interpolation of prices starting or ending with 0
CCSPrice_data[techCCS,s_cat,t]$(tx0[t] and t.val<2030 and CCSPrice_data[techCCS,s_cat,'2030'] and not CCSPrice_data[techCCS,s_cat,'2025']) = CCSPrice_data[techCCS,s_cat,'2030'];
CCSPrice_data[techCCS,s_cat,t]$(tx0[t] and t.val<2035 and CCSPrice_data[techCCS,s_cat,'2035'] and not CCSPrice_data[techCCS,s_cat,'2030']) = CCSPrice_data[techCCS,s_cat,'2035'];
CCSPrice_data[techCCS,s_cat,t]$(tx0[t] and t.val>2030 and CCSPrice_data[techCCS,s_cat,'2030'] and not CCSPrice_data[techCCS,s_cat,'2035']) = CCSPrice_data[techCCS,s_cat,'2030'];
CCSPrice_data[techCCS,s_cat,t]$(tx0[t] and t.val>2025 and CCSPrice_data[techCCS,s_cat,'2025'] and not CCSPrice_data[techCCS,s_cat,'2030']) = CCSPrice_data[techCCS,s_cat,'2025'];
CCSPrice_data[techCCS,s_cat,t]$(t.val>2035) = CCSPrice_data[techCCS,s_cat,'2035'];

# Interpolate prices and price shares 
CCSPrice_data[techCCS,s_cat,t]$(t.val > 2025 and t.val < 2030)
            = CCSPrice_data[techCCS,s_cat,'2025'] + 
            (CCSPrice_data[techCCS,s_cat,'2030'] - CCSPrice_data[techCCS,s_cat,'2025'])/5 * (t.val - 2025);

CCSPrice_data[techCCS,s_cat,t]$(t.val > 2030 and t.val < 2035)
            = CCSPrice_data[techCCS,s_cat,'2030'] + 
            (CCSPrice_data[techCCS,s_cat,'2035'] - CCSPrice_data[techCCS,s_cat,'2030'])/5 * (t.val - 2030);


# shCCSPrice_group_data[techCCS_data,s_cat,CCScostGroup,t]$(t.val > 2025 and t.val < 2030)
#             = shCCSPrice_group_data[techCCS_data,s_cat,CCScostGroup,'2025'] + 
#             (shCCSPrice_group_data[techCCS_data,s_cat,CCScostGroup,'2030'] - shCCSPrice_group_data[techCCS_data,s_cat,CCScostGroup,'2025'])/5 * (t.val - 2025);

# shCCSPrice_group_data[techCCS_data,s_cat,CCScostGroup,t]$(t.val > 2030 and t.val < 2035)
#             = shCCSPrice_group_data[techCCS_data,s_cat,CCScostGroup,'2030'] + 
#             (shCCSPrice_group_data[techCCS_data,s_cat,CCScostGroup,'2035'] - shCCSPrice_group_data[techCCS_data,s_cat,CCScostGroup,'2030'])/5 * (t.val - 2030);


# ------------------------------------------------------------------------------------------------------------------
# Mapping from s_cat to GreenREFORM dimensions
# ------------------------------------------------------------------------------------------------------------------

# Parameters
#     shCCSPrice_group[techCCS,s,CCScostGroup,t]
#     ;

thetaCCS.l[techCCS,purpose,energy19,s,t,emm]$(tCCS_data[t] and d1EmmProdE[s,t,emm,purpose,energy19]) = sum(s_cat$(map_scat2s_purpose_emm(s_cat,s,purpose,energy19,emm) and d1EmmProdE[s,t,emm,purpose,energy19]), 
                                                            pot_sh_CCS_scat[techCCS,s_cat,t]);

# Potentials are held constant after last data year (if there are emissions present in KF-data, i.e. the dummy d1EmmProdE)
thetaCCS.l[techCCS,purpose,energy19,s,t,emm]$(t.val > tCCS_data_end.val and thetaCCS.l[techCCS,purpose,energy19,s,tCCS_data_end,emm] and d1EmmProdE[s,t,emm,purpose,energy19])  = thetaCCS.l[techCCS,purpose,energy19,s,tCCS_data_end,emm];
thetaCCSxE.l[techCCS,'23001',t,'CO2ubio']                                   = thetaCCS.l[techCCS,'in_ETS','Oil products','23001',t,'CO2ubio'];

CCSPrice.l[techCCS,s,t] = sum(s_cat$(sum((purpose,energy19,emm), map_scat2s_purpose_emm(s_cat,s,purpose,energy19,emm))), 
                                                            CCSPrice_data[techCCS,s_cat,t]);

# We scale capital costs with the sector-specific investment price in baseline
CCSPrice.l[techCCS,s,t]$(CCSPrice.l[techCCS,s,t]) = CCSPrice.l[techCCS,s,t]/pI_s.l['iM',s,t];

# shCCSPrice_group[techCCS,s,CCScostGroup,t] = sum(s_cat$(sum((purpose,energy19,emm), map_scat2s_purpose_emm(s_cat,s,purpose,energy19,emm)) and tCCS_data[t]), 
#                                                             shCCSPrice_group_scat[techCCS,s_cat,CCScostGroup,t]);

# ------------------------------------------------------------------------------------------------------------------
# Checking potentials (and costs)
# ------------------------------------------------------------------------------------------------------------------

## Tjek potentials that are > 0.9 (KEFM says that the maximum efficiency of CCS is 90 pct.)

parameter
    tjek_thetaCCS[purpose,energy19,s,t,emm]
    thetaCCS_sumTech[purpose,energy19,s,t,emm]
    ;

tjek_thetaCCS[purpose,energy19,s,t,emm]$(sum(techCCS, thetaCCS.l[techCCS,purpose,energy19,s,t,emm])>0.9) = sum(techCCS, thetaCCS.l[techCCS,purpose,energy19,s,t,emm]);

thetaCCS_sumTech[purpose,energy19,s,t,emm]$(sum(techCCS, thetaCCS.l[techCCS,purpose,energy19,s,t,emm])) = sum(techCCS, thetaCCS.l[techCCS,purpose,energy19,s,t,emm]);

# LBS Skalering af potentialer, når de overstiger 0.9 
thetaCCS.l[techCCS,purpose,energy19,s,t,emm]$(thetaCCS.l[techCCS,purpose,energy19,s,t,emm] and thetaCCS_sumTech[purpose,energy19,s,t,emm] > 0.9) 
    = thetaCCS.l[techCCS,purpose,energy19,s,t,emm]/thetaCCS_sumTech[purpose,energy19,s,t,emm]*0.9;

## Tjek potentials that are > 0.9 (KEFM says that the maximum efficiency of CCS is 90 pct.)


Parameters
    Tjek_pot_CCS[s_cat,t]
    Tjek_CapitalCosts_CCS[s_cat,t]
    # Tjek_EnergyCosts_CCS[s_cat,t]

    data_cap_costs[techCCS,s_cat,t] "Billion DKK"
    model_cap_costs[techCCS,s_cat,t]     "Billion DKK"
    ;

# Reduction potentials
Tjek_pot_CCS[s_cat,t]$(tCCS_data[t]) = sum((techCCS,s,purpose,energy19,emm)$(map_scat2s_purpose_emm[s_cat,s,purpose,energy19,emm]), 
                                        thetaCCS.l[techCCS,purpose,energy19,s,t,emm]*qEmmProdE.l[s,t,emm,purpose,energy19])
                                + sum((techCCS,s,emm)$(sum((purpose,energy19), map_scat2s_purpose_emm[s_cat,s,purpose,energy19,emm])), 
                                        thetaCCSxE.l[techCCS,s,t,emm]*qEmmProdxE.l[s,t,emm])
                                - sum(techCCS, CCSPot_data[techCCS,s_cat,t]);

# Check that GR reduction potentials are the same as in data
LOOP((s_cat,t)$((sameas[t,'2030'] or sameas[t,'2035']) and not sameas[s_cat,'Affald']),
    tjek = Tjek_pot_CCS[s_cat,t];
    #£AKB: Slår test fra imens, der testes
    ABORT$(abs(tjek) > 10**(-6)) tjek, "Reduction potential is different than data";
);

data_cap_costs[techCCS,s_cat,t] = CCSPot_data[techCCS,s_cat,t]*1000 # Tonnes CO2
                                        *CCSPrice_data[techCCS,s_cat,t] # DKK per tonnes
                                        /10**9; # Billion
model_cap_costs[techCCS,s_cat,t]     = (sum((s,purpose,energy19,emm)$(map_scat2s_purpose_emm[s_cat,s,purpose,energy19,emm]), 
                                            thetaCCS.l[techCCS,purpose,energy19,s,t,emm]*qEmmProdE.l[s,t,emm,purpose,energy19]*1000 # Tonnes CO2
                                            *CCSPrice.l[techCCS,s,t]*pI_s.l['iM',s,t]) #*shCCSPrice_group[techCCS,s,'Kapital',t]) # DKK per tonnes
                                     +  sum((s,emm)$(sum((purpose,energy19), map_scat2s_purpose_emm[s_cat,s,purpose,energy19,emm])), 
                                            thetaCCSxE.l[techCCS,s,t,emm]*qEmmProdxE.l[s,t,emm]*1000
                                            *CCSPrice.l[techCCS,s,t]*pI_s.l['iM',s,t]))
                                            /10**9; # Billion

# Capital costs
Tjek_CapitalCosts_CCS[s_cat,t]$(sameas[t,'2025'] or sameas[t,'2030'] or sameas[t,'2035']) 
    = sum(techCCS, model_cap_costs[techCCS,s_cat,t]) 
    - sum(techCCS, data_cap_costs[techCCS,s_cat,t]);

# Check that GR capital costs are the same as in data
LOOP((s_cat,t)$((sameas[t,'2030'] or sameas[t,'2035']) and not sameas[s_cat,'Affald']),
    tjek = Tjek_CapitalCosts_CCS[s_cat,t];
    #£AKB: Slår test fra imens, der testes
    ABORT$(abs(tjek) > 10**(-6)) tjek, "Capital costs are different than data";
);

# Energy costs
# Tjek_EnergyCosts_CCS[s_cat,t]$(tCCS_data[t]) = sum((techCCS,s,purpose,energy19,emm)$(map_scat2s_purpose_emm[s_cat,s,purpose,energy19,emm]), 
#                                             thetaCCS.l[techCCS,purpose,energy19,s,t,emm]*qEmmProdE.l[s,t,emm,purpose,energy19]*CCSPrice.l[techCCS,s,t]*shCCSPrice_group[techCCS,s,'Energi',t])
#                                          - sum(techCCS_data, CCSPot_data[techCCS_data,s_cat,t]*CCScost_Energy_data[techCCS_data,s_cat,t]*1000);

# Check that GR energy costs are the same as in data
# LOOP((s_cat,t)$(sameas[t,'2030'] or sameas[t,'2035']),
#     tjek = Tjek_EnergyCosts_CCS[s_cat,t];
#     ABORT$(abs(tjek) > 10**(-6)) tjek, "Energy costs are different than data";
# );


# ----------------------------------------------------------------------------------------------------------------------
# Dummies and initialisation
# ----------------------------------------------------------------------------------------------------------------------

d1thetaCCS[techCCS,purpose,energy19,s,t,emm]$(thetaCCS.l[techCCS,purpose,energy19,s,t,emm]) = yes;

d1thetaCCS_end[techCCS,purpose,energy19,s,t,emm]$(d1thetaCCS[techCCS,purpose,energy19,s,t,emm]
                                          and not d1thetaCCS[techCCS,purpose,energy19,s,t+1,emm]) = yes;

d1CCSbio[purpose,energy19,s,t,'CCSbio']$(d1EmmProdE[s,t,'CO2bio',purpose,energy19] and sum(techCCS, d1thetaCCS[techCCS,purpose,energy19,s,t,'CO2bio'])) = yes;
d1CCSbio[purpose,energy19,s,t,'CO2e']$(d1CCSbio[purpose,energy19,s,t,'CCSbio']) = yes;

d1thetaCCSxE[techCCS,s,t,emm]$(thetaCCSxE.l[techCCS,s,t,emm]) = yes;
d1thetaCCSxE_end[techCCS,s,t,emm]$(d1thetaCCSxE[techCCS,s,t,emm]
                           and not d1thetaCCSxE[techCCS,s,t+1,emm]) = yes;

# d1thetaCCSxE['t8',s,t,emm]$(thetaCCSxE.l['t8',s,t,emm]) = no;
# d1thetaCCSxE_end['t8',s,t,emm]$(d1thetaCCSxE['t8',s,t,emm]
#                            and not d1thetaCCSxE['t8',s,t+1,emm]) = no;


d1switchCCS = 1;

rCCS.l[techCCS,s,purpose,t]$(sum((energy19,emm), thetaCCS.l[techCCS,purpose,energy19,s,t,emm])) = 0;

sigmaCCS.l[techCCS]$(sum((purpose,energy19,s,t,emm), d1thetaCCS[techCCS,purpose,energy19,s,t,emm]))         = 20;
rCCS_max_sh[techCCS]$(sum((purpose,energy19,s,t,emm), d1thetaCCS[techCCS,purpose,energy19,s,t,emm]) 
                    or sum((s,t,emm), d1thetaCCSxE[techCCS,s,t,emm]))     = 0.2;
uCCSscalar.l[techCCS,s,purpose,t]$(sum((energy19,emm), d1thetaCCS[techCCS,purpose,energy19,s,t,emm]))       = 1;
uCCSt.l[techCCS,s,purpose,t]$(sum((energy19,emm), d1thetaCCS[techCCS,purpose,energy19,s,t,emm]))            = 0;
j_rCCS.l[techCCS,s,purpose,t]$(sum((energy19,emm), d1thetaCCS[techCCS,purpose,energy19,s,t,emm]))  = 0;

# Potential reductions has to be initialised to not divide by zero in E_rCCS
qEmmCCSPot.l[techCCS,s,purpose,t]$(tCCS[t] and sum(energy19, sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,t,emm] and d1EmmProdE[s,t,emm,purpose,energy19]))) 
    = sum((energy19,emm)$(d1thetaCCS[techCCS,purpose,energy19,s,t,emm] and d1EmmProdE[s,t,emm,purpose,energy19]), 
        thetaCCS.l[techCCS,purpose,energy19,s,t,emm]*qEmmProdE.l[s,t,emm,purpose,energy19])
    + sum(emm$(d1thetaCCSxE[techCCS,s,t,emm] and d1EmmProdxE[s,t,emm]), 
        thetaCCSxE.l[techCCS,s,t,emm]*qEmmProdxE.l[s,t,emm])$(sameas[purpose,'in_ETS']);

# Switch der definerer, om CCS-teknologierne skal trænge ind (=1) eller ej (=0)
switch_CCS[techCCS] = 0;
switch_CCS[techCCS]$(sum((purpose,energy19,s,t,emm), d1thetaCCS[techCCS,purpose,energy19,s,t,emm])) = 1;

# execute_unload 'Output\calib_CCS_temp.gdx';