
	$GROUP G_EV
	betaMediumCorrection ""
	betaMediumLongCorrection ""
	betaLongCorrection ""
	;

	#We save target value of consumption in 2023 and 2030
	PARAMETER qCHH_save_2023, qCHH_save_2030, theiterator/0.5/;
	qCHH_save_2023 = qCHH.l['ctot','2023'];
	qCHH_save_2030 = qCHH.l['ctot','2030'];



  $BLOCK B_EV

	E_betaMediumCorrection[t]$(tMediumTerm[t])..   					beta[t] =E= (beta.l[t]+betaMediumLongCorrection+betaLongCorrection) + tFadeOut[t]*betaMediumCorrection;
	E_betaMediumLongCorrection[t]$(tMediumLongTerm[t])..   	beta[t] =E= (beta.l[t]+betaLongCorrection) + tFadeOut_2030_2050[t]*betaMediumLongCorrection;
	E_betaLongCorrection[t]$(tLongTerm[t])..    			 			beta[t] =E= (beta.l[t]+betaLongCorrection);

	E_qCHH_rela..           qCHH_R['2023'] * qCHH_nR['2030'] =E= qCHH_R['2030'] * qCHH_nR['2023']; # endogenous variable: JvWealth_MediumTerm
	E_qCHH_rela_2050..      qCHH_R['2023'] * qCHH_nR['2050'] =E= qCHH_R['2050'] * qCHH_nR['2023']; # endogenous variable: JvWealth_MediumLongTerm

	# This can be used if the model has difficulty when calibrating
	#  E_qCHH_2023..          qCHH['ctot','2023'] =E= theiterator * (qCHH_save_2023) + (1-theiterator) * (qCHH_R.l['2023'] + qCHH_nR.l['2023']);
	#  E_qCHH_2030..          qCHH['ctot','2030'] =E= theiterator * (qCHH_save_2030) + (1-theiterator) * (qCHH_R.l['2030'] + qCHH_nR.l['2030']);

  $ENDBLOCK


$MODEL M_dynamic_calibration_calib2KP_EV
	M_dynamic_calibration_cement
  # M_dynamic_calibration_calib2ExtFor
  B_EV
  -B_ConsumptionNest_partial_calib
;



$GROUP G_dynamic_calibration_endo
	G_dynamic_calibration_endo
	 # Privatforbruget sættes fri og rammes nu via fremadskuende og kreditrationerede forbrugere fra 2023 (se længere nede)
	-uC, -shareC, qCHH, qC$(sameas[c_,'cCar'])
	-qCHH$((t1[t] or t0[t]) and sameas[c_,'cCar'])
	# Privatforbruget rammes i 2050. Dette gøres ved korrektion i den langsigtede beta
  -qCHH$(cTot[c_] and t2050[t])
	beta$(tLongTerm[t]), betaLongCorrection
	# Privatforbruget rammes i 2030 ved at korrigere lige meget i de fremadskuende og de kredirationeredes forbrug. De fremadskuende får indlagt en trend i beta, og de kredirationerede reagerer på en trend i JvWealth.
	-qCHH$(cTot[c_] and t2030[t])
	beta$(tMediumLongTerm[t]), betaMediumLongCorrection, JvWealth_MediumLongTerm
	# Privatforbruget rammes i 2023 ved at korrigere lige meget i de fremadskuende og de kredirationeredes forbrug. De fremadskuende får indlagt en trend i beta, og de kredirationerede reagerer på en trend i JvWealth.
	-qCHH$(cTot[c_] and t2023[t])
    beta$(tMediumTerm[t]), betaMediumCorrection, JvWealth_MediumTerm
;




$GROUP G_dynamic_calibration_exo 
	G_dynamic_calibration_exo
	uC, shareC, -qCHH
	qCHH$((t1[t] or t0[t]) and sameas[c_,'cCar'])

	qCHH$(cTot[c_] and t2050[t])
	-beta$(tLongTerm[t]), -betaLongCorrection, 	
	qCHH$(cTot[c_] and t2030[t])
	-beta$(tMediumLongTerm[t]), -betaMediumLongCorrection, -JvWealth_MediumLongTerm	
	qCHH$(cTot[c_] and t2023[t])
	-beta$(tMediumTerm[t]), -betaMediumCorrection, -JvWealth_MediumTerm
;


    # d1qCHH_EV lig 1 bestemmes privatforbruget af EV-konsistent forbrugsvalg. d1qCHH_EV lig 0 holdes privatforbruget som en fast andel af BVT.
d1qCHH_EV.l[t] $ (tMediumTerm[t]) 			= 1;
d1qCHH_EV.l[t] $ (tMediumLongTerm[t])   = 1;
d1qCHH_EV.l[t] $ (tLongTerm[t])  				= 1;


$FIX G_dynamic_calibration_exo;
$UNFIX G_dynamic_calibration_endo;

# $FOR {theiterator} in ['0.5','1']:

 $FOR {theiterator} in ['1']:
	theiterator = {theiterator};
	$IF %readfromprevious%!=1:
		@Solve(M_dynamic_calibration_calib2KP_EV);
		#  execute_unload 'output\ExtFor_calib_EV_{theiterator}.gdx';
	$ENDIF
$ENDFOR

calibrate2_output['qGDP',t,'GRpostEV']$ (t.val ge t1.val)     = qGDP.l[t];
calibrate2_output['qCtot',t,'GRpostEV']$ (t.val ge t1.val)    = qCHH.l['cTot',t];
calibrate2_output['qG',t,'GRpostEV']$ (t.val ge t1.val)       = qG.l['Gtot',t];
calibrate2_output['qX',t,'GRpostEV']$ (t.val ge t1.val)       = sum(maks,qX_y_GR2KP.l[maks,t]);

calibrate2_output['pGDP',t,'GRpostEV']$ (t.val ge t1.val)     = vGDP.l[t]/qGDP.l[t];
calibrate2_output['w',t,'GRpostEV']$ (t.val ge t1.val)        = w.l[t];

calibrate2_output['qCCar',t,'GRpostEV']$ (t.val ge t1.val)    		= qCHH.l['cCar',t];
calibrate2_output['qCtou',t,'GRpostEV']$ (t.val ge t1.val)    		= qCHH.l['cTou',t];
calibrate2_output['qCGoo',t,'GRpostEV']$ (t.val ge t1.val)    		=	qCHH.l['cGoo',t];
calibrate2_output['qCCarEne',t,'GRpostEV']$ (t.val ge t1.val)    	= qCHH.l['cCarEne',t];
calibrate2_output['qCHouEne',t,'GRpostEV']$ (t.val ge t1.val)    	= qCHH.l['cHouEne',t];
calibrate2_output['qCSer',t,'GRpostEV']$ (t.val ge t1.val)    		= qCHH.l['cSer',t];
calibrate2_output['qCHou',t,'GRpostEV']$ (t.val ge t1.val)    		= qCHH.l['cHou',t];

calibrate2_output['qXfre',t,'GRpostEV']$ (t.val ge t1.val)    = qX_y_GR2KP.l['fre',t];
calibrate2_output['qXtje',t,'GRpostEV']$ (t.val ge t1.val)    = qX_y_GR2KP.l['tje',t];
calibrate2_output['qXsoe',t,'GRpostEV']$ (t.val ge t1.val)    = qX_y_GR2KP.l['soe',t];
calibrate2_output['qXlan',t,'GRpostEV']$ (t.val ge t1.val)    = qX_y_GR2KP.l['lan',t];

calibrate2_output['qCtotY',t,'GRpostEV']$ (t.val ge t1.val)   = qCHH.l['cTot',t] / qGDP.l[t];
calibrate2_output['qGY',t,'GRpostEV']$ (t.val ge t1.val)      = qG.l['Gtot',t]   / qGDP.l[t];
calibrate2_output['qIY',t,'GRpostEV']$ (t.val ge t1.val)      = qI.l['Itot',t]   / qGDP.l[t];
calibrate2_output['qXY',t,'GRpostEV']$ (t.val ge t1.val)      = qX.l['xtot',t]   / qGDP.l[t];
calibrate2_output['qMY',t,'GRpostEV']$ (t.val ge t1.val)      = qM.l['tot',t]    / qGDP.l[t];

calibrate2_output['vCY',t,'GRpostEV']$ (t.val ge t1.val)      = vC.l['ctot',t]   / vGDP.l[t];
calibrate2_output['vWealthY',t,'GRpostEV']$ (t.val ge t1.val) = vWealth.l[t]     / vGDP.l[t];


#  display calibrate2_output;
 
$import sanitycheck.gms


#  execute_unload 'output\ExtFor_calib_EV.gdx';
@assert_no_difference(G_data,%tolerance_data%);
$import check_DS.gms;