# ======================================================================================================================
# CALIBRATION OF ID-ABATEMENT
# ======================================================================================================================


# ======================================================================================================================
# SETS AND DATA
# ======================================================================================================================
    
    # This set controls which years potentials are scaled in order to not change energy-use in Climate Outlook-years (t up to 2050)
    singleton set tEA_ID_End[t]/2050/;

    # ------------------------------------------------------------------------------------------------------------------
    # Energy use in baseline (used to calculate relative technology potentials)
    # ------------------------------------------------------------------------------------------------------------------
    PARAMETER
        qREa_GSR[GSR_ag,energy19a,t] "Baseline energy use for each GSR and energy good"
    ;
    # Calculate energy use for each combination of GSR and energy goods
    qREa_GSR[GSR_ag,energy19a,t]     = sum((purpose,s)$(mapGrREFORM2GSR[purpose,energy19a,s,GSR_ag,t] and d1qREgj[purpose,energy19a,s,t]), qREgj.l[purpose,energy19a,s,t]);


    # ------------------------------------------------------------------------------------------------------------------
    # Load: ENS teknologikatalog til Ekspertgruppens 1. delrapport
    # ------------------------------------------------------------------------------------------------------------------
    #  $import calib_abatement_GSR_ENS.gms


    # ------------------------------------------------------------------------------------------------------------------
    # Load: SKM teknologikatalog til Ekspertgruppens 1. delrapport
    #  ------------------------------------------------------------------------------------------------------------------
    #  $import calib_abatement_GSR_SKM.gms



    # ------------------------------------------------------------------------------------------------------------------
    # Load: EA teknologikatalog
    #  ------------------------------------------------------------------------------------------------------------------



    # ------------------------------------------------------------------------------------------------------------------
    # £ BELOW UNTIL IF STATEMENT SOULD BE MOVED WHEN CCS CALIB IS FIXED 
    #  ------------------------------------------------------------------------------------------------------------------
    $import energy_price_partial.gms

    $GROUP G_abatement_partial_exo
        G_Energy_price_exo
        G_abatement_exo
    ;
    $GROUP G_abatement_partial_endo
        G_Energy_price_endo
        G_abatement_endo
    ;



$gdxIn '..\Data\Abatement\EA_KF25\EA_CCS_KF25.gdx'
Sets 
    s_cat
    ;

$load s_cat=s_cat

$gdxIn

alias(emm,emm_m);

Sets map_scat2s_purpose_emm(s_cat,s,purpose,energy19,emm_eq) /
    'Biogas'.'35002'.'process_special'.'Biogas'.'CO2bio'
    'Raffinaderi'.'19000'.'in_ETS'.'Refinery gas'.'CO2ubio'
    'Affald'.'38393'.'in_ETS'.'waste'.'CO2bio'
    'Affald'.'38393'.'in_ETS'.'waste'.'CO2ubio'
    /;

$onmultiR

SET MAC_set                      /'Reduction potential, ktCO2e','Reduction potential, pct.','Reduction potential, sh (GSR)','Reduction potential, sh (Tot)','cost_DKK_pr_tCO2'/;
SET MAC_emm                      /'CO2e','CO2ubio','CO2ubio + NatGas_bio'/;
SET set_abatement_reporting      /'Additional_costs_krprCO2','pREa','thetaID_k','rID','rID_actual','tCO2_REmarg'/;
SET tMAC_report[t] /2025*2050/;
# SET MAC_set_CCS /'Actual reduction potential, ktCO2e','Gross reduction potential, ktCO2e','cost_DKK_pr_tCO2'/;

SET MAC_set_CCS /'Additional reduction potential, ktCO2e',
                 'Gross reduction potential, ktCO2e',
                 'Additional cost, DKK per tCO2',
                 'Total additional cost, billion DKK',
                 'Additional cost incl. tax, DKK per tCO2',
                 'Total additional cost incl. tax, billion DKK',
                 'Technology cost, DKK per tCO2',
                 'Total technology cost, billion DKK'/;
SET MAC_set_CCS_annu /'Additional reduction potential, ktCO2e, NPV',
                      'Additional reduction potential, ktCO2e, yearly',
                      'Gross reduction potential, ktCO2e, NPV',
                      'Gross reduction potential, ktCO2e, yearly',
                      'Total additional cost, billion DKK, NPV',
                      'Total additional cost, billion DKK, yearly',
                      'Average additional cost, DKK per tCO2',
                      'Average additional cost, 2035',
                      'rCCS_input excl. tax',
                      'Total additional cost incl. tax, billion DKK, NPV',
                      'Total additional cost incl. tax, billion DKK, yearly',
                      'Average additional cost incl. tax, DKK per tCO2',
                      'Total technology cost, billion DKK, NPV',
                      'Total technology cost, billion DKK, yearly',
                      'Average technology cost, DKK per tCO2'/;

# Time set to define which years the annuity for CCS-MAC-curves should be calculated for
SET tMAC_CCS[t] /2019*2099/; 

$offmulti
    $import Report_and_steps\report_EV.gms
    $import Report_and_steps\report_Tech_MAC.gms


    $MODEL M_abatement_partial
        M_Energy_price_partial
        M_abatement
        # E_rCCS_lognormal, -E_rCCS
        # E_qLEVC_CCS_EmmE_RE_alt, -E_qLEVC_CCS_EmmE_RE
    ;


$IF '%EA_data%'=='yes':

     $import calib_ID_EA.gms

    sigmaID.l[techID]$(sum((purpose,energy19a,s,t), d1thetaID_k[techID,purpose,energy19a,s,t])) = 0.0005;

    d1switchID = 1; 

# ======================================================================================================================
# SOLVING PARTIAL PRICE MODEL TO UPDATE PRICES BASED ON EA-DATA FOR ID-ABATEMENT
# ======================================================================================================================

    # Partial price model 
    $FIX G_Energy_price_exo;
    $UNFIX G_Energy_price_endo;
    @SOLVE(M_Energy_price_partial);

# ======================================================================================================================
# SCALING TECHNOLOGY COSTS TO ENSURE ZERO TECHNOLOGY ADOPTION IN BASELINE (BEFORE 2036)
# ======================================================================================================================
    # ------------------------------------------------------------------------------------------------------------------
    # Construction of MAC-curves before scaling
    # ------------------------------------------------------------------------------------------------------------------
    PARAMETERS
        MAC_curve_ID_baseline[techID,s,purpose,energy19a,t,MAC_emm,MAC_set]             "Baseline MAC-curves"
        MAC_curve_ID_GSR_baseline[techID,GSR_ag,s,purpose,energy19a,t,MAC_emm,MAC_set]  "Baseline MAC-curves with GSR"
        thetaID_k_baseline[techID,purpose,energy19a,s,t]                                "Technology costs before scaling"
    ;
    # Construct MAC curves for technologies before scaling 
    $import Report_and_steps\report_Tech_MAC.gms 

    # Save MAC curves without scaled costs
    MAC_curve_ID_baseline[techID,s,purpose,energy19a,t,MAC_emm,MAC_set]            = MAC_curve_ID[techID,s,purpose,energy19a,t,MAC_emm,MAC_set]; 
    MAC_curve_ID_GSR_baseline[techID,GSR_ag,s,purpose,energy19a,t,MAC_emm,MAC_set] = MAC_curve_ID_GSR[techID,GSR_ag,s,purpose,energy19a,t,MAC_emm,MAC_set]; 

    # Save technology costs before scaling
    thetaID_k_baseline[techID,purpose,energy19a,s,t]                                = thetaID_k.l[techID,purpose,energy19a,s,t];


    # ------------------------------------------------------------------------------------------------------------------
    # Scaling of technology costs (thetaID_K) based on the "MAC-cost of reduction" to avoid baseline adoption
    # ------------------------------------------------------------------------------------------------------------------
    #   - The technology costs (thetaID_K) are scaled such that all "MAC-cost of reduction" are above some lower bound (e.g. 0) to avoid baseline adoption
    #   - We use the "MAC-costs" calculated as 'DKK pr. ton CO2ubio + CO2bio for naturalgas' as target for the scaling
    #   - The costs (thetaID_K) are scaled within a sector/purpose-combination. All costs within the combination are scaled if one or more technologies have negative "MAC-costs"
    #   - The scaling preserves the order of the technologies on the MAC-curve
    #   - The maximum "MAC-costs" within a sector/purpose is used as the upper bound for the scaled "MAC-costs"
    #   - The lower bound for the "MAC-costs" are set below
    # ------------------------------------------------------------------------------------------------------------------
    PARAMETERS  
        d1BaselineAdoption_ID[techID,purpose,energy19a,s,t]         "Dummy for technologies with baseline adoption (before 2036)"     
        d1BaselineAdoption_Agg[purpose,s,t]                         "Dummy for sector/purpose-combinations with baseline adoption of technologies"
        MAC_cost_baseline[techID,s,purpose,energy19a,t]             "MAC costs of reduction before scaling"
        max_cost_tech[purpose,s,t]                                  "Maximum MAC-costs within a sector/purpose combination (before scaling)"
        min_cost_tech[purpose,s,t]                                  "Minimum MAC-costs within a sector/purpose combination (before scaling)"    
        max_cost_scaled[purpose,s,t]                                "Maximum MAC-costs after scaling"
        min_cost_scaled                                             "Minimum MAC-costs after scaling"
        max_cost_lowerBound                                         "Lower bound for maximum technology costs after scaling"
    ;
    # SETTINGS FOR SCALING
    # The new lower bound of the "MAC-costs" 
    min_cost_scaled                                                     = 15; # The lower bound is set 1 DDK pr. ton CO2bio + NatGas_bio - THIS CAN BE CHANGED
    # The lower bound for the maximum scaled "MAC-costs" (only relevant if all "MAC-costs" within a sector/purpose are below the lower bound)
    max_cost_lowerBound                                                 = 20;

    # "MAC-cost of reduction" (DDK pr. ton CO2bio + NatGas_bio) from MAC-curves before scaling
    MAC_cost_baseline[techID,s,purpose,energy19a,t]                     = MAC_curve_ID[techID,s,purpose,energy19a,t,'CO2ubio + NatGas_bio','cost_DKK_pr_tCO2']; 

    # DUMMIES FOR SCALING
    # Technologies with a "MAC-cost" below the minimum "MAC-cost" 
    d1BaselineAdoption_ID[techID,purpose,energy19a,s,t]                 = yes$(MAC_cost_baseline[techID,s,purpose,energy19a,t] and (t.val <= tEA_ID_End.val)
                                                                               and (MAC_cost_baseline[techID,s,purpose,energy19a,t] < min_cost_scaled));

    # Sector/purpose-combinations where the costs have to be scaled because one or more technologies have "MAC-costs" below the minimum "MAC-costs"
    d1BaselineAdoption_Agg[purpose,s,t]                                 = yes$(sum((techID,energy19a)$(d1BaselineAdoption_ID[techID,purpose,energy19a,s,t]), 
                                                                                                d1BaselineAdoption_ID[techID,purpose,energy19a,s,t]));

    # CALCULATION OF SCALED "MAC-COST" 
    # Maximum "MAC-costs" within a sector/purpose combination (before scaling)
    max_cost_tech[purpose,s,t]$(d1BaselineAdoption_Agg[purpose,s,t])    = smax((techID,energy19a)$(d1thetaID_k[techID,purpose,energy19a,s,t]), MAC_cost_baseline[techID,s,purpose,energy19a,t]);
    # Minimum "MAC-costs" within a sector/purpose combination (before scaling)
    min_cost_tech[purpose,s,t]$(d1BaselineAdoption_Agg[purpose,s,t])    = smin((techID,energy19a)$(d1thetaID_k[techID,purpose,energy19a,s,t]), MAC_cost_baseline[techID,s,purpose,energy19a,t]);
    # The maximum "MAC-costs" after scaling is set equal to the highest of the actual maximum cost and the lower bound for the scaled maximum cost
    max_cost_scaled[purpose,s,t]$(d1BaselineAdoption_Agg[purpose,s,t])  = max(max_cost_tech[purpose,s,t],max_cost_lowerBound);

    # For each technology the scaled "MAC-cost" is calculated based on the location of the technology's original "MAC-cost" between the original maximum and minimum "MAC-costs" 
    # together with the new scaled maximum and minimum "MAC-costs" 
    MAC_cost_baseline[techID,s,purpose,energy19a,t]$(d1BaselineAdoption_Agg[purpose,s,t] and d1thetaID_k[techID,purpose,energy19a,s,t]) 
                                                                        = min_cost_scaled 
                                                                            + (MAC_cost_baseline[techID,s,purpose,energy19a,t]-min_cost_tech[purpose,s,t])
                                                                                            /(max_cost_tech[purpose,s,t]-min_cost_tech[purpose,s,t])
                                                                            * (max_cost_scaled[purpose,s,t]-min_cost_scaled);

    # PARAMETER whereundf[techID,s,purpose,energy19a,t];
    # $onUNDF
    # whereundf[techID,s,purpose,energy19a,t]$(d1BaselineAdoption_Agg[purpose,s,t] and d1thetaID_k[techID,purpose,energy19a,s,t] and MAC_cost_baseline[techID,s,purpose,energy19a,t]=UNDF) = yes;
    # execute_unload 'output\whereund.gdx';
    
    # MODEL TO CALIBRATE thetaID_K SUCH THAT MAC_cost_baseline IS EQUAL TO THE NEW SCALED MAC_cost_baseline                                                                       
    $BLOCK M_ID_scaling
      # Equation for calculating the 'MAC-cost of reduction' (see EA_report.gms). The equation is used to determine thetaID_K
      E_MAC_cost_baselineadoption[techID,s,purpose,energy19a,t]$(tx0[t] and d1BaselineAdoption_Agg[purpose,s,t] and d1thetaID_k[techID,purpose,energy19a,s,t] 
                                                                    and sum(energy19, qEmmProdE_MechCh_MAC[techID,purpose,energy19,s,t,'CO2ubio + NatGas_bio']))..
        MAC_cost_baseline[techID,s,purpose,energy19a,t] =E= 
            #pREa_MechCh
            -(sum(energy19$(d1thetaID[techID,purpose,energy19a,energy19,s,t]), thetaID[techID,purpose,energy19a,energy19,s,t]*pREgj[purpose,energy19,s,t])
                + thetaID_K[techID,purpose,energy19a,s,t]
                * sum(energy19$(d1thetaID[techID,purpose,energy19a,energy19,s,t] and sameas(energy19,energy19a)),-thetaID[techID,purpose,energy19a,energy19,s,t]) 
                * pI_s['iM',s,t])
            *(qREa[purpose,energy19a,s,t]/growth_factor[t])/sum(energy19, qEmmProdE_MechCh_MAC[techID,purpose,energy19,s,t,'CO2ubio + NatGas_bio'])*10**6;

    $ENDBLOCK

    $GROUP G_ID_scaling_endo
        thetaID_k$(d1BaselineAdoption_Agg[purpose,s,t] and d1thetaID_k[techID,purpose,energy19a,s,t])
        ;

    $GROUP G_ID_scaling_exo
        G_abatement_partial_exo
        -thetaID_k$(d1BaselineAdoption_Agg[purpose,s,t] and d1thetaID_k[techID,purpose,energy19a,s,t])
        pREgj$(tx0[t] and sum(techID, sum(energy19a, d1thetaID[techID,purpose,energy19a,energy19,r,t])))
        ;

    $FIX G_ID_scaling_exo;
    $UNFIX G_ID_scaling_endo;
    @SOLVE(M_ID_scaling);

    # If the technology costs are scaled in 2050, the new scaled value are used for the rest of the period
    thetaID_k.l[techID,purpose,energy19a,s,t]$(t.val>tEA_ID_End.val and d1thetaID_k[techID,purpose,energy19a,s,t])  = thetaID_k.l[techID,purpose,energy19a,s,tEA_ID_End]; 


# ======================================================================================================================
# SOLVING PARTIAL ABATEMENT MODEL AND SET ID-ADOPTION TO 1 IF TECHNOLOGIES ARE ADOPTED IN THE PARTIAL MODEL AFTER 2035
# ======================================================================================================================
    # Partial model to determine initial values for ID-gains and ID-costs (the partial model below does not run, if gains and costs don't have initial values)
    $MODEL M_ID_gains_costs
        E_rID_gains
        E_rID_costs
    ;
    $GROUP G_ID_gains_costs_endo
        rID_gains[techID,purpose,energy19a,s,t]$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t]) ""
        rID_costs[techID,purpose,energy19a,s,t]$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t]) ""
    ;
    
    # Starting values for gains and costs based on the scaled MAC-curve
    $FIX G_abatement_partial_exo;
    $UNFIX G_ID_gains_costs_endo;
    @SOLVE(M_ID_gains_costs);

    # Solving the partial abatement model to give starting values for the full model
    $FIX G_abatement_partial_exo;
    $UNFIX G_abatement_partial_endo;
    # execute_unload 'output\Calib_ID_pre_partial.gdx';
    @SOLVE(M_abatement_partial);

$ENDIF

# ======================================================================================================================
# SOLVING THE FULL MODEL WITH EXOGENOUS ID-ABATEMENT
# ======================================================================================================================


    $GROUP G_exo
        G_exo
        rID_actual$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t] and not d1switchID)
    ;

    # Move start year to 2023 
    $SETGLOBAL start_shock_year 2022 #Year where we start the shock
    set_time_periods(%start_shock_year%,%terminal_year%);

    d1switchID = 0; 

    $FIX G_exo;
    $UNFIX G_endo;
    # execute_unload 'output\Calib_ID_exo_pre.gdx';
    @SOLVE(M_calib_abatement);
    # execute_unload 'output\Calib_ID_exo.gdx';

# ======================================================================================================================
# SOLVING THE FULL MODEL WITH ENDOGENOUS ID-ABATEMENT
# ======================================================================================================================

    d1switchID = 1;

    $FIX G_exo;
    $UNFIX G_endo;
    # execute_unload 'output\Calib_ID_pre.gdx';
    @SOLVE(M_calib_abatement);
    # execute_unload 'output\Calib_ID.gdx';
    # @check_vBoP();

    # ------------------------------------------------------------------------------------------------------------------
    # Construction of MAC-curves after scaling
    # ------------------------------------------------------------------------------------------------------------------
    #  $onMulti
    #  SET tMAC_report[t] /2025,2030,2035,2040,2045,2050/;
    #  $offMulti

    $IF '%EA_data%'=='yes':
          $import Report_and_steps\report_Tech_MAC.gms 
    $ENDIF

    execute_unload 'output\Calib_ID.gdx';
    @check_vBoP();

# ======================================================================================================================
# CHECK FOR BASELINE ADOPTION OF ID-ABATEMENT
# ======================================================================================================================
    $IF '%EA_data%'=='yes':
        $FUNCTION check_ID_BaselineAdoption()
          LOOP((techID,purpose,energy19a,s,t)$(d1thetaID_k[techID,purpose,energy19a,s,t] and t.val <= tEA_ID_End.val),
            display$(rID.l[techID,purpose,energy19a,s,t] > 0.05) rID.l;
            ABORT$(rID.l[techID,purpose,energy19a,s,t] > 0.05) 'ID-adoption in baseline (before 2050)'
          );
        $ENDFUNCTION

        @check_ID_BaselineAdoption()
    $ENDIF


@test_emm_unfccc_lulucf_aftercalibID_and_CCS(10);
