# ======================================================================================================================
# EA ID-ABATEMENT DATA
# ======================================================================================================================

    # ------------------------------------------------------------------------------------------------------------------
    # Sets
    # ------------------------------------------------------------------------------------------------------------------


    # ------------------------------------------------------------------------------------------------------------------
    # Import EA technology data
    # ------------------------------------------------------------------------------------------------------------------
    PARAMETERS
      tech_cost_data[techID,GSR_ag,energy19a,t]                     "Technology capital costs (mia. DKK) (DATA)"
      eInput_diff_data[techID,GSR_ag,energy19a,energy19,t]          "Technology change in energy use (PJ) (DATA)"
    ;
    # Read change in energy consumption (PJ) and costs (mia. kr.)
    execute_loaddc '..\Data\Abatement\EA_KF25\DORS_EA_TechClean_industri_MO_KF25.gdx' eInput_diff_data = eInput_diff.l;  
    execute_loaddc '..\Data\Abatement\EA_KF25\DORS_EA_TechClean_industri_MO_KF25.gdx' tech_cost_data = tech_cost.l;  


# ======================================================================================================================
# POTENTIALS
# ======================================================================================================================
    # ------------------------------------------------------------------------------------------------------------------
    # Growth adjustment and calculation of relative potentials 
    # ------------------------------------------------------------------------------------------------------------------
    PARAMETERS
        eInput_diff[techID,GSR_ag,energy19a,energy19,t]             "Technology change in energy use (PJ) - growth adjusted"
        potential_sh_GSR[techID,GSR_ag,energy19a,energy19,t]        "Technology potential (share of energy use changed by the technology)"
        d1tjekID_energyUse[techID,GSR_ag,energy19a,energy19,tMAC]   "Dummy for potentials with zero baseline energy use"
        d1_potential_sh_GSR[techID,GSR_ag,energy19a,energy19,tMAC]  "Dummy for technologies"
        d1tjek_potential_sh_GSR[techID,GSR_ag,energy19a,energy19,t] "Test that no technologies are excluded"
    ;

    # Growth adjusting EA change in energy use (PJ)
    eInput_diff[techID,GSR_ag,energy19a,energy19,tMAC]$(eInput_diff_data[techID,GSR_ag,energy19a,energy19,tMAC]) 
                                                                    = eInput_diff_data[techID,GSR_ag,energy19a,energy19,tMAC] * growth_factor[tMAC];

    # £LBS midlertidig sletning af teknologier i Nordsoeen
    eInput_diff[techID,GSR_ag,energy19a,energy19,tMAC]$(sameas[GSR_ag,'Nordsoeen']) = 0;

    # Calculate the technology's change in energy use relative to the baseline energy use of that energy good in the GSR
    potential_sh_GSR[techID,GSR_ag,energy19a,energy19,tMAC]$((sameas[tMAC,'2025'] or sameas[tMAC,'2030'] or sameas[tMAC,'2035']) and eInput_diff[techID,GSR_ag,energy19a,energy19,tMAC])
                                                                    = eInput_diff[techID,GSR_ag,energy19a,energy19,tMAC] / qREa_GSR[GSR_ag,energy19a,tMAC];

    # ------------------------------------------------------------------------------------------------------------------
    # Interpolation of potentials 
    # ------------------------------------------------------------------------------------------------------------------
    # Check if potentials are zero in 2035 because there is no energy use 
    d1tjekID_energyUse[techID,GSR_ag,energy19a,energy19,'2035']$(eInput_diff[techID,GSR_ag,energy19a,energy19,'2030']
                                                                    and not eInput_diff[techID,GSR_ag,energy19a,energy19,'2035']
                                                                    and not qREa_GSR[GSR_ag,energy19a,'2035']) = yes;

    # If above is true, then the potential in 2035 is set equal to that in 2030
    potential_sh_GSR[techID,GSR_ag,energy19a,energy19,'2035']$(d1tjekID_energyUse[techID,GSR_ag,energy19a,energy19,'2035'])
                                                                    = potential_sh_GSR[techID,GSR_ag,energy19a,energy19,'2030'];

    # Check if potentials are zero in 2025 because there is no energy use 
    d1tjekID_energyUse[techID,GSR_ag,energy19a,energy19,'2025']$(eInput_diff[techID,GSR_ag,energy19a,energy19,'2030']
                                                                    and not eInput_diff[techID,GSR_ag,energy19a,energy19,'2025']
                                                                    and not qREa_GSR[GSR_ag,energy19a,'2025']) = yes;

    # If above is true, then energy change in 2025 is set equal to that in 2030
    potential_sh_GSR[techID,GSR_ag,energy19a,energy19,'2025']$(d1tjekID_energyUse[techID,GSR_ag,energy19a,energy19,'2025'])
                                                                    = potential_sh_GSR[techID,GSR_ag,energy19a,energy19,'2030'];

    # Dummy for technologies with af potential
    d1_potential_sh_GSR[techID,GSR_ag,energy19a,energy19,tMAC]      = yes$(potential_sh_GSR[techID,GSR_ag,energy19a,energy19,tMAC]);

    # Checking that no potentials are excluded
    d1tjek_potential_sh_GSR[techID,GSR_ag,energy19a,energy19,tMAC]  = yes$((sameas[tMAC,'2025'] or sameas[tMAC,'2030'] or sameas[tMAC,'2035']) and
                                                                           eInput_diff[techID,GSR_ag,energy19a,energy19,tMAC] 
                                                                           and not d1_potential_sh_GSR[techID,GSR_ag,energy19a,energy19,tMAC]);

    # Interpolate potentials from 2025 to 2030
    potential_sh_GSR[techID,GSR_ag,energy19a,energy19,t]$(t.val > 2025 and t.val < 2030)
                                                                    = potential_sh_GSR[techID,GSR_ag,energy19a,energy19,'2025'] 
                                                                    + (potential_sh_GSR[techID,GSR_ag,energy19a,energy19,'2030'] 
                                                                        - potential_sh_GSR[techID,GSR_ag,energy19a,energy19,'2025'])/5 * (t.val - 2025);

    # Interpolate potentials from 2030 to 2035
    potential_sh_GSR[techID,GSR_ag,energy19a,energy19,t]$(t.val > 2030 and t.val < 2035)
                                                                    = potential_sh_GSR[techID,GSR_ag,energy19a,energy19,'2030'] 
                                                                    + (potential_sh_GSR[techID,GSR_ag,energy19a,energy19,'2035'] 
                                                                        - potential_sh_GSR[techID,GSR_ag,energy19a,energy19,'2030'])/5 * (t.val - 2030);

# ======================================================================================================================
# CAPITAL COSTS
# ======================================================================================================================
    # ------------------------------------------------------------------------------------------------------------------
    # Growth adjustment and calculation of relative capital costs
    # ------------------------------------------------------------------------------------------------------------------
    PARAMETERS
        tech_cost[techID,GSR_ag,energy19a,t]                        "Technology capital costs (mia. DKK) - growth adjusted"
        tech_cost_sh_GSR[techID,GSR_ag,energy19a,t]                 "Technology capital costs per reduced energy use"
        d1_tjek_potentials_cost[techID,GSR_ag,energy19a,t]          "Check that all potentials have a corresponding cost"
    ;

    # Growth adjusting EA capital costs (mia. DKK)
    tech_cost[techID,GSR_ag,energy19a,tMAC]$(sum(energy1919, d1_potential_sh_GSR[techID,GSR_ag,energy19a,energy1919,tMAC]))
                                                                    = tech_cost_data[techID,GSR_ag,energy19a,tMAC] * growth_factor[tMAC];

    # Calculate the capital cost per reduction of the baseline energy good
    tech_cost_sh_GSR[techID,GSR_ag,energy19a,tMAC]$((sameas[tMAC,'2025'] or sameas[tMAC,'2030'] or sameas[tMAC,'2035']) and 
                                                      sum(energy19$(sameas(energy19a,energy19)), potential_sh_GSR[techID,GSR_ag,energy19a,energy19,tMAC]*qREa_GSR[GSR_ag,energy19a,tMAC])) 
                                                                    = - tech_cost[techID,GSR_ag,energy19a,tMAC] 
                                                                        / sum(energy19$(sameas(energy19a,energy19)), 
                                                                                potential_sh_GSR[techID,GSR_ag,energy19a,energy19,tMAC]*qREa_GSR[GSR_ag,energy19a,tMAC]) ;

    # ------------------------------------------------------------------------------------------------------------------
    # Interpolation of capital costs
    # ------------------------------------------------------------------------------------------------------------------
    # Setting values when prices are 0 in 2025 or 2035 and hence eliminating interpolation of prices starting or ending with 0
    tech_cost_sh_GSR[techID,GSR_ag,energy19a,'2025']$(not tech_cost_sh_GSR[techID,GSR_ag,energy19a,'2025'] 
                                                      and tech_cost_sh_GSR[techID,GSR_ag,energy19a,'2030']) = tech_cost_sh_GSR[techID,GSR_ag,energy19a,'2030'];
    tech_cost_sh_GSR[techID,GSR_ag,energy19a,'2025']$(not tech_cost_sh_GSR[techID,GSR_ag,energy19a,'2025'] and not tech_cost_sh_GSR[techID,GSR_ag,energy19a,'2030'] 
                                                      and tech_cost_sh_GSR[techID,GSR_ag,energy19a,'2035']) = tech_cost_sh_GSR[techID,GSR_ag,energy19a,'2035'];
    tech_cost_sh_GSR[techID,GSR_ag,energy19a,'2035']$(not tech_cost_sh_GSR[techID,GSR_ag,energy19a,'2035']
                                                      and tech_cost_sh_GSR[techID,GSR_ag,energy19a,'2030']) = tech_cost_sh_GSR[techID,GSR_ag,energy19a,'2030'];
    tech_cost_sh_GSR[techID,GSR_ag,energy19a,'2035']$(not tech_cost_sh_GSR[techID,GSR_ag,energy19a,'2035'] and not tech_cost_sh_GSR[techID,GSR_ag,energy19a,'2030']
                                                      and tech_cost_sh_GSR[techID,GSR_ag,energy19a,'2025']) = tech_cost_sh_GSR[techID,GSR_ag,energy19a,'2025'];

    # Interpolate costs between 2025 and 2030 
    tech_cost_sh_GSR[techID,GSR_ag,energy19a,t]$(t.val > 2025 and t.val < 2030 and tech_cost_sh_GSR[techID,GSR_ag,energy19a,'2025'] and tech_cost_sh_GSR[techID,GSR_ag,energy19a,'2030'])
                                                                    = tech_cost_sh_GSR[techID,GSR_ag,energy19a,'2025'] 
                                                                    + (tech_cost_sh_GSR[techID,GSR_ag,energy19a,'2030'] 
                                                                        - tech_cost_sh_GSR[techID,GSR_ag,energy19a,'2025'])/5 * (t.val - 2025);

    # Interpolate costs between 2030 and 2035 
    tech_cost_sh_GSR[techID,GSR_ag,energy19a,t]$(t.val > 2030 and t.val < 2035 and tech_cost_sh_GSR[techID,GSR_ag,energy19a,'2030'] and tech_cost_sh_GSR[techID,GSR_ag,energy19a,'2035'])
                                                                    = tech_cost_sh_GSR[techID,GSR_ag,energy19a,'2030'] 
                                                                    + (tech_cost_sh_GSR[techID,GSR_ag,energy19a,'2035'] 
                                                                        - tech_cost_sh_GSR[techID,GSR_ag,energy19a,'2030'])/5 * (t.val - 2030);

    # Interpolate costs between 2025 and 2035 (if there is no value in 2030)
    tech_cost_sh_GSR[techID,GSR_ag,energy19a,t]$(t.val > 2025 and t.val < 2035 and tech_cost_sh_GSR[techID,GSR_ag,energy19a,'2025'] and tech_cost_sh_GSR[techID,GSR_ag,energy19a,'2035'] 
                                                                               and not tech_cost_sh_GSR[techID,GSR_ag,energy19a,'2030'])
                                                                    = tech_cost_sh_GSR[techID,GSR_ag,energy19a,'2025'] 
                                                                    + (tech_cost_sh_GSR[techID,GSR_ag,energy19a,'2035'] 
                                                                        - tech_cost_sh_GSR[techID,GSR_ag,energy19a,'2025'])/10 * (t.val - 2025);

    # Check if there are potentials without a corresponding cost
    d1_tjek_potentials_cost[techID,GSR_ag,energy19a,t] = yes$(sum(energy19, potential_sh_GSR[techID,GSR_ag,energy19a,energy19,t]) and not tech_cost_sh_GSR[techID,GSR_ag,energy19a,t]);


# ======================================================================================================================
# CORRECTION OF POTENTIALS IF THE TOTAL POTENTIAL EXCEES BASELINE ENERGY USE
# ======================================================================================================================
    PARAMETERS
        potential_sh_GSR_SUM[GSR_ag,energy19a,energy19,t]                 "Total potential for each energy good within a GSR"
        d1tjek_potential_sh_GSR_SUM[techID,GSR_ag,energy19a,energy19,t]   "Total potential exceeds baseline energy use"
        scale_potential[GSR_ag,energy19a,tMAC]                            "Total potential for each energy good within a GSR - without energy19-dimension"
        potential_sh_GSR_korr[GSR_ag,energy19a,t]                         "Scaling of potentials (Report variable)"
    ;

    # Sum potentials over technologies
    potential_sh_GSR_SUM[GSR_ag,energy19a,energy19,tMAC]            = sum(techID, potential_sh_GSR[techID,GSR_ag,energy19a,energy19,tMAC]);

    # Identifies all sums where total potential for reducing the existing energy good exceeds baseline energy use
    d1tjek_potential_sh_GSR_SUM[techID,GSR_ag,energy19a,energy19,tMAC] 
                                                                    = yes$(abs(potential_sh_GSR_SUM[GSR_ag,energy19a,energy19,tMAC]) > 1
                                                                            and sameas[energy19a,energy19] and potential_sh_GSR[techID,GSR_ag,energy19a,energy19,tMAC]);

    # Excluding the energy19-dimension from 'potential_sh_GSR_SUM'
    scale_potential[GSR_ag,energy19a,tMAC]                          = sum(energy19$(sum(techID, d1tjek_potential_sh_GSR_SUM[techID,GSR_ag,energy19a,energy19,tMAC])), 
                                                                                    potential_sh_GSR_SUM[GSR_ag,energy19a,energy19,tMAC]);

    # Adjust potentials (both the potential for reducing the existing energy good and the potential for the new energy good) given that potential exceeds energy use in baseline
    potential_sh_GSR[techID,GSR_ag,energy19a,energy19,tMAC]$(sum(energy1919, d1tjek_potential_sh_GSR_SUM[techID,GSR_ag,energy19a,energy1919,tMAC])) 
                                                                    = potential_sh_GSR[techID,GSR_ag,energy19a,energy19,tMAC]/scale_potential[GSR_ag,energy19a,tMAC]*(-0.9999);

    # Calculates the scaling of the potentials (reporting parameter)
    potential_sh_GSR_korr[GSR_ag,energy19a,tMAC]$(sum((techID,energy19), d1tjek_potential_sh_GSR_SUM[techID,GSR_ag,energy19a,energy19,tMAC])) 
                                                                    = (-0.9999)/scale_potential[GSR_ag,energy19a,tMAC];

    # Check that reduction potential is less than initial energy consumption
    LOOP((GSR_ag,energy19a,energy19,t)$(tMAC[t] and sameas[energy19a,energy19]),
        tjek = sum(techID, potential_sh_GSR[techID,GSR_ag,energy19a,energy19,t]);
        ABORT$(abs(tjek) > 1) tjek, "Reduction potential is greater than initial energy consumption";
    );


# ======================================================================================================================
# SECTOR AND PURPOSE SPECIFIC POTENTIALS
# ======================================================================================================================
    PARAMETERS
        thetaID_in[techID,s,purpose,energy19a,energy19,t]                   "Technology potential for each sector and purpose"
        thetaID_k_in[techID,s,purpose,energy19a,t]                          "Technology capital costs for each sector and purpose"
    ;

    # Mapping from GSR to sector and purpose (the mapping is conditioned on the energy activity existing in baseline)
    thetaID_in[techID,s,purpose,energy19a,energy19,tMAC]            = sum(GSR_ag$(mapGrREFORM2GSR[purpose,energy19a,s,GSR_ag,tMAC] and qREa.l[purpose,energy19a,s,tMAC]), 
                                                                                    potential_sh_GSR[techID,GSR_ag,energy19a,energy19,tMAC]);
    thetaID_k_in[techID,s,purpose,energy19a,tMAC]                   = sum(GSR_ag$(mapGrREFORM2GSR[purpose,energy19a,s,GSR_ag,tMAC] and qREa.l[purpose,energy19a,s,tMAC]), 
                                                                                    tech_cost_sh_GSR[techID,GSR_ag,energy19a,tMAC]);

    # We scale capital costs with the sector-specific investment price in baseline
    thetaID_k_in[techID,s,purpose,energy19a,tMAC]$(thetaID_k_in[techID,s,purpose,energy19a,tMAC]) 
                                                                    = thetaID_k_in[techID,s,purpose,energy19a,tMAC]/pI_s.l['iM',s,tMAC];

    # Potentials and capital costs are held constant after the last year on the MAC-curve
    thetaID_in[techID,s,purpose,energy19a,energy19,tx0]$(tx0.val>tMAC_end.val and sum(emm,d1EmmProdE[s,tx0,emm,purpose,energy19a])) 
                                                                    = thetaID_in[techID,s,purpose,energy19a,energy19,tMAC_end];
    thetaID_k_in[techID,s,purpose,energy19a,tx0]$(tx0.val>tMAC_end.val and sum(emm,d1EmmProdE[s,tx0,emm,purpose,energy19a])) 
                                                                    = thetaID_k_in[techID,s,purpose,energy19a,tMAC_end];

    # ------------------------------------------------------------------------------------------------------------------
    # Remove tehnologies that have a negative use of electricity where there is no baseline use of electricity
    # ------------------------------------------------------------------------------------------------------------------
    PARAMETERS
        thetaID_negativ_el[techID,purpose,energy19a,energy19,s,t]           "Technologies with a negative use of electricity"
        tjek_elek_pot[purpose,s,t]                                          "Negative use of electricity from technologies bigger than baseline electricity use"
        removed_technologies[techID,purpose,energy19a,energy19,s,t]         "Removed technologies because of negative use of electricity"
    ;
    # All technologies with a negative use of electricity
    thetaID_negativ_el[techID,purpose,energy19a,'electricity',s,t]$(thetaID_in[techID,s,purpose,energy19a,'electricity',t]<0)  = thetaID_in[techID,s,purpose,energy19a,'electricity',t];

    # Sector/purpose combinations where the negative use of electricity from technologies are bigger than the baseline use of electricity
    tjek_elek_pot[purpose,s,t]                                      = yes$(abs(sum((techID,energy19a)$(thetaID_negativ_el[techID,purpose,energy19a,'electricity',s,t]), thetaID_negativ_el[techID,purpose,energy19a,'electricity',s,t]))
                                                                                                            > qREgj.l[purpose,'electricity',s,t]);


    # Technologies in the above sector/purpose combinations that have a negative use of electricity
    removed_technologies[techID,purpose,energy19a,energy19,s,t]     = yes$(tjek_elek_pot[purpose,s,t] and thetaID_negativ_el[techID,purpose,energy19a,'electricity',s,t]
                                                                            and thetaID_in[techID,s,purpose,energy19a,energy19,t]);



    # Remove potentials from the above technologies
    thetaID_in[techID,s,purpose,energy19a,energy19,t]$(removed_technologies[techID,purpose,energy19a,energy19,s,t])         = 0;

    # Remove cost for the above technologies
    thetaid_k_in[techID,s,purpose,energy19a,t]$(sum(energy19, removed_technologies[techID,purpose,energy19a,energy19,s,t])) = 0;
    
    #£
    set onlytheses[s]/
        01011	"Plant production"
        01012	"Organic plant production"
        01020	"Horticulture"
        01031	"Cattle (incl. milk production)"
        01032	"Organic cattle (incl. milk production"
        01051	"Pig farmers"
        01052	"Organic pig farmers"
        01061	"Poulty"
        01062	"Organic poultry"
        01070	"Fur animals"
        01080	"Agricultural contractor"
        02000	"Forestry"
        03000	"Fishing"
        0600a	"Extration"
        10020	"Manufacture of fish products"
        10030	"Manufacture of dairy products"
        10040	"Manufacture of bread products"
        10120	"Manufacture of beverages and tobacco"
        13150	"Manufacture of machines and electronics"
        16000	"Manufacture of wood and wood products"
        19000	"Oil refinery etc."
        20000	"Manufacture of chemicals"
        21000	"Pharmaceuticals"
        25000	"Other manufacture industries"
        35011	"Electricity and heating production"
        35012	"Transmission, distribution and trading of eletricity"
        35002	"Manufacture and distribution of gas"
        36000	"Water collection, purification and supply"
        37000	"Sewerage"
        38391	"Collection of non-harzardous and hazardous waste "
        38392	"Treatment and disposal of non-hazardous and hazardous waste"
        38393	"Disposal of energy waste"
        41430	"Construction"
        45000	"Wholesale and retail trade and repair of motor vehicles and motorcycles"
        46000	"Wholesale"
        47000	"Retail sale"
        49011	"Passenger transport by local and distance trains"
        49024	"Busses, local"
        49031	"Road freight transport and transport via pipelines"
        50001	"Domestic passenger and freight transport on water"
        51001	"Domestic passenger and freight transport by air plane"
        51009	"International passenger and freight transport by air plane"
        55560	"Services predominantly to private consumers"
        64000	"Financial sector"
        68203	"Housing sector"
        71000	"Services predominantly to business and exports  "
        53000	"Postal and courier activities"
        10011	"Manufacture of bovine meat products"
        10012	"Manufacture of pig meat"
        10013	"Manufacture of poultry"
        23001	"Cement production"
        23002	"Other mineralogical"
        49509	"International transport by sea and land"
        off	"Offentlig"
    /;

    # set onlythise19[energy19]/
	# "Crude oil"    
	# "Semi-refined oil"
	# "LVN" 
	# "Refinery gas" 							
	# "Gasoline for transport"        
	# "Jet petroleum"                       
	# "Oil products"          			        
	# "Bunkering of Danish operated vessels on foreign territory"                        
	# "Diesel for transport" 			    	
	# "Natural gas (Extraction)"                
	# "Natural gas incl. biongas"        
	# "Coal and coke"                           
	# "Waste"           
	# "Wood waste" 
	# "Renewable energy"                        
	# "Straw for energy purposes"               
	# "Firewood and woodchips"                  
	# "Wood pellets"   
	# "Biogas"         
	# "Biodiesel"
	# "bioethanol"
	# "Biooil" 
	# "Heat pumps"                              
                       
	# "District heat"
	# "Bunkering of Danish operated planes on foreign territory"  
	# "Bunkering of Danish operated trucks on foreign territory"
	# "Waste oil"
	# "Jet fuel, sustainable"
	# "El from y and m"
	# "electricity"
    # /;


    thetaID_in[techID,s,purpose,energy19a,energy19,t]$(thetaID_in[techID,s,purpose,energy19a,energy19,t] and not onlytheses[s])         = 0;
    # thetaID_in[techID,s,purpose,energy19a,energy19,t]$(thetaID_in[techID,s,purpose,energy19a,energy19,t] and not onlythise19[energy19a])         = 0;

    # Remove cost for the above technologies
    thetaid_k_in[techID,s,purpose,energy19a,t]$(sum(energy19, thetaID_in[techID,s,purpose,energy19a,energy19,t]) and not onlytheses[s]) = 0;
    # thetaid_k_in[techID,s,purpose,energy19a,t]$(sum(energy19, thetaID_in[techID,s,purpose,energy19a,energy19,t]) and not onlythise19[energy19a]) = 0;

# ======================================================================================================================
# UNDLOAD EXOGENOUS VALUES (thetaID and thetaID_K)
# ======================================================================================================================
    thetaID.l[techID,purpose,energy19a,energy19,s,tx0]$(thetaID_in[techID,s,purpose,energy19a,energy19,tx0])              = thetaID_in[techID,s,purpose,energy19a,energy19,tx0];
    thetaid_k.l[techID,purpose,energy19a,s,tx0]$(thetaid_k_in[techID,s,purpose,energy19a,tx0])                     = thetaid_k_in[techID,s,purpose,energy19a,tx0];

# ======================================================================================================================
# SET DUMMIES
# ======================================================================================================================
    d1thetaID[techID,purpose,energy19a,energy19,s,t]$(thetaID.l[techID,purpose,energy19a,energy19,s,t]) = yes;

    #Hack
    d1thetaID['t3','in_ETS','natural gas incl. biongas',energy19,'01020',t]$(t.val<2028) = no;

    d1thetaID_k[techID,purpose,energy19a,s,t]$(sum(energy19, d1thetaID[techID,purpose,energy19a,energy19,s,t])) = yes;
    d1thetaID_k_end[techID,purpose,energy19a,s,t]$(d1thetaID_k[techID,purpose,energy19a,s,t]
                                           and not d1thetaID_k[techID,purpose,energy19a,s,t+1]) = yes;


    # ------------------------------------------------------------------------------------------------------------------
    # Initialisation
    # ------------------------------------------------------------------------------------------------------------------
    option clear = uREExID;
    uREExID.l[purpose,energy19a,energy19,s,t] = 1$(sameas[energy19,energy19a] and d1pREgj[purpose,energy19,s,t]);

    option clear = uREE;
    uREE.l[purpose,energy19a,energy19,s,t] = uREExID.l[purpose,energy19a,energy19,s,t];

    option clear = qREE;
    qREE.l[purpose,energy19a,energy19,s,t] = qREgj.l[purpose,energy19,s,t]$(sameas[energy19,energy19a] and d1pREgj[purpose,energy19,s,t]);

    option clear = d1qREE;
    d1qREE[purpose,energy19a,energy19,s,t] = yes$((qREE.l[purpose,energy19a,energy19,s,t] and not sum(energy1919,d1vREE_transport[purpose,energy1919,energy19,s,t])) or sum(techID, d1thetaID[techID,purpose,energy19a,energy19,s,t]));
          

    # ------------------------------------------------------------------------------------------------------------------
    # Check that there are energy prices and emissions factors for new energy use
    # ------------------------------------------------------------------------------------------------------------------
    PARAMETERS
        d1EmmProdE_ABnew[s,t,emm_eq,purpose,energy19]
    ;

    option clear = d1pRE_base_ABnew;
    option clear = d1pREgj_ABnew;
    option clear = d1qREgj_ABnew;

    # Energy use
    d1qREgj_ABnew[purpose,energy19,s,t]$(sum((techID,energy19a)$(not sameas[energy19a,energy19]), d1thetaID[techID,purpose,energy19a,energy19,s,t])
                                         and not d1qREgj[purpose,energy19,s,t]) = yes;

    d1qREgj[purpose,energy19,s,t]$(d1qREgj_ABnew[purpose,energy19,s,t]) = yes;

    # Emissions
    d1EmmProdE_ABnew[s,t,'CO2ubio',purpose,energy19]$(d1qREgj_ABnew[purpose,energy19,s,t]
                                                    and uEmmHardCoded['CO2ubio',energy19] 
                                                    and not d1EmmProdE[s,t,'CO2ubio',purpose,energy19]) = yes;

    d1EmmProdE_ABnew[s,t,'CO2bio',purpose,energy19]$(d1qREgj_ABnew[purpose,energy19,s,t]
                                                    and uEmmHardCoded['CO2bio',energy19] 
                                                    and not d1EmmProdE[s,t,'CO2bio',purpose,energy19]) = yes;

    d1EmmProdE_ABnew[s,t,'CO2e',purpose,energy19]$(d1EmmProdE_ABnew[s,t,'CO2ubio',purpose,energy19]) = yes;

    d1EmmProdE[s,t,emm_eq,purpose,energy19]$(d1EmmProdE_ABnew[s,t,emm_eq,purpose,energy19]) = yes; 

    # Update emission factors
    uEmmProdE.fx[s,t,'CO2ubio',energy19]$(sum(purpose, d1EmmProdE_ABnew[s,t,'CO2ubio',purpose,energy19]) and not uEmmProdE.l[s,t,'CO2ubio',energy19]) = uEmmHardCoded['CO2ubio',energy19]; 
    uEmmProdE.fx[s,t,'CO2bio',energy19]$(sum(purpose, d1EmmProdE_ABnew[s,t,'CO2bio',purpose,energy19]) and not uEmmProdE.l[s,t,'CO2bio',energy19])   = uEmmHardCoded['CO2bio',energy19]; 

    # Update CCS-factors
    uEOPProdE.fx[purpose,energy19,s,t,emm]$(d1EmmProdE_ABnew[s,t,emm,purpose,energy19] and not uEOPProdE.l[purpose,energy19,s,t,emm]) = 1; 

    # Energy prices
    d1pRE_base_ABnew[purpose,energy19,s,t]$(d1qREgj_ABnew[purpose,energy19,s,t]
                                            and not nonpricedenergy[energy19]) = yes;


    d1pRE_base[purpose,energy19,s,t]$(d1pRE_base_ABnew[purpose,energy19,s,t]) = yes;

    #Opdaterer bionaturgasandele (£AKB: Mangler bionaturgas dummy)
    sBioNatgas.l[purpose,r,t]$(d1qREgj_ABnew[purpose,'natural gas incl. biongas',r,t]) = sBioNatgasAvgAdj.l[t];


    #### Update tax rates and dummies

    #  Marginal SO2-tax
    # tSO2_REmarg.l[purpose,energy19,r,t]$(d1qREgj_ABnew[purpose,energy19,r,t] and energy19_SKM[energy19]) 
    #     = sum(tREbase_SKM$(maptREbase_SKM2qRE(tREbase_SKM,r,purpose,energy19)), tSO2_REmarg_SKM.l(tREbase_SKM,t)); #Exogenous marginal tax

    #  Marginal energy tax
    tEAFG_REmarg.l[purpose,energy19,s,t]$(d1qREgj_ABnew[purpose,energy19,s,t]) 
    	= sum((categoryENS,GSR_ag,tREbase_SKM)$(sENS2GR(categoryENS, GSR_ag, purpose, energy19, s) 
    											and tREbase_SKM_2_ENS(tREbase_SKM,categoryENS,GSR_ag,energy19) 
    											and d1qREgj[purpose,energy19,s,t] 
    											and not sameas[energy19,'Jet petroleum']), tEAFG_REmarg_SKM.l[tREbase_SKM,t]);

    tEAFG_REmarg.l[purpose_xt,'electricity','64000',t]$(d1qREgj_ABnew[purpose_xt,'electricity','64000',t]) = tEAFG_REmarg_SKM.l['el_ikke-proces',t]; #Finansiel sektor (strengt taget momsfritagne/lønsumsomfattede vsh) betaler fuld elafgift, jf. mail fra Sebastian Lind SKM d. 22.5.2024. Kh AKB
    	  	
    #Test af indlæste energiafgifter 
    LOOP((purpose,energy19,s),
      tjek = tEAFG_REmarg.l[purpose,energy19,s,'2025'];
      ABORT$(tjek > smax(tREbase_SKM,tEAFG_REmarg_SKM.l(tREbase_SKM,'2025'))) tjek, "De indlæste energiafgifter må ikke overstige max i input fra data - hvis det gør er der fejl i mappingen tREbase_SKM_2_ENS";
     );

    #  Marginal CO2 tax
    tCO2_REmarg.l[purpose,energy19,s,t,'CO2ubio']$(d1qREgj_ABnew[purpose,energy19,s,t]) = sum((categoryENS,GSR_ag,tREbase_SKM)$(sENS2GR(categoryENS, GSR_ag, purpose, energy19, s) and tREbase_SKM_2_ENS(tREbase_SKM,categoryENS,GSR_ag,energy19) and qEmmProdE.l[s,t,'CO2ubio',purpose,energy19]), tCO2_REmarg_SKM.l[tREbase_SKM,t]);
    tCO2_REmarg.l[purpose,'Natural gas incl. biongas',s,t,'CO2bio']$(d1qREgj_ABnew[purpose,'Natural gas incl. biongas',s,t]) = sum((categoryENS,GSR_ag,tREbase_SKM)$(sENS2GR(categoryENS, GSR_ag, purpose, 'Natural gas incl. biongas', s) and tREbase_SKM_2_ENS(tREbase_SKM,categoryENS,GSR_ag,'Natural gas incl. biongas') and qEmmProdE.l[s,t,'CO2bio',purpose,'natural gas incl. biongas'] and qEmmProdE.l[s,t,'CO2ubio',purpose,'natural gas incl. biongas']), tCO2_REmarg_SKM.l[tREbase_SKM,t]);

    #Test af indlæste afgifter (vi laver stikprøve i 2025 - egentlig burde man nok køre over alle år)
      LOOP((purpose,energy19,s),
      #Tjek for CO2ubio
      tjek = tCO2_REmarg.l[purpose,energy19,s,'2025','CO2ubio'];
      ABORT$(tjek > smax(tREbase_SKM,tCO2_REmarg_SKM.l(tREbase_SKM,'2025'))) tjek, "De indlæste CO2-afgifter må ikke overstige max i input fra data - hvis det gør er der fejl i mappingen tREbase_SKM_2_ENS";
      #Tjek for CO2bio
      tjek = tCO2_REmarg.l[purpose,energy19,s,'2025','CO2bio'];
      ABORT$(tjek > smax(tREbase_SKM,tCO2_REmarg_SKM.l(tREbase_SKM,'2025'))) tjek, "De indlæste CO2-afgifter må ikke overstige max i input fra data - hvis det gør er der fejl i mappingen tREbase_SKM_2_ENS";
      );

    #NOx-afgift på ny energi
    tNOx_RE.l[purpose,energy19,r,t]$(d1qREgj_ABnew[purpose,energy19,r,t] and tNOx_REomregner[energy19] and not (sameas[r,'35001'] or sameas[r,'38393'])) #Vi antager at forbrændingsanlæggene har så meget røgteknologi at de slipper for NOx-afgift (grov antagelse, kh Asbjørn)
    	= 1/tNOx_REomregner[energy19];
    d1NOx_RE[purpose,energy19,r,t]$(tNOx_RE.l[purpose,energy19,r,t] and d1qREgj_ABnew[purpose,energy19,r,t]) = yes;


    #Ad hoc løsning
    tVAT_RE.l[purpose,energy19,'64000',t]$(d1qREgj_ABnew[purpose,energy19,'64000',t]) = 0.25;
    tVAT_RE.l[purpose,energy19,'off',t]$(d1qREgj_ABnew[purpose,energy19,'off',t]) = 0.25;

    # 		#   $FUNCTION compute_initial_taxvalues():


    #£AKB: Går det her godt?
    vtCO2_REmarg.l[purpose,energy19,r,t]$(d1qREgj_ABnew[purpose,energy19,r,t])                                       =  tCO2_REmarg.l[purpose,energy19,r,t,'CO2ubio'] * qEmmProdE.l[r,t,'CO2ubio',purpose,energy19]*growth_factor[t]/10**6;
    vtCO2_REmarg.l[purpose,'natural gas incl. biongas',r,t]$(d1qREgj_ABnew[purpose,'natural gas incl. biongas',r,t]) =  tCO2_REmarg.l[purpose,'natural gas incl. biongas',r,t,'CO2bio']  * qEmmProdE.l[r,t,'CO2bio',purpose,'natural gas incl. biongas']*growth_factor[t]/10**6;

    # TAXES 
    d1EAFG_RE[purpose,energy19,r,t]$(tEAFG_REmarg.l[purpose,energy19,r,t] and d1qREgj_ABnew[purpose,energy19,r,t]) = yes;
    d1SO2_RE[purpose,energy19,r,t] = yes$(vtSO2_RE.l[purpose,energy19,r,t] and d1qREgj[purpose,energy19,r,t]);
    d1NOx_RE[purpose,energy19,r,t]$(tNOx_RE.l[purpose,energy19,r,t] and d1qREgj_ABnew[purpose,energy19,r,t]) = yes;


    # CO2
    d1CO2_RE[purpose,energy19,r,tForecast]            = yes$(sum(emm_eq, tCO2_REmarg.l[purpose,energy19,r,tForecast,emm_eq]) and d1qREgj[purpose,energy19,r,tForecast]); #I data favner vi begge muligheder
    d1CO2_REmarg[purpose,energy19,r,tForecast,emm_eq] = yes$(tCO2_REmarg.l[purpose,energy19,r,tForecast,emm_eq]);
    d1CO2_REmarg_sumemm[purpose,energy19,r,tForecast] = yes$(sum(emm_eq, d1CO2_REmarg[purpose,energy19,r,tForecast,emm_eq]));

    # RETAIL AND WHOLESALE ENERG MARGINS 
    #Vi lægger hele leveringsomkostningen på engrossalgssiden 
    pEAV_RE.l[purpose,energy19,r,t]$(d1qREgj_ABnew[purpose,energy19,r,t]) = KF25_CostDel_RE[energy19,r,t];
    fpEAV_RE.l[purpose,energy19,r,t]$(d1qREgj_ABnew[purpose,energy19,r,t]) = pEAV_RE.l[purpose,energy19,r,t]/pY_CET.l['WholeAndRetailSaleMarginE','46000',t] -1;
    fpEAV_RE.l[purpose,energy19,r,t]$(d1qREgj_ABnew[purpose,energy19,r,t] and t.val>tBF_calib_end.val) = fpEAV_RE.l[purpose,energy19,r,tBF_calib_End];
    d1EAV_RE[purpose,energy19,r,t]$(d1qREgj_ABnew[purpose,energy19,r,t] and fpEAV_RE.l[purpose,energy19,r,t]) = yes;

    # Update dummy on ETS quotas 
    d1tCO2_ETS_marg[purpose,energy19,r,t]$(d1qREgj_ABnew[purpose,energy19,r,t] and (d1EmmProdE[r,t,'CO2ubio',purpose,energy19] or (d1EmmProdE[r,t,'CO2bio',purpose,energy19] and sameas[energy19,'Natural gas incl. biongas'])) and d1CO2_ETS[r,t] and sameas[purpose,'in_ETS']) = yes;


    d1CO2_ETS2_marg[purpose,energy19,r,t]$(tCO2_ETS2.l[t] and not sLan[r] 
                                                    and d1qREgj_ABnew[purpose,energy19,r,t]
                                                    and not sameas[purpose,'in_ETS'] 
                                                    and (d1EmmProdE[r,t,'CO2ubio',purpose,energy19] or (d1EmmProdE[r,t,'CO2bio',purpose,energy19] and sameas[energy19,'Natural gas incl. biongas']))
                                                    and not sameas[energy19,'District heat']) = yes;
    d1CO2_ETS2[r,t]                         = yes$(sum((purpose,energy19),d1CO2_ETS2_marg[purpose,energy19,r,t]));


    d1CO2_ETS2_marg[purpose,energy19,r,t]$(tCO2_ETS2.l[t] and not sLan[r] 
                                                    and d1qREgj_ABnew[purpose,energy19,r,t]
                                                    # and d1pRE_base_ABnew[purpose,energy19,r,t]
                                                    and not sameas[purpose,'in_ETS'] 
                                                    and (d1EmmProdE[r,t,'CO2ubio',purpose,energy19] or (d1EmmProdE[r,t,'CO2bio',purpose,energy19] and sameas[energy19,'Natural gas incl. biongas']))
                                                    and not sameas[energy19,'District heat']) = yes;
    d1CO2_ETS2[r,t]                         = yes$(sum((purpose,energy19),d1CO2_ETS2_marg[purpose,energy19,r,t]));


    #This needs to be updated after update of emissions 
    parameter d1tRE_new_aba[purpose,energy19,r,t];
    d1tRE_new_aba[purpose,energy19,r,t] = d1tRE[purpose,energy19,r,t];
    d1tRE[purpose,energy19,r,t]$(d1qREgj_ABnew[purpose,energy19,r,t] and (d1EAFG_RE[purpose,energy19,r,t] 
                                                                                          or d1SO2_RE[purpose,energy19,r,t] 
                                                                                          or d1PSO_RE[purpose,energy19,r,t] 
                                                                                          or d1NOx_RE[purpose,energy19,r,t] 
                                                                                          or d1CO2_RE[purpose,energy19,r,t] 
                                                                                          or d1VAT_RE[purpose,energy19,r,t] 
                                                                                          or d1tCO2_ETS_marg[purpose,energy19,r,t]
                                                                                          or d1CO2_ETS2_marg[purpose,energy19,r,t])) = yes;

    d1tRE_new_aba[purpose,energy19,r,t] = yes$(d1tRE[purpose,energy19,r,t] and not d1tRE_new_aba[purpose,energy19,r,t]);

    #We add elements to d1tRE to add calibENS to prices where there currently are no taxes on energy goods (i.e. cases where d1pRE_base is on, but d1tRE is not. Consider an alternative method of adding vtCalibENS to marginal prices directly)
    d1tRE[purpose,energy19,r,t]$(t.val > 2019 and t.val<%endhere% and thesesecon[r] and d1pREgj[purpose,energy19,r,t] and not eNotInEnergyNest[purpose,energy19,r,t] and theseLinearly[purpose,energy19,r,t]) = yes;


    d1pREgj_ABnew[purpose,energy19,r,t] = yes$(d1pREgj[purpose,energy19,r,t]);

    option clear = d1pREgj;
    d1pREgj[purpose,energy19,r,t]$(d1pRE_base[purpose,energy19,r,t] or d1tRE[purpose,energy19,r,t] or d1pREown[purpose,energy19,r,t]) = yes;
    d1pREgj_ABnew[purpose,energy19,r,t] = yes$(d1pREgj[purpose,energy19,r,t] and not sum(energy19a, d1vREE_transport[purpose,energy19a,energy19,r,t]) and not d1pREgj_ABnew[purpose,energy19,r,t]);

    d1vREgj[purpose,energy19,r,t]   = yes$(d1pREgj[purpose,energy19,r,t] and d1qREgj[purpose,energy19,r,t]);