# ======================================================================================================================
#  INTEGRATION AND CALIBRATION OF AGRICULTURAL MODULE
# ======================================================================================================================
# A brief overview:
#
# 0) Hacks that shouldn't be necessary 
#
# 1) In the first section various binary handles are introduced to turn different parts of the calibration on/off. Do not change default settings.
#
# 2) In the second section variables and groups used specifically for the integration and calibration of the agricultural module are created 
#
# 3) In the third section additional data and initial values are 
#
# 4) In the fourth section blocks of equations for integration are set up, split up on 5 sub-sections
#
#   4a) Plant production, prices, productivity, fertilizer, and land-use
#   4b) Animal production, prices, productivity and manure production
#   4c) Additional equations for agriculture as a whole
#   4d) Non-energy emissions from the Climate Outlook
#   4e) Markups in food processing sectors 
#
# 5) In the fifth stage we set up and calibrate the agricultural module in a partial set-up
#
# 6) In the sixth stage we set up and calibrate the agricultural module fully integrated with the CGE-model.
#

set reportpPlant_land/tobinsQ, tax_shield,instcost,hectaresubsidy, landtax, unobservable,j/;
set reportuc/tobinsQ, t_cap,tax_shield, instcost, j/;

parameter report_ucland[plant_sectors,reportpPlant_land,t], report_uccap_plant[plant_sectors,plant_pK,reportuc,t], report_uccap_ani[ani_sectors,ani_pK,reportuc,t];

$FUNCTION report_uc():

report_ucland[plant_sectors,'tobinsQ',t]$(tx0E[t]) =  ((1+rFirmsLand.l[plant_sectors,t]) *pLand.l[t] - pLand.l[t+1]*fv)/((1-tCorp.l[t+1])*fv); #*abs(pPlant.l[plant_sectors,'land',t+1]));
report_ucland[plant_sectors,'tax_shield',t]$(tx0E[t]) = 			- ((rFirmsLand.l[plant_sectors,'2025'] - rBonds.l[plant_sectors,'2025']*(1-tCorp.l[t+1])) * sDebt2j.l[plant_sectors,t] * pLand.l[t])$(t.val<2025)/((1-tCorp.l[t+1])*fv) #*abs(pPlant.l[plant_sectors,'land',t+1]))
		                                                        	- ((rFirmsLand.l[plant_sectors,t+1] - rBonds.l[plant_sectors,t+1]*(1-tCorp.l[t+1])) * sDebt2j.l[plant_sectors,t] * pLand.l[t])$(t.val>=2025)/((1-tCorp.l[t+1])*fv); #*abs(pPlant.l[plant_sectors,'land',t+1]));
report_ucland[plant_sectors,'instcost',t]$(tx0E[t]) = (1-tCorp.l[t+1])* pPlant.l[plant_sectors,'grossprod',t+1] * fp * dInstcostlandTp1.l[plant_sectors,t+1] *fq/((1-tCorp.l[t+1])*fv); #*abs(pPlant.l[plant_sectors,'land',t+1])); 
report_ucland[plant_sectors,'hectaresubsidy',t]$(tx0E[t]) = 	- (1-tCorp.l[t+1]) * tHectareSubsidy.l[t+1] *fv/((1-tCorp.l[t+1])*fv); #*abs(pPlant.l[plant_sectors,'land',t+1]));
report_ucland[plant_sectors,'landtax',t]$(tx0E[t]) = (1-tCorp.l[t+1]) * tLand.l[plant_sectors,t+1] * pLand.l[t]/((1-tCorp.l[t+1])*fv); #*abs(pPlant.l[plant_sectors,'land',t+1]));
report_ucland[plant_sectors,'unobservable',t]$(tx0E[t]) = 	- (1-tCorp.l[t+1]) * sum(idxUnobservable,  pLandvalueFromUnobserved.l[idxUnobservable, plant_sectors,t+1]) /((1-tCorp.l[t+1])*fv); #*abs(pPlant.l[plant_sectors,'land',t+1]));
report_ucland[plant_sectors,'j',t]$(tx0E[t]) = jpK_land.l[plant_sectors,t+1]/((1-tCorp.l[t+1])*fv);#*abs(pPlant.l[plant_sectors,'land',t+1]));


report_uccap_plant[plant_sectors,plant_pK,'tobinsQ',t]$(tx0E[t])     = (pTobinsQ_plant.l[plant_sectors,plant_pK,t] * (1+rFirms.l[plant_sectors,t+1]) - sum(k$agri2k[plant_pK,k], (1-rDepr.l[k,plant_sectors,t+1])) * pTobinsQ_plant.l[plant_sectors,plant_pK,t+1]*fp)/((1-tCorp.l[t+1])*fv); #*abs(pPlant_uc.l[plant_sectors,plant_pK,t+1]*fv));
report_uccap_plant[plant_sectors,plant_pK,'t_cap',t]$(tx0E[t])       = (1-tCorp.l[t+1]) * sum(k$agri2k[plant_pK,k], tK_plant.l[k,plant_sectors,t+1] * pI_s.l[k,plant_sectors,t+1]*fp)/((1-tCorp.l[t+1])*fv); #abs(pPlant_uc.l[plant_sectors,plant_pK,t+1]*fv));
report_uccap_plant[plant_sectors,plant_pK,'tax_shield',t]$(tx0E[t])   =        	-  ((rFirms.l[plant_sectors,t+1] - rBonds.l[plant_sectors,'2025'] * (1-tCorp.l[t+1])) * sum(k$agri2k[plant_pK,k],sDebt2k.l[k,plant_sectors,t] * pI_s.l[k,plant_sectors,t]))$(t.val<2025)/((1-tCorp.l[t+1])*fv) #abs(pPlant_uc.l[plant_sectors,plant_pK,t+1]*fv))
                                                               	-  ((rFirms.l[plant_sectors,t+1] - rBonds.l[plant_sectors,t+1]    * (1-tCorp.l[t+1])) * sum(k$agri2k[plant_pK,k],sDebt2k.l[k,plant_sectors,t] * pI_s.l[k,plant_sectors,t]))$(t.val>=2025)/((1-tCorp.l[t+1])*fv); #abs(pPlant_uc.l[plant_sectors,plant_pK,t+1]*fv));
report_uccap_plant[plant_sectors,plant_pK,'instcost',t]$(tx0E[t]) = (1-tCorp.l[t+1]) * pPlant.l[plant_sectors,'grossprod',t+1]*fp * sum(k$agri2k[plant_pK,k], dKinstCost2dK.l[k,plant_sectors,t])/((1-tCorp.l[t+1])*fv); # abs(pPlant_uc.l[plant_sectors,plant_pK,t+1]*fv));
report_uccap_plant[plant_sectors,plant_pK,'j',t]$(tx0E[t]) =jpK_plant.l[plant_sectors,plant_pK,t+1]/((1-tCorp.l[t+1])*fv);#*abs(pPlant_uc.l[plant_sectors,plant_pK,t+1]*fv));

report_uccap_ani[ani_sectors,ani_pK,'tobinsQ',t]$(tx0E[t])     = (pTobinsQ_ani.l[ani_sectors,ani_pK,t] * (1+rFirms.l[ani_sectors,t+1]) - sum(k$agri2k[ani_pK,k], (1-rDepr.l[k,ani_sectors,t+1])) * pTobinsQ_ani.l[ani_sectors,ani_pK,t+1]*fp)/((1-tCorp.l[t+1])*fv); #*abs(pani_uc.l[ani_sectors,ani_pK,t+1]*fv));
report_uccap_ani[ani_sectors,ani_pK,'t_cap',t]$(tx0E[t])       = (1-tCorp.l[t+1]) * sum(k$agri2k[ani_pK,k], tK.l[k,ani_sectors,t+1] * pI_s.l[k,ani_sectors,t+1]*fp)/((1-tCorp.l[t+1])*fv); #abs(pani_uc.l[ani_sectors,ani_pK,t+1]*fv));
report_uccap_ani[ani_sectors,ani_pK,'tax_shield',t]$(tx0E[t])   =        	-  ((rFirms.l[ani_sectors,t+1] - rBonds.l[ani_sectors,'2025'] * (1-tCorp.l[t+1])) * sum(k$agri2k[ani_pK,k],sDebt2k.l[k,ani_sectors,t] * pI_s.l[k,ani_sectors,t]))$(t.val<2025)/((1-tCorp.l[t+1])*fv) #abs(pani_uc.l[ani_sectors,ani_pK,t+1]*fv))
                                                               	-  ((rFirms.l[ani_sectors,t+1] - rBonds.l[ani_sectors,t+1]    * (1-tCorp.l[t+1])) * sum(k$agri2k[ani_pK,k],sDebt2k.l[k,ani_sectors,t] * pI_s.l[k,ani_sectors,t]))$(t.val>=2025)/((1-tCorp.l[t+1])*fv); #abs(pani_uc.l[ani_sectors,ani_pK,t+1]*fv));
report_uccap_ani[ani_sectors,ani_pK,'instcost',t]$(tx0E[t]) = (1-tCorp.l[t+1]) * pani.l[ani_sectors,'grossprod',t+1]*fp * sum(k$agri2k[ani_pK,k], dKinstCost2dK.l[k,ani_sectors,t])/((1-tCorp.l[t+1])*fv); # abs(pani_uc.l[ani_sectors,ani_pK,t+1]*fv));
report_uccap_ani[ani_sectors,ani_pK,'j',t]$(tx0E[t]) =jpK_ani.l[ani_sectors,ani_pK,t+1]/((1-tCorp.l[t+1])*fv);#*abs(pani_uc.l[ani_sectors,ani_pK,t+1]*fv));

$ENDFUNCTION



# ======================================================================================================================
# 0) Hacks
# ======================================================================================================================

  rFirmsLand.l[plant_sectors,tx1] = 0.07; #Flyt til production_plant

  d1Ani['01070','Mink',t]$(t.val>2020) = no;
  d1Ani['01070','AnimalsAgg',t]$(t.val>2020) = no;

  #Hacks
  KF_landemissions['Mineralization',emm,'2021'] = KF_landemissions['Mineralization',emm,'2023'];
  KF_landemissions['Mineralization',emm,'2022'] = KF_landemissions['Mineralization',emm,'2023'];

  pLand.l[t]$(t.val>2019) = pLand.l['2019'];
  pPlant.l[plant_sectors,'land',t]$(t.val>2019) = pPlant.l[plant_sectors,'land','2019'];
  # jqPlant_CET.l[plant_sectors,'Grain',t] = KF_qPlant_trend_[plant_sectors,t] -KF_qPlant_[plant_sectors,t];

  #Priser og mængder udvikler sig besynderligt efter 2050 for disse..
  # KF_pAni['01061',t]$(t.val>2041 and t.val<2051) = KF_pAni['01061','2041'] - (KF_pAni['01061','2041']-KF_pAni['01061','2050'])/(2050-2042)*(t.val-2042); #For poultry, we have no data after 2041, so we use the 2041 price for all years after
  
  # KF_qAni['01032',t]$(t.val>2039) = KF_qAni['01032','2039']*growth_factor[t]/growth_factor['2039'];
  # KF_pAni['01032',t]$(t.val>2039) = KF_pAni['01032','2039']*inf_factor[t]/inf_factor['2039'];

  # KF_qAni['01031',t]$(t.val>2039) = KF_qAni['01032','2039']*growth_factor[t]/growth_factor['2039'];
  # KF_pAni['01031',t]$(t.val>2039) = KF_pAni['01032','2039']*inf_factor[t]/inf_factor['2039'];

  # KF_pPlant['01012','2042'] = 0.5*KF_pPlant['01012','2041'] + 0.5 * KF_pPlant['01012','2043'];

  # KF_pAni['01052',t]$(t.val>2019 and t.val<2030) = KF_pAni['01052','2019'] +  (KF_pAni['01052','2030']-KF_pAni['01052','2019'])/(2030-2019)*(t.val-2019);
  # KF_qAni['01052',t]$(t.val>2019 and t.val<2030) = KF_qAni['01052','2019'] +  (KF_qAni['01052','2030']-KF_qAni['01052','2019'])/(2030-2019)*(t.val-2019);

  # KF_pPlant['01020',t]$(t.val>2019) = KF_pPlant['01020','2019']; #+  (KF_pPlant['01020','2030']-KF_pPlant['01020','2019'])/(2030-2019)*(t.val-2019);
  # KF_qPlant['01020',t]$(t.val>2019) = KF_qPlant['01020','2019']; #+  (KF_qPlant['01020','2030']-KF_qPlant['01020','2019'])/(2030-2019)*(t.val-2019);

  # KF_qPlant['01020',t]$(t.val>2030) = KF_qPlant['01020','2030'];
  # KF_pPlant['01020',t]$(t.val>2030) = KF_pPlant['01020','2030'];

  # KF_qPlant[plant_sectors,t]$(t.val > 2019) = KF_qPlant[plant_sectors,'2019'];
  # KF_pPlant[plant_sectors,t]$(t.val > 2019) = KF_pPlant[plant_sectors,'2019'];

  # KF_qAni[ani_sectors,t]$(t.val > 2019) = KF_qAni[ani_sectors,'2019'];
  # KF_pAni[ani_sectors,t]$(t.val > 2019) = KF_pAni[ani_sectors,'2019'];

 #HACK
  # KF_qAni['01062',t]$(t.val>2019 and t.val<2025) = KF_qAni['01062','2019']; 


# ======================================================================================================================
# 1) SETTINGS
# ======================================================================================================================

  #ALL AGRI_SECTORS
    #This dummy makes us hit target dummy from external analysis
    PARAMETER OneToZeroAgrIterator[agri_sectors];
    $SETGLOBAL markupudfasetiaar_agr 2026
    $SETGLOBAL markupudfasetiaar_mink 2025 #£: Skal vi gøre noget ved minkene..
    PARAMETER iteite;
    iteite = 0;  #0= 0-markup
    OneToZeroAgrIterator[plant_sectors] = 1; #0 = Flad produktion
    
  #PLANT SECTORS 
    $SETGLOBAL uKland 1  
    $SETGLOBAL calibpriser_plant 1
    $SETGLOBAL calibquanti_plant 1
    $SETGLOBAL plandphase 1
    $SETGLOBAL landphase2 0
    $SETGLOBAL lockland 1
    $SETGLOBAL calibrateNPK 1
    $SETGLOBAL calibratePlantManure 1
    $SETGLOBAL calibrateChemicalsPlusFinServL 1
    $SETGLOBAL pLand2024calib 0
    $SETGLOBAL smoothafter2050_plant 0
    $SETGLOBAL demand_response_in_partial_plant 1

    $SETGLOBAL plant_end 2050
    $SETGLOBAL land_end 2049
    $SETGLOBAL ani_end 2050


    set tKF_plant[t]/2020*%plant_end%/;
    set tKF_land[t] /2021*%land_end%/; # Land is ultimo dated and so to change productive land in year t, we must change model land in year t-1. However, we can't (and don't have to) change 2018 land
    singleton set tKF_ultimo_end[t] /%land_end%/;
    singleton set tKF_plant_end[t]/%plant_end%/;

  #ANIMAL SECTORS
    $SETGLOBAL calibpriser_ani 1
    $SETGLOBAL calibrateNManure 1
    $SETGLOBAL calibrateNManure_perdata 1
    $SETGLOBAL calibrateNumberAnimals_poul 1 #This means that the split con/org is calibrated. 
    $SETGLOBAL calibrateNumberAnimals_cowsnpigs 0 #This means that the split con/org is calibrated. 
    $SETGLOBAL demand_response_in_partial_ani 1
    $SETGLOBAL calibrateMinkMarkup 1
    $SETGLOBAL smoothafter2050_ani 0
    OneToZeroAgrIterator[ani_sectors] = 1; #0 = Flad produktion

    set tKF_animals[t] /2020*%ani_end%/;
    set tKF_ani[t] /2020*%ani_end%/;
    singleton set tKF_Animals_end[t] /%ani_end%/;
    singleton set tKF_ani_end[t] /%ani_end%/;

  #MACHINE STATION 
    $SETGLOBAL calibratemachinestationMarkup 1

  #FOOD PROCESSING SECTORS
    $SETGLOBAL markupudfasetiaar_food 2025


  # ----------------------------------------------------------------------------------------
  # Set dummies
  # ----------------------------------------------------------------------------------------  
  
    d1EmmProdxE[agri_sectors,tx1,'CH4'] = yes$(sum(emmtype, qEmmAgrxE.l[emmtype,agri_sectors,tx1,'CH4']));
    d1EmmProdxE[agri_sectors,tx1,'N2O'] = yes$(sum(emmtype, qEmmAgrxE.l[emmtype,agri_sectors,tx1,'N2O']));
    d1EmmProdxE[agri_sectors,tx1,'CO2ubio'] = yes$(sum(emmtype, qEmmAgrxE.l[emmtype,agri_sectors,tx1,'CO2ubio']));
    d1EmmProdxE[agri_sectors,tx1,'HFC'] = yes$(sum(emmtype, qEmmAgrxE.l[emmtype,agri_sectors,tx1,'HFC']));
    d1EmmProdxE[agri_sectors,tx1,'PFC'] = yes$(sum(emmtype, qEmmAgrxE.l[emmtype,agri_sectors,tx1,'PFC']));
    d1EmmProdxE[agri_sectors,tx1,'SF6'] = yes$(sum(emmtype, qEmmAgrxE.l[emmtype,agri_sectors,tx1,'SF6']));
    d1EmmProdxE[agri_sectors,tx1,'CO2e'] = yes$(sum(emmtype, qEmmAgrxE.l[emmtype,agri_sectors,tx1,'CO2e']));


    d1EmmProdxE[ani_sectors,t,'CH4']$(t.val > tKF_ani_end.val and d1EmmProdxE[ani_sectors,tKF_ani_end,'CH4']) = yes;
    d1EmmProdxE[ani_sectors,t,'N2O']$(t.val > tKF_ani_end.val and d1EmmProdxE[ani_sectors,tKF_ani_end,'N2O']) = yes;
    d1EmmProdxE[ani_sectors,t,'CO2ubio']$(t.val > tKF_ani_end.val and d1EmmProdxE[ani_sectors,tKF_ani_end,'CO2ubio']) = yes;
    d1EmmProdxE[ani_sectors,t,'HFC']$(t.val > tKF_ani_end.val and d1EmmProdxE[ani_sectors,tKF_ani_end,'HFC']) = yes;
    d1EmmProdxE[ani_sectors,t,'PFC']$(t.val > tKF_ani_end.val and d1EmmProdxE[ani_sectors,tKF_ani_end,'PFC']) = yes;
    d1EmmProdxE[ani_sectors,t,'SF6']$(t.val > tKF_ani_end.val and d1EmmProdxE[ani_sectors,tKF_ani_end,'SF6']) = yes;
    d1EmmProdxE[ani_sectors,t,'CO2e']$(t.val > tKF_ani_end.val and d1EmmProdxE[ani_sectors,tKF_ani_end,'CO2e']) = yes;

    d1EmmProdxE[plant_sectors,t,'CH4']$(t.val > tKF_plant_end.val and d1EmmProdxE[plant_sectors,tKF_plant_end,'CH4']) = yes;
    d1EmmProdxE[plant_sectors,t,'N2O']$(t.val > tKF_plant_end.val and d1EmmProdxE[plant_sectors,tKF_plant_end,'N2O']) = yes;
    d1EmmProdxE[plant_sectors,t,'CO2ubio']$(t.val > tKF_plant_end.val and d1EmmProdxE[plant_sectors,tKF_plant_end,'CO2ubio']) = yes;
    d1EmmProdxE[plant_sectors,t,'HFC']$(t.val > tKF_plant_end.val and d1EmmProdxE[plant_sectors,tKF_plant_end,'HFC']) = yes;
    d1EmmProdxE[plant_sectors,t,'PFC']$(t.val > tKF_plant_end.val and d1EmmProdxE[plant_sectors,tKF_plant_end,'PFC']) = yes;
    d1EmmProdxE[plant_sectors,t,'SF6']$(t.val > tKF_plant_end.val and d1EmmProdxE[plant_sectors,tKF_plant_end,'SF6']) = yes;
    d1EmmProdxE[plant_sectors,t,'CO2e']$(t.val > tKF_plant_end.val and d1EmmProdxE[plant_sectors,tKF_plant_end,'CO2e']) = yes;

    qEmmProdxE.l[agri_sectors,tx1,'CH4']$(not d1EmmProdxE[agri_sectors,tx1,'CH4']) = 0;
    qEmmProdxE.l[agri_sectors,tx1,'N2O']$(not d1EmmProdxE[agri_sectors,tx1,'N2O']) = 0;
    qEmmProdxE.l[agri_sectors,tx1,'CO2ubio']$(not d1EmmProdxE[agri_sectors,tx1,'CO2ubio']) = 0;
    qEmmProdxE.l[agri_sectors,tx1,'HFC']$(not d1EmmProdxE[agri_sectors,tx1,'HFC']) = 0;
    qEmmProdxE.l[agri_sectors,tx1,'PFC']$(not d1EmmProdxE[agri_sectors,tx1,'PFC']) = 0;
    qEmmProdxE.l[agri_sectors,tx1,'SF6']$(not d1EmmProdxE[agri_sectors,tx1,'SF6']) = 0;
    qEmmProdxE.l[agri_sectors,tx1,'CO2e']$(not d1EmmProdxE[agri_sectors,tx1,'CO2e']) = 0;


# ======================================================================================================================
# 2) CREATING VARIABLES AND GROUPS FOR THE INTEGRATION
# ======================================================================================================================

  $GROUP G_adjustmarkups_agr
    adj_markup_ani[ani_sectors,ani_out_top] "Used for mink only"
    adj_markup_machinestation               "Used on agricultural contractors mark-up"
  ;

  $GROUP G_adjustmarkups_foodprocessingsectors
    adj_markup_foodprocessingsectors[out,FoodProcessingSectors] "Adjusting mark-ups to zero for food processing sectors"
  ;

  $GROUP G_agr_emmi_calib_endo 
    adj_uEmmAgrxE[emmtype,t,emm] "Adjustment parameter used in calibrating emissions to Climate Outlook emissions"
    adj_NH3_pigs[t]              ""
  ;

  $GROUP G_ani_prod_calib_endo #Endogenous calibration parameters for animal production
    #Pigs endo     
      adj_qAni_pigs_con[t] "Adjustment parameter used in calibration of conventional pig production"
      adj_qAni_pigs_org[t] "Adjustment parameter used in calibration of organic pig production"
      sX_y$(tx1[t] and d1X_y[x,s,t] and sameas[x,'xOth'] and sameas[s,'01051']) 
      sX_y$(tx1[t] and d1X_y[x,s,t] and sameas[x,'xOth'] and sameas[s,'10012'])   
      ani_markup$(tx1[t] and sameas[ani_sectors,'01051'])
      TFPAni$(tx1[t] and sameas[ani_sectors,'01051'])
      pM_CET$(tx1[t] and d1vM_CET[out,s,t] and sameas[out,'out_other'] and sameas[s,'10012'])

      $IF %smaagrisesplit%!=1:
      sRxE_ym$(tx1[t] and d1RxE_ym[r,s,t] and sameas[r,'10012'] and sameas[s,'01052']) #Pigs, org
      $ENDIF 
      sX_y$(tx1[t] and d1x_y[x,s,t] and sameas[x,'xOth'] and sameas[s,'01052'])
      ani_markup$(tx1[t] and sameas[ani_sectors,'01052'])
      TFPAni$(tx1[t] and sameas[ani_sectors,'01052'])


    #Cows endo
      adj_qAni_cows_con[t] ""
      
      sX_y$(tx1[t] and d1X_y[x,s,t] and sameas[x,'xOth'] and sameas[s,'10030'])       #Cows, con 
      sX_y$(tx1[t] and d1X_y[x,s,t] and sameas[x,'xOth'] and sameas[s,'10011'])
      sX_y$(tx1[t] and d1X_y[x,s,t] and sameas[x,'xOth'] and sameas[s,'01031'])
      
      TFPAni$(tx1[t] and sameas[ani_sectors,'01031'])
      ani_markup$(tx1[t] and sameas[ani_sectors,'01031'])
      pM_CET$(tx1[t] and d1vM_CET[out,s,t] and sameas[out,'out_other'] and sameas[s,'10030'])
      pM_CET$(tx1[t] and d1vM_CET[out,s,t] and sameas[out,'out_other'] and sameas[s,'10011'])

      adj_qAni_cows_org[t] ""

      sRxE_ym$(tx1[t] and d1RxE_ym[r,s,t] and sameas[r,'10030'] and sameas[s,'01032']) #Cows, org
      sRxE_ym$(tx1[t] and d1RxE_ym[r,s,t] and sameas[r,'10011'] and sameas[s,'01032']) #Cows, org
      sX_y$(tx1[t] and d1X_y[x,s,t] and sameas[x,'xOth'] and sameas[s,'01032'])
      
      ani_markup$(tx1[t] and sameas[ani_sectors,'01032'])
      TFPAni$(tx1[t] and sameas[ani_sectors,'01032'])


    #Poultry endo
      adj_qAni_poul_con[t] ""
      sX_y$(tx1[t] and d1X_y[x,s,t] and sameas[x,'xOth'] and sameas[s,'10013']) #Poul, con
      sX_y$(tx1[t] and d1X_y[x,s,t] and sameas[x,'xOth'] and sameas[s,'01061']) 
      ani_markup$(tx1[t] and sameas[ani_sectors,'01061'])
      TFPAni$(tx1[t] and sameas[ani_sectors,'01061'])
      pM_CET$(tx1[t] and d1vM_CET[out,s,t] and sameas[out,'out_other'] and sameas[s,'10013'])


      adj_qAni_poul_org[t] ""
      sRxE_ym$(tx1[t] and d1RxE_ym[r,s,t] and sameas[r,'10013'] and sameas[s,'01062']) #Poul, org
      sX_y$(tx1[t] and d1X_y[x,s,t] and sameas[x,'xOth'] and sameas[s,'01062']) 
      ani_markup$(tx1[t] and sameas[ani_sectors,'01062'])
      TFPAni$(tx1[t] and sameas[ani_sectors,'01062'])

      adj_TFPAni[ani_sectors] ""

      #Animals 
      adj_animals[animals,t] ""
  ;

  $GROUP G_plant_prod_calib_endo 

      adj_qPlant_con[t]  ""
      $IF %calibquanti_plant%:
        sX_y$(tx1[t] and d1x_y[x,s,t] and sameas[x,'xOth'] and sameas[s,'01011'])
        sX_y$(tx1[t] and d1x_y[x,s,t] and sameas[x,'xOth'] and sameas[s,'10040'])
        sX_y$(tx1[t] and d1x_y[x,s,t] and sameas[x,'xOth'] and sameas[s,'10120'])
      $ENDIF

      $IF %calibpriser_plant%:
        pM_CET$(tx1[t] and d1vM_CET[out,s,t] and sameas[out,'out_other'] and sameas[s,'10040'])
        pM_CET$(tx1[t] and d1vM_CET[out,s,t] and sameas[out,'out_other'] and sameas[s,'10120'])
        plant_markup$(tx1[t] and d1Plant_CET0[plant_sectors,plant_out,t] and plant_out_top[plant_out] and sameas[plant_sectors,'01011'])
        TFPPlant$(tx1[t] and sameas[plant_sectors,'01011'])
      $ENDIF

      adj_qPlant_org[t] ""

      $IF %calibquanti_plant%:
        sX_y$(tx1[t] and d1x_y[x,s,t] and sameas[x,'xOth'] and sameas[s,'01012'])
        sRxE_ym$(tx1[t] and d1RxE_ym[r,s,t] and sameas[r,'10040'] and sameas[s,'01012'])
        sRxE_ym$(tx1[t] and d1RxE_ym[r,s,t] and sameas[r,'10120'] and sameas[s,'01012'])
      $ENDIF
    
      $IF %calibpriser_plant%:
        plant_markup$(tx1[t] and d1Plant_CET0[plant_sectors,plant_out,t] and plant_out_top[plant_out] and sameas[plant_sectors,'01012'])
        TFPPlant$(tx1[t] and sameas[plant_sectors,'01012'])
      $ENDIF

      adj_qPlant_hor[t] ""
      $IF %calibquanti_plant%:
       sX_y$(tx1[t] and d1x_y[x,s,t] and sameas[x,'xOth'] and sameas[s,'01020'])
      $ENDIF
   
      $IF %calibpriser_plant%:
        plant_markup$(tx1[t] and d1Plant_CET0[plant_sectors,plant_out,t] and plant_out_top[plant_out] and sameas[plant_sectors,'01020'])
        TFPPlant$(tx1[t] and sameas[plant_sectors,'01020'])
      $ENDIF

      #Manure consumption
      $IF %calibratePlantManure%:
        uPlant$(tx1[t] and d1Plant[plant_sectors,plant_,t] and sameas[plant_,'manure'])
      $ENDIF 
      adj_pD_manure   ""


      $IF (%calibrateNPK%) & (%calibratePlantManure%):
        uPlant$(tx1[t] and d1Plant[plant_sectors,plant_,t] and sameas[plant_,'Fertilizer'])
      $ENDIF

      $IF %calibrateChemicalsPlusFinServL%:
        uPlant$(tx1[t] and d1Plant[plant_sectors,plant_,t] and sameas[plant_,'Chemicals'])
        uPlant$(tx1[t] and d1PLant[plant_sectors,plant_,t] and sameas[plant_,'FinancialServiceL'])
      $ENDIF 

      $IF (%lockland%) & (%calibrateChemicalsPlusFinServL%):
        uPlant$(tx1[t] and d1Plant[plant_sectors,plant_,t] and sameas[plant_,'LandChem'])
      $ENDIF

      $IF (%lockland%) & (%calibrateChemicalsPlusFinServL%) & (%calibratePlantManure%) & (%calibrateNPK%):
        uPlant$(tx1[t] and d1Plant[plant_sectors,plant_,t] and sameas[plant_,'LF'])
      $ENDIF

      #Manure prices 

      adj_TFPPlant[plant_sectors] ""
      adj_pLand  ""

      #NPK
      $IF %calibrateNPK%:
       uPlant$(tx1[t] and d1Plant[plant_sectors,plant_,t] and sameas[plant_,'NPK'])
      $ENDIF
  ;



  $GROUP G_machinestation_mink_endo 
    markup$(tx1[t] and sameas[s,'01080'] and sameas[out,'out_other'])
    TFP$(tx1[t] and sameas[prdNest,'KELBM'] and sameas[sp,'01080'])
    ani_markup$(tx1[t] and sameas[ani_sectors,'01070'])
  ;

  $GROUP G_agr_calib_endo 
          adj_Manure[t] ""
  ;  
  $GROUP G_plant_prod_calib_exo 
      adj_Manure[t] ""

    $IF %calibrateNPK%:
      qPlant$(tx1[t] and tKF_plant[t] and d1Plant[plant_sectors,plant_,t] and sameas[plant_,'NPK'])
    $ENDIF
         
  ;



# ======================================================================================================================
# 3) ADDITIONAL DATA AND INITIAL VALUES 
# ======================================================================================================================

    adj_pD_manure.l = 1;

  #Fordeler NPK på konventionelt og gartneri

    $IF %calibrateNPK%:
      #To-steps fordeling 
      #I første trin fordeles med samme N per J forhold som i sidste data år, i andet trin afstemmes til den total vi skal ramme 
      qPlant.l['01011','NPK',tKF_plant] = qPlant.l['01011','NPK',tDataEnd]/qPlant.l['01011','Land',tDataEnd] * qPlant.l['01011','Land',tKF_plant];
      qPlant.l['01020','NPK',tKF_plant] = qPlant.l['01020','NPK',tDataEnd]/qPlant.l['01020','Land',tDataEnd] * qPlant.l['01020','Land',tKF_plant];

      #Afstemmer nu til KF-total 
      PARAMETER naivedist[plant_sectors,t];
      naivedist['01011',tKF_plant] = qPlant.l['01011','NPK',tKF_plant]/(qPlant.l['01011','NPK',tKF_plant] + qPlant.l['01020','NPK',tKF_plant]);
      naivedist['01020',tKF_plant] = qPlant.l['01020','NPK',tKF_plant]/(qPlant.l['01011','NPK',tKF_plant] + qPlant.l['01020','NPK',tKF_plant]);

      KF_NPK[t] = KF_NPK[t]/1000; #Mio tN, ligesom resten af modellen 
      qPlant.l['01011','NPK',tKF_plant] = naivedist['01011',tKF_plant] * KF_NPK[tKF_plant];
      qPlant.l['01020','NPK',tKF_plant] = naivedist['01020',tKF_plant] * KF_NPK[tKF_plant];

      qPlant.l['01011','NPK',t]$(t.val > tKF_plant_end.val) = qPlant.l['01011','NPK',tKF_plant_end]; 
      qPlant.l['01020','NPK',t]$(t.val > tKF_plant_end.val) = qPlant.l['01020','NPK',tKF_plant_end]; 
    $ENDIF

  #Gødningsproduktion 
    $IF %calibrateNManure%:
      qNManure.l[ani_sectors,animals,tKF_ani]$(not sameas[ani_sectors,'01070']) = KF_NabDyrViaLager[ani_sectors,animals,tKF_ani];
      qNManure.l[ani_sectors,animals,t]$(t.val > tKF_ani_end.val)               = qNManure.l[ani_sectors,animals,tKF_ani_end];
    $ENDIF

  #DYR 
    $IF %calibrateNumberAnimals_poul%:
      qAni.l['01061',animals,tKF_ani]                                  = KF_animals['01061',animals,tKF_ani];
      qAni.l['01061',animals,t]$(t.val >tKF_ani_end.val)                = qAni.l['01061',animals,tKF_ani_end]; 

      qAni.l['01062',animals,tKF_ani]                                  = KF_animals['01062',animals,tKF_ani];
      qAni.l['01062',animals,t]$(t.val >tKF_ani_end.val)               = qAni.l['01062',animals,tKF_ani_end]; 
    $ENDIF

    #If we do not calibrate cows and pigs they set to KF-numbers (the calibration means the conventional/org split is calibrated)
    $IF %calibrateNumberAnimals_cowsnpigs%==0:
      qAni.l['01031',animals,tKF_ani]                                  = KF_animals['01031',animals,tKF_ani];
      qAni.l['01031',animals,t]$(t.val >tKF_ani_end.val)                = qAni.l['01031',animals,tKF_ani_end]; 

      qAni.l['01032',animals,tKF_ani]                                  = KF_animals['01032',animals,tKF_ani];
      qAni.l['01032',animals,t]$(t.val >tKF_ani_end.val)               = qAni.l['01032',animals,tKF_ani_end]; 

      qAni.l['01051',animals,tKF_ani]                                  = KF_animals['01051',animals,tKF_ani];
      qAni.l['01051',animals,t]$(t.val >tKF_ani_end.val)                = qAni.l['01051',animals,tKF_ani_end]; 

      qAni.l['01052',animals,tKF_ani]                                  = KF_animals['01052',animals,tKF_ani];
      qAni.l['01052',animals,t]$(t.val >tKF_ani_end.val)               = qAni.l['01052',animals,tKF_ani_end]; 
    $ENDIF
  # ----------------------------------------------------------------------------------------
  # Initial values
  # ----------------------------------------------------------------------------------------
   
  adj_qPlant_con.l[tx1]    = 1;
  adj_qPlant_org.l[tx1]    = 1;
  adj_qPlant_hor.l[tx1]    = 1;
  adj_qAni_pigs_con.l[tx1] = 1;
  adj_qAni_pigs_org.l[tx1] = 1;
  adj_qAni_cows_con.l[tx1] = 1;
  adj_qAni_cows_org.l[tx1] = 1;
  adj_qAni_poul_con.l[tx1] = 1;
  adj_qAni_poul_org.l[tx1] = 1;

  adj_pland.l = 0.99; 

  # ----------------------------------------------------------------------------------------
  # Forecast of import prices 
  # ----------------------------------------------------------------------------------------

  #For animals
  LOOP(t$(tx1[t] and tKF_ani[t]),
    pM_CET.l['out_other',ani_sectors,t]$((sameas[ani_sectors,'01051'] or sameas[ani_sectors,'01052'] or sameas[ani_sectors,'01031'] or sameas[ani_sectors,'01032'] or sameas[ani_sectors,'01061'] or sameas[ani_sectors,'01062'])) 
      = pM_CET.l['out_other',ani_sectors,t-1] * KF_pAni[ani_sectors,t]/KF_pAni[ani_sectors,t-1];
    );

  pM_CET.l['out_other',ani_sectors,t]$(t.val>tKF_ani_end.val) = pM_CET.l['out_other',ani_sectors,tKF_ani_end];


  #For plants
  $IF %calibpriser_plant%:
    LOOP(t$(tx1[t] and tKF_plant[t]),
      pM_CET.l['out_other',plant_sectors,t]$((sameas[plant_sectors,'01011'] or sameas[plant_sectors,'01012'] or sameas[plant_sectors,'01020'])) 
        = pM_CET.l['out_other',plant_sectors,t-1] * ((KF_pPlant[plant_sectors,t]/KF_pPlant[plant_sectors,t-1])$(not sameas[plant_sectors,'01020']) + (KF_pPlant['01011',t]/KF_pPlant['01011',t-1])$(sameas[plant_sectors,'01020']));
      );

    pM_CET.l['out_other',plant_sectors,t]$(t.val>tKF_plant_end.val) = pM_CET.l['out_other',plant_sectors,tKF_plant_end];
  $ENDIF 


  # ----------------------------------------------------------------------------------------
  # Initial values on quantities of production and prices 
  # ----------------------------------------------------------------------------------------

  $FUNCTION compute_ani_quantities():
    LOOP(t$(tx1[t] and tKF_ani[t]),
    qAni_CET.l[ani_sectors,'out_other',t]$(not sameas[ani_sectors,'01070']) =  (1-OneToZeroAgrIterator[ani_sectors]) * qAni_CET.l[ani_sectors,'out_other',t-1] 
                                                                               +   OneToZeroAgrIterator[ani_sectors] * qAni_CET.l[ani_sectors,'out_other',t-1]  * KF_qAni[ani_sectors,t]/KF_qAni[ani_sectors,t-1];
    );

    qAni_CET.l[ani_sectors,'out_other',t]$(t.val > tKF_ani_end.val) = qAni_CET.l[ani_sectors,'out_other',tKF_ani_end];

  $ENDFUNCTION

  $FUNCTION compute_ani_prices():
    $IF %calibpriser_ani%:
    LOOP(t$(tx1[t] and tKF_ani[t]),
    pAni_CET.l[ani_sectors,'out_other',t]$(not sameas[ani_sectors,'01070']) =  (1-OneToZeroAgrIterator[ani_sectors]) * pAni_CET.l[ani_sectors,'out_other',t-1] 
                                                                               +   OneToZeroAgrIterator[ani_sectors] * pAni_CET.l[ani_sectors,'out_other',t-1]  * KF_pAni[ani_sectors,t]/KF_pAni[ani_sectors,t-1];
    );

    pAni_CET.l[ani_sectors,'out_other',t]$(t.val > tKF_ani_end.val) = pAni_CET.l[ani_sectors,'out_other',tKF_ani_end];
    $ENDIF
  $ENDFUNCTION


  $FUNCTION compute_plant_quantities():
    $IF %calibquanti_plant%:
    LOOP(t$(tx1[t] and tKF_plant[t]),
    qPlant_CET.l[plant_sectors,'Grain',t]       =   (1-OneToZeroAgrIterator[plant_sectors]) *  qPlant_CET.l[plant_sectors,'Grain',t-1]
                                                  + OneToZeroAgrIterator[plant_sectors]      *  qPlant_CET.l[plant_sectors,'Grain',t-1] * ((KF_qPlant[plant_sectors,t]/KF_qPlant[plant_sectors,t-1])$(not sameas[plant_sectors,'01020']) + (KF_qPlant['01011',t]/KF_qPlant['01011',t-1])$(sameas[plant_sectors,'01020']));
    
    qPlant_CET.l[plant_sectors,'EnergyStraw',t]$(qPlant_CET.l[plant_sectors,'EnergyStraw',t]) =
                                                  (1-OneToZeroAgrIterator[plant_sectors]) * qPlant_CET.l[plant_sectors,'EnergyStraw',t-1] 
                                                  + OneToZeroAgrIterator[plant_sectors] * qPlant_CET.l[plant_sectors,'EnergyStraw',t-1]  * ((KF_qPlant[plant_sectors,t]/KF_qPlant[plant_sectors,t-1])$(not sameas[plant_sectors,'01020']) + (KF_qPlant['01011',t]/KF_qPlant['01011',t-1])$(sameas[plant_sectors,'01020']));
    );

    qPlant_CET.l[plant_sectors,'Grain',t]$(t.val>tKF_plant_end.val)       = qPlant_CET.l[plant_sectors,'Grain',tKF_plant_end];
    qPlant_CET.l[plant_sectors,'EnergyStraw',t]$(t.val>tKF_plant_end.val) = qPlant_CET.l[plant_sectors,'EnergyStraw',tKF_plant_end];
    $ENDIF
  $ENDFUNCTION

  $FUNCTION compute_plant_prices():
    $IF %calibpriser_plant%:
    LOOP(t$(tx1[t] and tKF_plant[t]),
         pPlant_CET.l[plant_sectors,'Grain',t] =(1-OneToZeroAgrIterator[plant_sectors]) * pPlant_CET.l[plant_sectors,'grain',t-1] +
                                                 OneToZeroAgrIterator[plant_sectors] * (  pPlant_CET.l[plant_sectors,'Grain',t-1] 
                                            *((KF_pPlant[plant_sectors,t]/KF_pPlant[plant_sectors,t-1])$(not sameas[plant_sectors,'01020']) + (KF_pPlant['01011',t]/KF_pPlant['01011',t-1])$(sameas[plant_sectors,'01020'])));
    );

    pPlant_CET.l[plant_sectors,plant_out_top,t]$(t.val >tKF_plant_end.val) = pPlant_CET.l[plant_sectors,plant_out_top,tKF_plant_end];
    $ENDIF
  $ENDFUNCTION 

   @compute_ani_prices();
   @compute_ani_quantities();
   @compute_plant_prices(); 
   @compute_plant_quantities();



# ======================================================================================================================
# 4) INTEGRATION EQUATIONS 
# ======================================================================================================================

  # ----------------------------------------------------------------------------------------
  # 4a) Plant production, prices, productivity, fertilizer, and land-use
  # ----------------------------------------------------------------------------------------

  $FOR {s} in ['q']:
    $BLOCK B_KF25_plant_calib        
   #  Vi kontrollerer kun ikke-energi, markedsmæssigt output. 
     $IF %calibquanti_plant%:
       E_qKF_plant[plant_sectors,t]$(tx1[t] and tKF_plant[t])..
         qPlant_CET[plant_sectors,'Grain',t] =E= (1-OneToZeroAgrIterator[plant_sectors])*qPlant_CET.l[plant_sectors,'Grain',t-1]+ 
                                             OneToZeroAgrIterator[plant_sectors] * (   qPlant_CET[plant_sectors,'Grain',t-1] 
                                            *((KF_qPlant[plant_sectors,t]/KF_qPlant[plant_sectors,t-1])$(not sameas[plant_sectors,'01020']) + (KF_qPlant['01011',t]/KF_qPlant['01011',t-1])$(sameas[plant_sectors,'01020'])));
     $ENDIF 

     $IF %calibpriser_plant%:
       E_pKF_plant[plant_sectors,t]$(tx1[t] and tKF_plant[t])..
         pPlant_CET[plant_sectors,'Grain',t] =E= (1-OneToZeroAgrIterator[plant_sectors]) * pPlant_CET.l[plant_sectors,'grain',t-1] +
                                             OneToZeroAgrIterator[plant_sectors] * (  pPlant_CET[plant_sectors,'Grain',t-1] 
                                            *((KF_pPlant[plant_sectors,t]/KF_pPlant[plant_sectors,t-1])$(not sameas[plant_sectors,'01020']) + (KF_pPlant['01011',t]/KF_pPlant['01011',t-1])$(sameas[plant_sectors,'01020'])));
     $ENDIF

     #Plant demand
      $IF %calibquanti_plant%:
      #Conventional
        #Direct export
        E_qPlant_export_con[t]$(tx1[t] and d1X_y['xOth','01011',t] and tKF_plant[t]).. 
          {s}X_y['xOth','01011',t] =E= {s}X_y['xOth','01011',t1] * adj_qPlant_con[t];

        E_qPlant_export_con_afterKF[t]$(tx1[t] and t.val > tKF_plant_end.val and d1X_y['xOth','01011',t])..
          #  sX_y['xOth','01011',t] =E= sX_y['xOth','01011',tKF_plant_end];
          $IF1 %smoothafter2050_plant%!=1: sX_y['xOth','01011',t] =E= sX_y['xOth','01011',tKF_plant_end];$ENDIF1 
          $IF1 %smoothafter2050_plant%:  sX_y['xOth','01011',t] =E= sX_y['xOth','01011',t-1] + 0.5 * (sX_y['xOth','01011',t-1] - sX_y['xOth','01011',t-2]); $ENDIF1

          
          

        #Export through bread factories
        E_qPlant_bread_con[t]$(tx1[t] and tKF_plant[t] and d1X_y['xOth','10040',t])..
          {s}X_y['xOth','10040',t] =E= {s}X_y['xOth','10040',t1] * adj_qPlant_con[t];

        E_qPlant_bread_con_afterKF[t]$(tx1[t] and t.val > tKF_plant_end.val and d1X_y['xOth','10040',t])..
          #  sX_y['xOth','10040',t] =E= sX_y['xOth','10040',tKF_plant_end];
          $IF1 %smoothafter2050_plant%!=1:sX_y['xOth','10040',t] =E= sX_y['xOth','10040',tKF_plant_end]; $ENDIF1
          $IF1 %smoothafter2050_plant%:  sX_y['xOth','10040',t] =E= sX_y['xOth','10040',t-1] + 0.5 * (sX_y['xOth','10040',t-1] - sX_y['xOth','10040',t-2]); $ENDIF1



        #Beer exports
        E_qPlant_beer_con[t]$(tx1[t] and tKF_plant[t] and d1X_y['xOth','10120',t])..
          {s}X_y['xOth','10120',t] =E= {s}X_y['xOth','10120',t1] * adj_qPlant_con[t];

        E_qPlant_beer_con_afterKF[t]$(tx1[t] and t.val > tKF_plant_end.val and d1X_y['xOth','10120',t])..
          #  sX_y['xOth','10120',t] =E= sX_y['xOth','10120',tKF_plant_end];
          $IF1 %smoothafter2050_plant%!=1: sX_y['xOth','10120',t] =E= sX_y['xOth','10120',tKF_plant_end]; $ENDIF1
          $IF1 %smoothafter2050_plant%: sX_y['xOth','10120',t] =E= sX_y['xOth','10120',t-1] + 0.5 * (sX_y['xOth','10120',t-1] - sX_y['xOth','10120',t-2]); $ENDIF1
      $ENDIF

        $IF %calibpriser_plant%:
          E_pM_CET_bread[t]$(tx1[t] and tKF_plant[t] and d1vM_CET['out_other','10040',t]).. 
            pM_CET['out_other','10040',t] =E= pY_CET['out_other','10040',t];

          E_pM_CET_bread_afterKF[t]$(tx1[t] and t.val>tKF_plant_end.val and d1vM_CET['out_other','10040',t]).. 
            pM_CET['out_other','10040',t] =E= pM_CET['out_other','10040',tKF_plant_end];

          E_pM_CET_beer[t]$(tx1[t] and tKF_plant[t] and d1vM_CET['out_other','10120',t]).. 
            pM_CET['out_other','10120',t] =E= pY_CET['out_other','10120',t];

          E_pM_CET_beer_afterKF[t]$(tx1[t] and t.val>tKF_plant_end.val and d1vM_CET['out_other','10120',t]).. 
            pM_CET['out_other','10120',t] =E= pM_CET['out_other','10120',tKF_plant_end];


          #Prices
          E_TFPPlant_con_after2050_notKF[t]$(tx1[t] and t.val > tKF_plant_end.val).. #and t.val> 2050 
              TFPPlant['01011',t] =E= TFPPlant['01011',tKF_plant_end];
              # TFPPlant['01011',t] =E= TFPPlant['01011',t-1]*1.005;
              # TFPPlant['01011',t] =E= TFPPlant['01011',tKF_plant_end] * adj_pland**(t.val-tKF_plant_end.val);
              # TFPPlant['01011',t] =E= TFPPlant['01011',tKF_plant_end] + adj_pland *(t.val-tKF_plant_end.val);



          E_TFPPlant_con_notKF[t,plant_out_top]$(tx1[t] and t.val >= %markupudfasetiaar_agr% and d1Plant_CET0['01011',plant_out_top,t] and sameas[plant_out_top,'Grain'])..
              plant_markup['01011',plant_out_top,t] =E= iteite * plant_markup.l['01011',plant_out_top,t];

          E_TFPPlant_con_notgrain[t,plant_out_top]$(tx1[t] and d1Plant_CET0['01011',plant_out_top,t] and not sameas[plant_out_top,'Grain'])..
              plant_markup['01011',plant_out_top,t] =E= plant_markup['01011','Grain',t];


          E_TFP_plant_con[t]$(tx1[t] and t.val<=%markupudfasetiaar_agr%)..
              TFPPlant['01011',t] =E= TFPPlant['01011',t-1] + adj_TFPPlant['01011'];
        $ENDIF    



      #Organic
        $IF %calibquanti_plant%:
        E_qPlant_export_org[t]$(tx1[t] and tKF_plant[t] and d1X_y['xOth','01012',t])..
          {s}X_y['xOth','01012',t] =E= {s}X_y['xOth','01012',t1] * adj_qPlant_org[t];

        E_qPlant_export_org_afterKF[t]$(tx1[t] and t.val > tKF_plant_end.val and d1X_y['xOth','01012',t])..
          #  sX_y['xOth','01012',t] =E= sX_y['xOth','01012',tKF_plant_end];
          $IF1 %smoothafter2050_plant%!=1: sX_y['xOth','01012',t] =E= sX_y['xOth','01012',tKF_plant_end]; $ENDIF1
          $IF1 %smoothafter2050_plant%: sX_y['xOth','01012',t] =E= sX_y['xOth','01012',t-1] + 0.5 * (sX_y['xOth','01012',t-1] - sX_y['xOth','01012',t-2]); $ENDIF1


        E_qPlant_bread_org[t]$(tx1[t] and tKF_plant[t] and d1RxE_ym['10040','01012',t])..
          {s}RxE_ym['10040','01012',t] =E= {s}RxE_ym['10040','01012',t1] * adj_qPlant_org[t];

        E_qPlant_bread_org_afterKF[t]$(tx1[t] and t.val > tKF_plant_end.val and d1RxE_ym['10040','01012',t])..
          sRxE_ym['10040','01012',t] =E= sRxE_ym['10040','01012',tKF_plant_end];

        E_qPlant_beer_org[t]$(tx1[t] and tKF_plant[t] and d1RxE_ym['10120','01012',t])..
          {s}RxE_ym['10120','01012',t] =E= {s}RxE_ym['10120','01012',t1] * adj_qPlant_org[t];

        E_qPlant_beer_org_afterKF[t]$(tx1[t] and t.val > tKF_plant_end.val and d1RxE_ym['10120','01012',t])..
          #  sRxE_ym['10120','01012',t] =E= sRxE_ym['10120','01012',tKF_plant_end];
          $IF1 %smoothafter2050_plant%!=1: sRxE_ym['10120','01012',t] =E= sRxE_ym['10120','01012',tKF_plant_end]; $ENDIF1
          $IF1 %smoothafter2050_plant%:     sRxE_ym['10120','01012',t] =E= sRxE_ym['10120','01012',t-1] + 0.5 * (sRxE_ym['10120','01012',t-1] - sRxE_ym['10120','01012',t-2]); $ENDIF1
        $ENDIF

       $IF %calibpriser_plant%:
          E_TFPPlant_org_after2050_notKF[t]$(tx1[t] and t.val > tKF_plant_end.val).. # and t.val > 2050)..
              TFPPlant['01012',t] =E= TFPPlant['01012',tKF_plant_end];
              # TFPPlant['01012',t] =E= TFPPlant['01012',t-1]*1.005;
              # TFPPlant['01012',t] =E= TFPPlant['01012',tKF_plant_end] * adj_pland**(t.val-tKF_plant_end.val);
              # TFPPlant['01012',t] =E= TFPPlant['01012',tKF_plant_end] + adj_pland *(t.val-tKF_plant_end.val);



          E_TFPPlant_org_notKF[t,plant_out_top]$(tx1[t] and t.val >= %markupudfasetiaar_agr% and d1Plant_CET0['01012',plant_out_top,t] and sameas[plant_out_top,'Grain'])..
              plant_markup['01012',plant_out_top,t] =E= iteite *plant_markup.l['01012',plant_out_top,t];

          E_TFPPlant_org_notgrain[t,plant_out_top]$(tx1[t] and d1Plant_CET0['01012',plant_out_top,t] and not sameas[plant_out_top,'Grain'])..
              #  plant_markup['01012',plant_out_top,t] =E= 0;
              plant_markup['01012',plant_out_top,t] =E= plant_markup['01012','Grain',t];


          E_TFP_plant_org[t]$(tx1[t] and t.val<=%markupudfasetiaar_agr%)..
              TFPPlant['01012',t] =E= TFPPlant['01012',t-1] + adj_TFPPlant['01012'];
        $ENDIF



      #Horticulture
        $IF %calibquanti_plant%:
         E_qPlant_CET_hor[t]$(tx1[t] and tKF_plant[t] and d1X_y['xOth','01020',t])..
            {s}X_y['xOth','01020',t] =E= {s}X_y['xOth','01020',t1] * adj_qPlant_hor[t];

         E_qPlant_CET_hor_afterKF[t]$(tx1[t] and t.val > tKF_plant_end.val and d1x_y['xOth','01020',t])..
           #  sX_y['xOth','01020',t] =E= sX_y['xOth','01020',tKF_plant_end];
            $IF1 %smoothafter2050_plant%!=1: sX_y['xOth','01020',t] =E= sX_y['xOth','01020',tKF_plant_end]; $ENDIF1
            $IF1 %smoothafter2050_plant%: sX_y['xOth','01020',t] =E= sX_y['xOth','01020',t-1] + 0.5 * (sX_y['xOth','01020',t-1]-sX_y['xOth','01020',t-2] ); $ENDIF1
        $ENDIF

        $IF %calibpriser_plant%:

          E_TFPPlant_hor_after2050_notKF[t]$(tx1[t] and t.val > tKF_plant_end.val).. # and t.val > 2050)..
              TFPPlant['01020',t] =E= TFPPlant['01020',tKF_plant_end];
              # TFPPlant['01020',t] =E= TFPPlant['01020',t-1]*1.005;
              # TFPPlant['01020',t] =E= TFPPlant['01020',tKF_plant_end] * adj_pland**(t.val-tKF_plant_end.val);
              # TFPPlant['01020',t] =E= TFPPlant['01020',tKF_plant_end] + adj_pland *(t.val-tKF_plant_end.val);


          E_TFPPlant_hor_notKF[t,plant_out_top]$(tx1[t] and t.val >= %markupudfasetiaar_agr% and d1Plant_CET0['01020',plant_out_top,t] and sameas[plant_out_top,'Grain'])..
              plant_markup['01020',plant_out_top,t] =E= iteite*plant_markup.l['01020',plant_out_top,t];

          E_TFPPlant_hor_notgrain[t,plant_out_top]$(tx1[t] and d1Plant_CET0['01020',plant_out_top,t] and not sameas[plant_out_top,'Grain'])..
              plant_markup['01020',plant_out_top,t] =E= 0;


          E_TFP_plant_hor[t]$(tx1[t] and t.val<=%markupudfasetiaar_agr%)..
              TFPPlant['01020',t] =E= TFPPlant['01020',t-1] + adj_TFPPlant['01020'];
        $ENDIF

      $IF %calibratePlantManure%:
        #Manure per ha hodles så tæt på sidste data-år som muligt. Dog justeres, så vi rammer totalt udbudt manure.
        E_qPlantManure[plant_sectors,t]$(tx1[t] and tKF_plant[t] and d1Plant[plant_sectors,'Manure',t])..
         #We assume that the amount of fertilizer applied should be as close to baseline as possible, i.e. assuming that  
          (qPlant[plant_sectors,'manure',t] + qPlant[plant_sectors,'NPK',t]$(d1Plant[Plant_sectors,'NPK',t]))/qPlant[plant_sectors,'land',t]
             =E= (qPlant[plant_sectors,'Manure',t1] + qPlant[plant_sectors,'NPK',t1]$(d1Plant[plant_sectors,'NPK',t1]))/qPlant[plant_sectors,'Land',t1] + adj_Manure[t];

        E_uPlantManure_afterKF[plant_sectors,t]$(tx1[t] and t.val > tKF_plant_end.val and d1Plant[plant_sectors,'Manure',t])..
          uPlant[plant_sectors,'Manure',t] =E= uPlant[plant_sectors,'Manure',tKF_plant_end];
      $ENDIF

      $IF %calibrateNPK%:
        E_uPlant_NPK[plant_sectors,t]$(tx1[t] and t.val > tKF_plant_end.val and d1Plant[plant_sectors,'NPK',t])..
          uPlant[plant_sectors,'NPK',t] =E= uPlant[plant_sectors,'NPK',tKF_plant_end];
      $ENDIF

      #Hvis både NPK og Husdyrgødning låses kommer det de-facto til at være priserne på aggregatet, der tager slacket. Det er ikke hensigtsmæssigt. Derfor kalibreres aggregatet til et kædeindeks
      $IF (%calibrateNPK%) & (%calibratePlantManure%):
        E_qPlant_Fertilizer[plant_sectors,t]$(tx1[t] and tKF_plant[t] and d1Plant[plant_sectors,'Fertilizer',t])..
          pPlant[plant_sectors,'Fertilizer',t-1] * qPlant[plant_sectors,'Fertilizer',t] =E= sum(plant_$(PlantNest2inputs_('Fertilizer',Plant_) and d1Plant[plant_sectors,plant_,t]), pPlant[plant_sectors,plant_,t-1] * qPlant[plant_sectors,plant_,t]);

        E_uPlant_FertilizerAfterKF[plant_sectors,t]$(tx1[t] and t.val > tKF_plant_end.val and d1Plant[plant_sectors,'Fertilizer',t])..
          uPlant[plant_sectors,'Fertilizer',t] =E= uPlant[plant_sectors,'Fertilizer',tKF_plant_end];
      $ENDIF 


      #Når jorden mases på plads tabes relationen til kemikalier, da aggregatet LandChem ikke afspejler de underliggende ændringer i "præference" for jod.
    $IF %calibrateChemicalsPlusFinServL%:
      E_qPlant_Chemicals[plant_sectors,t]$(tx1[t] and tKF_plant[t] and d1Plant[plant_sectors,'Chemicals',t])..
        qPlant[plant_sectors,'Chemicals',t]/qPlant[plant_sectors,'land',t] =E= qPlant[plant_sectors,'Chemicals',t1]/qPlant[plant_sectors,'Land',t1];

      E_uPlant_Chemicals_afterKF[plant_sectors,t]$(tx1[t] and t.val > tKF_plant_end.val and d1Plant[plant_sectors,'Chemicals',t])..
        uPlant[Plant_sectors,'chemicals',t] =E= uPlant[plant_sectors,'chemicals',tKF_plant_end];

      E_qPlant_FinServL[plant_sectors,t]$(tx1[t] and tKF_plant[t] and d1Plant[plant_sectors,'FinancialServiceL',t])..
        qPlant[plant_sectors,'FinancialServiceL',t]/qPlant[Plant_sectors,'land',t] =E= qPlant[plant_sectors,'FinancialServiceL',t1]/qPlant[plant_sectors,'land',t1];

      E_uPlant_FinServL_afterKF[plant_sectors,t]$(tx1[t] and t.val > tKF_plant_end.val and d1Plant[plant_sectors,'FinancialServiceL',t])..
        uPlant[Plant_sectors,'FinancialServiceL',t] =E= uPlant[Plant_sectors,'FinancialServiceL',tKF_plant_end];
    $ENDIf

      #Hvis man både kalibrerer kemi og jord giver det ikke mening ikke at kalibrere aggregatet også.
    $IF (%lockland%) & (%calibrateChemicalsPlusFinServL%):
      E_qPlant_LandChem[plant_sectors,t]$(tx1[t] and tKF_plant[t] and d1Plant[Plant_sectors,'LandChem',t])..
        #  pPlant[plant_sectors,'LandChem',t-1] * qPlant[plant_sectors,'LandChem',t] =E= sum(plant_$(PlantNest2inputs_('LandChem',Plant_) and d1Plant[plant_sectors,plant_,t]), pPlant[plant_sectors,plant_,t-1] * qPlant[plant_sectors,plant_,t]);
        pPlant[plant_sectors,'LandChem',t-1] * qPlant[plant_sectors,'LandChem',t] =E= sum(plant_$(PlantNest2inputs_('LandChem',Plant_) and d1Plant[plant_sectors,plant_,t] and not sameas[plant_,'land']),
                                                                                                         pPlant[plant_sectors,plant_,t-1] * qPlant[plant_sectors,plant_,t])
                                                                                          +pPlant[plant_sectors,'land',t-1]*qPlant[plant_sectors,'land',t-1]; #Jord indgår lagget


      E_uPlant_LandChem_afterKF[plant_sectors,t]$(tx1[t] and t.val > tKF_plant_end.val and d1PLant[plant_sectors,'LandChem',t])..
        uPlant[plant_sectors,'LandChem',t] =E= uPlant[plant_sectors,'LandChem',tKF_plant_end];

    $ENDIF


      #Hvis man både kalibrerer kemi, jord, Husdyrgødning og NPK giver det ikke mening ikke også at kalibrere aggregatet (LF)

    $IF (%lockland%) & (%calibrateChemicalsPlusFinServL%) & (%calibratePlantManure%) & (%calibrateNPK%):

        E_qPlant_LF[plant_sectors,t]$(tx1[t] and tKF_plant[t] and d1Plant[plant_sectors,'LF',t])..
          pPlant[plant_sectors,'LF',t-1] * qPlant[plant_sectors,'LF',t] =E= sum(plant_$(PlantNest2inputs_('LF',Plant_) and d1Plant[plant_sectors,plant_,t]), pPlant[plant_sectors,plant_,t-1] * qPlant[plant_sectors,plant_,t]);


        E_uPlant_LF_afterKF[plant_sectors,t]$(tx1[t] and t.val > tKF_plant_end.val and d1Plant[plant_sectors,'LF',t])..
          uPlant[plant_sectors,'LF',t] =E= uPlant[plant_sectors,'LF',tKF_plant_end];

      $ENDIF


      #Jord
      $IF %uKland%:
        E_uK_land[plant_sectors,t]$(t.val > t2.val and d1plant[plant_sectors,'land',t])..
          uPlant[plant_sectors,'land',t] =E= uPlant[plant_sectors,'land',t1];
      $ENDIF

      $IF %lockland%:
   
       $IF1 %pLand2024calib%!=1:  
         E_pLand_adj[t]$(tx1[t] and t.val <=tKF_plant_end.val)..
          # pPlant['01011','land',t]$(not tKF_plant_end[t]) + pLand[t]$(tKF_plant_end[t])$(tKF_plant_end[t]) =E= pPlant['01011','land',t1]$(not tKF_plant_end[t]) + pLand[t-1]$(tKF_plant_end[t]);

            pPlant['01011','land',t] =E= pPlant['01011','land',t1] * adj_pland**(t.val-t1.val);
            # pLand[t] =E= pLand[t1]* adj_pland**(t.val-t1.val);
            # pPlant['01011','land',t] =E= pPlant['01011','land',t1] +  adj_pland *(t.val-t1.val);

      $ENDIF1

      $IF1 %pLand2024calib%==1:
        E_pLand_adj[t]$(tx1[t] and t.val <=tKF_plant_end.val and t.val > 2024)..
          #  pPlant['01011','land',t] =E= pPlant['01011','land','2022'] * adj_pland**(t.val-t1.val);
          pLand[t] =E= pLand['2024'] * adj_pland**(t.val-t1.val);  

          # pLand[t] =E= pLand[t-1] * adj_pland;
      $ENDIF1



        E_qPlant_Land_calib[plant_sectors,t]$(tx1[t] and t.val >tKF_plant_end.val)..
          thetaJ[plant_sectors,t] =E= thetaJ[plant_sectors,tKF_plant_end];

          # thetaJ[plant_sectors,t] =E= thetaJ[plant_sectors,t-1]/1.005;

      $ENDIF

     $ENDBLOCK

  # ----------------------------------------------------------------------------------------
  # 4b) Animal production, prices, productivity and manure production
  # ----------------------------------------------------------------------------------------


    $BLOCK B_KF25_ani_calib
     E_qAni_CET_KF25[ani_sectors,t]$(tx1[t] and tKF_ani[t] and (sameas[ani_sectors,'01031'] or sameas[ani_sectors,'01032'] or sameas[ani_sectors,'01051'] or sameas[ani_sectors,'01052'] or  sameas[ani_sectors,'01061'] or sameas[ani_sectors,'01062'])).. # and not sameas[ani_sectors,'01052']).. # and not (sameas[ani_sectors,'01052'] or sameas[ani_sectors,'01032'] or sameas[ani_sectors,'01062']))..
       qAni_CET[ani_sectors,'out_other',t] =E= (1-OneToZeroAgrIterator[ani_sectors]) * qAni_CET.l[ani_sectors,'out_other',t-1]
                                              + OneToZeroAgrIterator[ani_sectors] * qAni_CET[ani_sectors,'out_other',t-1]* (KF_qAni[ani_sectors,t]/KF_qAni[ani_sectors,t-1]);

     E_pAni_CET_KF25[ani_sectors,t]$(tx1[t] and tKF_ani[t] and (sameas[ani_sectors,'01031'] or sameas[ani_sectors,'01032'] or sameas[ani_sectors,'01051'] or sameas[ani_sectors,'01052'] or sameas[ani_sectors,'01061'] or sameas[ani_sectors,'01062'])).. # sameas[ani_sectors,'01052'])).. # not sameas[ani_sectors,'01070'] and not sameas[ani_sectors,'01032'] and not sameas[ani_sectors,'01052']).. # and not (sameas[ani_sectors,'01052'] or sameas[ani_sectors,'01032'] or sameas[ani_sectors,'01062']))..
       pAni_CET[ani_sectors,'out_other',t] =E= (1-OneToZeroAgrIterator[ani_sectors]) * pAni_CET.l[ani_sectors,'out_other',t-1] 
                                              + OneToZeroAgrIterator[ani_sectors] * pAni_CET[ani_sectors,'out_other',t-1]* (KF_pAni[ani_sectors,t]/KF_pAni[ani_sectors,t-1]);


    #Humans vs cows 2D
      #Conventional cows
        #Demand 
        E_qAni_cows_dairy_con[t]$(tx1[t]and tKF_ani[t] and d1X_y['xOth','10030',t]).. 
          {s}X_y['xOth','10030',t] =E= {s}X_y['xOth','10030',t1] * adj_qAni_cows_con[t];

        E_qAni_cows_dairy_con_afterKF[t]$(tx1[t] and t.val >tKF_ani_end.val and d1X_y['xOth','10030',t])..
          #  sX_y['xOth','10030',t] =E= sX_y['xOth','10030',tKF_ani_end];
          $IF1 %smoothafter2050_ani%!=1: sX_y['xOth','10030',t] =E= sX_y['xOth','10030',tKF_ani_end]; $ENDIF1
          $IF1 %smoothafter2050_ani%==1:sX_y['xOth','10030',t] =E= sX_y['xOth','10030',t-1] + 0.5 * (sX_y['xOth','10030',t-1]-sX_y['xOth','10030',t-2]); $ENDIF1


        #We also control slaughterhouse and direct exports 
        E_qAni_cows_slaughter_con[t]$(tx1[t] and tKF_ani[t] and d1X_y['xOth','10011',t])..
          {s}X_y['xOth','10011',t] =E= {s}X_y['xOth','10011',t1] * adj_qAni_cows_con[t];

        E_qAni_cows_slaughter_con_afterKF[t]$(tx1[t] and t.val > tKF_ani_end.val and d1X_y['xOth','10011',t])..
          
          $IF1 %smoothafter2050_ani%!=1: sX_y['xOth','10011',t] =E= sX_y['xOth','10011',tKF_ani_end]; $ENDIF1
          $IF1 %smoothafter2050_ani%==1:  sX_y['xOth','10011',t] =E= sX_y['xOth','10011',t-1] + 0.5 * (sX_y['xOth','10011',t-1]-sX_y['xOth','10011',t-2]); $ENDIF1



        #Direct export
        E_qAni_cows_con[t]$(tx1[t] and tKF_ani[t] and d1X_y['xOth','01031',t])..
          {s}X_y['xOth','01031',t] =E= {s}X_y['xOth','01031',t1] * adj_qAni_cows_con[t];

        E_qAni_cows_con_afterKF[t]$(tx1[t] and t.val > tKF_ani_end.val and d1X_y['xOth','01031',t])..
         $IF1 %smoothafter2050_ani%!=1: sX_y['xOth','01031',t] =E= sX_y['xOth','01031',tKF_ani_end]; $ENDIF1
         $IF1 %smoothafter2050_ani%==1: sX_y['xOth','01031',t] =E= sX_y['xOth','01031',t-1] + 0.5 * (sX_y['xOth','01031',t-1] - sX_y['xOth','01031',t-2]); $ENDIF1


        #Prices
        E_TFPAni_cows_con_after2050_notKF[t]$(tx1[t] and t.val > tKF_ani_end.val)..
          TFPAni['01031',t] =E= TFPAni['01031',tKF_ani_end];

        E_TFPani_cows_con_notKF[t]$(tx1[t] and t.val >= %markupudfasetiaar_agr%)..
            ani_markup['01031','out_other',t] =E= iteite*ani_markup.l['01031','out_other',t];

        E_TFP_ani_cows_con[t]$(tx1[t] and t.val<=%markupudfasetiaar_agr%)..
            TFPAni['01031',t] =E= TFPAni['01031',t-1] + adj_TFPAni['01031'];



        #Foreign slaugterhouses and dairy producers are assumed to follow domestic prices
        E_pM_CET_dairy_cows[t]$(tx1[t] and tKF_ani[t] and d1vM_CET['out_other','10030',t])..
          pM_CET['out_other','10030',t] =E= pY_CET['out_other','10030',t];

        E_pM_CET_dairy_cows_afterKF[t]$(tx1[t] and t.val > tKF_ani_end.val and d1vM_CET['out_other','10030',t])..
          pM_CET['out_other','10030',t] =E= pM_CET['out_other','10030',tKF_ani_end];


        E_pM_CET_slaughter_cows[t]$(tx1[t] and tKF_ani[t] and d1vM_CET['out_other','10011',t])..
          pM_CET['out_other','10011',t] =E= pY_CET['out_other','10011',t];

        E_pM_CET_slaughter_cows_afterKF[t]$(tx1[t] and t.val > tKF_ani_end.val and d1vM_CET['out_other','10011',t])..
          pM_CET['out_other','10011',t] =E= pM_CET['out_other','10011',tKF_ani_end];



      #Organic cows    
        E_qAni_cows_dairy_org[t]$(tx1[t] and d1RxE_ym['10030','01032',t] and tKF_ani[t])..
          {s}RxE_ym['10030','01032',t] =E= {s}RxE_ym['10030','01032',t1] * adj_qAni_cows_org[t];

        E_qAni_cows_dairy_org_afterKF[t]$(tx1[t] and d1RxE_ym['10030','01032',t] and t.val > tKF_ani_end.val)..
          $IF1 %smoothafter2050_ani%!=1: sRxE_ym['10030','01032',t] =E= sRxE_ym['10030','01032',tKF_ani_end]; $ENDIF1
          $IF1 %smoothafter2050_ani%==1:  sRxE_ym['10030','01032',t] =E= sRxE_ym['10030','01032',t-1] + 0.5*(sRxE_ym['10030','01032',t-1] -sRxE_ym['10030','01032',t-2]); $ENDIF1


        #We also control slaughterhouse and direct exports 
        E_qAni_cows_slaughter_org[t]$(tx1[t] and tKF_ani[t] and d1RxE_ym['10011','01032',t])..
          {s}RxE_ym['10011','01032',t] =E= {s}RxE_ym['10011','01032',t1] * adj_qAni_cows_org[t];

        E_qAni_cows_slaughter_org_afterKF[t]$(tx1[t] and t.val > tKF_ani_end.val and d1RxE_ym['10011','01032',t])..
          $IF1 %smoothafter2050_ani%!=1: sRxE_ym['10011','01032',t] =E= sRxE_ym['10011','01032',tKF_ani_end]; $ENDIF1
          $IF1 %smoothafter2050_ani%==1: sRxE_ym['10011','01032',t] =E= sRxE_ym['10011','01032',t-1] + 0.5 * (sRxE_ym['10011','01032',t-1] - sRxE_ym['10011','01032',t-2]); $ENDIF1


        #Direct export
        E_qAni_cows_org[t]$(tx1[t] and tKF_ani[t] and d1X_y['xOth','01032',t])..
          {s}X_y['xOth','01032',t] =E= {s}X_y['xOth','01032',t1] * adj_qAni_cows_org[t];

        E_qAni_cows_org_afterKF[t]$(tx1[t] and t.val > tKF_ani_end.val and d1X_y['xOth','01032',t])..
          $IF1 %smoothafter2050_ani%!=1: sX_y['xOth','01032',t] =E= sX_y['xOth','01032',tKF_ani_end]; $ENDIF1
          $IF1 %smoothafter2050_ani%==1: sX_y['xOth','01032',t] =E= sX_y['xOth','01032',t-1] + 0.5 * (sX_y['xOth','01032',t-1] - sX_y['xOth','01032',t-2]); $ENDIF1


        E_TFPAni_cows_org_after2050_notKF[t]$(tx1[t] and t.val > tKF_ani_end.val)..
          TFPAni['01032',t] =E= TFPAni['01032',tKF_ani_end];

        E_TFPani_cows_org_notKF[t]$(tx1[t] and t.val >= %markupudfasetiaar_agr%)..
            ani_markup['01032','out_other',t] =E= iteite*ani_markup.l['01032','out_other',t];

        E_TFP_ani_cows_org[t]$(tx1[t] and t.val<=%markupudfasetiaar_agr%)..
            TFPAni['01032',t] =E= TFPAni['01032',t-1] + adj_TFPAni['01032'];



    #We control deman for pigs through slaughterhouse export demand, we could consider also controlling direct export. 
      E_qAni_pigs_slaughter_con[t]$(tx1[t] and d1X_y['xOth','10012',t] and tKF_ani[t])..
      $IF1 %smaagrisesplit%!=1: 
        {s}X_y['xOth','10012',t] =E= {s}X_y['xOth','10012',t1] * adj_qAni_pigs_con[t];
      $ENDIF1
      $IF1 %smaagrisesplit%==1:
        {s}X_y['xOth','10012',t] =E= {s}X_y['xOth','10012',t1] * adj_qAni_pigs_org[t];
      $ENDIF1

      E_qAni_pigs_slaughter_con_afterKF[t]$(tx1[t] and d1X_y['xOth','10012',t] and t.val > tKF_ani_end.val)..
        $IF1 %smoothafter2050_ani%!=1: sX_y['xOth','10012',t] =E= sX_y['xOth','10012',tKF_ani_end]; $ENDIF1
        $IF1 %smoothafter2050_ani%==1: sX_y['xOth','10012',t] =E= sX_y['xOth','10012',t-1] + 0.5 * (sX_y['xOth','10012',t-1] - sX_y['xOth','10012',t-2]); $ENDIF1

      E_qAni_pigs_direct_con[t]$(tx1[t] and d1X_y['xOth','01051',t] and tKF_ani[t]).. 
        {s}X_y['xOth','01051',t] =E= {s}X_y['xOth','01051',t1] * adj_qAni_pigs_con[t];


      E_qAni_pigs_direct_con_afterKF[t]$(tx1[t] and d1X_y['xOth','01051',t] and t.val > tKF_ani_end.val)..
        $IF1 %smoothafter2050_ani%!=1: sX_y['xOth','01051',t] =E= sX_y['xOth','01051',tKF_ani_end]; $ENDIF1
        $IF1 %smoothafter2050_ani%==1:  sX_y['xOth','01051',t] =E= sX_y['xOth','01051',t-1] + 0.5 * (sX_y['xOth','01051',t-1] - sX_y['xOth','01051',t-2]); $ENDIF1


      #Foreign slaugterhouses are assumed to follow same prices as domestique 
      E_pM_CET_slaughter_pigs[t]$(tx1[t] and tKF_ani[t] and d1vM_CET['out_other','10012',t])..
        pM_CET['out_other','10012',t] =E= pY_CET['out_other','10012',t];

      E_pM_CET_slaughter_pigs_afterKF[t]$(tx1[t] and t.val > tKF_ani_end.val and d1vM_CET['out_other','10012',t])..
        pM_CET['out_other','10012',t] =E= pM_CET['out_other','10012',tKF_ani_end];

   

      E_TFPAni_pigs_con_after2050_notKF[t]$(tx1[t] and t.val > tKF_ani_end.val)..
         $IF1 %smoothafter2050_ani%!=1: TFPAni['01051',t] =E= TFPAni['01051',tKF_ani_end]; $ENDIF1
         $IF1 %smoothafter2050_ani%==1:  TFPAni['01051',t] =E= TFPAni['01051',t-1] + 0.5 * (TFPAni['01051',t-1]-TFPAni['01051',t-2]); $ENDIF1


      E_TFPani_pigs_con_notKF[t]$(tx1[t] and t.val >= %markupudfasetiaar_agr%)..
          ani_markup['01051','out_other',t] =E= iteite*ani_markup.l['01051','out_other',t];

      E_TFP_ani_pigs_con[t]$(tx1[t] and t.val<=%markupudfasetiaar_agr%)..
          TFPAni['01051',t] =E= TFPAni['01051',t-1] + adj_TFPAni['01051'];

      $IF2 %smaagrisesplit%!=1:
      E_qAni_pigs_org_sRxE[t]$(tx1[t] and d1RxE_ym['10012','01052',t] and tKF_ani[t])..
        {s}RxE_ym['10012','01052',t] =E= {s}RxE_ym['10012','01052',t1] * adj_qAni_pigs_org[t];

      E_qAni_pigs_org_sRxE_afterKF[t]$(tx1[t] and d1RxE_ym['10012','01052',t] and t.val>tKF_ani_end.val)..
        $IF1 %smoothafter2050_ani%!=1: sRxE_ym['10012','01052',t] =E= sRxE_ym['10012','01052',tKF_ani_end]; $ENDIF1
        $IF1 %smoothafter2050_ani%==1: sRxE_ym['10012','01052',t] =E= sRxE_ym['10012','01052',t-1] + 0.5 * (sRxE_ym['10012','01052',t-1] - sRxE_ym['10012','01052',t-2]); $ENDIF1
      $ENDIF2

      E_qAni_pigs_org_X[t]$(tx1[t] and d1X_y['xOth','01052',t] and tKF_ani[t]).. 
        {s}X_y['xOth','01052',t] =E= {s}X_y['xOth','01052',t1] * adj_qAni_pigs_org[t];

      E_qAni_pigs_org_X_afterKF[t]$(tx1[t] and d1X_y['xOth','10012',t] and t.val > tKF_ani_end.val)..
        $IF1 %smoothafter2050_ani%!=1: sX_y['xOth','01052',t] =E= sX_y['xOth','01052',tKF_ani_end]; $ENDIF1
        $IF1 %smoothafter2050_ani%==1:  sX_y['xOth','01052',t] =E= sX_y['xOth','01052',t-1] + 0.5*(sX_y['xOth','01052',t-1] - sX_y['xOth','01052',t-2]); $ENDIF1


      E_TFPAni_pigs_org_after2050_notKF[t]$(tx1[t] and t.val > tKF_ani_end.val)..
        TFPAni['01052',t] =E= TFPAni['01052',tKF_ani_end];

      E_TFPani_pigs_org_notKF[t]$(tx1[t] and t.val >= %markupudfasetiaar_agr%)..
          ani_markup['01052','out_other',t] =E= iteite*ani_markup.l['01052','out_other',t];

      E_TFP_ani_pigs_org[t]$(tx1[t] and t.val<=%markupudfasetiaar_agr%)..
          TFPAni['01052',t] =E= TFPAni['01052',t-1] + adj_TFPAni['01052'];



    #Poul 
      #For poultry there is a significant direct export on top of the processed chicken meat
      #Conventional 
        E_qAni_poul_Slaughterhouse_con[t]$(tx1[t] and d1X_y['xOth','10013',t] and tKF_ani[t]).. 
          {s}X_y['xOth','10013',t] =E= {s}X_y['xOth','10013',t1] * adj_qAni_poul_con[t];

        E_qAni_poul_Slaughterhouse_con_afterKF[t]$(tx1[t] and d1X_y['xOth','10013',t] and t.val > tKF_ani_end.val)..
          $IF1 %smoothafter2050_ani%!=1: sX_y['xOth','10013',t] =E= sX_y['xOth','10013',tKF_ani_end]; $ENDIF1
          $IF1 %smoothafter2050_ani%==1: sX_y['xOth','10013',t] =E= sX_y['xOth','10013',t-1] + 0.5 * (sX_y['xOth','10013',t-1] - sX_y['xOth','10013',t-2]); $ENDIF1


        E_qAni_poul_direct_con[t]$(tx1[t] and d1X_y['xOth','01061',t] and tKF_ani[t]).. 
          {s}X_y['xOth','01061',t] =E= {s}X_y['xOth','01061',t1] * adj_qAni_poul_con[t];

        E_qAni_poul_direct_con_afterKF[t]$(tx1[t] and d1X_y['xOth','01061',t] and t.val > tKF_ani_end.val)..
          $IF1 %smoothafter2050_ani%!=1: sX_y['xOth','01061',t] =E= sX_y['xOth','01061',tKF_ani_end]; $ENDIF1
          $IF1 %smoothafter2050_ani%==1: sX_y['xOth','01061',t] =E= sX_y['xOth','01061',t-1] + 0.5 * (sX_y['xOth','01061',t-1] - sX_y['xOth','01061',t-2]); $ENDIF1


        E_TFPAni_poul_con_after2050_notKF[t]$(tx1[t] and t.val > tKF_ani_end.val)..
          TFPAni['01061',t] =E= TFPAni['01061',tKF_ani_end];

        E_TFPani_poul_con_notKF[t]$(tx1[t] and t.val >= %markupudfasetiaar_agr%)..
            ani_markup['01061','out_other',t] =E= iteite*ani_markup.l['01061','out_other',t];

        E_TFP_ani_poul_con[t]$(tx1[t] and t.val<=%markupudfasetiaar_agr%)..
            TFPAni['01061',t] =E= TFPAni['01061',t-1] + adj_TFPAni['01061'];


        #Foreign slaugterhouses are assumed to follow same prices as domestique 
        E_pM_CET_slaughter_poul[t]$(tx1[t] and tKF_ani[t] and d1vM_CET['out_other','10013',t])..
          pM_CET['out_other','10013',t] =E= pY_CET['out_other','10013',t];

        E_pM_CET_slaughter_poul_afterKF[t]$(tx1[t] and t.val > tKF_ani_end.val and d1vM_CET['out_other','10013',t])..
          pM_CET['out_other','10013',t] =E= pM_CET['out_other','10013',tKF_ani_end];

          


      #Organic 
      E_qAni_poul_slaughter_org[t]$(tx1[t] and d1RxE_ym['10013','01062',t] and tKF_ani[t])..
        {s}RxE_ym['10013','01062',t] =E= {s}RxE_ym['10013','01062',t1] * adj_qAni_poul_org[t];

      E_qAni_poul_slaughter_org_afterKF[t]$(tx1[t] and d1RxE_ym['10013','01062',t] and t.val > tKF_ani_end.val)..
        $IF1 %smoothafter2050_ani%!=1: sRxE_ym['10013','01062',t] =E= sRxE_ym['10013','01062',tKF_ani_end]; $ENDIF1
        $IF1 %smoothafter2050_ani%==1:  sRxE_ym['10013','01062',t] =E= sRxE_ym['10013','01062',t-1] + 0.5 * (sRxE_ym['10013','01062',t-1] - sRxE_ym['10013','01062',t-2]); $ENDIF1

      E_qAni_poul_org[t]$(tx1[t] and tKF_ani[t] and d1X_y['xOth','01062',t])..
          {s}X_y['xOth','01062',t] =E= {s}X_y['xOth','01062',t1] * adj_qAni_poul_org[t];

      E_qAni_poul_org_afterKF[t]$(tx1[t] and d1X_y['xOth','01062',t] and t.val > tKF_ani_end.val)..
          $IF1 %smoothafter2050_ani%!=1:  sX_y['xOth','01062',t] =E= sX_y['xOth','01062',tKF_ani_end]; $ENDIF1
          $IF1 %smoothafter2050_ani%==1:  sX_y['xOth','01062',t] =E= sX_y['xOth','01062',t-1] + 0.5 * (sX_y['xOth','01062',t-1] - sX_y['xOth','01062',t-2]); $ENDIF1


        E_TFPAni_poul_org_after2050_notKF[t]$(tx1[t] and t.val > tKF_ani_end.val)..
          TFPAni['01062',t] =E= TFPAni['01062',tKF_ani_end];

        E_TFPani_poul_org_notKF[t]$(tx1[t] and t.val >= %markupudfasetiaar_agr%)..
            ani_markup['01062','out_other',t] =E=iteite*ani_markup.l['01062','out_other',t];

        E_TFP_ani_poul_org[t]$(tx1[t] and t.val<=%markupudfasetiaar_agr%)..
            TFPAni['01062',t] =E= TFPAni['01062',t-1] + adj_TFPAni['01062'];

    $ENDBLOCK
  $ENDFOR


  # ----------------------------------------------------------------------------------------
  # Animals split on conventional and organic
  # ----------------------------------------------------------------------------------------


  $IF %calibrateNumberAnimals_poul%:
    $BLOCK B_uAni_animals_poul_calib
        #Poultry
        E_qAni_animals_poul[ani_sectors,animals,t]$(tx1[t] and tKF_animals[t] and d1Ani[ani_sectors,animals,t] and Animals2Anisectors(Animals,ani_sectors) and (sameas[ani_sectors,'01061'] or sameas[ani_sectors,'01062']))..
          qAni[ani_sectors,animals,t]/qAni[ani_sectors,animals,t-1] =E= qAni_CET[Ani_sectors,'out_other',t] / qAni_CET[Ani_sectors,'out_other',t-1]+ adj_animals[animals,t];

        E_adj_animals_poul[animals,t]$(tx1[t] and tKF_animals[t] and (sameas[animals,'Poultry']))..
          sum(ani_sectors$(d1Ani[ani_sectors,animals,t]), qAni[ani_sectors,animals,t]) =E= sum(ani_sectors, KF_animals[ani_sectors,animals,t]); 
      
        E_uAnimals_poul_afterKF[ani_sectors,ani_,t]$(tx1[t] and t.val > tKF_animals_end.val and d1Ani[ani_sectors,ani_,t] and animals[ani_] and (sameas[ani_sectors,'01061'] or sameas[ani_sectors,'01062']))..
          uAni[ani_sectors,ani_,t] =E= uAni[ani_sectors,ani_,tKF_animals_end];

        E_uAnimals_not_poul_afterKF[ani_sectors,ani_,t]$(tx1[t] and t.val > tKF_animals_end.val and d1Ani[ani_sectors,ani_,t] and animals[ani_] and (sameas[ani_sectors,'01031'] or sameas[ani_sectors,'01032'] or sameas[ani_sectors,'01051'] or sameas[ani_sectors,'01052']))..
          uAni[ani_sectors,ani_,t] =E= uAni[ani_sectors,ani_,tKF_animals_end];

    $ENDBLOCK
  $ENDIF

  $IF %calibrateNumberAnimals_cowsnpigs%:
     $BLOCK B_uAni_animals_cowsnpigs_calib
        #When we alter the pig distribution we in turn alter the grazing emissions     
        E_uEmmAgrAnimals_NH3_pigs[t]$(tx1[t] and tKF_animals[t] and sum(animals, d1EmmAgrAni['GrazingAnimals','01051',animals,t,'NH3'] or d1EmmAgrAni['GrazingAnimals','01052',animals,t,'NH3']))..
          KF_qEmmAgrAnimals_NH3['GrazingAnimals','PigsFattening',t] =E= sum(animals, qEmmAgrAni['GrazingAnimals','01051',animals,t,'NH3']$(d1EmmAgrAni['GrazingAnimals','01051',animals,t,'NH3']) 
                                                                                   + qEmmAgrAni['GrazingAnimals','01052',animals,t,'NH3']$(d1EmmAgrAni['GrazingAnimals','01052',animals,t,'NH3']));

        E_adj_uEmmAgrAnimals_NH3_pigs[pigsec,animals,t]$(tx1[t] and tKF_animals[t] and (d1EmmAgrAni['GrazingAnimals','01051',animals,t,'NH3'] or d1EmmAgrAni['GrazingAnimals','01052',animals,t,'NH3']))..
          uEmmAgrAni['GrazingAnimals',pigsec,animals,t,'NH3'] =E= uEmmAgrAni.l['GrazingAnimals',pigsec,animals,t,'NH3'] * adj_NH3_pigs[t];

        E_uEMmAgrAni_Nh3_PIGS_after_tKF_animals_end[pigsec,animals,t]$(tx1[t] and t.val >tKF_animals_end.val and (d1EmmAgrAni['GrazingAnimals','01051',animals,t,'NH3'] or d1EmmAgrAni['GrazingAnimals','01052',animals,t,'NH3']))..
          uEmmAgrAni['GrazingAnimals',pigsec,animals,t,'NH3'] =E= uEmmAgrAni['GrazingAnimals',pigsec,animals,tKF_animals_end,'NH3'];        
     $ENDBLOCK
  $ENDIF



    #Gødningsproduktion 
      $IF %calibrateNManure%:

        $BLOCK B_qNMANURE_calib
        $IF1 %calibrateNManure_perdata% !=1:
        E_qNManure_tKF_notCows[ani_sectors,animals,t]$(tx1[t] and tKF_animals[t] and d1Ani[ani_sectors,animals,t] and (sameas[ani_sectors,'01051'] or sameas[ani_sectors,'01052'] or sameas[ani_sectors,'01061'] or sameas[ani_sectors,'01062']))..
          qNManure[ani_sectors,animals,t] =E= qAni[ani_sectors,animals,t]/sum(ani_sectorss$(d1Ani[ani_sectorss,animals,t]), qAni[ani_sectorss,animals,t]) * sum(ani_sectorss, KF_NabDyrViaLager[ani_sectorss,animals,t]);
        $ENDIF1

        E_qNManure_KF[ani_sectors,animals,t]$(tx1[t] and t.val > tKF_animals_end.val and sum(emm,d1EmmAgrAni['ManureManagement',ani_sectors,Animals,t,emm])).. 
           uManurePerAnimal[ani_sectors,animals,t] =E= uManurePerAnimal[ani_sectors,animals,tKF_animals_end];
      $ENDBLOCK

    $ENDIF



  # ----------------------------------------------------------------------------------------
  # 4c) Additional equations for agriculture as a whole
  # ----------------------------------------------------------------------------------------


    $BLOCK B_agr_integration_other
        E_pY_CET0_notagri[out,sp,t]$(tx0[t] and d1vY_CET[out,sp,t] and not agri_sectors_s[sp]).. 
            qY_CETgross[out,sp,t] =E= uY_CET[out,sp,t] * (pY0_CET[out,sp,t]/pY0[sp,t])**eCET[sp] *qY[sp,t];  

        E_qY_notagri[sp,t]$(tx0[t] and not agri_sectors_s[sp])..    
          pY0[sp,t]*qY[sp,t] =E= sum(out$d1vY_CET[out,sp,t], pY0_CET[out,sp,t] * qY_CETgross[out,sp,t]);     

       #  E_qIt_alt[sp,t]$(tx0[t]).. qIt[sp,t] =E= uIt[sp,t] * abs(pIt[sp,t]/pTKE[sp,t])**(-eTKE[sp]) * qTKE[sp,t];

       E_qIt_alt[sp,t]$(tx0[t]).. qProd['TK',sp,t] =E= uProd['TK',sp,t] * abs(pProd['TK',sp,t]/pProd['TKE',sp,t])**(-eProd['TKE',sp]) * qProd['TKE',sp,t];


        E_pK_plant_link[k,plant_sectors,t]$(t.val > t2.val and d1k[k,plant_sectors,t]).. pk[k,plant_sectors,t] =E= sum(plant_pK$agri2k[plant_pK,k], pPlant_uc[plant_sectors,plant_pK,t]);

        E_pK_ani_link[k,ani_sectors,t]$(t.val > t2.val and d1k[k,ani_sectors,t]).. pK[k,ani_sectors,t] =E= sum(ani_pK$agri2k[ani_pK,k], pAni_uc[ani_sectors,ani_pK,t]);

    $ENDBLOCK
   
    $BLOCK B_jstozero_calib

      E_jpK_ani_alt[ani_sectors,ani_pK,k,t]$(d1K[k,ani_sectors,t] and agri2k[ani_pK,k] and tx1[t] and t.val > t2.val and not sameas[ani_pK,'TransportCapital'] and not (sameas[ani_sectors,'01032'] or sameas[ani_sectors,'01052'] or sameas[ani_sectors,'01061'] or sameas[ani_sectors,'01062'])).. # or sameas[ani_sectors,'01070'] or sameas[ani_sectors,'01032'])).. # and not sameas[ani_sectors,'01032']).. # and not sameas[ani_sectors,'01051'])..                                                         #£HER
          jpK_ani[ani_sectors,ani_pK,t] =E=  0*jpK_ani[ani_sectors,ani_pK,t-1]$(not (sameas[ani_sectors,'01070'])) + 0.5*jpK_ani[ani_sectors,ani_pK,t-1]$(sameas[ani_sectors,'01070']);

      #  E_uPlant_01012[plant_pK,t]$(t.val > t2.val)..
      #    uPlant['01012',plant_pK,t] =E= 0.5 * uPlant['01012',plant_pK,t1] + 0.5*uPlant['01012',plant_pK,t2];

      #  E_uAni_01031[ani_pK,t]$(t.val >t2.val and not sameas[ani_pK,'TransportCapital'])..
      #    uAni['01031',ani_pK,t] =E= uAni['01031',ani_pK,t2];


      #  E_uAni_01032[ani_pK,t]$(t.val >t2.val and not sameas[ani_pK,'TransportCapital'])..
      #    uAni['01032',ani_pK,t] =E= uAni['01032',ani_pK,t2];

       E_uAni_01052[ani_pK,t]$(t.val > t2.val and not sameas[ani_pK,'TransportCapital'])..
         uAni['01052',ani_pK,t] =E= uAni['01052',ani_pK,t2];                                   


       E_uAni_01061[ani_pK,t]$(t.val > t2.val and not sameas[ani_pK,'TransportCapital'])..
         uAni['01061',ani_pK,t] =E= uAni['01061',ani_pK,t2];                                   

      #  E_uAni_01062[ani_pK,t]$(t.val > t2.val and not sameas[ani_pK,'TransportCapital'])..
      #   uAni['01062',ani_pK,t] =E= uAni['01062',ani_pK,t2];

      #  E_uAni_01070[ani_pK,t]$(t.val > t2.val and not sameas[ani_pK,'TransportCapital'])..
      #    uAni['01070',ani_pK,t] =E= uAni['01070',ani_pK,t2];                                   

      E_jpK_plant_alt[plant_sectors,plant_pK,k,t]$(d1K[k,plant_sectors,t] and agri2k[plant_pK,k] and tx1[t] and t.val > t2.val and not sameas[plant_pK,'TransportCapital']).. #and not sameas[plant_sectors,'01012']).. # and t.val<=2025)..
          jpK_plant[plant_sectors,plant_pK,t] =E= 0*jpK_plant[plant_sectors,plant_pK,t2]$(not sameas[plant_sectors,'01012'])
                                                  + 0.8* jpK_plant[plant_sectors,plant_pK,t-1]$(sameas[plant_sectors,'01012']);

      E_jpK_land_alt[plant_sectors,t]$(t.val > t2.val and d1Plant[plant_sectors,'land',t]).. 
          jpK_land[plant_sectors,t] =E= 0*jpK_land[plant_sectors,t2];

      # #We calibrate jpK_land so that user-cost in baseline is based on a discount-rate of 7%. When shocking the model the response will be with the 5 percent discount rate
      # $IF %uKland%:
      # E_jpK_land_alt_alt[plant_sectors,t]$(tx0E[t] and d1Plant[plant_sectors,'land',t])..
     	# pPlant[plant_sectors,'land',t+1]*fv*(1-tCorp[t+1]) =E= (1+0.07) * (1-tCorp[t]) * pPlant[plant_sectors,'grossprod',t] * dInstcostlandT[plant_sectors,t]
     	# 	+ (1-tCorp[t+1])* pPlant[plant_sectors,'grossprod',t+1] * fp * dInstcostlandTp1[plant_sectors,t+1] *fq 
     	# 	+ (1+0.07) *pLand[t] - pLand[t+1]*fv
			# - ((0.07 - rBonds[plant_sectors,'2025']*(1-tCorp[t+1])) * sDebt2j[plant_sectors,t] * pLand[t])$(t.val<2025)
			# - ((0.07 - rBonds[plant_sectors,t+1]*(1-tCorp[t+1]))    * sDebt2j[plant_sectors,t] * pLand[t])$(t.val>=2025)
     	# 	- (1-tCorp[t+1]) * tHectareSubsidy[t+1] *fv
     	# 	+ (1-tCorp[t+1]) * tLand[plant_sectors,t+1] * pLand[t]
     	# 	- (1-tCorp[t+1]) * sum(idxUnobservable,  pLandvalueFromUnobserved[idxUnobservable, plant_sectors,t+1]) 
     	# 	- (1-tCorp[t+1]) * tPerHectareBottomDeduction[t+1] *fv

    	# # A CO2-tax per unit of land is levied on farmers 
     	# 	+ (vCO2_plant[plant_sectors,'land',t+1]*fv/qPlant[plant_sectors,'land',t])$(d1EmmAgrxE['Mineralization',plant_sectors,t,'CO2e'] or d1EmmAgrxE['Other',plant_sectors,t,'CO2e'] or d1EmmAgrxE['CropResidues',plant_sectors,t,'CO2e']) 
     	# 	+ sum((Techplant,Emmtype)$(emmtype2plant_[emmtype,'land'] and sum(emm, d1Thetaplant[Techplant,plant_sectors,emmtype,t,emm])), vEOPCostplant_TechTot[Techplant,Emmtype,plant_sectors,t+1]*fv/qPlant[plant_sectors,'land',t])$(d1EmmAgrxE['Mineralization',plant_sectors,t,'CO2e'] or d1EmmAgrxE['Other',plant_sectors,t,'CO2e'])
     	# 	- sum((Techplant,Emmtype)$(emmtype2plant_[emmtype,'land'] and sum(emm, d1Thetaplant[Techplant,plant_sectors,emmtype,t,emm])), vTech_subsidy_plant[Techplant,EmmType,plant_sectors,t+1]*fv/qPlant[plant_sectors,'land',t])$(d1EmmAgrxE['Mineralization',plant_sectors,t,'CO2e'] or d1EmmAgrxE['Other',plant_sectors,t,'CO2e'])
     	# 	+ jpK_land[plant_sectors,t+1];
      # $ENDIF

    $ENDBLOCK

    $BLOCK B_calib_machinestation_and_mink
        E_markup_mink[t]$(tx1[t] and t.val <= %markupudfasetiaar_mink%)..
          ani_markup['01070','out_other',t] =E= ani_markup['01070','out_other',t-1] + adj_markup_ani['01070','out_other'];

        E_markup_mink_after_markupudfasetiaar_mink[t]$(tx1[t] and t.val >= %markupudfasetiaar_mink%)..
          ani_markup['01070','out_other',t] =E= ani_markup['01070','out_other',t1]; # iteite * ani_markup.l['01070','out_other',t];


        E_markup_machinestation[t]$(tx1[t] and t.val <=%markupudfasetiaar_agr%).. 
          TFP['KELBM','01080',t] =E= TFP['KELBM','01080',t-1] + adj_markup_machinestation;

        E_markup_machinestation_after[t]$(tx1[t] and t.val > %markupudfasetiaar_agr%)..
          TFP['KELBM','01080',t] =E= TFP['KELBM','01080','%markupudfasetiaar_agr%'];

        # Samme enhedsomkostning som i udgangspunktet  
        E_TFP_machinestation_target..
          pY0['01080','%markupudfasetiaar_agr%'] =E= pY0['01080',t1]; 

        E_markup_machinestation_markuppath[t]$(tx1[t] and t.val <%markupudfasetiaar_agr%)..
          markup['out_other','01080',t] =E= markup['out_other','01080',t1]*(%markupudfasetiaar_agr%-t.val)/(%markupudfasetiaar_agr%-t1.val);

        E_markup_machinestation_aftertarget[t]$(tx1[t] and t.val >= %markupudfasetiaar_agr%)..
          markup['out_other','01080',t] =E= 0; # markup['out_other','01080','%markupudfasetiaar_agr%'];
    $ENDBLOCK 


  # ----------------------------------------------------------------------------------------
  # 4d) Non-energy emissions from the Climate Outlook
  # ----------------------------------------------------------------------------------------

    $BLOCK B_emissions_agr_calib 
      
      #TARGET EQUATIONS
        E_qEmmAgrxE_other[emm,t]$(tx1[t] and KF_landemissions['Other',emm,t] and sum(plant_sectors,d1EmmAgrxE['Other',plant_sectors,t,emm]))..
          KF_landemissions['Other',emm,t]/(1$(not GWP.l[emm]) + GWP[emm]$(GWP.l[emm]))*1000 =E= sum(plant_sectors$(d1EmmAgrxE['Other',plant_sectors,t,emm]), qEmmAgrxE['Other',plant_sectors,t,emm]);

        E_qEmmAgrxE_N2OfromLeaching[emm,t]$(tx1[t] and KF_landemissions['N2OfromLeaching',emm,t] and sum(plant_sectors,d1EmmAgrxE['N2OfromLeaching',plant_sectors,t,emm]))..
          KF_landemissions['N2OfromLeaching',emm,t]/(1$(not GWP.l[emm]) + GWP[emm]$(GWP.l[emm]))*1000 =E= sum(plant_sectors$(d1EmmAgrxE['N2OfromLeaching',plant_sectors,t,emm]), qEmmAgrxE['N2OfromLeaching',plant_sectors,t,emm]);

        E_qEmmAgrxE_Mineralization[emm,t]$(tx1[t] and KF_landemissions['Mineralization',emm,t] and sum(plant_sectors,d1EmmAgrxE['Mineralization',plant_sectors,t,emm]))..
          KF_landemissions['Mineralization',emm,t]/(1$(not GWP.l[emm]) + GWP[emm]$(GWP.l[emm]))*1000 =E= sum(plant_sectors$(d1EmmAgrxE['Mineralization',plant_sectors,t,emm]), qEmmAgrxE['Mineralization',plant_sectors,t,emm]);

        E_qEmmAgrxE_OrganicSoilsInProduction[emm,t]$(tx1[t] and KF_landemissions['OrganicSoilsInProduction',emm,t] and sum(plant_sectors,d1EmmAgrxE['OrganicSoilsInProduction',plant_sectors,t,emm]))..
          KF_landemissions['OrganicSoilsInProduction',emm,t]/(1$(not GWP.l[emm]) + GWP[emm]$(GWP.l[emm]))*1000 =E= sum(plant_sectors$(d1EmmAgrxE['OrganicSoilsInProduction',plant_sectors,t,emm]), qEmmAgrxE['OrganicSoilsInProduction',plant_sectors,t,emm]);

        E_qEmmAgrxE_InorganicFertilizer[emm,t]$(tx1[t] and KF_landemissions['InorganicFertilizer',emm,t] and sum(plant_sectors,d1EmmAgrxE['InorganicFertilizer',plant_sectors,t,emm]))..
          KF_landemissions['InorganicFertilizer',emm,t]/(1$(not GWP.l[emm]) + GWP[emm]$(GWP.l[emm]))*1000 =E= sum(plant_sectors$(d1EmmAgrxE['InorganicFertilizer',plant_sectors,t,emm]), qEmmAgrxE['InorganicFertilizer',plant_sectors,t,emm]);

        E_qEmmAgrxE_Manure[emm,t]$(tx1[t] and KF_landemissions['Manure',emm,t] and sum(plant_sectors,d1EmmAgrxE['Manure',plant_sectors,t,emm]))..
          KF_landemissions['Manure',emm,t]/(1$(not GWP.l[emm]) + GWP[emm]$(GWP.l[emm]))*1000 =E= sum(plant_sectors$(d1EmmAgrxE['Manure',plant_sectors,t,emm]), qEmmAgrxE['Manure',plant_sectors,t,emm]);

        E_qEmmAgrxE_CropResidues[emm,t]$(tx1[t] and KF_landemissions['CropResidues',emm,t] and sum(plant_sectors,d1EmmAgrxE['CropResidues',plant_sectors,t,emm]))..
          KF_landemissions['CropResidues',emm,t]/(1$(not GWP.l[emm]) + GWP[emm]$(GWP.l[emm]))*1000 =E= sum(plant_sectors$(d1EmmAgrxE['CropResidues',plant_sectors,t,emm]), qEmmAgrxE['CropResidues',plant_sectors,t,emm]);

      #ADJUSTMENT EQUATIONS - EMISSION COEFFICIENTS ARE ADJUSTED TO HIT TARGETS (ABOVE)
        E_qEmmAgrxE_other_adj[emm,plant_sectors,t]$(tx1[t] and d1EmmAgrxE['Other',plant_sectors,t,emm] and KF_landemissions['Other',emm,t])..
          uEmmAgrxE['Other',plant_sectors,t,emm] =E= uEmmAgrxE.l['Other',plant_sectors,t,emm] * adj_uEmmAgrxE['other',t,emm];

        E_qEmmAgrxE_N2OFromLeaching_adj[emm,plant_sectors,t]$(tx1[t] and d1EmmAgrxE['N2OFromLeaching',plant_sectors,t,emm] and KF_landemissions['N2OFromLeaching',emm,t])..
          uEmmAgrxE['N2OFromLeaching',plant_sectors,t,emm] =E= uEmmAgrxE.l['N2OFromLeaching',plant_sectors,t,emm] * adj_uEmmAgrxE['N2OFromLeaching',t,emm];

        E_qEmmAgrxE_Mineralization_adj[emm,plant_sectors,t]$(tx1[t] and d1EmmAgrxE['Mineralization',plant_sectors,t,emm] and KF_landemissions['Mineralization',emm,t])..
          uEmmAgrxE['Mineralization',plant_sectors,t,emm] =E= uEmmAgrxE.l['Mineralization',plant_sectors,t,emm] * adj_uEmmAgrxE['Mineralization',t,emm];

        E_qEmmAgrxE_OrganicSoilsInProduction_adj[emm,plant_sectors,t]$(tx1[t] and d1EmmAgrxE['OrganicSoilsInProduction',plant_sectors,t,emm] and KF_landemissions['OrganicSoilsInProduction',emm,t])..
          uEmmAgrxE['OrganicSoilsInProduction',plant_sectors,t,emm] =E= uEmmAgrxE.l['OrganicSoilsInProduction',plant_sectors,t,emm] * adj_uEmmAgrxE['OrganicSoilsInProduction',t,emm];

        E_qEmmAgrxE_InorganicFertilizer_adj[emm,plant_sectors,t]$(tx1[t] and d1EmmAgrxE['InorganicFertilizer',plant_sectors,t,emm] and KF_landemissions['InorganicFertilizer',emm,t])..
          uEmmAgrxE['InorganicFertilizer',plant_sectors,t,emm] =E= uEmmAgrxE.l['InorganicFertilizer',plant_sectors,t,emm] * adj_uEmmAgrxE['InorganicFertilizer',t,emm];

        E_qEmmAgrxE_Manure_adj[emm,plant_sectors,t]$(tx1[t] and d1EmmAgrxE['Manure',plant_sectors,t,emm] and KF_landemissions['Manure',emm,t])..
          uEmmAgrxE['Manure',plant_sectors,t,emm] =E= uEmmAgrxE.l['Manure',plant_sectors,t,emm] * adj_uEmmAgrxE['Manure',t,emm];

        E_qEmmAgrxE_CropResidues_adj[emm,plant_sectors,t]$(tx1[t] and d1EmmAgrxE['CropResidues',plant_sectors,t,emm] and KF_landemissions['CropResidues',emm,t])..
          uEmmAgrxE['CropResidues',plant_sectors,t,emm] =E= uEmmAgrxE.l['CropResidues',plant_sectors,t,emm] * adj_uEmmAgrxE['CropResidues',t,emm];

      #AFTER 2050 EMISSION COEFFICIENTS ARE FORECAST FLAT
        E_qEmmAgrxE_other_adj_post2050[emm,plant_sectors,t]$(tx1[t] and d1EmmAgrxE['Other',plant_sectors,t,emm] and t.val > tKF_plant_end.val and not sameas[emm,"NH3"])..
          uEmmAgrxE['Other',plant_sectors,t,emm] =E= uEmmAgrxE['Other',plant_sectors,tKF_plant_end,emm];

        E_qEmmAgrxE_N2OFromLeaching_adj_post2050[emm,plant_sectors,t]$(tx1[t] and d1EmmAgrxE['N2OFromLeaching',plant_sectors,t,emm] and t.val > tKF_plant_end.val)..
          uEmmAgrxE['N2OFromLeaching',plant_sectors,t,emm] =E= uEmmAgrxE['N2OFromLeaching',plant_sectors,tKF_plant_end,emm];

        E_qEmmAgrxE_Mineralization_adj_post2025[emm,plant_sectors,t]$(tx1[t] and d1EmmAgrxE['Mineralization',plant_sectors,t,emm] and t.val > 2025)..
          uEmmAgrxE['Mineralization',plant_sectors,t,emm] =E= 0; #No mineralization after 2025

        E_qEmmAgrxE_OrganicSoilsInProduction_adj_post2034[emm,plant_sectors,t]$(tx1[t] and d1EmmAgrxE['OrganicSoilsInProduction',plant_sectors,t,emm] and t.val > 2034)..
          uEmmAgrxE['OrganicSoilsInProduction',plant_sectors,t,emm] =E= 0;

        E_qEmmAgrxE_InorganicFertilizer_adj_post2050[emm,plant_sectors,t]$(tx1[t] and d1EmmAgrxE['InorganicFertilizer',plant_sectors,t,emm] and t.val > tKF_plant_end.val  and not sameas[emm,'NH3'])..
          uEmmAgrxE['InorganicFertilizer',plant_sectors,t,emm] =E= uEmmAgrxE['InorganicFertilizer',plant_sectors,tKF_plant_end,emm];

        E_qEmmAgrxE_Manure_adj_post2050[emm,plant_sectors,t]$(tx1[t] and d1EmmAgrxE['Manure',plant_sectors,t,emm] and t.val > tKF_plant_end.val and not sameas[emm,"NH3"])..
          uEmmAgrxE['Manure',plant_sectors,t,emm] =E= uEmmAgrxE['Manure',plant_sectors,tKF_plant_end,emm];

        E_qEmmAgrxE_CropResidues_adj_post2050[emm,plant_sectors,t]$(tx1[t] and d1EmmAgrxE['CropResidues',plant_sectors,t,emm] and t.val > tKF_plant_end.val and not sameas[emm,'NH3'])..
          uEmmAgrxE['CropResidues',plant_sectors,t,emm] =E= uEmmAgrxE['CropResidues',plant_sectors,tKF_plant_end,emm];

        # It is nice being able to handle NH3 separately
        E_qemmAgrxE_Landemm_NH3_adj_post2050[emmtype,plant_sectors,emm,t]$(tx1[t] and d1EmmAgrxE[emmtype,plant_sectors,t,emm] and t.val > tKF_plant_end.val and sameas[emm,"NH3"]).. 
          uEmmAgrXe[emmtype,plant_sectors,t,emm] =E= uEmmAgrXe[emmtype,plant_sectors,tKF_plant_end, emm];  

    $ENDBLOCK 



  # ----------------------------------------------------------------------------------------
  # 4e) Markups in food processing sectors
  # ----------------------------------------------------------------------------------------

  $BLOCK B_markups2zero_foodprocessing_calib 

    E_markup_to_zero_foodprocessing_1[out,FoodProcessingSectors,t]$(tx1[t] and d1vY_CET[out,FoodProcessingSectors,t] and t.val <=%markupudfasetiaar_food%)..
      markup[out,FoodProcessingSectors,t] =E= markup[out,FoodProcessingSectors,t-1] + adj_markup_foodprocessingsectors[out,FoodProcessingSectors];

    E_markup_to_zero_foodprocessing_2[out,FoodProcessingSectors,t]$(tx1[t] and d1vY_CET[out,FoodProcessingSectors,t] and t.val >=%markupudfasetiaar_food%)..
      markup[out,FoodProcessingSectors,t] =E= iteite * markup.l[out,FoodProcessingSectors,t-1];

  $ENDBLOCK



# ======================================================================================================================
# 5) SETTING UP AND SOLVING PARTIAL MODEL 
# ======================================================================================================================

   $BLOCK B_alt 
      E_qPlant_nottop_alt[Plant_sectors,Plant_,Plantnest,t]$(tx0[t] and PlantNest2inputs_[PlantNest,Plant_] and d1Plant[plant_sectors,plant_,t] and not Leontief_PlantNest[plantNest] and not sameas[plant_,'land'] and not sameas[plantNest,'grossprod']).. 
        qPlant[Plant_sectors,Plant_,t] =E= uPlant[Plant_sectors,Plant_,t] * (abs(pPlant[Plant_sectors,Plant_,t] / pPlant[Plant_sectors,PlantNest,t]))**(-ePlant[Plant_sectors,PlantNest,t])*qPlant[Plant_sectors,PlantNest,t];

      E_qAni_nottop_alt[Ani_sectors,Ani_,Aninest,t]$(tx0[t] and AniNest2inputs_[AniNest,Ani_] and d1Ani[Ani_sectors,Ani_,t] and not sameas(Ani_,'AnimalsAgg') and not Leontief_aniNest[aniNest] and not Animals[ani_] and not sameas[AniNest,'grossprod'])..# and not sameas(AniNest,'AnimalsAgg') ).. 
       qAni[Ani_sectors,Ani_,t] =E= uAni[Ani_sectors,Ani_,t] * abs(pAni[Ani_sectors,Ani_,t] / pAni[Ani_sectors,AniNest,t])**(-eAni[Ani_sectors,AniNest,t])*qAni[Ani_sectors,AniNest,t];

  $ENDBLOCK


  $BLOCK B_demand_agr_partial 

    E_qAni_CET_demandresponse[ani_sectors,t]$(tx1[t] and t.val>tKF_ani_end.val and (sameas[ani_sectors,'01031'] or sameas[ani_sectors,'01032'] or sameas[ani_sectors,'01051'] or sameas[ani_sectors,'01052'] or  sameas[ani_sectors,'01061'] or sameas[ani_sectors,'01062'])).. # and not sameas[ani_sectors,'01052']).. # and not (sameas[ani_sectors,'01052'] or sameas[ani_sectors,'01032'] or sameas[ani_sectors,'01062']))..
      qAni_CET[ani_sectors,'out_other',t] =E= qAni_CET[ani_sectors,'out_other',tKF_ani_end] * (pAni_CET[ani_sectors,'out_other',tKF_ani_end]/pAni_CET[ani_sectors,'out_other',t]);

    E_qKF_plant_demandresponse[plant_sectors,t]$(tx1[t] and t.val>tKF_plant_end.val)..
        qPlant_CET[plant_sectors,'Grain',t]  =E= qPlant_CET[plant_sectors,'Grain',tKF_plant_end] * (pPlant_CET[plant_sectors,'Grain',tKF_plant_end]/pPlant_CET[plant_sectors,'grain',t]);
  $ENDBLOCK

  $GROUP G_demand_partial_endo 
    qAni_CET$(t.val>tKF_ani_end.val and (sameas[ani_sectors,'01031'] or sameas[ani_sectors,'01032'] or sameas[ani_sectors,'01051'] or sameas[ani_sectors,'01052'] or  sameas[ani_sectors,'01061'] or sameas[ani_sectors,'01062']))
    qPlant_CET$(t.val>tKF_plant_end.val and sameas[plant_out,'Grain'])
  ;


  $BLOCK B_KF_partial

    $IF %calibquanti_plant%:
      E_qKF_plant_after2050[plant_sectors,t]$(tx1[t] and t.val > tKF_plant_end.val)..
       qPlant_CET[plant_sectors,'Grain',t] =E= qPlant_CET[plant_sectors,'Grain',tKF_plant_end];
    $ENDIF

    E_qKF_ani_after2050[ani_sectors,t]$(tx1[t] and t.val > tKF_ani_end.val and not sameas[ani_sectors,'01070'])..
      qAni_CET[ani_sectors,'out_other',t] =E= qAni_CET[ani_sectors,'out_other',tKF_ani_end];



  $ENDBLOCK
 
    pPlant.l[plant_sectors,plant_,t]$(t.val <2018) = 0;
    pAni.l[ani_sectors,ani_,t]$(t.val <2018) = 0;

  $MODEL M_partial_plus 
    M_agr_calib_partial
    M_plant_calib_partial
    -E_jpK_plant,-E_jpK_land,
    E_jpK_plant_alt, E_jpK_land_alt 
    M_ani_calib_partial
    -E_jpK_ani, E_jpK_ani_alt
      # E_uAni_01031
      # E_uAni_01032
      E_uAni_01052
      E_uAni_01061
      # E_uAni_01062

    # -E_qPlant_nottop,E_qPlant_nottop_alt
    # -E_qAni_nottop, E_qAni_nottop_alt
    # -E_qAni_top, E_qAni_top_alt
    # -E_qPlant_top, E_qPlant_top_alt
    # -E_pPlant_CET0, E_pPlant_CET0_alt
    # -E_qPlant_AGG, E_qPlant_AGG_alt
    # -E_pAni_CET0, E_pAni_CET0_alt

    #  #ALL AGRI_SECTORS

      #  E_uPlant_01012
      #  E_uAni_01070

    #PLANT SECTORS
      $IF %uKland%:
        -E_jpK_land_alt
        E_uK_land
        # E_jpK_land_alt_alt
      $ENDIF 

      #Fix land
      $IF %lockland%:
        E_qPlant_Land_calib
        #Phase pLand
        $IF1 %plandphase%:
          E_pLand_adj
          $IF2 %landphase2%:
          E_pland_adj_2
          $ENDIF2
        $ENDIF1
      $ENDIF 


      #  Priser 
      $IF %calibpriser_plant%:
        E_pKF_plant

        E_TFPPlant_con_after2050_notKF
        E_TFPPlant_con_notKF
        E_TFPPlant_con_notgrain
        E_TFP_plant_con

        E_TFPPlant_org_after2050_notKF
        E_TFPPlant_org_notKF
        E_TFPPlant_org_notgrain
        E_TFP_plant_org

        E_TFPPlant_hor_after2050_notKF
        E_TFPPlant_hor_notKF
        E_TFPPlant_hor_notgrain
        E_TFP_plant_hor

      $ENDIF

      #Production of grain 
      $IF %calibquanti_plant%:
        E_qKF_plant
        E_qKF_plant_after2050
        $IF1 %demand_response_in_partial_plant%:
          -E_qKF_plant_after2050
          E_qKF_plant_demandresponse
        $ENDIF1
      $ENDIF



    $IF %calibrateNPK%:
      E_uPlant_NPK
    $ENDIF

    $IF %calibratePlantManure%:
      E_qPlantManure
      E_uPlantManure_afterKF
    $ENDIF


    $IF (%calibrateNPK%) & (%calibratePlantManure%):
      E_qPlant_Fertilizer
      E_uPlant_FertilizerAfterKF
    $ENDIF 

    $IF %calibrateChemicalsPlusFinServL%:
      E_qPlant_Chemicals
      E_uPlant_Chemicals_afterKF
      E_qPlant_FinServL
      E_uPlant_FinServL_afterKF
    $ENDIF

    $IF (%lockland%) & (%calibrateChemicalsPlusFinServL%):
      E_qPlant_LandChem
      E_uPlant_LandChem_afterKF
    $ENDIF 

    $IF (%lockland%) & (%calibrateChemicalsPlusFinServL%) & (%calibratePlantManure%) & (%calibrateNPK%):
      E_qPlant_LF
      E_uPlant_LF_afterKF
    $ENDIF

    #ANIMAL-SECTORS

    #Animals
    $IF %calibrateNumberAnimals_poul%:
      #Poultry
      E_qAni_animals_poul
      E_adj_animals_poul
      E_uAnimals_poul_afterKF
    $ENDIF 

    $IF %calibrateNumberAnimals_cowsnpigs%:
      #Pigs and cows
      E_uAnimals_not_poul_afterKF

      #Emissions
      E_uEmmAgrAnimals_NH3_pigs
      E_adj_uEmmAgrAnimals_NH3_pigs
      E_uEMmAgrAni_Nh3_PIGS_after_tKF_animals_end
    $ENDIF


    #Manure
    $IF %calibrateNManure%:
     $IF1 %calibrateNManure_perdata%!=1:
      E_qNManure_tKF_notCows
     $ENDIF1
     E_qNManure_KF
    $ENDIF


    #Production
    E_qAni_CET_KF25
    E_qKF_ani_after2050

      $IF %demand_response_in_partial_ani%:
          -E_qKF_ani_after2050
          E_qAni_CET_demandresponse
      $ENDIF


    $IF %calibpriser_ani%:
      E_pAni_CET_KF25

      #COWS
        #Conventional
        E_TFPAni_cows_con_after2050_notKF
        E_TFPani_cows_con_notKF
        E_TFP_ani_cows_con

        #Organic
        E_TFPAni_cows_org_after2050_notKF
        E_TFPani_cows_org_notKF
        E_TFP_ani_cows_org

      #PIGS 
        #Conventional
        E_TFPAni_pigs_con_after2050_notKF
        E_TFPani_pigs_con_notKF
        E_TFP_ani_pigs_con

        #Organic
        E_TFPAni_pigs_org_after2050_notKF
        E_TFPani_pigs_org_notKF
        E_TFP_ani_pigs_org

      #POULTRY
        #Conventional
        E_TFPAni_poul_con_after2050_notKF
        E_TFPani_poul_con_notKF
        E_TFP_ani_poul_con

        #Organic
        E_TFPAni_poul_org_after2050_notKF
        E_TFPani_poul_org_notKF
        E_TFP_ani_poul_org
    $ENDIF

    #MINK 

    $IF %calibrateMinkMarkup%:
      E_markup_mink
      E_markup_mink_after_markupudfasetiaar_mink
    $ENDIF 

  ;

  #-------------------------------------------------------------------------------------
  # EXO-gruppe til partiel model
  #-------------------------------------------------------------------------------------

  $GROUP G_partial_plus_exo 
    G_agr_calib_partial_exo
    G_plant_calib_partial_exo, adj_Manure 
    G_ani_calib_partial_exo 

    #PLANT SECTORS
      $IF %uKland%:
        jpK_land
      $ENDIF

      #Låser jord til Dejgård værdier
      $IF %lockland%:
        qPlant$(tx1[t] and d1plant[plant_sectors,plant_,t] and sameas[plant_,'land'] and t.val <tKF_plant_end.val)
        -thetaJ$(tx1[t] and t.val > t2.val) #
        $IF1 %plandphase%!=1:
          pLand$(tx1[t] and t.val <tKF_plant_end.val)
        $ENDIF1
      $ENDIF

      #PRISER OG MARKUP
      $IF %calibpriser_plant%:
      -plant_markup$(tx1[t] and d1Plant_CET0[plant_sectors,plant_out,t] and plant_out_top[plant_out] and sameas[plant_sectors,'01011'])
      -TFPPlant$(tx1[t] and sameas[plant_sectors,'01011'])

      -plant_markup$(tx1[t] and d1Plant_CET0[plant_sectors,plant_out,t] and plant_out_top[plant_out] and sameas[plant_sectors,'01012'])
      -TFPPlant$(tx1[t] and sameas[plant_sectors,'01012'])

      -plant_markup$(tx1[t] and d1Plant_CET0[plant_sectors,plant_out,t] and plant_out_top[plant_out] and sameas[plant_sectors,'01020'])
      -TFPPlant$(tx1[t] and sameas[plant_sectors,'01020'])
      $ENDIF
      

      #NPK 
      $IF %calibrateNPK%:
        qPlant$(tx1[t] and tKF_plant[t] and d1Plant[plant_sectors,plant_,t] and sameas[plant_,'NPK'])
      $ENDIF

      $IF %calibratePlantManure%:
       pD_manure$(tx1[t] and tKF_plant[t])
      $ENDIF

    # $IF %pLand2024calib%==1:
    #   pLand$(t.val<=2024)
    # $ENDIF 

    # #ANIMAL SECTORS

    $IF %calibpriser_ani%:
        #COWS
          -ani_markup$(tx1[t] and sameas[ani_sectors,'01031'])
          -TFPAni$(tx1[t] and sameas[ani_sectors,'01031'])

          -ani_markup$(tx1[t] and sameas[ani_sectors,'01032'])
          -TFPAni$(tx1[t] and sameas[ani_sectors,'01032'])

        #PIGS
          -ani_markup$(tx1[t] and sameas[ani_sectors,'01051'])
          -TFPAni$(tx1[t] and sameas[ani_sectors,'01051'])

          -ani_markup$(tx1[t] and sameas[ani_sectors,'01052'])
          -TFPAni$(tx1[t] and sameas[ani_sectors,'01052'])

        #POULTRY
          -ani_markup$(tx1[t] and sameas[ani_sectors,'01061'])
          -TFPAni$(tx1[t] and sameas[ani_sectors,'01061'])

          -ani_markup$(tx1[t] and sameas[ani_sectors,'01062'])
          -TFPAni$(tx1[t] and sameas[ani_sectors,'01062'])
      $ENDIF

      #Animals 
      $IF %calibrateNumberAnimals_poul%:
        #Poultry
        -uAni$(tx1[t] and Animals[Ani_] and d1Ani[ani_sectors,ani_,t] and (sameas[ani_sectors,'01061'] or sameas[ani_sectors,'01062']))
      $ENDIF 

        #Pigs and cows
        -uAni$(tx1[t] and Animals[Ani_] and d1Ani[ani_sectors,ani_,t] and (sameas[ani_sectors,'01031'] or sameas[ani_sectors,'01032'] or sameas[ani_sectors,'01051'] or sameas[ani_sectors,'01052']))
        qAni$(tx1[t] and tKF_animals[t] and Animals[Ani_] and d1Ani[ani_sectors,ani_,t] and (sameas[ani_sectors,'01031'] or sameas[ani_sectors,'01032'] or sameas[ani_sectors,'01051'] or sameas[ani_sectors,'01052']))

        #Emissions
        # -uEmmAgrAni$(tx1[t] and animals[ani_] and (sameas[ani_sectors,'01051'] or sameas[ani_sectors,'01052']) and sameas[emmtype,'GrazingAnimals'] and sameas[emm_eq,'NH3'])



  

      $IF %calibrateNManure%:
        -uManurePerAnimal$(tx1[t] and sum(emm,d1EmmAgrAni['ManureManagement',ani_sectors,Animals,t,emm])), qNMANURE$(tx1[t] and tKF_animals[t] and sum(emm,d1EmmAgrAni['ManureManagement',ani_sectors,Animals,t,emm]))
        $IF1 %calibrateNManure_perdata%!=1:
        qNManure$(tx1[t] and tKF_animals[t] and sum(emm,d1EmmAgrAni['ManureManagement',ani_sectors,Animals,t,emm]) and not (sameas[ani_sectors,'01051'] or sameas[ani_sectors,'01052'] or sameas[ani_sectors,'01061'] or sameas[ani_sectors,'01062']))
        $ENDIF1
      $ENDIF


    #  E_uAni_01052
     jpK_ani$(sameas[ani_sectors,'01052'])
     -uAni$(tx1[t] and ani_pK[ani_] and sameas[ani_sectors,'01052'] and not sameas[ani_,'TransportCapital'])
    #  #  E_uAni_01070
    #  jpK_ani$(sameas[ani_sectors,'01070'])
    #  -uAni$(tx1[t] and ani_pK[ani_] and sameas[ani_sectors,'01070'] and not sameas[ani_,'TransportCapital'])
     #  E_uAni_01032
    #  jpK_ani$(sameas[ani_sectors,'01032'])
    #  -uAni$(tx1[t] and ani_pK[ani_] and sameas[ani_sectors,'01032'] and not sameas[ani_,'TransportCapital'])
     #  E_uAni_01031
    #  jpK_ani$(sameas[ani_sectors,'01031'])
    #  -uAni$(tx1[t] and ani_pK[ani_] and sameas[ani_sectors,'01031'] and not sameas[ani_,'TransportCapital'])

    # E_uAni_01061
     jpK_ani$(sameas[ani_sectors,'01061'])
     -uAni$(tx1[t] and ani_pK[ani_] and sameas[ani_sectors,'01061'] and not sameas[ani_,'TransportCapital'])

    # E_uAni_01062
    #  jpK_ani$(sameas[ani_sectors,'01062'])
    #  -uAni$(tx1[t] and ani_pK[ani_] and sameas[ani_sectors,'01062'] and not sameas[ani_,'TransportCapital'])
    #Alternatively (jqI_s)
    # -qAni_capital$(t2[t] and sameas[ani_sectors,'01062'] and not sameas[ani_pK,'transportcapital']), jpK_ani$(sameas[ani_sectors,'01062'])
    -qAni_capital$(t2[t] and sameas[ani_sectors,'01062'] and not sameas[ani_pK,'transportcapital']), jpK_ani$(sameas[ani_sectors,'01062'] and not sameas[ani_pK,'transportcapital'])
    #£
    -qAni_capital$(t2[t] and sameas[ani_sectors,'01032'] and not sameas[ani_pK,'transportcapital']), jpK_ani$(sameas[ani_sectors,'01032'] and not sameas[ani_pK,'transportcapital'])
    

  ;


  #-------------------------------------------------------------------------------------
  # ENDO-gruppe til partiel model
  #-------------------------------------------------------------------------------------

  $GROUP G_partial_plus_endo
    G_agr_calib_partial, adj_manure
    G_plant_calib_partial
    G_ani_calib_partial   

    
    #PLANT SECTORS
      $IF %uKland%:
        -jpK_land
        uPlant$(tx1[t] and d1plant[plant_sectors,plant_,t] and sameas[plant_,'land'])
      $ENDIF


      #Låser jord til Dejgård værdier
      $IF %lockland%:
        -qPlant$(tx1[t] and d1plant[plant_sectors,plant_,t] and sameas[plant_,'land'] and t.val <tKF_plant_end.val)
        thetaJ$(tx1[t] and t.val > t2.val) #
        
        $IF1 %plandphase%!=1:
          -pLand$(tx1[t] and t.val <tKF_plant_end.val)
        $ENDIF1
      $ENDIF

      $IF %calibquanti_plant%:
        #Market-production 
        qPlant_CET$(tx1[t] and d1Plant_CET0[plant_sectors,plant_out,t] and sameas[plant_out,'Grain'])
      $ENDIF

      #PRISER OG MARKUP 
      $IF %calibpriser_plant%:
        plant_markup$(tx1[t] and d1Plant_CET0[plant_sectors,plant_out,t] and plant_out_top[plant_out] and sameas[plant_sectors,'01011'])
        TFPPlant$(tx1[t] and sameas[plant_sectors,'01011'])

        plant_markup$(tx1[t] and d1Plant_CET0[plant_sectors,plant_out,t] and plant_out_top[plant_out] and sameas[plant_sectors,'01012'])
        TFPPlant$(tx1[t] and sameas[plant_sectors,'01012'])

        plant_markup$(tx1[t] and d1Plant_CET0[plant_sectors,plant_out,t] and plant_out_top[plant_out] and sameas[plant_sectors,'01020'])
        TFPPlant$(tx1[t] and sameas[plant_sectors,'01020'])
      $ENDIF


      #NPK 
      $IF %calibrateNPK%:
        uPlant$(tx1[t] and d1Plant[plant_sectors,plant_,t] and sameas[plant_,'NPK'])
        -qPlant$(tx1[t] and tKF_plant[t] and d1Plant[plant_sectors,plant_,t] and sameas[plant_,'NPK'])
      $ENDIF


      #Manure consumption
      $IF %calibratePlantManure%:
        uPlant$(tx1[t] and d1Plant[plant_sectors,plant_,t] and sameas[plant_,'manure'])
      $ENDIF 

       $IF %calibratePlantManure%:
        -pD_manure$(tx1[t] and tKF_plant[t])
       $ENDIF

      $IF (%calibrateNPK%) & (%calibratePlantManure%):
        uPlant$(tx1[t] and d1Plant[plant_sectors,plant_,t] and sameas[plant_,'Fertilizer'])
      $ENDIF

       $IF %pLand2024calib%==1:
        -pLand$(t.val<=2024)
       $ENDIF


      $IF %calibrateChemicalsPlusFinServL%:
        uPlant$(tx1[t] and d1Plant[plant_sectors,plant_,t] and sameas[plant_,'Chemicals'])
        uPlant$(tx1[t] and d1PLant[plant_sectors,plant_,t] and sameas[plant_,'FinancialServiceL'])
      $ENDIF 

      $IF (%lockland%) & (%calibrateChemicalsPlusFinServL%):
        uPlant$(tx1[t] and d1Plant[plant_sectors,plant_,t] and sameas[plant_,'LandChem'])
      $ENDIF

      $IF (%lockland%) & (%calibrateChemicalsPlusFinServL%) & (%calibratePlantManure%) & (%calibrateNPK%):
        uPlant$(tx1[t] and d1Plant[plant_sectors,plant_,t] and sameas[plant_,'LF'])
      $ENDIF

    #ANIMAL SECTORS
      #Production
      qAni_CET$(tx1[t] and not sameas[ani_sectors,'01070'])

      $IF %calibpriser_ani%:
        ani_markup$(tx1[t] and sameas[ani_sectors,'01031'])
        TFPAni$(tx1[t] and sameas[ani_sectors,'01031'])

        ani_markup$(tx1[t] and sameas[ani_sectors,'01032'])
        TFPAni$(tx1[t] and sameas[ani_sectors,'01032'])

        ani_markup$(tx1[t] and sameas[ani_sectors,'01051'])
        TFPAni$(tx1[t] and sameas[ani_sectors,'01051'])

        ani_markup$(tx1[t] and sameas[ani_sectors,'01052'])
        TFPAni$(tx1[t] and sameas[ani_sectors,'01052'])

        ani_markup$(tx1[t] and sameas[ani_sectors,'01061'])
        TFPAni$(tx1[t] and sameas[ani_sectors,'01061'])

        ani_markup$(tx1[t] and sameas[ani_sectors,'01062'])
        TFPAni$(tx1[t] and sameas[ani_sectors,'01062'])
      $ENDIF


      #Animals 
      $IF %calibrateNumberAnimals_poul%:
        #Poultry 
        uAni$(tx1[t] and Animals[Ani_] and d1Ani[ani_sectors,ani_,t] and (sameas[ani_sectors,'01061'] or sameas[ani_sectors,'01062']))
      $ENDIF

        #Pigs and cows
        uAni$(tx1[t] and Animals[Ani_] and d1Ani[ani_sectors,ani_,t] and (sameas[ani_sectors,'01031'] or sameas[ani_sectors,'01032'] or sameas[ani_sectors,'01051'] or sameas[ani_sectors,'01052']))
        -qAni$(tx1[t] and tKF_animals[t] and Animals[Ani_] and d1Ani[ani_sectors,ani_,t] and (sameas[ani_sectors,'01031'] or sameas[ani_sectors,'01032'] or sameas[ani_sectors,'01051'] or sameas[ani_sectors,'01052']))
        
        #Emissions
        # uEmmAgrAni$(tx1[t] and animals[ani_] and (sameas[ani_sectors,'01051'] or sameas[ani_sectors,'01052']) and sameas[emmtype,'GrazingAnimals'] and sameas[emm_eq,'NH3'])


      $IF %calibrateNManure%:
        uManurePerAnimal$(tx1[t] and sum(emm,d1EmmAgrAni['ManureManagement',ani_sectors,Animals,t,emm])), -qNMANURE$(tx1[t] and tKF_animals[t] and sum(emm,d1EmmAgrAni['ManureManagement',ani_sectors,Animals,t,emm]))
        $IF1 %calibrateNManure_perdata%!=1:
        -qNManure$(tx1[t] and tKF_animals[t] and sum(emm,d1EmmAgrAni['ManureManagement',ani_sectors,Animals,t,emm]) and not (sameas[ani_sectors,'01051'] or sameas[ani_sectors,'01052'] or sameas[ani_sectors,'01061'] or sameas[ani_sectors,'01062']))
        $ENDIF1
     $ENDIF


     #MINK 
     $IF %calibrateMinkMarkup%:
        G_machinestation_mink_endo
     $ENDIF



    #  E_uAni_01052
     -jpK_ani$(sameas[ani_sectors,'01052'])
     uAni$(tx1[t] and ani_pK[ani_] and sameas[ani_sectors,'01052'] and not sameas[ani_,'TransportCapital'])
    #  #  E_uAni_01070
    #  -jpK_ani$(sameas[ani_sectors,'01070'])
    #  uAni$(tx1[t] and ani_pK[ani_] and sameas[ani_sectors,'01070'] and not sameas[ani_,'TransportCapital'])
     #  E_uAni_01032
    #  -jpK_ani$(sameas[ani_sectors,'01032'])
    #  uAni$(tx1[t] and ani_pK[ani_] and sameas[ani_sectors,'01032'] and not sameas[ani_,'TransportCapital'])
     #  E_uAni_01031
    #  -jpK_ani$(sameas[ani_sectors,'01031'])
    #  uAni$(tx1[t] and ani_pK[ani_] and sameas[ani_sectors,'01031'] and not sameas[ani_,'TransportCapital'])
  
    # E_uAni_01061
     -jpK_ani$(sameas[ani_sectors,'01061'])
     uAni$(tx1[t] and ani_pK[ani_] and sameas[ani_sectors,'01061'] and not sameas[ani_,'TransportCapital'])

    # E_uAni_01062
    #  -jpK_ani$(sameas[ani_sectors,'01062'])
    #  uAni$(tx1[t] and ani_pK[ani_] and sameas[ani_sectors,'01062'] and not sameas[ani_,'TransportCapital'])
    #Alternatively (jqI_s)
    # qAni_capital$(t2[t] and sameas[ani_sectors,'01062'] and not sameas[ani_pK,'transportcapital']), -jpK_ani$(sameas[ani_sectors,'01062'])
    qAni_capital$(t2[t] and sameas[ani_sectors,'01062'] and not sameas[ani_pK,'transportcapital']), -jpK_ani$(sameas[ani_sectors,'01062'] and not sameas[ani_pK,'TransportCapital'])

    #£
    qAni_capital$(t2[t] and sameas[ani_sectors,'01032'] and not sameas[ani_pK,'transportcapital']), -jpK_ani$(sameas[ani_sectors,'01032'] and not sameas[ani_pK,'TransportCapital'])


  ;


  $GROUP G_landprices_exo
    tCorp, rFirmsLand, pPlant, dInstcostlandT, dInstcostlandTp1, sDebt2j, tHectareSubsidy, rBonds, tLand, pLandvalueFromUnobserved, jpK_land 
  ;

  $GROUP G_landprices_endo 
    pLand$(tx0[t])
  ;

  $BLOCK B_landprices 
    $LOOP00 E_pPlant_land:
      {name}_landprices{sets}$({subsets} and sameas[plant_sectors,'01011']).. {LHS} =E= {RHS};
    $ENDLOOP00
  $ENDBLOCK 

  $MODEL M_landprices 
    B_landprices
    E_pLand_End
  ;

  $GROUP G_landprices_exo 
    G_landprices_exo 
    # pLand, -pPlant$(sameas[plant_,'land'])
  ;

  $GROUP G_landprices_endo 
    G_landprices_endo
    # -pLand, pPlant$(sameas[plant_,'land'])
  ;

  # pPlant.l[plant_sectors,'land',tx1] = 1;
  # sDebt2j.l[plant_sectors,tx1] = 0.2;
  


#   $FIX G_landprices_exo;
#   $UNFIX G_landprices_endo;
#   execute_unload 'output\pre.gdx';
#   @SOLVE(M_landprices);
#   @report_uc();
#   execute_unload 'output\post.gdx';
# $exit

# OneToZeroAgrIterator[ani_sectors] = 0;

# $FOR {ThatG} in ['0.1','0.5','1']:

#   OneToZeroAgrIterator['01031'] = {ThatG};
#   OneToZeroAgrIterator['01032'] = {ThatG};
#   OneToZeroAgrIterator['01051'] = {ThatG};
#   OneToZeroAgrIterator['01052'] = {ThatG};
#   OneToZeroAgrIterator['01061'] = {ThatG};
#   OneToZeroAgrIterator['01062'] = {ThatG};

#   @compute_ani_prices();
#   @compute_ani_quantities();


#   $FIX G_partial_plus_exo;
#   $UNFIX G_partial_plus_endo;
#   # $FIX pD_manure;
#    execute_unload 'output\pre.gdx';
#    @Solve(M_partial_plus,1);
#    @report_uc();
#    execute_unload 'output\post_{ThatG}.gdx';
# $ENDFOR
# @assert_no_difference(G_data,%tolerance_data%);
#    @report_uc();
#    execute_unload 'output\post.gdx';
  #  $exit
  #  @SOLVE(M_partial_plus);
  

  # $BLOCK B_block 
  #     E_qIm_alt[sp,t]$(tx0[t]).. qIm[sp,t] =E= (uIm[sp,t] * (pIm[sp,t]/pMKE[sp,t])**(-eMKE[sp]) * qMKE[sp,t])$(not sameas[sp,'01062'])
  #                                         +(uIm[sp,t] * abs(pIm[sp,t]/pMKE[sp,t])**(-eMKE[sp]) * qMKE[sp,t])$(sameas[sp,'01062']);
  # $ENDBLOCK

# ======================================================================================================================
# 6) SETTING UP AND SOLVING FULLY INTEGRATED MODEL 
# ======================================================================================================================
  

  # jqAni_CET.l[ani_sectors,'out_other',t] = qAni_CET.l[ani_sectors,'out_other',t] - qY_CET.l['out_other',ani_sectors,t];
  # qpAni_CET.l[ani_sectors,'out_other',t] = pAni_CET.l[ani_sectors,'out_other',t] - pY_CET.l['out_other',ani_sectors,t];

  # jqPlant_CET.l[plant_sectors,'grain',t] = qPlant_CET.l[plant_sectors,'grain',t] - qY_CETgross.l['out_other',plant_sectors,t];
  # jqPlant_CET.l[plant_sectors,'straw',t] = qPlant_CET.l[plant_sectors,'grain',t]*0.05 - qY_CETgross.l['straw for energy purposes',plant_sectors,t];
 

  $MODEL M_dynamic_calibration_agr
    M_agr_calib 
    -E_pY_CET0, E_pY_CET0_notagri
    -E_qY, E_qY_notagri
    # -E_qIt, E_qIt_alt
    # -E_pMKE, E_pMKE_alt
    # -E_pTKE, E_pTKE_alt
    # -E_pKE, E_pKE_alt
    # -E_qPlant_nottop, E_qPlant_nottop_alt
    #  -E_qAni_nottop, E_qAni_nottop_alt

    #2)
    E_pK_plant_link
    E_pK_ani_link


    #  -E_qPlant_nottop, E_qPlant_nottop_alt

    #CGE-EQUATIONS
      #3)
      B_markups2zero_foodprocessing_calib

    #ALL AGRI SECTORS
      #2)
      B_jstozero_calib,-E_jpK_ani, -E_jpK_plant,-E_jpK_land
      $IF %uKland%:
          -E_jpK_land_alt
          E_uK_land
          # E_jpK_land_alt_alt
      $ENDIF 
    

    #6)
    #PLANTS
     B_KF25_plant_calib

    # #CGE-EQUATIONS
      B_markups2zero_foodprocessing_calib




    #ANIMALS
      #1)
     B_KF25_ani_calib


      #1)
     #Antal dyr 
     $IF %calibrateNumberAnimals_poul%:
      B_uAni_animals_poul_calib
     $ENDIF

      #1)
     $IF %calibrateNumberAnimals_cowsnpigs%:
      B_uAni_animals_cowsnpigs_calib
     $ENDIF

    #1)
     $IF %calibrateNManure%:
      B_qNMANURE_calib
     $ENDIF

    #EMISSIONS
    #5)
      B_emissions_agr_calib

    #4)
    $IF %calibrateMinkMarkup%:
      E_markup_mink
      E_markup_mink_after_markupudfasetiaar_mink
    $ENDIF 

    $IF %calibratemachinestationMarkup%:
      E_markup_machinestation
      E_markup_machinestation_after
      E_TFP_machinestation_target
      E_markup_machinestation_markuppath
      E_markup_machinestation_aftertarget
    $ENDIF 
  ;


  $GROUP G_dynamic_calibration_endo
    G_dynamic_calibration_endo
    G_production_agr_calib 
    G_production_plant_calib
    G_production_ani_calib

    #ALL AGRI SECTORS
    -qY$(agri_sectors_s_[s_])
    -pY0_CET$(agri_sectors_[s])

  #    #6)
  #   #PLANTS 
      G_plant_prod_calib_endo #B_production_LF22_calib
      -G_plant_prod_calib_exo
      G_agr_calib_endo #Adj_manure - skal med B_KF25_plant_calib

      #2)
      $IF %uKland%:
        #Erstatter jpk_land
        uPlant$(tx1[t] and d1plant[plant_sectors,plant_,t] and sameas[plant_,'land'])
        -jpK_land
      $ENDIF

      #6)
      $IF %lockland%:
        #Låser jord 
        -qPlant$(tx1[t] and d1plant[plant_sectors,plant_,t] and sameas[plant_,'land'] and t.val <tKF_plant_end.val)
        thetaJ$(tx1[t] and t.val > t2.val) #
      $ENDIF 

      #6)
       $IF %calibratePlantManure%:
        -pD_manure$(tx1[t] and tKF_plant[t])
       $ENDIF

      #2)
      #E_pK_plant_link
      jpK$(t.val>t2.val and d1k[k,sp,t] and plant_sectors_sp[sp])
      #E_pK_ani_link
      jpK$(t.val>t2.val and d1k[k,sp,t] and ani_sectors_sp[sp])

  #     $IF %pLand2024calib%==1:
  #       -pLand$(t.val<=2024)
  #     $ENDIF 


    #ANIMALS
      #1)
      G_ani_prod_calib_endo   #B_production_LF22_calib

      #1)
      #Animals 
      $IF %calibrateNumberAnimals_poul%:
         uAni$(tx1[t] and Animals[Ani_] and d1Ani[ani_sectors,ani_,t] and (sameas[ani_sectors,'01061'] or sameas[ani_sectors,'01062']))
      $ENDIF 

      #1)
      uAni$(tx1[t] and Animals[Ani_] and d1Ani[ani_sectors,ani_,t] and (sameas[ani_sectors,'01031'] or sameas[ani_sectors,'01032'] or sameas[ani_sectors,'01051'] or sameas[ani_sectors,'01052']))
      -qAni$(tx1[t] and tKF_animals[t] and Animals[Ani_] and d1Ani[ani_sectors,ani_,t] and (sameas[ani_sectors,'01031'] or sameas[ani_sectors,'01032'] or sameas[ani_sectors,'01051'] or sameas[ani_sectors,'01052']))   
      # uEmmAgrAni$(tx1[t] and animals[ani_] and (sameas[ani_sectors,'01051'] or sameas[ani_sectors,'01052']) and sameas[emmtype,'GrazingAnimals'] and sameas[emm_eq,'NH3'])

      #1)
      #The manure from the animals
      $IF %calibrateNManure%:
        uManurePerAnimal$(tx1[t] and sum(emm,d1EmmAgrAni['ManureManagement',ani_sectors,Animals,t,emm])), -qNMANURE$(tx1[t] and tKF_animals[t] and sum(emm,d1EmmAgrAni['ManureManagement',ani_sectors,Animals,t,emm]))
        $IF1 %calibrateNManure_perdata%!=1:
        qNManure$(tx1[t] and tKF_animals[t] and sum(emm,d1EmmAgrAni['ManureManagement',ani_sectors,Animals,t,emm]) and not (sameas[ani_sectors,'01051'] or sameas[ani_sectors,'01052'] or sameas[ani_sectors,'01061'] or sameas[ani_sectors,'01062']))
        $ENDIF1
     $ENDIF

    #3) 
    #MARK-UPS IN FOOD PROCESSING SECTORS 
      markup$(tx1[t] and d1vY_CET[out,s,t] and FoodProcessingSectors_s[s]) #B_markups2zero_foodprocessing_calib

    #5)
      #EMISSIONS 
        uEmmAgrXe$(tx1[t] and d1EmmAgrxE[emmtype,agri_sectors,t,emm_eq] and sum(emmtype_dis,emmtype_dis2emmtype(emmtype_dis,emmtype)) and emm[emm_eq])
        uEmmAgrxE$(tx1[t] and d1EmmAgrxE[emmtype,agri_sectors,t,emm_eq] and sum(emmtype_dis,emmtype_dis2emmtype(emmtype_dis,emmtype)) and emm[emm_eq] and not sameas[emmtype,'GrazingAnimals'])
        uEmmAgrAni$(tx1[t] and d1EmmAgrAni[emmtype,ani_sectors,Ani_,t,emm_eq] and emm[emm_eq] and sameas[emmtype,'GrazingAnimals'] and not sameas[emm_eq,'NH3'])

    #4) 
     #MARK-UPS WITH MINK AND MACHINESTATIOn 
      $IF (%calibrateMinkMarkup%) & (%calibratemachinestationMarkup%):
        G_machinestation_mink_endo
      $ENDIF 

      $IF %calibrateMinkMarkup%:
        ani_markup$(tx1[t] and sameas[ani_sectors,'01070'])
      $ENDIF 

      $IF %calibratemachinestationMarkup%:
        markup$(tx1[t] and sameas[s,'01080'] and sameas[out,'out_other'])
        TFP$(tx1[t] and sameas[prdNest,'KELBM'] and sameas[sp,'01080'])
      $ENDIF

      #2)
    #  E_uAni_01052
     -jpK_ani$(sameas[ani_sectors,'01052'])
     uAni$(tx1[t] and ani_pK[ani_] and sameas[ani_sectors,'01052'] and not sameas[ani_,'TransportCapital'])

    #  #  E_uAni_01070
    #  -jpK_ani$(sameas[ani_sectors,'01070'])
    #  uAni$(tx1[t] and ani_pK[ani_] and sameas[ani_sectors,'01070'] and not sameas[ani_,'TransportCapital'])

     #  E_uAni_01032
    #  -jpK_ani$(sameas[ani_sectors,'01032'])
    #  uAni$(tx1[t] and ani_pK[ani_] and sameas[ani_sectors,'01032'] and not sameas[ani_,'TransportCapital'])

     #  E_uAni_01031
    #  -jpK_ani$(sameas[ani_sectors,'01031'])
    #  uAni$(tx1[t] and ani_pK[ani_] and sameas[ani_sectors,'01031'] and not sameas[ani_,'TransportCapital'])
  
    # E_uAni_01061
     -jpK_ani$(sameas[ani_sectors,'01061'])
     uAni$(tx1[t] and ani_pK[ani_] and sameas[ani_sectors,'01061'] and not sameas[ani_,'TransportCapital'])

    # E_uAni_01062
    #  -jpK_ani$(sameas[ani_sectors,'01062'])
    #  uAni$(tx1[t] and ani_pK[ani_] and sameas[ani_sectors,'01062'] and not sameas[ani_,'TransportCapital'])
    #Alternatively (jqI_s)
    # qAni_capital$(t2[t] and sameas[ani_sectors,'01062'] and not sameas[ani_pK,'transportcapital']), -jpK_ani$(sameas[ani_sectors,'01062'])
    qAni_capital$(t2[t] and sameas[ani_sectors,'01062']), -jpK_ani$(sameas[ani_sectors,'01062'] and not sameas[ani_pk,'transportcapital'])
    #  uK$(sameas[sp,'01062'] and t2[t] and not sameas[k,'it'])
    uProd$(prdbotult(prd) and sameas[sp,'01062'] and t2[t] and not sameas[prd,'it'])

    qAni_capital$(t2[t] and sameas[ani_sectors,'01032']), -jpK_ani$(sameas[ani_sectors,'01032'] and not sameas[ani_pk,'transportcapital'])
    #  uK$(sameas[sp,'01032'] and t2[t] and not sameas[k,'it'])
    uProd$(prdbotult(prd) and sameas[sp,'01032'] and t2[t] and not sameas[prd,'it'])

  ;

  $GROUP G_dynamic_calibration_exo
    G_dynamic_calibration_exo
    G_production_agr_calib_exo
    G_production_plant_calib_exo
    G_production_ani_calib_exo

    #ALL AGRI SECTORS
    qY$(agri_sectors_s_[s_])
    pY0_CET$(agri_sectors_[s])

    $IF %uKland%:
      jpK_land
    $ENDIF

      #PLANTS
        #6)
        G_plant_prod_calib_exo


        #2)
        $IF %uKland%:
         jpK_land
        $ENDIF
        
        #6)
        $IF %lockland%:
          #Låser jord 
          qPlant$(tx1[t] and d1plant[plant_sectors,plant_,t] and sameas[plant_,'land'] and t.val <tKF_plant_end.val)
          -thetaJ$(tx1[t] and t.val > t2.val) #
        $ENDIF

        #6)
        $IF %calibratePlantManure%:
          pD_manure$(tx1[t] and tKF_plant[t])
        $ENDIF

     #   $IF %pLand2024calib%==1:
    #     pLand$(t.val<=2024)
    #   $ENDIF

      #ANIMALS 

        #1)
        #Animals 
        $IF %calibrateNumberAnimals_poul%:
          -uAni$(tx1[t] and Animals[Ani_] and d1Ani[ani_sectors,ani_,t] and (sameas[ani_sectors,'01061'] or sameas[ani_sectors,'01062']))
        $ENDIF 
        #1)
        -uAni$(tx1[t] and Animals[Ani_] and d1Ani[ani_sectors,ani_,t] and (sameas[ani_sectors,'01031'] or sameas[ani_sectors,'01032'] or sameas[ani_sectors,'01051'] or sameas[ani_sectors,'01052']))
        qAni$(tx1[t] and tKF_animals[t] and Animals[Ani_] and d1Ani[ani_sectors,ani_,t] and (sameas[ani_sectors,'01031'] or sameas[ani_sectors,'01032'] or sameas[ani_sectors,'01051'] or sameas[ani_sectors,'01052']))   
        # -uEmmAgrAni$(tx1[t] and animals[ani_] and (sameas[ani_sectors,'01051'] or sameas[ani_sectors,'01052']) and sameas[emmtype,'GrazingAnimals'] and sameas[emm_eq,'NH3'])

        #1)
        #Gødning
        $IF %calibrateNManure%:
          -uManurePerAnimal$(tx1[t] and sum(emm,d1EmmAgrAni['ManureManagement',ani_sectors,Animals,t,emm])), qNMANURE$(tx1[t] and tKF_animals[t] and sum(emm,d1EmmAgrAni['ManureManagement',ani_sectors,Animals,t,emm]))
          $IF1 %calibrateNManure_perdata%!=1:
          -qNManure$(tx1[t] and tKF_animals[t] and sum(emm,d1EmmAgrAni['ManureManagement',ani_sectors,Animals,t,emm]) and not (sameas[ani_sectors,'01051'] or sameas[ani_sectors,'01052'] or sameas[ani_sectors,'01061'] or sameas[ani_sectors,'01062']))
          $ENDIF1
      $ENDIF




  
    #2)
    #  E_uAni_01052
     jpK_ani$(sameas[ani_sectors,'01052'])
     -uAni$(tx1[t] and ani_pK[ani_] and sameas[ani_sectors,'01052'] and not sameas[ani_,'TransportCapital'])
    #  #  E_uAni_01070
    #  -jpK_ani$(sameas[ani_sectors,'01070'])
    #  uAni$(tx1[t] and ani_pK[ani_] and sameas[ani_sectors,'01070'] and not sameas[ani_,'TransportCapital'])
     #  E_uAni_01032
    #  jpK_ani$(sameas[ani_sectors,'01032'])
    #  -uAni$(tx1[t] and ani_pK[ani_] and sameas[ani_sectors,'01032'] and not sameas[ani_,'TransportCapital'])
     #  E_uAni_01031
    #  -jpK_ani$(sameas[ani_sectors,'01031'])
    #  uAni$(tx1[t] and ani_pK[ani_] and sameas[ani_sectors,'01031'] and not sameas[ani_,'TransportCapital'])
  
    # E_uAni_01061
     jpK_ani$(sameas[ani_sectors,'01061'])
     -uAni$(tx1[t] and ani_pK[ani_] and sameas[ani_sectors,'01061'] and not sameas[ani_,'TransportCapital'])

    # E_uAni_01062
    #  jpK_ani$(sameas[ani_sectors,'01062'])
    #  -uAni$(tx1[t] and ani_pK[ani_] and sameas[ani_sectors,'01062'] and not sameas[ani_,'TransportCapital'])
    #Alternatively (jqI_s) 
    # -qAni_capital$(t2[t] and sameas[ani_sectors,'01062'] and not sameas[ani_pK,'transportcapital']), jpK_ani$(sameas[ani_sectors,'01062'])
    -qAni_capital$(t2[t] and sameas[ani_sectors,'01062']), jpK_ani$(sameas[ani_sectors,'01062'] and not sameas[ani_pk,'TransportCapital'])
    #  -uK$(sameas[sp,'01062'] and t2[t] and not sameas[k,'it'])
    -uProd$(prdbotult(prd) and sameas[sp,'01062'] and t2[t] and not sameas[prd,'it'])

    -qAni_capital$(t2[t] and sameas[ani_sectors,'01032']), jpK_ani$(sameas[ani_sectors,'01032'] and not sameas[ani_pk,'TransportCapital'])
    #  -uK$(sameas[sp,'01032'] and t2[t] and not sameas[k,'it'])
    -uProd$(prdbotult(prd) and sameas[sp,'01032'] and t2[t] and not sameas[prd,'it'])

  ; 
    

    # sDebt2j.l[plant_sectors,t]$(t.val>t1.val) = 0.1;

    $FOR {iteite} in ['0']:
      $FOR1 {OneToZeroAgrIterator} in ['1']:
        iteite = {iteite};
        OneToZeroAgrIterator[agri_sectors] = {OneToZeroAgrIterator};

        $FIX G_dynamic_calibration_exo;
        $UNFIX G_dynamic_calibration_endo;
        # execute_unload 'output\pre.gdx';
        @print("--------- Integration of agricultural module. Phasing out mark-up in base-year by {iteite} --------------------")  
        $IF %readfromprevious%!=1:
          @SOLVE(M_dynamic_calibration_agr);
        $ENDIF
        #  $IF {iteite} == 1: execute_unload 'output\integrated_agr_fullmarkup.gdx'; $ENDIF
        #  execute_unload 'output\calib_agr_{iteite}.gdx';
      $ENDFOR1
    $ENDFOR


   @report_uc();


    $import sanitycheck.gms
    execute_unload 'Output\integrated_agr.gdx';
    @assert_no_difference(G_data,%tolerance_data%);

