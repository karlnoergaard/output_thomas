#We calibrate domestic demand through 

set includetheser[r]/
	#  01011	
	#  01012	
	#  01020	
	#  01031	
	#  01032	
	#  01051	
	#  01052	
	#  01061	
	#  01062	
	#  01070	
	#  01080	
#  02000	
#  03000	
#  0600a	
#  10020	
#  10030	
#  10040	
#  10120	
#  13150	
#  16000	
#  19000	
#  20000	
#  21000	
#  25000	
#  35011	
#  35002	
#  36000	
#  37000	
#  38391	
#  38392	
#  38393	
41430	
#  45000	
#  46000	
#  47000	
#  49011	
#  49024	
#  49031	
#  50001	
#  51001	
#  51009	
#  55560	
#  64000	
#  68203	
#  71000	
#  53000	
#  10011	
#  10012	
#  10013	
 23001	
#  23002	
#  49509	
#  off	
/;

	$PGROUP PG_calib_cement 
		iterator_cement ""
		p_cement_DST[t] ""
		q_cement_DST[t] ""
		vEBITDA_books_23001[t] "From AP's actual books"
	;

	p_cement_DST[t]$(p_grey[t] or p_white[t]) = 1;

	vEBITDA_books_23001['2020'] = 0.793*inf_growth_factor['2020'];
	vEBITDA_books_23001['2021'] = 0.688*inf_growth_factor['2021'];
	vEBITDA_books_23001['2022'] = 0.840*inf_growth_factor['2022'];
	vEBITDA_books_23001['2023'] = 1.014*inf_growth_factor['2023'];
	vEBITDA_books_23001['2024'] = 0.1371*7.5*inf_growth_factor['2024']; #137.1 million EUR in 2024


	#Værdien udgør kun 2 mia. I DST er det 2,7. Muligvis grundet at DST-branche også har distribution?"
		LOOP(t$(t.val>1995 and t.val<=2023), 
			q_cement_DST[t] = (p_grey[t-1]*q_grey[t] + p_white[t-1]*q_white[t])/p_cement_DST[t-1];
			p_cement_DST[t] = (p_grey[t]*q_grey[t] + p_white[t]*q_white[t])/q_cement_DST[t];
			);

		p_cement_DST[t] = p_cement_DST[t]/p_cement_DST['2019'];
		q_cement_DST[t] = q_cement_DST[t]*p_cement_DST['2019'];

		p_cement_DST[t] = p_cement_DST[t] * inf_factor[t];
		q_cement_DST[t] = q_cement_DST[t] * growth_factor[t];


	  $GROUP G_cement_calib_new 
       uETS_23000[t] ""
       qD_domestic_cement[t] "Demand for domestic cement"
       adj_qD_domestic_cement[t] ""
   ;

 		qD_domestic_cement.l[t] =  sum((r)$(d1RxE_y[r,'23001',t]), qRxE_y.l[r,'23001',t]) 
  														+ sum(c$(d1C_y[c,'23001',t]), 		qC_y.l[c,'23001',t]) 
  														+ sum(g$(d1G_y[g,'23001',t]), 		qG_y.l[g,'23001',t])
  														+ sum(i$(d1I_y[i,'23001',t]), 		qI_y.l[i,'23001',t]);

		adj_qD_domestic_cement.l[t] = 1;

    $BLOCK B_cement_calib 

    	E_qX_y_23001_export[t]$(tx1[t] and tBF_calib[t])..
    		qX_y['xOth','23001',t]/qX_y['xOth','23001',t-1] 
    															=E= iterator_cement*  KF_cementprod['White',t]/KF_cementprod['White',t-1]
    														 + (1-iterator_cement) * qX_y.l['xOth','23001',t]/qX_y.l['xOth','23001',t-1];

    	E_qX_y_23001_export_after_tBF_calib[t]$(tx1[t] and not tBF_calib[t])..
    		sX_y['xOth','23001',t] =E= sX_y['xOth','23001',tBF_calib_end];

    	E_qD_domestic_cement_calib[t]$(tx0[t] and tBF_calib[t])..
    		qD_domestic_cement[t] =E= sum((r)$(d1RxE_y[r,'23001',t]), qRxE_y[r,'23001',t]) 
    														+ sum(c$(d1C_y[c,'23001',t]), 		qC_y[c,'23001',t]) 
    														+ sum(g$(d1G_y[g,'23001',t]), 		qG_y[g,'23001',t])
    														+ sum(i$(d1I_y[i,'23001',t]), 		qI_y[i,'23001',t])
    													;

   		E_adj_qD_domestic_cement[t]$(tx1[t] and tBF_calib[t])..
   			qD_domestic_cement[t]/qD_domestic_cement[t-1] =E= iterator_cement * KF_cementprod['Grey',t]/KF_cementprod['Grey',t-1]
   																												+(1-iterator_cement) *  qD_domestic_cement.l[t]/qD_domestic_cement.l[t-1];

			E_sRxE_y_23001_tBF_calib[r,t]$(tx1[t] and tBF_calib[t] and d1RxE_ym[r,'23001',t] and includetheser[r])..
				sRxE_ym[r,'23001',t] =E= sRxE_ym.l[r,'23001',t] * adj_qD_domestic_cement[t];

			E_sRxE_y_23001_post_tBF_calib[r,t]$(tx1[t] and not tBF_calib[t] and d1RxE_ym[r,'23001',t] and includetheser[r])..
				sRxE_ym[r,'23001',t] =E= sRxE_ym[r,'23001',tBF_calib_end];


      #Compute ETS-payments share of total costs in domestic cement production
  	  #  E_uETS[t]$(tx1[t])..
     #  	 uETS_23000[t] =E= tCO2_ETS_avg['23001',t-1]/10**6 * growth_factor[t] * qEmmCO2ETS['23001',t]/(pY0['23001',t-1]*qY['23001',t]); #Weight in growth-contribution calculation. This weighs the share of growth that stems from a change in ETS-price 


       #Import-prices on cement set to follow domestic
	    E_pM_CET_cement[t]$(tx1[t])..
	        pM_CET['out_other','23001',t] =E=  pY_CET['out_other','23001',t];
	    #      pM_CET['out_other','23001',t] =E=  pM_CET['out_other','23001',t-1] * ( uETS_23000[t] * tCO2_ETS_avg['23001',t]/tCO2_ETS_avg['23001',t-1]
	    #                                                                      +(1-uETS_23000[t])) ;
	    #Export prices on cement
	    E_pXF_CET_cement[t]$(tx1[t])..
	        pXF['23001',t] =E=  pY_CET['out_other','23001',t];
	    #      pXF['23001',t] =E=  pXF['23001',t-1] * ( uETS_23000[t] * tCO2_ETS_avg['23001',t]/tCO2_ETS_avg['23001',t-1]
	    #                                                                        +(1-uETS_23000[t])) ;

	    #  E_pY_CET_cement_dataDST[t]$(tx1[t] and p_cement_DST[t])..
	    #  	pY_CET['out_other','23001',t]/pY_CET['out_other','23001',t-1] =E= p_cement_DST[t]/p_cement_DST[t-1];

	    #  E_markup_cement[t]$(tx1[t] and not p_cement_DST[t])..
	    #  	markup['out_other','23001',t] =E= markup['out_other','23001',t-1];

	    #Justeres igennem mark-up
	    E_vEBITDA_23001[t]$(tx1[t] and t.val<=2024)..
	    	vEBITDA_books_23001[t] =E= vEBITDA['23001',t]; 

	    E_markup_cement[t]$(tx1[t] and t.val>2024)..
	    	markup['out_other','23001',t] =E= 0.5*markup['out_other','23001',t-1] + 0.5 * (markup['out_other','23001','2019'] + markup['out_other','23001','2020'] + markup['out_other','23001','2021'] + markup['out_other','23001','2022'] + markup['out_other','23001','2023'] + markup['out_other','23001','2024'])/6;

	$ENDBLOCK 

   $GROUP G_dynamic_calibration_exo 
   	G_dynamic_calibration_exo
	-markup$(tx1[t] and sameas[out,'out_other'] and sameas[s,'23001'])
	-pY_CET$(tx1[t] and d1vY_CET[out,s,t] and sameas[out,'out_other'] and sameas[s,'23001'])
   ;

  $GROUP G_dynamic_calibration_endo 
  	G_dynamic_calibration_endo
 
   	pM_CET$(tx1[t] and d1vM_CET[out,s,t] and sameas[out,'out_other'] and sameas[s,'23001'])
   	pXF$(tx1[t] and sameas[s,'23001'])
   	qD_domestic_cement$(tx0[t] and tBF_calib[t])
   	sX_y$(tx1[t] and sameas[x,'xOth'] and sameas[s,'23001'])
   	adj_qD_domestic_cement$(tx1[t] and tBF_calib[t])
   	sRxE_ym$(tx1[t] and sameas[s,'23001'] and d1RxE_ym[r,s,t] and includetheser[r])
   	
   	markup$(tx1[t] and sameas[s,'23001'] and sameas[out,'out_other'])
	pY_CET$(tx1[t] and d1vY_CET[out,s,t] and sameas[out,'out_other'] and sameas[s,'23001'])
  ;

	$MODEL M_dynamic_calibration_cement
		M_dynamic_calibration_calib2ExtFor
		B_cement_calib
		#  -E_pM_CET_cement_calib_prod
		#  -E_pXF_CET_cement_calib_prod
	;

	#Udfaser mark-up
	#  loop(t$(tx1[t]), markup.l[out,'23001',t] = 0.6*markup.l[out,'23001',t-1]);	

	$FIX G_dynamic_calibration_exo;
	$UNFIX G_dynamic_calibration_endo;
	$FOR {iterator_cement} in ['1']:
	#  execute_unload 'output\pre.gdx';
	#  $FOR {iterator_cement} in ['1']:
		iterator_cement = {iterator_cement};
		@SOLVE(M_dynamic_calibration_cement);
	$ENDFOR 
	#  execute_unload 'output\calib_cement.gdx';

