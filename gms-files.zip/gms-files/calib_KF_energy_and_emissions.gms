#====================================================================================================================================================================================================================#
# OVERVIEW
#====================================================================================================================================================================================================================#
#
# 0) Initial manouvres that should probably be moved to other files
#
# 1) Dummies are updated to align with KF. Taxes, emmission-coefficients, and first round of initial values for energy that was not in GR, but in KF	
#
# 2) A couple new control dummies and control sets are created
#
# 3) New variables and parameters are created
# 
# 4) An accounting model is setup for aligning energy-use variables in GR with KF 
#
# 5) A pre-model to align supply of energy-goods to demand is setup 
#
# 6) Calibration equations are set up 
#
# 7) A pre-model for initial values for the calibration is set-up 
#
# 8) The calibration is run
#	- Firstly, equations and endo/exo-groups are set up for the model
#	  #Now the calibration 
#		- The calibration runs in a loop were we iterate closer to KF for every iteration (iteration parameters lambda and chi =1 for full adjustment to KF)
#		- One loop consists of
#           0. Setting iteration parameters lambda and chi
#			a. The accounting model is run for a given lambda and chi 
#			b. The very small model to adjust demand and supply is run 
#			c. The larger pre-model is run, which yields a lot of initial values for the full calib 
#			d. A few further initial values are set.
#			e. The calibration model is run. 
#====================================================================================================================================================================================================================#
#====================================================================================================================================================================================================================#
# 0) Initial manouvres - should perhaps be moved elsewhere
#====================================================================================================================================================================================================================#

	#HACK
	KF_TIL_NatBal_['Natural gas (Extraction)','import','2023'] = KF_TIL_NatBal_['Natural gas (Extraction)','import','2023']  - KF_ANV_NatBal_['Natural gas incl. biongas','eksport','2023']; 
	KF_ANV_NatBal_['Natural gas incl. biongas','eksport','2023'] = KF_ANV_NatBal_['Natural gas incl. biongas','eksport','2023']*0.1;
	
	uKinstcost.l[k,'01032','2021'] = 0;

		$GROUP G_data 
			G_data 
			-qEtot$(t.val=2018)
		;

		  Parameter
			d1pREa_KFnew[purpose,energy19,r,t]
			d1pREgj_KFnew[purpose,energy19,r,t]
			;

			d1pREa_KFnew[purpose,energy19,r,t] = d1pREa[purpose,energy19,r,t];
			d1pREgj_KFnew[purpose,energy19,r,t] = d1pREgj[purpose,energy19,r,t];


		# d1Plant['01020','Fuel',tForecast] = no; #Se bunden af Energy_GSR.sets.gms, hvor der lukkes ned for transportforbrug i gartneri



		KF25_energybalance_ENS_['Raffinaderier','District heat','notinGSR',t] = 0;


		KF25_energybalance_ENS_['Raffinaderier','Refinery gas','Raffinaderier',t] = KF25_energybalance_ENS_['Raffinaderier','Refinery gas','Raffinaderier',t] 
																			 + KF25_energybalance_ENS_['Kraftvarme','Refinery gas','BraendslertilElOgFjernvarme_notETS',t];
		KF25_energybalance_ENS_['Kraftvarme','Refinery gas','BraendslertilElOgFjernvarme_notETS',t] = 0;
		KF25_energybalance_ENS_['Kraftvarme','District heat',GSR_ag,t] = 0; #Er overskudsvarme, der ikke som sådan skal prissættes...

		KF25_energybalance_ENS_['Udvinding','Natural gas (extraction)','Nordsoeen',t]$(t.val>2049) = KF25_energybalance_ENS_['Udvinding','Natural gas (extraction)','Nordsoeen','2049'];
	#Biodiesel 
		KF_TIL_NatBal_['Biodiesel','Energisektor','2019'] = qY_CET.l['Biodiesel','19000','2019'];  

		LOOP(t$(tForecast[t] and tBF_calib[t]),
		KF_TIL_NatBal_['Biodiesel','Energisektor',t] = KF_TIL_NatBal_['Biodiesel','Energisektor',t-1] 
												     * KF_TIL_NatBal_['Biodiesel','import',t]/KF_TIL_NatBal_['Biodiesel','Import',t-1];
			);


	#Kontrol sets, der kan bruges til trouble shooting. Slår hhv. kalibrering af forbrugernes energiforbrug fra/til og kalibrering af energipriser (eksl. el og fjernvarme)

		d1pREown[purpose,energy19,s,t]$(t.val < t1.val) = no;

		PARAMETER d1EAV_RE_KFnew[purpose,energy19,r,t], d1EAV_CE_KFnew[purpose,energy19,t],
				  d1DAV_RE_KFnew[purpose,energy19,r,t], d1DAV_CE_KFnew[purpose,energy19,t],
				  d1CAV_RE_KFnew[purpose,energy19,r,t], d1CAV_CE_KFnew[purpose,energy19,t]
				  ;

		d1EAV_RE_KFnew[purpose,energy19,r,t] = yes$(sum(tDataEnd, d1EAV_RE[purpose,energy19,r,tDataEnd]));
		d1DAV_RE_KFnew[purpose,energy19,r,t] = yes$(sum(tDataEnd, d1DAV_RE[purpose,energy19,r,tDataEnd]));
		d1CAV_RE_KFnew[purpose,energy19,r,t] = yes$(sum(tDataEnd, d1CAV_RE[purpose,energy19,r,tDataEnd]));
		d1EAV_CE_KFnew[purpose,energy19,t]   = yes$(sum(tDataEnd, d1EAV_CE[purpose,energy19,tDataEnd])); 
		d1DAV_CE_KFnew[purpose,energy19,t]   = yes$(sum(tDataEnd, d1DAV_CE[purpose,energy19,tDataEnd])); 
		d1CAV_CE_KFnew[purpose,energy19,t]   = yes$(sum(tDataEnd, d1CAV_CE[purpose,energy19,tDataEnd])); 

	#Remove negative deductions

		IEC_waste[GSR_ag,categoryENS,t]$(t.val<2023 and t.val>2019) = IEC_waste[GSR_ag,categoryENS,'2023']; 
  #Correcting emission coefficients 
     uEmmProdE.fx['10040',t,'CO2ubio','Waste']$(t.val > 2019) 		  = IEC_waste['proces_non_ETS','Foedevarer',t];
     uEmmProdE.fx['10120',t,'CO2ubio','Waste']$(t.val > 2019) 		  = IEC_waste['proces_non_ETS','Foedevarer',t];		
	 uEmmProdE.fx['13150',t,'CO2ubio','Waste']$(t.val > 2019) 		    = IEC_waste['rumvarme','MetalMaskinElektronik',t];

		uEmmProdE.fx['23001',t,'CO2ubio','Waste']$(t.val > 2019) 	    	= IEC_waste['Mineralogi_cement','Cement',t];
		uEmmProdE.fx['35011',t,'CO2ubio','Waste']$(t.val > 2019)        = IEC_waste['BraendslertilElOgFjernvarme_ETS','Kraftvarme',t];
		uEmmProdE.fx['38393',t,'CO2ubio','Waste']$(t.val > 2019)        = IEC_waste['BraendslertilElOgFjernvarme_notETS','Kraftvarme',t];
		
	
	#BØR TJEKKES EFTER
	#For some energy-goods imports fall out in KF21. To allow for imports to re-enter the model in shocks imports are put back into the model, but with a very low value 
		set slicediz[eENS2GR]/'Natural gas (Extraction)','Gas and diesel oil','Gasoline and LVN'/;
		KF_ANV_NatBal_['Natural gas (Extraction)','Konverteringssektor',t] 				   = 0; #Special treatment for natural gas going to distribution net
		KF_ANV_NatBal_[eENS2GR,'eksport',tBF_calib]$(KF_ANV_NatBal_[eENS2GR,'eksport',tBF_calib]=0 and KF_ANV_NatBal_[eENS2GR,'eksport','2019']) = 1;#If exports are zero, but exist in last data-year we still allow them in the model
		KF_ANV_NatBal_[eENS2GR,sENS,t]$(t.val > tBF_calib_End.val)                         = KF_ANV_NatBal_[eENS2GR,sENS,tBF_calib_End]; 
		KF_TIL_NatBal_[eENS2GR,'import',tBF_calib]$(KF_TIL_NatBal_[eENS2GR,'import',tBF_calib]=0 and KF_TIL_NatBal_[eENS2GR,'import','2019']) = 1;
		KF_TIL_NatBal_[eENS2GR,sENS,t]$(t.val > tBF_calib_End.val) = KF_TIL_NatBal_[eENS2GR,sENS,tBF_calib_End];
		KF_TIL_NatBal_[eENS2GR,'nettoimport',t] = no;

	#Extending emissions (SKAL FLYTTES)
		KF_emm_[emm_eq,sCRF,t]$(t.val > tBF_calib_end.val) = KF_emm_[emm_eq,sCRF,tBF_calib_end];

#=============================================================================================================================================================================================#
# 1) Updating dummies and loading in values for taxes, emission-factors, and some initial values on "new" energy (new meaning entries where there is energy in the Climate Outlook, but not in GR-data)
#=============================================================================================================================================================================================#

	#NO BOTTOM DEDUCTION AFTER 2025 (This should ideally be turned off in all phases of calibration)
		d1BotdedCO2post25=0;


		$SETGLOBAL calibKF23_consumers 1
		$SETGLOBAL calibvtCALIB 1
		$SETGLOBAL withoutchainindicesfirms 0

		$SETGLOBAL calibKF23_pricesXkraftvarme 1
		$SETGLOBAL calibKF23_priceskraftvarme 1
		$SETGLOBAL shutdownnorthsea 0 #For ad hoc shutting down Northsea. In KF25 projection goes until 2050, and takes over

		set KF25_pE_supply_xPricesKraftvarme[energy19,t];
		KF25_pE_supply_xPricesKraftvarme[energy19,t] = yes$(KF25_pE_supply[energy19,t] and not (sameas[energy19,'el from y and m'] or sameas[energy19,'electricity'] or sameas[energy19,'district heat']));

	#CREATE CONTROL PARAMETERS AND SETS
		#We create the dummy 'NotInMapping' to control those few entries where we don't want to map to ENS. Bunkering, natural gas and biogas for conversion and jet petroleum used for international flights
			PARAMETER NotInMapping[purpose,energy19,s,t];
			NotInMapping[purpose,energy19,s,t]                                      = yes$(bunkering[energy19]);
			NotInmapping['process_special','biogas','35002',t] 					    = yes; #Biogas converted to bionatural gas
			NotInmapping['process_special','Natural gas (extraction)','35002',t]    = yes; #Natural gas flowing into pipes for distribution
			# uKinstcost.l[k,'35002',t] = 0;  #uKinstcost.l[k,'19000',t] = 0; #uKinstcost.l[k,'35011',t] = 0;
			#  NotInmapping['in_ETS','Natural gas (extraction)','35002',t] 			= yes; 
			NotInmapping[purpose,energy19,s,t]$(d1pREown[purpose,energy19,s,t])     = yes; #Own-production we still want. Should be included in mapping instead of this though... Det burde der være styr på nu
			NotInmapping['transport','jet petroleum','51009',t]                     = yes; #International aviation is not in ENS-data
			# NotInmapping['in_ETS','jet petroleum','51001',t]                      = yes; #Hack to make it run
			NotInmapping['process_special','el from y and m','35012',t]             = yes; #Eldistribution is not in ENS-data

			#Check that we don't have any one-to-many mappings after expanding the mapping
			PARAMETER tjek, WhatismappedinGR[purpose,energy19,s];
			WhatismappedinGR[purpose,energy19,s] = sum((categoryENS,GSR_ag)$(sENS2GR(categoryENS, GSR_ag, purpose, energy19, s)), 1); 

			LOOP((purpose,energy19,s)$(WhatismappedinGR[purpose,energy19,s]),
					tjek = WhatismappedinGR[purpose,energy19,s];
				 ABORT$(tjek <> 1) tjek, "Et element i mappingen bliver mappet til flere steder - ret i sENS2sENS2DST eller sENS2sENS2DST_dis";
					);

			#We do not adjust import/export of the energy-goods below. Electricity imports/exports will however be calibrated, but in a separate calibration step
			set eExcludeExportsENS(eENS2GR)/'electricity','El from y and m'/; #'Jet petroleum','Oil products',
			set eExcludeExportsGR(out)/'Semi-refined oil','LVN','electricity', 'El from y and m'/; #'''Jet petroleum','Oil products',

			set eInclENS[eENS2GR] /set.eENS2GR/;
			set eInclGR[energy19]/set.energy19/;

			set sIncl[CategoryENS]/set.CategoryENS/;
			set purpIncl[GSR_ag]/set.GSR_ag/;

			$OnMultiR
			set nonpricedenergy(energy19)/'Waste','Wood waste','Biooil','waste oil','renewable energy','heat pumps','Jet fuel, sustainable'/;

			$OffMulti

		    #To avoid that the NLP - which ensures consistent energy-balances - skews the energy-balances for non-marketed energy-goods we create a dummy to avoid this.
		    PARAMETER d1NonMarketEnergy[energy19,t];
			d1NonMarketEnergy[energy19,t] = yes$((sum(s,d1vY_CET[energy19,s,t]) = 0 and sum(s,d1qY_CET[energy19,s,t])) or (sum(s,d1vM_CET[energy19,s,t]) = 0 and sum(s,d1qM_CET[energy19,s,t])));

		#SLowly phasing out Northsea over these years:
			set tShutNorthSea[t];
			singleton set tShutNorthSeaEnd[t]/2050/;
			singleton set tShutNorthSeaStart[t]/2036/;
			tShutNorthSea[t]$(t.val > tBF_calib_end.val and t.val <=2050) = yes;


	#ENERGY-USE
		#B2B	  
		  PARAMETER d1KF25_energybalance_ENS_notDST[CategoryENS,eENS2GR,GSR_ag,t], energybalance_DST2ENS[CategoryENS,eENS2GR,GSR_ag,t], d1energybalance_DST_notENS[CategoryENS,eENS2GR,GSR_ag,t], 
		  			d1qRE_out[purpose,energy19,s,t] "Dummy determining energy use (quantities) in DST that is not present in KF" 
		  			qE_shareofENS[s,GSR_ag,CategoryENS,t], qE_shareofENS_simple[s,CategoryENS,t];



		  #Laver initial energibalance af GR på mappingen
		  energybalance_DST2ENS[CategoryENS,eENS2GR,GSR_ag,t] = (sum((energy19,purpose,s)$(sENS2GR(categoryENS, GSR_ag, purpose, energy19, s) and ene192eENS2GR(energy19, eENS2GR)), qREgj.l[purpose,energy19,s,t]$(d1qREgj[purpose,energy19,s,t])))
				     + sum((energy19,purpose_xt)$(sENS2GR(categoryENS, GSR_ag, purpose_xt, energy19, '68203') and ene192eENS2GR(energy19, eENS2GR)), qCE.l[purpose_xt,energy19,t]$(d1qCE[purpose_xt,energy19,t]))
				     + (sum(energy19$(ene192eENS2GR(energy19, eENS2GR)), qCE.l['transport',energy19,t]$(d1qCE['transport',energy19,t])))$(sameas[CategoryENS,'Vejtransport'] and sameas[GSR_ag,'Vejtransport']); 


  		  #Vi beregner branchens initiale andel af ENS-branche pba. GR
		  qE_shareofENS[s,GSR_ag,CategoryENS,t]$(sum(eENS2GR,energybalance_DST2ENS[CategoryENS,eENS2GR,GSR_ag,t])) 
		  												   = sum((energy19,purpose)$(sENS2GR(categoryENS, GSR_ag, purpose, energy19, s)), qREgj.l[purpose,energy19,s,t]$(d1qREgj[purpose,energy19,s,t]))
		  													/sum(eENS2GR,energybalance_DST2ENS[CategoryENS,eENS2GR,GSR_ag,t]);

		  #Et grovere andelsmål opnås ved også at summere GSR_ag ud. Det er nødvendigt for at få lavet initial værdier på ny energi, da forskellen på ENS/GR er så store som de er. Var forskellene mindre ville det være kønnere at bruge ovenstående i stedet
		  qE_shareofENS_simple[s,CategoryENS,t]$(sum((eENS2GR,GSR_ag),energybalance_DST2ENS[CategoryENS,eENS2GR,GSR_ag,t])) 
		  								    = sum((energy19,purpose,GSR_ag)$(sENS2GR(categoryENS, GSR_ag, purpose, energy19, s)), qREgj.l[purpose,energy19,s,t]$(d1qREgj[purpose,energy19,s,t]))
		  									 /sum((eENS2GR,GSR_ag),energybalance_DST2ENS[CategoryENS,eENS2GR,GSR_ag,t]);

		  #Vi har endda tilfælde, hvor der ikke summes nogle energivarer i GR til Energibalancer. Der sætter vi bare andelen til 1.
		  qE_shareofENS_simple[s,CategoryENS,t]$(sum((energy19,purpose,GSR_ag)$(sENS2GR(categoryENS, GSR_ag, purpose, energy19, s)), qREgj.l[purpose,energy19,s,t]$(d1qREgj[purpose,energy19,s,t])) =0 and
		  										 qE_shareofENS_simple[s,CategoryENS,t] = 0 and
		  										 sum((eENS2GR,GSR_ag), KF25_energybalance_ENS_[categoryENS,eENS2GR,GSR_ag,t])) = 1;


	      #Tjek af tæller og nævner til troubleshooting
		  Parameter taeller_qE_share[s,CategoryENS,t], naevner_qE_share[s,CategoryENS,t];									 
		  taeller_qE_share[s,CategoryENS,t] = sum((energy19,purpose,GSR_ag)$(sENS2GR(categoryENS, GSR_ag, purpose, energy19, s)), qREgj.l[purpose,energy19,s,t]$(d1qREgj[purpose,energy19,s,t]));
		  naevner_qE_share[s,CategoryENS,t] = sum((eENS2GR,GSR_ag),energybalance_DST2ENS[CategoryENS,eENS2GR,GSR_ag,t]);


		  set thesecats[categoryENS]/KraftVarme/;
		  set thesepurs[GSR_ag]/LandOgSkov,notinGSR,notinGSR_ETS,LandOgSkov_gartneri_ETS/;

		  #Laver en dummy for, hvad der er i energibalancerne i ENS, men ikke GR
  		  d1KF25_energybalance_ENS_notDST[CategoryENS,eENS2GR,GSR_ag,t] = yes$(KF25_energybalance_ENS_[CategoryENS,eENS2GR,GSR_ag,t] and not energybalance_DST2ENS[CategoryENS,eENS2GR,GSR_ag,t]);

  		  #Laver en dummy for hvad, der ligger i GR, men ikke i ENS
		  d1energybalance_DST_notENS[CategoryENS,eENS2GR,GSR_ag,t] = yes$(energybalance_DST2ENS[CategoryENS,eENS2GR,GSR_ag,t] and not KF25_energybalance_ENS_[CategoryENS,eENS2GR,GSR_ag,t]);

		  ### ENERGY USE (QUANTITIES)
		  # Read dummy for DST-data as a first step
		  d1qREgj_KFnew[purpose,energy19,s,t] 	= d1qREgj[purpose,energy19,s,t];
		  d1qRE_out[purpose,energy19,s,t] 		= d1qREgj[purpose,energy19,s,t];

  		  d1qREgj[purpose,energy19,s,t]$(t.val > t1.val and qREgj.l[purpose,energy19,s,t] and not
  		  							  sum((CategoryENS,GSR_ag,eENS2GR)$(sENS2GR(categoryENS, GSR_ag, purpose, energy19, s) and ene192eENS2GR(energy19, eENS2GR) and sIncl[categoryENS] and purpIncl[GSR_ag]), KF25_energybalance_ENS_[categoryENS,eENS2GR,GSR_ag,t]) # and thesecats[categoryENS] and thesepurs[GSR_ag])) 
  		  							  and not NotInmapping[purpose,energy19,s,t]
  		  							  ) = no;



		  d1qREgj[purpose,energy19,'0600a',t]$(t.val > t1.val and not (sameas[energy19,'Natural gas (extraction)'] and sameas[purpose,'in_ETS'])) = no;


		   #  We dummy in where ENS-data is present that is not present in DST. #LBS: not qREgj kan slettes
		  d1qREgj['heating',energy19,s,t]$(t.val > t1.val and not qREgj.l['heating',energy19,s,t] and sum((CategoryENS,GSR_ag,eENS2GR)$(sENS2GR(categoryENS,GSR_ag, 'heating', energy19, s) and ene192eENS2GR(energy19, eENS2GR)),
		  											d1KF25_energybalance_ENS_notDST[CategoryENS,eENS2GR,GSR_ag,t]) and not NotInmapping['heating',energy19,s,t] and not sameas[s,'68203']) = yes;
		

		  d1qREgj['process_normal',energy19,s,t]$(t.val > t1.val and not qREgj.l['process_normal',energy19,s,t] and sum((CategoryENS,GSR_ag,eENS2GR)$(sENS2GR(categoryENS, GSR_ag, 'process_normal', energy19, s) and ene192eENS2GR(energy19, eENS2GR)), 
  											d1KF25_energybalance_ENS_notDST[CategoryENS,eENS2GR,GSR_ag,t]) and not NotInmapping['process_normal',energy19,s,t] and not sameas[s,'68203']) = yes;


		  d1qREgj['process_special',energy19,s,t]$(t.val > t1.val and not qREgj.l['process_special',energy19,s,t] and sum((CategoryENS,GSR_ag,eENS2GR)$(sENS2GR(categoryENS, GSR_ag, 'process_special', energy19, s) and ene192eENS2GR(energy19, eENS2GR)), 
  											d1KF25_energybalance_ENS_notDST[CategoryENS,eENS2GR,GSR_ag,t]) 
  											 and not NotInmapping['process_special',energy19,s,t] and not sameas[s,'68203']) = yes;

		  d1qREgj['intern_trans',energy19,s,t]$(t.val > t1.val and not qREgj.l['intern_trans',energy19,s,t] and sum((CategoryENS,GSR_ag,eENS2GR)$(sENS2GR(categoryENS, GSR_ag, 'intern_trans', energy19, s) and ene192eENS2GR(energy19, eENS2GR)), 
  											d1KF25_energybalance_ENS_notDST[CategoryENS,eENS2GR,GSR_ag,t]) and not NotInmapping['intern_trans',energy19,s,t] and not sameas[s,'68203']) = yes;



		  d1qREgj['in_ETS',energy19,s,t]$(t.val > t1.val and not qREgj.l['in_ETS',energy19,s,t] and sum((CategoryENS,GSR_ag,eENS2GR)$(sENS2GR(categoryENS, GSR_ag, 'in_ETS', energy19, s) and ene192eENS2GR(energy19, eENS2GR)), 
  											d1KF25_energybalance_ENS_notDST[CategoryENS,eENS2GR,GSR_ag,t]) and not NotInmapping['in_ETS',energy19,s,t] and not sameas[s,'68203']) = yes;


		  d1qREgj['transport',energy19,s,t]$(t.val > t1.val and not qREgj.l['transport',energy19,s,t] and sum((CategoryENS,GSR_ag,eENS2GR)$(sENS2GR(categoryENS, GSR_ag, 'transport', energy19, s) and ene192eENS2GR(energy19, eENS2GR)), 
  											d1KF25_energybalance_ENS_notDST[CategoryENS,eENS2GR,GSR_ag,t]) and not NotInmapping['transport',energy19,s,t] and not sameas[s,'68203']) = yes;


		  # Energy use that is deleted is determined as the subset of old energy use (DST), that is not present in KF
		  d1qRE_out[purpose,energy19,s,t] = yes$(d1qRE_out[purpose,energy19,s,t] and not d1qREgj[purpose,energy19,s,t]);
		  
		  # New energy use is determined as the subset of new energy use (KF), that is not present in DST
		  d1qREgj_KFnew[purpose,energy19,s,t] = yes$(d1qREgj[purpose,energy19,s,t] and not d1qREgj_KFnew[purpose,energy19,s,t]);
		  d1qREgj_KFnew[purpose,'Wood waste',s,t] = no; # New energy use is cancelled
		  d1qREgj_KFnew[purpose,'Waste oil',s,t]  = no; # New energy use is cancelled
		  
		  # Energy consumption (quantities) that is not present in the new energy matrix (KF) is deleted
		  qREa.l[purpose,energy19,s,t]$(not d1qREgj[purpose,energy19,s,t])  = no;
		  qREgj.l[purpose,energy19,s,t]$(not d1qREgj[purpose,energy19,s,t]) = no;


		  ### MARKET PRICE OF ENERGY ###
		  PARAMETER 
		  	d1pRE_base_KFnew[purpose,energy19,s,t] "Dummy determining energy use with market prices in KF that is not present in DST"
			d1pRE_base_out[purpose,energy19,s,t] "Dummy determining energy use (prices) in DST that is not present in KF"
			d1KF25_energybalance_ENS_new[CategoryENS,eENS2GR,GSR_ag,t]
			;
		  
		  # Read dummy for DST-data as a first step
		  d1pRE_base_KFnew[purpose,energy19,s,t] = d1pRE_base[purpose,energy19,s,t];
		  d1pRE_base_out[purpose,energy19,s,t] = d1pRE_base[purpose,energy19,s,t];

		  d1pRE_base[purpose,energy19,s,t]$(t.val > t1.val and not d1qREgj[purpose,energy19,s,t]) = no;
# 
		  # Set for non-priced energy use

		  
		  #We dummy in where ENS-data is present. 
		  										  #LBS: Forsøg at slette "not pRE_base"
		    d1pRE_base['heating',energy19,s,t]$(t.val > t1.val and not pRE_base.l['heating',energy19,s,t] and sum((CategoryENS,GSR_ag,eENS2GR)$(sENS2GR(categoryENS, GSR_ag, 'heating', energy19, s) and ene192eENS2GR(energy19, eENS2GR)),
		   											d1KF25_energybalance_ENS_notDST[CategoryENS,eENS2GR,GSR_ag,t]) and not NotInmapping['heating',energy19,s,t] and not sameas[s,'68203'] and not nonpricedenergy[energy19]) = yes;
		
		    d1pRE_base['process_normal',energy19,s,t]$(t.val > t1.val and not pRE_base.l['process_normal',energy19,s,t] and sum((CategoryENS,GSR_ag,eENS2GR)$(sENS2GR(categoryENS, GSR_ag, 'process_normal', energy19, s) and ene192eENS2GR(energy19, eENS2GR)), 
  		  									d1KF25_energybalance_ENS_notDST[CategoryENS,eENS2GR,GSR_ag,t]) and not NotInmapping['process_normal',energy19,s,t] and not sameas[s,'68203'] and not nonpricedenergy[energy19]) = yes;

		    d1pRE_base['process_special',energy19,s,t]$(t.val > t1.val and not pRE_base.l['process_special',energy19,s,t] and sum((CategoryENS,GSR_ag,eENS2GR)$(sENS2GR(categoryENS, GSR_ag, 'process_special', energy19, s) and ene192eENS2GR(energy19, eENS2GR)), 
  		  									d1KF25_energybalance_ENS_notDST[CategoryENS,eENS2GR,GSR_ag,t]) and not
  		  									NotInmapping['process_special',energy19,s,t] and not sameas[s,'68203'] and not nonpricedenergy[energy19]) = yes;

		    d1pRE_base['intern_trans',energy19,s,t]$(t.val > t1.val and not pRE_base.l['intern_trans',energy19,s,t] and sum((CategoryENS,GSR_ag,eENS2GR)$(sENS2GR(categoryENS, GSR_ag, 'intern_trans', energy19, s) and ene192eENS2GR(energy19, eENS2GR)), 
  		  									d1KF25_energybalance_ENS_notDST[CategoryENS,eENS2GR,GSR_ag,t]) and not NotInmapping['intern_trans',energy19,s,t] and not sameas[s,'68203'] and not nonpricedenergy[energy19]) = yes;

		    d1pRE_base['in_ETS',energy19,s,t]$(t.val > t1.val and not pRE_base.l['in_ETS',energy19,s,t] and sum((CategoryENS,GSR_ag,eENS2GR)$(sENS2GR(categoryENS, GSR_ag, 'in_ETS', energy19, s) and ene192eENS2GR(energy19, eENS2GR)), 
  		  									d1KF25_energybalance_ENS_notDST[CategoryENS,eENS2GR,GSR_ag,t]) and not NotInmapping['in_ETS',energy19,s,t] and not sameas[s,'68203'] and not nonpricedenergy[energy19]) = yes;

		    d1pRE_base['transport',energy19,s,t]$(t.val > t1.val and not pRE_base.l['transport',energy19,s,t] and sum((CategoryENS,GSR_ag,eENS2GR)$(sENS2GR(categoryENS, GSR_ag, 'transport', energy19, s) and ene192eENS2GR(energy19, eENS2GR)), 
  		  									d1KF25_energybalance_ENS_notDST[CategoryENS,eENS2GR,GSR_ag,t]) and not NotInmapping['transport',energy19,s,t] and not sameas[s,'68203'] and not nonpricedenergy[energy19]) = yes;


		  # Energy prices that are deleted is determined as the subset of old energy use (DST), that is not present in KF
		  d1pRE_base_out[purpose,energy19,s,t] = yes$(d1pRE_base_out[purpose,energy19,s,t] and not d1pRE_base[purpose,energy19,s,t]);

		  # New energy prices are determined as the subset of new energy use (KF), that is not present in DST
		  d1pRE_base_KFnew[purpose,energy19,s,t] = yes$(d1pRE_base[purpose,energy19,s,t] and not d1pRE_base_KFnew[purpose,energy19,s,t]);
  		  d1pRE_base_KFnew[purpose,'Wood waste',s,t] = no; # New energy prices are cancelled
		  d1pRE_base_KFnew[purpose,'Waste oil',s,t]  = no; # New energy prices are cancelled

		  #For new energy- the J-term is not determined and is set to zero. A dummy is needed to identify new J-terms (kan evt slettes)
		  d1KF25_energybalance_ENS_new[CategoryENS,eENS2GR,GSR_ag,t]$(not sameas[CategoryENS,'husholdninger']) 
		  	= yes$(sum((purpose,energy19,s)$(sENS2GR(categoryENS, GSR_ag, purpose, energy19, s) and ene192eENS2GR(energy19, eENS2GR)), d1pRE_base_KFnew[purpose,energy19,s,t]));
	

		  #Initial value
		  $SETLOCAL init_gj 1
		  qREgj.l[purpose,energy19,s,t]$(d1qREgj_KFnew[purpose,energy19,s,t]) = sum((CategoryENS,GSR_ag,eENS2GR)$(sENS2GR(categoryENS, GSR_ag, purpose, energy19, s) and ene192eENS2GR(energy19, eENS2GR)), qE_shareofENS_simple[s,CategoryENS,t]*KF25_energybalance_ENS_[CategoryENS,eENS2GR,GSR_ag,t]);      #    %init_gj%;
 		  qREa.l[purpose,energy19,s,t]$(d1qREgj_KFnew[purpose,energy19,s,t])   	 = qREgj.l[purpose,energy19,s,t];    #%init_gj%;
		  qREE.l[purpose,energy19a,energy19,s,t]$(d1qREgj_KFnew[purpose,energy19,s,t] and sameas[energy19,energy19a]) = qREgj.l[purpose,energy19,s,t]; #£: Overflødig?
		  qREE.l[purpose,energy19a,energy19,s,t]$(not d1qREgj[purpose,energy19,s,t]) = 0;
		  uREE.l[purpose,energy19a,energy19,s,t]$(d1qREgj_KFnew[purpose,energy19,s,t] and sameas[energy19,energy19a]) = 1; #£: Overflødig?

		  #Tildeler EMISSIONSFAKTORER til nye energivarer
		  uEmmProdE.fx[s,t,'CO2ubio',energy19]$(sum(purpose,d1qREgj_KFnew[purpose,energy19,s,t]) and not uEmmProdE.l[s,t,'CO2ubio',energy19]) = uEmmHardCoded['CO2ubio',energy19];
		  uEmmProdE.fx[s,t,'CO2bio',energy19]$(sum(purpose,d1qREgj_KFnew[purpose,energy19,s,t]) and not uEmmProdE.l[s,t,'CO2bio',energy19])   = uEmmHardCoded['CO2bio',energy19]; #£ tilføjer


		  qEmmProdE.l[s,t,emm,purpose,energy19]$(tForecast[t] and d1qREgj_KFnew[purpose,energy19,s,t])
		  		  										   				  = uEmmProdE.l[s,t,emm,energy19] * qREgj.l[purpose,energy19,s,t]; #Pga affaldskoefficienterne genberegnes alle emissioner 

		  qEmmProdE.l[s,t,'CO2e',purpose,energy19] 				  = sum(emm$(qEmmProdE.l[s,t,emm,purpose,energy19]), qEmmProdE.l[s,t,emm,purpose,energy19]*GWP.l[emm]) + qEmmProdE.l[s,t,'CCSbio',purpose,energy19];
		  								
		  #Opdaterer bionaturgasandele
		  sBioNatgas.l[purpose,r,t]$(d1qRE_new[purpose,'natural gas incl. biongas',r,t]) = sBioNatgasAvgAdj.l[t];


		  #TAX-RATES ON NEW ENERGY IS LOADED - THIS COMES BEFORE FINAL DUMMIES AS DUMMY UPDATE RELY ON THESE VALUES
		  	  tEAFG_REmarg.l[purpose,energy19,s,t]$(not d1qREgj[purpose,energy19,s,t]) = 0;

	  		  tEAFG_REmarg.l[purpose,energy19,s,t]$(d1qREgj_KFnew[purpose,energy19,s,t]) 
	  		  	= sum((categoryENS,GSR_ag,tREbase_SKM)$(sENS2GR(categoryENS, GSR_ag, purpose, energy19, s) 
	  		  											and tREbase_SKM_2_ENS(tREbase_SKM,categoryENS,GSR_ag,energy19) 
	  		  											and d1qREgj[purpose,energy19,s,t] 
	  		  											and not sameas[energy19,'Jet petroleum']), tEAFG_REmarg_SKM.l[tREbase_SKM,t]);

  		      tEAFG_REmarg.l[purpose_xt,'electricity','64000',t]$(d1qREgj_KFnew[purpose_xt,'electricity','64000',t]) = tEAFG_REmarg_SKM.l['el_ikke-proces',t]; #Finansiel sektor (strengt taget momsfritagne/lønsumsomfattede vsh) betaler fuld elafgift, jf. mail fra Sebastian Lind SKM d. 22.5.2024. Kh AKB
	  	
	  				#  tEAFG_REmarg.l[purpose,'waste',s,t]$(d1qREgj_KFnew[purpose,'waste',s,t] and not sameas[purpose,'in_ETS']) = 0.01;
	  				
		      #Test af indlæste energiafgifter
		      LOOP((purpose,energy19,s),
		        tjek = tEAFG_REmarg.l[purpose,energy19,s,'2025'];
		        ABORT$(tjek > smax(tREbase_SKM,tEAFG_REmarg_SKM.l(tREbase_SKM,'2025'))) tjek, "De indlæste energiafgifter må ikke overstige max i input fra data - hvis det gør er der fejl i mappingen tREbase_SKM_2_ENS";
	      	   );
	      


			  tCO2_REmarg.l[purpose,energy19,s,t,'CO2ubio']$(d1qREgj_KFnew[purpose,energy19,s,t]) = sum((categoryENS,GSR_ag,tREbase_SKM)$(sENS2GR(categoryENS, GSR_ag, purpose, energy19, s) and tREbase_SKM_2_ENS(tREbase_SKM,categoryENS,GSR_ag,energy19) and qEmmProdE.l[s,t,'CO2ubio',purpose,energy19]), tCO2_REmarg_SKM.l[tREbase_SKM,t]);
			  tCO2_REmarg.l[purpose,'Natural gas incl. biongas',s,t,'CO2bio']$(d1qREgj_KFnew[purpose,'Natural gas incl. biongas',s,t]) = sum((categoryENS,GSR_ag,tREbase_SKM)$(sENS2GR(categoryENS, GSR_ag, purpose, 'Natural gas incl. biongas', s) and tREbase_SKM_2_ENS(tREbase_SKM,categoryENS,GSR_ag,'Natural gas incl. biongas') and qEmmProdE.l[s,t,'CO2bio',purpose,'natural gas incl. biongas'] and qEmmProdE.l[s,t,'CO2ubio',purpose,'natural gas incl. biongas']), tCO2_REmarg_SKM.l[tREbase_SKM,t]);
			  tCO2_REmarg.l[purpose,energy19,s,t,emm_eq]$(not d1qREgj[purpose,energy19,s,t]) = 0;

			  #Test af indlæste afgifter (vi laver stikprøve i 2025 - egentlig burde man nok køre over alle år)
		        LOOP((purpose,energy19,s),
		        #Tjek for CO2ubio
		        tjek = tCO2_REmarg.l[purpose,energy19,s,'2025','CO2ubio'];
		        ABORT$(tjek > smax(tREbase_SKM,tCO2_REmarg_SKM.l(tREbase_SKM,'2025'))) tjek, "De indlæste CO2-afgifter må ikke overstige max i input fra data - hvis det gør er der fejl i mappingen tREbase_SKM_2_ENS";
		        #Tjek for CO2bio
		        tjek = tCO2_REmarg.l[purpose,energy19,s,'2025','CO2bio'];
		        ABORT$(tjek > smax(tREbase_SKM,tCO2_REmarg_SKM.l(tREbase_SKM,'2025'))) tjek, "De indlæste CO2-afgifter må ikke overstige max i input fra data - hvis det gør er der fejl i mappingen tREbase_SKM_2_ENS";
		        );

				

	      #NOx-afgift på ny energi
	      tNOx_RE.l[purpose,energy19,r,t]$(d1qREgj_KFnew[purpose,energy19,r,t] and tNOx_REomregner[energy19] and not (sameas[r,'35001'] or sameas[r,'38393'])) #Vi antager at forbrændingsanlæggene har så meget røgteknologi at de slipper for NOx-afgift (grov antagelse, kh Asbjørn)
	      	= 1/tNOx_REomregner[energy19];

		#   $FUNCTION compute_initial_taxvalues():

 		  	#Regner provenuer, så dummies for skattevariable ryger ind længere nede
    	  	vtEAFG_RE.l[purpose,energy19,r,t]$(d1qREgj_KFnew[purpose,energy19,r,t]) = tEAFG_REmarg.l[purpose,energy19,r,t]*10**(-3) 
          	                                                                          * (qREgj.l[purpose,energy19,r,t] - qEAFG_REgj_ded.l[purpose,energy19,r,t]) 
          	                                                                          + jtEAFG_RE.l[purpose,energy19,r,t];

		  	vtNOx_RE.l[purpose,energy19,r,t]$(d1qREgj_KFnew[purpose,energy19,r,t])  = tNOx_RE.l[purpose,energy19,r,t] * qREgj.l[purpose,energy19,r,t];

		  	vtCO2_REmarg.l[purpose,energy19,r,t]$(d1qREgj_KFnew[purpose,energy19,r,t])                                       =  tCO2_REmarg.l[purpose,energy19,r,t,'CO2ubio'] * qEmmProdE.l[r,t,'CO2ubio',purpose,energy19]*growth_factor[t]/10**6;
  		  	vtCO2_REmarg.l[purpose,'natural gas incl. biongas',r,t]$(d1qREgj_KFnew[purpose,'natural gas incl. biongas',r,t]) =  tCO2_REmarg.l[purpose,'natural gas incl. biongas',r,t,'CO2bio']  * qEmmProdE.l[r,t,'CO2bio',purpose,'natural gas incl. biongas']*growth_factor[t]/10**6;


  		  	vEAV_RE.l[purpose,energy19,r,t]$(d1qREgj_KFnew[purpose,energy19,r,t] and d1EAV_RE_KFnew[purpose,energy19,r,t]) = 0.001; #Just inserting value to update dummy below 
  		  	vDAV_RE.l[purpose,energy19,r,t]$(d1qREgj_KFnew[purpose,energy19,r,t] and d1DAV_RE_KFnew[purpose,energy19,r,t]) = 0.001; #Just inserting value to update dummy below 
  		  	vCAV_RE.l[purpose,energy19,r,t]$(d1qREgj_KFnew[purpose,energy19,r,t] and d1CAV_RE_KFnew[purpose,energy19,r,t]) = 0.001; #Just inserting value to update dummy below 

		#   $ENDFUNCTION

		  	# Deleting old revenues
		  	vtEAFG_REmarg.l[purpose,energy19,r,t]$(not d1qREgj[purpose,energy19,r,t]) = 0;
		  	vtNOx_RE.l[purpose,energy19,r,t]$(not d1qREgj[purpose,energy19,r,t])      = 0;
		  	vtCO2_REmarg.l[purpose,energy19,r,t]$(not d1qREgj[purpose,energy19,r,t])	= 0;
	
  		  	vEAV_RE.l[purpose,energy19,r,t]$(not d1qREgj[purpose,energy19,r,t]) 		= 0; 
  		  	vDAV_RE.l[purpose,energy19,r,t]$(not d1qREgj[purpose,energy19,r,t]) 		= 0; 
  		  	vCAV_RE.l[purpose,energy19,r,t]$(not d1qREgj[purpose,energy19,r,t]) 		= 0; 

		  #HUSK AFGIFTER PÅ F.EKS AFFALD HER!!!! - AFFALD ER IKKE INDEHOLDT I d1pRE_base_KFnew
		#Private consumption
		  PARAMETER d1vCE_new[purpose,energy19,t]; d1vCE_new[purpose,energy19,t] = d1vCE[purpose,energy19,t];

		  $IF %calibKF23_consumers%==1:
			  #Opdaterer dummies 
			  d1qCE['heating','coal and coke',t]$(t.val > t1.val) = no;
	  	   	  d1vCE['heating','coal and coke',t]$(t.val > t1.val) = no;
			  qCE.l[purpose_xt,energy19,t]$(not d1qCE[purpose_xt,energy19,t]) = 0;

			  d1qCE['heating',energy19,t]$(t.val > t1.val and qCE.l['heating',energy19,t] = 0 and sum(eENS2GR$ene192eENS2GR(energy19, eENS2GR), KF25_energybalance_ENS_['Husholdninger',eENS2GR,'rumvarme',t])) = yes;

			  d1qCE['heating',energy19,t]$(t.val > t1.val and not sum(eENS2GR$ene192eENS2GR(energy19, eENS2GR), KF25_energybalance_ENS_['Husholdninger',eENS2GR,'rumvarme',t])) = no;
			  
			  d1vCE[purpose_xt,energy19,t]$(t.val > t1.val and d1qCE[purpose_xt,energy19,t] and not nonpricedenergy[energy19]) = yes;
			  d1vCE['process_special','firewood and woodchips',t] = no;

			  d1vCE[purpose_xt,energy19,t]$(t.val > t1.val and not d1qCE[purpose_xt,energy19,t] and not nonpricedenergy[energy19]) = no;
			  d1EAV_CE[purpose_xt,energy19,t]$(t.val > t1.val and not d1qCE[purpose_xt,energy19,t] and not nonpricedenergy[energy19]) = no;
			  d1DAV_CE[purpose_xt,energy19,t]$(t.val > t1.val and not d1qCE[purpose_xt,energy19,t] and not nonpricedenergy[energy19]) = no;
			  d1CAV_CE[purpose_xt,energy19,t]$(t.val > t1.val and not d1qCE[purpose_xt,energy19,t] and not nonpricedenergy[energy19]) = no;

			  d1vCE_new[purpose,energy19,t] = yes$(d1vCE[purpose,energy19,t] and not d1vCE_new[purpose,energy19,t]);

			  #Indfører ny skatterate på NOx
			  tNOx_CE.l[purpose,energy19,t]$(d1vCE_new[purpose,energy19,t] and tNOx_CEomregner[energy19]) = 1/tNOx_CEomregner[energy19];
			  vtNOx_CE.l[purpose,energy19,t] = tNOx_CE.l[purpose,energy19,t]; 

			  #Indfører og sletter energiforbrug
			  qCE.l['heating',energy19,t]$(t.val > t1.val and d1qCE['heating',energy19,t] and qCE.l['heating',energy19,t]=0) = sum(eENS2GR$ene192eENS2GR(energy19, eENS2GR), KF25_energybalance_ENS_['Husholdninger',eENS2GR,'rumvarme',t]);

			  pCE.l[purpose_xt,energy19,t]$(t.val > t1.val and d1vCE[purpose_xt,energy19,t] and pCE.l[purpose_xt,energy19,t]=0 and not nonpricedenergy[energy19]) = pEtot.l[energy19,t];
		
			  qCEPE.l['heating',t]$(t.val > t1.val and qCEPE.l['heating',t]=0) 			     = sum(energy19$(d1vCE['heating',energy19,t]), pCE.l['heating',energy19,t] * qCE.l['heating',energy19,t]);

			  sCEPE.l[purpose,t]$(t.val > tBF_calib_start.val and tBF_calib[t]) = qCEPE.l[purpose,t]/(sum(purposee, pCEPE.l[purposee,t]*qCEPE.l[purposee,t]));


			  sCE.l['heating',energy19,t]$(t.val > t1.val and d1vCE['heating',energy19,t])
	  		  	 = qCE.l['heating',energy19,t] * (pCEPE.l['heating',t]/pCE.l['heating',energy19,t]) ** (-eCE.l)/qCEPE.l['heating',t];

	 
			  d1vCE[purpose_xt,energy19,t]$(t.val > tBF_calib_End.val)   = d1vCE[purpose_xt,energy19,tBF_calib_End];
			  d1EAV_CE[purpose_xt,energy19,t]$(t.val > tBF_calib_End.val) = d1EAV_CE[purpose_xt,energy19,tBF_calib_end]; 
			  d1DAV_CE[purpose_xt,energy19,t]$(t.val > tBF_calib_End.val) = d1DAV_CE[purpose_xt,energy19,tBF_calib_end]; 
			  d1CAV_CE[purpose_xt,energy19,t]$(t.val > tBF_calib_End.val) = d1CAV_CE[purpose_xt,energy19,tBF_calib_end]; 

			  d1vCEPE[purpose,t] = yes$(sum(energy19, d1vCE[purpose,energy19,t]));
			$ENDIF

		#Inventories 
		  d1qLE[purpose,energy19,t]$(t.val > t1.val and not sum(eENS2GR$energy192eENS2GR(energy19,eENS2GR), KF_ANV_NatBal_[eENS2GR,'Lagertraek og statistisk difference',t]) and not bunkering[energy19] and not sameas[energy19,'Jet petroleum'] and not sameas[energy19,'semi-refined oil']) = no;
		  qLE.l[purpose,energy19,t]$(not d1qLE[purpose,energy19,t]) = 0;

		  d1vLE[purpose,energy19,t]$(t.val > t1.val and not sum(eENS2GR$energy192eENS2GR(energy19,eENS2GR), KF_ANV_NatBal_[eENS2GR,'Lagertraek og statistisk difference',t]) and not bunkering[energy19]  and not sameas[energy19,'Jet petroleum'] and not sameas[energy19,'semi-refined oil']) = no;
		  d1vLE[purpose,energy19,t]$(not d1qLE[purpose,energy19,t]) = no;


		#Imports 
		  d1qM_CET[energy19,'19000',t]$(t.val >t1.val and qM_CET.l[energy19,'19000',t] and not (sum(eENS2GR$energy192eENS2GR(energy19,eENS2GR), KF_TIL_NatBal_[eENS2GR,'import',t])) and not bunkering[energy19] and not eExcludeExportsGR[energy19]) = no; # and not notthese[energy19]) = no;
		  d1qM_CET[energy19,'19000',t]$(t.val > tBF_calib_End.val) = d1qM_CET[energy19,'19000',tBF_calib_End];
		  qM_CET.l[energy19,'19000',t]$(not d1qM_CET[energy19,'19000',t]) = 0;

		  d1vM_CET[energy19,'19000',t]$(t.val >t1.val and pM_CET.l[energy19,'19000',t] and not (sum(eENS2GR$energy192eENS2GR(energy19,eENS2GR), KF_TIL_NatBal_[eENS2GR,'import',t])) and not bunkering[energy19] and not eExcludeExportsGR[energy19]) = no;  #and not notthese[energy19]) = no;
		  d1vM_CET[energy19,'19000',t]$(t.val > tBF_calib_End.val) = d1vM_CET[energy19,'19000',tBF_calib_End];
		  pM_CET.l[energy19,'19000',t]$(not d1vM_CET[energy19,'19000',t]) = 0;

		#Exports 
		  d1qXE['unspecified',energy19,t]$(t.val > t1.val and qXE.l['unspecified',energy19,t] and not (sum(eENS2GR$energy192eENS2GR(energy19,eENS2GR), KF_ANV_NatBal_[eENS2GR,'eksport',t])) and not bunkering[energy19] and not eExcludeExportsGR[energy19]) = no;
		  d1qXE['unspecified',energy19,t]$(t.val > tBF_calib_end.val) = d1qXE['unspecified',energy19,tBF_calib_End];
		  qXE.l['unspecified',energy19,t]$(not d1qXE['unspecified',energy19,t]) = 0;

		  d1vXE['unspecified',energy19,t]$(t.val > t1.val and pXE.l['unspecified',energy19,t] and not (sum(eENS2GR$energy192eENS2GR(energy19,eENS2GR), KF_ANV_NatBal_[eENS2GR,'eksport',t])) and not bunkering[energy19] and not eExcludeExportsGR[energy19]) = no;
		  d1vXE['unspecified',energy19,t]$(t.val > tBF_calib_end.val) = d1vXE['unspecified',energy19,tBF_calib_End];
		  pXE.l['unspecified',energy19,t]$(not d1vXE['unspecified',energy19,t]) = 0;
		  #For chain-indeces prices are needed 
		  pXE.l['unspecified',energy19,t]$(d1vXE['unspecified',energy19,t+1] and not d1vXE['unspecified',energy19,t]) = pXE.l['unspecified',energy19,t+1]*fp; #Should be set to some value from a price forecast

  		  d1Xe_y[energy19,s,t] = yes$(d1vY_CET[energy19,s,t] and d1vXE['unspecified',energy19,t]);
  		  d1X_s[s,t] = yes$(d1x_y['xOth',s,t] or sum(energy19, d1xe_y[energy19,s,t]));
  	
	#TAXES 
		  d1EAFG_RE[purpose,energy19,r,t] = yes$((vtEAFG_RE.l[purpose,energy19,r,t] or vtEAFG_REmarg.l[purpose,energy19,r,t]) and d1qREgj[purpose,energy19,r,t]);
		  d1EAFG_CE[purpose,energy19,t]   = yes$(vtEAFG_CE.l[purpose,energy19,t] and d1qCE[purpose,energy19,t]);
		  d1EAFG_LE[purpose,energy19,t]   = yes$(vtEAFG_LE.l[purpose,energy19,t] and d1qLE[purpose,energy19,t]);

		  d1SO2_RE[purpose,energy19,r,t] = yes$(vtSO2_RE.l[purpose,energy19,r,t] and d1qREgj[purpose,energy19,r,t]);
		  d1SO2_CE[purpose,energy19,t]   = yes$(vtSO2_CE.l[purpose,energy19,t] and d1qCE[purpose,energy19,t]);
		  d1SO2_LE[purpose,energy19,t]   = yes$(vtSO2_LE.l[purpose,energy19,t] and d1qLE[purpose,energy19,t]);

		  d1PSO_RE[purpose,energy19,r,t] = yes$(vtPSO_RE.l[purpose,energy19,r,t] and d1qREgj[purpose,energy19,r,t]);
		  d1PSO_CE[purpose,energy19,t]	 = yes$(vtPSO_CE.l[purpose,energy19,t] and d1qCE[purpose,energy19,t]);
		  d1PSO_XE[purpose,energy19,t]   = yes$(vtPSO_XE.l[purpose,energy19,t] and d1qXE[purpose,energy19,t]);

		  d1NOx_RE[purpose,energy19,r,t] = yes$(vtNOx_RE.l[purpose,energy19,r,t] and d1qREgj[purpose,energy19,r,t]);
		  d1NOx_CE[purpose,energy19,t]	 = yes$(vtNOx_CE.l[purpose,energy19,t] and d1qCE[purpose,energy19,t]);


		  d1CO2_CE[purpose,energy19,t]   = yes$(vtCO2_CE.l[purpose,energy19,t] and d1qCE[purpose,energy19,t]);
		  d1CO2_LE[purpose,energy19,t]   = yes$(vtCO2_LE.l[purpose,energy19,t] and d1qLE[purpose,energy19,t]);

	     #	CO2
		    d1CO2_RE[purpose,energy19,r,t] = no; d1CO2_REmarg[purpose,energy19,r,t,emm_eq] = no; d1CO2_REmarg_sumemm[purpose,energy19,r,t] = no;


		    d1CO2_RE[purpose,energy19,r,tData]            = yes$(sum(emm_eq, tCO2_REmarg.l[purpose,energy19,r,tData,emm_eq]) or vtCO2_RE.l[purpose,energy19,r,tData]); #I data favner vi begge muligheder
		    d1CO2_REmarg[purpose,energy19,r,tData,emm_eq] = yes$(tCO2_REmarg.l[purpose,energy19,r,tData,emm_eq]);
		    d1CO2_REmarg_sumemm[purpose,energy19,r,tData] = yes$(sum(emm_eq, d1CO2_REmarg[purpose,energy19,r,tData,emm_eq]));

		    #After last data year
		    d1CO2_RE[purpose,energy19,r,tForecast]            = yes$(sum(emm_eq, tCO2_REmarg.l[purpose,energy19,r,tForecast,emm_eq]) and d1qREgj[purpose,energy19,r,tForecast]); #I data favner vi begge muligheder
		    d1CO2_REmarg[purpose,energy19,r,tForecast,emm_eq] = yes$(tCO2_REmarg.l[purpose,energy19,r,tForecast,emm_eq]);
		    d1CO2_REmarg_sumemm[purpose,energy19,r,tForecast] = yes$(sum(emm_eq, d1CO2_REmarg[purpose,energy19,r,tForecast,emm_eq]));


		  d1VAT_RE[purpose,energy19,r,t] = yes$(vtVAT_RE.l[purpose,energy19,r,t] and d1qREgj[purpose,energy19,r,t]);
		  d1VAT_CE[purpose,energy19,t]   = yes$(vtVAT_CE.l[purpose,energy19,t] and d1qCE[purpose,energy19,t]);
		  d1VAT_LE[purpose,energy19,t]   = yes$(vtVAT_LE.l[purpose,energy19,t] and d1qLE[purpose,energy19,t]);
		  #  d1VAT_XE[purpose,energy19,t]   = yes$(vtVAT_XE.l[purpose,energy19,t]);

		  d1tCE[purpose,energy19,t]   = yes$(d1vCE[purpose,energy19,t]    and (d1EAFG_CE[purpose,energy19,t] or d1SO2_CE[purpose,energy19,t] or d1PSO_CE[purpose,energy19,t] or d1NOx_CE[purpose,energy19,t] or d1CO2_CE[purpose,energy19,t] or d1VAT_CE[purpose,energy19,t]));
		  d1tLE[purpose,energy19,t]   = yes$(EN_vnLE[purpose,energy19,t]  and (d1EAFG_LE[purpose,energy19,t] or d1SO2_LE[purpose,energy19,t] or d1CO2_LE[purpose,energy19,t] or d1VAT_LE[purpose,energy19,t]));
		  #  d1tXE[purpose,energy19,t]   = yes$(EN_vnXE[purpose,energy19,t]    and (d1EAFG_XE[purpose,energy19,t] or d1SO2_XE[purpose,energy19,t] or d1PSO_XE[purpose,energy19,t] or d1CO2_XE[purpose,energy19,t] or d1VAT_XE[purpose,energy19,t]));

	#RETAIL AND WHOLESALE ENERG MARGINS 
		  d1EAV_RE[purpose,energy19,r,t] = yes$(vEAV_RE.l[purpose,energy19,r,t] and d1qREgj[purpose,energy19,r,t]);
		  d1DAV_RE[purpose,energy19,r,t] = yes$(vDAV_RE.l[purpose,energy19,r,t] and d1qREgj[purpose,energy19,r,t]);
		  d1CAV_RE[purpose,energy19,r,t] = yes$(vCAV_RE.l[purpose,energy19,r,t] and d1qREgj[purpose,energy19,r,t]);


		#Emissions
		  d1EmmProdE[s,t,emm_eq,purpose, energy19] = yes$(qEmmProdE.l[s,t,emm_eq,purpose, energy19] and included_gases(emm_eq) and d1qREgj[purpose,energy19,s,t]); 
		  qEmmProdE.l[s,t,emm_eq,purpose,energy19]$(not d1EmmProdE[s,t,emm_eq,purpose,energy19]) = 0;
		  qEmmProdE_ded.l[s,t,emm_eq,purpose,energy19]$(not d1EmmProdE[s,t,emm_eq,purpose,energy19]) = 0;
			qGrossEmmE.l[s,t,emm,purpose,energy19]$(not d1EmmProdE[s,t,emm,purpose,energy19]) = 0;
		  d1EmmProdE[s,t1,'CO2ubio',purpose, energy19]$(d1qREgj_KFnew[purpose,energy19,s,'2019']) = no;
		  d1EmmConsE[t, emm, purpose,energy19]     = yes$(qEmmConsE.l[t, emm, purpose, energy19] and included_gases(emm) and d1qCE[purpose,energy19,t]); 
		  d1EmmConsE[t, 'co2e', purpose,energy19]  = yes$(qEmmConsE.l[t, 'co2e', purpose, energy19] and d1qCE[purpose,energy19,t]);  
		  qEmmConsE.l[t,emm,purpose,energy19]$(not d1EmmConsE[t,emm,purpose,energy19]) = 0;
		  d1EmmProdS[s,t,emm_eq,accounts] = yes$(((d1EmmProdxE[s,t,emm_eq] or sum((purpose,energy19)$energy2accounts[energy19,accounts], d1EmmProdE[s,t,emm_eq,purpose,energy19]))
                                          and included_gases(emm_eq)) or sum((purpose,energy19), d1CCSbio[purpose,energy19,s,t,emm_eq]));

		  #Opdaterer bionaturgasandele og tilhørende dummies
			  sBioNatgas.l[purpose,s,t]$(not d1qREgj[purpose,'Natural gas incl. biongas',s,t]) = 0;
			  sBioNatGasC.l[purpose,t]$(not d1qCE[purpose,'Natural gas incl. biongas',t])      = 0;
				
			  d1sBioNatGasC[purpose,t]     =yes$(sBioNatGasC.l[purpose,t]=1  and d1EmmConsE[t,'CO2bio',purpose,'Natural gas incl. biongas']    and not d1EmmConsE[t,'CO2ubio',purpose,'Natural gas incl. biongas']);
			  d1sBioNatGasCzero[purpose,t] =yes$(sBioNatGasC.l[purpose,t]=0  and d1EmmConsE[t,'CO2ubio',purpose,'Natural gas incl. biongas']   and not d1EmmConsE[t,'CO2bio',purpose,'Natural gas incl. biongas']);
			  d1sBioNatGas[purpose,s,t]    =yes$(sBionatgas.l[purpose,s,t]=1 and d1EmmProdE[s,t,'CO2bio',purpose,'Natural gas incl. biongas']  and not d1EmmProdE[s,t,'CO2ubio',purpose,'Natural gas incl. biongas']);
			  d1sBioNatGaszero[purpose,s,t]=yes$(sBionatgas.l[purpose,s,t]=0 and d1EmmProdE[s,t,'CO2ubio',purpose,'Natural gas incl. biongas'] and not d1EmmProdE[s,t,'CO2bio',purpose,'Natural gas incl. biongas']);

		  # Update dummy on ETS quotas - important that this comes after updating emissions and CO2-tax dummies

			d1tCO2_ETS_marg[purpose,energy19,r,t]$(tx1[t] and (d1EmmProdE[r,t,'CO2ubio',purpose,energy19] or 
															  (d1EmmProdE[r,t,'CO2bio',purpose,energy19] and sameas[energy19,'Natural gas incl. biongas'])) and sameas[purpose,'in_ETS']) = yes;

			d1CO2_ETS[r,t]$(tx1[t]) = yes$(vtCO2_ETS.l[r,t] or sum(energy19, d1tCO2_ETS_marg['in_ETS',energy19,r,t]));



      d1CO2_ETS2_marg[purpose,energy19,r,t]   = no; d1CO2_ETS2[r,t] = no;
      d1CO2_ETS2_marg[purpose,energy19,r,t]$(tCO2_ETS2.l[t] and not sLan[r] 
                                                    and d1qREgj[purpose,energy19,r,t]
                                                    and not sameas[purpose,'in_ETS'] 
                                                    and (d1EmmProdE[r,t,'CO2ubio',purpose,energy19] or (d1EmmProdE[r,t,'CO2bio',purpose,energy19] and sameas[energy19,'Natural gas incl. biongas']))
                                                    and not sameas[energy19,'District heat']) = yes;

       d1CO2_ETS2[r,t]                         = yes$(sum((purpose,energy19),d1CO2_ETS2_marg[purpose,energy19,r,t]));

  	    	vtCO2_ETS2_marg.l[purpose,energy19,r,t]$(not d1CO2_ETS2_marg[purpose,energy19,r,t]) = 0;

		  #This needs to be updated after update of emissions 
		  d1tRE[purpose,energy19,r,t] = yes$(d1qREgj[purpose,energy19,r,t] and (d1EAFG_RE[purpose,energy19,r,t] or 
		  							         									d1SO2_RE[purpose,energy19,r,t]  or 
		  							         									d1PSO_RE[purpose,energy19,r,t]  or
		  							         									d1NOx_RE[purpose,energy19,r,t]  or
		  							         									d1CO2_RE[purpose,energy19,r,t]  or 
		  							         									d1VAT_RE[purpose,energy19,r,t]  or 
		  							         									d1tCO2_ETS_marg[purpose,energy19,r,t] or
		  							         									d1CO2_ETS2_marg[purpose,energy19,r,t])); 
        

		  # Update of d1pREa
			  d1pREa[purpose,energy19,r,t]$(tForecast[t]) = no;
	
			  d1pREgj[purpose,energy19,r,t] 	  = yes$(d1tRE[purpose,energy19,r,t] or d1pRE_base[purpose,energy19,r,t] or d1pREown[purpose,energy19,r,t]);
			  d1pREgj_KFnew[purpose,energy19,r,t] = yes$(d1pREgj[purpose,energy19,r,t] and not d1pREgj_KFnew[purpose,energy19,r,t]);
			  d1vREgj[purpose,energy19,r,t]		  = yes$(d1pREgj[purpose,energy19,r,t] and d1qREgj[purpose,energy19,r,t]);

			  d1pREa[purpose,energy19,r,t]$(tForecast[t] and (d1pRE_base[purpose,energy19,r,t] or d1tRE[purpose,energy19,r,t] or d1pREown[purpose,energy19,r,t])) = yes;
 			  d1pREa[purpose,'Biodiesel',s,t]$(tForecast[t] and  sENS2GR('vejtransport','vejtransport',purpose,'Diesel for transport',s)   and d1qREgj[purpose,'Biodiesel',s,t] and d1qREgj[purpose,'Diesel for transport',s,t])       = no;
   			  d1pREa[purpose,'Bioethanol',s,t]$(tForecast[t] and sENS2GR('vejtransport','vejtransport',purpose,'Gasoline for transport',s) and d1qREgj[purpose,'Bioethanol',s,t] and d1qREgj[purpose,'Gasoline for transport',s,t]) = no;

   			  d1pREa_KFnew[purpose,energy19,r,t] = yes$(d1pREa[purpose,energy19,r,t] and not d1pREa_KFnew[purpose,energy19,r,t]);

		  # Initialization of prices
		  	pREa.l[purpose,energy19,r,t]$(d1pREa_KFnew[purpose,energy19,r,t] or d1pREa_KFnew[purpose,energy19,r,t+1]) = 0.1; #This primarily aims at giving an initial price on waste, which is not a market good
		  	pREgj.l[purpose,energy19,s,t]$(d1pREgj_KFnew[purpose,energy19,s,t])      	= 0.1;
        	pRE_base.l[purpose,energy19,s,t]$(d1pRE_base_KFnew[purpose,energy19,s,t])   = 0.1;
        #  pRE_base_marg.l[energy19,t]$(d1pRE_base_KFnew[purpose,energy19,s,t]) = 0.1;

			  pREa.l[purpose,energy19,s,t]$(not (d1pREa[purpose,energy19,s,t] or d1pREa[purpose,energy19,s,t+1]))      		= 0;
			  pREgj.l[purpose,energy19,s,t]$(not (d1pREgj[purpose,energy19,s,t] or d1pREgj[purpose,energy19,s,t+1]))      	= 0;
			  pRE_base.l[purpose,energy19,s,t]$(not (d1pRE_base[purpose,energy19,s,t] or d1pRE_base[purpose,energy19,s,t+1])) 	= 0;
			  #  pRE_base_marg.l[energy19,t]$(not (d1pRE_base[purpose,energy19,s,t] or d1pRE_base[purpose,energy19,s,t+1])) 	= 0;



		  #d1EP is updated wrt. d1tRE
        PARAMETER d1EP_new[purpose,s,t], d1E_new[s,t], d1EP_out[purpose,s,t], d1E_out[s,t], d1Prod_new[prd,sp,t];  
        d1EP_new[purpose,s,t] = d1EP[purpose,s,t];
        d1EP_out[purpose,s,t] = d1EP[purpose,s,t];

		d1EP[purpose,s,t] = yes$(sum(energy19, d1pREa[purpose,energy19,s,t] and not eNotInEnergyNest[purpose,energy19,s,t])); 
        d1EP_new[purpose,s,t] = yes$(d1EP[purpose,s,t] and not d1EP_new[purpose,s,t]);
        d1EP_out[purpose,s,t] = yes$(d1EP_out[purpose,s,t] and not d1EP[purpose,s,t]);

        qEP.l[purpose,s,t]$(d1EP_new[purpose,s,t])    = sum(energy19$(d1pREa[purpose,energy19,s,t] and not eNotInEnergyNest[purpose,energy19,s,t]), pREa.l[purpose,energy19,s,t] * qREgj.l[purpose,energy19,s,t]);
        pEP.l[purpose,s,t]$(d1EP_new[purpose,s,t] or d1EP_new[purpose,s,t+1]) = 1; #For chain-indeces we need one lagged value 
	  	
	  		pEP.l[purpose,s,t]$(not (d1EP[purpose,s,t] or d1EP[purpose,s,t+1])) = 0; qEP.l[purpose,s,t]$(not d1EP[purpose,s,t]) = 0; uEP.l[purpose,sp,t]$(not d1EP[purpose,sp,t]) = 0; uEP_off.l[purpose,t]$(not d1EP[purpose,'off',t]) = 0;
                
        d1E_new[s,t] = yes$(sum(purpose,d1EP_new[purpose,s,t]));
        d1E_out[s,t] = yes$(sum(purpose,d1EP_out[purpose,s,t]));

        #d1prod opdateres for energi pba. af ovenstående
		  d1Prod_new[prd,sp,t]=no;
		  d1Prod_new['Eother',sp,t] = yes$(sum(purpose,d1EP_new[purpose,sp,t]));
	      # Total energy use and transport energy 
	      d1Etrans[s,t] = no;
		  d1Etrans[sp,t] = yes$(sum(purpose$(sameas[purpose,'transport'] or sameas[purpose,'intern_trans']), d1EP[purpose,sp,t]));

	      d1E[sp,t]      = no;

	      d1Prod['Etrans',sp,t]      = no;
	      d1Prod['Etrans',sp,t] = yes$(sum(purpose$(sameas[purpose,'transport'] or sameas[purpose,'intern_trans']), d1EP[purpose,sp,t]));
	      
	      d1Prod['EOther',sp,t]    = yes$(sum(purpose$(not (sameas[purpose,'transport'] or sameas[purpose,'intern_trans'])), d1EP[purpose,sp,t]));

		  pE_CGE.l[s,t]$(not ((d1E[s,t] or d1Etrans[s,t]) or (d1E[s,t+1] or d1Etrans[s,t+1]))) 	= 0; 
		  qE.l[s,t]$(not (d1E[s,t] or d1Etrans[s,t])) 		= 0; 


		  pProd.l['EOther',sp,t]$(not d1Prod['EOther',sp,t]) = 0;
		  qProd.l['EOther',sp,t]$(not d1Prod['EOther',sp,t]) = 0;
		  uProd.l['EOther',sp,t]$(not d1Prod['EOther',sp,t]) = 0; 

		  pProd.l['Etrans',sp,t]$(not d1Prod['Etrans',sp,t]) = 0;
		  qProd.l['Etrans',sp,t]$(not d1Prod['Etrans',sp,t]) = 0;
		  uProd.l['Etrans',sp,t]$(not d1Prod['Etrans',sp,t]) = 0; 


		  #  pProd.l['EOther',sp,t]$(not ((d1Prod['EOther',sp,t] or d1Prod['Etrans',sp,t]) or (d1Prod['EOther',sp,t+1] or d1Prod['Etrans',sp,t+1])))	= 0; 
		  #  qProd.l['EOther',sp,t]$(not (d1Prod['EOther',sp,t] or d1Prod['Etrans',sp,t])) 		= 0;
		  #  uProd.l['EOther', sp,t]$(not (d1Prod['EOther',sp,t] or d1Prod['Etrans',sp,t])) 	= 0;

          #The whole nest needs new CES-shares
          uEP.l[purpose,sp,t]$(d1Prod_new['Eother',sp,t]) = pEP.l[purpose,sp,t]*qEP.l[purpose,sp,t]/(sum(purposee, pEP.l[purposee,sp,t]*qEP.l[purposee,sp,t]));
          uEP_off.l[purpose,t]$(d1E_new['off',t]) = pEP.l[purpose,'off',t]*qEP.l[purpose,'off',t]/(sum(purposee, pEP.l[purposee,'off',t]*qEP.l[purposee,'off',t]));

		  uRE.l[purpose,energy19,s,t]$(d1pREa_KFnew[purpose,energy19,s,t] and not eNotInEnergyNest[purpose,energy19,s,t]) = qREa.l[purpose,energy19,s,t] * (pREa.l[purpose,energy19,s,t]/pEP.l[purpose,s,t]) ** (eRE.l[purpose,s]) / qEP.l[purpose,s,t];				


	      #Hvis branchen har brug af samme energivare indenfor andre formål tages gennemsnittet af distributør mark-up herfra
          fpRE.l[purpose,energy19,s,t]$(d1pRE_base_KFnew[purpose,energy19,s,t] and (sum((purposee)$(d1pRE_base[purposee,energy19,s,t] and not d1pRE_base_KFnew[purposee,energy19,s,t]), fpRE.l[purposee,energy19,s,t])<>0)) 
           	= sum((purposee)$(d1pRE_base[purposee,energy19,s,t] and not d1pRE_base_KFnew[purposee,energy19,s,t]), fpRE.l[purposee,energy19,s,t])/sum((purposee)$(d1pRE_base[purposee,energy19,s,t] and not d1pRE_base_KFnew[purposee,energy19,s,t]), 1);

	      #Hvis der ikke er noget indenfor branchen tages et gennemsnit af brancher og formål (man kunne måske argumentere for at det ville være mere korrekt bare at bruge et gennemsnit over brancher indenfor samme formål)
	      fpRE.l[purpose,energy19,s,t]$(d1pRE_base_KFnew[purpose,energy19,s,t] and (sum((purposee)$(d1pRE_base[purposee,energy19,s,t] and not d1pRE_base_KFnew[purposee,energy19,s,t]), fpRE.l[purposee,energy19,s,t])=0))
           	= sum((purposee,ss)$(d1pRE_base[purposee,energy19,ss,t] and not d1pRE_base_KFnew[purposee,energy19,ss,t]), fpRE.l[purposee,energy19,ss,t])/sum((purposee,ss)$(d1pRE_base[purposee,energy19,ss,t] and not d1pRE_base_KFnew[purposee,energy19,ss,t]), 1);
        
        
          #Svært at lave en god helgardering for det her tilfælde...
          fpRE.l['process_special','district heat','16000',t] = 0; #fpRE.l['heating','district heat','16000',t]; 

		  # Setting distributor mark-up to zero for deleted energy use
		  		fpRE.l[purpose,energy19,s,t]$(not d1pRE_base[purpose,energy19,s,t]) = no;

     	  #Engros- og detailavancer
     	      #Hvis branchen har brug af samme energivare indenfor andre formål tages gennemsnittet af distributør mark-up herfra
               	 fpEAV_RE.l[purpose,energy19,s,t]$(d1EAV_RE_KFnew[purpose,energy19,s,t] and d1pRE_base_KFnew[purpose,energy19,s,t] and (sum((purposee)$(d1pRE_base[purposee,energy19,s,t] and not d1pRE_base_KFnew[purposee,energy19,s,t]), fpEAV_RE.l[purposee,energy19,s,t])<>0)) 
               	 = sum((purposee)$(d1pRE_base[purposee,energy19,s,t] and not d1pRE_base_KFnew[purposee,energy19,s,t]), fpEAV_RE.l[purposee,energy19,s,t])/sum((purposee)$(d1pRE_base[purposee,energy19,s,t] and not d1pRE_base_KFnew[purposee,energy19,s,t]), 1);

     	      #Hvis der ikke er noget indenfor branchen tages et gennemsnit af brancher og formål (man kunne måske argumentere for at det ville være mere korrekt bare at bruge et gennemsnit over brancher indenfor samme formål)
     	     	 fpEAV_RE.l[purpose,energy19,s,t]$(d1EAV_RE_KFnew[purpose,energy19,s,t] and d1pRE_base_KFnew[purpose,energy19,s,t] and (sum((purposee)$(d1pRE_base[purposee,energy19,s,t] and not d1pRE_base_KFnew[purposee,energy19,s,t]), fpEAV_RE.l[purposee,energy19,s,t])=0))
               	 = sum((purposee,ss)$(d1pRE_base[purposee,energy19,ss,t] and not d1pRE_base_KFnew[purposee,energy19,ss,t]), fpEAV_RE.l[purposee,energy19,ss,t])/sum((purposee,ss)$(d1pRE_base[purposee,energy19,ss,t] and not d1pRE_base_KFnew[purposee,energy19,ss,t]), 1);

     	      #Hvis branchen har brug af samme energivare indenfor andre formål tages gennemsnittet af distributør mark-up herfra
               	 fpDAV_RE.l[purpose,energy19,s,t]$(d1DAV_RE_KFnew[purpose,energy19,s,t] and d1pRE_base_KFnew[purpose,energy19,s,t] and (sum((purposee)$(d1pRE_base[purposee,energy19,s,t] and not d1pRE_base_KFnew[purposee,energy19,s,t]), fpDAV_RE.l[purposee,energy19,s,t])<>0)) 
               	 = sum((purposee)$(d1pRE_base[purposee,energy19,s,t] and not d1pRE_base_KFnew[purposee,energy19,s,t]), fpDAV_RE.l[purposee,energy19,s,t])/sum((purposee)$(d1pRE_base[purposee,energy19,s,t] and not d1pRE_base_KFnew[purposee,energy19,s,t]), 1);

     	      #Hvis der ikke er noget indenfor branchen tages et gennemsnit af brancher og formål (man kunne måske argumentere for at det ville være mere korrekt bare at bruge et gennemsnit over brancher indenfor samme formål)
     	     	 fpDAV_RE.l[purpose,energy19,s,t]$(d1DAV_RE_KFnew[purpose,energy19,s,t] and d1pRE_base_KFnew[purpose,energy19,s,t] and (sum((purposee)$(d1pRE_base[purposee,energy19,s,t] and not d1pRE_base_KFnew[purposee,energy19,s,t]), fpDAV_RE.l[purposee,energy19,s,t])=0))
               	 = sum((purposee,ss)$(d1pRE_base[purposee,energy19,ss,t] and not d1pRE_base_KFnew[purposee,energy19,ss,t]), fpDAV_RE.l[purposee,energy19,ss,t])/sum((purposee,ss)$(d1pRE_base[purposee,energy19,ss,t] and not d1pRE_base_KFnew[purposee,energy19,ss,t]), 1);

     	      #Hvis branchen har brug af samme energivare indenfor andre formål tages gennemsnittet af distributør mark-up herfra
               	 fpCAV_RE.l[purpose,energy19,s,t]$(d1CAV_RE_KFnew[purpose,energy19,s,t] and d1pRE_base_KFnew[purpose,energy19,s,t] and (sum((purposee)$(d1pRE_base[purposee,energy19,s,t] and not d1pRE_base_KFnew[purposee,energy19,s,t]), fpCAV_RE.l[purposee,energy19,s,t])<>0)) 
               	 = sum((purposee)$(d1pRE_base[purposee,energy19,s,t] and not d1pRE_base_KFnew[purposee,energy19,s,t]), fpCAV_RE.l[purposee,energy19,s,t])/sum((purposee)$(d1pRE_base[purposee,energy19,s,t] and not d1pRE_base_KFnew[purposee,energy19,s,t]), 1);

     	      #Hvis der ikke er noget indenfor branchen tages et gennemsnit af brancher og formål (man kunne måske argumentere for at det ville være mere korrekt bare at bruge et gennemsnit over brancher indenfor samme formål)
     	     	 fpCAV_RE.l[purpose,energy19,s,t]$(d1CAV_RE_KFnew[purpose,energy19,s,t] and d1pRE_base_KFnew[purpose,energy19,s,t] and (sum((purposee)$(d1pRE_base[purposee,energy19,s,t] and not d1pRE_base_KFnew[purposee,energy19,s,t]), fpCAV_RE.l[purposee,energy19,s,t])=0))
               	 = sum((purposee,ss)$(d1pRE_base[purposee,energy19,ss,t] and not d1pRE_base_KFnew[purposee,energy19,ss,t]), fpCAV_RE.l[purposee,energy19,ss,t])/sum((purposee,ss)$(d1pRE_base[purposee,energy19,ss,t] and not d1pRE_base_KFnew[purposee,energy19,ss,t]), 1);

  		
			#Re-setter (men ikke i dataår)
			uREExID_transport.l[purpose,energy19a,energy19,s,t]$(tForecast[t] and uREExID_transport.l[purpose,energy19a,energy19,s,t]) = 0;

			uREExID_transport.l[purpose,'Gasoline for transport','Gasoline for transport',s,t]$(tForecast[t] and sENS2GR('vejtransport','vejtransport',purpose,'Gasoline for transport',s) 
                                                                          and ((qREgj.l[purpose,'Gasoline for transport',s,t] + qREgj.l[purpose,'Bioethanol',s,t])))
                                                                           = qREgj.l[purpose,'Gasoline for transport',s,t]/(qREgj.l[purpose,'Gasoline for transport',s,t] + qREgj.l[purpose,'Bioethanol',s,t]); 

			uREExID_transport.l[purpose,'Gasoline for transport','Bioethanol',s,t]$(tForecast[t] and sENS2GR('vejtransport','vejtransport',purpose,'Gasoline for transport',s) 
			                                                                          and ((qREgj.l[purpose,'Gasoline for transport',s,t] + qREgj.l[purpose,'Bioethanol',s,t]))) 
			                                                                          = 1 -uREExID_transport.l[purpose,'Gasoline for transport','Gasoline for transport',s,t];

			uREExID_transport.l[purpose,'Diesel for transport','Diesel for transport',s,t]$(tForecast[t] and sENS2GR('vejtransport','vejtransport',purpose,'Diesel for transport',s) 
			                                                                          and (qREgj.l[purpose,'Diesel for transport',s,t] + qREgj.l[purpose,'Biodiesel',s,t])) 
			                                                                            = qREgj.l[purpose,'Diesel for transport',s,t]/(qREgj.l[purpose,'Diesel for transport',s,t] + qREgj.l[purpose,'Biodiesel',s,t]);  

			uREExID_transport.l[purpose,'Diesel for transport','Biodiesel',s,t]$(tForecast[t] and sENS2GR('vejtransport','vejtransport',purpose,'Diesel for transport',s) 
			                                                                          and (qREgj.l[purpose,'Diesel for transport',s,t] + qREgj.l[purpose,'Biodiesel',s,t])) 
			                                                                          =  1- uREExID_transport.l[purpose,'Diesel for transport','Diesel for transport',s,t];

			d1qREE_transport[purpose,energy19a,energy19,s,t] = yes$(uREExID_transport.l[purpose,energy19a,energy19,s,t]);
			d1vREE_transport[purpose,energy19a,energy19,s,t] = yes$(d1qREE_transport[purpose,energy19a,energy19,s,t] and d1pREgj[purpose,energy19,s,t]);


			#  j_qREgj.l['Transport',energy19,s,t]$(not sum(energy19a,d1vREE_transport['transport',energy19a,energy19,s,t]) and d1qREgj['transport',energy19,s,t]) = 0;
			j_qREgj.l[purpose,energy19,s,t] = 0;

  		  #Abatement - this needs to come after update of d1tRE (d1pREown if updated)
			#  execute_unload 'output\pre.gdx';

	  		uEOPProdE.l[purpose,energy19,s,t,emm]$(tForecast[t]) 	 = 1$(qEmmProdE.l[s,t,emm,purpose,energy19]);
			d1qREE[purpose,energy19a,energy19,s,t]$(tForecast[t])    = no;		
			#  d1qREE[purpose,energy19a,energy19,s,t] = yes$(d1pREgj[purpose,energy19,s,t] and ((qREE.l[purpose,energy19a,energy19,s,t] and not sum(energy1919,d1vREE_transport[purpose,energy1919,energy19,s,t])) or sum(techID, d1thetaID[techID,purpose,energy19a,energy19,s,t])));
			
			uREExID.l[purpose,energy19a,energy19,s,t]$(tForecast[t]) = 1$(sameas[energy19,energy19a] and d1pREgj[purpose,energy19,s,t]);
			uREE.l[purpose,energy19a,energy19,s,t]$(tForecast[t])    = uREExID.l[purpose,energy19a,energy19,s,t];
			qREE.l[purpose,energy19a,energy19,s,t]$(tForecast[t])    = qREgj.l[purpose,energy19,s,t]$(sameas[energy19,energy19a] and d1pREgj[purpose,energy19,s,t]);
			
			d1qREE[purpose,energy19a,energy19,s,t]$(tForecast[t])    = yes$((qREE.l[purpose,energy19a,energy19,s,t] and not sum(energy1919,d1vREE_transport[purpose,energy1919,energy19,s,t])) or sum(techID, d1thetaID[techID,purpose,energy19a,energy19,s,t]));

#=============================================================================================================================================================================================#
# 2) Creation of new dummies and control sets
#=============================================================================================================================================================================================#

	#Dummies to control which price-levels we control in the calibration to KF
	PARAMETER d1pY_CET_overlap[out,s,t], d1pM_CET_overlap[out,s,t], d1qY_CET_overlap[out,s,t], d1qM_CET_overlap[out,s,t];
	d1pY_CET_overlap[energy19,s,t] = yes$(tx0[t] and KF25_pE_supply[energy19,t] and d1vY_CET[energy19,s,t]);
	d1pM_CET_overlap[energy19,s,t] = yes$(tx0[t] and KF25_pE_supply[energy19,t] and d1vM_CET[energy19,s,t]);
	d1qM_CET_overlap[energy19,s,t] = yes$(sum(eENS2GR,KF_TIL_NatBal_[eENS2GR,'import',t] and d1qM_CET[energy19,'19000',t] and energy192eENS2GR(energy19,eENS2GR) and not eExcludeExportsGR[energy19]));
	d1qY_CET_overlap[energy19,s,t] = yes$(sum((eENS2GR,sENS), d1qY_CET[energy19,s,t] and KF_TIL_NatBal_[eENS2GR,sENS,t] and not sameas[sENS,'import'] and e192s2sENS_IN(energy19,s,sENS) and energy192eENS2GR(energy19,eENS2GR) and not sameas[s,'38393']));

	#Sets to control which enregy-goods demanded we calibrate to KF. (Useful if there is calibration issues - i.e keep adding energy-goods to these sets until the module is square. In this way it can be deduced which energy good was causing the issue)
	set eExclGR(energy19)/set.Bunkering, 'LVN','semi-refined oil'/; #,'Coal and coke','Electricity','Renewable energy'/; #We do not adjust bunkering. LVN and semi-refined oil is not adjusted as it does not seem to be present in KF21
	@define_set_complement(eInclGR,energy19,eExclGR,'no');


	PARAMETER d1Xthese[purpose,energy19,s,t];
	d1Xthese[purpose,energy19,s,t] = no;

	#Sets to control what renewable energy goods we calibrate to KF
	set eRenewable(eENS2GR)/'Renewable energy','heat pumps','waste'/;
	set eRenewableGR(out)/'Renewable energy','heat pumps','waste'/;


	#Set to control which prices we calibrate to
	set ePrices(out)/set.energy19/;

	set bunkering_o[out]/set.Bunkering/;


	PARAMETER PhaseOut_j_ANV[eENS2GR,sENS];
	PhaseOut_j_ANV['Natural gas incl. biongas','Privat service inkl. soe-, jernbane-, og lufttransport'] = yes; #We need to specify that the difference between KF and GR on this particular item is phased out to avoid energy-use becoming negative in GR
	PhaseOut_j_ANV['Gas and diesel oil',sENS] = yes;
	PhaseOut_j_ANV['Biogas',sENS] = yes;

#=============================================================================================================================================================================================#
# 3) NEW VARIABLES
#=============================================================================================================================================================================================#

	$GROUP G_KF_calib #Various adjustment terms used in calibration
		adj_ENS[categoryENS,eENS2GR,GSR_ag,t] "Adjustment term"
		j_ENS[categoryENS,eENS2GR,GSR_ag,t] ""
		adj_Y_BF[eENS2GR,sENS,t] ""
		j_TIL_Y[eENS2GR,sENS,t] ""
		adj_EnergyPrices[energy19,eRamses,t] ""

		adj_BF[eENS2GR,sENS,t] "Adjustment term"
		j_ANV[eENS2GR,sENS,t] ""

		adj_Avance_RE[purpose,energy19,r,t] ""
 		adj_Avance_CE[purpose,energy19,t] ""
	;

	$GROUP G_KF_calib_endo G_KF_calib;

	$GROUP G_KF_calib_emmi
	 adj_uEmmxE[emm,sCRF,t] "Adjustment term in calibration to KF of non-energy emissions"
	;

	$GROUP G_KF_calib_emmi_endo G_KF_calib_emmi;

	PARAMETER lambda, xi, lambda_prices_elheat, lambda_prices; #Lambda and xi are parameters in [0,1] used to iterate towards a model that matches Klimafremskrivningen
	lambda = 0.00001; xi = 0; lambda_prices_elheat = 0; lambda_prices = 0;#Initial values of lambda and xi are set
	#  lambda = 1; xi = 1;


#=============================================================================================================================================================================================#
# 4) ACCOUNTING MODEL TO MATCH ENERGY IN KF
#=============================================================================================================================================================================================#



$BLOCK B_BF_ENERGY
	#=============================================================================================================================================================================================================================================================================#
	# DOMESTIC DEMAND ADJUSTMENT
	#=============================================================================================================================================================================================================================================================================#
	
		#This equation maps GreenREFORM energy-variables to Klimafremskrivningen
		E_KF_ANV_NatBal_[CategoryENS,eENS2GR,GSR_ag,t]$(tx0[t] and tBF_calib[t] and KF25_energybalance_ENS_[CategoryENS,eENS2GR,GSR_ag,t] and (sum((purpose,energy19,s)$(sENS2GR(categoryENS, GSR_ag, purpose, energy19, s) and ene192eENS2GR(energy19, eENS2GR)), d1qREgj[purpose,energy19,s,t]) or (sum((purpose,energy19)$(sENS2GR(categoryENS, GSR_ag, purpose, energy19, '68203') and ene192eENS2GR(energy19, eENS2GR)), d1qCE[purpose,energy19,t]))) and eInclENS[eENS2GR] and sIncl[CategoryENS] and purpIncl[GSR_ag])..
			     lambda * KF25_energybalance_ENS_[CategoryENS,eENS2GR,GSR_ag,t] 
			+ (1-lambda) * ( sum((energy19,purpose,s)$(sENS2GR(categoryENS, GSR_ag, purpose, energy19, s) and ene192eENS2GR(energy19, eENS2GR)), qREgj.l[purpose,energy19,s,t]$(d1qREgj[purpose,energy19,s,t]))
				   + sum((energy19,purpose_xt)$(sENS2GR(categoryENS, GSR_ag, purpose_xt, energy19, '68203') and ene192eENS2GR(energy19, eENS2GR)), qCE.l[purpose_xt,energy19,t]$(d1qCE[purpose_xt,energy19,t]))
				   + (sum(energy19$(ene192eENS2GR(energy19, eENS2GR)), qCE.l['transport',energy19,t]$(d1qCE['transport',energy19,t])))$(sameas[GSR_ag,'Vejtransport'] and sameas[CategoryENS,'Vejtransport'])) 

					=E=

					( sum((energy19,purpose,s)$(sENS2GR(categoryENS, GSR_ag, purpose, energy19, s) and ene192eENS2GR(energy19, eENS2GR)), qREgj[purpose,energy19,s,t]$(d1qREgj[purpose,energy19,s,t]))
				   + sum((energy19,purpose_xt)$(sENS2GR(categoryENS, GSR_ag, purpose_xt, energy19, '68203') and ene192eENS2GR(energy19, eENS2GR)), qCE[purpose_xt,energy19,t]$(d1qCE[purpose_xt,energy19,t]))
				   + (sum(energy19$(ene192eENS2GR(energy19, eENS2GR)), qCE['transport',energy19,t]$(d1qCE['transport',energy19,t])))$(sameas[GSR_ag,'Vejtransport'] and sameas[CategoryENS,'Vejtransport'])) 
				   + j_ENS[CategoryENS,eENS2GR,GSR_ag,t];

		#  The J-term captures whatever data-difference there is between GreenREFORM and KF. Setting the J-term to 0 in forecast years means that GreenREFORM will completely match the corresponding entry in Klimafremskrivningen.
		E_j_KF_ENS_[CategoryENS,eENS2GR,GSR_ag,t]$(tx0[t] and t.val > tBF_calib_Start.val and KF25_energybalance_ENS_[CategoryENS,eENS2GR,GSR_ag,t] and (sum((purpose,energy19,s)$(sENS2GR(categoryENS, GSR_ag, purpose, energy19, s) and ene192eENS2GR(energy19, eENS2GR)), d1qREgj[purpose,energy19,s,t]) or (sum((purpose,energy19)$(sENS2GR(categoryENS, GSR_ag, purpose, energy19, '68203') and ene192eENS2GR(energy19, eENS2GR)), d1qCE[purpose,energy19,t]))) and eInclENS[eENS2GR] and sIncl[CategoryENS] and purpIncl[GSR_ag])..
			j_ENS[CategoryENS,eENS2GR,GSR_ag,t] =E=  0*j_ENS[CategoryENS,eENS2GR,GSR_ag,t-1]; #We phase out j-term very quickly.

		#Energy-levels are adjusted proportionally by the factor adj_BF to hit KF. The adjustment-term is determined by the equation E_KF_ANV_NatBal_
		E_qREgj_ANV_[purpose,energy19,r,CategoryENS,eENS2GR,GSR_ag,t]$(tx0[t] and tBF_calib[t] and t.val > tBF_calib_Start.val and ene192eENS2GR(energy19, eENS2GR) and d1qREgj[purpose,energy19,r,t] and KF25_energybalance_ENS_[CategoryENS,eENS2GR,GSR_ag,t] and sENS2GR(categoryENS, GSR_ag, purpose, energy19, r) and eInclENS[eENS2GR] and sIncl[CategoryENS] and purpIncl[GSR_ag] and not sameas[r,'68203'])..
			qREgj[purpose,energy19,r,t] =E= qREgj.l[purpose,energy19,r,t] * adj_ENS[CategoryENS,eENS2GR,GSR_ag,t];

		#To provide the solver with better initial values after last KF year we extrapolate the adjusted energy-levels
		E_qREgj_ANV_forecast[purpose,energy19,r,CategoryENS,eENS2GR,GSR_ag,t]$(tx0[t] and t.val > tBF_calib_End.val and ene192eENS2GR(energy19, eENS2GR) and d1qREgj[purpose,energy19,r,t] and KF25_energybalance_ENS_[CategoryENS,eENS2GR,GSR_ag,t] and sENS2GR(categoryENS, GSR_ag, purpose, energy19, r)  and eInclENS[eENS2GR] and sIncl[CategoryENS] and purpIncl[GSR_ag] and not sameas[r,'68203'])..	
			qREgj[purpose,energy19,r,t] =E= (qREgj[purpose,energy19,r,t-1] * qREgj.l[purpose,energy19,r,t]/qREgj.l[purpose,energy19,r,t-1])$(qREgj.l[purpose,energy19,r,t-1]) + qREgj[purpose,energy19,r,t-1]$(not qREgj.l[purpose,energy19,r,t-1]);


		#Energy-levels are adjusted proportionally by the factor adj_BF to hit KF. The adjustment-term is determined by the equation E_KF_ANV_NatBal_
		E_qCE_ANV_[purpose_xt,energy19,GSR_ag,eENS2GR,t]$(tx0[t] and tBF_calib[t] and t.val > tBF_calib_Start.val and ene192eENS2GR(energy19, eENS2GR) and d1qCE[purpose_xt,energy19,t] and KF25_energybalance_ENS_['Husholdninger',eENS2GR,GSR_ag,t] and sENS2GR('husholdninger', GSR_ag, purpose_xt, energy19, '68203') and eInclENS[eENS2GR] and purpIncl[GSR_ag])..	 #and e192s2sens_use(energy19,purpose_xt,'68203','Husholdninger')
			qCE[purpose_xt,energy19,t] =E= qCE.l[purpose_xt,energy19,t] * adj_ENS['Husholdninger',eENS2GR,GSR_ag,t];

		#To provide the solver with better initial values after last KF year we extrapolate the adjusted energy-levels
		E_qCE_ANV_forecast[purpose_xt,energy19,GSR_ag,eENS2GR,t]$(tx0[t] and t.val > tBF_calib_End.val and ene192eENS2GR(energy19, eENS2GR) and d1qCE[purpose_xt,energy19,t] and KF25_energybalance_ENS_['Husholdninger',eENS2GR,GSR_ag,t] and sENS2GR('husholdninger', GSR_ag, purpose_xt, energy19, '68203') and eInclENS[eENS2GR] and purpIncl[GSR_ag]).. #e192s2sens_use(energy19,purpose_xt,'68203','Husholdninger') 
			qCE[purpose_xt,energy19,t] =E= qCE[purpose_xt,energy19,t-1] * qCE.l[purpose_xt,energy19,t]/qCE.l[purpose_xt,energy19,t-1];

		#Energy-levels are adjusted proportionally by the factor adj_BF to hit KF. The adjustment-term is determined by the equation E_KF_ANV_NatBal_
		E_qCE_ANV_trans[energy19,eENS2GR,t]$(tx0[t] and tBF_calib[t] and t.val > tBF_calib_Start.val and ene192eENS2GR(energy19, eENS2GR) and d1qCE['transport',energy19,t] and KF25_energybalance_ENS_['vejtransport',eENS2GR,'Vejtransport',t] and eInclENS[eENS2GR])..
			qCE['transport',energy19,t] =E= qCE.l['transport',energy19,t] * adj_ENS['vejtransport',eENS2GR,'vejtransport',t];

		#To provide the solver with better initial values after last KF year we extrapolate the adjusted energy-levels
		E_qCE_ANV_trans_forecast[energy19,eENS2GR,t]$(tx0[t] and t.val > tBF_calib_End.val and ene192eENS2GR(energy19, eENS2GR) and d1qCE['transport',energy19,t] and KF25_energybalance_ENS_['vejtransport',eENS2GR,'Vejtransport',t] and eInclENS[eENS2GR])..
			qCE['transport',energy19,t] =E= qCE['transport',energy19,t-1] * qCE.l['transport',energy19,t]/qCE.l['transport',energy19,t-1];


		#Special treatment of natural gas. Natural gas consumed in the gas distribution sector must per definition be equal to production, imports minus any transmission losses and own-use. 
		E_qRE_natgastodistribution[t]$(tx0[t] and tBF_calib[t] and t.val > tBF_calib_Start.val and d1qREgj['process_special','Natural gas (Extraction)','35002',t])..
			qREgj['process_special','Natural gas (Extraction)','35002',t] =E= qY_CET['Natural gas (Extraction)','0600a',t] + qM_CET['Natural gas (Extraction)','19000',t] - qTL['unspecified','Natural gas (Extraction)',t]; #- qREgj['in_ETS','Natural gas (Extraction)','35002',t]; 
				#  + j_ANV['Natural gas (Extraction)','Konverteringssektor',t];

		E_qRE_natgastodistribution_forecast[t]$(tx0[t] and t.val > tBF_calib_End.val and d1qREgj['process_special','Natural gas (Extraction)','35002',t])..	
			qREgj['process_special','Natural gas (Extraction)','35002',t] =E= qREgj['process_special','Natural gas (Extraction)','35002',tBF_calib_end];


		E_qRE_bionatgasdistribution[t]$(tx0[t] and tBF_calib[t] and t.val > tBF_calib_Start.val and d1qREgj['process_special','Biogas','35002',t])..
			qREgj['process_special','Biogas','35002',t] =E= KF25_energybalance_ENS_['Biogasopg','Biogas','Biogasopg',t];  # 	

		E_qRE_bionatgasdistribution_forecast[t]$(tx0[t] and t.val > tBF_calib_End.val and d1qREgj['process_special','Biogas','35002',t])..
			qREgj['process_special','Biogas','35002',t] =E= qREgj['process_special','Biogas','35002',tBF_calib_end];  # 	

		#elektricitet 
		E_qRE_elfromyandm[t]$(tx0[t] and tBF_calib[t] and t.val > tBF_calib_Start.val)..
			qREgj['process_special','El from y and m','35012',t] =E= qY_CET['El from y and m','35011',t] + qY_CET['El from y and m','38393',t] + qM_CET['El from y and m','19000',t];

		E_qRE_elfromyandm_forecast[t]$(tx0[t] and t.val > tBF_calib_End.val and d1qREgj['process_special','El from y and m','35012',t])..	
			qREgj['process_special','El from y and m','35012',t] =E= qREgj['process_special','El from y and m','35012',tBF_calib_end];

		#Iblandingskrav
		E_qREa_gasoline[r,t]$(tx0[t] and tBF_calib[t] and t.val > tBF_calib_start.val and sENS2GR('Vejtransport', 'Vejtransport', 'Transport', 'Gasoline for transport', r) and d1pREa['transport','gasoline for transport',r,t])..
			qREa['transport','gasoline for transport',r,t] =E= qREgj['transport','gasoline for transport',r,t] + qREgj['transport','bioethanol',r,t]$(d1qREgj['transport','bioethanol',r,t]);

		E_qREa_diesel[r,t]$(tx0[t] and tBF_calib[t] and t.val > tBF_calib_start.val   and sENS2GR('Vejtransport', 'Vejtransport', 'Transport', 'diesel for transport', r)   and d1pREa['transport','diesel for transport',r,t])..
			qREa['transport','diesel for transport',r,t] =E= qREgj['transport','diesel for transport',r,t] + qREgj['transport','biodiesel',r,t]$(d1qREgj['transport','biodiesel',r,t]);

		E_qREa_gasoline_or_diesel[energy19a,r,t]$(tx0[t] and t.val>tBF_calib_end.val and sENS2GR('Vejtransport', 'Vejtransport', 'Transport', energy19a, r) and d1pREa['transport',energy19a,r,t] and (sameas[energy19a,'gasoline for transport'] or sameas[energy19a,'diesel for transport']))..
			qREa['transport',energy19a,r,t] =E= qREa['transport',energy19a,r,tBF_calib_end];


		E_uREExID_transport_gasoline[r,t]$(tx0[t] and tBF_calib[t] and t.val > tBF_calib_start.val and sENS2GR('Vejtransport', 'Vejtransport', 'Transport', 'Gasoline for transport', r) and d1qREgj['transport','gasoline for transport',r,t])..
			uREExID_transport['transport','gasoline for transport','Gasoline for transport',r,t] =E= qREgj['transport','gasoline for transport',r,t]/(qREgj['transport','gasoline for transport',r,t] + qREgj['transport','bioethanol',r,t]$(d1qREgj['transport','Bioethanol',r,t]));

		E_uREExID_transport_bioethanol[r,t]$(tx0[t] and tBF_calib[t] and t.val > tBF_calib_start.val and sENS2GR('Vejtransport', 'Vejtransport', 'Transport', 'bioethanol', r) and d1qREgj['transport','bioethanol',r,t])..
			uREExID_transport['transport','gasoline for transport','bioethanol',r,t] =E= 1-uREExID_transport['transport','gasoline for transport','Gasoline for transport',r,t];


		E_uREExID_transport_diesel[r,t]$(tx0[t] and tBF_calib[t] and t.val > tBF_calib_start.val and sENS2GR('Vejtransport', 'Vejtransport', 'Transport', 'Diesel for transport', r) and d1qREgj['transport','Diesel for transport',r,t])..
			uREExID_transport['transport','Diesel for transport','Diesel for transport',r,t] =E= qREgj['transport','Diesel for transport',r,t]/(qREgj['transport','Diesel for transport',r,t] + qREgj['transport','Biodiesel',r,t]$(d1qREgj['transport','Biodiesel',r,t]));

		E_uREExID_transport_Biodiesel[r,t]$(tx0[t] and tBF_calib[t] and t.val > tBF_calib_start.val and sENS2GR('Vejtransport', 'Vejtransport', 'Transport', 'Biodiesel', r) and d1qREgj['transport','Biodiesel',r,t])..
			uREExID_transport['transport','Diesel for transport','Biodiesel',r,t] =E= 1-uREExID_transport['transport','Diesel for transport','Diesel for transport',r,t];

		E_uREExID_transport_forecast[purpose,energy19a,energy19,r,t]$(tx0[t] and t.val > tBF_calib_end.val and d1vREE_transport[purpose,energy19a,energy19,r,t])..
			uREExID_transport[purpose,energy19a,energy19,r,t] =E= uREExID_transport[purpose,energy19a,energy19,r,tBF_calib_End];




		E_j_ANV_natgas[t]$(tx0[t] and t.val >tBF_calib_Start.val)..
			j_ANV['Natural gas (Extraction)','Konverteringssektor',t] =E= j_ANV['Natural gas (Extraction)','Konverteringssektor',t-1];

	#INVENTORIES 
		E_KF_ANV_NatBal_inv[eENS2GR,t]$(tx0[t] and tBF_calib[t] and KF_ANV_NatBal_[eENS2GR,'Lagertraek og statistisk difference',t] and (sum(energy19$energy192eENS2GR(energy19,eENS2GR), sum(purpose, d1qLE[purpose,energy19,t]))) and eInclENS[eENS2GR])..
			KF_ANV_NatBal_[eENS2GR,'Lagertraek og statistisk difference',t] 
				=E= sum((purpose,energy19)$(d1qLE[purpose,energy19,t] and energy192eENS2GR(energy19,eENS2GR)), qLE[purpose,energy19,t]) + j_ANV[eENS2GR,'Lagertraek og statistisk difference',t];

		E_j_KF_ANV_NatBal_inv[eENS2GR,t]$(tx0[t] and tBF_calib[t] and t.val > tBF_calib_Start.val and KF_ANV_NatBal_[eENS2GR,'Lagertraek og statistisk difference',t] and (sum(energy19$energy192eENS2GR(energy19,eENS2GR), sum(purpose, d1qLE[purpose,energy19,t]))) and eInclENS[eENS2GR]).. 
			j_ANV[eENS2GR,'Lagertraek og statistisk difference',t] =E=   0* j_ANV[eENS2GR,'Lagertraek og statistisk difference',t-1]$(not sameas[eENS2GR,'Jet petroleum'])
																	+    0 * j_ANV[eENS2GR,'Lagertraek og statistisk difference',t-1]$(sameas[eENS2GR,'Jet petroleum']);

		E_qLE_ANV_[purpose,energy19,eENS2GR,t]$(tx0[t] and tBF_calib[t] and t.val > tBF_calib_Start.val and d1qLE[purpose,energy19,t] and KF_ANV_NatBal_[eENS2GR,'Lagertraek og statistisk difference',t] and energy192eENS2GR(energy19,eENS2GR) and eInclGR[energy19])..				 
				qLE[purpose,energy19,t] =E= qLE.l[purpose,energy19,t] + adj_BF[eENS2GR,'Lagertraek og statistisk difference',t];


		E_qLE_ANV_forecast[purpose,energy19,eENS2GR,t]$(tx0[t] and t.val > tBF_calib_End.val and d1qLE[purpose,energy19,t] and KF_ANV_NatBal_[eENS2GR,'Lagertraek og statistisk difference',t] and energy192eENS2GR(energy19,eENS2GR) and eInclGR[energy19])..				 
				qLE[purpose,energy19,t] =E= qLE[purpose,energy19,t-1];


	#TRANSMISSION LOSSES
		E_KF_ANV_NatBal_TL[eENS2GR,t]$(tx0[t] and tBF_calib[t] and KF_ANV_NatBal_[eENS2GR,'Distributionstab m.m.',t] and sum((purpose,energy19)$energy192eENS2GR(energy19,eENS2GR), d1TL[purpose,energy19,t]) and eInclENS[eENS2GR])..
			lambda * KF_ANV_NatBal_[eENS2GR,'Distributionstab m.m.',t]
		+(1-lambda)* sum(energy19$energy192eENS2GR(energy19,eENS2GR), qTL.l['unspecified',energy19,t]) 
				=E=
				sum(energy19$energy192eENS2GR(energy19,eENS2GR), qTL['unspecified',energy19,t]) + j_ANV[eENS2GR,'Distributionstab m.m.',t];

		E_j_ANV_TL[eENS2GR,t]$(tx0[t] and t.val > tBF_calib_Start.val and KF_ANV_NatBal_[eENS2GR,'Distributionstab m.m.',t] and sum((purpose,energy19)$energy192eENS2GR(energy19,eENS2GR), d1TL[purpose,energy19,t]) and eInclENS[eENS2GR])..
			j_ANV[eENS2GR,'Distributionstab m.m.',t] =E= 0.8*j_ANV[eENS2GR,'Distributionstab m.m.',t-1]$(not sameas[eENS2GR,'electricity'])
																									+ 0*j_ANV[eENS2GR,'Distributionstab m.m.',t-1]$(sameas[eENS2GR,'electricity']);
;

		E_qTL_anv[energy19,eENS2GR,t]$(tx0[t] and tBF_calib[t] and t.val > tBF_calib_start.val and d1TL['unspecified',energy19,t] and KF_ANV_NatBal_[eENS2GR,'Distributionstab m.m.',t]$(energy192eENS2GR(energy19,eENS2GR)) and eInclENS[eENS2GR])..
			qTL['unspecified',energy19,t] =E= qTL.l['unspecified',energy19,t] * adj_BF[eENS2GR,'Distributionstab m.m.',t];

		E_qTL_anv_forecast[energy19,eENS2GR,t]$(tx0[t] and t.val > tBF_calib_End.val and d1TL['unspecified',energy19,t] and KF_ANV_NatBal_[eENS2GR,'Distributionstab m.m.',t]$(energy192eENS2GR(energy19,eENS2GR)) and eInclENS[eENS2GR])..
			qTL['unspecified',energy19,t] =E= qTL['unspecified',energy19,t-1]; 

	#=============================================================================================================================================================================================================================================================================#
	# ADJUSTMENT OF INTERNATIONAL TRADE
	#=============================================================================================================================================================================================================================================================================#
		E_KF_ANV_NatBal_X[eENS2GR,t]$(tx0[t] and tBF_calib[t] and KF_ANV_NatBal_[eENS2GR,'eksport',t] and sum(energy19$energy192eENS2GR(energy19,eENS2GR), d1qXE['unspecified',energy19,t]) and not eExcludeExportsENS[eENS2GR])..
			(lambda * KF_ANV_NatBal_[eENS2GR,'eksport',t])$(not sameas[eENS2GR,'electricity'])
		+ (xi * KF_ANV_NatBal_[eENS2GR,'eksport',t])$(sameas[eENS2GR,'electricity']) 
		+ (1-lambda) * sum(energy19$(energy192eENS2GR(energy19,eENS2GR) and d1qXE['unspecified',energy19,t]), qXE.l['unspecified',energy19,t])$(not sameas[eENS2GR,'electricity'])
		+ (1-xi) * sum(energy19$(energy192eENS2GR(energy19,eENS2GR) and d1qXE['unspecified',energy19,t]), qXE.l['unspecified',energy19,t])$(sameas[eENS2GR,'electricity'])
				=E= sum(energy19$(energy192eENS2GR(energy19,eENS2GR) and d1qXE['unspecified',energy19,t]), qXE['unspecified',energy19,t]) + j_ANV[eENS2GR,'eksport',t];

		E_j_KF_ANV_NatBal_X[eENS2GR,t]$(tx0[t] and t.val > tBF_calib_Start.val and KF_ANV_NatBal_[eENS2GR,'eksport',t] and sum(energy19$energy192eENS2GR(energy19,eENS2GR), d1qXE['unspecified',energy19,t]) and not eExcludeExportsENS[eENS2GR])..
			j_ANV[eENS2GR,'eksport',t] =E=   0 *j_ANV[eENS2GR,'eksport',t-1]$(not (sameas[eENS2GR,'electricity'] or sameas[eENS2GR,'Crude oil and semi-refined oil']))
										   + 0* j_ANV[eENS2GR,'eksport',t-1]$(sameas[eENS2GR,'electricity'] or sameas[eENS2GR,'Crude oil and semi-refined oil']);

		E_qXE_[energy19,eENS2GR,t]$(tx0[t] and tBF_calib[t] and t.val > tBF_calib_Start.val and KF_ANV_NatBal_[eENS2GR,'eksport',t] and d1qXE['unspecified',energy19,t] and energy192eENS2GR(energy19,eENS2GR) and not eExcludeExportsGR[energy19])..
			qXE['unspecified',energy19,t] =E= qXE.l['unspecified',energy19,t] *adj_BF[eENS2GR,'eksport',t];

		E_qXE_forecast[energy19,eENS2GR,t]$(tx0[t] and t.val > tBF_calib_End.val and KF_ANV_NatBal_[eENS2GR,'eksport',t] and d1qXE['unspecified',energy19,t] and energy192eENS2GR(energy19,eENS2GR) and not eExcludeExportsGR[energy19])..
			qXE['unspecified',energy19,t] =E= qXE['unspecified',energy19,t-1];

		E_KF_TIL_NatBal_M[eENS2GR,t]$(tx0[t] and tBF_calib[t] and KF_TIL_NatBal_[eENS2GR,'import',t] and sum(energy19$energy192eENS2GR(energy19,eENS2GR), d1qM_CET[energy19,'19000',t]) and not eExcludeExportsENS[eENS2GR]).. #and not sameas[eENS2GR,'Natural gas (incl. city-gas)'])..
		      (lambda * KF_TIL_NatBal_[eENS2GR,'import',t])$(not sameas[eENS2GR,'El from y and m'])
		    + (xi * KF_TIL_NatBal_[eENS2GR,'import',t])$(sameas[eENS2GR,'El from y and m'])
		+ (1-lambda) * sum(energy19$energy192eENS2GR(energy19,eENS2GR), qM_CET.l[energy19,'19000',t]$(d1qM_CET[energy19,'19000',t]))$(not sameas[eENS2GR,'El from y and m'])
		+ (1-xi) *  sum(energy19$energy192eENS2GR(energy19,eENS2GR), qM_CET.l[energy19,'19000',t]$(d1qM_CET[energy19,'19000',t]))$(sameas[eENS2GR,'El from y and m']) 
				=E= sum(energy19$energy192eENS2GR(energy19,eENS2GR), qM_CET[energy19,'19000',t]$(d1qM_CET[energy19,'19000',t])) + j_TIL_Y[eENS2GR,'import',t]; 


		E_j_KF_TIL_NatBal_M[eENS2GR,t]$(tx0[t] and t.val > tBF_calib_Start.val and KF_TIL_NatBal_[eENS2GR,'import',t] and sum(energy19$energy192eENS2GR(energy19,eENS2GR), d1qM_CET[energy19,'19000',t]) and not eExcludeExportsENS[eENS2GR])..  #and not sameas[eENS2GR,'Natural gas (incl. city-gas)'])..
			j_TIL_Y[eENS2GR,'import',t] =E=   0 * j_TIL_Y[eENS2GR,'import',t-1]$(not sameas[eENS2GR,'Natural gas (Extraction)'])
											+ 0 * j_TIL_Y[eENS2GR,'import',t-1]$(sameas[eENS2GR,'Natural gas (Extraction)']);


		E_qM_M[energy19,eENS2GR,t]$(tx0[t] and tBF_calib[t] and t.val > tBF_calib_Start.val and KF_TIL_NatBal_[eENS2GR,'import',t] and d1qM_CET[energy19,'19000',t] and energy192eENS2GR(energy19,eENS2GR) and not eExcludeExportsGR[energy19]).. # and not sameas[eENS2GR,'Natural gas (incl. city-gas)'])..
			qM_CET[energy19,'19000',t] =E= qM_CET.l[energy19,'19000',t] * adj_Y_BF[eENS2GR,'import',t];

		E_qM_M_forecast[energy19,eENS2GR,t]$(tx0[t] and t.val > tBF_calib_End.val and KF_TIL_NatBal_[eENS2GR,'import',t] and d1qM_CET[energy19,'19000',t] and energy192eENS2GR(energy19,eENS2GR) and not eExcludeExportsGR[energy19]).. # and not sameas[eENS2GR,'Natural gas (incl. city-gas)'])..
			qM_CET[energy19,'19000',t] =E= qM_CET[energy19,'19000',t-1];

	#=============================================================================================================================================================================================================================================================================#
	# DOMESTIC SUPPLY ADJUSTMENT
	#=============================================================================================================================================================================================================================================================================#
	
	#DOMESTIC SUPPLY
		E_KF_TIL_NatBal_Y[eENS2GR,sENS,t]$(tx0[t] and tBF_calib[t] and KF_TIL_NatBal_[eENS2GR,sENS,t] and not sameas[sENS,'import'] and not sameas[sENS,'Graensehandel'] and sum(energy19$energy192eENS2GR(energy19,eENS2GR), sum(s$e192s2sENS_IN(energy19,s,sENS), d1qY_CET[energy19,s,t])))..
			lambda * KF_TIL_NatBal_[eENS2GR,sENS,t]
		+(1-lambda)*(sum(energy19$energy192eENS2GR(energy19,eENS2GR), sum(s$(e192s2sENS_IN(energy19,s,sENS) and d1qY_CET[energy19,s,t]), qY_CET.l[energy19,s,t]) + qCE.l['process_special','firewood and woodchips',t]$(d1qCE['process_special','firewood and woodchips',t] and sameas[energy19,'Firewood and woodchips'])))
				=E= sum(energy19$energy192eENS2GR(energy19,eENS2GR), sum(s$(e192s2sENS_IN(energy19,s,sENS) and d1qY_CET[energy19,s,t]),  qY_CET[energy19,s,t]) + qCE['process_special','firewood and woodchips',t]$(d1qCE['process_special','firewood and woodchips',t] and sameas[energy19,'Firewood and woodchips'])) + j_TIL_Y[eENS2GR,sENS,t];

	    KF_TIL_NatBal_Y_J[eENS2GR,sENS,t]$(tx0[t] and t.val > tBF_calib_start.val and KF_TIL_NatBal_[eENS2GR,sENS,t] and not sameas[sENS,'import'] and not sameas[sENS,'Graensehandel'] and sum(energy19$energy192eENS2GR(energy19,eENS2GR), sum(s$e192s2sENS_IN(energy19,s,sENS), d1qY_CET[energy19,s,t])))..
			j_TIL_Y[eENS2GR,sENS,t] =E= 0*j_TIL_Y[eENS2GR,sENS,t-1]$(not sameas[eENS2GR,'El from y and m'] and KF_TIL_NatBal_[eENS2GR,'energisektor',t])
									 #  + 0 *j_TIL_Y[eENS2GR,sENS,t-1]$(not sameas[eENS2GR,'el from y and m'] and KF_TIL_NatBal_[eENS2GR,'energisektor',t])
									 + 0 * j_TIL_Y[eENS2GR,sENS,t-1]$(not sameas[eENS2GR,'El from y and m'] and not KF_TIL_NatBal_[eENS2GR,'energisektor',t]) 
										#  + 0 * j_TIL_Y[eENS2GR,sENS,t-1]$(sameas[eENS2GR,'Oil products'])
									  + 0 * j_TIL_Y[eENS2GR,sENS,t-1]$(sameas[eENS2GR,'El from y and m']);


		E_qY_CET_BF[energy19,s,eENS2GR,sENS,t]$(tx0[t] and tBF_calib[t] and t.val > tBF_calib_Start.val and d1qY_CET[energy19,s,t] and KF_TIL_NatBal_[eENS2GR,sENS,t] and not sameas[sENS,'Graensehandel'] and not sameas[sENS,'import'] and e192s2sENS_IN(energy19,s,sENS) and energy192eENS2GR(energy19,eENS2GR) and not sameas[s,'38393'])..
			qY_CET[energy19,s,t] =E= qY_CET.l[energy19,s,t] * adj_Y_BF[eENS2GR,sENS,t];

		E_qY_CET_BF_forecast[energy19,s,eENS2GR,sENS,t]$(tx0[t] and t.val > tBF_calib_End.val and d1qY_CET[energy19,s,t] and KF_TIL_NatBal_[eENS2GR,sENS,t] and not sameas[sENS,'import'] and e192s2sENS_IN(energy19,s,sENS) and energy192eENS2GR(energy19,eENS2GR) and not sameas[s,'38393'])..
			qY_CET[energy19,s,t] =E= qY_CET[energy19,s,t-1];

	#RENEWABLE ENERGY 
		E_KF_TIL_NatBal_REN[eENS2GR,sENS,t]$(tx0[t] and tBF_calib[t] and KF_TIL_NatBal_[eENS2GR,sENS,t] and eRenewable[eENS2GR] and not sameas[sENS,'import'])..
			lambda * KF_TIL_NatBal_[eENS2GR,sENS,t]
		+(1-lambda) *sum(energy19$(energy192eENS2GR(energy19,eENS2GR) and eRenewableGR[energy19]), qRENEWABLE.l[energy19,t])
			 =E= sum(energy19$(energy192eENS2GR(energy19,eENS2GR) and eRenewableGR[energy19]), qRENEWABLE[energy19,t]) + j_TIL_Y[eENS2GR,sENS,t];

		E_j_TIL_REN[eENS2GR,sENS,t]$(tx0[t] and t.val > tBF_calib_Start.val and KF_TIL_NatBal_[eENS2GR,sENS,t] and eRenewable[eENS2GR] and not sameas[sENS,'import'])..
			j_TIL_Y[eENS2GR,sENS,t] =E= j_TIL_Y[eENS2GR,sENS,t-1];

		E_qRENEWABLE_REN[energy19,eENS2GR,sENS,t]$(tx0[t] and tBF_calib[t] and t.val > tBF_calib_Start.val and KF_TIL_NatBal_[eENS2GR,sENS,t] and not sameas[sENS,'import'] and eRenewable[eENS2GR] and d1RENEWABLE[energy19,t] and eRenewableGR[energy19] and energy192eENS2GR(energy19,eENS2GR))..
			qRENEWABLE[energy19,t] =E= qRENEWABLE.l[energy19,t]* adj_Y_BF[eENS2GR,sENS,t];

		E_qRENEWABLE_REN_forecast[energy19,eENS2GR,sENS,t]$(tx0[t] and t.val > tBF_calib_End.val and KF_TIL_NatBal_[eENS2GR,sENS,t] and not sameas[sENS,'import'] and eRenewable[eENS2GR] and d1RENEWABLE[energy19,t] and eRenewableGR[energy19] and energy192eENS2GR(energy19,eENS2GR))..
			qRENEWABLE[energy19,t] =E= qRENEWABLE[energy19,t-1];

		E_qRENEWABLE_other[energy19,t]$(tx1[t] and d1RENEWABLE[energy19,t] and not eRenewableGR[energy19])..
			qRENEWABLE[energy19,t] =E= qRENEWABLE[energy19,t-1];


	#=============================================================================================================================================================================================================================================================================#
	# ADJUSTMENT OF PRICES
	#=============================================================================================================================================================================================================================================================================#

		$IF %calibKF23_pricesXkraftvarme%:
		#Non energy-sector prices
		E_pY_CET_adj2BF[energy19,s,t]$(tx0[t] and tBF_calib_prices[t] and d1vY_CET[energy19,s,t] and KF25_pE_supply[energy19,t] and KF25_pE_supply_xPricesKraftvarme[energy19,t]and not sameas[s,'01012'] and not sameas[energy19,'firewood and woodchips'])..
			pY_CET[energy19,s,t] =E= KF25_pE_supply[energy19,t] * lambda_prices + (1-lambda_prices) * pY_CET.l[energy19,s,t];
									;

		E_pY_CET_adj2BF_firewood[energy19,s,t]$(tx0[t] and tBF_calib_prices[t] and d1vY_CET[energy19,s,t] and KF25_pE_supply[energy19,t] and KF25_pE_supply_xPricesKraftvarme[energy19,t] and not sameas[s,'01012'] and sameas[energy19,'firewood and woodchips'])..
			pY_CET[energy19,s,t]/pY_CET[energy19,s,t-1] =E= lambda_prices *	KF25_pE_supply[energy19,t]/KF25_pE_supply[energy19,t-1]+ (1-lambda_prices) * pY_CET.l[energy19,s,t]/pY_CET.l[energy19,s,t-1];
																

		#£zeroprofitagr - straw prices gain a large spread due to phasing out mark-ups. This causes problems with very low straw prices. To fix this we let straw price of organic straw follow convention (probably also much more realistic)
		E_pY_CET_adj2BF_organicstraw[energy19,t]$(tx0[t] and tBF_calib_prices[t] and d1vY_CET[energy19,'01012',t] and KF25_pE_supply[energy19,t] and KF25_pE_supply_xPricesKraftvarme[energy19,t])..
			pY_CET[energy19,'01012',t] =E= pY_CET[energy19,'01011',t];

		E_pY_CET_adj2BF_forecast[energy19,s,t]$(tx0[t] and t.val > tBF_calib_prices_end.val and d1vY_CET[energy19,s,t] and KF25_pE_supply[energy19,t] and KF25_pE_supply_xPricesKraftvarme[energy19,t])..
			pY_CET[energy19,s,t] =E= pY_CET[energy19,s,tBF_calib_prices_end];


		E_pM_CET_adj2BF[energy19,s,t]$(tx0[t] and tBF_calib_prices[t] and d1vM_CET[energy19,s,t] and KF25_pE_supply[energy19,t] and KF25_pE_supply_xPricesKraftvarme[energy19,t] and not sameas[energy19,'Firewood and woodchips'])..
			pM_CET[energy19,s,t] =E= lambda_prices * KF25_pE_supply[energy19,t] + (1-lambda_prices) * KF25_pE_supply[energy19,t];

									

		E_pM_CET_adj2BF_firewood[energy19,s,t]$(tx0[t] and tBF_calib_prices[t] and d1vM_CET[energy19,s,t] and KF25_pE_supply[energy19,t] and KF25_pE_supply_xPricesKraftvarme[energy19,t] and sameas[energy19,'Firewood and woodchips'])..
			pM_CET[energy19,s,t]/pM_CET[energy19,s,t-1] =E= lambda_prices * KF25_pE_supply[energy19,t]/KF25_pE_supply[energy19,t-1] + (1-lambda_prices) * pM_CET.l[energy19,s,t]/pM_CET.l[energy19,s,t-1];
																																			

		E_pM_CET_adj2BF_forecast[energy19,s,t]$(tx0[t] and t.val > tBF_calib_prices_end.val and d1vM_CET[energy19,s,t] and KF25_pE_supply[energy19,t] and KF25_pE_supply_xPricesKraftvarme[energy19,t])..
			pM_CET[energy19,s,t] =E= pM_CET[energy19,s,tBF_calib_prices_end];
		$ENDIF


		$IF %calibKF23_priceskraftvarme%:
		#Electricity and district heat
 		E_pM_CET_E[t]$(tx0[t] and tBF_calib_prices[t]).. pM_CET['El from y and m','19000',t] =E= 
										lambda_prices_elheat * (pM_CET['El from y and m','19000',t-1] + KF25_pE_supply['El from y and m',t] - KF25_pE_supply['El from y and m',t-1])
							    	+ (1-lambda_prices_elheat) * pM_CET.l['El from y and m','19000',t];



		E_pM_CET_E_forecast[t]$(tx0[t] and t.val > tBF_calib_prices_End.val).. pM_CET['El from y and m','19000',t] =E= pM_CET['El from y and m','19000',tBF_calib_prices_end];


		E_pY_CET_e[EH_sectors,t]$(tx0[t] and tBF_calib_prices[t]).. pY_CET['El from y and m',EH_sectors,t]    =E= 
																					 lambda_prices_elheat * KF25_pE_supply['El from y and m',t] + (1-lambda_prices_elheat) * pY_CET.l['El from y and m',EH_sectors,t];

		E_pY_CET_h[EH_sectors,t]$(tx0[t] and tBF_calib_prices[t]).. pY_CET['district heat',EH_sectors,t]  =E= lambda_prices_elheat * KF25_pE_supply['district heat',t] + (1-lambda_prices_elheat) * pY_CET.l['district heat',EH_sectors,t];	


		E_pY_CET_e_forecast[EH_sectors,t]$(tx0[t]  and t.val > tBF_calib_prices_end.val).. pY_CET['El from y and m',EH_sectors,t]   =E= pY_CET['El from y and m',EH_sectors,tBF_calib_prices_end]; 
		E_pY_CET_h_forecast[EH_sectors,t]$(tx0[t]  and t.val > tBF_calib_prices_end.val).. pY_CET['district heat',EH_sectors,t] =E= pY_CET['district heat',EH_sectors,tBF_calib_prices_end]; 



		#ELECTRICITY FOR DISTRIBUTION

		E_pXE_e[t]$(tx0[t] and tBF_calib_prices[t]).. pXE_base['unspecified','electricity',t]  =E= 
																								 lambda_prices_elheat  * (pXE_base['unspecified','electricity',t-1] + KF25_pE_supply['Electricity',t] - KF25_pE_supply['Electricity',t-1])
																							+ (1-lambda_prices_elheat) *  pXE_base.l['unspecified','electricity',t];


 		E_pXE_e_forecast[t]$(tx0[t] and t.val > tBF_calib_prices_end.val).. pXE_base['unspecified','electricity',t] =E= pXE_base['unspecified','electricity',tBF_calib_prices_end];


		E_pY_CET_e_dist[t]$(tx0[t] and tBF_calib_prices[t]).. 
			pY_CET['electricity','35012',t] =E= lambda_prices_elheat * KF25_pE_supply['electricity',t] + (1-lambda_prices_elheat) * pY_CET.l['electricity','35012',t];
												
																			 

		E_pY_CET_e_dist_forecast[t]$(tx0[t] and t.val>tBF_calib_prices_end.val)..pY_CET['electricity','35012',t]   =E= pY_CET['electricity','35012',tBF_calib_prices_end]; 
			
 		$ENDIF

	$ENDBLOCK


	$MODEL M_BF_ENERGY 
		B_BF_ENERGY
	;

	#We set up the groups of exogenous and endogenous variables for the accounting model
	$GROUP G_BF_ENERGY_exo 
		#DOMESTIC DEMAND
		qREgj$(d1qREgj[purpose,energy19,r,t])

		qCE$(d1qCE[purpose,energy19,t])

		qLE$(d1qLE[purpose,energy19,t])

			#BIO-FUELS IN GASOLINE AND DIESEL

		#PRODUCTION
		qY_CET$(d1qY_CET[out,s,t])

		#PRICES
		$IF %calibKF23_pricesXkraftvarme%:
		pY_CET$(tx0[t] and t.val < tBF_calib_prices_start.val and d1vY_CET[out,s,t])
		pM_CET$(tx0[t] and t.val < tBF_calib_prices_start.val and d1vM_CET[out,s,t])
		$ENDIF

		#ENERGY-MODULE PRICES
		$IF %calibKF23_priceskraftvarme%:
		pY_CET$(tx0[t] and t.val < tBF_calib_prices_Start.val and d1vY_CET[out,s,t] and (sameas[out,'El from y and m'] or sameas[out,'district heat']))
		pY_CET$(tx0[t] and t.val < tBF_calib_prices_Start.val and d1vY_CET[out,s,t] and sameas[out,'electricity'] )
		pM_CET$(tx0[t] and t.val < tBF_calib_prices_Start.val and d1vM_CET[out,s,t] and sameas[out,'El from y and m'])
		pXE_base$(tx0[t] and t.val < tBF_calib_prices_Start.val and d1vXE[purpose,energy19,t] and sameas[purpose,'unspecified'] and sameas[energy19,'electricity'])
		$ENDIF 

		#RENEWABLE ENERGY
		qRENEWABLE$(tx0[t] and t.val <= tBF_calib_Start.val and d1RENEWABLE[energy19,t] and eRenewableGR[energy19])
		qM_CET$(tx0[t] and t.val <= tBF_calib_Start.val and d1qM_CET[out,s,t] and sameas[s,'19000'])
		qXE$(tx0[t])
		qM_CET$(tx0[t])

		j_ANV$(tx0[t] and tBF_calib[t] and not(KF_ANV_NatBal_[eENS2GR,sENS,t])) 
		#  j_TIL_Y$(tx0[t] and tBF_calib[t] and not KF_TIL_NatBal_[eENS2GR,sENS,t])
		j_ENS$(tx0[t] and ((not KF25_energybalance_ENS_[CategoryENS,eENS2GR,GSR_ag,t]))) 

		qREgj$(tx0[t] and t.val > tBF_calib_Start.val and sameas[purpose,'in_ETS'] and sameas[energy19,'Natural gas (Extraction)'] and sameas[r,'35002'])
		-qREgj$(tx0[t] and t.val > tBF_calib_Start.val and sameas[purpose,'process_special'] and sameas[energy19,'Natural gas (Extraction)'] and sameas[r,'35002'])

	;

	$GROUP G_BF_ENERGY_endo 
			#DOMESTIC DEMAND
			qREgj$(tx0[t] and t.val > tBF_calib_Start.val and d1qREgj[purpose,energy19,r,t] and eInclGR[energy19] and not sameas[r,'68203']) # and d1RE_overlap[purpose,energy19,r,t])
			-qREgj$(tx0[t] and t.val > tBF_calib_Start.val and sameas[purpose,'in_ETS'] and sameas[energy19,'Natural gas (Extraction)'] and sameas[r,'35002'])
			qREgj$(tx0[t] and t.val > tBF_calib_Start.val and sameas[purpose,'process_special'] and sameas[energy19,'Natural gas (Extraction)'] and sameas[r,'35002'])
			qREgj$(tx0[t] and t.val > tBF_calib_Start.val and sameas[purpose,'process_special'] and sameas[energy19,'Biogas'] and sameas[r,'35002'])
			qREgj$(tx0[t] and t.val > tBF_calib_end.val and sameas[purpose,'transport'] and sameas[energy19,'jet petroleum'] and sameas[r,'51009'])
			qREgj$(tx0[t] and t.val > tBF_calib_end.val and sameas[purpose,'process_special'] and sameas[energy19,'el from y and m'] and sameas[r,'35012'])

				#BIO-FUELS IN GASOLINE AND DIESEL
				qREa$(tx0[t] and t.val>tBF_calib_start.val and sum(energy19, d1vREE_transport[purpose,energy19a,energy19,s,t]))
				uREExID_transport$(tx0[t] and t.val>tBF_calib_start.val and d1vREE_transport[purpose,energy19a,energy19,s,t])
		
			qCE$(tx0[t] and t.val > tBF_calib_Start.val and d1qCE[purpose,energy19,t] and sameas[purpose,'transport'] and eInclGR[energy19]) # and d1CE_overlap[purpose,energy19,t]
			qCE$(tx0[t] and t.val > tBF_calib_Start.val and d1qCE[purpose,energy19,t] and not sameas[purpose,'transport'] and eInclGR[energy19]) #and d1CE_overlap[purpose,energy19,t]

			#IMPORTS 
			qM_CET$(tx0[t] and t.val > tBF_calib_start.val and d1qM_CET_overlap[out,s,t] and not sameas[out,'Natural gas incl. biongas'] and not eExcludeExportsGR[out])
			qM_CET$(tx0[t] and t.val > tBF_calib_start.val and d1qM_CET_overlap[out,s,t] and sameas[out,'Natural gas (Extraction)'] and not eExcludeExportsGR[out])
			qM_CET$(tx0[t] and t.val > tBF_calib_Start.val and d1vM_CET[out,s,t] and sameas[out,'El from y and m'] and not eExcludeExportsGR[out])

			#EXPORTS 
			qXE$(tx0[t] and t.val > tBF_calib_Start.val and d1qXE[purpose,energy19,t] and sameas[purpose,'unspecified'] and not eExcludeExportsGR[energy19]) # and d1X_overlap[energy19,t]

			#PRODUCTION
			qY_CET$(tx0[t] and t.val >tBF_calib_start.val and d1qY_CET_overlap[out,s,t])

			#INVENTORIES 
			qLE$(tx0[t] and t.val > tBF_calib_Start.val and d1qLE[purpose,energy19,t] and eInclGR[Energy19]) # and d1LE_overlap[purpose,energy19,t])

			#TRANSMISSION LOSSES
			qTL$(tx1[t] and t.val > tBF_calib_Start.val and d1TL[purpose,energy19,t] and eInclGR[energy19])

			#PRICES 
			$IF %calibKF23_pricesXkraftvarme%:
			pY_CET$(tx0[t] and t.val >= tBF_calib_prices_start.val and d1vY_CET[out,s,t])
			pM_CET$(tx0[t] and t.val >= tBF_calib_prices_start.val and d1vM_CET[out,s,t])
			$ENDIF

			$IF %calibKF23_priceskraftvarme%:
			#Electricity and district heat
				pY_CET$(tx0[t] and t.val >= tBF_calib_prices_start.val and d1vY_CET[out,s,t] and (sameas[out,'El from y and m'] or sameas[out,'district heat']))
				pY_CET$(tx0[t] and t.val >= tBF_calib_prices_Start.val and d1vY_CET[out,s,t] and sameas[out,'electricity'] )

				pM_CET$(tx0[t] and t.val >= tBF_calib_prices_start.val and d1vM_CET[out,s,t] and sameas[out,'El from y and m'])

				pXE_base$(tx0[t] and t.val >= tBF_calib_prices_Start.val and d1vXE[purpose,energy19,t] and sameas[purpose,'unspecified'] and sameas[energy19,'electricity'])
			$ENDIF

			#RENEWABLE ENERGY 
			qRENEWABLE$(tx0[t] and t.val > tBF_calib_Start.val and eRenewableGR[energy19])
			qRENEWABLE$(tx1[t] and d1RENEWABLE[energy19,t] and not eRenewableGR[energy19])

			adj_BF
			adj_Y_BF
	;

	lambda = 1; xi = 1;

	# # The accounting model is solved

	#  $FIX G_BF_ENERGY_exo;
	#  $UNFIX G_BF_ENERGY_endo;
	#  execute_unload 'output\pre.gdx';
	#  @SOLVE(M_BF_ENERGY);
	#  execute_unload 'output\post.gdx';
	#  $exit

	#Seperate model for iblandingskrav -used in final calibration
	$MODEL M_iblandingskrav
		E_qREa_gasoline 
		E_qREa_diesel
		#  E_qREa_gasoline_or_diesel
		E_uREExID_transport_gasoline
		E_uREExID_transport_bioethanol
		E_uREExID_transport_diesel
		E_uREExID_transport_Biodiesel
		E_uREExID_transport_forecast
	;

	$GROUP G_iblandingskrav_exo 
		qREgj$(tx0[t] and tBF_calib[t] and d1qREgj[purpose,energy19,r,t] and sum(energy19a, d1vREE_transport[purpose,energy19a,energy19,r,t]))
	;

	$GROUP G_iblandingskrav_endo 
		qREa$(tx0[t] and tBF_calib[t] and t.val>tBF_calib_start.val and sum(energy19, d1vREE_transport[purpose,energy19a,energy19,s,t]))
		uREExID_transport$(tx0[t] and t.val > tBF_calib_start.val and d1vREE_transport[purpose,energy19a,energy19,s,t])
	;




	#Function to check that new energy-balance matches ENS-data
	$FUNCTION assert_no_difference_ENS_energy():
		#FIRSTLY WE CHECK DOMESTIC DEMAND (DOMESTIC SUPPLY BELOW)

		$OnMultiR
		set abc /diff,ENS,CGE/;
		PARAMETER Dowehit_KF25_energybalance_ENS_[abc,CategoryENS,eENS2GR,GSR_ag,t], ignorethesedimensions[CategoryENS,eENS2GR,GSR_ag,t];
		$OffMulti 
		Dowehit_KF25_energybalance_ENS_['ENS',CategoryENS,eENS2GR,GSR_ag,t]  =  KF25_energybalance_ENS_[CategoryENS,eENS2GR,GSR_ag,t];
		Dowehit_KF25_energybalance_ENS_['CGE',CategoryENS,eENS2GR,GSR_ag,t] = 					
							( sum((energy19,purpose,s)$(sENS2GR(categoryENS, GSR_ag, purpose, energy19, s) and ene192eENS2GR(energy19, eENS2GR)), qREgj.l[purpose,energy19,s,t]$(d1qREgj[purpose,energy19,s,t]))
						   + sum((energy19,purpose_xt)$(sENS2GR(categoryENS, GSR_ag, purpose_xt, energy19, '68203') and ene192eENS2GR(energy19, eENS2GR)), qCE.l[purpose_xt,energy19,t]$(d1qCE[purpose_xt,energy19,t]))
						   + (sum(energy19$(ene192eENS2GR(energy19, eENS2GR)), qCE.l['transport',energy19,t]$(d1qCE['transport',energy19,t])))$(sameas[CategoryENS,'Vejtransport'] and sameas[GSR_ag,'Vejtransport']));  

		#Some dimensions we deliberately ignore. Some of these, like ptx are future work
		ignorethesedimensions['Graensehandel','Gas and diesel oil','NotinGSR',t] = yes;
		ignorethesedimensions['Graensehandel','Biodiesel','NotinGSR',t] = yes;
		ignorethesedimensions['Graensehandel','Bioethanol','NotinGSR',t] = yes;
		ignorethesedimensions['Graensehandel','Biooil','NotinGSR',t] = yes;
		
		ignorethesedimensions['Biogasopg','Biogas','NotinGSR',t] = yes;
		ignorethesedimensions['Biogasopg','electricity','NotinGSR',t] = yes;
		ignorethesedimensions['Solceller','Renewable energy','NotinGSR',t] = yes;
		ignorethesedimensions['Vandkraftanlaeg','Renewable energy','NotinGSR',t] = yes;
		ignorethesedimensions['Vindmoeller','Renewable energy','NotinGSR',t] = yes;
		ignorethesedimensions['Oevrigtransport','gasoline and lvn','NotinGSR',t] = yes;
		ignorethesedimensions['Oevrigtransport','gas and diesel oil','NotinGSR',t] = yes;
		ignorethesedimensions['Oevrigtransport','gasoline and lvn','Oevrigtransport',t] = yes;
		ignorethesedimensions['Oevrigtransport','gas and diesel oil','Oevrigtransport',t] = yes;
		
		ignorethesedimensions['Vejtransport','Renewable energy','Vejtransport',t] = yes;
		ignorethesedimensions['Kraftvarme','refinery gas','raffinaderier',t] = yes;
		ignorethesedimensions['Husholdninger','Gasoline and lvn','notinGSR',t] = yes;
		ignorethesedimensions['Husholdninger','Oil products','notinGSR',t] = yes;
		ignorethesedimensions['Husholdninger','Natural gas incl. biongas','notinGSR',t] = yes;
		ignorethesedimensions['Husholdninger','Biodiesel','notinGSR',t] = yes;
		ignorethesedimensions['Husholdninger','Bioethanol','notinGSR',t] = yes;
		ignorethesedimensions['Husholdninger','Biooil','notinGSR',t] = yes;
		ignorethesedimensions['ptx','electricity','notinGSR',t] = yes;
		ignorethesedimensions['LandOgskov','electricity','LandOgSkov_diesel',t] = yes;
		Dowehit_KF25_energybalance_ENS_[abc,CategoryENS,eENS2GR,GSR_ag,t]$(ignorethesedimensions[CategoryENS,eENS2GR,GSR_ag,t])=0;

		PARAMETER tjek;
		LOOP((CategoryENS,eENS2GR,GSR_ag,t)$(not ignorethesedimensions[CategoryENS,eENS2GR,GSR_ag,t] and tBF_calib[t] and t.val > tBF_calib_start.val),
			tjek = Dowehit_KF25_energybalance_ENS_['diff',CategoryENS,eENS2GR,GSR_ag,t];
			ABORT$(abs(tjek) gt 1e-6) tjek, "Energy-input does not match ENS-data"
			);

		#CHECK OF DOMESTIC SUPPLY 
		$OnMultiR
		PARAMETER KF_TIL_Y[eENS2GR,t], KF_TIL_M[eENS2GR,t], GR_TIL_Y[eENS2GR,t], GR_TIL_M[eENS2GR,t], DIFF_TIL_Y[eENS2GR,t];
		$OffMulti
		KF_TIL_Y[eENS2GR,t]$(tBF_calib[t]) = KF_TIL_NatBal_[eENS2GR,'Primaer produktion',t] + KF_TIL_NatBal_[eENS2GR,'Energisektor',t] + KF_TIL_NatBal_[eENS2GR,'Konverteringssektor',t]; 
		KF_TIL_M[eENS2GR,t]$(tBF_calib[t]) = KF_TIL_NatBal_[eENS2GR,'import',t];

		GR_TIL_Y[eENS2GR,t]$(tBF_calib[t]) = sum((energy19,s)$(energy192eENS2GR(energy19,eENS2GR) and d1qY_CET[energy19,s,t]), qY_CET.l[energy19,s,t]); 
		GR_TIL_M[eENS2GR,t]$(tBF_calib[t]) = sum((energy19,s)$(energy192eENS2GR(energy19,eENS2GR) and d1qM_CET[energy19,s,t]), qM_CET.l[energy19,s,t]); 

		DIFF_TIL_Y[eENS2GR,t] = KF_TIL_Y[eENS2GR,t] - GR_TIL_Y[eENS2GR,t];
		execute_unload 'output\DIFF_TIL_Y.gdx';
		loop((eENS2GR,t)$(tBF_calib[t] and t.val >tBF_calib_start.val and (sameas[eENS2GR,'Oil products'] or sameas[eENS2GR,'Gas and diesel oil'] or sameas[eENS2GR,'Gasoline and LVN'] or sameas[eENS2GR,'Jet petroleum'])),
			tjek = KF_TIL_Y[eENS2GR,t] - GR_TIL_Y[eENS2GR,t];
			ABORT$(abs(tjek)>3) tjek, "Production in refineries do not match up closely enough with Climate Outlook";
			);
		$ENDFUNCTION 

		$FUNCTION compute_and_compare_emissions_KF({turnontest}):
		#TEST OF EMISSIONS BASED ON CRF-TABLES PUBLISHED WITH CLIMATE OUTLOOK
	   	$OnMultiR
			set itemss/GR,CRF,DIFF/;
			PARAMETER GreenREFORM_CRF[sCRF,emm_eq,t], jetfuelabroad[s,purpose,energy19];
	 		PARAMETER SammenlignCRF[itemss,sCRF,emm_eq,t], tolerateddiffCRF[sCRF,t], actualdiff[sCRF,t];
			$OffMulti

	
			jetfuelabroad['51009','Transport','Jet petroleum'] = yes;
		
			GreenREFORM_CRF[sCRF,emm_eq,t] = 0; 
	
	 	#Inserting elements that are not modelled 
			GreenREFORM_CRF[sCRF,emm,t]$(nonmappedCRFxE[sCRF] and GWP.l[emm]) = KF_emm_[emm,sCRF,t]*1000/GWP.l[emm];
			GreenREFORM_CRF[sCRF,'CO2e',t]$(nonmappedCRFxE[sCRF]) = sum(emm,GreenREFORM_CRF[sCRF,emm,t]*GWP.l[emm]);
	
	 	#1A and 1B: Energy-related emissions
	 		GreenREFORM_CRF[sCRF,'CO2e',t] = GreenREFORM_CRF[sCRF,'CO2e',t] 
	 								  + sum((emm,purpose,energy19,s)$(sum((categoryENS,GSR_ag),sCRF_2_sENS2GR_e(sCRF,categoryENS,GSR_ag,purpose,energy19,s)) and d1EmmProdE[s,t,emm,purpose,energy19] and not jetfuelabroad[s,purpose,energy19]), GWP.l[emm] * qEmmProdE.l[s,t,emm,purpose,energy19]);
	 	
		#Fra husholdninger 
	 		GreenREFORM_CRF['Residential','CO2e',t]    = GreenREFORM_CRF['Residential','CO2e',t] + sum((emm,purpose,energy19)$(d1EmmConse[t,emm,purpose,energy19] and not sameas[purpose,'transport']), GWP.l[emm] * qEmmConsE.l[t, emm, purpose, energy19]);
	
	 		GreenREFORM_CRF['Road transport','CO2e',t] = GreenREFORM_CRF['Road transport','CO2e',t] + sum((emm,purpose,energy19)$(d1EmmConse[t,emm,purpose,energy19] and sameas[purpose,'transport']), GWP.l[emm] * qEmmConsE.l[t, emm, purpose, energy19]);
	
	 	#IKke-energi i 2A-2H, samt 5A - 5E
	 		GreenREFORM_CRF[sCRF,'CO2e',t] = GreenREFORM_CRF[sCRF,'CO2e',t] + sum((s,emm)$(sCRF_2_sENS2GR_xE(sCRF,s,emm) and d1EmmProdxE[s,t,emm]), GWP.l[emm] * qEmmProdxE.l[s,t,emm])
	 		 															    + sum(emm$(sCRF_2_sENS2GR_xE(sCRF,'68203',emm) and d1emmconsxe[t,emm]), GWP.l[emm]*qEmmConsxE.l[t,emm]);
	
		
	 	#3A - 3I: Agriculture
	 		GreenREFORM_CRF['Enteric fermentation','CO2e',t] = sum((agri_sectors)$(d1EmmAgrxE['EntericFermentation',agri_sectors,t,'CO2e']), qEmmAgrxE.l['EntericFermentation',agri_sectors,t,'CO2e'])
	 														 +qEmmAgrAnimalsOther.l['EntericFermentation',t,'CO2e']$(d1EmmAgrAniOther['EntericFermentation',t,'CO2e'])
	 														;
	
	 		GreenREFORM_CRF['Manure management','CO2e',t]    = sum((agri_sectors)$(d1EmmAgrxE['ManureManagement',agri_sectors,t,'CO2e']), qEmmAgrxE.l['ManureManagement',agri_sectors,t,'CO2e'])
	 													    	+qEmmAgrAnimalsOther.l['ManureManagement',t,'CO2e']$(d1EmmAgrAniOther['ManureManagement',t,'CO2e'])
	 														;
	
	 		GreenREFORM_CRF['Agricultural soils','CO2e',t]   = sum((agri_sectors,emmtype)$(d1EmmAgrxE[emmtype,agri_sectors,t,'CO2e'] and not sameas[emmtype,'EntericFermentation'] and not sameas[emmtype,'ManureManagement']), qEmmAgrxE.l[emmtype,agri_sectors,t,'CO2e'])
	 														 + sum(emmtype$(not sameas[emmtype,'EntericFermentation'] and not sameas[emmtype,'ManureManagement']), qEmmAgrAnimalsOther.l[emmtype,t,'CO2e']$(d1EmmAgrAniOther[emmtype,t,'CO2e']))
	 														;
	
	 	#Border trade from road transport
	 	    GreenREFORM_CRF['Road transport - Bordertrade','CO2e',t] = qEmmBorderTrade.l[t,'CO2e'];
	
	 	#Domestic aviation
	 	    GreenREFORM_CRF['Domestic aviation','CO2e',t] = GreenREFORM_CRF['Domestic aviation','CO2e',t] + qEmmDomesticAviationDCE.l[t];
	
	 	#4A-4H: LULUCF
	 		GreenREFORM_CRF['Forest land','CO2e',t]             = qEmmLULUCF5.l['Forest',t];
	 		GreenREFORM_CRF['Cropland','CO2e',t]                = qEmmLULUCF5.l['Crop',t];
	 		GreenREFORM_CRF['Grassland','CO2e',t]               = qEmmLULUCF5.l['Grass',t];
	 		GreenREFORM_CRF['Wetlands','CO2e',t]                = qEmmLULUCF5.l['Wetland',t];
	 		GreenREFORM_CRF['Settlements','CO2e',t]             = qEmmLULUCF5.l['Settlement',t];
	 		GreenREFORM_CRF['Harvested wood products','CO2e',t] = qEmmHWP.l[t];

		#Residual to total 
			GreenREFORM_CRF['GR-residual to UNFCCC-LULUCF','CO2e',t] = jEmmTot_UNFCCC_LULUCF_Calib2KF.l[t];
	
		#Total 
			GreenREFORM_CRF['Total (UNFCCC-LULUCF)',emm_eq,t] = sum(sCRF, GreenREFORM_CRF[sCRF,emm_eq,t]);


		#Comparion with official CRF-tables
	 		SammenlignCRF['GR',sCRF,emm_eq,t]  = GreenREFORM_CRF[sCRF,emm_eq,t];
	 		SammenlignCRF['CRF',sCRF,emm_eq,t] = KF_EMM_[emm_eq,sCRF,t]*1000;
	 		SammenlignCRF['DIFF',sCRF,emm_eq,t]$(not sameas[sCRF,'GR-residual to UNFCCC-LULUCF']) = SammenlignCRF['GR',sCRF,emm_eq,t] - SammenlignCRF['CRF',sCRF,emm_eq,t];


	 	#Setting test-tolerance for known differences to CRF-table
	 		tolerateddiffCRF[sCRF,t] = 50;
	 		tolerateddiffCRF['Non-energy products from fuels and solvent use',t] = -100; #Exception 1 
	 		tolerateddiffCRF['Residential (mobile)',t] = -50;
	 		tolerateddiffCRF['Ag./for./fish. (mobile)',t] = -50; #
	 		tolerateddiffCRF['Domestic navigation',t] = -150; #Contains transport to Greenland and Faroe Islands in CRF-tables, but these are not (yet) in the model 
	 		tolerateddiffCRF['Other energy industries (oil/gas extraction)',t] = -75;
	 		tolerateddiffCRF['Combustion in manufacturing industry',t] = -65;
	 		tolerateddiffCRF['Domestic aviation',t] = -70;
	 		tolerateddiffCRF['Residential',t] = -60;
	 		tolerateddiffCRF['Manure management',t] = -150;
	 		tolerateddiffCRF['Agricultural soils',t] = -103;
	 		tolerateddiffCRF['Agricultural soils','2028'] = -221;
	 		tolerateddiffCRF['Agricultural soils','2029'] = -134;
	 		tolerateddiffCRF['Agricultural soils','2026'] = -120;
	 		tolerateddiffCRF['Road transport',t] = -60;
	 		tolerateddiffCRF['Agriculture, forestry and aquaculture',t] = -41;

			actualdiff[sCRF,t]$(abs(SammenlignCRF['DIFF',sCRF,'CO2e',t]) > abs(tolerateddiffCRF[sCRF,t])) = abs(SammenlignCRF['DIFF',sCRF,'CO2e',t]);
			execute_unload 'output\actualdiff.gdx', actualdiff, SammenlignCRF;

			$IF {turnontest}=='turnontest':
				LOOP((t,sCRF)$(t.val>=2025 and t.val<=tBF_calib_end.val),
					# ABORT$(abs(SammenlignCRF['DIFF',sCRF,'CO2e',t]) > abs(tolerateddiffCRF[sCRF,t])) 'Emissions in calibrated model are not close enough to official CRF-tables from Climate Outlook';
					);
			$ENDIF
	$ENDFUNCTION

#=============================================================================================================================================================================================#
# 5) Pre-model adjusting supply to energy demand
#=============================================================================================================================================================================================#


#=============================================================================================================================================================================================#
# 5) Pre-model calibrating supply of energy to deamand
#=============================================================================================================================================================================================#

#Total supply and demand of energy-goods will not necessarily be equal to one another after solving M_BF_ENERGY (though they should be close).
#We adjust energy-balances with a least-squares approach in an NLP. Only energy sold in a market in currently encompassed by the modelling)

	# $BLOCK B_adjust_supply_to_demand 
	# 	#We minimize squared relative distance to value set in above
	# 	E_min_obj.. obj =E= sum((energy19,s,t)$(t.val > tBF_calib_Start.val and d1vY_CET[energy19,s,t] and not bunkering[energy19] and tBF_calib[t] and not d1NonMarketEnergy[energy19,t]), sqr(qY_CET[energy19,s,t]/qY_CET.l[energy19,s,t]-1)) 
	# 			+ sum((energy19,s,t)$(tBF_calib[t] and t.val > tBF_calib_Start.val and d1vM_CET[energy19,s,t] and not bunkering[energy19] and not d1NonMarketEnergy[energy19,t] and qM_CET.l[energy19,s,t]), sqr(qM_CET[energy19,s,t]/qM_CET.l[energy19,s,t]-1));

	# 	#Constraint: Total demand = Total supply
	# 	E_BAL_notelfromyandm[energy19,t]$(tBF_calib[t] and t.val > tBF_calib_Start.val and not bunkering[energy19] and not d1NonMarketEnergy[energy19,t] and not sameas[energy19,'el from y and m']).. sum((purpose,r), qREgj.l[purpose,energy19,r,t]$(d1pRE_base[purpose,energy19,r,t]))   
	#                                      +  sum(purpose$d1vCE[purpose,energy19,t], qCE.l[purpose,energy19,t]) 
	#                                      +  sum(purpose$d1vLE[purpose,energy19,t], qLE.l[purpose,energy19,t])
	#                                      +  sum(purpose$d1vXE[purpose,energy19,t], qXE.l[purpose,energy19,t]) 
	#                                      +  sum(purpose$d1TL[purpose,energy19,t],  qTL.l[purpose,energy19,t]) =E= 
	#                                      	sum(s$(d1vY_CET[energy19,s,t]), qY_CET[energy19,s,t]) + sum(s$d1vM_CET[energy19,s,t], qM_CET[energy19,s,t]);

	#    E_BAL_elfromyandm[t]$(tBF_calib[t] and t.val > tBF_calib_start.val)..
	# 	 		qM_CET['el from y and m','19000',t] =E= qY_CET['electricity','35012',t] - qY_CET['el from y and m','35011',t] - qY_CET['el from y and m','38393',t];

	# 	 E_qREa_elfromyandm[t]$(tBF_calib[t] and t.val > tBF_calib_start.val)..
	# 	 		qREa['process_special','el from y and m','35012',t] =E= qY_CET['electricity','35012',t];

	# 	 E_qREgj_elfromyandm[t]$(tBF_calib[t] and t.val > tBF_calib_start.val)..
	# 	 		qREgj['process_special','el from y and m','35012',t] =E= qY_CET['electricity','35012',t];

	# $ENDBLOCK 

	$BLOCK B_adjust_supply_to_demand 
		#For imports the penalty is squared and for domestic production the penalty is squared twice, i.e. we would rather meet demand through imports than domestic production.
		E_min_obj.. obj =E= sum((energy19,s,t)$(t.val > tBF_calib_Start.val and d1vY_CET[energy19,s,t] and not bunkering[energy19] and not d1NonMarketEnergy[energy19,t]), sqr(sqr(qY_CET[energy19,s,t]/qY_CET.l[energy19,s,t]-1))) 
				+ sum((energy19,s,t)$(t.val > tBF_calib_Start.val and d1vM_CET[energy19,s,t] and not bunkering[energy19] and not d1NonMarketEnergy[energy19,t] and qM_CET.l[energy19,s,t]), sqr(qM_CET[energy19,s,t]/qM_CET.l[energy19,s,t]-1));

		#Constraint: Total demand = Total supply
		E_BAL_notelfromyandm[energy19,t]$(t.val > tBF_calib_Start.val and not bunkering[energy19] and not d1NonMarketEnergy[energy19,t] and not sameas[energy19,'el from y and m']).. sum((purpose,r), qREgj.l[purpose,energy19,r,t]$(d1pRE_base[purpose,energy19,r,t]))   
	                                     +  sum(purpose$d1vCE[purpose,energy19,t], qCE.l[purpose,energy19,t]) 
	                                     +  sum(purpose$d1vLE[purpose,energy19,t], qLE.l[purpose,energy19,t])
	                                     +  sum(purpose$d1vXE[purpose,energy19,t], qXE.l[purpose,energy19,t]) 
	                                     +  sum(purpose$d1TL[purpose,energy19,t],  qTL.l[purpose,energy19,t]) =E= 
	                                     	sum(s$(d1vY_CET[energy19,s,t]), qY_CET[energy19,s,t]) + sum(s$d1vM_CET[energy19,s,t], qM_CET[energy19,s,t]);

	   E_BAL_elfromyandm[t]$(t.val > tBF_calib_start.val)..
		 		qM_CET['el from y and m','19000',t] =E= qY_CET['electricity','35012',t] - qY_CET['el from y and m','35011',t] - qY_CET['el from y and m','38393',t];

		 E_qREa_elfromyandm[t]$(t.val > tBF_calib_start.val)..
		 		qREa['process_special','el from y and m','35012',t] =E= qY_CET['electricity','35012',t];

		 E_qREgj_elfromyandm[t]$(t.val > tBF_calib_start.val)..
		 		qREgj['process_special','el from y and m','35012',t] =E= qY_CET['electricity','35012',t];

	$ENDBLOCK 

	# $GROUP G_adjust_supply_to_demand_exo 
	# 	qY_CET$((d1qY_CET[out,s,t] and t.val > tBF_calib_End.val)) # or (d1qY_CET[out,s,t] and t1.val))
	# 	qM_CET$((d1qM_CET[out,s,t] and t.val > tBF_calib_end.val)) # or (d1qM_CET[out,s,t] and t1.val))
	# 	#  qY_CET$((d1vY_CET[out,s,t] and t.val > tBF_calib_start.val and tBF_calib[t] and sameas[out,'Jet petroleum']))
	# ;

	# $GROUP G_adjust_supply_to_demand_endo
	# 	qM_CET$((d1vM_CET[out,s,t] and t.val > tBF_calib_start.val and tBF_calib[t]))
	# 	qY_CET$((d1vY_CET[out,s,t] and t.val > tBF_calib_start.val and tBF_calib[t]) and sameas[out,'Semi-refined oil'])
	# 	qY_CET$((d1vY_CET[out,s,t] and t.val > tBF_calib_start.val and tBF_calib[t]) and sameas[out,'electricity'])
	# 	qREa$(d1pREa[purpose,energy19a,s,t] and sameas[purpose,'process_special'] and sameas[energy19a,'el from y and m'] and sameas[s,'35012'] and t.val > tBF_calib_start.val and tBF_calib[t])
	# 	qREgj$(d1qREgj[purpose,energy19,r,t] and sameas[purpose,'process_special'] and sameas[energy19,'el from y and m'] and sameas[r,'35012'] and t.val > tBF_calib_start.val and tBF_calib[t])
	# ;

	$GROUP G_adjust_supply_to_demand_exo 
		qY_CET$((d1qY_CET[out,s,t] and t.val > tBF_calib_start.val)) # or (d1qY_CET[out,s,t] and t1.val))
		qM_CET$((d1qM_CET[out,s,t] and t.val > tBF_calib_start.val)) # or (d1qM_CET[out,s,t] and t1.val))
		#  qY_CET$((d1vY_CET[out,s,t] and t.val > tBF_calib_start.val and tBF_calib[t] and sameas[out,'Jet petroleum']))
	;

	$GROUP G_adjust_supply_to_demand_endo
		qM_CET$((d1vM_CET[out,s,t] and t.val > tBF_calib_start.val))  
		qY_CET$((d1vY_CET[out,s,t] and t.val > tBF_calib_start.val)) 
		qREa$(d1pREa[purpose,energy19a,s,t] and sameas[purpose,'process_special'] and sameas[energy19a,'el from y and m'] and sameas[s,'35012'] and t.val > tBF_calib_start.val)
		qREgj$(d1qREgj[purpose,energy19,r,t] and sameas[purpose,'process_special'] and sameas[energy19,'el from y and m'] and sameas[r,'35012'] and t.val > tBF_calib_start.val)

	;


	$FIX G_adjust_supply_to_demand_exo;
	$UNFIX(0.01,inf) G_adjust_supply_to_demand_endo;
	$MODEL M_adjust_supply_to_demand 
		B_adjust_supply_to_demand
	;

		# execute_unload 'output\pre_adjust_supply_to_demand.gdx';
	#  SOLVE M_adjust_supply_to_demand using NLP minimizing obj;


	qREa.l[purpose,energy19,s,t] = qREgj.l[purpose,energy19,s,t];
	qEtot.l[energy19,t]$(not d1NonMarketEnergy[energy19,t]) =sum((purpose,r), qREgj.l[purpose,energy19,r,t]$(d1pRE_base[purpose,energy19,r,t]))   
	                                  +  sum(purpose$d1vCE[purpose,energy19,t], qCE.l[purpose,energy19,t]) 
	                                  +  sum(purpose$d1vLE[purpose,energy19,t], qLE.l[purpose,energy19,t])
	                                  +  sum(purpose$d1vXE[purpose,energy19,t], qXE.l[purpose,energy19,t]) 
	                                  +  sum(purpose$d1TL[purpose,energy19,t],  qTL.l[purpose,energy19,t]);

#=============================================================================================================================================================================================#
# 6) ADDITIONAL CALIBRATION EQUATIONS
#=============================================================================================================================================================================================#

	#-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
	# ENERGY-RELATED EQUATIONS
	#-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

	#The equations below are used to calibrate the model to KF
	$BLOCK B_CALIB_2_KF 

	   #PRODUKTION
	   		#Re-calibration of distributors portfolio shares. KF dictates energy-production and we force the model to hit these production-levels through the portfolio-shares of the distributor
		    E_qAGG_y_calib[energy19,s,t]$(tx0[t] and tBF_calib[t] and d1vY_CET[energy19,s,t] and not d1vE_onesupplier[energy19,t]).. 
		      sY_AGG[energy19,s,t] =E= qY_CET[energy19,s,t]/qEtot[energy19,t] * pY_CET[energy19,s,t]**eAGG(energy19);

		    E_qAGG_m_calib[energy19,s,t]$(tx0[t]  and tBF_calib[t] and d1vM_CET[energy19,s,t] and not d1vE_onesupplier[energy19,t])..  
		      sM_AGG[energy19,s,t] =E= qM_CET[energy19,s,t]/qEtot[energy19,t] * pM_CET[energy19,s,t]**eAGG(energy19);

		    
		    E_sY_AGG_forecast[energy19,s,t]$(tx0[t] and t.val > tBF_calib_End.val and d1vY_CET[energy19,s,t] and not d1vE_onesupplier[energy19,t]).. 
		      sY_AGG[energy19,s,t] =E= sY_AGG[energy19,s,tBF_calib_End];

		  	E_sM_AGG_forecast[energy19,s,t]$(tx0[t] and t.val > tBF_calib_End.val and d1vM_CET[energy19,s,t] and not d1vE_onesupplier[energy19,t]).. 
		      sM_AGG[energy19,s,t] =E= sM_AGG[energy19,s,tBF_calib_End];


		    #Special treatment of semi-refined oil and LVN. 
		    E_sY_AGG_LVN_SEMIREFINEDOIL_forecast[energy19,s,t]$(tx0[t] and t.val > tBF_calib_End.val and d1vY_CET[energy19,s,t] and (sameas[energy19,'LVN'] or sameas[energy19,'semi-refined oil']))..
		      sY_AGG[energy19,s,t] =E= sY_AGG[energy19,s,tBF_calib_End];


		    #Given portfolio shares extrapolated flat after 2030 the distributor chooses energy-demand according to the usual equations (below) 
		    E_qY_CET_energy19_forecast[energy19,s,t]$(tx0[t] and t.val > tBF_calib_End.val and d1vY_CET[energy19,s,t] and not d1vE_onesupplier[energy19,t])..      qY_CET[energy19,s,t] * (sum(ss$d1vY_CET[energy19,ss,t], sY_AGG[energy19,ss,t] * pY_CET[energy19,ss,t] ** (-eAGG[energy19])) + sum(ss$d1vM_CET[energy19,ss,t], sM_AGG[energy19,ss,t] * pM_CET[energy19,ss,t]**(-eAGG[energy19]))) 
		                                                               =E= sY_AGG[energy19,s,t] * pY_CET[energy19,s,t] **(-eAGG[energy19]) * qEtot[energy19,t];
		    
			E_qM_CET_energy19_forecast[energy19,s,t]$(tx0[t] and t.val > tBF_calib_End.val and d1vM_CET[energy19,s,t] and not d1vE_onesupplier[energy19,t])..      qM_CET[energy19,s,t]*(sum(ss$d1vY_CET[energy19,ss,t], sY_AGG[energy19,ss,t] * pY_CET[energy19,ss,t] ** (-eAGG[energy19])) + sum(ss$d1vM_CET[energy19,ss,t], sM_AGG[energy19,ss,t] * pM_CET[energy19,ss,t]**(-eAGG[energy19]))) 
		                                                               =E= sM_AGG[energy19,s,t] * pM_CET[energy19,s,t] **(-eAGG[energy19]) * qEtot[energy19,t];


		    E_qY_CET_Naturalgasinclbiongas[t]$(tx0[t] and tBF_calib[t])..
		    	qY_CET['Natural gas incl. biongas','35002',t] =E= qEtot['Natural gas incl. biongas',t]; 

		    #For one-supplier markets the market-clearing condition is re-introduced for forecast years
		    E_qAGG_onesupplier_forecast[energy19,t]$(tx0[t] and t.val > tBF_calib_End.val and d1pEtot[energy19,t] and d1vE_onesupplier[energy19,t] and not bunkering[energy19]).. 
		    	qEtot[energy19,t] =E= sum(s$d1vY_CET[energy19,s,t], qY_CET[energy19,s,t]) + sum(s$d1vM_CET[energy19,s,t], qM_CET[energy19,s,t]);

		    #Bunkering is allowed to be chosen freely in all years as it is not part of KF
		    E_qAGG_onesupplier_bunkering[energy19,t]$(tx0[t] and d1pEtot[energy19,t] and d1vE_onesupplier[energy19,t] and bunkering[energy19]).. 
		    	qEtot[energy19,t] =E= sum(s$d1vY_CET[energy19,s,t], qY_CET[energy19,s,t]) + sum(s$d1vM_CET[energy19,s,t], qM_CET[energy19,s,t]);

		#WASTE PRODUCTION 
			E_jqRENEWABLEWaste[t]$(tx0[t] and t.val > tBF_calib_end.val)..
				jqRENEWABLEWaste[t] =E= jqRENEWABLEWaste[tBF_calib_End];

		#PRICES 
			$IF %calibKF23_pricesXkraftvarme%:
			#Mark-ups are adjusted to hit the price paths of Ramsesdata. After 2030 mark-ups are extrapolated flat
			E_markup_forecast[energy19,s,t]$(tx0[t] and t.val > tBF_calib_prices_End.val and d1vY_CET[energy19,s,t] 
																and d1pY_CET_overlap[energy19,s,t] 
																and not sameas[energy19,'Straw for energy purposes'] 
																and not sameas[s,'0600a']
																and not (sameas[energy19,'Diesel for transport'] or sameas[energy19,'Gasoline for transport'] or sameas[energy19,'Oil products'] or sameas[energy19,'jet petroleum'] or sameas[energy19,'Semi-refined oil'] or sameas[energy19,'Biodiesel'])
																and not sameas[energy19,'electricity']
																and not sameas[energy19,'el from y and m']
																and not sameas[energy19,'district heat']).. # and not sameas[energy19,'Electricity'])..
				markup[energy19,s,t] =E= markup[energy19,s,tBF_calib_prices_end];


			E_uPlant_CET_straw[Plant_sectors,t]$(tx0[t] and t.val > tBF_calib_prices_end.val and d1Plant_CET0[plant_sectors,'EnergyStraw',t])..
				uPlant_CET[plant_sectors,'EnergyStraw',t] =E= uPlant_CET[plant_sectors,'EnergyStraw',tBF_calib_prices_end]; 
			$ENDIF 

			E_markup_forecast_ElHeat[energy19,s,t]$(tx0[t] and t.val > tBF_calib_prices_End.val and d1vY_CET[energy19,s,t] and (sameas[energy19,'electricity'] or sameas[energy19,'district heat'] or sameas[energy19,'el from y and m']))..
				markup[energy19,s,t] =E= markup[energy19,s,tBF_calib_prices_end];
			
			#Import prices are adjusted to hit the price paths of Ramsesdata. After 2030 the import-prices are extrapolated flat
			E_pM_CET_forecast[energy19,s,t]$(tx0[t] and t.val > tBF_calib_prices_end.val and d1vM_CET[energy19,s,t] and d1pM_CET_overlap[energy19,s,t] and not (sameas[energy19,'el from y and m'] or sameas[energy19,'district heat']))..
				pM_CET[energy19,s,t] =E= pM_CET[energy19,s,tBF_calib_prices_end];

			E_pM_CET_forecast_ElHeat[energy19,s,t]$(tx0[t] and t.val > tBF_calib_prices_end.val and d1vM_CET[energy19,s,t] and (sameas[energy19,'el from y and m'] or sameas[energy19,'district heat'])).. 
				pM_CET[energy19,s,t] =E= pM_CET[energy19,s,tBF_calib_prices_end];


			#For export price of electricity the distributors mark-up is used to match price paths. After 2030 this mark-up is extrapolated flat
			E_pXE_el[t]$(tx0[t] and t.val > tBF_calib_prices_End.val)..
				fpXE['unspecified','electricity',t] =E= fpXE['unspecified','electricity',tBF_calib_prices_end];


	    #BUNDEN AF VSH. OG FORBRUGERE

		    #Kalibrering af forbrugerens CES-andele
		    E_sCE_forecast[purpose,energy19,t]$(tx0[t] and t.val > tBF_calib_End.val and d1vCE[purpose,energy19,t])..
		    	sCE[purpose,energy19,t] =E= sCE[purpose,energy19,tBF_calib_End];

		    E_sCEPE_forecast[purpose,t]$(tx0[t] and t.val > tBF_calib_end.val and d1vCEPE[purpose,t])..
		    	sCEPE[purpose,t] =E= sCEPE[purpose,tBF_calib_end];

  	       #Energi of formål
		    E_uRE_forecast[purpose,energy19,s,t]$(tx0[t] and t.val > tBF_calib_End.val and d1pREa[purpose,energy19,s,t] and not bunkering[energy19] and not sameas[s,'35012'])..
		    	uRE[purpose,energy19,s,t] =E= uRE[purpose,energy19,s,tBF_calib_End];

	   	   #Formålsopdelt 
		   E_uEP_[purpose,s,t]$(tx0[t] and t.val > tBF_calib_Start.val and tBF_calib[t] and d1EP[purpose,s,t] and not d1EP_new[purpose,s,t] and not (sameas[s,'49509'] or sameas[s,'0600a'])).. 
		   		pEP[purpose,s,t-1] * qEP[purpose,s,t] =E= sum(energy19$(d1pREa[purpose,energy19,s,t] and not eNotInEnergyNest[purpose,energy19,s,t]), pREa[purpose,energy19,s,t-1] * qREa[purpose,energy19,s,t]); 

		   E_uEP_new[purpose,s,t]$(tx0[t] and t.val > tBF_calib_Start.val and tBF_calib[t] and d1EP[purpose,s,t] and d1EP_new[purpose,s,t] and d1EP_new[purpose,s,t-1] and not (sameas[s,'49509'] or sameas[s,'0600a'])).. 
		   		pEP[purpose,s,t-1] * qEP[purpose,s,t] =E= sum(energy19$(d1pREa[purpose,energy19,s,t] and not eNotInEnergyNest[purpose,energy19,s,t]), pREa[purpose,energy19,s,t-1] * qREa[purpose,energy19,s,t]); 

		   #We only forecast uEP for non-ani sectors, because uEP is used in link with agr-production 
		    E_uEP_forecast[purpose,sp,t]$(tx0[t] and t.val > tBF_calib_End.val and d1EP[purpose,sp,t] and not agri_sectors[sp])..
		   		uEP[purpose,sp,t] =E= uEP[purpose,sp,tBF_calib_End];  
		   		
		    E_uEP_forecast_off[purpose,t]$(tx0[t] and t.val > tBF_calib_End.val and d1EP[purpose,'off',t])..
		   		uEP_off[purpose,t] =E= uEP_off[purpose,tBF_calib_End];  

		   	#Øverste nest
		    E_uE_notoff[sp,t]$(tx0[t] and t.val > tBF_calib_Start.val and tBF_calib[t] and d1Prod['Eother',sp,t] and not (sameas[sp,'49509'] or sameas[sp,'0600a'])).. 
		   		pProd['EOther',sp,t-1] * qProd['EOther',sp,t] =E= sum(purpose$(d1EP[purpose,sp,t] and not (sameas[purpose,'transport'] or sameas[purpose,'intern_trans'])), pEP[purpose,sp,t-1] * qEP[purpose,sp,t]);

		   	E_uEtrans[sp,t]$(tx0[t] and t.val > tBF_calib_Start.val and tBF_calib[t] and d1Prod['Etrans',sp,t] and not (sameas[sp,'49509'] or sameas[sp,'0600a']))..
		   		pProd['Etrans',sp,t-1] * qProd['Etrans',sp,t] =E= sum(purpose$(d1EP[purpose,sp,t] and (sameas[purpose,'transport'] or sameas[purpose,'intern_trans'])), pEP[purpose,sp,t-1] * qEP[purpose,sp,t]);

		    E_uE_off[s,t]$(tx0[t] and t.val > tBF_calib_Start.val and tBF_calib[t] and d1E[s,t] and sameas[s,'off']).. #and not agri_sectors_s[s]).. 
		   		pE_CGE[s,t-1] * qE[s,t] =E= sum(purpose$(d1EP[purpose,s,t]), pEP[purpose,s,t-1] * qEP[purpose,s,t]);
	

		    E_uE_forecast[sp,t]$(tx0[t] and t.val > tBF_calib_End.val and d1Prod['Eother',sp,t] and not (sameas[sp,'49509'] or sameas[sp,'0600a'])).. #and not agri_sectors[sp])..
		   		uProd['EOther',sp,t] =E= uProd['EOther',sp,tBF_calib_End];

		   	E_uEtrans_forecast[sp,t]$(tx0[t] and t.val > tBF_calib_End.val and d1Prod['Etrans',sp,t] and not (sameas[sp,'49509'] or sameas[sp,'0600a']))..
		   		uProd['Etrans',sp,t] =E= uProd['Etrans',sp,tBF_calib_end];

		   	#Offentlige
		   	E_uEOFF_forecast[t]$(tx0[t] and t.val > tBF_calib_End.val and d1E['off',t])..
		   		uEOFF[t] =E= uEOFF[tBF_calib_End];

		   	#  Landbrugsmodulet	
			   	#Other energy
		        E_uOtherEnergy_ani[purpose_xtint,ani_sectors,t]$(tx0[t] and t.val > tBF_calib_End.val and d1EP[purpose_xtint,ani_sectors,t])..
			   		uOtherEnergy_ani[purpose_xtint,ani_sectors,t] =E= uOtherEnergy_ani[purpose_xtint,ani_sectors,tBF_calib_End];

			    E_uOtherEnergy_plant[purpose_xtint,plant_sectors,t]$(tx0[t] and t.val > tBF_calib_End.val and d1EP[purpose_xtint,plant_sectors,t])..
			   		uOtherEnergy_plant[purpose_xtint,plant_sectors,t] =E= uOtherEnergy_plant[purpose_xtint,plant_sectors,tBF_calib_End];

			   	E_uAni_otherenergy_ani_calib[ani_sectors,t]$(tx0[t] and t.val > tBF_calib_Start.val and tBF_calib[t] and d1Ani[ani_sectors,'OtherEnergy',t])..
					pAni[Ani_sectors,'OtherEnergy',t-1]*qAni[Ani_sectors,'OtherEnergy',t] =E= sum(purpose_xtint$(d1EP[purpose_xtint,ani_sectors,t]), pEP[purpose_xtint,ani_sectors,t-1] * qEP[purpose_xtint,ani_sectors,t]); 

				E_uAni_otherenergy_ani_calib_forecast[ani_sectors,t]$(tx0[t] and t.val > tBF_calib_End.val and d1Ani[ani_sectors,'OtherEnergy',t])..
					uAni[Ani_sectors,'OtherEnergy',t] =E= uAni[Ani_sectors,'OtherEnergy',tBF_calib_End]; 

			   	E_uPlant_otherenergy_plant_calib[Plant_sectors,t]$(tx0[t] and t.val > tBF_calib_Start.val and tBF_calib[t] and d1Plant[plant_sectors,'OtherEnergy',t])..
					pPlant[Plant_sectors,'OtherEnergy',t-1]*qPlant[Plant_sectors,'OtherEnergy',t] =E= sum(purpose_xtint$(d1EP[purpose_xtint,plant_sectors,t]), pEP[purpose_xtint,plant_sectors,t-1] * qEP[purpose_xtint,plant_sectors,t]); 

				E_uPlant_otherenergy_plant_calib_forecast[Plant_sectors,t]$(tx0[t] and t.val > tBF_calib_End.val and d1Plant[Plant_sectors,'OtherEnergy',t])..
					uPlant[Plant_sectors,'OtherEnergy',t] =E= uPlant[Plant_sectors,'OtherEnergy',tBF_calib_End]; 

			#Fuel 
			   	E_uAni_trans_forecast[ani_sectors,t]$(tx0[t] and t.val > tBF_calib_end.val and d1Ani[Ani_sectors,'fuel',t])..
			   		uAni[ani_sectors,'fuel',t] =E= uAni[ani_sectors,'fuel',tBF_calib_End];

			   	E_uPlant_trans_forecast[plant_sectors,t]$(tx0[t] and t.val > tBF_calib_End.val and d1Plant[plant_sectors,'Fuel',t])..
			   		uPlant[plant_sectors,'fuel',t] =E= uPlant[plant_sectors,'fuel',tBF_calib_End]; 

		#ANDET
		 	E_TL_forecast[purpose,energy19,t]$(tx0[t] and t.val > tBF_calib_End.val and d1TL[purpose,energy19,t])..
		 		qTL[purpose,energy19,t] =E= qTL[purpose,energy19,tBF_calib_End];


		 	E_sXE_forecast[purpose,energy19,t]$(tx0[t] and t.val >tBF_calib_End.val and d1vXE[purpose,energy19,t]).. # and not sameas[energy19,'Natural gas (incl. city-gas)']).. # NatGasCityLVN[energy19])..	
		 		sXE[purpose,energy19,t] =E= sXE[purpose,energy19,tBF_calib_End];

		 	E_qRENEWABLE_forecast[energy19,t]$(tx0[t] and t.val > tBF_calib_End.val and d1RENEWABLE[energy19,t] and not d1waste_module[energy19,t])..
		 		qRENEWABLE[energy19,t] =E= qRENEWABLE[energy19,tBF_calib_End];


			$IF %shutdownnorthsea%:
		 	E_qY_CET_northsea[energy19,t]$(tx0[t] and tShutNorthSea[t] and d1vY_CET[energy19,'0600a',t])..
		 		qY_CET[energy19,'0600a',t] =E= 0.8 * qY_CET[energy19,'0600a',t-1];

		 	E_qY_CET_northsea_aftertShutNorthSeaEnd[energy19,t]$(tx0[t] and t.val > tShutNorthSeaEnd.val and d1vY_CET[energy19,'0600a',t])..
		 		qY_CET[energy19,'0600a',t] =E= qY_CET[energy19,'0600a',tShutNorthSeaEnd];
			$ENDIF

		 #TILPASNING AF AVANCER
		 	#Summen af avancer fra de tre avanceproducerende brancher sættes lig avancerne fra ENS
		 	E_adj_Avance_RE[purpose,energy19,r,t]$(tx0[t] and tBF_calib_prices[t] and (d1EAV_RE[purpose,energy19,r,t] or d1DAV_RE[purpose,energy19,r,t] or d1CAV_RE[purpose,energy19,r,t]) and KF25_CostDel_RE[energy19,r,t])..
		 		KF25_CostDel_RE[energy19,r,t] =E= pEAV_RE[purpose,energy19,r,t]$(d1EAV_RE[purpose,energy19,r,t]) + pDAV_RE[purpose,energy19,r,t]$(d1DAV_RE[purpose,energy19,r,t]) + pCAV_RE[purpose,energy19,r,t]$(d1CAV_RE[purpose,energy19,r,t]);

		 	E_pEAV_RE_tBF_calib_prices[purpose,energy19,r,t]$(tx0[t] and tBF_calib_prices[t] and d1VY_CEt['WholeAndRetailSaleMarginE','46000',t] and d1EAV_RE[purpose,energy19,r,t] and KF25_CostDel_RE[energy19,r,t])..
		 		fpEAV_RE[purpose,energy19,r,t] =E= fpEAV_RE.l[purpose,energy19,r,t] + adj_Avance_RE[purpose,energy19,r,t];

		 	E_pDAV_RE_tBF_calib_prices[purpose,energy19,r,t]$(tx0[t] and tBF_calib_prices[t] 
		 															 and d1VY_CEt['WholeAndRetailSaleMarginE','47000',t] 
		 															 and d1DAV_RE[purpose,energy19,r,t] 
		 															 and KF25_CostDel_RE[energy19,r,t] 
		 															 and not sameas[energy19,'oil products'])..
		 		fpDAV_RE[purpose,energy19,r,t] =E= fpDAV_RE.l[purpose,energy19,r,t] + adj_Avance_RE[purpose,energy19,r,t];

		 	E_pCAV_RE_tBF_calib_prices[purpose,energy19,r,t]$(tx0[t] and tBF_calib_prices[t] 
		 															 and d1VY_CEt['WholeAndRetailSaleMarginE','45000',t] 
		 															 and d1CAV_RE[purpose,energy19,r,t] 
		 															 and KF25_CostDel_RE[energy19,r,t]
		 															 and not sameas[energy19,'oil products'])..
		 		fpCAV_RE[purpose,energy19,r,t] =E= fpCAV_RE.l[purpose,energy19,r,t] + adj_Avance_RE[purpose,energy19,r,t];


		 	E_pEAV_RE_post_tBF_calib_prices_end[purpose,energy19,r,t]$(tx0[t] and t.val > tBF_calib_prices_end.val and d1VY_CEt['WholeAndRetailSaleMarginE','46000',t] and d1EAV_RE[purpose,energy19,r,t] and KF25_CostDel_RE[energy19,r,t])..
		 		fpEAV_RE[purpose,energy19,r,t] =E= fpEAV_RE[purpose,energy19,r,tBF_calib_prices_end];

		 	E_pDAV_RE_tBF_post_tBF_calib_prices_end[purpose,energy19,r,t]$(tx0[t] and t.val > tBF_calib_prices_end.val 
		 																		  and d1VY_CEt['WholeAndRetailSaleMarginE','47000',t] 
		 																		  and d1DAV_RE[purpose,energy19,r,t] 
		 																		  and KF25_CostDel_RE[energy19,r,t]
		 																		  and not sameas[energy19,'oil products'])..
		 		fpDAV_RE[purpose,energy19,r,t] =E= fpDAV_RE[purpose,energy19,r,tBF_calib_prices_end];

		 	E_pCAV_RE_tBF_post_tBF_calib_prices_end[purpose,energy19,r,t]$(tx0[t] and t.val > tBF_calib_prices_end.val 
		 																		  and d1VY_CEt['WholeAndRetailSaleMarginE','45000',t] 
		 																		  and d1CAV_RE[purpose,energy19,r,t] 
		 																		  and KF25_CostDel_RE[energy19,r,t]
		 																		  and not sameas[energy19,'oil products']).. #Oil margins are so low that we only calibrate EAV, because otherwise it will yields negative prices
		 		fpCAV_RE[purpose,energy19,r,t] =E= fpEAV_RE[purpose,energy19,r,tBF_calib_prices_end];



		 	E_adj_Avance_CE[purpose,energy19,t]$(tx0[t] and tBF_calib_prices[t] and (d1EAV_CE[purpose,energy19,t] or d1DAV_CE[purpose,energy19,t] or d1CAV_CE[purpose,energy19,t]) and KF25_CostDel_CE[energy19,t])..
		 		KF25_CostDel_CE[energy19,t] =E= pEAV_CE[purpose,energy19,t]$(d1EAV_CE[purpose,energy19,t]) + pDAV_CE[purpose,energy19,t]$(d1DAV_CE[purpose,energy19,t]) + pCAV_CE[purpose,energy19,t]$(d1CAV_CE[purpose,energy19,t]);

		 	E_pEAV_CE_tBF_calib_prices[purpose,energy19,t]$(tx0[t] and tBF_calib_prices[t] and d1VY_CEt['WholeAndRetailSaleMarginE','46000',t] and d1EAV_CE[purpose,energy19,t] and KF25_CostDel_CE[energy19,t])..
		 		fpEAV_CE[purpose,energy19,t] =E= fpEAV_CE.l[purpose,energy19,t] + adj_Avance_CE[purpose,energy19,t];

		 	E_pDAV_CE_tBF_calib_prices[purpose,energy19,t]$(tx0[t] and tBF_calib_prices[t] and d1VY_CEt['WholeAndRetailSaleMarginE','47000',t] and d1DAV_CE[purpose,energy19,t] and KF25_CostDel_CE[energy19,t])..
		 		fpDAV_CE[purpose,energy19,t] =E= fpDAV_CE.l[purpose,energy19,t] + adj_Avance_CE[purpose,energy19,t];

		 	E_pCAV_CE_tBF_calib_prices[purpose,energy19,t]$(tx0[t] and tBF_calib_prices[t] and d1VY_CEt['WholeAndRetailSaleMarginE','45000',t] and d1CAV_CE[purpose,energy19,t] and KF25_CostDel_CE[energy19,t])..
		 		fpCAV_CE[purpose,energy19,t] =E= fpCAV_CE.l[purpose,energy19,t] + adj_Avance_CE[purpose,energy19,t];

		 	E_pEAV_CE_post_tBF_calib_prices_end[purpose,energy19,t]$(tx0[t] and t.val > tBF_calib_prices_end.val and d1VY_CEt['WholeAndRetailSaleMarginE','46000',t] and d1EAV_CE[purpose,energy19,t] and KF25_CostDel_CE[energy19,t])..
		 		fpEAV_CE[purpose,energy19,t] =E= fpEAV_CE[purpose,energy19,tBF_calib_prices_end];

		 	E_pDAV_CE_tBF_post_tBF_calib_prices_end[purpose,energy19,t]$(tx0[t] and t.val > tBF_calib_prices_end.val and d1VY_CEt['WholeAndRetailSaleMarginE','47000',t] and d1DAV_CE[purpose,energy19,t] and KF25_CostDel_CE[energy19,t])..
		 		fpDAV_CE[purpose,energy19,t] =E= fpDAV_CE[purpose,energy19,tBF_calib_prices_end];

		 	E_pCAV_CE_tBF_post_tBF_calib_prices_end[purpose,energy19,t]$(tx0[t] and t.val > tBF_calib_prices_end.val and d1VY_CEt['WholeAndRetailSaleMarginE','45000',t] and d1CAV_CE[purpose,energy19,t] and KF25_CostDel_CE[energy19,t])..
		 		fpCAV_CE[purpose,energy19,t] =E= fpEAV_CE[purpose,energy19,tBF_calib_prices_end];


		 #El- og fjernvarmepriser, samt biogas og naturgaspriser hos end-user sættes lig priser i ENS-data 
		 	E_adj_pRE_base_marg[purpose,energy19,r,t]$(tx0[t] and tBF_calib_prices[t] and KF25_pRE_base[purpose,energy19,r,t] and d1pRE_base[purpose,energy19,r,t])..
		 		pRE_base_marg[purpose,energy19,r,t] =E= KF25_pRE_base[purpose,energy19,r,t];

		 	E_adj_pRE_base_marg_post_tBF_calib_prices_end[purpose,energy19,r,t]$(tx0[t] and t.val > tBF_calib_prices_end.val and KF25_pRE_base[purpose,energy19,r,t] and d1pRE_base[purpose,energy19,r,t])..
		 		adj_pRE_base_marg[purpose,energy19,r,t] =E= adj_pRE_base_marg[purpose,energy19,r,tBF_calib_prices_end];

		 	E_fpCE[purpose,energy19,t]$(tx0[t] and tBF_calib_prices[t] and KF25_pCE_base[purpose,energy19,t] and d1vCE[purpose,energy19,t])..
		 		pCE_base[purpose,energy19,t] =E= KF25_pCE_base[purpose,energy19,t];

		 	E_fpCE_post_tBF_calib_prices_end[purpose,energy19,t]$(tx0[t] and t.val > tBF_calib_prices_end.val and KF25_pCE_base[purpose,energy19,t] and d1vCE[purpose,energy19,t])..
		 		fpCE[purpose,energy19,t] =E= fpCE[purpose,energy19,tBF_calib_prices_end];
	$ENDBLOCK


  	#-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
	# Avancer
	#-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

	$MODEL M_Avancer 
		#Vsh.
		E_adj_Avance_RE, E_pEAV_RE_tBF_calib_prices, E_pDAV_RE_tBF_calib_prices, E_pCAV_RE_tBF_calib_prices, E_pEAV_RE_post_tBF_calib_prices_end, E_pDAV_RE_tBF_post_tBF_calib_prices_end, E_pCAV_RE_tBF_post_tBF_calib_prices_end

		E_adj_pRE_base_marg
		E_adj_pRE_base_marg_post_tBF_calib_prices_end

		#Forbr.
		E_adj_Avance_CE, E_pEAV_CE_tBF_calib_prices, E_pDAV_CE_tBF_calib_prices, E_pCAV_CE_tBF_calib_prices, E_pEAV_CE_post_tBF_calib_prices_end, E_pDAV_CE_tBF_post_tBF_calib_prices_end, E_pCAV_CE_tBF_post_tBF_calib_prices_end
		E_fpCE, E_fpCE_post_tBF_calib_prices_end
	;

	$GROUP G_avancer_endo 
		   	fpEAV_RE$(tx0[t] and tBF_calib_prices[t] and KF25_CostDel_RE[energy19,r,t] and d1EAV_RE[purpose,energy19,r,t]), fpEAV_RE$(tx0[t] and t.val > tBF_calib_prices_end.val and KF25_CostDel_RE[energy19,r,t] and d1EAV_RE[purpose,energy19,r,t])
		   	fpDAV_RE$(tx0[t] and tBF_calib_prices[t] and KF25_CostDel_RE[energy19,r,t] and d1DAV_RE[purpose,energy19,r,t] and not sameas[energy19,'oil products']), fpDAV_RE$(tx0[t] and t.val > tBF_calib_prices_end.val and KF25_CostDel_RE[energy19,r,t] and d1DAV_RE[purpose,energy19,r,t] and not sameas[energy19,'oil products'])
		   	fpCAV_RE$(tx0[t] and tBF_calib_prices[t] and KF25_CostDel_RE[energy19,r,t] and d1CAV_RE[purpose,energy19,r,t] and not sameas[energy19,'oil products']), fpCAV_RE$(tx0[t] and t.val > tBF_calib_prices_end.val and KF25_CostDel_RE[energy19,r,t] and d1CAV_RE[purpose,energy19,r,t] and not sameas[energy19,'oil products'])


		   	fpEAV_CE$(tx0[t] and tBF_calib_prices[t] and KF25_CostDel_CE[energy19,t] and d1EAV_CE[purpose,energy19,t]), fpEAV_CE$(tx0[t] and t.val > tBF_calib_prices_end.val and KF25_CostDel_CE[energy19,t] and d1EAV_CE[purpose,energy19,t])
		   	fpDAV_CE$(tx0[t] and tBF_calib_prices[t] and KF25_CostDel_CE[energy19,t] and d1DAV_CE[purpose,energy19,t]), fpDAV_CE$(tx0[t] and t.val > tBF_calib_prices_end.val and KF25_CostDel_CE[energy19,t] and d1DAV_CE[purpose,energy19,t])
		   	fpCAV_CE$(tx0[t] and tBF_calib_prices[t] and KF25_CostDel_CE[energy19,t] and d1CAV_CE[purpose,energy19,t]), fpCAV_CE$(tx0[t] and t.val > tBF_calib_prices_end.val and KF25_CostDel_CE[energy19,t] and d1CAV_CE[purpose,energy19,t])


		 	  adj_pRE_base_marg$(tx0[t] and tBF_calib_prices[t] and KF25_pRE_base[purpose,energy19,r,t] and d1pRE_base[purpose,energy19,r,t]), adj_pRE_base_marg$($(tx0[t] and t.val > tBF_calib_prices_end.val and KF25_pRE_base[purpose,energy19,r,t] and d1pRE_base[purpose,energy19,r,t]))
				fpCE$(tx0[t] and tBF_calib_prices[t] and KF25_pCE_base[purpose,energy19,t] and d1vCE[purpose,energy19,t]), fpCE$(tx0[t] and t.val > tBF_calib_prices_end.val and KF25_pCE_base[purpose,energy19,t] and d1vCE[purpose,energy19,t]) 
	;


		#  parameter whereisitdoch[purpose,energy19,r,t];
		#  whereisitdoch[purpose,'coal and coke',r,t]$(d1qREgj[purpose,'coal and coke',r,t] and not d1EAV_RE[purpose,'coal and coke',r,t]) = 1;


		#Tilføjer engros- og detailavancer på kul
			pEAV_RE.l[purpose,'coal and coke',r,t]$(tForecast[t] and d1qREgj[purpose,'coal and coke',r,t] and not d1EAV_RE[purpose,'coal and coke',r,t]) = pY_CET.l['WholeAndRetailSaleMarginE','46000',t];
			vEAV_RE.l[purpose,'coal and coke',r,t]$(tForecast[t] and d1qREgj[purpose,'coal and coke',r,t] and not d1EAV_RE[purpose,'coal and coke',r,t]) = pEAV_RE.l[purpose,'coal and coke',r,t];

	   	    d1EAV_RE[purpose,energy19,r,t] = yes$(vEAV_RE.l[purpose,energy19,r,t] and d1qREgj[purpose,energy19,r,t]);

		#  execute_unload 'output\pre.gdx';
		#  $exit


	#-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
	# EMISSIONS EQUATIONS
	#-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

	d1EmmProdxE[s,t,emm]$(tx1[t] and GWP.l[emm] and sum(sCRF,sCRF_2_sENS2GR_xE(sCRF,s,emm) and KF_emm_[emm,sCRF,t]) and not agri_sectors_s[s]) = yes;
	d1EmmProdxE[s,t,emm]$(tx1[t] and GWP.l[emm] and not sum(sCRF,sCRF_2_sENS2GR_xE(sCRF,s,emm)) and not agri_sectors_s[s]) = no; #If it is not in mapping it is removed
	d1EmmProdxE[s,t,emm]$(tx1[t] and GWP.l[emm] and sum(sCRF,sCRF_2_sENS2GR_xE(sCRF,s,emm) and not KF_emm_[emm,sCRF,t]) and not agri_sectors_s[s]) = no; #If it is in mapping but not in KF it is removed
	d1EmmProdxE[s,t,'CO2e']$(tx1[t]) = yes$(sum(emm,d1EmmProdxE[s,t,emm] and GWP.l[emm]));
	qEmmProdxE.l[s,t,emm_eq]$(not d1EmmProdxE[s,t,emm_eq]) = 0; 


	d1EmmConsxE[t,emm]$(tx1[t] and GWP.l[emm] and sum(sCRF,sCRF_2_sENS2GR_xE(sCRF,'68203',emm) and KF_emm_[emm,sCRF,t])) = yes;
	d1EmmConsxE[t,emm]$(tx1[t] and GWP.l[emm] and not sum(sCRF,sCRF_2_sENS2GR_xE(sCRF,'68203',emm))) = no; #If it is not in mapping it is removed
	d1EmmConsxE[t,emm]$(tx1[t] and GWP.l[emm] and sum(sCRF,sCRF_2_sENS2GR_xE(sCRF,'68203',emm) and not KF_emm_[emm,sCRF,t])) = no; #If it is in mapping but not in KF it is removed
	d1EmmConsxE[t,'CO2e']$(tx1[t]) = yes$(sum(emm,d1EmmConsxE[t,emm] and GWP.l[emm]));
	qEmmConsxE.l[t,emm_eq]$(not d1EmmConsxE[t,emm_eq]) = 0; 

	#Corrections, should be in emissions, the mapping test should also be expanded to check for these instances
	sCRF_2_sENS2GR_xE(sCRF,sLan,emm) = no;
	sCRF_2_sENS2GR_xE('Product uses as ODS substitutes','38392',emm) = no;
	sCRF_2_sENS2GR_xE('Product uses as ODS substitutes','35002',emm) = no;
	sCRF_2_sENS2GR_xE('Product uses as ODS substitutes','37000',emm) = no;
	sCRF_2_sENS2GR_xE('Other product manufacture and use','38392',emm) = no;
	sCRF_2_sENS2GR_xE('Other product manufacture and use','35002',emm) = no;
	sCRF_2_sENS2GR_xE('Other product manufacture and use','37000',emm) = no;

	sCRF_2_sENS2GR_xE('Other product manufacture and use',s,'N2O') = no;

	#Control set to trouble-shoot
	set thesesCRF[sCRF]/set.sCRF/;

	$BLOCK B_KF_calib_emmi 
		E_qEmmProdxE_and_qEmmConsxE_calib2KF_not_Agri_or_LULUCF[emm,sCRF,t]$(tx0[t] and t.val > tBF_calib_Start.val and tBF_calib[t] and thesesCRF[sCRF]
										and (sum(s,sCRF_2_sENS2GR_xE(sCRF,s,emm) and KF_emm_[emm,sCRF,t] and d1EmmProdxE[s,t,emm]) or (d1EmmConsxE[t,emm] and sCRF_2_sENS2GR_xE(sCRF,'68203',emm) and KF_emm_[emm,sCRF,t])))..
			KF_emm_[emm,sCRF,t]/GWP[emm]*1000 * lambda + (1-lambda ) * 
																										(sum(s$(sCRF_2_sENS2GR_xE(sCRF,s,emm) and d1EmmProdxE[s,t,emm]), qEmmProdxE.l[s,t,emm])
																														+ qEmmConsxE.l[t,emm]$(sCRF_2_sENS2GR_xE(sCRF,'68203',emm) and d1EmmConsxE[t,emm]))
										
										 =E= sum(s$(sCRF_2_sENS2GR_xE(sCRF,s,emm) and d1EmmProdxE[s,t,emm]), qEmmProdxE[s,t,emm])
														+ qEmmConsxE[t,emm]$(sCRF_2_sENS2GR_xE(sCRF,'68203',emm) and d1EmmConsxE[t,emm])
														;

		E_uEmmProdxE_tBF_calib[emm,sCRF,s,t]$(tx0[t] and t.val>tBF_calib_start.val and tBF_calib[t] and thesesCRF[sCRF] and sCRF_2_sENS2GR_xE(sCRF,s,emm) and KF_emm_[emm,sCRF,t] and d1EmmProdxE[s,t,emm])..
				uEmmProdxE[s,t,emm] =E= uEmmProdxE.l[s,t,emm] * adj_uEmmxE[emm,sCRF,t];

		E_uEmmConsxE_tBF_calib[emm,sCRF,t]$(tx0[t] and t.val>tBF_calib_start.val and tBF_calib[t] and thesesCRF[sCRF] and sCRF_2_sENS2GR_xE(sCRF,'68203',emm) and KF_emm_[emm,sCRF,t] and d1EmmConsxE[t,emm])..
				uEmmConsxE[t,emm] =E= uEmmConsxE.l[t,emm] * adj_uEmmxE[emm,sCRF,t];


		E_uEmmProdxE_after_tBF_calib[emm,sCRF,s,t]$(tx0[t] and t.val>tBF_calib_end.val and thesesCRF[sCRF] and sCRF_2_sENS2GR_xE(sCRF,s,emm) and KF_emm_[emm,sCRF,t] and d1EmmProdxE[s,t,emm])..
				uEmmProdxE[s,t,emm] =E= uEmmProdxE[s,tBF_calib_end,emm];

		E_uEmmConsxE_after_tBF_calib[emm,sCRF,t]$(tx0[t] and t.val>tBF_calib_end.val and thesesCRF[sCRF] and sCRF_2_sENS2GR_xE(sCRF,'68203',emm) and KF_emm_[emm,sCRF,t] and d1EmmConsxE[t,emm])..
				uEmmConsxE[t,emm] =E= uEmmConsxE[tBF_calib_end,emm];

	  #Domestic aviation 
	  E_qEmmDomesticAviationDCE[t]$(tx0[t] and t.val> tBF_calib_start.val and KF_emm_['CO2e','domestic aviation',t])..
				KF_emm_['CO2e','Domestic aviation',t]*1000	=E=  qEmmDomesticAviationDCE[t] + qEmmProdE['51001',t,'CO2e','in_ETS','jet petroleum']$d1EmmProdE['51001',t,'CO2e','in_ETS','jet petroleum']; 
	
		#Total UNFCCC_lulucf emissions 
		E_qEmmTot_UNFCCC_LULUCF_calib2KF[t]$(tx0[t] and t.val > tBF_calib_start.val and tBF_calib[t])..
				qEmmTot[t,'CO2e','UNFCCC_LULUCF'] =E= sum(sCRF, KF_emm_['CO2e',sCRF,t]*1000);

		E_qEmmTot_UNFCCC_LULUCF_calib2KF_after_tBF_calib_start[t]$(tx0[t] and t.val > tBF_calib_end.val)..
				jEmmTot_UNFCCC_LULUCF_Calib2KF[t] =E= 0; #jEmmTot_UNFCCC_LULUCF_Calib2KF[tBF_calib_end];

	$ENDBLOCK


#=============================================================================================================================================================================================#
# 7) PRE-MODEL FOR CALIBRATION TO KF. THIS MODEL YIELDS INITIAL VALUES FOR THE FINAL CALIBRATION (and is also helpful in trouble-shooting)
#=============================================================================================================================================================================================#

# ---------------------------------------------------------------------------------------------------------------- 
# First pre-model to give initial values to taxes and energy prices for new energy use
# ---------------------------------------------------------------------------------------------------------------- 

	$MODEL M_premodel_prices_emissions_taxes 
		M_taxes_calib
		M_taxes_energy_calib
		M_emissions_calib
		M_energy_prices
		B_energy_margins,-E_vOtherDistributionProfits_EAV,-E_vOtherDistributionProfits_DAV,-E_vOtherDistributionProfits_CAV
		M_Avancer

		E_pREa
	;



	$GROUP G_premodel_prices_emissions_taxes_exo 
		G_taxes_calib_Exo 
		G_taxes_energy_calib_exo
		G_emissions_calib_exo 	
		sBioNatgas  # Add to exo-group of G_emissions_calib_exo
		sBionatgasC # Add to exo-group of G_emissions_calib_exo

		G_IO_exo
		G_energy_demand_prices_exo
		G_energy_markets_margins_exo
		vOtherDistributionProfits_EAV, vOtherDistributionProfits_DAV, vOtherDistributionProfits_CAV
		
		j_pREa$(tx0[t] and d1pREa[purpose,energy19a,s,t])

		vtCalibENS$(d1tRE[purpose,energy19,r,t])
		tCALIBENS$(d1tRE[purpose,energy19,r,t])

		w

		qXE['unspecified','natural gas incl. biongas',t]
	;

	$GROUP G_premodel_prices_emissions_taxes_endo 
		G_taxes_calib 
		G_taxes_energy_calib
		G_emissions_calib
		G_energy_demand_prices_endo
		G_energy_markets_margins_endo,-vOtherDistributionProfits_EAV,-vOtherDistributionProfits_DAV,-vOtherDistributionProfits_CAV
		 
		G_avancer_endo

		pREa$(tx0[t] and d1pREa[purpose,energy19a,s,t])
	;

	#  $FIX G_premodel_prices_emissions_taxes_exo;
	#  $UNFIX G_premodel_prices_emissions_taxes_endo;
	#  @SOLVE(M_premodel_prices_emissions_taxes);
	#  @assert_no_difference(G_data,1e-6);
	# execute_unload 'output\post.gdx';

# Updating energy prices (period t) when nothing exists in current period (t) but exists in next period (t+1)
pREa.l[purpose,energy19,r,t]$(d1pREa_KFnew[purpose,energy19,r,t+1] and not d1pREa_KFnew[purpose,energy19,r,t]) 		        = pREa.l[purpose,energy19,r,t+1]; 
pREgj.l[purpose,energy19,r,t]$(d1pREgj_KFnew[purpose,energy19,r,t+1] and not d1pREgj_KFnew[purpose,energy19,r,t]) 	        = pREgj.l[purpose,energy19,r,t+1]; 
pRE_base.l[purpose,energy19,r,t]$(d1pRE_base_KFnew[purpose,energy19,r,t+1] and not d1pRE_base_KFnew[purpose,energy19,r,t])  = pRE_base.l[purpose,energy19,r,t+1]; 


# ---------------------------------------------------------------------------------------------------------------- 
# Second pre-model 
# ----------------------------------------------------------------------------------------------------------------

$BLOCK B_premodel_chainindices 
			  E_uEP_chain[purpose,s,t]$(tx0[t] and t.val > tBF_calib_Start.val and tBF_calib[t] and d1EP[purpose,s,t] and not d1EP_new[purpose,s,t] and not (sameas[s,'49509'] or sameas[s,'0600a'])).. 
		   		pEP[purpose,s,t] * qEP[purpose,s,t] =E= sum(energy19$(d1pREa[purpose,energy19,s,t] and not eNotInEnergyNest[purpose,energy19,s,t]), pREa[purpose,energy19,s,t] * qREa[purpose,energy19,s,t]); 

		   E_uEP_new_chain[purpose,s,t]$(tx0[t] and t.val > tBF_calib_Start.val and tBF_calib[t] and d1EP[purpose,s,t] and d1EP_new[purpose,s,t] and d1EP_new[purpose,s,t-1] and not (sameas[s,'49509'] or sameas[s,'0600a'])).. 
		   		pEP[purpose,s,t] * qEP[purpose,s,t] =E= sum(energy19$(d1pREa[purpose,energy19,s,t] and not eNotInEnergyNest[purpose,energy19,s,t]), pREa[purpose,energy19,s,t] * qREa[purpose,energy19,s,t]); 

		   E_uEP_new_chain_firstyear[purpose,s,t]$(tx0[t] and t.val > tBF_calib_Start.val and tBF_calib[t] and d1EP[purpose,s,t] and d1EP_new[purpose,s,t] and not d1EP_new[purpose,s,t-1] and not (sameas[s,'49509'] or sameas[s,'0600a'])).. 
		   		qEP[purpose,s,t] =E= sum(energy19$(d1pREa[purpose,energy19,s,t] and not eNotInEnergyNest[purpose,energy19,s,t]), pREa[purpose,energy19,s,t] * qREa[purpose,energy19,s,t]); 


		   	E_pEP_elongate[purpose,s,t]$(tx0[t] and t.val>tBF_calib_end.val and d1EP[purpose,s,t] and d1EP[purpose,s,tBF_calib_end] and not (sameas[s,'49509'] or sameas[s,'0600a']))..
		   		pEP[purpose,s,t] =E= pEP[purpose,s,tBF_calib_end]; 

		   	E_qEP_elongate[purpose,s,t]$(tx0[t] and t.val>tBF_calib_end.val and d1EP[purpose,s,t] and d1EP[purpose,s,tBF_calib_end] and not (sameas[s,'49509'] or sameas[s,'0600a']))..
		   		qEP[purpose,s,t] =E= qEP[purpose,s,tBF_calib_end];

		    E_uE_notoff_chain[sp,t]$(tx0[t] and t.val > tBF_calib_Start.val and tBF_calib[t] and d1Prod['EOther',sp,t] and not (sameas[sp,'49509'] or sameas[sp,'0600a'])).. 
		   		pProd['EOther',sp,t] * qProd['EOther',sp,t] =E= sum(purpose$(d1EP[purpose,sp,t] and not (sameas[purpose,'transport'] or sameas[purpose,'intern_trans'])), pEP[purpose,sp,t] * qEP[purpose,sp,t]);

		   	E_uEtrans_chain[sp,t]$(tx0[t] and t.val > tBF_calib_Start.val and tBF_calib[t] and d1Prod['Etrans',sp,t] and not (sameas[sp,'49509'] or sameas[sp,'0600a']))..
		   		pProd['Etrans',sp,t] * qProd['Etrans',sp,t] =E= sum(purpose$(d1EP[purpose,sp,t] and (sameas[purpose,'transport'] or sameas[purpose,'intern_trans'])), pEP[purpose,sp,t] * qEP[purpose,sp,t]);

		      E_uE_off_chain[t]$(tx0[t] and t.val > tBF_calib_Start.val and tBF_calib[t] and d1E['off',t]).. #and not agri_sectors_s[s]).. 
		   		pE_CGE['off',t] * qE['off',t] =E= sum(purpose$(d1EP[purpose,'off',t]), pEP[purpose,'off',t] * qEP[purpose,'off',t]);


		   	E_pE_CGE_elongate_off[s,t]$(tx0[t] and t.val >tBF_calib_end.val and d1E[s,t] and sameas[s,'off'])..
		   		pE_CGE[s,t] =E= pE_CGE[s,tBF_calib_end];

		   	E_pE_CGE_elongate[sp,t]$(tx0[t] and t.val >tBF_calib_end.val and d1Prod['EOther',sp,t] and not (sameas[sp,'49509'] or sameas[sp,'0600a']))..
		   		pProd['EOther',sp,t] =E= pProd['EOther',sp,tBF_calib_end];

		   	E_qE_CGE_elongate_off[s,t]$(tx0[t] and t.val >tBF_calib_end.val and d1E[s,t] and sameas[s,'off'])..
		   		qE[s,t] =E= qE[s,tBF_calib_end];

		   	E_qE_CGE_elongate[sp,t]$(tx0[t] and t.val >tBF_calib_end.val and d1Prod['EOther',sp,t] and not (sameas[sp,'49509'] or sameas[sp,'0600a']))..
		   		qProd['EOther',sp,t] =E= qProd['EOther',sp,tBF_calib_end];

		   	E_pE_Trans_elongate[sp,t]$(tx0[t] and t.val >tBF_calib_end.val and d1Prod['Etrans',sp,t] and not (sameas[sp,'49509'] or sameas[sp,'0600a']))..
		   		pProd['Etrans',sp,t] =E= pProd['Etrans',sp,tBF_calib_end];

		   	E_qE_Trans_elongate[sp,t]$(tx0[t] and t.val >tBF_calib_end.val and d1Prod['Etrans',sp,t] and not (sameas[sp,'49509'] or sameas[sp,'0600a']))..
		   		qProd['Etrans',sp,t] =E= qProd['Etrans',sp,tBF_calib_end];

		   	#  Landbrugsmodulet	
		  #   	E_pAni_OtherEnergy_chain[ani_sectors,t]$(tx0[t] and t.val > tBF_calib_Start.val and tBF_calib[t] and d1Ani[ani_sectors,'OtherEnergy',t])..
				#  pAni[Ani_sectors,'OtherEnergy',t-1]*qAni[Ani_sectors,'OtherEnergy',t] =E= sum(purpose_xtint$(d1EP[purpose_xtint,ani_sectors,t]), pEP[purpose_xtint,ani_sectors,t-1] * qEP[purpose_xtint,ani_sectors,t]); 

		  #   	E_pPlant_otherenergy_chain[Plant_sectors,t]$(tx0[t] and t.val > tBF_calib_Start.val and tBF_calib[t] and d1Plant[plant_sectors,'OtherEnergy',t])..
				#  pPlant[Plant_sectors,'OtherEnergy',t-1]*qPlant[Plant_sectors,'OtherEnergy',t] =E= sum(purpose_xtint$(d1EP[purpose_xtint,plant_sectors,t]), pEP[purpose_xtint,plant_sectors,t-1] * qEP[purpose_xtint,plant_sectors,t]); 


$ENDBLOCK 

$BLOCK B_premodel_extra
	 	   E_uEP_forecast_agrisectors[purpose,sp,t]$(tx0[t] and t.val > tBF_calib_End.val and d1EP[purpose,sp,t] and agri_sectors[sp])..
	  	 		uEP[purpose,sp,t] =E= uEP[purpose,sp,tBF_calib_End];  


				$LOOP00 E_qREa: 
					{name}_tBF_calib{sets}$({subsets} and t.val > tBF_calib_start.val and tBF_calib[t] and not (sameas[sp,'49509'] or sameas[sp,'0600a']))..
						{LHS} =E= {RHS};
				$ENDLOOP00

				$LOOP00 E_qRE_trans: 
					{name}_tBF_calib{sets}$({subsets} and t.val > tBF_calib_start.val and tBF_calib[t] and not (sameas[sp,'49509'] or sameas[sp,'0600a']))..
						{LHS} =E= {RHS};
				$ENDLOOP00

				$LOOP00 E_qREa_off: 
					{name}_tBF_calib{sets}$({subsets} and t.val > tBF_calib_start.val and tBF_calib[t])..
						{LHS} =E= {RHS};
				$ENDLOOP00

				$LOOP00 E_qRE_natgas: 
					{name}_tBF_calib{sets}$({subsets} and t.val > tBF_calib_start.val and tBF_calib[t])..
						{LHS} =E= {RHS};
				$ENDLOOP00

				$LOOP00 E_qRE_biogas: 
					{name}_tBF_calib{sets}$({subsets} and t.val > tBF_calib_start.val and tBF_calib[t])..
						{LHS} =E= {RHS};
				$ENDLOOP00

				$LOOP00 E_qRE_DataCentre: 
					{name}_tBF_calib{sets}$({subsets} and t.val > tBF_calib_start.val and tBF_calib[t])..
						{LHS} =E= {RHS};
				$ENDLOOP00

				$LOOP00 E_qRE_CrudeOilToRefineries:
					{name}_tBF_calib{sets}$({subsets} and t.val > tBF_calib_start.val and tBF_calib[t])..
						{LHS} =E= {RHS};
				$ENDLOOP00

				$LOOP00 E_qEP: 
					{name}_tBF_calib{sets}$({subsets} and t.val > tBF_calib_start.val and tBF_calib[t] and not (sameas[sp,'49509'] or sameas[sp,'0600a']))..
						{LHS} =E= {RHS};
				$ENDLOOP00

				$LOOP00 E_qEP_trans: 
					{name}_tBF_calib{sets}$({subsets} and t.val > tBF_calib_start.val and tBF_calib[t] and not (sameas[sp,'49509'] or sameas[sp,'0600a']))..
						{LHS} =E= {RHS};
				$ENDLOOP00

				$LOOP00 E_qEP_off: 
					{name}_tBF_calib{sets}$({subsets} and t.val > tBF_calib_start.val and tBF_calib[t])..
						{LHS} =E= {RHS};
				$ENDLOOP00

				$LOOP00 E_qProd_map_notUlt: 
					{name}_tBF_calib{sets}$({subsets} and t.val > tBF_calib_start.val and tBF_calib[t] and not (sameas[sp,'49509'] or sameas[sp,'0600a']) and (sameas[prd,'EOther'] or sameas[prd,'Etrans']))..
						{LHS} =E= {RHS};
				$ENDLOOP00

				$LOOP00 E_qEOFF: 
					{name}_tBF_calib{sets}$({subsets} and t.val > tBF_calib_start.val and tBF_calib[t])..
						{LHS} =E= {RHS};
				$ENDLOOP00


				$LOOP00 E_uRE_forecast:
					{name}_premodel_extra{sets}$({subsets} and not bunkering[energy19] and not (sameas[s,'49509'] or sameas[s,'0600a']))..
						{LHS} =E= {RHS};
				$ENDLOOP00


				$LOOP00 E_uEP_forecast: 
					{name}_premodel_extra{sets}$({subsets} and not (sameas[sp,'49509'] or sameas[sp,'0600a']))..
						{LHS} =E= {RHS};
				$ENDLOOP00

				$LOOP00 E_uEP_forecast_off: 
					{name}_premodel_extra{sets}$({subsets})..
						{LHS} =E= {RHS};
				$ENDLOOP00

$ENDBLOCK


$MODEL M_premodel_chainindices
	#EP-chain
	E_uEP_
	E_uEP_new

	#E-chain 
	E_uE_notoff
	E_uEtrans
	E_uE_off 

	#CES-shares
	E_qREa_tBF_calib 
	E_qRE_trans_tBF_calib 
	E_qREa_off_tBF_calib 
	E_qRE_natgas_tBF_calib 
	E_qRE_biogas_tBF_calib 
	E_qRE_DataCentre_tBF_calib
	E_qRE_CrudeOilToRefineries_tBF_calib
	E_uRE_forecast_premodel_extra

	E_qEP_tBF_calib 
	E_qEP_trans_tBF_calib 
	E_qEP_off_tBF_calib
	E_uEP_forecast_premodel_extra, E_uEP_forecast_agrisectors, E_uEP_forecast_off_premodel_extra

	E_qProd_map_notUlt_tBF_calib 
	E_uE_forecast 
	E_uETrans_forecast 
	E_qEOff_tBF_calib, E_uEOFF_forecast 
	
	B_premodel_chainindices
;

$GROUP G_premodel_chaindices_exo 
	#Bottom
		pREa$(d1pREa[purpose,energy19a,s,t] and not eNotInEnergyNest[purpose,energy19a,s,t]) #All prices in the bottom are exogenous
		qREa$(d1pREa[purpose,energy19a,s,t] and not eNotInEnergyNest[purpose,energy19a,s,t]) #All prices in the bottom are exogenous
		pREa$(d1pREa[purpose,energy19a,s,t+1] and not d1pREa[purpose,energy19a,s,t])

	#EP-layer
		pEP$(t0[t])
		pEP$(tx0[t] and t.val = tBF_calib_Start.val and tBF_calib[t] and d1EP[purpose,s,t+1] and not (sameas[s,'49509'] or sameas[s,'0600a']))

		#Første periode.
		pEP$(tx0[t] and t.val > tBF_calib_Start.val and tBF_calib[t] and d1EP[purpose,s,t] and d1EP_new[purpose,s,t] and not d1EP_new[purpose,s,t-1] and not (sameas[s,'49509'] or sameas[s,'0600a'])) 
		pREa$(t0[t])

	#E-layer
		pE_CGE$(t0[t])
		pE_CGE$(tx0[t] and t.val=tBF_calib_start.val and tBF_calib[t] and d1E[s,t+1] and not (sameas[s,'49509'] or sameas[s,'0600a']))
		pProd$(t0[t] and sameas[prd,'EOther'])
		pProd$(tx0[t] and sameas[prd,'EOther'] and t.val=tBF_calib_start.val and tBF_calib[t] and d1Prod[prd,sp,t+1] and not (sameas[sp,'49509'] or sameas[sp,'0600a']))

		pProd$(t0[t] and sameas[prd,'Etrans'])
		pProd$(tx0[t] and sameas[prd,'Etrans'] and t.val=tBF_calib_start.val and tBF_calib[t] and d1Prod[prd,sp,t+1] and not (sameas[sp,'49509'] or sameas[sp,'0600a']))
		
		#Over-eksogenisering. Noget med de laggede priser
		pEP$(tx0[t])		
		pE_CGE$(tx0[t])
		pProd$(tx0[t] and sameas[prd,'EOther'])


		#Agriculture
		#  pAni$(tx0[t] and t.val=tBF_calib_start.val and tBF_calib[t] and (d1Ani[ani_sectors,ani_,t] or d1Ani[ani_sectors,ani_,t+1]) and sameas[ani_,'otherenergy'])
		#  pPlant$(tx0[t] and t.val=tBF_calib_start.val and tBF_calib[t] and (d1Plant[plant_sectors,plant_,t] or d1Plant[plant_sectors,plant_,t+1]) and sameas[plant_,'otherenergy'])

		#  #CES-shares
			 qREa$(tx0[t] and t.val > tBF_calib_start.val and tBF_calib[t] and d1pREa[purpose,energy19a,s,t] and not bunkering[energy19a])
		#  	# For bunkering bestemmes qREa i alle år af qRE-ligningerne i production.gms
			uRE$(tx0[t] and d1pREa[purpose,energy19a,s,t] and bunkering[energy19a]) 
		# '35012' indgår ikke
			uRE$(tx0[t] and d1pREa[purpose,energy19a,s,t] and sameas[s,'35012']) 

			qY_CETgross$(d1vY_CET[out,s,t] and sameas[out,'Natural gas incl. biongas']) # E_qRE_natgas

			qKELBM$(tx0[t] and sameas[s,'19000']) #E_qRE_CrudeOilToRefineries


		#  #  #Quantities of energy purpose 
			pE_CGE$(d1E[s,t])   	# pE_CGE er eksogen i qEP-ligningerne
			pProd$(sameas[prd,'EOther'] and d1Prod[prd,sp,t])   	# pE_CGE er eksogen i qEP-ligningerne
			qE$(d1E[s,t]) 		    # qE er eksogen i qEP-ligningerne 
			qProd$(sameas[prd,'EOther'] and d1Prod[prd,sp,t]) 		    # qE er eksogen i qEP-ligningerne 
			qProd$(sameas[prd,'Etrans'] and d1Prod[prd,sp,t])

		#  #  # Quantities of energy purpose
		#  #   	pEP$(tx0[t] and d1EP[purpose,s,t]) 			# pEP er eksogen i qEP-ligningerne (endogeniseres nedenfor)
		#  #  	pE_CGE$(sum(purpose, d1EP[purpose,s,t])) 	# pE_CGE er eksogen i qEP-ligningerne
		#  #  	qE$(sum(purpose, d1EP[purpose,s,t])) 		# qE er eksogen i qEP-ligningerne 
		#  #  	qEtrans$(sum(purpose, d1EP[purpose,s,t])) 	# qEtrans er eksogen i qEP-ligningerne 

		#  #  # E_uEP_new
		#  #  	qEP$(d1EP[purpose,s,t+1] and not d1EP[purpose,s,t] and not (sameas[s,'49509'] or sameas[s,'0600a']))
		#  #  	pREa$(t0[t])
		#  #  	pREa$(d1pREa[purpose,energy19a,s,t+1] and not d1pREa[purpose,energy19a,s,t])
		#  #  # E_pEP
		#  #  	pEP$(t0[t])
		#  #   	pEP$(d1EP[purpose,s,t+1] and not d1EP[purpose,s,t] and not (sameas[s,'49509'] or sameas[s,'0600a'])) # I første år med nyt energiforbrug eksogeniseres prisen, så prisligningen bestemmer mængden


	 #  #  	 pE_CGE$(d1E[s,t+1] and not d1E[s,t])

	 #  #  	 pEtrans$(d1Etrans[s,t+1] and not d1Etrans[s,t])

	 	#E_qE 
	 	pProd$(tx0[t] and sameas[prd,'MKE']), qProd$(tx0[t] and sameas[prd,'MKE'])
	 	#E_qEtrans
	 	pProd$(tx0[t] and sameas[prd,'TKE']), qProd$(tx0[t] and sameas[prd,'TKE'])
	 	#E_qEoff
	 	pR, qR

;

$GROUP G_premodel_chainindices_endo 
# E_uEP_
	pEP$(tx0[t] and t.val > tBF_calib_Start.val and tBF_calib[t] and d1EP[purpose,s,t] and not d1EP_new[purpose,s,t] and not (sameas[s,'49509'] or sameas[s,'0600a'])) #Gamle EP
# E_uEP_new
	pEP$(tx0[t] and t.val > tBF_calib_Start.val and tBF_calib[t] and d1EP[purpose,s,t] and d1EP_new[purpose,s,t] and d1EP_new[purpose,s,t-1] and not (sameas[s,'49509'] or sameas[s,'0600a'])) #Nye EP
# E_uEP_chain
	qEP$(tx0[t] and t.val > tBF_calib_Start.val and tBF_calib[t] and d1EP[purpose,s,t] and not d1EP_new[purpose,s,t] and not (sameas[s,'49509'] or sameas[s,'0600a'])) 
# E_uEP_new_chain
	qEP$(tx0[t] and t.val > tBF_calib_Start.val and tBF_calib[t] and d1EP[purpose,s,t] and d1EP_new[purpose,s,t] and d1EP_new[purpose,s,t-1] and not (sameas[s,'49509'] or sameas[s,'0600a']))

	#Første periode for nyt energiforbrug
¨# E_uEP_new_chain_firstyear
	qEP$(tx0[t] and t.val > tBF_calib_Start.val and tBF_calib[t] and d1EP[purpose,s,t] and d1EP_new[purpose,s,t] and not d1EP_new[purpose,s,t-1] and not (sameas[s,'49509'] or sameas[s,'0600a'])) 

# E_qEP_elongate
	qEP$(tx0[t] and t.val > tBF_calib_End.val and d1EP[purpose,s,t] and d1EP[purpose,s,tBF_calib_end] and not (sameas[s,'49509'] or sameas[s,'0600a']))

# E_pEP_elongate
	pEP$(tx0[t] and t.val > tBF_calib_End.val and d1EP[purpose,s,t] and d1EP[purpose,s,tBF_calib_end] and not (sameas[s,'49509'] or sameas[s,'0600a']))

	#E-layer 
# E_uE_off_chain
		pE_CGE$(tx0[t] and t.val > tBF_calib_start.val and tBF_calib[t] and d1E[s,t] and not (sameas[s,'49509'] or sameas[s,'0600a']) and sameas[s,'off'])
# E_uE_off 
		qE$(tx0[t] and t.val > tBF_calib_start.val and tBF_calib[t] and d1E[s,t] and not (sameas[s,'49509'] or sameas[s,'0600a']) and sameas[s,'off'])
# E_uE_notoff_chain
		pProd$(tx0[t] and sameas[prd,'EOther'] and t.val > tBF_calib_start.val and tBF_calib[t] and d1Prod[prd,sp,t] and not (sameas[sp,'49509'] or sameas[sp,'0600a']))
# E_uE_notoff
		qProd$(tx0[t] and sameas[prd,'EOther'] and t.val > tBF_calib_start.val and tBF_calib[t] and d1Prod[prd,sp,t] and not (sameas[sp,'49509'] or sameas[sp,'0600a']))
# E_uEtrans_chain
		pProd$(tx0[t] and sameas[prd,'Etrans'] and t.val > tBF_calib_start.val and tBF_calib[t] and d1Prod[prd,sp,t] and not (sameas[sp,'49509'] or sameas[sp,'0600a']))
# E_uEtrans
		qProd$(tx0[t] and sameas[prd,'Etrans'] and t.val > tBF_calib_start.val and tBF_calib[t] and d1Prod[prd,sp,t] and not (sameas[sp,'49509'] or sameas[sp,'0600a']))

# E_pE_CGE_elongate_off
		pE_CGE$(tx0[t] and t.val > tBF_calib_End.val and d1E[s,t] and d1E[s,tBF_calib_end] and not (sameas[s,'49509'] or sameas[s,'0600a']) and sameas[s,'off'])
# E_qE_CGE_elongate_off
		qE$(tx0[t] and t.val > tBF_calib_End.val and d1E[s,t] and d1E[s,tBF_calib_end] and not (sameas[s,'49509'] or sameas[s,'0600a']) and sameas[s,'off'])
# E_pE_CGE_elongate
		pProd$(tx0[t] and sameas[prd,'EOther'] and t.val > tBF_calib_End.val and d1Prod[prd,sp,t] and d1Prod[prd,sp,tBF_calib_end] and not (sameas[sp,'49509'] or sameas[sp,'0600a']))
# E_qE_CGE_elongate
		qProd$(tx0[t] and sameas[prd,'EOther'] and t.val > tBF_calib_End.val and d1Prod[prd,sp,t] and d1Prod[prd,sp,tBF_calib_end] and not (sameas[sp,'49509'] or sameas[sp,'0600a']))
# E_pE_Trans_elongate
		pProd$(tx0[t] and sameas[prd,'Etrans'] and t.val > tBF_calib_end.val and d1Prod[prd,sp,t] and d1Prod[prd,sp,tBF_calib_End] and not (sameas[sp,'49509'] or sameas[sp,'0600a']))
# E_qE_Trans_elongate
		qProd$(tx0[t] and sameas[prd,'Etrans'] and t.val > tBF_calib_end.val and d1Prod[prd,sp,t] and d1Prod[prd,sp,tBF_calib_End] and not (sameas[sp,'49509'] or sameas[sp,'0600a']))

	#Agriculture 
		#  pAni$(tx0[t] and t.val>tBF_calib_start.val and tBF_calib[t] and d1Ani[ani_sectors,ani_,t] and sameas[ani_,'otherenergy'])
		#  pPlant$(tx0[t] and t.val>tBF_calib_start.val and tBF_calib[t] and d1Plant[plant_sectors,plant_,t] and sameas[plant_,'otherenergy'])

		#  qAni$(tx0[t] and t.val>tBF_calib_start.val and tBF_calib[t] and d1Ani[ani_sectors,ani_,t] and sameas[ani_,'otherenergy'])
		#  qPlant$(tx0[t] and t.val>tBF_calib_start.val and tBF_calib[t] and d1Plant[plant_sectors,plant_,t] and sameas[plant_,'otherenergy'])

	#CES-shares
		# Quantities of energy activity
#  # E_qREa_tBF_calib  not bunkering
#  E_qRE_trans_tBF_calib 
#  E_qREa_off_tBF_calib 
#  E_qRE_natgas_tBF_calib 
#  E_qRE_biogas_tBF_calib 
#  E_qRE_DataCentre_tBF_calib
#  E_qRE_CrudeOilToRefineries_tBF_calib
				# qREa og uRE bytter plads i qRE-ligningerne i production.gms i kalibreringsår
				uRE$(tx0[t] and tBF_calib[t] and t.val > tBF_calib_start.val and d1pREa[purpose,energy19a,s,t] and not bunkering[energy19a])# and not sameas[s,'35012'])
				# uRE bestemmes af E_uRE_forecast efter sidste kalibreringsår
# E_uRE_forecast_premodel_extra
				uRE$(tx0[t] and t.val > tBF_calib_end.val and d1pREa[purpose,energy19a,s,t] and not bunkering[energy19a] and not sameas[s,'35012'])
				# For bunkering bestemmes qREa i alle år af qRE-ligningerne i production.gms
# E_qREa_tBF_calib  bunkering
				qREa$(tx0[t] and tBF_calib[t] and t.val > tBF_calib_start.val and d1pREa[purpose,energy19a,s,t] and bunkering[energy19a]) 

			#  ##Budget shares for purposes. We introduce chain-indices for quantities and endogenize budget-shares (E_uEP_ and E_uEP_new)
# E_qEP_off_tBF_calib
				uEP_off$(tx0[t] and t.val > tBF_calib_Start.val and tBF_calib[t] and d1EP[purpose,'off',t] and not d1EP_new[purpose,'off',t])
				uEP_off$(tx0[t] and t.val > tBF_calib_Start.val and tBF_calib[t] and d1EP_new[purpose,'off',t] )
#  E_uEP_forecast_off_premodel_extra
				uEP_off$(tx0[t] and t.val > tBF_calib_End.val and d1EP[purpose,'off',t])

# E_qEP_tBF_calib E_qEP_trans_tBF_calib 
				uEP$(tx0[t] and t.val > tBF_calib_Start.val and tBF_calib[t] and d1EP[purpose,sp,t] and not d1EP_new[purpose,sp,t] and not (sameas[sp,'49509'] or sameas[sp,'0600a']))
				uEP$(tx0[t] and t.val > tBF_calib_Start.val and tBF_calib[t] and d1EP[purpose,sp,t] and d1EP_new[purpose,sp,t] and not (sameas[sp,'49509'] or sameas[sp,'0600a']))
# E_uEP_forecast_premodel_extra,,
				uEP$(tx0[t] and t.val > tBF_calib_End.val and d1EP[purpose,sp,t] and not (sameas[sp,'49509'] or sameas[sp,'0600a'] or agri_sectors[sp]))
#  E_uEP_forecast_agrisectors
				uEP$(tx0[t] and t.val > tBF_calib_End.val and d1EP[purpose,sp,t] and agri_sectors[sp] and not (sameas[sp,'49509'] or sameas[sp,'0600a']))
			#  #Budget shares for energy 
# E_qProd_map_notUlt_tBF_calib  Eother
# E_uE_forecast 
					uProd$(tx0[t] and sameas[prd,'EOther'] and t.val> tBF_calib_start.val and d1Prod[prd,sp,t] and not (sameas[sp,'0600a'] or sameas[sp,'49509']))
# E_qProd_map_notUlt_tBF_calib Etrans
# E_uETrans_forecast 
					uProd$(tx0[t] and sameas[prd,'Etrans'] and t.val > tBF_calib_start.val and d1Prod[prd,sp,t] and not (sameas[sp,'0600a'] or sameas[sp,'49509']))
#  E_qEOff_tBF_calib
#  , E_uEOFF_forecast 
					uEOFF$(tx0[t] and t.val>tBF_calib_start.val)
;

#  $FIX G_premodel_chaindices_exo;
#  $UNFIX G_premodel_chainindices_endo;
#   execute_unload 'output\pre_chain.gdx';
#  @SOLVE(M_premodel_chainindices);
#   execute_unload 'output\post.gdx';
#  $UNFIX G_premodel_chaindices_exo;


# ---------------------------------------------------------------------------------------------------------------- 
# Third pre-model 
# ----------------------------------------------------------------------------------------------------------------

	$GROUP G_adjustpricesthroughdatayears
		adjLinearly[purpose,energy19,r] ""

	;

	set thesesecon[s]/set.s/;
	thesesecon['49509'] = no; thesesecon['0600a'] = no; thesesecon['01020'] = no;

	set thesesecprice[s]/set.s/;
	set thesesec_short[s]/set.s/;
	set thesesec_long[s];
	thesesec_short['01020'] = no;
	thesesec_long[s]        = yes$(not thesesec_short[s]);

	thesesecprice['35011']  = yes;
	#  thesesecprice['23001']  = yes;
	#  thesesecprice['53000']  = yes;
	#  thesesecprice['23001']  = yes;


PARAMETER theseLinearly[purpose,energy19,r,t];
theseLinearly[purpose,energy19,r,t] = yes;
theseLinearly[purpose,energy19,r,t]$(d1pREgj[purpose,energy19,r,'2030']=0) = no; #The method of putting a linear trend in marginal prices so far does not extend properly to combinations of energy use that end before 2030
$SETGLOBAL endhere 2026
$setglobal endhere_long 2026

$IF %calibvtCALIB%:
	#We add elements to d1tRE to add calibENS to prices where there currently are no taxes on energy goods (i.e. cases where d1pRE_base is on, but d1tRE is not. Consider an alternative method of adding vtCalibENS to marginal prices directly)
	d1tRE[purpose,energy19,r,t]$(t.val > 2019 and t.val<%endhere% and thesesecon[r] and not thesesec_long[r] and d1pREgj[purpose,energy19,r,t] and not eNotInEnergyNest[purpose,energy19,r,t] and theseLinearly[purpose,energy19,r,t]) = yes;
	d1tRE[purpose,energy19,r,t]$(t.val > 2019 and t.val<%endhere_long% and thesesecon[r] and thesesec_long[r] and d1pREgj[purpose,energy19,r,t] and not eNotInEnergyNest[purpose,energy19,r,t] and theseLinearly[purpose,energy19,r,t]) = yes;
$ENDIF

	$BLOCK B_premodel 
	    E_qAGG_y_calib_pre[energy19,s,t]$(tx0[t] and tBF_calib[t] and d1vY_CET[energy19,s,t] and not d1vE_onesupplier[energy19,t]).. 
	      sY_AGG[energy19,s,t] =E= qY_CET[energy19,s,t]/qEtot[energy19,t] * pY_CET[energy19,s,t]**eAGG(energy19);

	    E_qAGG_m_calib_pre[energy19,s,t]$(tx0[t]  and tBF_calib[t] and d1vM_CET[energy19,s,t] and not d1vE_onesupplier[energy19,t]).. 
	      sM_AGG[energy19,s,t] =E= qM_CET[energy19,s,t]/qEtot[energy19,t] * pM_CET[energy19,s,t]**eAGG(energy19);

	    E_sY_AGG_forecast_pre[energy19,s,t]$(tx0[t] and t.val > tBF_calib_End.val and d1vY_CET[energy19,s,t] and not d1vE_onesupplier[energy19,t]).. 
	      sY_AGG[energy19,s,t] =E= sY_AGG[energy19,s,t-1];

	  	E_sM_AGG_forecast_pre[energy19,s,t]$(tx0[t] and t.val > tBF_calib_End.val and d1vM_CET[energy19,s,t] and not d1vE_onesupplier[energy19,t]).. 
	      sM_AGG[energy19,s,t] =E= sM_AGG[energy19,s,t-1];


	   	E_uAni_otherenergy_ani_calib_after2035[ani_sectors,t]$(tx0[t] and t.val > tBF_calib_end.val and d1Ani[ani_sectors,'OtherEnergy',t])..
			pAni[Ani_sectors,'OtherEnergy',t-1]*qAni[Ani_sectors,'OtherEnergy',t] =E= sum(purpose_xtint$(d1EP[purpose_xtint,ani_sectors,t]), pEP[purpose_xtint,ani_sectors,t-1] * qEP[purpose_xtint,ani_sectors,t]); 

	   	E_uPlant_otherenergy_plant_calib_after2035[plant_sectors,t]$(tx0[t] and t.val > tBF_calib_end.val and d1Plant[plant_sectors,'OtherEnergy',t])..
			pPlant[plant_sectors,'OtherEnergy',t-1]*qPlant[plant_sectors,'OtherEnergy',t] =E= sum(purpose_xtint$(d1EP[purpose_xtint,plant_sectors,t]), pEP[purpose_xtint,plant_sectors,t-1] * qEP[purpose_xtint,plant_sectors,t]); 

		$IF %shutdownnorthsea%:
		E_qM_CET_northsea[energy19,t]$(tx0[t] and t.val>= tShutNorthSeaStart.val and d1vY_CET[energy19,'0600a',t]).. #Læg mærke til at d1vY_CET benyttes
			qM_CET[energy19,'19000',t] =E= qEtot[energy19,t]-qY_CET[energy19,'0600a',t];
		$ENDIF 

	   $IF %calibvtCALIB%:

	   #If prices are computed on a shorter timeline
	   	   #We can adjust prices linearly. Currently prices are adjusted linearly
		   E_vtCalib_LINEARLY_short[purpose,energy19,r,t]$(tx0[t] and t.val > 2019 and t.val<=%endhere% and thesesecon[r] 
		   																								and not thesesec_long[r]
		   																								and theseLinearly[purpose,energy19,r,t] 
		   																								and thesesecprice[r] and d1pREgj[purpose,energy19,r,t] and not eNotInEnergyNest[purpose,energy19,r,t]
		   																								)..  #and sameas[purpose,'process_normal'] and sameas[energy19,'electricity'])..
		   	pREgj[purpose,energy19,r,t]  =E= pREgj[purpose,energy19,r,t-1] + adjLinearly[purpose,energy19,r];

		   #Or budgets. 
		   E_vtCalib_LINEARLY_budget_short[purpose,energy19,r,t]$(tx0[t] and t.val > 2019 and t.val<=%endhere% and thesesecon[r] 
		   																									   and not thesesec_long[r]
		   																									   and theseLinearly[purpose,energy19,r,t] 
		   																									   and not thesesecprice[r] and d1pREgj[purpose,energy19,r,t] and not eNotInEnergyNest[purpose,energy19,r,t]
		   																									   )..  #and sameas[purpose,'process_normal'] and sameas[energy19,'electricity'])..
		   	pREgj[purpose,energy19,r,t] * qREgj[purpose,energy19,r,t] =E= pREgj[purpose,energy19,r,t-1] * qREgj[purpose,energy19,r,t-1] + adjLinearly[purpose,energy19,r];


		#If prices are computed on a longer timeline. Currently long/short is same end year  
		   E_vtCalib_LINEARLY_long[purpose,energy19,r,t]$(tx0[t] and t.val > 2019 and t.val<=%endhere_long% and thesesecon[r]
		   																								    and thesesec_long[r]
		   																								    and theseLinearly[purpose,energy19,r,t] 
		   																								    and thesesecprice[r] and d1pREgj[purpose,energy19,r,t] and not eNotInEnergyNest[purpose,energy19,r,t]
		   																								    )..  #and sameas[purpose,'process_normal'] and sameas[energy19,'electricity'])..
		   	pREgj[purpose,energy19,r,t]  =E= pREgj[purpose,energy19,r,t-1] + adjLinearly[purpose,energy19,r];

		   E_vtCalib_LINEARLY_budget_long[purpose,energy19,r,t]$(tx0[t] and t.val > 2019 and t.val<=%endhere_long% and thesesecon[r]
		   																										   and thesesec_long[r]
		   																										   and theseLinearly[purpose,energy19,r,t]
		   																										   and not thesesecprice[r] and d1pREgj[purpose,energy19,r,t] and not eNotInEnergyNest[purpose,energy19,r,t]
		   																										   )..  #and sameas[purpose,'process_normal'] and sameas[energy19,'electricity'])..
		   	pREgj[purpose,energy19,r,t] * qREgj[purpose,energy19,r,t] =E= pREgj[purpose,energy19,r,t-1] * qREgj[purpose,energy19,r,t-1] + adjLinearly[purpose,energy19,r];

	   $ENDIF

	$ENDBLOCK

	$BLOCK B_copy 
		$LOOP00 E_qProd_map_notUlt:
			{name}_copy{sets}$({conditions} and (sameas[prd,'EOther'] or sameas[prd,'Etrans'])).. {LHS} =E= {RHS};
		$ENDLOOP00
	$ENDBLOCK

	$MODEL M_premodel 
		# B_premodel
		 E_qAGG_y_calib_pre
		 E_sY_AGG_forecast_pre
		 E_qAGG_m_calib_pre
		 E_sM_AGG_forecast_pre

		$IF %shutdownnorthsea%:
	    #Nordsø
  	 	E_qM_CET_northsea
     	E_qY_CET_northsea
     	E_qY_CET_northsea_aftertShutNorthSeaEnd
		$ENDIF

  	$IF %calibvtCALIB%:
		E_vtCalib_LINEARLY_short
		E_vtCalib_LINEARLY_budget_short
		E_vtCalib_LINEARLY_long
		E_vtCalib_LINEARLY_budget_long
		$ENDIF

		M_taxes_calib
		M_taxes_energy_calib
		M_emissions_calib
		B_KF_calib_emmi
		M_energy_prices

		B_energy_margins,-E_vOtherDistributionProfits_EAV,-E_vOtherDistributionProfits_DAV,-E_vOtherDistributionProfits_CAV

		M_Avancer

		# Prices of energy activity
			E_pREa 				# Modelligning (production.gms)
			E_pREa_off


	    # Quantities of energy activity
		    E_qREa 				  # Modelligning (production.gms)
		    E_qRE_trans 		  # Modelligning (production.gms)
		    E_qREa_off 			  # Modelligning (production.gms)
		    E_qRE_natgas 		  # Modelligning (production.gms)
		    E_qRE_biogas 		  # Modelligning (production.gms)
		    E_qRE_DataCentre 	  # Modelligning (production.gms)
		    E_qRE_CrudeOilToRefineries
		    E_uRE_forecast 		  # Kalibreringsligning
		    E_qRE_el			  # Modelligning (production.gms) 

	    # Quantities of energy purpose (must be run together with price equations, E_pEP etc..)
	      E_qEP 		  # Modelligning (production.gms)
	      E_qEP_trans 	  # Modelligning (production.gms)
	      E_qEP_off 	  # Modelligning (production.gms)

	    # Prices of energy purpose
	      E_pEP 
	      E_pEP_trans
	      E_pEP_off   #

	    #Budget shares for purposes
	      E_uEP_forecast
	      E_uEP_forecast_off
		   E_uEP_forecast_agrisectors # We only forecast uEP for non-ani sectors, because uEP is used in link with agr-production 
	      E_uEP_ 		  # qEP bestemmes endogent i kalibreringsår af kalibreringsligning
	      E_uEP_new 	# qEP bestemmes endogent i kalibreringsår af kalibreringsligning

	    #Quantities of energy and transport-energy 
		  #  E_qE 
		  #  E_qEOFF
		  #  E_qEtrans
		  E_qEOFF
		  E_qProd_map_notUlt_copy

	    #Prices of energy, and transport-energy 
	      E_pE_CGE 
	      E_pE_CGE_off
	      E_pEtrans

	    #Budget shares 
	      E_uE_notoff, E_uE_forecast
	      E_uETrans, E_uETrans_forecast
	      E_uE_off, E_uEOFF_forecast

		 # Ani OtherEnergy
	   	 E_qRE_otherenergy_ani #uOtherEnergy_ani frem til 2035, efter 2035 bestemmer 
			 E_pRE_otherenergy_ani #pAni[otherenergy]
	   	 E_uAni_otherenergy_ani_calib #qAni[otherenergy] 	# From B_premodel
	     E_uAni_otherenergy_ani_calib_after2035			# From B_premodel

		 # Plant OtherEnergy 
	     E_qRE_otherenergy_plant
	     E_pRE_otherenergy_plant 
	     E_uPlant_otherenergy_plant_calib 			# From B_premodel
	     E_uPlant_otherenergy_plant_calib_after2035 # From B_premodel

	   #

;

	$GROUP G_premodel_exo 
		# E_qAGG_y_calib_pre and E_sY_AGG_forecast_pre
			qY_CET$(tx0[t] and energy19[out] and d1vY_CET[out,s,t])
			qEtot$(tx0[t] and sum(s, d1vY_CET[energy19,s,t] and not d1vE_onesupplier[energy19,t]))
			pY_CET$(tx0[t] and energy19[out] and d1vY_CET[out,s,t])
		# E_qAGG_m_calib_pre and E_sM_AGG_forecast_pre
			qM_CET$(tx0[t] and energy19[out] and d1vM_CET[out,s,t])
			qEtot$(tx0[t] and sum(s, d1vM_CET[energy19,s,t] and not d1vE_onesupplier[energy19,t]))
			pM_CET$(tx0[t] and energy19[out] and d1vM_CET[out,s,t])
			$IF %shutdownnorthsea%:
		# E_qM_CET_northsea
			qEtot$(tx0[t] and t.val >= tShutNorthSeaStart.val) # and sum(s$(sameas[s,'0600a']), d1vY_CET[energy19,s,t]))
			qY_CET$(tx0[t] and t.val >= tShutNorthSeaStart.val and d1vY_CET[out,s,t] and energy19[out] and sameas[s,'0600a'])

		# E_qY_CET_northsea and E_qY_CET_northsea_aftertShutNorthSeaEnd
			qY_CET$(d1vY_CET[out,s,t] and energy19[out] and sameas[s,'0600a'] and t.val=tShutNorthSeaStart.val-1)
		 $ENDIF 

		# E_vtCALIBENS 
			# pRE_base$(tx0[t] and not sameas[r,'01020'] and (d1pRE_base[purpose,energy19,r,t] or d1pREown[purpose,energy19,r,t]) and not eNotInEnergyNest[purpose,energy19,r,t] and t.val>2019 and t.val <%endhere_long% and thesesecon[r])
			# qREgj$(tx0[t] and not sameas[r,'01020'] and (d1pRE_base[purpose,energy19,r,t] or d1pREown[purpose,energy19,r,t]) and not eNotInEnergyNest[purpose,energy19,r,t] and t.val>2019 and t.val <%endhere_long% and thesesecon[r])
			pRE_base$(tx0[t] and (d1pRE_base[purpose,energy19,r,t] or d1pREown[purpose,energy19,r,t]) and not eNotInEnergyNest[purpose,energy19,r,t] and t.val>2019 and t.val <%endhere_long% and thesesecon[r])
			qREgj$(tx0[t] and (d1pRE_base[purpose,energy19,r,t] or d1pREown[purpose,energy19,r,t]) and not eNotInEnergyNest[purpose,energy19,r,t] and t.val>2019 and t.val <%endhere_long% and thesesecon[r])
			
			pREgj$(not d1qREgj[purpose,energy19,r,t] and d1qREgj[purpose,energy19,r,t+1])
			qREgj$(d1qREgj[purpose,energy19,r,t] or d1qREgj[purpose,energy19,r,t+1])


			G_taxes_calib_Exo
			G_taxes_energy_calib_exo 
			G_emissions_calib_exo 
			sBioNatgas  # Add to exo-group of G_emissions_calib_exo
			sBionatgasC # Add to exo-group of G_emissions_calib_exo

			G_IO_exo
			G_energy_demand_prices_exo
			G_energy_markets_margins_exo, vOtherDistributionProfits_EAV, vOtherDistributionProfits_DAV, vOtherDistributionProfits_CAV

			# Prices of energy activity
			# E_pREa
			j_pREa$(d1pREa[purpose,energy19a,s,t])

			# Quantities of energy activity
			# qREa og uRE bytter plads i qRE-ligningerne i production.gms i kalibreringsår
			-uRE$(tx0[t] and tBF_calib[t] and t.val > tBF_calib_start.val and d1pREa[purpose,energy19a,s,t] and not bunkering[energy19a]), qREa$(tx0[t] and t.val > tBF_calib_start.val and tBF_calib[t] and d1pREa[purpose,energy19a,s,t] and not bunkering[energy19a])
			# qREa bestemmes af qRE-ligningerne i production.gms efter sidste kalibreringsår
			-qREa$(tx0[t] and t.val > tBF_calib_end.val and d1pREa[purpose,energy19a,s,t] and not bunkering[energy19a])
			# uRE bestemmes af E_uRE_forecast efter sidste kalibreringsår
			-uRE$(tx0[t] and t.val > tBF_calib_end.val and d1pREa[purpose,energy19a,s,t] and not bunkering[energy19a])
			# For bunkering bestemmes qREa i alle år af qRE-ligningerne i production.gms
			-qREa$(tx0[t] and d1pREa[purpose,energy19a,s,t] and bunkering[energy19a])
			-qREa$(tx0[t] and d1pREa[purpose,energy19a,s,t] and sameas[s,'35012'] and sameas[purpose,'process_special'] and sameas[energy19a,'el from y and m'])   #Tilføjet
		 	pEP$(d1EP[purpose,s,t]) 					# pEP er eksogen i qRE-ligningerne (endogeniseres nedenfor)
		 	qEP$(d1EP[purpose,s,t]) 					# qEP er eksogen i qRE-ligningerne (endogeniseres nedenfor)
			qY_CETgross$(d1vY_CET[out,s,t] and sameas[out,'Natural gas incl. biongas']) # E_qRE_natgas
			qKELBM$(tx0[t] and sameas[s,'19000'])                                       # E_qRE_CrudeOilToRefineries


		#Quantities of energy purpose 
			#  pEP$(tx0[t] and d1EP[purpose,s,t]), uEP$(tx0[t] and d1EP[purpose,s,t] and not (d1EP['transport',s,t] or d1EP['intern_trans',s,t]))          #E_qEP 
			pEP$(tx0[t] and d1EP[purpose,s,t]), uEP$(tx0[t] and d1EP[purpose,sp,t] and not (d1EP['transport',sp,t] or d1EP['intern_trans',sp,t]))          #E_qEP  
			uEP_off$(tx0[t] and d1EP[purpose,'off',t] and not (d1EP['transport','off',t] or d1EP['intern_trans','off',t])) 
			pE_CGE$(d1E[s,t] and sameas[s,'off'])   	# pE_CGE er eksogen i qEP-ligningerne
			pProd$(sameas[prd,'EOther'] and d1Prod[prd,sp,t])   	# pE_CGE er eksogen i qEP-ligningerne
			qE$(d1E[s,t] and sameas[s,'off']) 		    # qE er eksogen i qEP-ligningerne 
			qProd$(sameas[prd,'EOther'] and d1Prod[prd,sp,t]) 		    # qE er eksogen i qEP-ligningerne 
			qProd$(sameas[prd,'Etrans'] and d1Prod[prd,sp,t]), uEP$(tx0[t] and (d1EP['transport',sp,t] or d1EP['intern_trans',sp,t]))
			uEP_off$(tx0[t] and (d1EP['transport','off',t] or d1EP['intern_trans','off',t]))  	# qEtrans er eksogen i qEP-ligningerne 
			pProd$(sameas[prd,'Etrans'] and d1Prod[prd,sp,t])

		# Quantities of energy purpose
		 #  	pEP$(tx0[t] and d1EP[purpose,s,t]) 			# pEP er eksogen i qEP-ligningerne (endogeniseres nedenfor)
			#  pE_CGE$(sum(purpose, d1EP[purpose,s,t])) 	# pE_CGE er eksogen i qEP-ligningerne
			#  qE$(sum(purpose, d1EP[purpose,s,t])) 		# qE er eksogen i qEP-ligningerne 
			#  qEtrans$(sum(purpose, d1EP[purpose,s,t])) 	# qEtrans er eksogen i qEP-ligningerne 
		 	pEP$(tx0[t] and d1EP[purpose,s,t]) 			# pEP er eksogen i qEP-ligningerne (endogeniseres nedenfor)
			pE_CGE$(sum(purpose, d1EP[purpose,'off',t])) 	# pE_CGE er eksogen i qEP-ligningerne
			pProd$(sameas[prd,'EOther'] and sum(purpose, d1EP[purpose,sp,t])) 	# pE_CGE er eksogen i qEP-ligningerne
			qE$(sum(purpose, d1EP[purpose,'off',t])) 		# qE er eksogen i qEP-ligningerne 
			qProd$(sameas[prd,'EOther'] and sum(purpose, d1EP[purpose,sp,t])) 		# qE er eksogen i qEP-ligningerne 
			qProd$(sameas[prd,'Etrans'] and sum(purpose, d1EP[purpose,sp,t])) 	# qEtrans er eksogen i qEP-ligningerne 

		# E_uEP_new
			qEP$(d1EP[purpose,s,t+1] and not d1EP[purpose,s,t] and not (sameas[s,'49509'] or sameas[s,'0600a']))
			pREa$(t0[t])
			pREa$(d1pREa[purpose,energy19a,s,t+1] and not d1pREa[purpose,energy19a,s,t])
		# E_pEP
			pEP$(t0[t])
		 	pEP$(d1EP[purpose,s,t+1] and not d1EP[purpose,s,t] and not (sameas[s,'49509'] or sameas[s,'0600a'])) # I første år med nyt energiforbrug eksogeniseres prisen, så prisligningen bestemmer mængden


	 	 #  pE_CGE$(d1E[s,t+1] and not d1E[s,t])

	 	 #  pEtrans$(d1Etrans[s,t+1] and not d1Etrans[s,t])
	 	 pE_CGE$(d1E[s,t+1] and not d1E[s,t])
	 	 pProd$(sameas[prd,'EOther'] and d1Prod[prd,sp,t+1] and not d1Prod[prd,sp,t])

	 	 pProd$(sameas[prd,'Etrans'] and d1Prod[prd,sp,t+1] and not d1Prod[prd,sp,t])



	 	#  #E_qE 
	 	#  pMKE$(tx0[t]), qMKE$(tx0[t])
	 	#  #E_qEtrans
	 	#  pTKE$(tx0[t]), qTKE$(tx0[t])
	 	#E_qE 
	 	pProd$(tx0[t] and sameas[prd,'MKE']), qProd$(tx0[t] and sameas[prd,'MKE'])
	 	#E_qEtrans
	 	pProd$(tx0[t] and sameas[prd,'TKE']), qProd$(tx0[t] and sameas[prd,'TKE'])
	 	#E_qEoff
	 	pR, qR

	 	#Other energy in production_agr
		qAni$(tx0[t] and t.val <= tBF_calib_start.val and d1Ani[ani_sectors,ani_,t] and sameas[ani_,'OtherEnergy'])
		qPlant$(tx0[t] and t.val <=tBF_calib_start.val and d1Plant[plant_sectors,plant_,t] and sameas[plant_,'OtherEnergy'])
			uRE$(tx0[t] and d1pREa[purpose,energy19a,s,t] and sameas[s,'35012'] and sameas[purpose,'process_special'] and sameas[energy19a,'el from y and m'])

				qXE['unspecified','natural gas incl. biongas',t]

	;

	$GROUP G_premodel_endo 
		 # E_qAGG_y_calib_pre and E_sY_AGG_forecast_pre
			 sY_AGG$(tx0[t] and d1vY_CET[energy19,s,t] and not d1vE_onesupplier[energy19,t])
		 # E_qAGG_m_calib_pre and E_sM_AGG_forecast_pre
			 sM_AGG$(tx0[t] and d1vM_CET[energy19,s,t] and not d1vE_onesupplier[energy19,t])

			$IF %shutdownnorthsea%:
		 # E_qM_CET_northsea
			 qM_CET$(tx0[t] and t.val>= tShutNorthSeaStart.val and d1vY_CET[out,s,t] and energy19[out] and sameas[s,'0600a'])

	 	 #Northsea
		 	 qY_CET$(d1vY_CET[out,s,t] and energy19[out] and sameas[s,'0600a'] and t.val>=tShutNorthSeaStart.val)
		 	 qM_CET$(d1vY_CET[out,'0600a',t] and energy19[out] and sameas[s,'19000'] and t.val>=tShutNorthSeaStart.val)
			$ENDIF


		 	$IF %calibvtCALIB%:

			tCalibENS$(tx0[t] and t.val > 2019 and t.val<%endhere% and thesesecon[r] and not thesesec_long[r] and d1pREgj[purpose,energy19,r,t] and not eNotInEnergyNest[purpose,energy19,r,t] and theseLinearly[purpose,energy19,r,t])  #and sameas[purpose,'process_normal'] and sameas[energy19,'electricity'])
			tCalibENS$(tx0[t] and t.val > 2019 and t.val<%endhere_long% and thesesecon[r] and thesesec_long[r] and d1pREgj[purpose,energy19,r,t] and not eNotInEnergyNest[purpose,energy19,r,t] and theseLinearly[purpose,energy19,r,t])  #and sameas[purpose,'process_normal'] and sameas[energy19,'electricity'])

			$ENDIF


			G_taxes_calib
			G_taxes_energy_calib 
			G_emissions_calib

			#Emissions
			uEmmProdxE$(tx0[t] and t.val>tBF_calib_start.val and sum(sCRF, thesesCRF[sCRF] and sCRF_2_sENS2GR_xE(sCRF,s,emm) and KF_emm_[emm,sCRF,t] and d1EmmProdxE[s,t,emm]))
			uEmmConsxE$(tx0[t] and t.val>tBF_calib_start.val and sum(sCRF, thesesCRF[sCRF] and sCRF_2_sENS2GR_xE(sCRF,'68203',emm) and KF_emm_[emm,sCRF,t] and d1EmmConsxE[t,emm]))
	    qEmmDomesticAviationDCE$(t.val > tBF_calib_start.val and KF_emm_['CO2e','Domestic aviation',t])
    	jEmmTot_UNFCCC_LULUCF_Calib2KF$(tx0[t] and t.val > tBF_calib_start.val)

		G_energy_demand_prices_endo
		G_energy_markets_margins_endo, -vOtherDistributionProfits_EAV,-vOtherDistributionProfits_DAV,-vOtherDistributionProfits_CAV

		G_avancer_endo

		# Prices of energy activity
		pREa$(tx0[t] and d1pREa[purpose,energy19a,s,t])
		
		# Quantities of energy activity
			# I første modelår (2019) bestemmes qREa af qRE-ligninger
			qREa$(t1[t] and d1pREa[purpose,energy19a,s,t] and not bunkering[energy19a]) 
			# qREa og uRE bytter plads i qRE-ligningerne i production.gms i kalibreringsår
			uRE$(tx0[t] and tBF_calib[t] and t.val > tBF_calib_start.val and d1pREa[purpose,energy19a,s,t] and not bunkering[energy19a]), -qREa$(tx0[t] and t.val > tBF_calib_start.val and tBF_calib[t] and d1pREa[purpose,energy19a,s,t] and not bunkering[energy19a])
			# qREa bestemmes af qRE-ligningerne i production.gms efter sidste kalibreringsår
			qREa$(tx0[t] and t.val > tBF_calib_end.val and d1pREa[purpose,energy19a,s,t] and not bunkering[energy19a])
			# uRE bestemmes af E_uRE_forecast efter sidste kalibreringsår
			uRE$(tx0[t] and t.val > tBF_calib_end.val and d1pREa[purpose,energy19a,s,t] and not bunkering[energy19a])
			# For bunkering bestemmes qREa i alle år af qRE-ligningerne i production.gms
			qREa$(tx0[t] and d1pREa[purpose,energy19a,s,t] and bunkering[energy19a]) 
			# For eldistribution bestemmes qREa i alle år af qRE-ligningerne i production.gms

			-uRE$(tx0[t] and d1pREa[purpose,energy19a,s,t] and sameas[s,'35012'] and sameas[purpose,'process_special'] and sameas[energy19a,'el from y and m'])

			qREa$(tx0[t] and d1pREa[purpose,energy19a,s,t] and sameas[s,'35012'] and sameas[purpose,'process_special'] and sameas[energy19a,'el from y and m'])


		##Quantities of energy purpose (E_qEP in production.gms)
			qEP$(tx0[t] and d1EP[purpose,s,t] and  (sameas[purpose,'transport'] or sameas[purpose,'intern_trans']) and not sameas[s,'off']) #E_qEP_trans i production.gms
			qEP$(tx0[t] and d1EP[purpose,s,t] and not (sameas[purpose,'transport'] or sameas[purpose,'intern_trans']) and not sameas[s,'off']) #E_qEP i production.gms
			qEP$(tx0[t] and d1EP[purpose,s,t] and sameas[s,'off']) #E_qEP_off i production.gms

		##Prices of energy purpose (E_pEP in production.gms)
 			pEP$(tx0[t] and d1EP[purpose,s,t] and  (sameas[purpose,'transport'] or sameas[purpose,'intern_trans']) and not sameas[s,'off']) #E_qEP_trans i production.gms
  			pEP$(tx0[t] and d1EP[purpose,s,t] and not (sameas[purpose,'transport'] or sameas[purpose,'intern_trans']) and not sameas[s,'off']) #E_qEP i production.gms
	  		pEP$(tx0[t] and d1EP[purpose,s,t] and sameas[s,'off']) #E_qEP_off i production.gms

		##Budget shares for purposes. We introduce chain-indices for quantities and endogenize budget-shares (E_uEP_ and E_uEP_new)
			uEP_off$(tx0[t] and t.val > tBF_calib_Start.val and tBF_calib[t] and d1EP[purpose,'off',t] and not d1EP_new[purpose,'off',t])
			uEP_off$(tx0[t] and t.val > tBF_calib_Start.val and tBF_calib[t] and d1EP[purpose,'off',t] and d1EP_new[purpose,'off',t])

			uEP_off$(tx0[t] and t.val > tBF_calib_End.val and d1EP[purpose,'off',t])

			uEP$(tx0[t] and t.val > tBF_calib_Start.val and tBF_calib[t] and d1EP[purpose,sp,t] and not d1EP_new[purpose,sp,t] and not (sameas[sp,'49509'] or sameas[sp,'0600a']))
			uEP$(tx0[t] and t.val > tBF_calib_Start.val and tBF_calib[t] and d1EP[purpose,sp,t] and d1EP_new[purpose,sp,t] and not (sameas[sp,'49509'] or sameas[sp,'0600a']))

			uEP$(tx0[t] and t.val > tBF_calib_End.val and d1EP[purpose,sp,t] and not (sameas[sp,'49509'] or sameas[sp,'0600a'] or agri_sectors[sp]))
			uEP$(tx0[t] and t.val > tBF_calib_End.val and d1EP[purpose,sp,t] and agri_sectors[sp] and not (sameas[sp,'49509'] or sameas[sp,'0600a']))
			#First year of new energy is exogenized 
			-pEP$(tx0[t] and t.val > tBF_calib_start.val and tBF_calib[t] and d1EP_new[purpose,s,t] and not d1EP_new[purpose,s,t-1] and not (sameas[s,'49509'] or sameas[s,'0600a'])) 

		#Quantities of energy
		   qE$(tx0[t] and d1E[s,t] and sameas[s,'off']) #E_qE
		   qProd$(tx0[t] and sameas[prd,'EOther'] and d1Prod[prd,sp,t]) #E_qE
		   qProd$(tx0[t] and sameas[prd,'Etrans'] and d1Prod[prd,sp,t]) #E_qEtran

		#Prices of energy s
			 pE_CGE$(tx0[t] and d1E[s,t] and sameas[s,'off'])
			 pProd$(tx0[t] and sameas[prd,'EOther'] and d1Prod[prd,sp,t])
			 pProd$(tx0[t] and sameas[prd,'Etrans'] and d1Prod[prd,sp,t])

		#Budget shares for energy 
				#  uE$(tx0[t] and t.val> tBF_calib_start.val and d1E[sp,t] and not (sameas[sp,'0600a'] or sameas[sp,'49509']))
				uProd$(tx0[t] and sameas[prd,'EOther'] and t.val> tBF_calib_start.val and d1Prod[prd,sp,t] and not (sameas[sp,'0600a'] or sameas[sp,'49509']))
				uProd$(tx0[t] and sameas[prd,'Etrans'] and t.val> tBF_calib_start.val and d1Prod[prd,sp,t] and not (sameas[sp,'0600a'] or sameas[sp,'49509']))
				uEOFF$(tx0[t] and t.val>tBF_calib_start.val)

	 	 # Ani OtherEnergy 
		 	 pAni$(tx0[t] and d1Ani[ani_sectors,ani_,t] and sameas[ani_,'OtherEnergy'])
		 	 qAni$(tx0[t] and t.val > tBF_calib_start.val and d1Ani[ani_sectors,ani_,t] and sameas[ani_,'OtherEnergy'])
		 	 uOtherEnergy_ani$(tx0[t]) #and t.val > tBF_calib_start.val)

	 	 # Plant OtherEnergy 
		 	 pPlant$(tx0[t] and d1Plant[plant_sectors,plant_,t] and sameas[plant_,'OtherEnergy'])
		 	 qPlant$(tx0[t] and t.val > tBF_calib_start.val and d1Plant[plant_sectors,plant_,t] and sameas[plant_,'OtherEnergy'])
		 	 uOtherEnergy_plant$(tx0[t]) #and t.val > tBF_calib_start.val)

	;

	#  $FIX G_premodel_exo;
	#  $UNFIX G_premodel_endo;
	#  execute_unload 'output\pre.gdx';
	#   @SOLVE(M_premodel,1);
	#  execute_unload 'output\post.gdx';
	#  $exit

	#  $FIX G_dynamic_calibration_exo;
	#  $UNFIX G_dynamic_calibration_endo;
	#  execute_unload 'output\pre.gdx';
	#  @Solve(M_dynamic_calibration_calib2KP_EV);

#=============================================================================================================================================================================================#
# 8) CALIBRATION
		#GROUPS ARE COMPILED
		#THE FULL CALIBRATION MODEL IS SETUP.
#=============================================================================================================================================================================================#

	$MODEL M_dynamic_calibration_KF 
		M_dynamic_calibration_calib2KP_EV
	    -E_qM_CET_onesupplier
	    -E_qY_CET_energy19
	    -E_qM_CET_energy19
	    -E_qTL
	    -E_qRENEWABLE

	    B_CALIB_2_KF
	    B_KF_calib_emmi

			# E_pK_ani_link

	    $IF %calibvtCALIB%:
		    E_vtCalib_LINEARLY_short 
		    E_vtCalib_LINEARLY_budget_short
		    E_vtCalib_LINEARLY_long 
		    E_vtCalib_LINEARLY_budget_long
	    $ENDIF

	    $IF %withoutchainindicesfirms%:
			-E_uRE_forecast
			-E_uEP_
			-E_uEP_new
			-E_uOtherEnergy_ani
			-E_uOtherEnergy_plant
			-E_uAni_trans_forecast
			-E_uPlant_trans_forecast
			-E_uEP_forecast
			-E_uEP_forecast_off
			-E_uE_notoff
			-E_uEtrans
			-E_uE_off
			-E_uE_forecast
			-E_uEtrans_forecast
			-E_uEOFF_forecast
			-E_uAni_otherenergy_ani_calib
			-E_uAni_otherenergy_ani_calib_forecast
			-E_uPlant_otherenergy_plant_calib
			-E_uPlant_otherenergy_plant_calib_forecast
			-E_uAni_trans_forecast
			-E_uPlant_trans_forecast
		$ENDIF

		#  M_iblandingskrav


	   ;

	#    #If we read from previous solution we load endogenous values before we do endo/exo swaps

	 $GROUP G_dynamic_calibration_exo
	 	G_dynamic_calibration_exo 
		pY_CET$(tx0[t] and sameas[s,'53000']), -markup$(sameas[s,'53000'] and tx0[t] and d1vY_CET[out,s,t] and sameas[out,'out_other'])
		pY_CET$(tx0[t] and sameas[s,'51001']), -markup$(sameas[s,'51001'] and tx0[t] and d1vY_CET[out,s,t] and sameas[out,'out_other'])

	 	pY_CET$(tx0[t] and d1vY_CET[out,s,t] and sameas[s,'35011'] and sameas[out,'out_other']), -uY_CET$(tx0[t] and d1vY_CET[out,s,t] and sameas[s,'35011'] and sameas[out,'out_other'])

	 	qY_CET$(tx0[t] and tBF_calib[t] and d1vY_CET[out,s,t] and not sameas[out,'out_other'] and not sameas[out,'WholeAndRetailSaleMarginE'] and not bunkering_o[out]) # and not d1vE_onesupplier_a[out,t])
	 	qM_CET$(tx0[t] and tBF_calib[t] and d1vM_CET[out,s,t] and not sameas[out,'out_other'] and not sameas[out,'WholeAndRetailSaleMarginE'] and not bunkering_o[out]) # and not d1vE_onesupplier_a[out,t])
	 	-sY_AGG$(tx0[t] and d1vY_CET[energy19,s,t] and not d1vE_onesupplier[energy19,t])
	 	-sY_AGG$(tx0[t] and d1vY_CET[energy19,s,t] and (sameas[energy19,'lvn'] or sameas[energy19,'semi-refined oil']))
	 	-sM_AGG$(tx0[t] and d1vM_CET[energy19,s,t] and not d1vE_onesupplier[energy19,t])

	   	qXE$(tx0[t] and tBF_calib[t] and t.val > tBF_calib_Start.val and d1vXE[purpose,energy19,t]), -sXE$(tx0[t] and t.val > tBF_calib_Start.val and d1vXE[purpose,energy19,t]) 
	 	
	   	qTL$(tx0[t] and tBF_calib[t] and d1TL[purpose,energy19,t])

	   	#Prices
		   	$IF %calibKF23_pricesXkraftvarme%:
		   	-markup$(tx0[t] and t.val >=tBF_calib_prices_start.val and d1vY_CET[out,s,t] and d1pY_CET_overlap[out,s,t] and energy19[out] and not sameas[out,'Straw for energy purposes'] and not (sameas[out,'Diesel for transport'] or sameas[out,'Gasoline for transport'] or sameas[out,'Oil products'] or sameas[out,'jet petroleum'] or sameas[out,'Semi-refined oil'] or sameas[out,'Biodiesel'] or sameas[out,'district heat'] or sameas[out,'el from y and m'] or sameas[out,'electricity']))  

		   	pY_CET$(tx0[t] and tBF_calib_prices[t] and d1vY_CET[out,s,t] and d1pY_CET_overlap[out,s,t] and energy19[out] and not (sameas[out,'el from y and m'] or sameas[out,'electricity'] or sameas[out,'district heat'])) # and not sameas[out,'straw for energy purposes'])
		   	-uPlant_CET$(tx0[t] and t.val >= tBF_calib_prices_start.val and d1PLant_CET0[plant_sectors,plant_out,t] and sameas[plant_out,'EnergyStraw'])
		   	$ENDIF
	

		   	-markup$(tx0[t] and t.val >= tBF_calib_prices_start.val and d1vY_CET[out,s,t] and (sameas[out,'el from y and m'] or sameas[out,'district heat']))
		   	 pY_CET$(tx0[t] and tBF_calib_prices[t] and d1vY_CET[out,s,t] and (sameas[out,'el from y and m'] or sameas[out,'district heat']))
			
		  	-markup$(tx0[t] and t.val >= tBF_calib_prices_start.val and d1vY_CET[out,s,t] and sameas[out,'electricity'])
	  		pY_CET$(tx0[t] and tBF_calib_prices[t] and d1vY_CET[out,s,t] and sameas[out,'electricity'])

		   	-pM_CET$(tx0[t] and t.val >tBF_calib_prices_End.val and d1vM_CET[out,s,t] and d1pM_CET_overlap[out,s,t] and energy19[out] and not (sameas[out,'el from y and m'] or sameas[out,'district heat']))
		   	-fpxE$(tx0[t] and t.val >= tBF_calib_prices_start.val and d1vXE[purpose,energy19,t] and sameas[purpose,'unspecified'] and sameas[energy19,'electricity']), pXE_base$(tx0[t] and tBF_calib_prices[t] and d1vXE[purpose,energy19,t] and sameas[purpose,'unspecified'] and sameas[energy19,'electricity'])
		   	-pM_CET$(tx0[t] and t.val >tBF_calib_prices_End.val and d1vM_CET[out,s,t] and (sameas[out,'el from y and m'] or sameas[out,'district heat']))

		$IF %withoutchainindicesfirms%!=1:
	   	#Nederste lag
		   	-uRE$(tx0[t] and t.val > tBF_calib_start.val and d1pREa[purpose,energy19a,s,t])
		   	uRE$(tx0[t] and d1pREa[purpose,energy19a,s,t] and bunkering[energy19a])
		   	qREa$(tx0[t] and t.val > tBF_calib_start.val and d1pREa[purpose,energy19a,s,t]) #Over ekso?
		   	-qREa$(tx0[t] and d1pREa[purpose,energy19a,s,t] and bunkering[energy19a])


	   	#Lag af formål
	   		-uEP_off$(tx0[t] and t.val > tBF_calib_Start.val and d1EP[purpose,'off',t]) #, -pEP$(t0[t] and d1EP[purpose,s,t]), pEP$(tBasis[t] and d1EP[purpose,s,t])
	   		-uEP$(tx0[t] and t.val > tBF_calib_Start.val and d1EP[purpose,sp,t] and not (sameas[sp,'49509'] or sameas[sp,'0600a'])) #, -pEP$(t0[t] and d1EP[purpose,s,t]), pEP$(tBasis[t] and d1EP[purpose,s,t])	   		-uEP$(tx0[t] and t.val > tBF_calib_Start.val and d1EP[purpose,s,t] and not (sameas[s,'49509'] or sameas[s,'0600a'])) #, -pEP$(t0[t] and d1EP[purpose,s,t]), pEP$(tBasis[t] and d1EP[purpose,s,t])
	   		-uOtherEnergy_ani$(tx0[t] and t.val > tBF_calib_Start.val and d1EP[purpose_xtint,ani_sectors,t])
	   		-uOtherEnergy_plant$(tx0[t] and t.val > tBF_calib_Start.val and d1EP[purpose_xtint,plant_sectors,t])
	   		-uAni$(tx0[t] and t.val > tBF_calib_Start.val and d1Ani[ani_sectors,ani_,t] and sameas[ani_,'fuel'])
	   		-uPlant$(tx0[t] and t.val > tBF_calib_Start.val and d1Plant[plant_sectors,plant_,t] and sameas[plant_,'fuel'])

	 	#Lag af energi
		 	#  -uE$(tx0[t] and t.val > tBF_calib_start.val and d1E[sp,t] and not (sameas[sp,'49509'] or sameas[sp,'0600a']))
		 	#  -uEtrans$(tx0[t] and t.val>tBF_calib_start.val and d1Etrans[sp,t] and not (sameas[sp,'49509'] or sameas[sp,'0600a']))
		 	-uProd$(tx0[t] and sameas[prd,'EOther'] and t.val > tBF_calib_start.val and d1Prod['Eother',sp,t] and not (sameas[sp,'49509'] or sameas[sp,'0600a']))
		 	-uProd$(tx0[t] and sameas[prd,'Etrans'] and t.val>tBF_calib_start.val and d1Prod['Etrans',sp,t] and not (sameas[sp,'49509'] or sameas[sp,'0600a']))
		 	-uEOFF$(tx0[t] and t.val > tBF_calib_Start.val)

		 	pEP$(t0[t])
		 	pREgj$(t0[t])
		 	pREgj$(not d1pREgj[purpose,energy19,r,t] and d1pREgj[purpose,energy19,r,t+1])
		 	pREa$(not d1pREa[purpose,energy19a,s,t] and d1pREa[purpose,energy19a,s,t+1])
		 	pEP$(not d1EP[purpose,s,t]), pEP$(d1EP_new[purpose,s,t] and not d1EP_new[purpose,s,t-1])
		 $ENDIF


	   #Forbruger 
		   	qCE$(tx0[t] and t.val > tBF_calib_Start.val and tBF_calib[t] and d1vCE[purpose,energy19,t])
		   	-sCE$(tx0[t] and t.val > tBF_calib_Start.val and d1vCE[purpose,energy19,t])
		   	-sCEPE$(tx0[t] and t.val > tBF_calib_start.val and d1vCEPE[purpose,t])
		   	pCEPE$(tx0[t] and t.val > tBF_calib_start.val and tBF_calib[t] and d1vCEPE[purpose,t])

		   	qRENEWABLE$(d1RENEWABLE[energy19,t] and not d1waste_module[energy19,t])
		   	qRENEWABLE$(tx0[t] and tBF_calib[t] and d1RENEWABLE[energy19,t] and sameas[energy19,'Waste']), -jqRENEWABLEWaste$(tx0[t])

	   	#Avancer og el- og fjernvarmepriser i endelig anvendelse 
	   		-G_avancer_endo

	   	#Iblandingskrav
	        #  G_iblandingskrav_exo

			#  pIt$(tx0[t] and agri_sectors[sp])
			#  -uIt$(tx0[t] and agri_sectors[sp])
			# pProd$(sameas[prd,'TK'] and tx0[t] and agri_sectors[sp])
			# -uProd$(sameas[prd,'TK'] and tx0[t] and agri_sectors[sp])

			pProd$(tx0[t] and sameas[sp,'01020'] and sameas[prd,'TK'])
			-uProd$(tx0[t] and sameas[sp,'01020'] and sameas[prd,'TK'])

			# pIt$(tx0[t] and sameas[sp,'01020']) #, pTKE$(tx0[t] and sameas[sp,'01020']), pMKE$(tx0[t] and sameas[sp,'01020']),-pKE$(tx0[t] and sameas[sp,'01020']) #, pEtrans$(sameas[s,'01020']), pE_CGE$(sameas[s,'01020'])
			# -uIt$(tx0[t] and sameas[sp,'01020']) #, -uTKE$(tx0[t] and sameas[sp,'01020']), -uMKE$(tx0[t] and sameas[sp,'01020']), uKE$(tx0[t] and sameas[sp,'01020']) #, -uEtrans$(sameas[sp,'01020']), -uE$(sameas[sp,'01020'])

			pProd$(tx0[t] and sameas[sp,'01020'] and sameas[prd,'TKE'])
			-uProd$(tx0[t] and sameas[sp,'01020'] and sameas[prd,'TKE'])

			# pTKE$(tx0[t] and sameas[sp,'01020'])
			# -uTKE$(tx0[t] and sameas[sp,'01020'])

			pProd$(tx0[t] and sameas[sp,'01020'] and sameas[prd,'MK'])
			-uProd$(tx0[t] and sameas[sp,'01020'] and sameas[prd,'MK'])

 			# pIm$(tx0[t] and sameas[sp,'01020'])
			# -uIm$(tx0[t] and sameas[sp,'01020'])

			pProd$(tx0[t] and sameas[sp,'01020'] and sameas[prd,'MKE'])
			-uProd$(tx0[t] and sameas[sp,'01020'] and sameas[prd,'MKE'])

			# pMKE$(tx0[t] and sameas[sp,'01020'])
			# -uMKE$(tx0[t] and sameas[sp,'01020'])

			pProd$(tx0[t] and sameas[sp,'01020'] and sameas[prd,'KETM'])
			-uProd$(tx0[t] and sameas[sp,'01020'] and sameas[prd,'KETM'])

			# pKE$(tx0[t] and sameas[sp,'01020'])
			# -uKE$(tx0[t] and sameas[sp,'01020'])


			# pIt$(tx0[t] and agri_sectors[sp])
			# -uIt$(tx0[t] and agri_sectors[sp])

			# pIt$(tx0[t] and sameas[sp,'51001'])
			# -uIt$(tx0[t] and sameas[sp,'51001'])

			# pIb$(tx0[t] and sameas[sp,'51001'])
			# -uIb$(tx0[t] and sameas[sp,'51001'])



		#CALIBRATION OF EMISSIONS
			-uEmmProdxE$(tx0[t] and t.val>tBF_calib_start.val and sum(sCRF, thesesCRF[sCRF] and sCRF_2_sENS2GR_xE(sCRF,s,emm) and KF_emm_[emm,sCRF,t] and d1EmmProdxE[s,t,emm]))
			-uEmmConsxE$(tx0[t] and t.val>tBF_calib_start.val and sum(sCRF, thesesCRF[sCRF] and sCRF_2_sENS2GR_xE(sCRF,'68203',emm) and KF_emm_[emm,sCRF,t] and d1EmmConsxE[t,emm]))
			-qEmmDomesticAviationDCE$(t.val > tBF_calib_start.val and KF_emm_['CO2e','Domestic aviation',t])

      -jEmmProdWaste$(tx0[t]), uEmmProdE$(tx0[t] and sameas[energy19,'waste'])

	      #Linear prices 
	      pREgj$(not d1qREgj[purpose,energy19,r,t] and d1qREgj[purpose,energy19,r,t+1])

     pXE$(d1vXE[purpose,energy19,t+1] and not d1vXE[purpose,energy19,t]) # For chain-indices in aggregates we exogenize last years prices when they are not determined  
	  ;

	   $GROUP G_dynamic_calibration_endo
	   	G_dynamic_calibration_endo
			-pY_CET$(tx0[t] and sameas[s,'53000']), markup$(sameas[s,'53000'] and tx0[t] and d1vY_CET[out,s,t] and sameas[out,'out_other'])
			-pY_CET$(tx0[t] and sameas[s,'51001']), markup$(sameas[s,'51001'] and tx0[t] and d1vY_CET[out,s,t] and sameas[out,'out_other'])

	   	-pY_CET$(tx0[t] and d1vY_CET[out,s,t] and sameas[s,'35011'] and sameas[out,'out_other']), uY_CET$(tx0[t] and d1vY_CET[out,s,t] and sameas[s,'35011'] and sameas[out,'out_other'])
	
	  	-qY_CET$(tx0[t] and tBF_calib[t] and d1vY_CET[out,s,t] and not sameas[out,'out_other'] and not sameas[out,'WholeAndRetailSaleMarginE'] and not bunkering_o[out]) # and not d1vE_onesupplier_a[out,t])
	 	-qM_CET$(tx0[t] and tBF_calib[t] and d1vM_CET[out,s,t] and not sameas[out,'out_other'] and not sameas[out,'WholeAndRetailSaleMarginE'] and not bunkering_o[out]) # and not d1vE_onesupplier_a[out,t])
	   	qY_CET$(tx0[t] and tBF_calib[t] and sameas[s,'35002'] and sameas[out,'natural gas incl. biongas'])

	   	sY_AGG$(tx0[t] and d1vY_CET[energy19,s,t] and not d1vE_onesupplier[energy19,t])
	   	sY_AGG$(tx0[t] and d1vY_CET[energy19,s,t] and (sameas[energy19,'lvn'] or sameas[energy19,'semi-refined oil']))
	   	sM_AGG$(tx0[t] and d1vM_CET[energy19,s,t] and not d1vE_onesupplier[energy19,t])
	 

	   	-qXE$(tx0[t] and tBF_calib[t] and t.val > tBF_calib_Start.val and d1vXE[purpose,energy19,t]), sXE$(tx0[t] and t.val > tBF_calib_Start.val and d1vXE[purpose,energy19,t]) 

	   	-qTL$(tx0[t] and tBF_calib[t] and d1TL[purpose,energy19,t])

	   	#Prices
	   	$IF %calibKF23_pricesXkraftvarme%:
	   	markup$(tx0[t] and t.val >=tBF_calib_prices_start.val and d1vY_CET[out,s,t] and d1pY_CET_overlap[out,s,t] and energy19[out] and not sameas[out,'Straw for energy purposes'] and not (sameas[out,'Diesel for transport'] or sameas[out,'Gasoline for transport'] or sameas[out,'Oil products'] or sameas[out,'jet petroleum'] or sameas[out,'Semi-refined oil'] or sameas[out,'Biodiesel'] or sameas[out,'district heat'] or sameas[out,'el from y and m'] or sameas[out,'electricity']))  
	   	-pY_CET$(tx0[t] and tBF_calib_prices[t] and d1vY_CET[out,s,t] and d1pY_CET_overlap[out,s,t] and energy19[out] and not (sameas[out,'el from y and m'] or sameas[out,'electricity'] or sameas[out,'district heat'])) # and not sameas[out,'straw for energy purposes'])
	   	uPlant_CET$(tx0[t] and t.val >=tBF_calib_prices_start.val and d1PLant_CET0[plant_sectors,plant_out,t] and sameas[plant_out,'EnergyStraw'])
	  	$ENDIF

	  	markup$(tx0[t] and t.val >= tBF_calib_prices_start.val and d1vY_CET[out,s,t] and (sameas[out,'el from y and m'] or sameas[out,'district heat']))
	  	-pY_CET$(tx0[t] and tBF_calib_prices[t] and d1vY_CET[out,s,t] and (sameas[out,'el from y and m'] or sameas[out,'district heat']))
	 	
	  	markup$(tx0[t] and t.val >= tBF_calib_prices_start.val and d1vY_CET[out,s,t] and sameas[out,'electricity'])
	  	-pY_CET$(tx0[t] and tBF_calib_prices[t] and d1vY_CET[out,s,t] and sameas[out,'electricity'])


	   	pM_CET$(tx0[t] and t.val >tBF_calib_prices_End.val and d1vM_CET[out,s,t] and d1pM_CET_overlap[out,s,t] and energy19[out] and not (sameas[out,'el from y and m'] or sameas[out,'district heat']))
	  	fpxE$(tx0[t] and t.val >= tBF_calib_prices_start.val and d1vXE[purpose,energy19,t] and sameas[purpose,'unspecified'] and sameas[energy19,'electricity']), -pXE_base$(tx0[t] and tBF_calib_prices[t] and d1vXE[purpose,energy19,t] and sameas[purpose,'unspecified'] and sameas[energy19,'electricity'])
	  	pM_CET$(tx0[t] and t.val >tBF_calib_prices_End.val and d1vM_CET[out,s,t] and (sameas[out,'El from y and m'] or sameas[out,'district heat']))

	  	$IF %withoutchainindicesfirms%!=1:
		   	#Nederste lag
		   	uRE$(tx0[t] and t.val > tBF_calib_start.val and d1pREa[purpose,energy19a,s,t])
		   	-uRE$(tx0[t] and d1pREa[purpose,energy19a,s,t] and bunkering[energy19a])
		   	-qREa$(tx0[t] and t.val > tBF_calib_start.val and tBF_calib[t] and d1pREa[purpose,energy19a,s,t])
		   	qREa$(tx0[t] and d1pREa[purpose,energy19a,s,t] and bunkering[energy19a])


		   	#Lag af formål
		   	uEP_off$(tx0[t] and t.val > tBF_calib_Start.val and d1EP[purpose,'off',t]), 
		   	uEP$(tx0[t] and t.val > tBF_calib_Start.val and d1EP[purpose,sp,t] and not (sameas[sp,'49509'] or sameas[sp,'0600a']))
		   	-pEP$(d1EP_new[purpose,s,t] and not d1EP_new[purpose,s,t-1])
		   	uOtherEnergy_ani$(tx0[t] and t.val > tBF_calib_Start.val and d1EP[purpose_xtint,ani_sectors,t])
		   	uOtherEnergy_plant$(tx0[t] and t.val > tBF_calib_Start.val and d1EP[purpose_xtint,plant_sectors,t])
		   	uAni$(tx0[t] and t.val > tBF_calib_Start.val and d1Ani[ani_sectors,ani_,t] and sameas[ani_,'fuel'])
		   	uPlant$(tx0[t] and t.val > tBF_calib_Start.val and d1Plant[plant_sectors,plant_,t] and sameas[plant_,'fuel'])
		  	uAni$(tx0[t] and t.val > tBF_calib_Start.val and d1Ani[ani_sectors,ani_,t] and sameas[ani_,'OtherEnergy'])
		   	uPlant$(tx0[t] and t.val > tBF_calib_Start.val and d1Plant[plant_sectors,plant_,t] and sameas[plant_,'OtherEnergy'])

		 	-pEP$(t0[t])
		 	#  -pETrans$(t0[t])
		 	-pProd$(t0[t] and sameas[prd,'Etrans'])

		 	#Lag af energi
		 	#  uE$(tx0[t] and t.val > tBF_calib_start.val and d1E[sp,t] and not (sameas[sp,'49509'] or sameas[sp,'0600a']))
		 	uProd$(tx0[t] and sameas[prd,'EOther'] and t.val > tBF_calib_start.val and d1Prod['Eother',sp,t] and not (sameas[sp,'49509'] or sameas[sp,'0600a']))
		 	uEOFF$(tx0[t] and t.val > tBF_calib_Start.val)
		 	uProd$(tx0[t] and sameas[prd,'Etrans']  and t.val > tBF_calib_start.val and d1Prod['Etrans',sp,t] and not (sameas[sp,'49509'] or sameas[sp,'0600a']))
		$ENDIF

		$IF %shutdownnorthsea%:
		 #Northsea
		 qY_CET$(d1vY_CET[out,s,t] and energy19[out] and sameas[s,'0600a'] and t.val>=tShutNorthSeaStart.val)
		$ENDIF

	  	#Forbruger 
	   	-qCE$(tx0[t] and t.val > tBF_calib_Start.val and tBF_calib[t] and d1vCE[purpose,energy19,t])
	   	sCE$(tx0[t] and t.val > tBF_calib_Start.val and d1vCE[purpose,energy19,t])
	   	sCEPE$(tx0[t] and t.val > tBF_calib_start.val and d1vCEPE[purpose,t])
	   	-pCEPE$(tx0[t] and t.val > tBF_calib_start.val and tBF_calib[t] and d1vCEPE[purpose,t])
	    
	      -qRENEWABLE$(d1RENEWABLE[energy19,t] and not d1waste_module[energy19,t])
	   	-qRENEWABLE$(tx0[t] and tBF_calib[t] and d1RENEWABLE[energy19,t] and sameas[energy19,'Waste']), jqRENEWABLEWaste$(tx0[t])


	   	#Avancer og el- og fjernvarmepriser hos endelig forbruger 
	   		G_avancer_endo 

	   	#Iblandingskrav
	   		#  G_iblandingskrav_endo

	 	#Emissions 
			uEmmProdxE$(tx0[t] and t.val>tBF_calib_start.val and sum(sCRF, thesesCRF[sCRF] and sCRF_2_sENS2GR_xE(sCRF,s,emm) and KF_emm_[emm,sCRF,t] and d1EmmProdxE[s,t,emm]))
			uEmmConsxE$(tx0[t] and t.val>tBF_calib_start.val and sum(sCRF, thesesCRF[sCRF] and sCRF_2_sENS2GR_xE(sCRF,'68203',emm) and KF_emm_[emm,sCRF,t] and d1EmmConsxE[t,emm]))
	    qEmmDomesticAviationDCE$(t.val > tBF_calib_start.val and KF_emm_['CO2e','Domestic aviation',t])
	    
	    #Total emissions
    	jEmmTot_UNFCCC_LULUCF_Calib2KF$(tx0[t] and t.val > tBF_calib_start.val)
	  
	    #Waste
	     jEmmProdWaste$(tx0[t]), -uEmmProdE$(tx0[t] and sameas[energy19,'waste'])

	    #Domestic aviation 

	    #Linear prices	 
	    $IF %calibvtCALIB%:
			#  vtCalibENS$(tx0[t] and t.val > 2019 and t.val<%endhere% and thesesecon[r] and not thesesec_long[r] and d1pREgj[purpose,energy19,r,t] and not eNotInEnergyNest[purpose,energy19,r,t] and theseLinearly[purpose,energy19,r,t])  #and sameas[purpose,'process_normal'] and sameas[energy19,'electricity'])
			#  vtCalibENS$(tx0[t] and t.val > 2019 and t.val<%endhere_long% and thesesecon[r] and thesesec_long[r] and d1pREgj[purpose,energy19,r,t] and not eNotInEnergyNest[purpose,energy19,r,t] and theseLinearly[purpose,energy19,r,t])  #and sameas[purpose,'process_normal'] and sameas[energy19,'electricity'])
			tCalibENS$(tx0[t] and t.val > 2019 and t.val<%endhere% and thesesecon[r]      and not thesesec_long[r] and d1pREgj[purpose,energy19,r,t] and not eNotInEnergyNest[purpose,energy19,r,t] and theseLinearly[purpose,energy19,r,t])  #and sameas[purpose,'process_normal'] and sameas[energy19,'electricity'])
			tCalibENS$(tx0[t] and t.val > 2019 and t.val<%endhere_long% and thesesecon[r] and thesesec_long[r]     and d1pREgj[purpose,energy19,r,t] and not eNotInEnergyNest[purpose,energy19,r,t] and theseLinearly[purpose,energy19,r,t])  #and sameas[purpose,'process_normal'] and sameas[energy19,'electricity'])
		$ENDIF
	 

		#E_pK_ani_link
      # jpK$(t.val>t2.val and d1k[k,sp,t] and ani_sectors_sp[sp])

			#  -pIt$(tx0[t] and agri_sectors[sp])
			#  uIt$(tx0[t] and agri_sectors[sp])
			# -pProd$(sameas[prd,'TK'] and tx0[t] and agri_sectors[sp])
			# uProd$(sameas[prd,'TK'] and tx0[t] and agri_sectors[sp])

			
			# -pIt$(tx0[t] and sameas[sp,'01020']) #, -pTKE$(tx0[t] and sameas[sp,'01020']), -pMKE$(tx0[t] and sameas[sp,'01020']),-pkE$(tx0[t] and sameas[sp,'01020']) #,-pEtrans$(sameas[s,'01020']),-pE_CGE$(sameas[s,'01020'])
			# uIt$(tx0[t] and sameas[sp,'01020']) #, uTKE$(tx0[t] and sameas[sp,'01020']), uMKE$(tx0[t] and sameas[sp,'01020']), uKE$(tx0[t] and sameas[sp,'01020']) #,uEtrans$(sameas[sp,'01020']),uE$(sameas[sp,'01020'])

			-pProd$(tx0[t] and sameas[sp,'01020'] and sameas[prd,'TK'])
			uProd$(tx0[t] and sameas[sp,'01020'] and sameas[prd,'TK'])

			# -pIm$(tx0[t] and sameas[sp,'01020'])
			# uIm$(tx0[t] and sameas[sp,'01020'])

			-pProd$(tx0[t] and sameas[sp,'01020'] and sameas[prd,'MK'])
			uProd$(tx0[t] and sameas[sp,'01020'] and sameas[prd,'MK'])

			# -pTKE$(tx0[t] and sameas[sp,'01020'])
			# uTKE$(tx0[t] and sameas[sp,'01020'])

			-pProd$(tx0[t] and sameas[sp,'01020'] and sameas[prd,'TKE'])
			uProd$(tx0[t] and sameas[sp,'01020'] and sameas[prd,'TKE'])

			# -pMKE$(tx0[t] and sameas[sp,'01020'])
			# uMKE$(tx0[t] and sameas[sp,'01020'])

			-pProd$(tx0[t] and sameas[sp,'01020'] and sameas[prd,'MKE'])
			uProd$(tx0[t] and sameas[sp,'01020'] and sameas[prd,'MKE'])

			# -pKE$(tx0[t] and sameas[sp,'01020'])
			# uKE$(tx0[t] and sameas[sp,'01020'])

			-pProd$(tx0[t] and sameas[sp,'01020'] and sameas[prd,'KETM'])
			uProd$(tx0[t] and sameas[sp,'01020'] and sameas[prd,'KETM'])



			# -pIt$(tx0[t] and agri_sectors[sp])
			# uIt$(tx0[t] and agri_sectors[sp])

			# -pIt$(tx0[t] and sameas[sp,'51001'])
			# uIt$(tx0[t] and sameas[sp,'51001'])

			# -pIb$(tx0[t] and sameas[sp,'51001'])
			# uIb$(tx0[t] and sameas[sp,'51001'])

	 ;


		eExcludeExportsENS('electricity') = no;
		eExcludeExportsGR('electricity')  = no;
		eExcludeExportsENS('El from y and m') = no;
		eExcludeExportsGR('El from y and m')  = no;

	$MODEL M_sBionatgas
	E_sBioNatGasAvgAdj_after23
	E_qXE_bionatgas
	E_sBionatgasX
	;

	$GROUP G_bionatgas_exo 
		qREgj, qCE, qXE 
	;

		$IF %readfromprevious_KF22%!=1:
			#We iterate towards a full implementation of BF
			#  $FOR {lambda} in ['0.1','0.25','0.5','0.5','1']:
			#  $FOR {lambda} in ['0.1','0.2','0.25','0.33','0.66','1']:
			#  $FOR {lambda} in ['0.1','0.33','0.5','1']:
		# $FOR {lambda} in ['0.05','0.10','0.25','0.25','0.5','0.25','0.25','1']:
		$FOR {lambda} in ['0.25','0.25','0.5','1']:
		# $FOR {lambda} in ['1']:
			
			  lambda = {lambda}; xi = {lambda}; 
				# lambda_prices = {lambda}; 
				# lambda_prices_elheat = {lambda};
				lambda_prices = 1;
				lambda_prices_elheat =1;

			  #Update energy-levels with lambda
			   $FIX G_BF_ENERGY_exo;
			   $UNFIX G_BF_ENERGY_endo;
			   @SOLVE(M_BF_ENERGY);
		

				# Adjust supply to demand
				$FIX G_adjust_supply_to_demand_exo;
				$UNFIX(0.01,inf) G_adjust_supply_to_demand_endo;
				# execute_unload 'output\adjust_supply_to_demand_pre_{lambda}.gdx';
				SOLVE M_adjust_supply_to_demand using NLP minimizing obj;
				# execute_unload 'output\adjust_supply_to_demand_post_{lambda}.gdx';
	
				  qEtot.l[energy19,t]$(not d1NonMarketEnergy[energy19,t]) =sum((purpose,r),    qREgj.l[purpose,energy19,r,t]$(d1pRE_base[purpose,energy19,r,t]))   
				                                       +  sum(purpose$d1vCE[purpose,energy19,t], qCE.l[purpose,energy19,t]) 
				                                       +  sum(purpose$d1vLE[purpose,energy19,t], qLE.l[purpose,energy19,t])
				                                       +  sum(purpose$d1vXE[purpose,energy19,t], qXE.l[purpose,energy19,t]) 
				                                       +  sum(purpose$d1TL[purpose,energy19,t],  qTL.l[purpose,energy19,t]);
					                                     
		

				  #Update energy-levels for abatement-module (this is just initial valuing)
				  qREE.l[purpose,energy19a,energy19,s,t] = qREgj.l[purpose,energy19,s,t]$(sameas[energy19,energy19a] and d1pREgj[purpose,energy19,s,t]);
				  qREa.l[purpose,energy19,r,t]$(d1pREa[purpose,energy19,r,t] and not sum(energy19a,d1vREE_transport[purpose,energy19a,energy19,r,t])) = qREgj.l[purpose,energy19,r,t]; 
				  #  qREa.l[purpose,energy19,r,t] = qREgj.l[purpose,energy19,r,t]; 
		
		    
		       	$IF1 %calibKF23_consumers%==1:
				      qCEPE.l['heating',t]$(t.val > t1.val and qCEPE.l['heating',t]=0) 			     = sum(energy19$(d1vCE['heating',energy19,t]), pCE.l['heating',energy19,t] * qCE.l['heating',energy19,t]);
		
		
				      sCEPE.l[purpose,t]$(t.val > tBF_calib_start.val and tBF_calib[t]) = qCEPE.l[purpose,t]/(sum(purposee, pCEPE.l[purposee,t]*qCEPE.l[purposee,t]));
		
				      sCE.l['heating',energy19,t]$(t.val > t1.val and d1vCE['heating',energy19,t])
				  	  	 = qCE.l['heating',energy19,t] * (pCEPE.l['heating',t]/pCE.l['heating',energy19,t]) ** (-eCE.l)/qCEPE.l['heating',t];
  			  	$ENDIF1

				#Pre-model recalibrates the energy-distribor and also gives initial values for CES-shares and a lot of the accounting variables in taxes/emissions-modules

				#If previous rounds tCALIBENS are used for updated 
				vtCALIBENS.l[purpose,energy19,s,t]$(d1pREgj[purpose,energy19,s,t])  = 0;
				tCALIBENS.l[purpose,energy19,s,t]$(d1pREgj[purpose,energy19,s,t])  = 0;
				
				$FIX G_premodel_prices_emissions_taxes_exo;
				$UNFIX G_premodel_prices_emissions_taxes_endo;
				#  execute_unload 'output\emissions_taxes_pre.gdx';
				@Solve(M_premodel_prices_emissions_taxes);

				pREa.l[purpose,energy19,r,t]$(d1pREa_KFnew[purpose,energy19,r,t+1] and not d1pREa_KFnew[purpose,energy19,r,t]) 		        = pREa.l[purpose,energy19,r,t+1]; 
				pREgj.l[purpose,energy19,r,t]$(d1pREgj_KFnew[purpose,energy19,r,t+1] and not d1pREgj_KFnew[purpose,energy19,r,t]) 	        = pREgj.l[purpose,energy19,r,t+1]; 
				pRE_base.l[purpose,energy19,r,t]$(d1pRE_base_KFnew[purpose,energy19,r,t+1] and not d1pRE_base_KFnew[purpose,energy19,r,t])  = pRE_base.l[purpose,energy19,r,t+1]; 

				$FIX G_premodel_chaindices_exo;
				$UNFIX G_premodel_chainindices_endo;
				execute_unload 'output\chainindices_pre.gdx';
				@SOLVE(M_premodel_chainindices);


				#AKB, 27/6/2024: Main calibration model is not square without premodel
				$FIX G_premodel_exo;
				$UNFIX G_premodel_endo;
				execute_unload 'output\premodel_pre.gdx';
				@SOLVE(M_premodel);
				execute_unload 'output\premodel_post.gdx';

				pREa.l[purpose,energy19,r,t]$(d1pREa_KFnew[purpose,energy19,r,t+1] and not d1pREa_KFnew[purpose,energy19,r,t]) 		        	= pREa.l[purpose,energy19,r,t+1]; 
				pREgj.l[purpose,energy19,r,t]$(d1pREgj_KFnew[purpose,energy19,r,t+1] and not d1pREgj_KFnew[purpose,energy19,r,t]) 	        = pREgj.l[purpose,energy19,r,t+1]; 
				pRE_base.l[purpose,energy19,r,t]$(d1pRE_base_KFnew[purpose,energy19,r,t+1] and not d1pRE_base_KFnew[purpose,energy19,r,t])  = pRE_base.l[purpose,energy19,r,t+1]; 
					

				#  execute_unload 'output\premodel_post.gdx';
				# $FIX G_bionatgas_exo;
				# @SOLVE(M_sBionatgas);
		
			  	@print("------------------------------------------ Calibration to Klimafremskrivningen--------------------------------------------------------")
			  	@print("------------------------------------------ Current iteration is: lambda = {lambda} and xi = {lambda} --------------------------")		   	 	

				$FIX G_dynamic_calibration_exo;
				$UNFIX G_dynamic_calibration_endo;
				# $import check_DS.gms
				# execute_unload 'output\pre_{lambda}.gdx';
			# @assert_no_difference_ENS_energy();
    			@SOLVE(M_dynamic_calibration_KF);
				#  execute_unload 'output\dynamic_calibration_{lambda}.gdx';
				#  @assert_no_difference_from(G_save_deez,1e-6,_before);
    			$import check_ds.gms
   	   		  # @assert_no_difference(G_savetaxes,1e-6);
   	   		 	$import sanitycheck.gms
				@assert_no_difference(G_data,%tolerance_data%); #Checks that the model still runs through data
			 $ENDFOR
		$ENDIF 



	 	#Checks 
		 execute_unload 'output\dynamic_calibration_KF.gdx'; 
	 	$import sanitycheck.gms
		@assert_no_difference(G_data,%tolerance_data%); 
		@assert_no_difference_ENS_energy();
		@compute_and_compare_emissions_KF('turnontest')
		@assert_no_difference(G_endoland_calib_should_not_change,1e-8);
		$import check_DS.gms
