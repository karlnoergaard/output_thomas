# ======================================================================================================================
# Calibration of CCS potential
# ======================================================================================================================

# ------------------------------------------------------------------------------------------------------------------
# Set time indices
# ------------------------------------------------------------------------------------------------------------------

singleton set tCCS_data_start[t] /2025/;
singleton set tCCS_data_end[t] /2045/;

set tCCS_data[t] /2025*2045/;


# ------------------------------------------------------------------------------------------------------------------
# Read input-data
# ------------------------------------------------------------------------------------------------------------------
Set s_cat /
    'Industri' 
    /
    ;


# Define parameters
Parameter
    CCSPot_data[s_cat,techCCS,t]
    # CCScost_Capital_data[techCCS_data,s_cat,t]
    # CCScost_Energy_data[techCCS_data,s_cat,t]
    CCSPrice_data[s_cat,techCCS,t]
    ;

    #  CCSPot_data['Industri','t1','2030'] = 1000;
    #  CCSPot_data['Industri','t1','2035'] = 1000;
    #  CCSPot_data['Industri','t1','2040'] = 1000;
    #  CCSPot_data['Industri','t1','2045'] = 1000;

    #  CCSPrice_data['Industri','t1','2030'] = 2300;
    #  CCSPrice_data['Industri','t1','2035'] = 2300;
    #  CCSPrice_data['Industri','t1','2040'] = 2300;
    #  CCSPrice_data['Industri','t1','2045'] = 2300;


# ------------------------------------------------------------------------------------------------------------------
# Create mapping to GreenREFORM dimensions
# ------------------------------------------------------------------------------------------------------------------

# Create mapping of potentials to GreenREFORM dimensions
sets s_industry_CCS(s) /
    '10011'
    '10012'
    '10013'
    '10020'
    '10030'
    '10040'
    '10120'
    '13150'
    '16000'
    '20000'
    '21000'
    '23002'
    '25000'
    /;

# Define mapping from s_cat to s, purpose and emm
Sets map_scat2s_purpose_emm(s_cat,s,purpose,energy19,emm_eq) /
    #  'Biogas'.'35002'.'process_special'.'Biogas'.'CO2bio'
    #  'Raffinaderi'.'19000'.'in_ETS'.'Refinery gas'.'CO2ubio'
    #  'Affald'.'38393'.'in_ETS'.'waste'.'CO2bio'
    #  'Affald'.'38393'.'in_ETS'.'waste'.'CO2ubio'
    /;

map_scat2s_purpose_emm['Industri',s,purpose,energy19,emm_eq]$(sum(tCCS_data, qEmmProdE.l[s,tCCS_data,emm_eq,purpose,energy19]) 
                                                          and s_industry_CCS(s)
                                                          and sameas[purpose,'in_ETS'] # For industrien l�gges kun CCS p� kvoteomfattede udledninger
                                                          and not sameas[energy19,'Wood waste']
                                                          and (sameas[emm_eq,'CO2bio'] or sameas[emm_eq,'CO2ubio'])) = yes;

# ------------------------------------------------------------------------------------------------------------------
# Mapping of potentials to GreenREFORM dimensions
# ------------------------------------------------------------------------------------------------------------------

Parameter
    qEmmProdE_scat[s_cat,t]
    qEmmProdxE_scat[s_cat,t]
    pot_sh_CCS_scat[techCCS,s_cat,t]
    ;

qEmmProdE_scat[s_cat,t]     = sum((s,purpose,energy19,emm)$(map_scat2s_purpose_emm[s_cat,s,purpose,energy19,emm] 
                                                        and d1EmmProdE[s,t,emm,purpose,energy19]
                                                        and (sameas[emm,'CO2ubio'] or sameas[emm,'CO2bio'])), qEmmProdE.l[s,t,emm,purpose,energy19]);

qEmmProdxE_scat[s_cat,t]    = sum((s,emm)$(sum((purpose,energy19), map_scat2s_purpose_emm[s_cat,s,purpose,energy19,emm]) 
                                       and qEmmProdxE.l[s,t,emm]
                                       and (sameas[emm,'CO2ubio'] or sameas[emm,'CO2bio'])), qEmmProdxE.l[s,t,emm]);

pot_sh_CCS_scat[techCCS,s_cat,t]$(CCSPot_data[s_cat,techCCS,t] and not sameas[s_cat,'Industri'])    = CCSPot_data[s_cat,techCCS,t] / qEmmProdE_scat[s_cat,t];
pot_sh_CCS_scat[techCCS,s_cat,t]$(CCSPot_data[s_cat,techCCS,t] and sameas[s_cat,'Industri'])        = CCSPot_data[s_cat,techCCS,t] / (qEmmProdE_scat[s_cat,t] + qEmmProdxE_scat[s_cat,t]);

# Interpolate potentials between 2030 and 2035
pot_sh_CCS_scat[techCCS,s_cat,t]$(t.val > 2030 and t.val < 2035)
            = pot_sh_CCS_scat[techCCS,s_cat,'2030'] + 
            (pot_sh_CCS_scat[techCCS,s_cat,'2035'] - pot_sh_CCS_scat[techCCS,s_cat,'2030'])/5 * (t.val - 2030);

# Interpolate potentials between 2035 and 2040
pot_sh_CCS_scat[techCCS,s_cat,t]$(t.val > 2035 and t.val < 2040)
            = pot_sh_CCS_scat[techCCS,s_cat,'2035'] + 
            (pot_sh_CCS_scat[techCCS,s_cat,'2040'] - pot_sh_CCS_scat[techCCS,s_cat,'2035'])/5 * (t.val - 2035);

# Interpolate potentials between 2040 and 2045
pot_sh_CCS_scat[techCCS,s_cat,t]$(t.val > 2040 and t.val < 2045)
            = pot_sh_CCS_scat[techCCS,s_cat,'2040'] + 
            (pot_sh_CCS_scat[techCCS,s_cat,'2045'] - pot_sh_CCS_scat[techCCS,s_cat,'2040'])/5 * (t.val - 2040);


## Non-Energy related emissions
thetaCCS.l[techCCS,purpose,energy19,s,t,emm]$(tCCS_data[t]) = sum(s_cat$(map_scat2s_purpose_emm(s_cat,s,purpose,energy19,emm) and d1EmmProdE[s,t,emm,purpose,energy19]), 
                                                            pot_sh_CCS_scat[techCCS,s_cat,t]);

## Non-Energy related emissions in industry
thetaCCSxE.l[techCCS,s,t,'CO2ubio']$(sum((purpose,energy19,emm_eq), map_scat2s_purpose_emm['Industri',s,purpose,energy19,emm_eq])) = pot_sh_CCS_scat[techCCS,'Industri',t];

# Potentials are held constant after last data year
thetaCCS.l[techCCS,purpose,energy19,s,t,emm]$(t.val > tCCS_data_end.val)         = thetaCCS.l[techCCS,purpose,energy19,s,tCCS_data_end,emm];
thetaCCSxE.l[techCCS,s,t,emm]$(t.val > tCCS_data_end.val)                        = thetaCCSxE.l[techCCS,s,tCCS_data_end,emm];


# ------------------------------------------------------------------------------------------------------------------
# Mapping of prices to GreenREFORM dimensions
# ------------------------------------------------------------------------------------------------------------------

# Interpolate prices between 2030 and 2035
CCSPrice_data[s_cat,techCCS,t]$(t.val > 2030 and t.val < 2035)
            = CCSPrice_data[s_cat,techCCS,'2030'] + 
            (CCSPrice_data[s_cat,techCCS,'2035'] - CCSPrice_data[s_cat,techCCS,'2030'])/5 * (t.val - 2030);

# Interpolate prices between 2035 and 2040
CCSPrice_data[s_cat,techCCS,t]$(t.val > 2035 and t.val < 2040)
            = CCSPrice_data[s_cat,techCCS,'2035'] + 
            (CCSPrice_data[s_cat,techCCS,'2040'] - CCSPrice_data[s_cat,techCCS,'2035'])/5 * (t.val - 2035);

# Interpolate prices between 2040 and 2045
CCSPrice_data[s_cat,techCCS,t]$(t.val > 2040 and t.val < 2045)
            = CCSPrice_data[s_cat,techCCS,'2040'] + 
            (CCSPrice_data[s_cat,techCCS,'2045'] - CCSPrice_data[s_cat,techCCS,'2040'])/5 * (t.val - 2040);

CCSPrice.l[techCCS,s,t] = sum(s_cat$(sum((purpose,energy19,emm), map_scat2s_purpose_emm(s_cat,s,purpose,energy19,emm))), 
                                                            CCSPrice_data[s_cat,techCCS,t]);

# Prices are held constant after last data year
CCSPrice.l[techCCS,s,t]$(t.val > tCCS_data_end.val)         = CCSPrice.l[techCCS,s,tCCS_data_end];

# We scale capital costs with the sector-specific investment price in baseline
CCSPrice.l[techCCS,s,t]$(CCSPrice.l[techCCS,s,t]) = CCSPrice.l[techCCS,s,t]/pI_s.l['iM',s,t];


# ------------------------------------------------------------------------------------------------------------------
# Checking potentials (and costs)
# ------------------------------------------------------------------------------------------------------------------

## Tjek potentials that are >1 

parameter
    tjek_thetaCCS[purpose,energy19,s,t,emm]
    ;

tjek_thetaCCS[purpose,energy19,s,t,emm]$(sum(techCCS, thetaCCS.l[techCCS,purpose,energy19,s,t,emm]>1)) = sum(techCCS, thetaCCS.l[techCCS,purpose,energy19,s,t,emm]);

# Skalering af potentialer, n�r de overstiger 1 
#  thetaCCS.l[techCCS,purpose,energy19,s,t,emm]$(tjek_thetaCCS[purpose,energy19,s,t,emm]) 
#      = thetaCCS.l[techCCS,purpose,energy19,s,t,emm]/tjek_thetaCCS[purpose,energy19,s,t,emm]*0.99;


Parameters
    Tjek_pot_CCS[s_cat,t]
    Tjek_CapitalCosts_CCS[s_cat,t]
    # Tjek_EnergyCosts_CCS[s_cat,t]

    data_cap_costs[techCCS,s_cat,t] "Billion DKK"
    model_cap_costs[techCCS,s_cat,t]     "Billion DKK"
    ;

# Reduction potentials
Tjek_pot_CCS[s_cat,t]$(tCCS_data[t]) = sum((techCCS,s,purpose,energy19,emm)$(map_scat2s_purpose_emm[s_cat,s,purpose,energy19,emm]), 
                                        thetaCCS.l[techCCS,purpose,energy19,s,t,emm]*qEmmProdE.l[s,t,emm,purpose,energy19])
                                + sum((techCCS,s,emm)$(sum((purpose,energy19), map_scat2s_purpose_emm[s_cat,s,purpose,energy19,emm])), 
                                        thetaCCSxE.l[techCCS,s,t,emm]*qEmmProdxE.l[s,t,emm])
                                - sum(techCCS, CCSPot_data[s_cat,techCCS,t]);

# Check that GR reduction potentials are the same as in data
LOOP((s_cat,t)$(sameas[t,'2030'] or sameas[t,'2035']),
    tjek = Tjek_pot_CCS[s_cat,t];
    ABORT$(abs(tjek) > 10**(-6)) tjek, "Reduction potential is different than data";
);

data_cap_costs[techCCS,s_cat,t] = CCSPot_data[s_cat,techCCS,t]*1000 # Tonnes CO2
                                        *CCSPrice_data[s_cat,techCCS,t] # DKK per tonnes
                                        /10**9; # Billion
model_cap_costs[techCCS,s_cat,t]     = (sum((s,purpose,energy19,emm)$(map_scat2s_purpose_emm[s_cat,s,purpose,energy19,emm]), 
                                            thetaCCS.l[techCCS,purpose,energy19,s,t,emm]*qEmmProdE.l[s,t,emm,purpose,energy19]*1000 # Tonnes CO2
                                            *CCSPrice.l[techCCS,s,t]*pI_s.l['iM',s,t]) #*shCCSPrice_group[techCCS,s,'Kapital',t]) # DKK per tonnes
                                     +  sum((s,emm)$(sum((purpose,energy19), map_scat2s_purpose_emm[s_cat,s,purpose,energy19,emm])), 
                                            thetaCCSxE.l[techCCS,s,t,emm]*qEmmProdxE.l[s,t,emm]*1000
                                            *CCSPrice.l[techCCS,s,t]*pI_s.l['iM',s,t]))
                                            /10**9; # Billion

# Capital costs
Tjek_CapitalCosts_CCS[s_cat,t]$(sameas[t,'2025'] or sameas[t,'2030'] or sameas[t,'2035']) 
    = sum(techCCS, model_cap_costs[techCCS,s_cat,t]) 
    - sum(techCCS, data_cap_costs[techCCS,s_cat,t]);

# Check that GR capital costs are the same as in data
LOOP((s_cat,t)$(sameas[t,'2030'] or sameas[t,'2035']),
    tjek = Tjek_CapitalCosts_CCS[s_cat,t];
    ABORT$(abs(tjek) > 10**(-6)) tjek, "Capital costs are different than data";
);


# ----------------------------------------------------------------------------------------------------------------------
# Dummies and initialisation
# ----------------------------------------------------------------------------------------------------------------------

d1thetaCCS[techCCS,purpose,energy19,s,t,emm] = no;
d1thetaCCS[techCCS,purpose,energy19,s,t,emm]$(thetaCCS.l[techCCS,purpose,energy19,s,t,emm]) = yes;
d1thetaCCS_end[techCCS,purpose,energy19,s,t,emm]$(d1thetaCCS[techCCS,purpose,energy19,s,t,emm]
                                          and not d1thetaCCS[techCCS,purpose,energy19,s,t+1,emm]) = yes;

d1CCSbio[purpose,energy19,s,t,'CCSbio']$(d1EmmProdE[s,t,'CO2bio',purpose,energy19] and sum(techCCS, d1thetaCCS[techCCS,purpose,energy19,s,t,'CO2bio'])) = yes;
d1CCSbio[purpose,energy19,s,t,'CO2e']$(d1CCSbio[purpose,energy19,s,t,'CCSbio']) = yes;

d1thetaCCSxE[techCCS,s,t,emm] = no;
d1thetaCCSxE[techCCS,s,t,emm]$(thetaCCSxE.l[techCCS,s,t,emm]) = yes;
d1thetaCCSxE_end[techCCS,s,t,emm]$(d1thetaCCSxE[techCCS,s,t,emm]
                           and not d1thetaCCSxE[techCCS,s,t+1,emm]) = yes;

rCCS.l[techCCS,s,purpose,energy19,t]$(sum(emm, thetaCCS.l[techCCS,purpose,energy19,s,t,emm])) = 0;

sigmaCCS.l[techCCS]$(sum((purpose,energy19,s,t,emm), d1thetaCCS[techCCS,purpose,energy19,s,t,emm]))     = 100;
rhoCCS[techCCS]$(sum((purpose,energy19,s,t,emm), d1thetaCCS[techCCS,purpose,energy19,s,t,emm]))         = 0.5;
uCCSscalar.l[techCCS,s,purpose,t]$(sum((energy19,emm), d1thetaCCS[techCCS,purpose,energy19,s,t,emm]))   = 1;
uCCSt.l[techCCS,s,purpose,t]$(sum((energy19,emm), d1thetaCCS[techCCS,purpose,energy19,s,t,emm]))        = 0;
j_rCCS.l[techCCS,s,purpose,energy19,t]$(sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,t,emm]))        = 0;

# Switch der definerer, om CCS-teknologierne skal tr�nge ind (=1) eller ej (=0)
switch_CCS[techCCS] = 0;
switch_CCS[techCCS]$(sum((purpose,energy19,s,t,emm), d1thetaCCS[techCCS,purpose,energy19,s,t,emm])) = 1;
