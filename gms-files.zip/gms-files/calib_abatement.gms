
# ======================================================================================================================
# INITIALIZATION 
# ======================================================================================================================

# Set some default options (START)
$SETGLOBAL costs_are_taxes 'NO';                    # MAC curves are by default additional costs. However, in some cases MAC curves may have CO2-tax increases on the y-axis. When this is the case, costs should be redifined

$SETGLOBAL tMACp_val 2021;                          # Default year for which years' prices that the mac curves are constructed in 
singleton set tMACp[t] /%tMACp_val%/;

$SETGLOBAL SOLVE_CALIB_ABATEMENT_MODELS 1;          # Solving is switched on (standard)
#  $SETGLOBAL SOLVE_CALIB_ABATEMENT_MODELS 0;          # Solving is switched off (to e.g. speed up data checks)

#  Set some default options (END)

#Now we move start year to 2023 
$SETGLOBAL start_shock_year 2024 
set_time_periods(%start_shock_year%,%terminal_year%);



# ------------------------------------------------------------------------------------------------------------------
# Augmenting variables for calculating technical effects
# ------------------------------------------------------------------------------------------------------------------

parameter
    qREa_GSR[GSR_ag,energy19a,t]
;

$GROUP G_calib_abatement_GSR_variables

    qEmmProdE_GSR_ag[t,GSR_ag,energy19] ""
    qEmmProdE_GSR_ag_sumE[t,GSR_ag] ""
    qEmmProdE_GSR_ag_propE[t,GSR_ag,energy19] ""
    qEmmProdE_GSR_ag_propE_max[t,GSR_ag] ""
    qEmmProdxE_GSR_ag[t,GSR_ag] ""
;

## EMISSIONS AND ENERGY USE IN BASELINE
# Udregner energiforbrug i et givet afgiftsgrundlag, form�l og energiaktivitet, der bliver �ndret af en given teknologi
qREa_GSR[GSR_ag,energy19a,t] = sum((purpose,s)$(mapGrREFORM2GSR[purpose,energy19a,s,GSR_ag,t] and d1qREgj[purpose,energy19a,s,t]), qREgj.l[purpose,energy19a,s,t]);

# Udledninger for hver energivare i hvert afgiftsgrundlag. Inkl. udledning fra CO2bio for naturgas
qEmmProdE_GSR_ag.l[t,GSR_ag,energy19]$(not sameas[energy19,'Natural gas incl. biongas']) = sum((purpose,s)$(mapGrREFORM2GSR[purpose,energy19,s,GSR_ag,t] and d1EmmProdE[s,t,'CO2ubio',purpose,energy19]), qEmmProdE.l[s,t,'co2ubio',purpose,energy19]);

qEmmProdE_GSR_ag.l[t,GSR_ag,'Natural gas incl. biongas'] = sum((purpose,s)$(mapGrREFORM2GSR[purpose,'Natural gas incl. biongas',s,GSR_ag,t] and d1EmmProdE[s,t,'CO2ubio',purpose,'Natural gas incl. biongas']), qEmmProdE.l[s,t,'co2ubio',purpose,'Natural gas incl. biongas'])
                                 #Vi betinger på at der også skal være ubio emissioner fra naturgas. Der er nogle få tilfælde, hvor det lader til at virksomhederne bruger ren bionaturgas. Det er enten en datafejl, eller fordi de ikke modtager fra ledningsnettet og derfor kan få det rent. Det antages at det er sidstnævnte - og i de tilfælde skal naturgassen ikke beskattes, da det er ren bionaturgas.
                                   +sum((purpose,s)$(mapGrREFORM2GSR[purpose,'Natural gas incl. biongas',s,GSR_ag,t] and d1EmmProdE[s,t,'CO2bio',purpose,'Natural gas incl. biongas']), qEmmProdE.l[s,t,'co2bio',purpose,'Natural gas incl. biongas'])
                                   ;

# Udledninger for hvert afgiftsgrundlag
qEmmProdE_GSR_ag_sumE.l[t,GSR_ag] = sum(energy19,qEmmProdE_GSR_ag.l[t,GSR_ag,energy19]);

qEmmProdxE_GSR_ag.l[t,'Mineralogi_cement'] = qEmmProdxE.l['23001',t,'CO2e'];
qEmmProdxE_GSR_ag.l[t,'Mineralogi_oevrig'] = sum(s$(sum((categoryENS,purpose,energy19), sENS2GR(categoryENS,'Mineralogi_oevrig',purpose,energy19, s)) and d1EmmProdxE[s,t,'CO2ubio']), qEmmProdxE.l[s,t,'CO2ubio']);

# Energivares andel i afgiftgrundlags samlede udlednunger
qEmmProdE_GSR_ag_propE.l[t,GSR_ag,energy19]$(qEmmProdE_GSR_ag_sumE.l[t,GSR_ag]) = qEmmProdE_GSR_ag.l[t,GSR_ag,energy19] / qEmmProdE_GSR_ag_sumE.l[t,GSR_ag];


qEmmProdE_GSR_ag_propE_max.l[t,GSR_ag] = smax(energy19,qEmmProdE_GSR_ag_propE.l[t,GSR_ag,energy19]);

set qEmmProdE_GSR_ag_propE_max_energy19(t,GSR_ag,energy19);
qEmmProdE_GSR_ag_propE_max_energy19(t,GSR_ag,energy19)$(qEmmProdE_GSR_ag_propE_max.l[t,GSR_ag]) = yes$(qEmmProdE_GSR_ag_propE.l[t,GSR_ag,energy19]=qEmmProdE_GSR_ag_propE_max.l[t,GSR_ag]);


# ------------------------------------------------------------------------------------------------------------------
# ENS teknologikatalog til Ekspertgruppens 1. delrapport
# ------------------------------------------------------------------------------------------------------------------
#  $import calib_abatement_GSR_ENS.gms

# ------------------------------------------------------------------------------------------------------------------
# SKM teknologikatalog til Ekspertgruppens 1. delrapport
# ------------------------------------------------------------------------------------------------------------------
#  $import calib_abatement_GSR_SKM.gms

# ------------------------------------------------------------------------------------------------------------------
# EA teknologikatalog tbf. D�RS analyse
 #  ------------------------------------------------------------------------------------------------------------------

#  $import DORS_EA_read_data.gms

 #  $import calib_abatement_DORS_EA.gms

# ======================================================================================================================
# Calibrate model with ID-abatement 
# ======================================================================================================================

max_baseline_adoption_error = 0.01;
sigmaID.l[techID] = 1;
# sigmaID.l[techID] = 0.01*sum((purpose,energy19a,s),thetaid_k.l[techID,purpose,energy19a,s,tMAC]*sum(energy19,-thetaID.l[techID,purpose,energy19a,energy19,s,tMAC]));
rID.l[techID,purpose,energy19a,s,t]$(d1thetaID_k[techID,purpose,energy19a,s,t]) = max_baseline_adoption_error*switch_ID*switch_abatement;

#  execute_unload 'output\test.gdx' techID, thetaID.l, thetaID_k.l, mac_curve, sigmaID.l, rID.l;

set set_abatement_reporting /'Additional_costs_krprCO2','pREa','thetaID_k','rID','rID_actual','tCO2_REmarg'/;

$GROUP G_abatement_reporting
    abatement_reporting[set_abatement_reporting,techID,purpose,energy19a,s,t]$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t]) ""
;


$GROUP G_abatement_reporting_exo
    tCO2_REmarg$(d1tRE[purpose,energy19,r,t])
    tVAT_RE
    uEmmProdE
;

$GROUP G_abatement_reporting_exo G_abatement_reporting_exo;

$BLOCK B_abatement_reporting

    E_abreporting_mac_step[techID,purpose,energy19a,s,t]$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t])..
    abatement_reporting['Additional_costs_krprCO2',techID,purpose,energy19a,s,t] =E= 
        (thetaID_k[techID,purpose,energy19a,s,t]-pREa[purpose,energy19a,s,t])/sum(emm, uEmmProdE[s,t,emm,energy19a]*GWP[emm])*(10**6);

    E_abreporting_mac_pre[techID,purpose,energy19a,s,t]$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t])..
    abatement_reporting['pREa',techID,purpose,energy19a,s,t] =E= 
    sum(energy19$(d1thetaID[techID,purpose,energy19a,energy19,s,t]), pREa[purpose,energy19,s,t]); 
 
    E_abreporting_mac_thetaid_k[techID,purpose,energy19a,s,t]$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t])..
    abatement_reporting['thetaID_k',techID,purpose,energy19a,s,t] =E= thetaID_k[techID,purpose,energy19a,s,t]; 
 
   E_abreporting_mac_rid[techID,purpose,energy19a,s,t]$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t])..
    abatement_reporting['rID',techID,purpose,energy19a,s,t] =E= rID[techID,purpose,energy19a,s,t];

   E_abreporting_mac_rid_actual[techID,purpose,energy19a,s,t]$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t])..
    abatement_reporting['rID_actual',techID,purpose,energy19a,s,t] =E= rID_actual[techID,purpose,energy19a,s,t];

    E_abreporting_tCO2_REmarg[techID,purpose,energy19a,s,t]$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t] )..
    abatement_reporting['tCO2_REmarg',techID,purpose,energy19a,s,t] =E= sum(emm_eq$(d1CO2_REmarg[purpose,energy19a,s,t,emm_eq]), tCO2_REmarg[purpose,energy19a,s,t,emm_eq]);

$ENDBLOCK



# ======================================================================================================================
# Calibration of CCS potential
# ======================================================================================================================

# ----------------------------------------------------------------------------------------------------------------------
# CCS in EA Energianalyse
# ----------------------------------------------------------------------------------------------------------------------

 $import calib_CCS_EA.gms
 
# ----------------------------------------------------------------------------------------------------------------------
# CCS in Model 2 from Ekspertgruppen for en Gr�n Skattereform, delrapport 1
# ----------------------------------------------------------------------------------------------------------------------

#  $import calib_abatement_CCS_GSR.gms


# ======================================================================================================================
# Construct MAC curves (Doesn't work at the moment)
# ======================================================================================================================


 Parameter 
    # MAC_curve_ID[techID,s,purpose,energy19a,energy19,t,*] 'Mac curve for ID technologies'
    MAC_curve_CCS[techCCS,s,purpose,energy19,t,emm,*] 'Mac curve for CCS technologies'
    MAC_curve_sum_techID_Energy19a[s,purpose,energy19,t,*]
    MAC_curve_Agg[t,*]
    d1tjek_MAC[s,purpose,energy19,t]
 ;

## ID MAC CURVE

 # Reduction potential for individual technologies
#  MAC_curve_ID[techID,s,purpose,energy19a,energy19,tMAC,'Reduction potential, ktCO2e'] = 
#      thetaID_in[techID,s,purpose,energy19a,energy19,tMAC]*qEmmProdE.l[s,tMAC,'CO2e',purpose,energy19];

#  MAC_curve_sum_techID_Energy19a[s,purpose,energy19,tMAC,'Reduction potential, ktCO2e'] = sum((techID,energy19a), MAC_curve_ID[techID,s,purpose,energy19a,energy19,tMAC,'Reduction potential, ktCO2e']);

#  d1tjek_MAC[s,purpose,energy19,tMAC] = MAC_curve_sum_techID_Energy19a[s,purpose,energy19,tMAC,'Reduction potential, ktCO2e'] - qEmmProdE_MechCh_kt[s,tMAC,'CO2e',purpose,energy19];

# Reduction cost for individual technologies
#  $SETGLOBAL costs_are_taxes 'NO';  
#  $IF %costs_are_taxes% == 'NO':
#      mac_curve_ID(techID,purpose,energy19a,energy19,s,'cost_kr_pr_t')$(mac_curve(techID,purpose,energy19a,energy19,s,'potential_1000tCO2e') and sum(emm, uEmmProdE.l[s,tMAC,emm,energy19]*GWP.l[emm])) 
#      = (thetaid_k_in[techID,purpose,energy19,s,tMAC]-pRE.l[purpose,energy19,s,tMAC])/sum(emm, uEmmProdE.l[s,tMAC,emm,energy19]*GWP.l[emm])*(10**6)*(fp**(%tMACp_val%-%base_year%));
#  $ENDIF

#  $IF %costs_are_taxes% == 'YES':
#      mac_curve_ID(techID,purpose,energy19a,energy19,s,'cost_kr_pr_t')$(mac_curve(techID,purpose,energy19a,energy19,s,'potential_1000tCO2e') and sum(emm, uEmmProdE.l[s,tMAC,emm,energy19]*GWP.l[emm])) 
#      = (thetaid_k_in[techID,purpose,energy19,s,tMAC]-pRE.l[purpose,energy19,s,tMAC]
#          + (1-d1tREmarg[s])*(tCO2_RE.l[purpose,energy19a,s,tMAC] + tEAFG_RE.l[purpose,energy19a,s,tMAC]) * (1+tVAT_RE.l[purpose,energy19a,s,tMAC])
#          + d1tREmarg[s]*(((sum(emm_eq$(d1CO2_REmarg[purpose,energy19a,s,tMAC,emm_eq]), tCO2_REmarg.l[purpose,energy19a,s,tMAC,emm_eq])*uEmmProdE.l[s,tMAC,'CO2ubio',energy19a]*(10**(-6))) + tEAFG_REmarg.l[purpose,energy19a,s,tMAC]*10**(-3)) * (1+tVAT_RE.l[purpose,energy19a,s,tMAC]))
#            )/sum(emm, uEmmProdE.l[s,tMAC,emm,energy19]*GWP.l[emm])*(10**6)*(fp**(%tMACp_val%-%base_year%));
#  $ENDIF

## CCS MAC CURVE

MAC_curve_CCS[techCCS,s,purpose,energy19,t,emm,'Reduction potential, ktCO2e']$(d1thetaCCS[techCCS,purpose,energy19,s,t,emm]) 
    = thetaCCS.l[techCCS,purpose,energy19,s,t,emm]*qEmmProdE.l[s,t,emm,purpose,energy19];

MAC_curve_CCS[techCCS,s,purpose,energy19,t,emm,'cost_DKK_pr_tCO2']$(d1thetaCCS[techCCS,purpose,energy19,s,t,emm])
    = CCSPrice.l[techCCS,s,t];

## AGGREGATE MAC CURVE

# MAC_curve_Agg[t,'Reduction potential, ktCO2e'] = sum((techCCS,s,purpose,energy19,emm)$(d1thetaCCS[techCCS,purpose,energy19,s,t,emm]), )

# execute_unload 'output\test.gdx' 
# $exit


# ======================================================================================================================
# Solving the model with abatement technologies
# ======================================================================================================================

# ----------------------------------------------------------------------------------------------------------------------
# Pre-model for ID-abatement
# ----------------------------------------------------------------------------------------------------------------------

j_rID.l[techID,purpose,energy19a,s,t] = 0;
rID.l[techID,purpose,energy19a,s,t]$(tx0[t] and d1thetaID_k[techID,purpose,energy19a,s,t]) = max_baseline_adoption_error*switch_ID*switch_abatement;
#  $FIX G_rID_calib_exo;
#  $UNFIX G_rID_calib_endo;
#  @solve(rID_calib);
  
# Remove shadow taxes if they are in fact shadow subsidies (i.e. if no shadow tax is required to minimize baseline adoption)
rID.l[techID,purpose,energy19a,s,t]$(uIDt.l[techID,purpose,energy19a,s,t]<0) = 0;
uIDt.l[techID,purpose,energy19a,s,t]$(uIDt.l[techID,purpose,energy19a,s,t]<0) = 0;
j_rID.l[techID,purpose,energy19a,s,t] = -rID.l[techID,purpose,energy19a,s,t];
rID.l[techID,purpose,energy19a,s,t] = 0;
  
# ----------------------------------------------------------------------------------------------------------------------
# Pre-model for CCS (LBS: pt slået fra, men skal slås til, når vi får styr på den endogene indtrængning)
# ----------------------------------------------------------------------------------------------------------------------

#  $GROUP G_rCCS_calib_exo
#  rCCS
#  vtCO2_REmarg
#  vtCO2_RxE
#  uCCSt
#  thetaCCS_K
#  pI_s
#  uCCSscalar
#  sigmaCCS
#  j_rCCS
#  qEmmProdS;
  
#  j_rCCS.l[techCCS,purpose,energy19,s,t,emm] = 0;
#  rCCS.l[techCCS,purpose,energy19,s,t,emm]$(tx0[t] or t0[t]) = max_baseline_adoption_error*switch_CCS[techCCS]*switch_abatement;
#  $FIX G_rCCS_calib_exo;
#  $UNFIX G_rCCS_calib_endo;
#  @solve(rCCS_calib);          

#  rCCS.l[techCCS,purpose,energy19,s,t,emm]$(uCCSt.l[techCCS,purpose,energy19,s,t,emm]<0) = 0;      # LBS kommenteret ud, men skal ind, n�r der skal endogen indtr�ngning
#  uCCSt.l[techCCS,purpose,energy19,s,t,emm]$(uCCSt.l[techCCS,purpose,energy19,s,t,emm]<0) = 0;     # LBS kommenteret ud, men skal ind, n�r der skal endogen indtr�ngning
#  j_rCCS.l[techCCS,purpose,energy19,s,t,emm] = -rCCS.l[techCCS,purpose,energy19,s,t,emm];
rCCS.l[techCCS,s,purpose,t] = 0;
#  j_rCCS.l[techCCS,purpose,energy19,s,t,emm] = 0;

# Opdatering af qREE efter KF22
qREE.l[purpose,energy19a,energy19,r,t]$(not (d1pREa[purpose,energy19,r,t] and sameas(energy19,energy19a))) = 0;


## ---------------------------------------------------------------------------------------------------------
## `Formodel til at bestemme teknologiindtrængning
## ---------------------------------------------------------------------------------------------------------

switch_forward_looking = 0;

$import energy_price_partial.gms

$MODEL M_abatement_partial
    M_Energy_price_partial

    M_abatement
;

$GROUP G_abatement_partial_endo
    G_Energy_price_endo
    
    G_abatement_endo
;

$GROUP G_abatement_partial_exo
    G_Energy_price_exo

    G_abatement_exo
;

$FIX G_abatement_partial_exo;
$UNFIX G_abatement_partial_endo;
@SOLVE(M_abatement_partial);


## ---------------------------------------------------------------------------------------------------------
## Korrektion for, at der er nogle ID-teknologier som trænger ind i baseline (inden 2036)
## ---------------------------------------------------------------------------------------------------------

parameter
    d1BaselineAdoption_ID[techID,purpose,energy19a,s,t]
    rID_input_neg[techID,purpose,energy19a,s,t]
    thetaID_k_diff[techID,purpose,energy19a,s,t]
    thetaID_k_baseline[techID,purpose,energy19a,s,t]
    ;

thetaID_k_baseline[techID,purpose,energy19a,s,t] = thetaID_k.l[techID,purpose,energy19a,s,t];
d1BaselineAdoption_ID[techID,purpose,energy19a,s,t]$(rID_input.l[techID,purpose,energy19a,s,t] > 0 and t.val < 2036) = 1;

rID_input.l[techID,purpose,energy19a,s,t]$(d1BaselineAdoption_ID[techID,purpose,energy19a,s,t]) = -0.001;

$BLOCK M_ID_baseline_adoption
  # Input for calculating instantaneous adoption rate
  E_rID_input_baselineadoption[techID,purpose,energy19a,s,t]$(tx0[t] and d1BaselineAdoption_ID[techID,purpose,energy19a,s,t])..
    rID_input[techID,purpose,energy19a,s,t] =E= 
      # Energy costs
      (sum(energy19$(d1thetaID[techID,purpose,energy19a,energy19,s,t]), -thetaID[techID,purpose,energy19a,energy19,s,t]*pREgj[purpose,energy19,s,t]) 
      # Capital costs
      - pI_s['iM',s,t]*thetaID_k[techID,purpose,energy19a,s,t]
        * sum(energy19$(d1thetaID[techID,purpose,energy19a,energy19,s,t] and sameas(energy19,energy19a)), -thetaID[techID,purpose,energy19a,energy19,s,t])
        * uIDscalar[techID,t]*(1+lambda_ID) - uIDt[techID,purpose,energy19a,s,t])  
      # Smoothing of technology costs
      / sigmaID[techID];

$ENDBLOCK

$GROUP G_ID_baseline_adoption_endo
    thetaID_k$(d1BaselineAdoption_ID[techID,purpose,energy19a,s,t])
    ;

$GROUP G_ID_baseline_adoption_exo
    G_abatement_adoption_partial_exo ""
    -thetaID_k$(d1BaselineAdoption_ID[techID,purpose,energy19a,s,t])
    rID_input$(d1BaselineAdoption_ID[techID,purpose,energy19a,s,t])
    pREgj$(tx0[t] and sum(techID, sum(energy19a, d1thetaID[techID,purpose,energy19a,energy19,r,t])))
    ;


$FIX G_ID_baseline_adoption_exo;
$UNFIX G_ID_baseline_adoption_endo;
@SOLVE(M_ID_baseline_adoption);


thetaID_k_diff[techID,purpose,energy19a,s,t] = thetaID_k.l[techID,purpose,energy19a,s,t] - thetaID_k_baseline[techID,purpose,energy19a,s,t];

# ======================================================================================================================
# Construct MAC curves 
# ======================================================================================================================

#  pREa_MechCh[techID,purpose,energy19a,s,t]$(d1thetaID_k[techID,purpose,energy19a,s,t]) =
#      # Energy costs:
#      sum(energy19$(d1thetaID[techID,purpose,energy19a,energy19,s,t]), 
#            thetaID.l[techID,purpose,energy19a,energy19,s,t] * pREgj_Mech[purpose,energy19,s,t])
#      # Capital costs from ID:
#      + thetaid_k.l[techID,purpose,energy19a,s,t]
#            * sum(energy19$(d1thetaID[techID,purpose,energy19a,energy19,s,t] and sameas(energy19,energy19a)),
#                    - thetaID.l[techID,purpose,energy19a,energy19,s,t]) * pI_s.l['iM',s,t]
#  ;

#  vREa_MechCh[techID,purpose,energy19a,s,t]$(d1thetaID_k[techID,purpose,energy19a,s,t]) =
#      pREa_MechCh[techID,purpose,energy19a,s,t] * qREa.l[purpose,energy19a,s,t];


#   Parameter 
#      MAC_curve_ID_scale[techID,s,purpose,energy19a,t,emm_eq,*]     'Mac curve for ID technologies'
#      MAC_curve_ID_GSR_scale[techID,GSR_ag,s,purpose,energy19a,t,emm_eq,*]  'Mac curve for ID technologies'
#   ;

#  MAC_curve_ID_scale[techID,s,purpose,energy19a,t,emm_eq,'Reduction potential, ktCO2e']$(d1thetaID_k[techID,purpose,energy19a,s,t] and (sameas[emm_eq,'CO2bio'] or sameas[emm_eq,'CO2ubio'] or sameas[emm_eq,'CO2e'])) 
#      = sum(energy19, qEmmProdE_MechCh_kt[techID,purpose,energy19,s,t,emm_eq]);

#  MAC_curve_ID_scale[techID,s,purpose,energy19a,t,emm_eq,'Reduction potential, pct.']$(d1thetaID_k[techID,purpose,energy19a,s,t] and (sameas[emm_eq,'CO2bio'] or sameas[emm_eq,'CO2ubio'] or sameas[emm_eq,'CO2e']) and qEmmProdE.l[s,t,emm_eq,purpose,energy19a]) 
#      = MAC_curve_ID_scale[techID,s,purpose,energy19a,t,emm_eq,'Reduction potential, ktCO2e']/qEmmProdE.l[s,t,emm_eq,purpose,energy19a];

#  MAC_curve_ID_scale[techID,s,purpose,energy19a,t,emm_eq,'cost_DKK_pr_tCO2']$(MAC_curve_ID_scale[techID,s,purpose,energy19a,t,emm_eq,'Reduction potential, ktCO2e'] and d1thetaID_k[techID,purpose,energy19a,s,t] and (sameas[emm_eq,'CO2bio'] or sameas[emm_eq,'CO2ubio'] or sameas[emm_eq,'CO2e'])) 
#      = -vREa_MechCh[techID,purpose,energy19a,s,t]/MAC_curve_ID_scale[techID,s,purpose,energy19a,t,emm_eq,'Reduction potential, ktCO2e']*10**6;

#  MAC_curve_ID_GSR_scale[techID,GSR_ag,s,purpose,energy19a,t,emm_eq,'Reduction potential, ktCO2e']$(MAC_curve_ID_GSR[techID,GSR_ag,s,purpose,energy19a,t,emm_eq,'Reduction potential, ktCO2e'])
#      = MAC_curve_ID_GSR[techID,GSR_ag,s,purpose,energy19a,t,emm_eq,'Reduction potential, ktCO2e'];

#  MAC_curve_ID_GSR_scale[techID,GSR_ag,s,purpose,energy19a,t,emm_eq,'Reduction potential, sh (GSR)']$(MAC_curve_ID_GSR[techID,GSR_ag,s,purpose,energy19a,t,emm_eq,'Reduction potential, sh (GSR)'])
#      = MAC_curve_ID_GSR[techID,GSR_ag,s,purpose,energy19a,t,emm_eq,'Reduction potential, sh (GSR)'];

#  MAC_curve_ID_GSR_scale[techID,GSR_ag,s,purpose,energy19a,t,emm_eq,'Reduction potential, sh (Tot)']$(MAC_curve_ID_GSR[techID,GSR_ag,s,purpose,energy19a,t,emm_eq,'Reduction potential, sh (Tot)'])
#      = MAC_curve_ID_GSR[techID,GSR_ag,s,purpose,energy19a,t,emm_eq,'Reduction potential, sh (Tot)'];

#  MAC_curve_ID_GSR_scale[techID,GSR_ag,s,purpose,energy19a,t,emm_eq,'Reduction potential, sh (Tot overlap)']$(MAC_curve_ID_GSR[techID,GSR_ag,s,purpose,energy19a,t,emm_eq,'Reduction potential, sh (Tot overlap)'])
#      = MAC_curve_ID_GSR[techID,GSR_ag,s,purpose,energy19a,t,emm_eq,'Reduction potential, sh (Tot overlap)'];

#  MAC_curve_ID_GSR_scale[techID,GSR_ag,s,purpose,energy19a,t,emm_eq,'cost_DKK_pr_tCO2']
#      = MAC_curve_ID_scale[techID,s,purpose,energy19a,t,emm_eq,'cost_DKK_pr_tCO2']$(mapGrREFORM2GSR[purpose,energy19a,s,GSR_ag,t]);


## ---------------------------------------------------------------------------------------------------------
## Kør formodellen og sæt indtrængning til 1 for de teknologier, som trænger ind
## ---------------------------------------------------------------------------------------------------------

$FIX G_abatement_partial_exo;
$UNFIX G_abatement_partial_endo;
@SOLVE(M_abatement_partial);

rID.l[techID,purpose,energy19a,s,t]$(rID_input.l[techID,purpose,energy19a,s,t] > 0 and d1thetaID_k[techID,purpose,energy19a,s,t]) = 1;



# ----------------------------------------------------------------------------------------------------------------------
# Running the full model
# ----------------------------------------------------------------------------------------------------------------------

## We first solve the model with exogenous CCS
$MODEL M_calib_abatement_CCS_exo
    M_qEmm_korrektion

    -E_tRE_market # Vi hiver denne ud, da tvRE er en dead-end variabel

    # Eksogenisering af ID-indtrængning
     -E_rID
     -E_rCCS

    #B_abatement_reporting
;
  
$GROUP G_calib_abatement_endo
    G_endo

    -tvRE$(tx0[t] and d1tRE[purpose,energy19,r,t] and d1pRE_base[purpose,energy19,r,t]) # Vi hiver denne ud, da tvRE er en dead-end variabel

    # Eksogenisering af ID-indtrængning
     -rID$(d1thetaID_k[techID,purpose,energy19a,s,t])
     -rCCS$(tCCS[t] and sum(energy19, sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])))

    #G_abatement_reporting
;
  
$GROUP G_calib_abatement_exo
    G_exo

    # Eksogenisering af teknologiindtrængning
     rID$(d1thetaID_k[techID,purpose,energy19a,s,t])
     rCCS$(tCCS[t] and sum(energy19, sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])))
;


switch_forward_looking = 0;
switch_sluggish = 1;

#Now we move start year to 2023 
$SETGLOBAL start_shock_year 2022 #Year where we start the shock
set_time_periods(%start_shock_year%,%terminal_year%);


$FIX G_calib_abatement_exo;
$UNFIX G_calib_abatement_endo;
#  execute_unloaddi 'Output\Pre_Calib_abatement.gdx';
@SOLVE(M_calib_abatement_CCS_exo);


## Solving the model with endogenous CCS
$MODEL M_calib_abatement
    M_calib_abatement_CCS_exo

    E_rCCS
;

$GROUP G_calib_abatement_endo
    G_calib_abatement_endo

    rCCS$(tCCS[t] and sum(energy19, sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])))
;
  
$GROUP G_calib_abatement_exo
    G_calib_abatement_exo

    -rCCS$(tCCS[t] and sum(energy19, sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])))
;

$FIX G_calib_abatement_exo;
$UNFIX G_calib_abatement_endo;
@SOLVE(M_calib_abatement);

#Now we move start year to 2023 
$SETGLOBAL start_shock_year 2024 #Year where we start the shock
set_time_periods(%start_shock_year%,%terminal_year%);

$FIX G_calib_abatement_exo;
$UNFIX G_calib_abatement_endo;
@SOLVE(M_calib_abatement);

parameter
    qEmmCCStot[t]
    ;

qEmmCCStot[t] = sum(s, sumqEmmCCSbio.l[s,t] + sumqEmmCCSubio.l[s,t]);

execute_unloaddi 'Output\Calib_abatement.gdx';
@check_vBoP();