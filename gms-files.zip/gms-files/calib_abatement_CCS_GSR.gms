# ======================================================================================================================
# Calibration of CCS potential
# ======================================================================================================================

set CCScostGroup / 
    Kapital
    Energi
/;

parameter 
    thetaCCS_sh_ubio[techCCS,purpose,energy19,s,t,emm]
    thetaCCS_sh_bio[techCCS,purpose,energy19,s,t,emm]
    ubio_sh[techCCS,s,t]
    ParmsumqEmmProdECCSbio[techCCS,s,t]
    ParmsumqEmmProdECCSubio[techCCS,s,t]
    CCSPot[techCCS,s,t]
    shCCSPrice_group[techCCS,CCScostGroup,t]
    ;

# ----------------------------------------------------------------------------------------------------------------------
# Potentials on bio and ubio emissions
# ----------------------------------------------------------------------------------------------------------------------

# Potentialer (kt i 2030 givet fra KEFM)
CCSPot['t1','23000','2030'] = -700; # Aalborg 
#  CCSPot['t2','35011','2030'] = -100; # Biomasse
CCSPot['t3','35002','2030'] = -600; # Biogas 
CCSPot['t4','38393','2030'] = -500; # Affald

# Fossile andele (givet fra KEFM)
ubio_sh['t1','23000',t] = 1; 
#  ubio_sh['t2','35011',t] = 0; 
ubio_sh['t3','35002',t] = 0; 
ubio_sh['t4','38393',t] = 0.225; 

## Samlede CCS-reduktioner pr. branche fordelt på bio og ubio
ParmsumqEmmProdECCSubio[techCCS,s,'2030'] =    ubio_sh[techCCS,s,'2030']  * CCSPot[techCCS,s,'2030']; # Fossile
ParmsumqEmmProdECCSbio[techCCS,s,'2030']  = (1-ubio_sh[techCCS,s,'2030']) * CCSPot[techCCS,s,'2030']; # Biogene

# ----------------------------------------------------------------------------------------------------------------------
# Prices and subsidies
# ----------------------------------------------------------------------------------------------------------------------

# CCS-priser
CCSPrice.l['t1','23000',t,emm] = 1400;
#  CCSPrice.l['t2','35011',t,emm] = 820;
CCSPrice.l['t3','35002',t,emm] = 700; # Prisen på CCS på biogasopgradering er sat til 700 både for FL-puljen (ingen kilde) og ekspertgruppen (kilde: KEFM)
CCSPrice.l['t4','38393',t,emm] = 945;

# Andel af kapitalomkostninger, anlæg (LEVC)
shCCSPrice_group['t1','Kapital',t] = 0.765; # Aalborg Portland
#  shCCSPrice_group['t2','Kapital',t] = 0.763; # Biomasse
shCCSPrice_group['t3','Kapital',t] = 0.792; # Biogas
shCCSPrice_group['t4','Kapital',t] = 0.741; # Affald

# Andel af kapital- og energiomkostninger (LEVC)
shCCSPrice_group[techCCS,'Energi',t] = 1 - shCCSPrice_group[techCCS,'Kapital',t]; 

# Tilskud til CCS (Originalt fra Thomas, men korrigeret så virksomhederne har den rette tilskyndelse til CCS)
CCSsubsidy.l['t1','23000',t,emm] = 550;#600;
#  CCSsubsidy.l['t2','35011',t,emm] = 820;#700;
CCSsubsidy.l['t3','35002',t,emm] = 700;
CCSsubsidy.l['t4','38393',t,'CO2ubio'] = CCSPrice.l['t4','38393',t,'CO2ubio'] - ubio_sh['t4','38393',t]*tCO2_ETS.l[t]; # Eneste afgiftsbesparelse, affaldsværkerne opnår er sparede kvoteomkostninger 601.25;#531.25;
CCSsubsidy.l['t4','38393',t,'CO2bio'] = CCSPrice.l['t4','38393',t,'CO2bio'];

# ----------------------------------------------------------------------------------------------------------------------
# Dummies and initialisation
# ----------------------------------------------------------------------------------------------------------------------

d1thetaCCS[techCCS,purpose,energy19,s,t,emm] = no;

# Aalborg Portland: Kun ETS-udledninger
d1thetaCCS['t1','in_ETS',energy19,'23000',t,'CO2ubio'] = yes;
# Biomasse kraftvarme: Udledninger fra process_normal, process_special og in_ETS
#  d1thetaCCS['t2',purpose,energy19,'35011',t,'CO2bio'] = yes$(sameas[purpose,'process_normal'] or sameas[purpose,'process_special'] or sameas[purpose,'in_ETS']);
# Biogasopgradering: Udledninger fra Biogas i Process_special
d1thetaCCS['t3','process_special','Biogas','35002',t,'CO2bio'] = yes;
# Affaldsforbrænding: Udledninger fra Waste i in_ETS
d1thetaCCS['t4','in_ETS','waste','38393',t,'CO2ubio'] = yes;
d1thetaCCS['t4','in_ETS','waste','38393',t,'CO2bio'] = yes;


d1CCSbio[purpose,energy19,s,t,'CCSbio']$(d1EmmProdE[s,t,'CO2bio',purpose,energy19] and sum(techCCS, d1thetaCCS[techCCS,purpose,energy19,s,t,'CO2bio'])) = yes;

d1thetaCCSxE[techCCS,s,t,emm] = no;
d1thetaCCSxE['t1','23000',t,'CO2ubio'] = yes;

#  sigmaCCS.l[techCCS]         = 0.05 * thetaCCS_k.l[techCCS,'2030'];
rhoCCS[techCCS]             = 0.5;
rhoID[techID]               = 1; #LBS: Sikrer 100 procent indtrængning af reduktionspotentiale

# Switch der definerer, om CCS-teknologierne skal trænge ind (=1) eller ej (=0)
switch_CCS[techCCS] = 0;
switch_CCS['t1'] = 1;
#  switch_CCS['t2'] = 1;
switch_CCS['t3'] = 1;
switch_CCS['t4'] = 1;