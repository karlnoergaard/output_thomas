
# ------------------------------------------------------------------------------------------------------------------
# Indl�sning af ENS teknologikatalog til Ekspertgruppens 1. delrapport
# ------------------------------------------------------------------------------------------------------------------

$SETGLOBAL scen 'Model2' 

SETS
    techs
    eservice
    Scenario
    ;

# Indl�s sets fra .gdx fil
$gdxIn '..\Data\Abatement\ENS\ENSTechClean.gdx'
$load techs
$load eservice
$load Scenario
$gdxIn
#$offMulti

SETS 
    ENS_energy /
        INDELC
        INDAMB
        INDHWW
        INDNGA
        INDWAH
        INDHFO
        INDLPG
        INDDSL
        INDCOA
        INDWCH
        INDWPE
        INDDHD
        INDDHC
        INDBGA
        INDWST
        INDSOL
        INDDSB1
        INDSNG1
        INDSTR
        INDDSB2
        INDDSB
        INDSNG
        INDEFF /

    ENS_sectors /
        agrcul
        cement
        chemcl
        othcom
        constr
        foodbv
        metmch
        prvsrv
        pubsrv
        retail /

    ENS_energy19(energy19) /
        "Oil products" 
        "Diesel for transport"
        "Natural gas incl. biongas"
        "Coal and coke"
        "Waste"
        "Wood waste"
        "Renewable energy"
        "Straw for energy purposes"
        "Wood pellets"
        "Biogas"
        "Biodiesel"
        "Bioethanol"
        "Biooil"
        "Electricity"
        "District heat" /

    ENS_s(s) / 
        01011
        01012
        01020
        01031
        01032
        01051
        01052
        01061
        01062
        01070
        01080
        23000
        20000
        21000
        16000
        41430
        10120
        13150
        25000
        55560
        36000
        37000
        52000
        53000
        71000
        49024
        49025
        49031
        off
        45000
        46000
        47000 /
;

alias(ENS_energy19,ENS_energy19a);
alias(ENS_energy19,ENS_energy19aa);
alias(ENS_s,ENS_ss);


SET map_ENS_Energy2GR(ENS_energy,ENS_energy19) "test" /
    INDELC  . "Electricity"
    INDAMB  . "District heat"   #Snak med Asbj�rn om disse
    INDHWW  . "District heat"   #Snak med Asbj�rn om disse
    INDNGA  . "Natural gas incl. biongas"
    INDWAH  . "District heat" 
    INDHFO  . "Oil products" 
    INDLPG  . "Oil products"
    INDDSL  . "Diesel for transport"
    INDCOA  . "Coal and coke"
    INDWCH  . "Wood waste"
    INDWPE  . "Wood pellets"
    INDDHD  . "District heat"
    INDDHC  . "District heat"
    INDBGA  . "Biogas"
    INDWST  . "Waste"
    INDSOL  . "Renewable energy"
    INDDSB1 . "Biodiesel"
    INDSNG1 . "Biogas"
    INDSTR  . "Straw for energy purposes"
    INDDSB2 . "Biodiesel" 
    INDDSB  . "Biodiesel"
    INDSNG  . "Biogas" 
    /;

SET map_ENS_sectors2GR(ENS_sectors,ENS_s) "test2" /
    agrcul . (01011,01012,01020,01031,01032,01051,01052,01061,01062,01070,01080)
    cement . (23000)
    chemcl . (20000)
    othcom . (16000,21000,25000)
    constr . (41430)
    foodbv . (10120)
    metmch . (13150)
    prvsrv . (36000,52000,53000,55560,71000,37000,49024,49025,49031) #64000,38391,38392,38394,38395,51009,49509
    pubsrv . (off)
    retail . (45000,46000,47000) 
    /;

PARAMETER   
            # Indl�ste variable fra .gdx-fil
            eInput[Scenario,t,techs,ENS_sectors,eservice,ENS_energy,purpose]
            energy_service[Scenario,t,ENS_sectors,eservice,techs,purpose]
            var_cost[scenario,t,techs,ENS_sectors,eservice,purpose]
            fix_cost[scenario,t,techs,ENS_sectors,eservice,purpose]
            inv_cost[scenario,t,techs,ENS_sectors,eservice,purpose]

            # Variable for �ndring i energi og omkostninger
            eInputCh[t,techs,ENS_sectors,eservice,ENS_energy,purpose]
            eServiceCh[t,techs,ENS_sectors,eservice,purpose]
            var_costCh[t,techs,ENS_sectors,eservice,purpose]
            fix_costCh[t,techs,ENS_sectors,eservice,purpose]
            inv_costCh[t,techs,ENS_sectors,eservice,purpose]
            
            # Variable til tjek af data
            sumEInputData[purpose,ENS_energy,ENS_sectors,t]
            sumEInputGR[purpose,ENS_energy19,ENS_sectors,t]
            diffEInput[purpose,ENS_energy19,ENS_sectors,t]
            
            sumEServiceData[ENS_sectors,purpose,t]
            sumEServiceGR[ENS_sectors,purpose,t]
            diffEService[ENS_sectors,purpose,t]

            sumTotalCostData[ENS_sectors,purpose,t]
            sumTotalCostGR[ENS_sectors,purpose,t]
            diffTotalCost[ENS_sectors,purpose,t]
            
            # �ndring i energiinput
            eInputCh_agg[purpose,ENS_energy,ENS_sectors,t]
            eInputNegCh_GR[purpose,ENS_energy19a,ENS_s,t]
            tjekNegInput[purpose,ENS_energy19a,ENS_s,t]
            eInputNegCh_sumE[purpose,ENS_s,t]
            eInputNegCh_sumES[purpose,ENS_s,t]
            eInputPosCh_GR[purpose,ENS_energy19a,ENS_s,t]
            eInputCh_GR[purpose,energy19,s,t]
            #  eInputCh_map[techs,eservice,purpose,ENS_energy19,ENS_s,t]
            
            # �ndring i energiservice
            eServiceCh_agg[purpose,ENS_sectors,t]
            eServiceCh_GR[purpose,ENS_s,t]
            qRE_base[purpose,ENS_energy19,ENS_s,t]
            potential_shGR_LBS[purpose,ENS_energy19,ENS_s,t]
            potential_shGR_LBS_alt[purpose,ENS_energy19,ENS_s,t]
            eDisplacingpotential_shGR_LBS[purpose,ENS_energy19,ENS_energy19a,ENS_s,t]
            sumNegE19[purpose,ENS_s,t]
            
            # �ndring i totale omkostninger
            TotalCostCh_agg[purpose,ENS_sectors,t]
            TotalCostCh_GR[purpose,ENS_s,t]
            TotalCost_shGR_LBS[purpose,ENS_energy19a,ENS_s,t]

            #�ndring i emissioner
            EmmCh[emm_eq,purpose,ENS_energy19,ENS_s,t]
            ;

## Import af data fra .gdx fil
# Import ny bank
execute_loaddc '..\Data\Abatement\ENS\ENSTechClean.gdx' eInput = eInput.l;    
execute_loaddc '..\Data\Abatement\ENS\ENSTechClean.gdx' energy_service = energy_service.l; 
execute_loaddc '..\Data\Abatement\ENS\ENSTechClean.gdx' var_cost = var_cost.l;            
execute_loaddc '..\Data\Abatement\ENS\ENSTechClean.gdx' fix_cost = fix_cost.l;            
execute_loaddc '..\Data\Abatement\ENS\ENSTechClean.gdx' inv_cost = inv_cost.l;            

#Laver differencer i forhold til baseline for de tre modeller
$IF %scen%=='Model1': 
    eInputCh[t,techs,ENS_sectors,eservice,ENS_energy,purpose] = eInput['kf21-nohou-groenskatmod1-kf22kvoter_TIMES_DK',t,techs,ENS_sectors,eservice,ENS_energy,purpose] - eInput['kf21-nohou-kf22kvotepriser_TIMES_DK',t,techs,ENS_sectors,eservice,ENS_energy,purpose];
    eServiceCh[t,techs,ENS_sectors,eservice,purpose] = energy_service['kf21-nohou-groenskatmod1-kf22kvoter_TIMES_DK',t,ENS_sectors,eservice,techs,purpose] - energy_service['kf21-nohou-kf22kvotepriser_TIMES_DK',t,ENS_sectors,eservice,techs,purpose];
    var_costCh[t,techs,ENS_sectors,eservice,purpose] = var_cost['kf21-nohou-groenskatmod1-kf22kvoter_TIMES_DK',t,techs,ENS_sectors,eservice,purpose] - var_cost['kf21-nohou-kf22kvotepriser_TIMES_DK',t,techs,ENS_sectors,eservice,purpose];
    fix_costCh[t,techs,ENS_sectors,eservice,purpose] = fix_cost['kf21-nohou-groenskatmod1-kf22kvoter_TIMES_DK',t,techs,ENS_sectors,eservice,purpose] - fix_cost['kf21-nohou-kf22kvotepriser_TIMES_DK',t,techs,ENS_sectors,eservice,purpose];
    inv_costCh[t,techs,ENS_sectors,eservice,purpose] = inv_cost['kf21-nohou-groenskatmod1-kf22kvoter_TIMES_DK',t,techs,ENS_sectors,eservice,purpose] - inv_cost['kf21-nohou-kf22kvotepriser_TIMES_DK',t,techs,ENS_sectors,eservice,purpose];
$ENDIF

$IF %scen%=='Model2': 
    eInputCh[t,techs,ENS_sectors,eservice,ENS_energy,purpose] = eInput['kf21-nohou-groenskatmod2-kf22kvoter_TIMES_DK',t,techs,ENS_sectors,eservice,ENS_energy,purpose] - eInput['kf21-nohou-kf22kvotepriser_TIMES_DK',t,techs,ENS_sectors,eservice,ENS_energy,purpose];
    eServiceCh[t,techs,ENS_sectors,eservice,purpose] = energy_service['kf21-nohou-groenskatmod2-kf22kvoter_TIMES_DK',t,ENS_sectors,eservice,techs,purpose] - energy_service['kf21-nohou-kf22kvotepriser_TIMES_DK',t,ENS_sectors,eservice,techs,purpose];
    var_costCh[t,techs,ENS_sectors,eservice,purpose] = var_cost['kf21-nohou-groenskatmod2-kf22kvoter_TIMES_DK',t,techs,ENS_sectors,eservice,purpose] - var_cost['kf21-nohou-kf22kvotepriser_TIMES_DK',t,techs,ENS_sectors,eservice,purpose];
    fix_costCh[t,techs,ENS_sectors,eservice,purpose] = fix_cost['kf21-nohou-groenskatmod2-kf22kvoter_TIMES_DK',t,techs,ENS_sectors,eservice,purpose] - fix_cost['kf21-nohou-kf22kvotepriser_TIMES_DK',t,techs,ENS_sectors,eservice,purpose];
    inv_costCh[t,techs,ENS_sectors,eservice,purpose] = inv_cost['kf21-nohou-groenskatmod2-kf22kvoter_TIMES_DK',t,techs,ENS_sectors,eservice,purpose] - inv_cost['kf21-nohou-kf22kvotepriser_TIMES_DK',t,techs,ENS_sectors,eservice,purpose];
$ENDIF

$IF %scen%=='Model3': 
    eInputCh[t,techs,ENS_sectors,eservice,ENS_energy,purpose] = eInput[t,'kf21-nohou-groenskatmod3-kf22kvoter_TIMES_DK',techs,ENS_sectors,eservice,ENS_energy,purpose] - eInput[t,'kf21-nohou-kf22kvotepriser_TIMES_DK',techs,ENS_sectors,eservice,ENS_energy,purpose];
    eServiceCh[t,techs,ENS_sectors,eservice,purpose] = energy_service[t,'kf21-nohou-groenskatmod3-kf22kvoter_TIMES_DK',ENS_sectors,eservice,techs,purpose] - energy_service[t,'kf21-nohou-kf22kvotepriser_TIMES_DK',ENS_sectors,eservice,techs,purpose];
    var_costCh[t,techs,ENS_sectors,eservice,purpose] = var_cost[t,'kf21-nohou-groenskatmod3-kf22kvoter_TIMES_DK',techs,ENS_sectors,eservice,purpose] - var_cost[t,'kf21-nohou-kf22kvotepriser_TIMES_DK',techs,ENS_sectors,eservice,purpose];
    fix_costCh[t,techs,ENS_sectors,eservice,purpose] = fix_cost[t,'kf21-nohou-groenskatmod3-kf22kvoter_TIMES_DK',techs,ENS_sectors,eservice,purpose] - fix_cost[t,'kf21-nohou-kf22kvotepriser_TIMES_DK',techs,ENS_sectors,eservice,purpose];
    inv_costCh[t,techs,ENS_sectors,eservice,purpose] = inv_cost[t,'kf21-nohou-groenskatmod3-kf22kvoter_TIMES_DK',techs,ENS_sectors,eservice,purpose] - inv_cost[t,'kf21-nohou-kf22kvotepriser_TIMES_DK',techs,ENS_sectors,eservice,purpose];
$ENDIF

# S�tter teknologiskift i opvarmning til 0, fordi de ikke er lagt rigtigt ind i ENS' k�rsler i IntERACT
eInputCh[t,techs,ENS_sectors,eservice,ENS_energy,'heating'] = 0;
eServiceCh[t,techs,ENS_sectors,eservice,'heating']          = 0;
var_costCh[t,techs,ENS_sectors,eservice,'heating']          = 0;
fix_costCh[t,techs,ENS_sectors,eservice,'heating']          = 0;
inv_costCh[t,techs,ENS_sectors,eservice,'heating']          = 0;


sumEServiceData[ENS_sectors,purpose,t] = sum((techs,eservice), eServiceCh[t,techs,ENS_sectors,eservice,purpose]);


# ------------------------------------------------------------------------------------------------------------------
# Fordeling af energiinput p� GR-brancher fra ENS-brancher ud fra deres initiale energiforbrug
# ------------------------------------------------------------------------------------------------------------------
# �ndringen i energiinput v�gtes efter fordelingen af det initiale energiforbrug til et givet form�l mellem sektorerne i en ENS_sectors-kategori 
#### OBS!!! Denne v�gtning g�r, at der energi�ndringer og omkostninger fjernes, hvis der ikke er noget initialt energiforbrug p� det givne form�l - pt. kun et problem med s�rlig proces i constr (41430)
# V�kstkorrektion af energi�ndringer
eInputCh[t,techs,ENS_sectors,eservice,ENS_energy,purpose] = eInputCh[t,techs,ENS_sectors,eservice,ENS_energy,purpose]*growth_factor[t];

# Map af energiinput og sum over teknologier
eInputCh_agg[purpose,ENS_energy,ENS_sectors,t] = sum((eservice,techs), eInputCh[t,techs,ENS_sectors,eservice,ENS_energy,purpose]);




eInputNegCh_GR[purpose,ENS_energy19a,ENS_s,t]
                                    = sum((ENS_sectors,ENS_energy)$(map_ENS_sectors2GR(ENS_sectors,ENS_s) and map_ENS_Energy2GR(ENS_energy,ENS_energy19a)), eInputCh_agg[purpose,ENS_energy,ENS_sectors,t]$(eInputCh_agg[purpose,ENS_energy,ENS_sectors,t]<0) # Medtager kun fald i energiinput
                                    * (1 + (qRE.l[purpose,ENS_energy19a,ENS_s,t]/sum((ENS_ss)$(map_ENS_sectors2GR(ENS_sectors,ENS_ss)), qRE.l[purpose,ENS_energy19a,ENS_ss,t]) - 1)$(sum((ENS_ss)$(map_ENS_sectors2GR(ENS_sectors,ENS_ss)),qRE.l[purpose,ENS_energy19a,ENS_ss,t]))) # Fordeling af energifald p� GR-brancher p� baggrund af initialt forbrug af den givne energivare
                                    * (1 + (1 / sum((ENS_ss)$(map_ENS_sectors2GR(ENS_sectors,ENS_ss)),1) - 1)$(not sum((ENS_ss)$(map_ENS_sectors2GR(ENS_sectors,ENS_ss)),qRE.l[purpose,ENS_energy19a,ENS_ss,t])))); # Proportional fordeling af energifald, hvis der ikke er noget initialt energiforbrug i nogen af de opsplittede brancher

tjekNegInput[purpose,ENS_energy19a,ENS_s,t]
                                    = sum((ENS_sectors,ENS_energy)$(map_ENS_sectors2GR(ENS_sectors,ENS_s) and map_ENS_Energy2GR(ENS_energy,ENS_energy19a)), eInputCh_agg[purpose,ENS_energy,ENS_sectors,t]$(eInputCh_agg[purpose,ENS_energy,ENS_sectors,t]<0) # Medtager kun fald i energiinput
                                    * (1 + (qRE.l[purpose,ENS_energy19a,ENS_s,t]/sum((ENS_ss)$(map_ENS_sectors2GR(ENS_sectors,ENS_ss)),qRE.l[purpose,ENS_energy19a,ENS_ss,t]) - 1)$(sum((ENS_ss)$(map_ENS_sectors2GR(ENS_sectors,ENS_ss)),qRE.l[purpose,ENS_energy19a,ENS_ss,t]))))
                                    - eInputNegCh_GR[purpose,ENS_energy19a,ENS_s,t]; # Fordeling af energifald p� GR-brancher p� baggrund af initialt forbrug af den givne energivare

parameter negtoENS[purpose,ENS_energy19a,ENS_sectors,t], DiffnegtoENS[purpose,ENS_energy19a,ENS_sectors,t];

negtoENS[purpose,ENS_energy19a,ENS_sectors,t] = sum((ENS_s)$(map_ENS_sectors2GR(ENS_sectors,ENS_s)), eInputNegCh_GR[purpose,ENS_energy19a,ENS_s,t]);
DiffnegtoENS[purpose,ENS_energy19a,ENS_sectors,t] = sum(ENS_energy$(map_ENS_Energy2GR(ENS_energy,ENS_energy19a)), eInputCh_agg[purpose,ENS_energy,ENS_sectors,t]$(eInputCh_agg[purpose,ENS_energy,ENS_sectors,t]<0)) - negtoENS[purpose,ENS_energy19a,ENS_sectors,t];


# Sum over negative �ndringer i energiinput for et givet form�l og branche
eInputNegCh_sumE[purpose,ENS_s,t] = sum(ENS_energy19a$(eInputNegCh_GR[purpose,ENS_energy19a,ENS_s,t]<0), eInputNegCh_GR[purpose,ENS_energy19a,ENS_s,t]);

# Sum over negative �ndringer i energiinput for et givet form�l over alle GR-brancher i en given ENS-branche
eInputNegCh_sumES[purpose,ENS_s,t] = sum((ENS_sectors,ENS_energy)$(map_ENS_sectors2GR(ENS_sectors,ENS_s) and eInputCh_agg[purpose,ENS_energy,ENS_sectors,t]<0), eInputCh_agg[purpose,ENS_energy,ENS_sectors,t]); # Medtager kun fald i energiinput

# De positive �ndringer i energiinput fordeles p� energiaktiviteter ud fra, hvor store fald hver branche har 
eInputPosCh_GR[purpose,ENS_energy19a,ENS_s,t]
                                    = sum((ENS_sectors,ENS_energy)$(map_ENS_sectors2GR(ENS_sectors,ENS_s) and map_ENS_Energy2GR(ENS_energy,ENS_energy19a)), eInputCh_agg[purpose,ENS_energy,ENS_sectors,t]$(eInputCh_agg[purpose,ENS_energy,ENS_sectors,t]>0)) # Medtager kun stigning i energiinput
                                    * (1 + (eInputNegCh_sumE[purpose,ENS_s,t] / eInputNegCh_sumES[purpose,ENS_s,t] - 1)$(eInputNegCh_sumES[purpose,ENS_s,t])) # De positive �ndringer fordeles ud efter faldet
                                    * (1 + (1 / sum(ENS_sectors$(map_ENS_sectors2GR(ENS_sectors,ENS_s)), sum((ENS_ss)$(map_ENS_sectors2GR(ENS_sectors,ENS_ss)),1)) - 1)$(not eInputNegCh_sumES[purpose,ENS_s,t])); # Hvis der ikke er et fald i andre energiinput fordeles stigningen ligeligt ud p� alle GR-brancher

parameter postoENS[purpose,ENS_energy19a,ENS_sectors,t], DiffpostoENS[purpose,ENS_energy19a,ENS_sectors,t];

postoENS[purpose,ENS_energy19a,ENS_sectors,t] = sum((ENS_s)$(map_ENS_sectors2GR(ENS_sectors,ENS_s)), eInputPosCh_GR[purpose,ENS_energy19a,ENS_s,t]);
DiffpostoENS[purpose,ENS_energy19a,ENS_sectors,t] = sum(ENS_energy$(map_ENS_Energy2GR(ENS_energy,ENS_energy19a)), eInputCh_agg[purpose,ENS_energy,ENS_sectors,t]$(eInputCh_agg[purpose,ENS_energy,ENS_sectors,t]>0)) - postoENS[purpose,ENS_energy19a,ENS_sectors,t];

# Sum af positive og negative �ndringer i energiinput
eInputCh_GR[purpose,ENS_energy19a,ENS_s,t] = eInputNegCh_GR[purpose,ENS_energy19a,ENS_s,t] + eInputPosCh_GR[purpose,ENS_energy19a,ENS_s,t];

# Sum til at tjekke, at fordelingen er g�et godt
sumEInputGR[purpose,ENS_energy19a,ENS_sectors,t] = sum((ENS_s)$(map_ENS_sectors2GR(ENS_sectors,ENS_s)), eInputCh_GR[purpose,ENS_energy19a,ENS_s,t]);
diffEInput[purpose,ENS_energy19a,ENS_sectors,t] = sum(ENS_energy$(map_ENS_Energy2GR(ENS_energy,ENS_energy19a)), eInputCh_agg[purpose,ENS_energy,ENS_sectors,t]) - sumEInputGR[purpose,ENS_energy19a,ENS_sectors,t];

#  tjek = sum((ENS_energy19,ENS_sectors,purpose,t), diffEInput[ENS_sectors,purpose,t]);
#  ABORT$(abs(tjek) gt 1e-6) tjek, "diffEInput stemmer ikke";


# ------------------------------------------------------------------------------------------------------------------
# Umiddelbare emissions�ndringer
# ------------------------------------------------------------------------------------------------------------------
EmmCh[emm,purpose,ENS_energy19,ENS_s,t] = (eInputCh_GR[purpose,ENS_energy19,ENS_s,t]/growth_factor[t]) * uEmmProdE.l[ENS_s,t,emm,ENS_energy19]*uEOPProdE.l[ENS_s,t,emm,ENS_energy19];

EmmCh['CO2e',purpose,ENS_energy19,ENS_s,t] = sum(emm, EmmCh[emm,purpose,ENS_energy19,ENS_s,t]*GWP.l[emm]);

Parameter emisfaktCO2e[emm_eq,energy19,s,t]; 
emisfaktCO2e[emm,energy19,s,t] = uEmmProdE.l[s,t,emm,energy19]*GWP.l[emm];
emisfaktCO2e['CO2e',energy19,s,t] = sum(emm,emisfaktCO2e[emm,energy19,s,t]);

# ------------------------------------------------------------------------------------------------------------------
# Beregning af thetaID'er 
# ------------------------------------------------------------------------------------------------------------------

# Reduktionspotentiale for energiinput i energiaktivitet a
potential_shGR_LBS[purpose,ENS_energy19a,ENS_s,t]$(tx0[t] and d1qRE[purpose,ENS_energy19a,ENS_s,t] and (eInputCh_GR[purpose,ENS_energy19a,ENS_s,t]<0)) 
                                    = eInputCh_GR[purpose,ENS_energy19a,ENS_s,t]/qRE.l[purpose,ENS_energy19a,ENS_s,t];

# Sum over negative energi�ndringer i energiaktivitet a
sumNegE19[purpose,ENS_s,t] = sum(ENS_energy19a$(eInputCh_GR[purpose,ENS_energy19a,ENS_s,t]<0), eInputCh_GR[purpose,ENS_energy19a,ENS_s,t]);

# Fordeling af stigningen i energiinput (energy19) ud p� de energiaktiviteter (energy19a), som har reduceret energiforbruget
# Betingelsen p� qRE skyldes formentlig, at energiforbruget ikke er mappet til ENS endnu - kan forh�bentlig udelades senere...
eDisplacingpotential_shGR_LBS[purpose,ENS_energy19,ENS_energy19a,ENS_s,t]$(qRE.l[purpose,ENS_energy19a,ENS_s,t] and eInputCh_GR[purpose,ENS_energy19,ENS_s,t]>0) = 
                                                                            (eInputCh_GR[purpose,ENS_energy19a,ENS_s,t] / sumNegE19[purpose,ENS_s,t])$(eInputCh_GR[purpose,ENS_energy19a,ENS_s,t]<0 and sumNegE19[purpose,ENS_s,t]<0)
                                                                            * eInputCh_GR[purpose,ENS_energy19,ENS_s,t] / qRE.l[purpose,ENS_energy19a,ENS_s,t]; # Overvej om det skal v�re qRE[energy19a eller energy19]

parameter PotCh[purpose,ENS_energy19a,ENS_s,t];
PotCh[purpose,ENS_energy19a,ENS_s,t]$(eInputCh_GR[purpose,ENS_energy19a,ENS_s,t]<0 and not qRE.l[purpose,ENS_energy19a,ENS_s,t]) = yes;


# ------------------------------------------------------------------------------------------------------------------
# Fordeling af omkostninger p� GR-brancher fra ENS-brancher ud fra deres initiale energiforbrug (Omkostninger i data er m�lt i mio. kr.)
# ------------------------------------------------------------------------------------------------------------------

# F�rst omregnes omkostningerne (2022-priser??) til l�bende priser med FM's deflator. Har skrevet mail til Thomas omkring prisniveauer
parameter fm_deflator[t];
fm_deflator['2015'] =  0.953;
fm_deflator['2016'] =  0.957;
fm_deflator['2017'] =  0.969;
fm_deflator['2018'] =  0.977;
fm_deflator['2019'] =  0.986;
fm_deflator['2020'] =  0.987;
fm_deflator['2021'] =  1.000;
fm_deflator['2022'] =  1.016;
fm_deflator['2023'] =  1.035;
fm_deflator['2024'] =  1.056;
fm_deflator['2025'] =  1.079;
fm_deflator['2026'] =  1.100;
fm_deflator['2027'] =  1.122;
fm_deflator['2028'] =  1.144;
fm_deflator['2029'] =  1.166;
fm_deflator['2030'] =  1.188;
fm_deflator['2031'] =  1.212;
fm_deflator['2032'] =  1.235;
fm_deflator['2033'] =  1.259;
fm_deflator['2034'] =  1.283;
fm_deflator['2035'] =  1.308;
fm_deflator['2036'] =  1.334;
fm_deflator['2037'] =  1.361;
fm_deflator['2038'] =  1.389;
fm_deflator['2039'] =  1.417;
fm_deflator['2040'] =  1.445;

var_costCh[t,techs,ENS_sectors,eservice,purpose] = var_costCh[t,techs,ENS_sectors,eservice,purpose] * fm_deflator[t]; #$(t.val > 2014 and t.val < 2041)
fix_costCh[t,techs,ENS_sectors,eservice,purpose] = fix_costCh[t,techs,ENS_sectors,eservice,purpose] * fm_deflator[t]; #$(t.val > 2014 and t.val < 2041)
inv_costCh[t,techs,ENS_sectors,eservice,purpose] = inv_costCh[t,techs,ENS_sectors,eservice,purpose] * fm_deflator[t]; #$(t.val > 2014 and t.val < 2041)

# Herefter omregnes de til faste (2018-priser) i GR
var_costCh[t,techs,ENS_sectors,eservice,purpose] = var_costCh[t,techs,ENS_sectors,eservice,purpose] * inf_factor[t]; 
fix_costCh[t,techs,ENS_sectors,eservice,purpose] = fix_costCh[t,techs,ENS_sectors,eservice,purpose] * inf_factor[t];
inv_costCh[t,techs,ENS_sectors,eservice,purpose] = inv_costCh[t,techs,ENS_sectors,eservice,purpose] * inf_factor[t];

# Sum af de tre forskellige priser
TotalCostCh_agg[purpose,ENS_sectors,t] = sum((techs,eservice),(var_costCh[t,techs,ENS_sectors,eservice,purpose] + fix_costCh[t,techs,ENS_sectors,eservice,purpose] + inv_costCh[t,techs,ENS_sectors,eservice,purpose]));

# De samlede omkostninger fordeles ud p� de GR-brancher, hvor energiforbruget reduceres (samme fordelingsn�gle som for positive �ndringer i energiforbrug)
TotalCostCh_GR[purpose,ENS_s,t] = sum((ENS_sectors)$(map_ENS_sectors2GR(ENS_sectors,ENS_s)), TotalCostCh_agg[purpose,ENS_sectors,t])
                                  * (1 + (eInputNegCh_sumE[purpose,ENS_s,t] / eInputNegCh_sumES[purpose,ENS_s,t] - 1)$(eInputNegCh_sumES[purpose,ENS_s,t])) # De positive �ndringer fordeles ud efter faldet
                                  * (1 + (1 / sum(ENS_sectors$(map_ENS_sectors2GR(ENS_sectors,ENS_s)), sum((ENS_ss)$(map_ENS_sectors2GR(ENS_sectors,ENS_ss)),1)) - 1)$(not eInputNegCh_sumES[purpose,ENS_s,t])); # Hvis der ikke er et fald i andre energiinput fordeles stigningen ligeligt ud p� alle GR-brancher

# Sum til at tjekke, at fordelingen er g�et godt
sumTotalCostGR[ENS_sectors,purpose,t] = sum((ENS_s)$(map_ENS_sectors2GR(ENS_sectors,ENS_s)), TotalCostCh_GR[purpose,ENS_s,t]);
diffTotalCost[ENS_sectors,purpose,t] = TotalCostCh_agg[purpose,ENS_sectors,t] - sumTotalCostGR[ENS_sectors,purpose,t];

#  tjek = sum((ENS_sectors,purpose,t), diffTotalCost[ENS_sectors,purpose,t]);
#  ABORT$(abs(tjek) gt 1e-6) tjek, "diffTotalCost stemmer ikke";

# ------------------------------------------------------------------------------------------------------------------
# Beregning af thetaID_K'er 
# ------------------------------------------------------------------------------------------------------------------

# Total Cost er m�lt i mio. kr., s� de konverteres til mia.
TotalCost_shGR_LBS[purpose,ENS_energy19a,ENS_s,t]$(qRE.l[purpose,ENS_energy19a,ENS_s,t] and eInputCh_GR[purpose,ENS_energy19a,ENS_s,t]<0) 
                                                    = (eInputCh_GR[purpose,ENS_energy19a,ENS_s,t] / sumNegE19[purpose,ENS_s,t])$(sumNegE19[purpose,ENS_s,t]<0)
                                                      * (TotalCostCh_GR[purpose,ENS_s,t]/1000) / qRE.l[purpose,ENS_energy19a,ENS_s,t];

# ------------------------------------------------------------------------------------------------------------------
# Beregning af eService (Bruges som udgangspunkt ikke til beregningerne af thetaID eller thetaID_K) 
# ------------------------------------------------------------------------------------------------------------------

# Import af baseline energiforbrug
#qRE_base[purpose,ENS_energy19,ENS_s,t] = qRE.l[purpose,ENS_energy19,ENS_s,t];

# Map af energiservice og sum over teknologier. 
# �ndringen i energiservice v�gtes efter fordelingen af det initiale energiforbrug til et givet form�l mellem sektorerne i en ENS_sectors-kategori 
eServiceCh_agg[purpose,ENS_sectors,t] = sum((eservice,techs), eServiceCh[t,techs,ENS_sectors,eservice,purpose]);

eServiceCh_GR[purpose,ENS_s,t] = sum((ENS_sectors)$(map_ENS_sectors2GR(ENS_sectors,ENS_s)), eServiceCh_agg[purpose,ENS_sectors,t]
                                 * (sum(ENS_energy19a,qRE.l[purpose,ENS_energy19a,ENS_s,t])/sum((ENS_energy19a,ENS_ss)$(map_ENS_sectors2GR(ENS_sectors,ENS_ss)),qRE.l[purpose,ENS_energy19a,ENS_ss,t]))$(sum((ENS_energy19a,ENS_ss)$(map_ENS_sectors2GR(ENS_sectors,ENS_ss)),qRE.l[purpose,ENS_energy19a,ENS_ss,t])));

# Sum til at tjekke, at fordelingen er g�et godt
sumEServiceGR[ENS_sectors,purpose,t] = sum((ENS_s)$(map_ENS_sectors2GR(ENS_sectors,ENS_s)), eServiceCh_GR[purpose,ENS_s,t]);
diffEService[ENS_sectors,purpose,t] = sumEServiceData[ENS_sectors,purpose,t] - sumEServiceGR[ENS_sectors,purpose,t];

#  tjek = sum((ENS_sectors,purpose,t), diffEService[ENS_sectors,purpose,t]);
#  ABORT$(abs(tjek) gt 1e-6) tjek, "diffEService stemmer ikke";
# ------------------------------------------------------------------------------------------------------------------
# Unload exogenous values and dummies
# ------------------------------------------------------------------------------------------------------------------

parameters
    thetaID_in[techID,purpose,energy19a,energy19,s,t]
    thetaID_k_in[techID,purpose,energy19a,s,t]
    counter
;

counter = 0;

#Loop over potentialer, hvor hver energiakivitet og energiinput f�r tildelt en 'aggregeret' teknologi
loop(ENS_s,loop(purpose,loop(ENS_energy19a,
#if(sum(t,techexists(s,purpose,energy19a,omk,t)),
    counter = counter+1;
    thetaID_in[techID,purpose,ENS_energy19a,ENS_energy19,ENS_s,tx0]$(ord(techID)=counter and sameas(ENS_energy19a,ENS_energy19)) = potential_shGR_LBS[purpose,ENS_energy19a,ENS_s,tx0];
    thetaID_in[techID,purpose,ENS_energy19a,ENS_energy19,ENS_s,tx0]$(ord(techID)=counter and not sameas(ENS_energy19a,ENS_energy19)) = eDisplacingpotential_shGR_LBS[purpose,ENS_energy19,ENS_energy19a,ENS_s,tx0];
    thetaID_k_in[techID,purpose,ENS_energy19a,ENS_s,tx0]$(ord(techID)=counter) = TotalCost_shGR_LBS[purpose,ENS_energy19a,ENS_s,tx0];
);););#);

tjek_potentiale('efter-GR_unloaded') = sum((s,purpose,energy19,energy19a,techid), thetaID_in[techID,purpose,energy19a,energy19,s,tMAC]*qEmmProdE.l[s,tMAC,'co2e',purpose,energy19]/1000); 
display tjek_potentiale,tjek_potentiale_brch;

# Indl�sning af thetaID og thetaID_k
thetaID.l[techID,purpose,energy19a,energy19,s,tx0] = thetaID_in[techID,purpose,energy19a,energy19,s,tx0];
thetaid_k.l[techID,purpose,energy19a,s,tx0] = thetaid_k_in[techID,purpose,energy19a,s,tx0];

thetaID.l[techID,purpose,energy19a,energy19,s,t]$(t.val > 2030) = thetaID.l[techID,purpose,energy19a,energy19,s,'2030'];
thetaID_k.l[techID,purpose,energy19a,s,t]$(t.val > 2030) = thetaID_k.l[techID,purpose,energy19a,s,'2030'];


# Abatement sl�es fra

thetaID.l[techID,purpose,energy19a,energy19,s,t] = 0;
thetaID.l[techID,purpose,energy19a,energy19,s,t] = 0;
thetaID.l[techID,purpose,energy19a,energy19,s,t] = 0;

thetaID_k.l[techID,purpose,energy19a,s,t] = 0;
thetaID_k.l[techID,purpose,energy19a,s,t] = 0;
thetaID_k.l[techID,purpose,energy19a,s,t] = 0;

# ------------------------------------------------------------------------------------------------------------------
# Set dummies
# ------------------------------------------------------------------------------------------------------------------

d1thetaID_k[techID,purpose,energy19a,s,t] = yes$(thetaid_k.l[techID,purpose,energy19a,s,t]);
d1thetaID[techID,purpose,energy19a,energy19,s,t]$(thetaID.l[techID,purpose,energy19a,energy19,s,t]) = yes;

d1uREE_tech[purpose,energy19a,energy19,s,t] = sum(techID,d1thetaID[techID,purpose,energy19a,energy19,s,t]);

d1_qgj_tech[purpose,energy19,s,t] = sum((techID,energy19a), d1thetaID[techID,purpose,energy19a,energy19,s,t]);
d1_tech_s[techID,s,t] = sum((purpose,energy19a,energy19), d1thetaID[techID,purpose,energy19a,energy19,s,t]);

# Technologies only enter in 2025
thetaID.l[techID,purpose,energy19a,energy19,s,t]$(t.val<=first_year_of_technologies.val) = 0;


# ------------------------------------------------------------------------------------------------------------------
# Tjek at thetaID giver de rette energi�ndringer
# ------------------------------------------------------------------------------------------------------------------

parameters
    uREE_theta[purpose,energy19a,energy19,s,t]
    qREE_theta[purpose,energy19a,energy19,s,t]
    qREgj_theta[purpose,energy19,s,t]
    qREgj_thetaCh[purpose,energy19,s,t]
    sumqREgj_thetaCh[purpose,ENS_energy19,ENS_sectors,t]
    diffqREgj_thetaCh[purpose,ENS_energy19,ENS_sectors,t]
    ;

    uREE_theta[purpose,energy19a,energy19,s,t]$(tx0[t] and (d1qREE[purpose,energy19a,energy19,s,t] or d1uREE_tech[purpose,energy19a,energy19,s,t]))
                                     = uREExID.l[purpose,energy19a,energy19,s,t] + sum(techID$(d1thetaID_k[techID,purpose,energy19a,s,t] and d1thetaID[techID,purpose,energy19a,energy19,s,t]), thetaID.l[techID,purpose,energy19a,energy19,s,t]);
    qREE_theta[purpose,energy19a,energy19,s,t]$(tx0[t] and (d1qREE[purpose,energy19a,energy19,s,t] or d1uREE_tech[purpose,energy19a,energy19,s,t] ))
                                     = uREE_theta[purpose,energy19a,energy19,s,t] * qRE.l[purpose,energy19a,s,t];
    qREgj_theta[purpose,energy19,s,t]$(tx0[t] and (d1qRE[purpose,energy19,s,t] or d1_qgj_tech[purpose,energy19,s,t]))
                                     = sum(energy19a$(d1qREE[purpose,energy19a,energy19,s,t] or d1uREE_tech[purpose,energy19a,energy19,s,t]), qREE_theta[purpose,energy19a,energy19,s,t]);
    qREgj_thetaCh[purpose,energy19,s,t] = qREgj_theta[purpose,energy19,s,t] - qREgj.l[purpose,energy19,s,t];
    sumqREgj_thetaCh[purpose,ENS_energy19,ENS_sectors,t] = sum((ENS_s)$(map_ENS_sectors2GR(ENS_sectors,ENS_s)), qREgj_thetaCh[purpose,ENS_energy19,ENS_s,t]);
    diffqREgj_thetaCh[purpose,ENS_energy19,ENS_sectors,t] = sum(ENS_energy$(map_ENS_Energy2GR(ENS_energy,ENS_energy19)), eInputCh_agg[purpose,ENS_energy,ENS_sectors,t]) - sumqREgj_thetaCh[purpose,ENS_energy19,ENS_sectors,t];

Parameter
    uREE_repo[purpose,energy19a,energy19,s,t]
    qREE_repo[purpose,energy19a,energy19,s,t]
    qREgj_repo[purpose,energy19,s,t]
    qEmmProdE_repo[s,t,emm_eq,purpose,energy19]
    qEmmProdE_repo2[s,t,emm_eq,purpose,energy19]
    qEmmProdE_repo3[s,t,purpose,energy19a,energy19]
    ;

qREE_repo[purpose,energy19a,energy19,s,t]   = uREE_theta[purpose,energy19a,energy19,s,t] * qRE.l[purpose,energy19a,s,t];

qREgj_repo[purpose,energy19,s,t]            = sum(energy19a, qREE_repo[purpose,energy19a,energy19,s,t]);

qEmmProdE_repo[s,t,emm,purpose,energy19]    = (qREgj_repo[purpose,energy19,s,t]/growth_factor[t]) * uEmmProdE.l[s,t,emm,energy19];
qEmmProdE_repo[s,t,'CO2e',purpose,energy19] = sum(emm, qEmmProdE_repo[s,t,emm,purpose,energy19]);
qEmmProdE_repo2[s,t,emm,purpose,energy19]   = (qREgj_thetaCh[purpose,energy19,s,t]/growth_factor[t]) * uEmmProdE.l[s,t,emm,energy19];
qEmmProdE_repo2[s,t,'CO2e',purpose,energy19] = sum(emm, qEmmProdE_repo2[s,t,emm,purpose,energy19]);

qEmmProdE_repo3[s,t,purpose,energy19a,energy19] = uREE_theta[purpose,energy19a,energy19,s,t] * qEmmProdE.l[s,t,'CO2e',purpose,energy19];



# ------------------------------------------------------------------------------------------------------------------
# Korrektion af thetaID og thetaID_k, n�r der er for stort reduktionspotentiale ift. det initiale energiforbrug
# ------------------------------------------------------------------------------------------------------------------
 
# OBS: Der burde ikke v�re nogen, hvis mappingen er gjort rigtigt!! Hvis der skal korrigeres b�r det nok ogs� g�res for kapitalapparatet????
parameter thetaID_tjek[purpose,energy19a,s,t], thetaID_tjek2[techID,purpose,energy19a,energy19,s,t], KorrThetaID[purpose,energy19a,s,t];
thetaID_tjek[purpose,energy19a,s,t] = sum((techID, energy19)$(sameas(energy19a,energy19)), thetaID.l[techID,purpose,energy19a,energy19,s,t]);
thetaID_tjek2[techID,purpose,energy19a,energy19,s,t]$(thetaID.l[techID,purpose,energy19a,energy19,s,t]<-0.96) = thetaID.l[techID,purpose,energy19a,energy19,s,t];
KorrThetaID[purpose,energy19a,s,t]$(thetaID_tjek[purpose,energy19a,s,t]<-0.96) = thetaID_tjek[purpose,energy19a,s,t];
display KorrThetaID;
thetaID_tjek[purpose,energy19a,s,t]$(thetaID_tjek[purpose,energy19a,s,t]<-0.96) = thetaID_tjek[purpose,energy19a,s,t]/0.96;
thetaID.l[techID,purpose,energy19a,energy19,s,t]$(thetaID_tjek[purpose,energy19a,s,t]<-0.96 and d1thetaID[techID,purpose,energy19a,energy19,s,t]) = thetaID.l[techID,purpose,energy19a,energy19,s,t]/(-thetaID_tjek[purpose,energy19a,s,t]);
thetaID_k.l[techID,purpose,energy19a,s,t]$(thetaID_tjek[purpose,energy19a,s,t]<-0.96 and sum(energy19,d1thetaID[techID,purpose,energy19a,energy19,s,t])) = thetaID_k.l[techID,purpose,energy19a,s,t]/(-thetaID_tjek[purpose,energy19a,s,t]);

# ------------------------------------------------------------------------------------------------------------------
# Umiddelbare emissions�ndringer efter korrektion af theta_ID
# ------------------------------------------------------------------------------------------------------------------

Parameter 
    uREE_korr[purpose,energy19a,energy19,s,t]
    qREE_korr[purpose,energy19a,energy19,s,t]
    diffqREE_korr[purpose,energy19a,energy19,s,t]
    qREgj_korr[purpose,energy19,r,t]
    diffqREgj_korr[purpose,energy19,r,t]
    qEmmProdE_korr[s,t,emm,purpose,energy19]
    EmmCh_Korr[emm_eq,purpose,energy19,s,t];
    
    uREE_korr[purpose,energy19a,energy19,s,t]$(tx0[t] and (d1qREE[purpose,energy19a,energy19,s,t] or d1uREE_tech[purpose,energy19a,energy19,s,t]))
                                     = uREExID.l[purpose,energy19a,energy19,s,t] + sum(techID$(d1thetaID_k[techID,purpose,energy19a,s,t] and d1thetaID[techID,purpose,energy19a,energy19,s,t]), thetaID.l[techID,purpose,energy19a,energy19,s,t]);
    qREE_korr[purpose,energy19a,energy19,s,t]$(tx0[t] and (d1qREE[purpose,energy19a,energy19,s,t] or d1uREE_tech[purpose,energy19a,energy19,s,t] ))
                                     = uREE_korr[purpose,energy19a,energy19,s,t] * qRE.l[purpose,energy19a,s,t];
    diffqREE_korr[purpose,energy19a,energy19,s,t] = qREE_korr[purpose,energy19a,energy19,s,t] - qREE.l[purpose,energy19a,energy19,s,t];
    qREgj_korr[purpose,energy19,s,t]$(tx0[t] and (d1qRE[purpose,energy19,s,t] or d1_qgj_tech[purpose,energy19,s,t]))
                                     = sum(energy19a$(d1qREE[purpose,energy19a,energy19,s,t] or d1uREE_tech[purpose,energy19a,energy19,s,t]), qREE_korr[purpose,energy19a,energy19,s,t]);
    diffqREgj_korr[purpose,energy19,r,t] = qREgj_korr[purpose,energy19,r,t] - qREgj.l[purpose,energy19,r,t] - eInputCh_GR[purpose,energy19,r,t];                             

    qEmmProdE_korr[s,t,emm,purpose,energy19]$(tx0[t] and d1EmmProdE[s,t,emm,purpose, energy19]) 
                                     = ((qREgj_korr[purpose,energy19,s,t]/growth_factor[t]) * uEmmProdE.l[s,t,emm,energy19]*uEOPProdE.l[purpose,energy19,s,t,emm]);
    EmmCh_Korr[emm,purpose,energy19,s,t]      = qEmmProdE_korr[s,t,emm,purpose,energy19] - qEmmProdE.l[s,t,emm,purpose,energy19];
    EmmCh_Korr['CO2e',purpose,energy19,s,t]   = sum(emm, EmmCh_Korr[emm,purpose,energy19,s,t]*GWP.l[emm]);

execute_unload 'output\test2.gdx' ;
#$exit;