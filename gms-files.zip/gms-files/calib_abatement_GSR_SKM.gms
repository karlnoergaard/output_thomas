Parameter
    potential_shGR_GSR_E[purpose,energy19a,energy19,s,t]
    potential_shGR_GSR_xE[purpose,energy19,s,t]
    potential_shGR_GSR[purpose,energy19,s,t]
    eDisplacingpotential_shGR_GSR[purpose,energy19a,energy19,s,t]
    mapGrREFORM2GSR[purpose,energy19,s,GSR_ag,t]
    tek_effekt[t,GSR_ag]
    tek_effekt_subst[t,GSR_ag,energy19]
    Net_CO2tax_GSR[t,GSR_ag]
    omkEmm_ch_potential_shGR_GSR[purpose,energy19,s,t]
    omkE_ch_potential_shGR_GSR[purpose,energy19,s,t]
    omkE_ch_eDisplacingpotential_shGR_GSR[purpose,energy19a,energy19,s,t]
    k_omk_shGR_GSR[purpose,energy19a,s,t]
    tmin_GSR
    omk_share

    testtest[GSR_ag,energy19a]
    testtest2[GSR_ag,energy19a]
    testtest3[GSR_ag,energy19a]
    testtest4[s,purpose]
    testtest5[GSR_ag,energy19,s,purpose]
    tjek_GSR[t,GSR_ag]
    tjek_GSR_2[t,GSR_ag]
    tjek_GSR_0[t,GSR_ag,s,purpose]
    ;

$GROUP G_calib_abatement_GSR_variables
    qEmmProdE_GSR_ag[t,GSR_ag,energy19]
    qEmmProdE_GSR_ag_sumE[t,GSR_ag]
    qEmmProdE_GSR_ag_propE[t,GSR_ag,energy19]
    qEmmProdE_GSR_ag_propE_max[t,GSR_ag]
;

tmin_GSR = 2025;
omk_share = 0.5;

# Definer tekniske effekter i 2030
tek_effekt[tMAC,'proces_ETS'] = 0.164;
tek_effekt[tMAC,'proces_non_ETS'] = 0.281;
tek_effekt[tMAC,'LandOgSkov'] = 0.313;
tek_effekt[tMAC,'LandOgSkov_diesel'] = 0.082;
tek_effekt[tMAC,'LandOgSkov_gartneri_ETS'] = 0.197;
tek_effekt[tMAC,'LandOgSkov_gartneri_non_ETS'] = 0.310;

#  tek_effekt[tMAC,'Mineralogi_cement'] = 0.068;
tek_effekt[tMAC,'Mineralogi_cement'] = 0.068 / (953.003661283045 / 2277.33173146422);

#  tek_effekt[tMAC,'Mineralogi_oevrig'] = 0.030;
tek_effekt[tMAC,'Mineralogi_oevrig'] = 0.030 / (561.161861386778 / 1033.43108064093);


tek_effekt[tMAC,'Nordsoeen'] = 0.139;
tek_effekt[tMAC,'Raffinaderier'] = 0.163;
tek_effekt[tMAC,'Fiskeri'] = 0.199;
tek_effekt[tMAC,'Indenrigssoefart'] = 0.190;
tek_effekt[tMAC,'Banetransport'] = 0.119;
tek_effekt[tMAC,'Indenrigsluftfart'] = 0.053;



# Extrapoler fra 2025 til 2030 (line�rt fra 0) og efter 2030 (lig 2030 teknisk effekt)
tek_effekt[t,GSR_ag]$(t.val>=tmin_GSR and t.val<tMAC.val) = tek_effekt[tMAC,GSR_ag]*(t.val-tmin_GSR+5)/(tMAC.val-tmin_GSR+5);

#  tek_effekt[t,GSR_ag] = 0.94/0.67 * tek_effekt[t,GSR_ag];

# Definer substitution mod andre energivarer
tek_effekt_subst[t,'proces_ETS','Electricity']$(tek_effekt[t,'proces_ETS']>0) = 0.333;
tek_effekt_subst[t,'proces_ETS','Firewood and woodchips']$(tek_effekt[t,'proces_ETS']>0) = 0.333;
tek_effekt_subst[t,'proces_non_ETS','Electricity']$(tek_effekt[t,'proces_non_ETS']>0) = 0.333;
tek_effekt_subst[t,'proces_non_ETS','Firewood and woodchips']$(tek_effekt[t,'proces_non_ETS']>0) = 0.333;
tek_effekt_subst[t,'LandOgSkov','Electricity']$(tek_effekt[t,'LandOgSkov']>0) = 0.333;
tek_effekt_subst[t,'LandOgSkov','Straw for energy purposes']$(tek_effekt[t,'LandOgSkov']>0) = 0.333;
tek_effekt_subst[t,'LandOgSkov_gartneri_ETS','Electricity']$(tek_effekt[t,'LandOgSkov_gartneri_ETS']>0) = 0.333;
tek_effekt_subst[t,'LandOgSkov_gartneri_ETS','Firewood and woodchips']$(tek_effekt[t,'LandOgSkov_gartneri_ETS']>0) = 0.333;
tek_effekt_subst[t,'LandOgSkov_gartneri_non_ETS','Electricity']$(tek_effekt[t,'LandOgSkov_gartneri_non_ETS']>0) = 0.333;
tek_effekt_subst[t,'LandOgSkov_gartneri_non_ETS','Firewood and woodchips']$(tek_effekt[t,'LandOgSkov_gartneri_non_ETS']>0) = 0.333;
tek_effekt_subst[t,'Mineralogi_cement','Firewood and woodchips']$(tek_effekt[t,'Mineralogi_cement']>0) = 0.302;
tek_effekt_subst[t,'Mineralogi_cement','Natural gas incl. biongas']$(tek_effekt[t,'Mineralogi_cement']>0) = 0.115;
tek_effekt_subst[t,'Mineralogi_oevrig','Firewood and woodchips']$(tek_effekt[t,'Mineralogi_oevrig']>0) = 0.571;
tek_effekt_subst[t,'Nordsoeen','Electricity']$(tek_effekt[t,'Nordsoeen']>0) = 0.571;
tek_effekt_subst[t,'Raffinaderier','Biogas']$(tek_effekt[t,'Raffinaderier']>0) = 0.400;
tek_effekt_subst[t,'Indenrigssoefart','Electricity']$(tek_effekt[t,'Indenrigssoefart']>0) = 0.479;
tek_effekt_subst[t,'Indenrigssoefart','Natural gas incl. biongas']$(tek_effekt[t,'Indenrigssoefart']>0) = 0.042;
tek_effekt_subst[t,'Banetransport','Electricity']$(tek_effekt[t,'Banetransport']>0) = 0.333;


# Definer afgifter i 2030
Net_CO2tax_GSR[tMAC,'proces_ETS'] = (375 - 144) *inf_factor['2022'];
Net_CO2tax_GSR[tMAC,'proces_non_ETS'] = (750 - 323) *inf_factor['2022'];
Net_CO2tax_GSR[tMAC,'LandOgSkov'] = (750 - 264) *inf_factor['2022'];
Net_CO2tax_GSR[tMAC,'LandOgSkov_diesel'] = (750 - 264) *inf_factor['2022'];
Net_CO2tax_GSR[tMAC,'LandOgSkov_gartneri_ETS'] = (375 - 91) *inf_factor['2022'];
Net_CO2tax_GSR[tMAC,'LandOgSkov_gartneri_non_ETS'] = (750 - 271) *inf_factor['2022'];
Net_CO2tax_GSR[tMAC,'Mineralogi_cement'] = (125 - 27) *inf_factor['2022'];
Net_CO2tax_GSR[tMAC,'Mineralogi_oevrig'] = (125 - 43) *inf_factor['2022'];
Net_CO2tax_GSR[tMAC,'Nordsoeen'] = 375 *inf_factor['2022'];
Net_CO2tax_GSR[tMAC,'Raffinaderier'] = 375 *inf_factor['2022'];
Net_CO2tax_GSR[tMAC,'Fiskeri'] = 750 *inf_factor['2022'];
Net_CO2tax_GSR[tMAC,'Indenrigssoefart'] = 750 *inf_factor['2022'];
Net_CO2tax_GSR[tMAC,'Banetransport'] = (750 - 179) *inf_factor['2022'];
Net_CO2tax_GSR[tMAC,'Indenrigsluftfart'] = 375 *inf_factor['2022'];

# Extrapoler fra 2025 til 2030 (line�rt fra 0) og efter 2030 (lig 2030 teknisk effekt)
Net_CO2tax_GSR[t,GSR_ag]$(t.val>=tmin_GSR and t.val<tMAC.val) = Net_CO2tax_GSR[tMAC,GSR_ag]*(t.val-tmin_GSR+5)/(tMAC.val-tmin_GSR+5);
#  Net_CO2tax_GSR[t,GSR_ag]$(t.val>tMAC.val and t.val<=2040) = Net_CO2tax_GSR[tMAC,GSR_ag];

# Mapping til afgiftsgrundlag
mapGrREFORM2GSR[purpose,energy19,s,GSR_ag,t] = yes$sum((categoryENS), sENS2GR(categoryENS,GSR_ag,purpose,energy19,s));

# Udledninger for hver energivare i hvert afgiftsgrundlag. Inkl. udledning fra CO2bio for naturgas
qEmmProdE_GSR_ag.l[t,GSR_ag,energy19]$(not sameas[energy19,'Natural gas incl. biongas']) = sum((purpose,s) $ mapGrREFORM2GSR[purpose,energy19,s,GSR_ag,t], qEmmProdE.l[s,t,'co2ubio',purpose,energy19]);


qEmmProdE_GSR_ag.l[t,GSR_ag,'Natural gas incl. biongas'] = sum((purpose,s) $(mapGrREFORM2GSR[purpose,'Natural gas incl. biongas',s,GSR_ag,t]), qEmmProdE.l[s,t,'co2ubio',purpose,'Natural gas incl. biongas'])
                                 #Vi betinger p� at der ogs� skal v�re ubio emissioner fra naturgas. Der er nogle f� tilf�lde, hvor det lader til at virksomhederne bruger ren bionaturgas. Det er enten en datafejl, eller fordi de ikke modtager fra ledningsnettet og derfor kan f� det rent. Det antages at det er sidstn�vnte - og i de tilf�lde skal naturgassen ikke beskattes, da det er ren bionaturgas.
                                   +sum((purpose,s) $(mapGrREFORM2GSR[purpose,'Natural gas incl. biongas',s,GSR_ag,t]), qEmmProdE.l[s,t,'co2bio',purpose,'Natural gas incl. biongas'])
                                   ;

# Udledninger for hvert afgiftsgrundlag
qEmmProdE_GSR_ag_sumE.l[t,GSR_ag] = sum(energy19,qEmmProdE_GSR_ag.l[t,GSR_ag,energy19]);

# Energivares andel i afgiftgrundlags samlede udlednunger
qEmmProdE_GSR_ag_propE.l[t,GSR_ag,energy19]$(qEmmProdE_GSR_ag_sumE.l[t,GSR_ag]) = qEmmProdE_GSR_ag.l[t,GSR_ag,energy19] / qEmmProdE_GSR_ag_sumE.l[t,GSR_ag];


qEmmProdE_GSR_ag_propE_max.l[t,GSR_ag] = smax(energy19,qEmmProdE_GSR_ag_propE.l[t,GSR_ag,energy19]);

set qEmmProdE_GSR_ag_propE_max_energy19(t,GSR_ag,energy19);
qEmmProdE_GSR_ag_propE_max_energy19(t,GSR_ag,energy19)$(qEmmProdE_GSR_ag_propE_max.l[t,GSR_ag]) = yes$(qEmmProdE_GSR_ag_propE.l[t,GSR_ag,energy19]=qEmmProdE_GSR_ag_propE_max.l[t,GSR_ag]);


loop(t$(t.val>=tmin_GSR and t.val<=tMAC.val),loop(GSR_ag$(tek_effekt[t,GSR_ag]),
    potential_shGR_GSR_E[purpose,energy19a,energy19,s,t]$((not sameas(energy19a,'Natural gas incl. biongas')) 
        and mapGrREFORM2GSR[purpose,energy19a,s,GSR_ag,t] 
        and qEmmProdE_GSR_ag_propE_max_energy19(t,GSR_ag,energy19a) 
        and qEmmProdE.l[s,t,'co2ubio',purpose,energy19a]) 
        = -tek_effekt[t,GSR_ag]$(qEmmProdE_GSR_ag_propE_max_energy19(t,GSR_ag,energy19a))
            /qEmmProdE_GSR_ag_propE.l[t,GSR_ag,energy19a]$(qEmmProdE_GSR_ag_propE_max_energy19(t,GSR_ag,energy19a))
            *tek_effekt_subst[t,GSR_ag,energy19]$(mapGrREFORM2GSR[purpose,energy19,s,GSR_ag,t])
            *qEmmProdE.l[s,t,'co2ubio',purpose,energy19a]$(qEmmProdE_GSR_ag_propE_max_energy19(t,GSR_ag,energy19a))
            /(uEmmProdE.l[s,t,'co2ubio',energy19a]$(qEmmProdE_GSR_ag_propE_max_energy19(t,GSR_ag,energy19a))-uEmmProdE.l[s,t,'co2ubio',energy19]$(tek_effekt_subst[t,GSR_ag,energy19]$(mapGrREFORM2GSR[purpose,energy19,s,GSR_ag,t])>0))
            /(qREgj.l[purpose,energy19a,s,t]$(qEmmProdE_GSR_ag_propE_max_energy19(t,GSR_ag,energy19a)) / growth_factor[t])
            ;


    potential_shGR_GSR_E[purpose,energy19a,energy19,s,t]$(sameas(energy19a,'Natural gas incl. biongas') 
        and mapGrREFORM2GSR[purpose,energy19a,s,GSR_ag,t] 
        and qEmmProdE_GSR_ag_propE_max_energy19(t,GSR_ag,energy19a) 
        and (qEmmProdE.l[s,t,'co2ubio',purpose,energy19a] or qEmmProdE.l[s,t,'co2bio',purpose,energy19a]))      
        = -tek_effekt[t,GSR_ag]$(qEmmProdE_GSR_ag_propE_max_energy19(t,GSR_ag,energy19a))
            /qEmmProdE_GSR_ag_propE.l[t,GSR_ag,energy19a]$(qEmmProdE_GSR_ag_propE_max_energy19(t,GSR_ag,energy19a))
            *tek_effekt_subst[t,GSR_ag,energy19]$(mapGrREFORM2GSR[purpose,energy19,s,GSR_ag,t])
            *(qEmmProdE.l[s,t,'co2ubio',purpose,energy19a]$(qEmmProdE_GSR_ag_propE_max_energy19(t,GSR_ag,energy19a))+qEmmProdE.l[s,t,'co2bio',purpose,energy19a]$(qEmmProdE_GSR_ag_propE_max_energy19(t,GSR_ag,energy19a)))
            /(uEmmProdE.l[s,t,'co2ubio',energy19a]$(qEmmProdE_GSR_ag_propE_max_energy19(t,GSR_ag,energy19a))-uEmmProdE.l[s,t,'co2ubio',energy19]$(tek_effekt_subst[t,GSR_ag,energy19]$(mapGrREFORM2GSR[purpose,energy19,s,GSR_ag,t])>0))
            /(qREgj.l[purpose,energy19a,s,t]$(qEmmProdE_GSR_ag_propE_max_energy19(t,GSR_ag,energy19a)) / growth_factor[t])
            ;


    potential_shGR_GSR_xE[purpose,energy19a,s,t]$(mapGrREFORM2GSR[purpose,energy19a,s,GSR_ag,t] 
        and qEmmProdE_GSR_ag_propE_max_energy19(t,GSR_ag,energy19a)
        and (qEmmProdE.l[s,t,'co2ubio',purpose,energy19a] or qEmmProdE.l[s,t,'co2bio',purpose,energy19a]))
            = -tek_effekt[t,GSR_ag]
            /qEmmProdE_GSR_ag_propE.l[t,GSR_ag,energy19a]$(qEmmProdE_GSR_ag_propE_max_energy19(t,GSR_ag,energy19a))
            *(1-sum(energy19,tek_effekt_subst[t,GSR_ag,energy19]$(mapGrREFORM2GSR[purpose,energy19,s,GSR_ag,t])))
            ;

    
    eDisplacingpotential_shGR_GSR[purpose,energy19a,energy19,s,t] = -potential_shGR_GSR_E[purpose,energy19a,energy19,s,t];

););

potential_shGR_GSR[purpose,energy19a,s,t] = sum(energy19,potential_shGR_GSR_E[purpose,energy19a,energy19,s,t]) + potential_shGR_GSR_xE[purpose,energy19a,s,t];


loop(t$(t.val>=tmin_GSR and t.val<=tMAC.val),loop(GSR_ag$(tek_effekt[t,GSR_ag]),
    omkEmm_ch_potential_shGR_GSR[purpose,energy19a,s,t]$(mapGrREFORM2GSR[purpose,energy19a,s,GSR_ag,t]) = 
    (potential_shGR_GSR[purpose,energy19a,s,t]
        *(qREgj.l[purpose,energy19a,s,t]/growth_factor[t])
        *uEmmProdE.l[s,t,'co2ubio',energy19a]
        *Net_CO2tax_GSR[t,GSR_ag]$(mapGrREFORM2GSR[purpose,energy19a,s,GSR_ag,t]) 

        + sum(energy19,(eDisplacingpotential_shGR_GSR[purpose,energy19a,energy19,s,t]
            *(qREgj.l[purpose,energy19a,s,t]/growth_factor[t])
            *uEmmProdE.l[s,t,'co2ubio',energy19]
            *Net_CO2tax_GSR[t,GSR_ag]$(mapGrREFORM2GSR[purpose,energy19a,s,GSR_ag,t]))))
    /1000000; #Divider med 1 million?
););

omkE_ch_potential_shGR_GSR[purpose,energy19a,s,t] = potential_shGR_GSR[purpose,energy19a,s,t]*(qREgj.l[purpose,energy19a,s,t])*pRE.l[purpose,energy19a,s,t]; # divide by growth_factor[t]? 
omkE_ch_eDisplacingpotential_shGR_GSR[purpose,energy19a,energy19,s,t] = eDisplacingpotential_shGR_GSR[purpose,energy19a,energy19,s,t]*(qREgj.l[purpose,energy19a,s,t])*pRE.l[purpose,energy19,s,t]; # divide by growth_factor[t]?

k_omk_shGR_GSR[purpose,energy19a,s,t] = -(omkEmm_ch_potential_shGR_GSR[purpose,energy19a,s,t]*(1-omk_share)+omkE_ch_potential_shGR_GSR[purpose,energy19a,s,t] + sum(energy19,omkE_ch_eDisplacingpotential_shGR_GSR[purpose,energy19a,energy19,s,t]));

# ------------------------------------------------------------------------------------------------------------------
# Unload exogenous values and dummies
# ------------------------------------------------------------------------------------------------------------------

parameters
    thetaID_in[techID,purpose,energy19a,energy19,s,t]
    thetaID_k_in[techID,purpose,energy19a,s,t]
    counter_GSR
;

counter_GSR = 0;

#Loop over potentialer, hvor hver energiakivitet og energiinput f�r tildelt en 'aggregeret' teknologi
loop(s,loop(purpose,loop(energy19a,
#if(sum(t,techexists(s,purpose,energy19a,omk,t)),
    if((sum(tx0,potential_shGR_GSR[purpose,energy19a,s,tx0]) 
        or sum((energy19,tx0),eDisplacingpotential_shGR_GSR[purpose,energy19a,energy19,s,tx0]) 
        or (sum((tx0),k_omk_shGR_GSR[purpose,energy19a,s,tx0])
        and sum((tx0),qREgj.l[purpose,energy19a,s,tx0]))),
        counter_GSR = counter_GSR + 1);
    thetaID_in[techID,purpose,energy19a,energy19,s,tx0]$(ord(techID)=counter_GSR and sameas(energy19a,energy19)) = potential_shGR_GSR[purpose,energy19a,s,tx0];
    thetaID_in[techID,purpose,energy19a,energy19,s,tx0]$(ord(techID)=counter_GSR and not sameas(energy19a,energy19)) = eDisplacingpotential_shGR_GSR[purpose,energy19a,energy19,s,tx0];
    thetaID_k_in[techID,purpose,energy19a,s,tx0]$(ord(techID)=counter_GSR and qREgj.l[purpose,energy19a,s,tx0]) = k_omk_shGR_GSR[purpose,energy19a,s,tx0]/qREgj.l[purpose,energy19a,s,tx0];
);););#);

thetaID_in[techID,purpose,energy19a,energy19,s,tx0]$(tx0.val>tMAC.val) = thetaID_in[techID,purpose,energy19a,energy19,s,tMAC];
thetaID_k_in[techID,purpose,energy19a,s,tx0]$(tx0.val>tMAC.val) = thetaID_k_in[techID,purpose,energy19a,s,tMAC];


tjek_GSR_0[tMAC,GSR_ag,s,purpose]$(qEmmProdE_GSR_ag_sumE.l[tMAC,GSR_ag]) = sum((techID,energy19a,energy19)$(mapGrREFORM2GSR[purpose,energy19a,s,GSR_ag,tMAC]), thetaID_in[techID,purpose,energy19a,energy19,s,tMAC] * (qREgj.l[purpose,energy19a,s,tMAC]/growth_factor[tMAC])* uEmmProdE.l[s,tMAC,'co2ubio',energy19]);

tjek_GSR[tMAC,GSR_ag]$(qEmmProdE_GSR_ag_sumE.l[tMAC,GSR_ag]) = sum((purpose,s,techID,energy19a,energy19)$(mapGrREFORM2GSR[purpose,energy19a,s,GSR_ag,tMAC]), thetaID_in[techID,purpose,energy19a,energy19,s,tMAC] * (qREgj.l[purpose,energy19a,s,tMAC]/growth_factor[tMAC])* uEmmProdE.l[s,tMAC,'co2ubio',energy19])/qEmmProdE_GSR_ag_sumE.l[tMAC,GSR_ag];

tjek_GSR_2[tMAC,GSR_ag]$(tek_effekt[tMAC,GSR_ag]) = (tjek_GSR[tMAC,GSR_ag]+tek_effekt[tMAC,GSR_ag])/tek_effekt[tMAC,GSR_ag];

# ------------------------------------------------------------------------------------------------------------------
# Unload exogenous values and dummies
# ------------------------------------------------------------------------------------------------------------------
# Indl�sning af thetaID og thetaID_k
thetaID.l[techID,purpose,energy19a,energy19,s,tx0] = thetaID_in[techID,purpose,energy19a,energy19,s,tx0];
thetaid_k.l[techID,purpose,energy19a,s,tx0] = thetaid_k_in[techID,purpose,energy19a,s,tx0];

#  thetaID.l[techID,purpose,energy19a,energy19,s,t] = 0;
#  thetaID_k.l[techID,purpose,energy19a,s,t] = 0;

# ------------------------------------------------------------------------------------------------------------------
# Set dummies
# ------------------------------------------------------------------------------------------------------------------

d1thetaID_k[techID,purpose,energy19a,s,t] = yes$(thetaid_k.l[techID,purpose,energy19a,s,t]);
d1thetaID[techID,purpose,energy19a,energy19,s,t]$(thetaID.l[techID,purpose,energy19a,energy19,s,t]) = yes;

d1uREE_tech[purpose,energy19a,energy19,s,t] = sum(techID,d1thetaID[techID,purpose,energy19a,energy19,s,t]);

d1_qgj_tech[purpose,energy19,s,t] = sum((techID,energy19a), d1thetaID[techID,purpose,energy19a,energy19,s,t]);
d1_tech_s[techID,s,t] = sum((purpose,energy19a,energy19), d1thetaID[techID,purpose,energy19a,energy19,s,t]);



# ------------------------------------------------------------------------------------------------------------------
# Tjek at thetaID giver de rette energi�ndringer
# ------------------------------------------------------------------------------------------------------------------

parameters
    uREE_theta[purpose,energy19a,energy19,s,t]
    qREE_theta[purpose,energy19a,energy19,s,t]
    qREgj_theta[purpose,energy19,s,t]
    qREgj_thetaCh[purpose,energy19,s,t]
    #  sumqREgj_thetaCh[purpose,ENS_energy19,ENS_sectors,t]
    #  diffqREgj_thetaCh[purpose,ENS_energy19,ENS_sectors,t]
    ;

    uREE_theta[purpose,energy19a,energy19,s,t]$(tx0[t] and (d1qREE[purpose,energy19a,energy19,s,t] or d1uREE_tech[purpose,energy19a,energy19,s,t]))
                                     = uREExID.l[purpose,energy19a,energy19,s,t] + sum(techID$(d1thetaID_k[techID,purpose,energy19a,s,t] and d1thetaID[techID,purpose,energy19a,energy19,s,t]), thetaID.l[techID,purpose,energy19a,energy19,s,t]);
    qREE_theta[purpose,energy19a,energy19,s,t]$(tx0[t] and (d1qREE[purpose,energy19a,energy19,s,t] or d1uREE_tech[purpose,energy19a,energy19,s,t] ))
                                     = uREE_theta[purpose,energy19a,energy19,s,t] * qRE.l[purpose,energy19a,s,t];
    qREgj_theta[purpose,energy19,s,t]$(tx0[t] and (d1qRE[purpose,energy19,s,t] or d1_qgj_tech[purpose,energy19,s,t]))
                                     = sum(energy19a$(d1qREE[purpose,energy19a,energy19,s,t] or d1uREE_tech[purpose,energy19a,energy19,s,t]), qREE_theta[purpose,energy19a,energy19,s,t]);
    qREgj_thetaCh[purpose,energy19,s,t] = qREgj_theta[purpose,energy19,s,t] - qREgj.l[purpose,energy19,s,t];
    #  sumqREgj_thetaCh[purpose,ENS_energy19,ENS_sectors,t] = sum((ENS_s)$(map_ENS_sectors2GR(ENS_sectors,ENS_s)), qREgj_thetaCh[purpose,ENS_energy19,ENS_s,t]);
    #  diffqREgj_thetaCh[purpose,ENS_energy19,ENS_sectors,t] = sum(ENS_energy$(map_ENS_Energy2GR(ENS_energy,ENS_energy19)), eInputCh_agg[purpose,ENS_energy,ENS_sectors,t]) - sumqREgj_thetaCh[purpose,ENS_energy19,ENS_sectors,t];

Parameter
    uREE_repo[purpose,energy19a,energy19,s,t]
    qREE_repo[purpose,energy19a,energy19,s,t]
    qREgj_repo[purpose,energy19,s,t]
    qEmmProdE_repo[s,t,emm_eq,purpose,energy19]
    qEmmProdE_repo2[s,t,emm_eq,purpose,energy19]
    qEmmProdE_repo3[s,t,purpose,energy19a,energy19]
    ;

qREE_repo[purpose,energy19a,energy19,s,t]   = uREE_theta[purpose,energy19a,energy19,s,t] * qRE.l[purpose,energy19a,s,t];

qREgj_repo[purpose,energy19,s,t]            = sum(energy19a, qREE_repo[purpose,energy19a,energy19,s,t]);

qEmmProdE_repo[s,t,emm,purpose,energy19]    = (qREgj_repo[purpose,energy19,s,t]/growth_factor[t]) * uEmmProdE.l[s,t,emm,energy19];
qEmmProdE_repo[s,t,'CO2e',purpose,energy19] = sum(emm, qEmmProdE_repo[s,t,emm,purpose,energy19]);
qEmmProdE_repo2[s,t,emm,purpose,energy19]   = (qREgj_thetaCh[purpose,energy19,s,t]/growth_factor[t]) * uEmmProdE.l[s,t,emm,energy19];
qEmmProdE_repo2[s,t,'CO2e',purpose,energy19] = sum(emm, qEmmProdE_repo2[s,t,emm,purpose,energy19]);

qEmmProdE_repo3[s,t,purpose,energy19a,energy19] = uREE_theta[purpose,energy19a,energy19,s,t] * qEmmProdE.l[s,t,'CO2e',purpose,energy19];



# ------------------------------------------------------------------------------------------------------------------
# Korrektion af thetaID og thetaID_k, n�r der er for stort reduktionspotentiale ift. det initiale energiforbrug
# ------------------------------------------------------------------------------------------------------------------
 
# OBS: Der burde ikke v�re nogen, hvis mappingen er gjort rigtigt!! Hvis der skal korrigeres b�r det nok ogs� g�res for kapitalapparatet????
parameter thetaID_tjek[purpose,energy19a,s,t], thetaID_tjek2[techID,purpose,energy19a,energy19,s,t], KorrThetaID[purpose,energy19a,s,t];
thetaID_tjek[purpose,energy19a,s,t] = sum((techID, energy19)$(sameas(energy19a,energy19)), thetaID.l[techID,purpose,energy19a,energy19,s,t]);
thetaID_tjek2[techID,purpose,energy19a,energy19,s,t]$(thetaID.l[techID,purpose,energy19a,energy19,s,t]<-0.96) = thetaID.l[techID,purpose,energy19a,energy19,s,t];
KorrThetaID[purpose,energy19a,s,t]$(thetaID_tjek[purpose,energy19a,s,t]<-0.96) = thetaID_tjek[purpose,energy19a,s,t];
display KorrThetaID;
thetaID_tjek[purpose,energy19a,s,t]$(thetaID_tjek[purpose,energy19a,s,t]<-0.96) = thetaID_tjek[purpose,energy19a,s,t]/0.96;
thetaID.l[techID,purpose,energy19a,energy19,s,t]$(thetaID_tjek[purpose,energy19a,s,t]<-0.96 and d1thetaID[techID,purpose,energy19a,energy19,s,t]) = thetaID.l[techID,purpose,energy19a,energy19,s,t]/(-thetaID_tjek[purpose,energy19a,s,t]);
thetaID_k.l[techID,purpose,energy19a,s,t]$(thetaID_tjek[purpose,energy19a,s,t]<-0.96 and sum(energy19,d1thetaID[techID,purpose,energy19a,energy19,s,t])) = thetaID_k.l[techID,purpose,energy19a,s,t]/(-thetaID_tjek[purpose,energy19a,s,t]);

# ------------------------------------------------------------------------------------------------------------------
# Umiddelbare emissions�ndringer efter korrektion af theta_ID
# ------------------------------------------------------------------------------------------------------------------

Parameter 
    uREE_korr[purpose,energy19a,energy19,s,t]
    qREE_korr[purpose,energy19a,energy19,s,t]
    diffqREE_korr[purpose,energy19a,energy19,s,t]
    qREgj_korr[purpose,energy19,r,t]
    diffqREgj_korr[purpose,energy19,r,t]
    qEmmProdE_korr[s,t,emm,purpose,energy19]
    EmmCh_Korr[emm_eq,purpose,energy19,s,t];
    
    uREE_korr[purpose,energy19a,energy19,s,t]$(tx0[t] and (d1qREE[purpose,energy19a,energy19,s,t] or d1uREE_tech[purpose,energy19a,energy19,s,t]))
                                     = uREExID.l[purpose,energy19a,energy19,s,t] + sum(techID$(d1thetaID_k[techID,purpose,energy19a,s,t] and d1thetaID[techID,purpose,energy19a,energy19,s,t]), thetaID.l[techID,purpose,energy19a,energy19,s,t]);
    qREE_korr[purpose,energy19a,energy19,s,t]$(tx0[t] and (d1qREE[purpose,energy19a,energy19,s,t] or d1uREE_tech[purpose,energy19a,energy19,s,t] ))
                                     = uREE_korr[purpose,energy19a,energy19,s,t] * qRE.l[purpose,energy19a,s,t];
    diffqREE_korr[purpose,energy19a,energy19,s,t] = qREE_korr[purpose,energy19a,energy19,s,t] - qREE.l[purpose,energy19a,energy19,s,t];
    qREgj_korr[purpose,energy19,s,t]$(tx0[t] and (d1qRE[purpose,energy19,s,t] or d1_qgj_tech[purpose,energy19,s,t]))
                                     = sum(energy19a$(d1qREE[purpose,energy19a,energy19,s,t] or d1uREE_tech[purpose,energy19a,energy19,s,t]), qREE_korr[purpose,energy19a,energy19,s,t]);
    #  diffqREgj_korr[purpose,energy19,r,t] = qREgj_korr[purpose,energy19,r,t] - qREgj.l[purpose,energy19,r,t] - eInputCh_GR[purpose,energy19,r,t];                             

    qEmmProdE_korr[s,t,emm,purpose,energy19]$(tx0[t] and d1EmmProdE[s,t,emm,purpose, energy19]) 
                                     = ((qREgj_korr[purpose,energy19,s,t]/growth_factor[t]) * uEmmProdE.l[s,t,emm,energy19]*uEOPProdE.l[purpose,energy19,s,t,emm]);
    EmmCh_Korr[emm,purpose,energy19,s,t]      = qEmmProdE_korr[s,t,emm,purpose,energy19] - qEmmProdE.l[s,t,emm,purpose,energy19];
    EmmCh_Korr['CO2e',purpose,energy19,s,t]   = sum(emm, EmmCh_Korr[emm,purpose,energy19,s,t]*GWP.l[emm]);

#$exit;
