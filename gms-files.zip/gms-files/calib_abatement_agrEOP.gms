# ############################################
# ##### Abatement technology for Animals ######
# ############################################

  # These switches control whether abatement forward looking and/or sluggish. Should be set to 0 (not forward-looking or sluggish) or 1
switch_forward_looking_ani = 0; # Perhaps this should be controlled individually for ID and EOPtech...
switch_sluggish_ani = 0; 		# Perhaps this should be controlled individually for ID and EOPtech...
uEOPanibeta = 0.5;            	# This parameter controls the degree of forward-lookingness for EOPtech technologies
rhoEOPani[TechAni] = 0.8;       # This parameter controls the degree of sluggishness for EOPtech technologies
sigmaEOPAni[TechAni] = 0.1;  	# Default value for variance on technology costs

# BOVAER (Konventionelle malkekøer)
thetaAni.l['tech1','01031','EntericFermentation','CowsDairy',t,'CH4']$(tx1[t] and d1EmmAgrAni['EntericFermentation','01031','CowsDairy',t,'CH4'])
		 = 0.25;	# Reduction potential (25 pct)
pEOPAni.l['tech1',Emmtype,ani_sectors,animals,t] = 425*inf_factor['2023'];		# Price per tonne CO2e (425 kr, 2023-prices)
sigmaEOPAni['tech1'] = 1; 														# Variance on technology costs 
shareAniPrice_type.l['tech1','capital',t] = 1;									# Cost type (Capital)
 shareAniPrice_group.l['tech1','10120',t] = 0;								# IO price group (Not relevant)

# TELTOVERDÆKNING (Konventionelle og økologiske svin)
thetaAni.l['tech2',ani_sectors,'Manuremanagement',animals,t,emm]$(tx1[t] and d1EmmAgrAni['ManureManagement',ani_sectors,animals,t,emm] and
                                                                  (sameas(ani_sectors,'01051') or sameas(ani_sectors,'01052')) and (sameas(animals,'pigssows') or sameas(animals,'piglets') or sameas(animals,'pigsfattening')) and (sameas(emm,'N2O') or sameas(emm,'CH4'))) 
	= 0.1; 																		# Reduction potential (10 pct)
pEOPAni.l['tech2',Emmtype,ani_sectors,animals,t] = 300*inf_factor['2023'];		# Price per tonne CO2e (525 kr, 2023-prices)
sigmaEOPAni['tech2'] = 112.5; 													# Variance on technology costs (interval at 75-975)
shareAniPrice_type.l['tech2','capital',t] = 1;									# Cost type (Capital)
#  shareAniPrice_group.l['tech2',s,t] = 0;										# IO price group (Not relevant)
	
	#Ammoniak-effekt af teltoverdækning med flydelag
	# thetaAni.l['tech2',ani_sectors,'Manuremanagement',animals,t,emm]$(d1EmmAgrAni['ManureManagement',ani_sectors,animals,t,emm] and
  #                                                                 (sameas(ani_sectors,'01051') or sameas(ani_sectors,'01052')) and sameas(animals,'pigsfattening') and (sameas(emm,'NH3'))) 
	# 	= 0.022; # 2,2 reduktionspotentiale i 2030, jf. korrespondance med DCE

# TELTOVERDÆKNING (Konventionelle og økologiske kvæg)
thetaAni.l['tech3',ani_sectors,'Manuremanagement',animals,t,emm]$(tx1[t] and d1EmmAgrAni['ManureManagement',ani_sectors,animals,t,emm] and 
                                                                (sameas(ani_sectors,'01031') or sameas(ani_sectors,'01032')) and (sameas(animals,'CowsDairy') or sameas(animals,'cowsother')) and (sameas(emm,'N2O') or sameas(emm,'CH4'))) 
	= 0.03; 																	# Reduction potential (4 pct)
pEOPAni.l['tech3',Emmtype,ani_sectors,animals,t] = 425*inf_factor['2023'];	# Price per tonne CO2e (462.5 kr, 2023-prices)
sigmaEOPAni['tech3'] = 187.5; 													# Variance on technology costs (interval at 50-875)
shareAniPrice_type.l['tech3','capital',t] = 1;									# Cost type (Capital)
#  shareAniPrice_group.l['tech3',s,t] = 0;										# IO price group (Not relevant)

	#Ammoniak-effekt af teltoverdækning med flydelag
	# thetaAni.l['tech3',ani_sectors,'Manuremanagement',animals,t,emm]$(d1EmmAgrAni['ManureManagement',ani_sectors,animals,t,emm] and
  #                                                                 (sameas(ani_sectors,'01031') or sameas(ani_sectors,'01032')) and (sameas(animals,'CowsDairy') or sameas(animals,'cowsother')) and (sameas(emm,'NH3'))) 
	#     = 0.0218; # 2,18 procent reduktionspotentiale i 2030, jf. korrespondance m. DC

### BACKSTOP ANIMALSK

# Effektiviseringsteknologi for ManureManagement i konventionel kvæg
thetaAni.l['tech4','01031','Manuremanagement',animals,t,emm]$(tx1[t] and d1EmmAgrAni['ManureManagement','01031',animals,t,emm] and 
                                                              (sameas(animals,'CowsDairy') or sameas(animals,'cowsother')) and (sameas(emm,'N2O') or sameas(emm,'CH4'))) = 0.1 * (1-afgiftsfritagede[t,animals,'01031']);	
pEOPAni.l['tech4',Emmtype,'01031',animals,t] = 500;								
sigmaEOPAni['tech4'] = 200; 													
shareAniPrice_type.l['tech4','capital',t] = 1;

thetaAni.l['tech5','01031','Manuremanagement',animals,t,emm]$(tx1[t] and d1EmmAgrAni['ManureManagement','01031',animals,t,emm] and 
                                                              (sameas(animals,'CowsDairy') or sameas(animals,'cowsother')) and (sameas(emm,'N2O') or sameas(emm,'CH4'))) = 0.12 *  (1-afgiftsfritagede[t,animals,'01031']);
pEOPAni.l['tech5',Emmtype,'01031',animals,t] = 1000;							
sigmaEOPAni['tech5'] = 300; 													
shareAniPrice_type.l['tech5','capital',t] = 1;

# Effektiviseringsteknologi for ManureManagement i økologisk kvæg
thetaAni.l['tech6','01032','Manuremanagement',animals,t,emm]$(tx1[t] and d1EmmAgrAni['ManureManagement','01032',animals,t,emm] and 
                                                              (sameas(animals,'CowsDairy') or sameas(animals,'cowsother')) and (sameas(emm,'N2O') or sameas(emm,'CH4'))) = 0.1 * (1-afgiftsfritagede[t,animals,'01032']);
pEOPAni.l['tech6',Emmtype,'01032',animals,t] = 500;								
sigmaEOPAni['tech6'] = 200; 													
shareAniPrice_type.l['tech6','capital',t] = 1;

thetaAni.l['tech7','01032','Manuremanagement',animals,t,emm]$(tx1[t] and d1EmmAgrAni['ManureManagement','01032',animals,t,emm] and 
                                                            (sameas(animals,'CowsDairy') or sameas(animals,'cowsother')) and (sameas(emm,'N2O') or sameas(emm,'CH4'))) = 0.12 * (1-afgiftsfritagede[t,animals,'01032']);
pEOPAni.l['tech7',Emmtype,'01032',animals,t] = 1000;							
sigmaEOPAni['tech7'] = 300; 													
shareAniPrice_type.l['tech7','capital',t] = 1;

# Effektiviseringsteknologi for ManureManagement i konventionel og økologisk svinebrug
thetaAni.l['tech8',ani_sectors,'Manuremanagement',animals,t,emm]$(tx1[t] and d1EmmAgrAni['ManureManagement',ani_sectors,animals,t,emm] and 
                                                              (sameas(ani_sectors,'01051') or sameas(ani_sectors,'01052')) and (sameas(animals,'pigssows') or sameas(animals,'piglets') or sameas(animals,'pigsfattening')) and (sameas(emm,'N2O') or sameas(emm,'CH4'))) = 0.075 * (1-afgiftsfritagede[t,animals,ani_sectors]);
pEOPAni.l['tech8',Emmtype,ani_sectors,animals,t] = 500;							
sigmaEOPAni['tech8'] = 200; 													
shareAniPrice_type.l['tech8','capital',t] = 1;

thetaAni.l['tech9',ani_sectors,'Manuremanagement',animals,t,emm]$(tx1[t] and d1EmmAgrAni['ManureManagement',ani_sectors,animals,t,emm] and 
                                                                (sameas(ani_sectors,'01051') or sameas(ani_sectors,'01052')) and (sameas(animals,'pigssows') or sameas(animals,'piglets') or sameas(animals,'pigsfattening')) and (sameas(emm,'N2O') or sameas(emm,'CH4'))) = 0.09 * (1-afgiftsfritagede[t,animals,ani_sectors]);	
pEOPAni.l['tech9',Emmtype,ani_sectors,animals,t] = 1000;						
sigmaEOPAni['tech9'] = 300; 													
shareAniPrice_type.l['tech9','capital',t] = 1;

# Effektiviseringsteknologi for EntericFermentation i konventionel kvæg
thetaAni.l['tech10','01031','EntericFermentation',animals,t,'CH4']$(tx1[t] and d1EmmAgrAni['EntericFermentation','01031',animals,t,'CH4'] and 
                                                                  (sameas(animals,'CowsDairy') or sameas(animals,'cowsother'))) = 0.1 * (1-afgiftsfritagede[t,animals,'01031']);
pEOPAni.l['tech10',Emmtype,'01031',animals,t] = 500;							
sigmaEOPAni['tech10'] = 200; 													
shareAniPrice_type.l['tech10','capital',t] = 1;

thetaAni.l['tech11','01031','EntericFermentation',animals,t,'CH4']$(tx1[t] and d1EmmAgrAni['EntericFermentation','01031',animals,t,'CH4'] and 
                                                                  (sameas(animals,'CowsDairy') or sameas(animals,'cowsother'))) = 0.12 * (1-afgiftsfritagede[t,animals,'01031']);
pEOPAni.l['tech11',Emmtype,'01031',animals,t] = 1000;							
sigmaEOPAni['tech11'] = 300; 													
shareAniPrice_type.l['tech11','capital',t] = 1;

# Effektiviseringsteknologi for EntericFermentation i økologisk kvæg
thetaAni.l['tech12','01032','EntericFermentation',animals,t,'CH4']$(tx1[t] and d1EmmAgrAni['EntericFermentation','01032',animals,t,'CH4'] and 
                                                                  (sameas(animals,'CowsDairy') or sameas(animals,'cowsother'))) = 0.1 * (1-afgiftsfritagede[t,animals,'01032']);
pEOPAni.l['tech12',Emmtype,'01032',animals,t] = 500;							
sigmaEOPAni['tech12'] = 200; 													
shareAniPrice_type.l['tech12','capital',t] = 1;

thetaAni.l['tech13','01032','EntericFermentation',animals,t,'CH4']$(tx1[t] and d1EmmAgrAni['EntericFermentation','01032',animals,t,'CH4'] and 
                                                                  (sameas(animals,'CowsDairy') or sameas(animals,'cowsother'))) = 0.12 * (1-afgiftsfritagede[t,animals,'01032']);
pEOPAni.l['tech13',Emmtype,'01032',animals,t] = 1000;							
sigmaEOPAni['tech13'] = 300; 													
shareAniPrice_type.l['tech13','capital',t] = 1;

# Effektiviseringsteknologi for EntericFermentation i konventionel og økologisk svin 
thetaAni.l['tech14',ani_sectors,'EntericFermentation',animals,t,'CH4']$(tx1[t] and d1EmmAgrAni['EntericFermentation',ani_sectors,animals,t,'CH4'] and 
                                                                  (sameas(ani_sectors,'01051') or sameas(ani_sectors,'01052')) and (sameas(animals,'pigssows') or sameas(animals,'piglets') or sameas(animals,'pigsfattening'))) = 0.075 * (1-afgiftsfritagede[t,animals,ani_sectors]);
pEOPAni.l['tech14',Emmtype,ani_sectors,animals,t] = 500;							
sigmaEOPAni['tech14'] = 200; 													
shareAniPrice_type.l['tech14','capital',t] = 1;

thetaAni.l['tech15',ani_sectors,'EntericFermentation',animals,t,'CH4']$(tx1[t] and d1EmmAgrAni['EntericFermentation',ani_sectors,animals,t,'CH4'] and 
                                                                  (sameas(ani_sectors,'01051') or sameas(ani_sectors,'01052')) and (sameas(animals,'pigssows') or sameas(animals,'piglets') or sameas(animals,'pigsfattening'))) = 0.09 * (1-afgiftsfritagede[t,animals,ani_sectors]);
pEOPAni.l['tech15',Emmtype,ani_sectors,animals,t] = 1000;							
sigmaEOPAni['tech15'] = 300; 													
shareAniPrice_type.l['tech15','capital',t] = 1;

# TechAni_eff[TechAni] = yes$(sameas[TechAni,'tech4'] or sameas[TechAni,'Tech5'] or sameas[TechAni,'Tech6'] or sameas[TechAni,'Tech7'] or sameas[TechAni,'Tech8']
#                           or sameas[TechAni,'Tech9'] or sameas[TechAni,'Tech10'] or sameas[TechAni,'Tech11'] or sameas[Techani,'Tech12'] or sameas[TechAni,'Tech13'],
#                           or sameas[TechAni,'Tech14'] or sameas[TechAni,'Tech15']);

# #SETTING UP CALIBRATION

# Parametre og dummies
uEOPani.l[Emmtype,ani_sectors,animals,t,emm]$d1EmmAgrAni[emmtype,ani_sectors,animals,t,emm] = 1; #End-of-pipe initilized at zero end of pipe (uEOP=1)
uEOPAnit.l[TechAni,ani_sectors,Emmtype,animals,t]$sum((emm),uEOPani.l[Emmtype,ani_sectors,animals,t,emm]) = 0;
j_rEOPAni.l[TechAni,ani_sectors,Emmtype,animals,t]$sum((emm),uEOPani.l[Emmtype,ani_sectors,animals,t,emm])= 0;

#Subsidie

# Updating dummies
d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm] = yes$(thetaAni.l[TechAni,ani_sectors,Emmtype,animals,t,emm]);
d1vEOPCostAni[Emmtype,ani_sectors,s,animals,t] = yes$(sum((TechAni,emm), d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]) and sum(techAni, shareAniPrice_type.l[TechAni,'IO',t] and shareAniPrice_group.l[techAni,s,t]));
aflob[TechAni,ani_sectors,Emmtype,animals,t]$(sum(emm,d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm])) = 1; #90 procent afløb i et par år
aflob['Tech1','01031','EntericFermentation','CowsDairy',t]$(t.val>=2026 and t.val<=2031) = 0.9; #Afløb på Bovaer
d1TechSubsidyani[Techani,Emmtype,ani_sectors,animals,t] = yes$(sameas(Techani,'tech1') and sum(emm, d1Thetaani[Techani,ani_sectors,Emmtype,animals,t,emm]) and (425*inf_factor['2023'] - tCO2_emm_ani.l['EntericFermentation','01031','CowsDairy',t])>0);

#Subsidy between 2027 and 2031 (the years where the tax-incentive is too low for implementation of Bovaer)
tech_subsidy_ani.l[Techani,'EntericFermentation',ani_sectors,animals,t]$(d1TechSubsidyani[Techani,'EntericFermentation',ani_sectors,animals,t] and t.val>=2027 and t.val<=2031) 
  = 10 + 425*inf_factor['2023'] - tCO2_emm_ani.l['EntericFermentation','01031','CowsDairy',t];

###########################################
###### Abtement technology for plant ######
###########################################

switch_forward_looking_plant = 0; 	# Perhaps this should be controlled individually for ID and EOPtech...
switch_sluggish_plant = 0; 			# Perhaps this should be controlled individually for ID and EOPtech...
uEOPplantbeta = 0.5;            	# This parameter controls the degree of forward-lookingness for EOPtech technologies
rhoEOPplant[Techplant] = 0.8;       # This parameter controls the degree of sluggishness for EOPtech technologies
sigmaEOPplant[Techplant] = 0.1;  	# Default value for variance on technology costs

# NITRIFIKATIONSHÆMMERE (Konventionel plante, husdyrgødning)
thetaplant.l['tech1','01011','manure',t,'N2O'] = 0.22;						# Reduction potential (22 pct)
pEOPplant.l['tech1','manure',plant_sectors,t] = 1250*inf_factor['2023'];	# Price per tonne CO2e (1250 kr, 2023-prices)
sigmaEOPplant['tech1'] = 1; 												# Variance on technology costs 
shareplantPrice_type.l['tech1','capital',t] = 1;							# Cost type (Capital)
#  shareplantPrice_group.l['tech1','10120',t] = 0;							# IO price group (Not relevant)

# NITRIFIKATIONSHÆMMERE (Økologisk plante, husdyrgødning)
thetaplant.l['tech2','01012','manure',t,'N2O'] = 0.22;						# Reduction potential (22 pct)
pEOPplant.l['tech2','manure',plant_sectors,t] = 1250*inf_factor['2023'];	# Price per tonne CO2e (1250 kr, 2023-prices)
sigmaEOPplant['tech2'] = 1; 												# Variance on technology costs 
shareplantPrice_type.l['tech2','capital',t] = 1;							# Cost type (Capital)
#  shareplantPrice_group.l['tech2','10120',t] = 0;								# IO price group (Not relevant)

# NITRIFIKATIONSHÆMMERE (Konventionel plante, kunstgødning)
thetaplant.l['tech3','01011','inorganicfertilizer',t,'N2O'] = 0.24;						# Reduction potential (24 pct)
pEOPplant.l['tech3','inorganicfertilizer',plant_sectors,t] = 1500*inf_factor['2023'];	# Price per tonne CO2e (1500 kr, 2023-prices)
sigmaEOPplant['tech3'] = 1; 															# Variance on technology costs 
shareplantPrice_type.l['tech3','capital',t] = 1;										# Cost type (Capital)
#  shareplantPrice_group.l['tech3','10120',t] = 0;											# IO price group (Not relevant)

#### BACKSTOP VEGETABILSK

# Effektiviseringsteknologi for Manure i konventionel og økologisk plante 
#  thetaplant.l['tech4',plant_sectors,'manure',t,'N2O']$(sameas(plant_sectors,'01011') or sameas(plant_sectors,'01012')) = 0.075;	
#  pEOPplant.l['tech4','manure',plant_sectors,t] = 100;							
#  sigmaEOPplant['tech4'] = 10; 													
#  shareplantPrice_type.l['tech4','capital',t] = 1;

#  thetaplant.l['tech5',plant_sectors,'manure',t,'N2O']$(sameas(plant_sectors,'01011') or sameas(plant_sectors,'01012')) = 0.075;
#  pEOPplant.l['tech5','manure',plant_sectors,t] = 1000;							
#  sigmaEOPplant['tech5'] = 300; 													
#  shareplantPrice_type.l['tech5','capital',t] = 1;

#  # Effektiviseringsteknologi for InorganicFertilizer i konventionel plante 
#  thetaplant.l['tech6','01011','inorganicfertilizer',t,'N2O'] = 0.075;	
#  pEOPplant.l['tech6','inorganicfertilizer','01011',t] = 100;				
#  sigmaEOPplant['tech6'] = 10; 											
#  shareplantPrice_type.l['tech6','capital',t] = 1;

#  thetaplant.l['tech7','01011','inorganicfertilizer',t,'N2O'] = 0.075;	
#  pEOPplant.l['tech7','inorganicfertilizer','01011',t] = 1000;			
#  sigmaEOPplant['tech7'] = 300; 											
#  shareplantPrice_type.l['tech7','capital',t] = 1;

#  # Effektiviseringsteknologi for Other i konventionel og økologisk plante 
#  thetaplant.l['tech8',plant_sectors,'other',t,'CO2ubio']$(sameas(plant_sectors,'01011') or sameas(plant_sectors,'01012')) = 0.075;
#  pEOPplant.l['tech8','other',plant_sectors,t] = 100;							
#  sigmaEOPplant['tech8'] = 10; 												
#  shareplantPrice_type.l['tech8','capital',t] = 1;

#  thetaplant.l['tech9',plant_sectors,'other',t,'CO2ubio']$(sameas(plant_sectors,'01011') or sameas(plant_sectors,'01012')) = 0.075;
#  pEOPplant.l['tech9','other',plant_sectors,t] = 1000;							
#  sigmaEOPplant['tech9'] = 300; 													
#  shareplantPrice_type.l['tech9','capital',t] = 1;


# Parametre og dummies
uEOPplant.l[Emmtype,plant_sectors,t,emm]$(d1EmmAgrxE[emmtype,plant_sectors,t,emm]) = 1;		# Emmisionsfaktor


d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm] = yes$(tx1[t] and thetaplant.l[Techplant,plant_sectors,Emmtype,t,emm]);
d1vEOPCostplant[Emmtype,plant_sectors,s,t] = yes$(tx1[t] and sum((Techplant,emm), d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]) and sum(techplant, shareplantPrice_type.l[Techplant,'IO',t] and shareplantPrice_group.l[techplant,s,t]));

$GROUP G_dynamic_calibration_exo 
  G_dynamic_calibration_exo 
  qEmmAgrAni$(tx0[t] and d1EmmAgrAni[emmtype,Ani_sectors,Ani_,t,emm_eq] and sum(TechAni, d1ThetaAni[TechAni,ani_sectors,Emmtype,Ani_,t,emm_eq])) , -uEmmAgrAni$(tx0[t] and  d1EmmAgrAni[emmtype,Ani_sectors,Ani_,t,emm_eq] and sum(TechAni, d1ThetaAni[TechAni,ani_sectors,Emmtype,Ani_,t,emm_eq])) 
;

$GROUP G_dynamic_calibration_endo 
  G_dynamic_calibration_endo 
  -qEmmAgrAni$(tx0[t] and d1EmmAgrAni[emmtype,Ani_sectors,Ani_,t,emm_eq] and sum(TechAni, d1ThetaAni[TechAni,ani_sectors,Emmtype,Ani_,t,emm_eq])) , uEmmAgrAni$(tx0[t] and d1EmmAgrAni[emmtype,Ani_sectors,Ani_,t,emm_eq] and sum(TechAni, d1ThetaAni[TechAni,ani_sectors,Emmtype,Ani_,t,emm_eq])) 
;


$FIX G_dynamic_calibration_exo;
$UNFIX G_dynamic_calibration_endo;
# execute_unload 'output\pre.gdx';
@SOLVE(M_dynamic_calibration_KF);
# execute_unload 'output\post.gdx';
@assert_no_difference(G_data,%tolerance_data%);
$import sanitycheck.gms;