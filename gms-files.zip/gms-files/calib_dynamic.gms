
# ======================================================================================================================
# Dynamic calibration
# ======================================================================================================================

$SETGLOBAL adjacltable 1

# ----------------------------------------------------------------------------------------------------------------------
# Solver options
# ----------------------------------------------------------------------------------------------------------------------

$SETLOCAL flat_forecast 0 # Set to zero for regular calibration. Else we hold all exogenous variables (except rBonds) constant from this year.
$SETLOCAL steady_state 0  # If not zero, we overwrite all years with values from this year after solving.

# ----------------------------------------------------------------------------------------------------------------------
# Set time periods
# ----------------------------------------------------------------------------------------------------------------------

set_time_periods(%cal_start%, %terminal_year%);

# ----------------------------------------------------------------------------------------------------------------------
# Set dummies
# ----------------------------------------------------------------------------------------------------------------------


@set_dummies('2019',tForecast);  # Use dummies from last data year in following periods

#Implementer mere robust måde at opdatere d1tRE
d1tRE[purpose,energy19,r,t]               = yes$(d1qREgj[purpose,energy19,r,t] and (d1EAFG_RE[purpose,energy19,r,t] 
                                                                                    or d1SO2_RE[purpose,energy19,r,t] 
                                                                                    or d1PSO_RE[purpose,energy19,r,t] 
                                                                                    or d1NOx_RE[purpose,energy19,r,t] 
                                                                                    or d1CO2_RE[purpose,energy19,r,t] 
                                                                                    or d1VAT_RE[purpose,energy19,r,t] 
                                                                                    or d1tCO2_ETS_marg[purpose,energy19,r,t]));

d1pREgj[purpose,energy19,r,t]   = no;
d1pREgj[purpose,energy19,r,t]   = yes$(d1tRE[purpose,energy19,r,t] or d1pRE_base[purpose,energy19,r,t] or d1pREown[purpose,energy19,r,t]);
d1vREgj[purpose,energy19,r,t]   = yes$(d1pREgj[purpose,energy19,r,t] and d1qREgj[purpose,energy19,r,t]);



#Hvis der har været nul-investeringer i sidste dataår, bliver investeringerne dummy'et ud i resten af forecast. Dette rådes bod på ved at sætte den lig kapitalapparats dummy'en (NB: Redder ikke, hvis der er problemer med lagre)
d1I_s[k,s,tForecast]  = d1K[k,s,tDataEnd];

#Hvis der ikke er investeringer i sidste dataår bliver fpI_s ikke fremskrevet fladt. Derfor sættes den til et gennemsnit (gennemsnittet bør tilpasses eventuelle "nul-observationer")
fpI_s.l[i,s,tForecast]$(fpI_s.l[i,s,tDataEnd] = 0) = sum(t$tData[t], fpI_s.l[i,s,t])/card(tData); 

# ----------------------------------------------------------------------------------------------------------------------
# For certain energy-producing sectors there's an extremely small production of non-energy. In the forecast these are set to zero, by dummying out. It is likely that the small values are due to data inconsistencies - should be investigated with Statistics Denmark.
# ----------------------------------------------------------------------------------------------------------------------

#PRODUCTION 
$FOR {sectors} in ['38393']:
  d1qY_CET['out_other','{sectors}',tForecast] = no; qY_CET.l['out_other','{sectors}',tForecast] = 0;
  d1vY_CET['out_other','{sectors}',tForecast] = no; pY_CET.l['out_other','{sectors}',tForecast] = 0;
  d1vM_CET['out_other','{sectors}',tForecast] = no; pM_CET.l['out_other','{sectors}',tForecast] = 0;

  #DEMAND 
  $FOR1 {dim},{suffix} in [('r','RxE_y'),('r','RxE_m'),('c','C_y'),('c','C_m'),('g','G_y'),('g','G_m'),('i','I_y'),('i','I_m'),('x','X_y'),('x','X_m')]:
    d1{suffix}[{dim},'{sectors}',tForecast] = no;
    p{suffix}.l[{dim},'{sectors}',tForecast] = 0;
    q{suffix}.l[{dim},'{sectors}',tForecast] = 0;
    t{suffix}.l[{dim},'{sectors}',tForecast] = 0;
    #  vt{suffix}.l[{dim},'{sectors}',tForecast] = 0;
  $ENDFOR1

$ENDFOR

#  For 35002 and 19000 there's significant non-energy imports. Hence we only kill domestic demand/production
#PRODUCTION 35002
d1qY_CET['out_other','35002',tForecast] = no; qY_CET.l['out_other','35002',tForecast] = 0;
d1vY_CET['out_other','35002',tForecast] = no; pY_CET.l['out_other','35002',tForecast] = 0;

#DEMAND 35002
d1RxE_y[r,'35002',tForecast] = no; pRxE_y.l[r,'35002',tForecast] = 0; qRxE_y.l[r,'35002',tForecast] = 0;
d1C_y[c,'35002',tForecast]   = no; pC_y.l[c,'35002',tForecast] = 0; qC_y.l[c,'35002',tForecast] = 0;
d1G_y[g,'35002',tForecast]   = no; pG_y.l[g,'35002',tForecast] = 0; qG_y.l[g,'35002',tForecast] = 0;
d1I_y[i,'35002',tForecast]   = no; pI_y.l[i,'35002',tForecast] = 0; qI_y.l[i,'35002',tForecast] = 0;
d1X_y[x,'35002',tForecast]   = no; pX_y.l[x,'35002',tForecast] = 0; qX_y.l[x,'35002',tForecast] = 0;

#PRODUCTION 35012
d1qY_CET['out_other','35012',tForecast] = no; qY_CET.l['out_other','35012',tForecast] = 0;
d1vY_CET['out_other','35012',tForecast] = no; pY_CET.l['out_other','35012',tForecast] = 0;

#DEMAND 35012
d1RxE_y[r,'35012',tForecast] = no; pRxE_y.l[r,'35012',tForecast] = 0; qRxE_y.l[r,'35012',tForecast] = 0;
d1C_y[c,'35012',tForecast]   = no; pC_y.l[c,'35012',tForecast] = 0; qC_y.l[c,'35012',tForecast] = 0;
d1G_y[g,'35012',tForecast]   = no; pG_y.l[g,'35012',tForecast] = 0; qG_y.l[g,'35012',tForecast] = 0;
d1I_y[i,'35012',tForecast]   = no; pI_y.l[i,'35012',tForecast] = 0; qI_y.l[i,'35012',tForecast] = 0;
d1X_y[x,'35012',tForecast]   = no; pX_y.l[x,'35012',tForecast] = 0; qX_y.l[x,'35012',tForecast] = 0;


#PRODUCTION 19000
d1qY_CET['out_other','19000',tForecast] = no; qY_CET.l['out_other','19000',tForecast] = 0;
d1vY_CET['out_other','19000',tForecast] = no; pY_CET.l['out_other','19000',tForecast] = 0;

d1qM_CET['out_other','19000',tForecast] = no; qM_CET.l['out_other','19000',tForecast] = 0;
d1vM_CET['out_other','19000',tForecast] = no; pM_CET.l['out_other','19000',tForecast] = 0;

#DEMAND 19000
d1RxE_y[r,'19000',tForecast] = no; pRxE_y.l[r,'19000',tForecast] = 0; qRxE_y.l[r,'19000',tForecast] = 0;
d1C_y[c,'19000',tForecast]   = no; pC_y.l[c,'19000',tForecast]   = 0; qC_y.l[c,'19000',tForecast]   = 0;
d1G_y[g,'19000',tForecast]   = no; pG_y.l[g,'19000',tForecast]   = 0; qG_y.l[g,'19000',tForecast]   = 0;
d1I_y[i,'19000',tForecast]   = no; pI_y.l[i,'19000',tForecast]   = 0; qI_y.l[i,'19000',tForecast]   = 0;
d1X_y[x,'19000',tForecast]   = no; pX_y.l[x,'19000',tForecast]   = 0; qX_y.l[x,'19000',tForecast]   = 0;
d1I_s['invt','19000',tForecast] = no; pI_s.l['invt','19000',tForecast]= 0; qI_s.l['invt','19000',tForecast] = 0; 

d1RxE_m[r,'19000',tForecast] = no; pRxE_m.l[r,'19000',tForecast] = 0; qRxE_m.l[r,'19000',tForecast] = 0;
d1C_m[c,'19000',tForecast]   = no; pC_m.l[c,'19000',tForecast]   = 0; qC_m.l[c,'19000',tForecast]   = 0;
d1G_m[g,'19000',tForecast]   = no; pG_m.l[g,'19000',tForecast]   = 0; qG_m.l[g,'19000',tForecast]   = 0;
d1I_m[i,'19000',tForecast]   = no; pI_m.l[i,'19000',tForecast]   = 0; qI_m.l[i,'19000',tForecast]   = 0;
d1X_m[x,'19000',tForecast]   = no; pX_m.l[x,'19000',tForecast]   = 0; qX_m.l[x,'19000',tForecast]   = 0;

d1I_m['invt','19000',tForecast] = no; pI_m.l['invt','19000',tForecast] = 0; qI_m.l['invt','19000',tForecast] = 0;


#Dræber lagerinvesteringer i forecast 
d1I_s['invt',s,tForecast] = no; pI_s.l['invt',s,tForecast] = 0; qI_s.l['invt',s,tForecast]= 0; vI_s.l['invt',s,tForecast] = 0; d1I_y['invt',s,tForecast] = no; pI_y.l['invt',s,tForecast] = 0; qI_y.l['invt',s,tForecast] = 0; vI_y.l['invt',s,tForecast] = 0; pI_m.l['invt',s,tForecast] = 0; qI_m.l['invt',s,tForecast] = 0; vI_m.l['invt',s,tForecast] = 0; d1I_m['invt',s,tForecast] = no;
pI_r.l['invt',tForecast] = 0; qI.l['invt',tForecast] = 0; vI.l['invt',tForecast] = 0;

#  d1I_s['invt',sX02000,tForecast] = no; pI_s.l['invt',sX02000,tForecast] = 0; qI_s.l['invt',sX02000,tForecast]= 0; vI_s.l['invt',sX02000,tForecast] = 0; #Skovinvt
#  d1I_y['invt',sX02000,tForecast] = no; pI_y.l['invt',sX02000,tForecast] = 0; qI_y.l['invt',sX02000,tForecast] = 0; vI_y.l['invt',sX02000,tForecast] = 0; 
#  pI_m.l['invt',s,tForecast] = 0; qI_m.l['invt',s,tForecast] = 0; vI_m.l['invt',s,tForecast] = 0; d1I_m['invt',s,tForecast] = no;
#  #  pI_r.l['invt',tForecast] = 0; qI.l['invt',tForecast] = 0; vI.l['invt',tForecast] = 0;


#Update aggregate dummies
d1RxE_ym[r,s,tForecast] = yes$(d1RxE_y[r,s,tForecast] or d1RxE_m[r,s,tForecast]); # pRxE_ym.l[r,s,tForecast]$(not d1RxE_ym[r,s,tForecast]) = 0; qRxE_ym.l[r,s,tForecast]$(not d1RxE_ym[r,s,tForecast]) = 0;
d1c_ym[c,s,tForecast]   = yes$(d1C_y[c,s,tForecast] or d1C_m[c,s,tForecast]); # pC_ym.l[c,s,tForecast]$(not d1C_ym[c,s,tForecast]) = 0; qC_ym.l[c,s,tForecast]$(not d1C_ym[c,s,tForecast]) = 0;
d1g_ym[g,s,tForecast]   = yes$(d1G_y[g,s,tForecast] or d1g_m[g,s,tForecast]); # pG_ym.l[g,s,tForecast]$(not d1G_ym[g,s,tForecast]) = 0; qG_ym.l[g,s,tForecast]$(not d1G_ym[g,s,tForecast]) = 0;
d1I_ym[i,s,tForecast]   = yes$(d1I_y[i,s,tForecast] or d1I_m[i,s,tForecast]); # pI_ym.l[i,s,tForecast]$(not d1I_ym[i,s,tForecast]) = 0; qI_ym.l[i,s,tForecast]$(not d1I_ym[i,s,tForecast]) = 0;
d1X_ym[x,s,tForecast]   = yes$(d1X_y[x,s,tForecast] or d1X_m[x,s,tForecast]); 


# ----------------------------------------------------------------------------------------------------------------------
# Import the dynamic calibration models from the modules and combine them
# ----------------------------------------------------------------------------------------------------------------------
@import_from_modules("dynamic_calibration");

#If you want to run a calibration on a truncated time-horizon (to a year earlier than 2099 and as low was 2051) reset time-periods for calibration here:
  # set_time_periods(%cal_start%, 2025); #You can run the dynamic calibration (and that only) running to 2025, if you comment out the LULUCF-module
  # set_time_periods(%cal_start%, 2051); #At this point, 2.1.2025, you can run a calibration until and including the EV-consumer running the model until 2051.
  # set_time_periods(%cal_start%, 2051); #At this point, 2.1.2025, you can run a calibration until and including the EV-consumer running the model until 2051.

# ----------------------------------------------------------------------------------------------------------------------
# Shut down fur sector
# ----------------------------------------------------------------------------------------------------------------------
# The REGEX matches sector sets, sector aliases and sector subsets and shuts down the fur sector. If a dummy is defined over a new sector set this should be added to the code. 
# $LOOP pG_dummies:
# $REGEX("(.*)(,s,|,s_,|,r,|,r_,|,sp,|,ds_,|,ani_sectorss,|,Agri_sectors,|,Ani_sectors_,|,Ani_sectors,|,ani_sectors_sp,|,Ani_sectors_s,|,Ani_sectors_r,|,Ani_sectors_s_,)(.*)(\=)(.*)","\1,'01070',\3\4 no;") {name}{sets} = {name}{sets}; $ENDREGEX
# $REGEX("(.*)(\[s,|\[s_,|\[r,|\[r_,|\[sp,|\[ani_sectorss,|\[sec,|\[Ani_sectors_,|\[Ani_sectors,|\[ani_sectors_sp,|\[Ani_sectors_s,|\[Ani_sectors_r,|\[Ani_sectors_s_,)(.*)(\=)(.*)","\1['01070',\3\4 no;") {name}{sets} = {name}{sets}; $ENDREGEX
# $REGEX("(.*)(\[s\]|\[Ani_sectors_\]|\[Ani_sectors\]|\[ani_sectors_sp\]|\[Ani_sectors_s\]|\[Ani_sectors_r\]|\[Ani_sectors_s_\])(.*)(\=)(.*)","\1['01070']\3\4 no;") {name}{sets} = {name}{sets}; $ENDREGEX
# $ENDLOOP
# $exit 

$MODEL M_dynamic_calibration
  M_taxes_calib
  M_taxes_energy_calib, -M_taxes_aggregate_energy_tax_rates, B_taxes_calib #Currently the dynamic calibration will only solve with tax-rates computed based on revenues. Equations are swapped back in bottom of this file.
  M_energy_markets_calib
  M_aggregates_calib
  M_IO_calib
  M_exports_calib
  M_government_calib
  M_consumers_calib
  M_labor_market_calib
  M_emissions_calib
  M_production_private_calib
  M_production_public_calib
  M_waste_calib
  M_leakage_calib
  M_udvaskning_calib
  M_abatement_calib
  M_LULUCF_calib
  M_pyrolyse_calib 
;

# $MODEL M_dynamic_calibration_xlulucf
#   M_dynamic_calibration, -M_lulucf_calib,-M_udvaskning_calib
# ;

$GROUP G_dynamic_calibration_endo
  G_taxes_calib
  G_taxes_energy_calib
  G_energy_markets_calib
  G_aggregates_calib
  G_IO_calib
  G_exports_calib
  G_government_calib
  G_consumers_calib
  G_labor_market_calib
  G_emissions_calib
  G_production_private_calib
  G_production_public_calib
  G_waste_calib
  G_leakage_calib
  G_udvaskning_calib
  G_abatement_calib
  G_LULUCF_calib
  G_pyrolyse_calib
   -pWoodproduct_markup
   -qY_CET$(sameas[s,'03000'] and d1vY_CET[out,s,t]), markup$(sameas[s,'03000'] and d1vY_CET[out,s,t])
;

$GROUP G_dynamic_calibration_endo_saved
  G_dynamic_calibration_endo
  -G_lulucf_calib
;

$GROUP G_dynamic_calibration_exo
  G_taxes_calib_exo
  G_taxes_energy_calib_exo, vtCalibENS$(tx0[t] and d1pREgj[purpose,energy19,r,t] and d1tRE[purpose,energy19,r,t])
  G_energy_markets_calib_exo
  G_aggregates_calib_exo
  G_IO_calib_exo
  G_exports_calib_exo 
  G_government_calib_exo
  G_consumers_calib_exo
  G_production_private_calib_exo
  G_production_public_calib_exo
  G_labor_market_calib_exo
  G_emissions_calib_exo
  G_abatement_calib_exo
  G_waste_calib_exo
  G_leakage_calib_exo
  G_udvaskning_calib_exo
  G_LULUCF_calib_exo
  G_pyrolyse_calib_exo
   pWoodproduct_markup
   # udkommenteres ift. cet prod
   qY_CET$(sameas[s,'03000'] and d1vY_CET[out,s,t]), -markup$(sameas[s,'03000'] and d1vY_CET[out,s,t])
;

$GROUP G_dynamic_calibration_exo_saved 
  G_dynamic_calibration_exo
;

$FIX G_dynamic_calibration_exo;
$UNFIX G_dynamic_calibration_endo;
 execute_unload 'output\pre.gdx';
@SOLVE(M_dynamic_calibration);

$import sanitycheck.gms
execute_unload 'output\dynamic_calibration.gdx';

#Various check
  #  Check that demand equals supply for energy-goods. The check is carried out for both values and quantities
  $import check_DS.gms
  @assert_no_difference(G_data,1e-6);



#SETTING UP CALIBRATION MODEL INCL. AGRICULTURE
  $MODEL M_agr_calib 
      M_dynamic_calibration
      M_production_agr_calib
      M_production_plant_calib
      M_production_ani_calib
      M_taxes_aggregate_energy_tax_rates,-B_taxes_calib 
  ;

  $GROUP G_dynamic_calibration_exo 
      G_dynamic_calibration_exo
      G_production_agr_calib_exo
      G_production_plant_calib_exo
      G_production_ani_calib_exo
  ;

  $GROUP G_dynamic_calibration_endo
      G_dynamic_calibration_endo
      G_production_agr_calib
      G_production_plant_calib
      G_production_ani_calib
  ;


  #  $FIX G_dynamic_calibration_exo;
  #  $UNFIX G_dynamic_calibration_endo;
  #  @SOLVE(M_agr_calib);
  #  @assert_no_difference(G_data,1e-9);


