#====================================================================================================================================================================================#
# SOLVER OP<IONS 
#====================================================================================================================================================================================#

#Sætter LP-solver til CONOPT4
OPTION LP=CONOPT4;

#====================================================================================================================================================================================#
# VARIABLES AND PARAMETERS 
#====================================================================================================================================================================================#

$PGROUP G_endoland_parms npv_f                                    "Kapitaliseringsfaktor"
                         rDisk[t]                                 "Diskonteringsrate"
                         scaleha                                  "Divisor til skalering af arealer"
                         scale_value                              "Divisor til skalering af værdier"
                         ha_afgift                                "Hektarafgift"
                         ha_stoette                               "Hektarstøtte/grundbetaling"
                         ha_stoette_12aar                         "12-års grundbetaling til skovrejsning"
                         optionsvaerdi                            "Optionsvaerdi på landbrugsjord"


                         CO2perhaskov[btype,t]                    "CO2 optaget per ha skov - bør kobles til LULUCF-modul i stedet for hardcoding herunder"
                         c_struct_perha                           "Strukturel omkostning per hektar målt i 1000 kroner per ha. (eller mia. kroner per mio. ha). Fra zero_shock_agr 2079, hvor DBII er det samme som i IFRO data. =Netprod - Buildings - Machinesprivate - land"

                         #Udtagsmodel
                         qArea_tot[btype]                         "Total areal fra IFRO fordelt på 14 bedriftstyper"
                         qArea_tot_udtbase[btype]                 "Udtaget areal, baseline fordelt på 14 bedriftstyper"
                         qArea_tot_ejudtbase[btype]               "Areal ej udtaget i baseline fordelt på 14 bedriftstyper, før udtag af lavbund, solceller, mm."
                         qArea_tot_ejudt[btype]                   "Areal ej udtaget i baseline fordelt på 14 bedriftstyper"
                         DBII_gns[btype]                          "Gns. DBII på areal af en given 14-bedriftstype."
                         DBII_gns_base[btype]                     "Gns. DBII på areal i baseline - sættes pt. i read_land.gms"
                         DBII_std[btype]                          "Standardafvigelse på DBII for en given 14-bedriftstype"

                         vAlts[udfaldsrum,btype]                  "Værdien (målt i x kr/ha) af et givent alternativ til omdrift"
                         DBIIongrid[gridDBII,btype]               "Dækningsbidraget på et areal indenfor et givent grid (gridDBII). Beregnes pba. af DBII_gns og DBII_std"
                         areasingrid[gridDBII,btype]              "Areal indenfor et givent grid (gridDBII). Beregnes pba. af DBII_gns og DBII_std"
                         vAlts[alt,btype]                         ""
                         vAlts_base[alt,btype]                    ""
                         vBudget_bio_basis                        "Budget til udtag ved eco-schemet biodiversitet. Pt. indeholder det også finansiering til udtag af 32200 ha til GML-8 krav. Det bør ændres, så det holdes adskilt på sigt"
                         vBudget_bio                              ""  
                         qArea_GLM                                "Total udtagning af jord til GLM8-krav"
                         UdtagLavbund[btype]                      "Udtag af lavbund. Det er fordelt på alle btyper, pga. randarealer er mineraljorder"
                         UdtagSolceller[btype]                    "Udtag til solceller"

                         qAreaskovfragnsjord_tot                  "Udtag fra skov, der kommer fra gns. jord"
                         qAreaskovfragnsjord[btype]               ""
                         sAreaskovfragnsjord                      "Andel af skov, der tages fra gns. jord"
                         qLandSolceller_tot                       "Totalt udtag af solceller i justeret baseline"
                         qArea_permanentgraes_baseline            "Gns. permanente græsarealer i baseline"
                         qArea_omdrift_baseline                   "Omdriftsarealer i baseline"

                         #Link til CGE
                         vDBII_iomdrift_total[grid,gridtax,haudtag,lavbundsmodel]       "Samlet dækningsbidrag på jord i omdrift for given hektarafgift/negativ CO2e-afgift (grid,gridtax). Sum over btype"
                         udtag_udf[grid,gridtax,haudtag,lavbundsmodel,udfaldsrum,btype] "Samlet udtag for en given hektarafgift/negativ CO2e-afgift (grid,gridtax) fordelt på alternativer til omdrift og btype" 
                         permanentgraestilskov_udf[grid,gridtax,haudtag,lavbundsmodel]  "Samlet permanente græsarealer til skov"
                         produktion_perhaiomdrift[grid,gridtax,HaUdtag,lavbundsmodel]              "DBII_per ha i omdrift"
                         fproduktion_perhaiomdrift[grid,gridtax,HaUdtag,lavbundsmodel]             "Ændring i produktivitet per ha. DB_perhaiomdrift "

                         #Rapportering
                         DBII_atgrid[grid,btype]                  "Gns. DBII for bedriftstype for given værdi af hektarafgift"
                         vDBII_iomdrift[grid,gridtax,haudtag,lavbundsmodel,btype]       "Samlet dækningsbidrag på jord i omdrift for given hektarafgift/negativ CO2e-afgift (grid,gridtax) og btype"

                         udtag[grid,gridtax,haudtag,lavbundsmodel,btype]                "Samlet udtag for en given hektarafgift/negativ CO2e-afgift (grid,gridtax) fordelt på btype" 
                         udtag_udf_sumbtype[grid,gridtax,haudtag,lavbundsmodel,udfaldsrum] ""
                         AarligKulstof[grid,gridtax,haudtag,lavbundsmodel,t] ""


                        vAlts_atgrid[grid,gridtax,haudtag,lavbundsmodel,udfaldsrum,btype] "Værdien af alternativerne ved forskellige grid-sizes"
                        bioarea_ite                                 "Hjælpe-parameter til udtag til bioordning"     
                        bioarea_ite_lagged                          "Hjælpe-parameter til udtag til bioordning"                 
                        cutoff_GLM_atgrid[grid]                     "Nedslag på DB-fordelingerne for, hvor meget udtages til GLM-8 krav"
                        cutoff_GLM_parm                             "Hjælpe parameter til nedslag på DB-fordeligerne ift., hvor meget areal der udtages til GLM8-krav "
                        tCO2skov_equivalent[btype]                  ""

                        areasingrid_allite[grid,gridtax,haudtag,lavbundsmodel,gridDBII,udfaldsrum,btype] ""
                        DBII_allite[grid,gridtax,haudtag,lavbundsmodel,gridDBII,btype] ""


                        areasingrid_allite_sumbtype[grid,gridtax,haudtag,lavbundsmodel,gridDBII,udfaldsrum] ""
                        vDBII_allite_sumbtype[grid,gridtax,haudtag,lavbundsmodel,gridDBII] ""

                        AfkastTilskov[gridtax,btype]    ""
                        SkovTilskudOpslag250000[grid,haudtag,lavbundsmodel,btype] ""

                        qLandSolceller_tot "Totalt udtag af solceller i justeret baseline"
                        qArea_permanentgraes_baseline "Gns. permanente græsarealer i baseline"
                        qArea_omdrift_baseline        "Omdriftsarealer i baseline"
                        DBII_ongrid_allite_xhastoette[grid,gridtax,Haudtag,lavbundsmodel,gridDBII,btype] ""
                        DBIImarg_iomdrift[grid,gridtax,Haudtag,lavbundsmodel,btype] ""
                        DBIImarg_iomdrift_summminbtype[grid,gridtax,Haudtag,lavbundsmodel] ""
                        ChangeInDBIIperha[grid,gridtax,HaUdtag,lavbundsmodel] ""

; 


$GROUP G_endoland
                        qArea[udfaldsrum,btype]               "Areal ej udtaget i baseline fordelt på allokering (brak/bio/skov/omdrift) for de 14-bedriftstyper."
                        vProfit                               "Målvariabel for LP. Den samlede profit/DBII i systemet maksimeres ved valg af allokering af areal. Målvariablen kan dog ikke tolkes som faktisk samlet DBII, da små arealer skaleres op i objektfunktionen"
                        vProfit_brk                           "Profit på braklagte arealer. Kan som vProfit ikke direkte tolkes som samlet profit fra brak."
                        vProfit_bio                           "Profit på arealer udlagt til biodiversitet. Kan som vProfit ikke direkte tolkes som samlet profit fra biodiversitets eco-scheme."
                        vProfit_sko                           "Profit på arealer omlagt til skov. Kan som vProfit ikke direkte tolkes som samlet profit fra skovrejsning"
                        vProfit_glm                           "Straf for at vælge GLM - skal gøre de mindst produktive arealer til GLM"
                        cutoff_baseline[btype]                "Bruges ikke pt."
                        qArea_grid[udfaldsrum,gridDBII,btype] "Areal ej udtaget i baseline fordelt på arealanvendelse (brak/bio/skov/omdrift), et grid af arealer gridDBII og btype"
                        vDBII_tot                             "Total DBII på tilbageværende areal i omdrift"
                        vBudget_bio_ekstr                     "Yderligere finansiering af bio-scheme taget fra grundbetalingen (op til 50 000 ha)"                       
                        vBudget_grundbetaling                 "Totalt budget til grundbetaling - kan tilgå bio"
                        cutoff_GLM                            ""
                        vAlts_var[alt,btype]                  ""
                        adj_vAlts_var                         ""
                        govmoneyspentonforest                 ""
                        qArea_skovfrapermanentgraes           "Permanente græsarealer reguleres ud fra en forudsætning af at deres andel af produktive arealer ikke må falde. Når der omlægges til skov falder de produktive arealer, hvilket frigør arealer til skov"
;

  #  rDisk[t]$(t.val<=2053)                 = 0.035; #FM-diskonteringsrater. 3,5 pct. første 30 år
  #  rDisk[t]$(t.val>2053 and t.val <=2089) = 0.025; #FM-diskonteringsrater: 2,5 pct. fra 30-70 
  #  rDisk[t]$(t.val>2089)                  = 0.015; #FM-diskonteringsrater: 1,5 pct.t efter 70

  #  rDisk       = 1-fv/(1+rFirms.l['01011','2019']);
  rDisk[t]    = 0.035;

  rDisk['2019'] =  0.0230344201504476;
  rDisk['2020'] =  0.0234243449731645;
  rDisk['2021'] =  0.0238090361657042;
  rDisk['2022'] =  0.0240349854317454;
  rDisk['2023'] =  0.0243378717702636;
  rDisk['2024'] =  0.0246234520506898;
  rDisk['2025'] =  0.0248917381384944;
  rDisk['2026'] =  0.0251428074784504;
  rDisk['2027'] =  0.0253768019166088;
  rDisk['2028'] =  0.025593926324747;
  rDisk['2029'] =  0.0257944470404016;
  rDisk['2030'] =  0.0259786901367752;
  rDisk['2031'] =  0.0261470395380658;
  rDisk['2032'] =  0.0262999349970923;
  rDisk['2033'] =  0.0264378699534562;
  rDisk['2034'] =  0.0265613892918614;
  rDisk['2035'] =  0.026671087021594;
  rDisk['2036'] =  0.0267676038995155;
  rDisk['2037'] =  0.0268516250202253;
  rDisk['2038'] =  0.0269238773982874;
  rDisk['2039'] =  0.0269851275685777;
  rDisk['2040'] =  0.0270361792318835;
  rDisk['2041'] =  0.02707787097387;
  rDisk['2042'] =  0.027111074086434;
  rDisk['2043'] =  0.0271366905212876;
  rDisk['2044'] =  0.0271556510063889;
  rDisk['2045'] =  0.0271689133565814;
  rDisk['2046'] =  0.0271774610105523;
  rDisk['2047'] =  0.0271823018270299;
  rDisk['2048'] =  0.0271844671740504;
  rDisk['2049'] =  0.0271850113462177;
  rDisk['2050'] =  0.0271850113462177;
  rDisk['2051'] =  0.0271850113462177;
  rDisk['2052'] =  0.0271850113462177;
  rDisk['2053'] =  0.0271850113462177;
  rDisk['2054'] =  0.0271850113462177;
  rDisk['2055'] =  0.0271850113462177;
  rDisk['2056'] =  0.0271850113462177;
  rDisk['2057'] =  0.0271850113462177;
  rDisk['2058'] =  0.0271850113462177;
  rDisk['2059'] =  0.0271850113462177;
  rDisk['2060'] =  0.0271850113462177;
  rDisk['2061'] =  0.0271850113462177;
  rDisk['2062'] =  0.0271850113462177;
  rDisk['2063'] =  0.0271850113462177;
  rDisk['2064'] =  0.0271850113462177;
  rDisk['2065'] =  0.0271850113462177;
  rDisk['2066'] =  0.0271850113462177;
  rDisk['2067'] =  0.0271850113462177;
  rDisk['2068'] =  0.0271850113462177;
  rDisk['2069'] =  0.0271850113462177;
  rDisk['2070'] =  0.0271850113462177;
  rDisk['2071'] =  0.0271850113462177;
  rDisk['2072'] =  0.0271850113462177;
  rDisk['2073'] =  0.0271850113462177;
  rDisk['2074'] =  0.0271850113462177;
  rDisk['2075'] =  0.0271850113462177;
  rDisk['2076'] =  0.0271850113462177;
  rDisk['2077'] =  0.0271850113462177;
  rDisk['2078'] =  0.0271850113462177;
  rDisk['2079'] =  0.0271850113462177;
  rDisk['2080'] =  0.0271850113462177;
  rDisk['2081'] =  0.0271850113462177;
  rDisk['2082'] =  0.0271850113462177;
  rDisk['2083'] =  0.0271850113462177;
  rDisk['2084'] =  0.0271850113462177;
  rDisk['2085'] =  0.0271850113462177;
  rDisk['2086'] =  0.0271850113462177;
  rDisk['2087'] =  0.0271850113462177;
  rDisk['2088'] =  0.0271850113462177;
  rDisk['2089'] =  0.0271850113462177;
  rDisk['2090'] =  0.0271850113462177;
  rDisk['2091'] =  0.0271850113462177;
  rDisk['2092'] =  0.0271850113462177;
  rDisk['2093'] =  0.0271850113462177;
  rDisk['2094'] =  0.0271850113462177;
  rDisk['2095'] =  0.0271850113462177;
  rDisk['2096'] =  0.0271850113462177;
  rDisk['2097'] =  0.0271850113462177;
  rDisk['2098'] =  0.0271850113462177;
  rDisk['2099'] =  0.0271850113462177;

  npv_f            = sum(t$npv_periods[t], 1/(1+rDisk[t])**(t.val-t1.val));
  scaleha          = 1;    #Eventuel skalering af hektarer (1000 giver umiddelbart stabile resultater)
  scale_value      = 1000; #Skalering af værdier (1000 => værdier i tusinde kroner)
  #  ha_stoette  = 1900; #2000 kroner per ha.
  ha_stoette       = 704; #Løbende værdi af hektarstøtten  med udgangspunkt i 2025 
  ha_stoette_12aar = 294; #Værdi af 12 års nominel hektarstøtte med udgangspunkt i 2025
  ha_afgift        = 0;
  optionsvaerdi    = pLandvalueFromUnobserved.l['OptionsVaerdiIfbmInfrastruktur','01011','2025']*1000;
  c_struct_perha   = 5140;

#HER INDLÆSES IFRO-DATA - SE READLAND.GMS FOR DATA
  $IMPORT readland.gms

#Lidt beregninger
  qArea_tot_ejudtbase[btype] = qArea_tot[btype] - qArea_tot_udtbase[btype]; #Beregner ikke udtaget areal
  DBII_gns[btype]            = DBII_gns_base[btype] + ha_stoette;             #Beregner gns. DBII inkl. hastøtte
  DBII_std[btype]            = max(DBII_gns_base[btype]/3,500);               #Vi bruger IFRO's tommelfingerregel for standardafvigelsen som 1/3 af GNS, men mindst 500 kroner
  qArea_omdrift_baseline     = sum(btype, qArea_tot_ejudtbase[btype]);        #Kan overveje om den her skal endogent justeres til lavbund også..
  qArea_permanentgraes_baseline = 222000;                                     #Aflæser ved øjemål et ca. gennemsnit fra grafen her: https://lbst.dk/nyheder/nyhed/nyhed/i-fremtiden-skal-alle-danske-landbrugere-opfylde-et-krav-om-areal-med-permanent-graes

#VÆRDI AF ALTERNATIVER (eksl. skov  som bare indledningsvist sættes til noget meget lavt)
  vAlts['bio',btype]         =   2740; 
  #AKB: Skovgrid
  #  vAlts['bio',btype]         = -1000;
  vAlts['brk',btype]         =   -300; #-50; 


  vAlts['sko',btype]         = -10000; #NB: Ikke faktisk DBII på skov. Der sættes blot en lav værdi, så skov ikke vælges i nuværende setup.
  vAlts[alt,btype]$(not sameas[alt,'sko']) = vAlts[alt,btype] + ha_stoette + optionsvaerdi; #Lægger EU-støtte til.

  #Normaliser alternativer 
  vAlts_base[alt,btype]      = vAlts[alt,btype];
  vAlts[alt,btype]           = vAlts[alt,btype];

#Biodiversitets budgetbegrænsning                - Snydetarget med 82200. I virkeligheden er det 32200 GLM8 + 50000 biodiversitet. Det vurderes dog ikke, at det er urealistisk at landmændene udtager de mindst produktive jorde til GLM8, det kan de handle med på tværs af landet (åbenbart)
  vBudget_bio                = 2740/scale_value * 100000/scaleha; #Budget til 82200 hektar udtagning til biodiversitet
  vBudget_bio_basis          = 2740/scale_value *  50000/scaleha;
  vBudget_bio_ekstr.l        = 0;

#GLM8-krav 
  qArea_GLM                  = 32000/scaleha;

#SKALERING AF VÆRDIER 
  vAlts[alt,btype]           = vAlts[alt,btype]/scale_value;        #Skalerer til pænere størrelser for GAMS
  vAlts_base[alt,btype]      = vAlts_base[alt,btype]/scale_value;   #Skalerer til pænere størrelser for GAMS
  DBII_gns_base[btype]       = DBII_gns_base[btype]/scale_value;    #Skalerer til pænere størrelser for GAMS
  DBII_gns[btype]            = DBII_gns[btype]/scale_value;         #Skalerer til pænere størrelser for GAMS
  DBII_std[btype]            = DBII_std[btype]/scale_value;         #Skalerer til pænere størrelser for GAMS
  ha_stoette                 = ha_stoette/scale_value;              #Skalerer til pænere størrelser for GAMS
  ha_stoette_12aar           = ha_stoette_12aar/scale_value;        #Skalerer til pænere størrelser for GAMS
  optionsvaerdi              = optionsvaerdi/scale_value;           #Skalerer til pænere størrelser for GAMS
  c_struct_perha             = c_struct_perha/scale_value;          #Skalerer til pænere størrelser for GAMS

#  #SKALERING AF MÆNGDER
  qArea_tot[btype]           = qArea_tot[btype]/scaleha;            
  qArea_tot_udtbase[btype]   = qArea_tot_udtbase[btype]/scaleha;
  qArea_tot_ejudtbase[btype] = qArea_tot_ejudtbase[btype]/scaleha;
  qArea_omdrift_baseline     = qArea_omdrift_baseline/scaleha;
  qArea_permanentgraes_baseline = qArea_permanentgraes_baseline/scaleha; 
#Indlæser i anden variabel
  qArea_tot_ejudt[btype]     = qArea_tot_ejudtbase[btype];

#SKOV 
  #Andel af skov fra gns. jorder 
      sAreaskovfragnsjord = 0.2; #Sætter 20 pct. gennemsnitsjord.

#CO2-optag per ha skov for hhv. lav og højbonitetsjorde. 
# Vi regner med IGN's 'klimaoptimerede skovrejnsing', som er 50/50 af hurtigvoksende og skovrejsning siden 1990. 

  #FRA TABEL 2 I BILAG TIL GSR - 50/50 hurtigvoksende og traditionel
    CO2perhaskov[btypeH,t]$(t.val>=2019 and t.val <=2024) = 1.4;    #(0-5)
    CO2perhaskov[btypeH,t]$(t.val>=2025 and t.val <=2029) = 16;     #(6-10)
    CO2perhaskov[btypeH,t]$(t.val>=2030 and t.val <=2034) = 19.5;   #(11-15)
    CO2perhaskov[btypeH,t]$(t.val>=2035 and t.val <=2039) = 3;      #(16-20)
    CO2perhaskov[btypeH,t]$(t.val>=2040 and t.val <=2044) = 12.7;   #(21-25)
    CO2perhaskov[btypeH,t]$(t.val>=2045 and t.val <=2049) = 14.3;   #(26-30)
    CO2perhaskov[btypeH,t]$(t.val>=2050)                  = 2.2;    #(31-80)
  
  #På lav bonitet er det kulturmodel 12, hurtigvooksende sitka/rødgran, lav bonitet 
    CO2perhaskov[btypeL,t]$(t.val>=2019 and t.val <=2024) = 0.4;    #(0-5)
    CO2perhaskov[btypeL,t]$(t.val>=2025 and t.val <=2029) = 8.4;    #(6-10)
    CO2perhaskov[btypeL,t]$(t.val>=2030 and t.val <=2034) = 8.3;    #(11-15)
    CO2perhaskov[btypeL,t]$(t.val>=2035 and t.val <=2039) = 17.2;   #(16-20)
    CO2perhaskov[btypeL,t]$(t.val>=2040 and t.val <=2044) = 8.2;    #(21-25)
    CO2perhaskov[btypeL,t]$(t.val>=2045 and t.val <=2049) = 12.9;   #(26-30)
    CO2perhaskov[btypeL,t]$(t.val>=2050)                  = 4;      #(31-80)
  
  #Hack. Da tilskuddet ikke differentieres på bonitet og i øvrigt ikke gives per lagret ton CO2 sættes CO2perhaskov for lav til at være den samme som for højbonitet 
    CO2perhaskov[btypeL,t]$(t.val>=2019 and t.val <=2024) = 1.4;    #(0-5)
    CO2perhaskov[btypeL,t]$(t.val>=2025 and t.val <=2029) = 16;     #(6-10)
    CO2perhaskov[btypeL,t]$(t.val>=2030 and t.val <=2034) = 19.5;   #(11-15)
    CO2perhaskov[btypeL,t]$(t.val>=2035 and t.val <=2039) = 3;      #(16-20)
    CO2perhaskov[btypeL,t]$(t.val>=2040 and t.val <=2044) = 12.7;   #(21-25)
    CO2perhaskov[btypeL,t]$(t.val>=2045 and t.val <=2049) = 14.3;   #(26-30)
    CO2perhaskov[btypeL,t]$(t.val>=2050)                  = 2.2;    #(31-80)
  
  #Hack 2 - indlæser lavbundsudtag på placering 0 - som skal blive til baseline før solceller 
    VaadOmk[HaUdtag,'0']                                  = VaadOmk[HaUdtag,'1'];
    Komp120pct[HaUdtag,'0']                               = Komp120pct[HaUdtag,'1'];
    HaHoejV[HaUdtag,'0']                                  = HaHoejV[HaUdtag,'1'];
    HaLavV[HaUdtag,'0']                                   = HaLavV[HaUdtag,'1'];
    HaRand[HaUdtag,'0']                                   = HaRand[HaUdtag,'1'];

  #Engangstilskudssats omregnes til, hvad det ville svare til, hvis der blev givet løbende CO2e-tilskud. Herunder et engangstilskud på 60 000 = 90 0000 (fuldt tilskud) - 30 000 (kompensation for tabt harmoniareal).
    #Det giver ca. 250 kroner per tCO2e
    tCO2skov_equivalent[btypeL] = 60000/scale_value/sum(t$(npv_periods[t]), 1/(1+rDisk[t])**(t.val-t1.val) *inf_factor['2022']/scale_value * CO2perhaskov[btypeL,t]);
    tCO2skov_equivalent[btypeH] = 60000/scale_value/sum(t$(npv_periods[t]), 1/(1+rDisk[t])**(t.val-t1.val) *inf_factor['2022']/scale_value * CO2perhaskov[btypeH,t]);
    
  #"HACK" - indlæser lavbundsudtag på placering 0 - som bliver til baseline før solceller. Det er lidt forvirrende lavet at bruge placering 0 til dette. Overvej at lave et nyt set i stedet for at bruge lavbundssettet som placeholder.
    VaadOmk[HaUdtag,'0']                                  = VaadOmk[HaUdtag,'1'];
    Komp120pct[HaUdtag,'0']                               = Komp120pct[HaUdtag,'1'];
    HaHoejV[HaUdtag,'0']                                  = HaHoejV[HaUdtag,'1'];
    HaLavV[HaUdtag,'0']                                   = HaLavV[HaUdtag,'1'];
    HaRand[HaUdtag,'0']                                   = HaRand[HaUdtag,'1'];

  #Totalt udtag til solceller i justeret baseline 
    qLandSolceller_tot = 7300;

#====================================================================================================================================================================================#
# MODEL 
#====================================================================================================================================================================================#

#Laver model til beregning af baseline - bruges ikke pt.
  #  $BLOCK B_calculatebaselinecutoff
  #    #  E_cutoff_baseline[btype].. qArea_tot_udtbase[btype] =E= qArea_tot_ejudt[btype] * @cdfNorm(cutoff_baseline[btype],DBII_gns[btype],DBII_std[btype]);

  #    E_cutoff_GLM..    qArea_GLM =E= sum(btype, qArea_tot_ejudtbase[btype] * @cdfNorm(cutoff_GLM, DBII_gns[btype], DBII_std[btype]));

  #    E_qArea_glm_[btype].. qArea['glm',btype] =E= qArea_tot_ejudtbase[btype] * @cdfNorm(cutoff_GLM, DBII_gns[btype], DBII_std[btype]);
  #  $ENDBLOCK 

  $BLOCK B_calculateGLM
    E_cutoff_GLM..                 qArea_GLM =E= sum(btype, qArea_tot_ejudt[btype] * @cdfNorm(cutoff_GLM, DBII_gns[btype], DBII_std[btype]));


    E_qArea_glm_[btype].. qArea['glm',btype] =E= qArea_tot_ejudt[btype] * @cdfNorm(cutoff_GLM, DBII_gns[btype], DBII_std[btype]);


 $ENDBLOCK 

  $MODEL M_calculateGLM B_calculateGLM;
  $UNFIX cutoff_GLM, qArea;
  @SOLVE(M_calculateGLM);
  cutoff_GLM_parm = cutoff_GLM.l;


#Ligninger
Equations E_qArea_tot[gridDBII,btype]
          E_qArea_omd[btype]
          E_qArea_bio[btype]
          E_qArea_brk[btype]
          E_qArea_sko[btype]
          E_maxskov
          E_qArea_glm[btype]
          E_vBudget_bio
          E_vBudget_grundbetaling
          E_qUdtagGLM8
          E_qUdtagGLM8_calib
          E_vProfit
          E_vProfit_brk
          E_vProfit_bio
          E_vProfit_sko
          E_vDBII_gns
          E_qArea_skovfrapermanentgraes
          E_vProfit_glm
          E_vProfit_sko_search
          E_maxoutsko
          E_vAlts_var_sko
          E_govmoneyspentonforest
          E_vProfitAlt
          
          #As a rule
          E_vProfitAlt2
          E_vAlts_ge_brk 
          E_vGridRule

          ;

#Restriktion, der sige rat det totale areal indenfor et grid skal være summen af arealer fordelt på de mulige allokeringer indenfor det grid.
E_qArea_tot[gridDBII,btype].. areasingrid[gridDBII,btype] =E=  qArea_grid['omd',gridDBII,btype]
                                                             + qArea_grid['bio',gridDBII,btype]
                                                             + qArea_grid['brk',gridDBII,btype]
                                                             + qArea_grid['sko',gridDBII,btype]
                                                             + qArea_grid['glm',gridDBII,btype];

#Beregner samlet areal i omdrift for given btype
E_qArea_omd[btype].. qArea['omd',btype] =E= sum(gridDBII,qArea_grid['omd',gridDBII,btype]);

#Beregner samlet areal til eco-schemet biodiversitet for given btype
E_qArea_bio[btype].. qArea['bio',btype] =E= sum(gridDBII,qArea_grid['bio',gridDBII,btype]);

#Beregner samlet braklagt areal for en given btype (*braklagt i stød)
E_qArea_brk[btype].. qArea['brk',btype] =E= sum(gridDBII,qArea_grid['brk',gridDBII,btype]);

#Beregner samlet areal i til skovrejsning for en given btype
E_qArea_sko[btype].. qArea['sko',btype] =E= sum(gridDBII,qArea_grid['sko',gridDBII,btype]);

#Max 250 000 ha skov udtaget
E_maxskov..          250000 =G=       sum(btype, qArea['sko',btype]) + qArea_skovfrapermanentgraes + qAreaskovfragnsjord_tot;

#Budgetbetingelse for eco-schemet biodiversitet. 
E_vBudget_bio..      vBudget_bio        =G= sum(btype,(vAlts_base['bio',btype] -ha_stoette-optionsvaerdi) * qArea['bio',btype]);

#Der skal udtages 32000 ha til GLM8-krav
E_qUdtagGLM8_calib..       qArea_GLM          =E= sum(btype, qArea['glm',btype]);

E_qUdtagGLM8[btype]..             qArea['glm',btype] =E= qArea.l['glm',btype];

#MÅL - MAKSIMER vPROFIT
E_vProfit.. vProfit =E= vProfit_brk + vProfit_bio + vProfit_sko;
 
E_vProfit_bio.. vProfit_bio =E= sum((gridDBII,btype)$(areasingrid[gridDBII,btype]), (vAlts['bio',btype] -DBIIongrid[gridDBII,btype])                    * qArea_grid['bio',gridDBII,btype] *(sum((gridDBII_a,btype_a), areasingrid[gridDBII_a,btype_a])/(sum(btype_a,areasingrid[gridDBII,btype_a]))));
#  E_vProfit_brk.. vProfit_brk =E= sum((gridDBII,btype), (vAlts['brk',btype] + (1900/scale_value-ha_stoette)-DBIIongrid[gridDBII,btype])  * qArea_grid['brk',gridDBII,btype] *(sum((gridDBII_a,btype_a), areasingrid[gridDBII_a,btype_a])/(sum(btype_a,areasingrid[gridDBII,btype_a]))));
E_vProfit_brk.. vProfit_brk =E= sum((gridDBII,btype)$(areasingrid[gridDBII,btype]), (vAlts['brk',btype] -DBIIongrid[gridDBII,btype])                    * qArea_grid['brk',gridDBII,btype] *(sum((gridDBII_a,btype_a), areasingrid[gridDBII_a,btype_a])/(sum(btype_a,areasingrid[gridDBII,btype_a]))));
E_vProfit_sko.. vProfit_sko =E= sum((gridDBII,btype)$(areasingrid[gridDBII,btype]), (vAlts['sko',btype] -DBIIongrid[gridDBII,btype])                    * qArea_grid['sko',gridDBII,btype] *(sum((gridDBII_a,btype_a), areasingrid[gridDBII_a,btype_a])/(sum(btype_a,areasingrid[gridDBII,btype_a]))));
#  E_vProfit_glm.. vProfit_glm =E= sum((gridDBII,btype), (2*smax(alt,vAlts[alt,btype])-DBIIongrid[gridDBII,btype])   * qArea_grid['glm',gridDBII,btype]         *(sum((gridDBII_a,btype_a), areasingrid[gridDBII_a,btype_a])/(sum(btype_a,areasingrid[gridDBII,btype_a]))));


#PERMANENT GRÆS TIL SKOV 

E_qArea_skovfrapermanentgraes.. qArea_skovfrapermanentgraes =E= qArea_permanentgraes_baseline/qArea_omdrift_baseline * (sum(btype, qArea['sko',btype]) + qAreaskovfragnsjord_tot); 

#tKroner/ha x ha = tKroner 
E_vDBII_gns.. vDBII_tot =E= sum((gridDBII,btype), (DBIIongrid[gridDBII,btype]-ha_stoette-optionsvaerdi) * qArea_grid['omd',gridDBII,btype]);




#Den her del er til modellen, der søger optimalt tilskud til 250 000 hektar skov
E_vProfit_sko_search.. vProfit_sko =E= sum((gridDBII,btype)$(areasingrid[gridDBII,btype]), (vAlts_var['sko',btype] -DBIIongrid[gridDBII,btype])  * qArea_grid['sko',gridDBII,btype]);  #*(sum((gridDBII_a,btype_a), areasingrid[gridDBII_a,btype_a])/(sum(btype_a,areasingrid[gridDBII,btype_a]))));

E_maxoutsko.. 250000 =E= sum(btype, qArea['sko',btype]) + qArea_skovfrapermanentgraes + qAreaskovfragnsjord_tot;

E_govmoneyspentonforest.. sum(btype, vAlts_var['sko',btype] * qArea['sko',btype]) =E= govmoneyspentonforest;
#  E_vAlts_var_sko[btype].. vAlts_var['sko',btype] =E= vAlts['sko',btype] + adj_vAlts_var;
E_vAlts_var_sko[btype].. vAlts_var['sko',btype] =E= adj_vAlts_var;

#Hvad hvis man laver skovudtag som et sæt regler
E_vAlts_ge_brk[btype].. vAlts_var['sko',btype] =G= vAlts['brk',btype]; #Regel 1: Skov skal slå braklægning
E_vGridRule[gridDBII,btype]$(areasingrid[gridDBII,btype])..  vAlts_var['sko',btype] * qArea_grid['sko',gridDBII,btype] =G= DBIIongrid[gridDBII,btype] *qArea_grid['sko',gridDBII,btype]; #Regel 2, skov skal slå omdrift
#  E_vGridRule2[gridDBII,btype]$(areasingrid[gridDBII,btype]).. qArea_grid['sko',gridDBII,btype] =G= qArea_grid['omd',gridDBII+1,btype]; 
E_vProfitAlt.. vProfit =E= vProfit_brk + vProfit_bio + vProfit_sko - sqr(govmoneyspentonforest); #Vi trækker penge på skovrejsning fra i kriterie funktionen. Det skulle gerne lægge en øvre grænse på vAlts_var 




#Model samles. Der laves også en model uden braklægning til eventuel troubleshooting.
MODEL M_endoland /E_qArea_tot, E_qArea_omd, E_qArea_bio, E_qArea_brk,  E_qArea_sko,  E_maxskov,
                  E_vBudget_bio, 
                  E_vProfit,    
                  E_qUdtagGLM8, 
                  E_vProfit_bio, E_vProfit_brk, 
                  E_vProfit_sko,E_vDBII_gns,
                  E_qArea_skovfrapermanentgraes
                  /;

MODEL M_endoland_calib /E_qArea_tot, E_qArea_omd, E_qArea_bio, E_qArea_brk,  E_qArea_sko,  E_maxskov,
                  E_vBudget_bio, 
                  E_vProfit,    
                  E_vProfit_bio, E_vProfit_brk, 
                  E_vProfit_sko,E_vDBII_gns,
                  E_qArea_skovfrapermanentgraes
                  /;



MODEL M_opslagskov/E_qArea_tot, E_qArea_omd, E_qArea_bio, E_qArea_brk,  E_qArea_sko
                  E_vBudget_bio,    
                  E_qUdtagGLM8, 
                  E_vProfit_bio, E_vProfit_brk, 
                  E_vDBII_gns,
                  E_maxoutsko,
                  E_vAlts_var_sko,
                  E_vProfit_sko_search,
                  E_vProfitAlt,
                  E_govmoneyspentonforest,
                  E_vAlts_ge_brk,
                  E_vGridRule,
                  E_qArea_skovfrapermanentgraes/;




 
#====================================================================================================================================================================================#
# LØSNING AF MODEL VED FORSKELLIGE FORUDSÆTNINGER 
#====================================================================================================================================================================================#


#Der kører to grids over loops. Det yderste er grid over en eventuel negativ CO2e-afgift på skovrejsning. Det inderste er loop over hektarafgifter.
#  $FOR {gridCO2tax} in ['0','125','250','375','500','625','750']:
$FOR {gridCO2tax} in ['0','750']: #,'125','150','175','200','225','250','275','300','325','350','375','400','425','450','475','500','625','750']:
    $FOR1 {grid} in ['0','100','200','300','400','500','600','700','800','900','1000','1100','1200','1300','1400','1500','1600','1700','1800','1900','2000','2100','2200','2300','2400','2500','2600','2700','2800','2900','3000','3100','3200','3300','3400','3500','3600','3700','3800','3900','4000','4100','4200','4300','4400','4500','4600','4700','4800','4900','5000','5100','5200','5300','5400','5500','5600','5700','5800','5900','6000']:
       $FOR2 {HaUdtag},{lavm} in [('35000','0'),('35000','1'),('70000','1'),('70000','2')]:
    
    #Start by unfixing everything
    qArea_grid.lo[udfaldsrum,gridDBII,btype] = 0; qArea_grid.up[udfaldsrum,gridDBII,btype] = inf;

    #Ha-afgift sættes og gns. DBII beregnes 
    ha_afgift                   = {grid}/scale_value;


    
    DBII_gns[btype]             = DBII_gns_base[btype] + ha_stoette + optionsvaerdi - ha_afgift $IF {lavm}==2: - 1.8$( (sameas[btype,'11'] or sameas[btype,'11_high'])) $ENDIF;
    DBII_atgrid['{grid}',btype] = DBII_gns[btype];
    #  cutoff_GLM.l                = cutoff_GLM_parm - ha_afgift;


  #Opdaterer arealer med evt. lavbund (og solceller, når de kommer )
  UdtagLavbund[btype]    =  0.42 * HaRand['{HaUdtag}','{lavm}']*qArea_tot_ejudtbase[btype]$(btypexlav[btype])/sum(btypexlav_a, qArea_tot_ejudtbase[btypeXlav_a])
                          + 0.42 * HaHoejV['{HaUdtag}','{lavm}']$(sameas[btype,'11_high'])
                          + 0.42 * HaLavV['{HaUdtag}','{lavm}']$(sameas[btype,'11']); 

  #Solceller
   UdtagSolceller[btype] = 0;
   $IF {lavm} !=0:  UdtagSolceller[btype] = qLandSolceller_tot * qArea_tot_ejudtbase[btype]$(btypexlav[btype])/sum(btypexlav_a, qArea_tot_ejudtbase[btypeXlav_a]); $ENDIF

  qArea_tot_ejudt[btype] =  qArea_tot_ejudtbase[btype] - UdtagLavbund[btype] - UdtagSolceller[btype];
  loop(btype, 
      tjek = qArea_tot_ejudt[btype];
      ABORT$(tjek < 0) tjek, "Udtag giver negative arealer - juster hvordan arealer udtages i ovenstående kode.";
      );

  #Skov - nulstiller evt. udtag fra gnsjord
    qAreaskovfragnsjord_tot = 0;


  #GLM cut-off beregnes efter arealer er justerede. Det bør ændres til at GLM er 4 pct. af omdrift. Ha' en god dag.
   @SOLVE(M_calculateGLM); 
   cutoff_GLM_atgrid['{grid}'] = cutoff_GLM.l;
  
  

  #Nutidsværdi af skovrejsning
    #For højbonitetsjorde
    vAlts['sko',btypeH]     = -31937/scale_value                                                                                                    #Rejsningsomkostninger #JMN udkommenteret fordi jeg gerne vil se på tilskyndelse hvis nuværende puljer skaleres (nuværende puljer dækker investeringsomkostningen)
                              -5500/scale_value #Meromkostning ved indfrielse af fuldt teknisk potentiale (250 000 ha)
                              +7000/scale_value #Forskel i diskontering af fremtidige indtægter
                              + sum(t$(npv_periods[t]), 1/(1+rDisk[t])**(t.val-t1.val) * {gridCO2tax}*inf_factor['2023']/scale_value * CO2perhaskov[btypeH,t])      #Indtægter fra negativ CO2-afgift 
                            #  + sum(t$(npv_periods[t]), 1/(1+rDisk[t])**(t.val-t1.val) * ha_stoette)                                #JMN: Hektarstøtte 4ever
                            #  + sum(t$(npv_periods_hastoette[t]), 1/(1+rDisk)**(t.val-t1.val) * ha_stoette);
                            ;
    #For lavbonitetsjorde
    vAlts['sko',btypeL]      = -39776/scale_value  
                               -5500/scale_value #Meromkostning ved indfrielse af fuldt teknisk potentiale (250 000 ha)
                               +7000/scale_value #Forskel i diskontering af fremtidige indtægter
                             + sum(t$(npv_periods[t]), 1/(1+rDisk[t])**(t.val-t1.val) * {gridCO2tax}*inf_factor['2023']/scale_value * CO2perhaskov[btypeL,t])
                            #  + sum(t$(npv_periods[t]), 1/(1+rDisk[t])**(t.val-t1.val) * ha_stoette); 
                            #  + sum(t$(npv_periods_hastoette[t]), 1/(1+rDisk)**(t.val-t1.val) * ha_stoette)
                            ; 

  #Nutidsværdien omregnes til fast løbende cash-flow for sammenlignelighed med løbende DBII 
    vAlts['sko',btype] = vAlts['sko',btype]/npv_f;
    vAlts['sko',btype] = vAlts['sko',btype] + ha_stoette_12aar; #Lægger 12 års hektarstøtte til.

  #TIL NORMALISERING  
    vAlts[alt,btype]   =  vAlts[alt,btype];
    vAlts['sko',btype] =  vAlts['sko',btype]; 

    #Ok, indtil videre antages ingen rabatter.
    #  $IF {lavm}==2: vAlts[alt,btypelav] = vAlts_base[alt,btypelav] - 1.8*0.5; $ENDIF #Halvdelen af afgiften kan undgås ved ikke at dyrke jorden...
    #  $IF {lavm}==2: vAlts[alt,btypelav] = vAlts_base[alt,btypelav] - 1.8*0.5; $ENDIF #Halvdelen af afgiften kan undgås ved ikke at dyrke jorden...
    #  $IF {lavm}!=2: vAlts[alt,btypelav] = vAlts_base[alt,btypelav]; $ENDIF

  #STEP 2) Arealet over cut-off inddeles i et grid (indtil videre 100-steps grid). Arealet imellem cut-off og 3 standardafvigelser (så vi er langt ude på fordelingen)

    loop(gridDBII,
      DBIIongrid[gridDBII,btype] = (cutoff_GLM.l + (8.5*smax(btype_a,DBII_std[btype_a]))*(ord(gridDBII)-1)/(card(gridDBII)-1));
       );

  #STEP 3) Compute the areas in each grid
    areasingrid[gridDBII,btype] = qArea_tot_ejudt[btype]*  (@cdfNorm(DBIIongrid[gridDBII,btype],DBII_gns[btype],DBII_std[btype])
                                                               -(@cdfNorm(DBIIongrid[gridDBII-1,btype],DBII_gns[btype],DBII_std[btype]))$(not sameas[gridDBII,'grid1']));
                                                                                             

    areasingrid[gridDBII,btype]$(areasingrid[gridDBII,btype]<1 and not sameas[gridDBII,'grid1']) = 0;

    #  areasingrid['grid1',btype]   = 0; #GLM - nothing to allocate

    areasingrid['grid100',btype] = qArea_tot_ejudt[btype] * (1-@cdfNorm(DBIIongrid['grid99',btype],DBII_gns[btype],DBII_std[btype]));


  #STEP 4) Maximize profits on all lands, allocating land to bio, brk and omd.
    qArea_grid.lo[udfaldsrum,gridDBII,btype] = 0; #No negative areas allowed
    qArea_grid.fx['sko',gridDBII,'11']       = 0; #JMN Ingen skov på lavbund - bør være et kriterie i støttepuljen.
    qArea_grid.fx['sko',gridDBII,'11_high']  = 0; #    Ingen skov på lavbund
    qArea_grid.fx['GLM','grid1',btype]       = areasingrid['grid1',btype];
    qArea_grid.fx['GLM',gridDBII,btype]$(not sameas[gridDBII,'grid1']) = 0;

#STEP 5) Hand-held biodiversity 
    #  qArea_grid.l['bio',gridDBII,btype]$((DBIIongrid[gridDBII,btype]<vAlts['bio',btype]) and (vAlts['bio',btype]> vAlts['sko',btype]) and not sameas[gridDBII,'grid1']) = areasingrid[gridDBII,btype]; #Initial value on BIO
    qArea_grid.l['bio',gridDBII,btype] = 0; qArea_grid.up['bio',gridDBII,btype] = inf; qArea_grid.lo['bio',gridDBII,btype] = 0;  #Resetter bio
    qArea_grid.l['bio',gridDBII,btype]$((DBIIongrid[gridDBII,btype]<vAlts['bio',btype]) and not sameas[gridDBII,'grid1']) = areasingrid[gridDBII,btype]; #Initial value on BIO
    bioarea_ite = 0;
    bioarea_ite_lagged = 0;
    LOOP(gridDBII,
      bioarea_ite = bioarea_ite + sum(btype,qArea_grid.l['bio',gridDBII,btype]);
      bioarea_ite_lagged$(not (sameas[gridDBII,'grid1'] or sameas[gridDBII,'grid2']))
                  = bioarea_ite_lagged + sum(btype,qArea_grid.l['bio',gridDBII-1,btype]); #Den her ville starte på 1, hvis ikke 1 var reserveret til GLM allerede.

      #Når vi overskrider 100 000 grænsen tildeles de sidste hektar proportionalt med hvor meget areal, der ligger for btypen. 
      qArea_grid.fx['bio',gridDBII,btype]$(bioarea_ite>100000/scaleha and bioarea_ite_lagged<100000/scaleha)
         = (100000/scaleha - bioarea_ite_lagged) * areasingrid[gridDBII,btype]/sum(btype_a, areasingrid[gridDBII,btype_a]);

      #Efter grænsen på 100 000 er overskredet sættes alt til 0.
      qArea_grid.fx['bio',gridDBII,btype]$(bioarea_ite>100000/scaleha and bioarea_ite_lagged>=100000/scaleha) = 0; 
      );

    qArea_grid.fx['bio',gridDBII,btype]$(qArea_grid.l['bio',gridDBII,btype]<>0) = qArea_grid.l['bio',gridDBII,btype];

    Solve M_endoland using LP maximizing vProfit;
    qArea_grid.fx['sko',gridDBII,btype]$(not sameas[gridDBii,'grid1'] and (qArea_grid.l['sko',gridDBII,btype]<100) and (qArea_grid.l['sko',gridDBII-1,btype]=0) and (qArea_grid.l['sko',gridDBII+1,btype]=0)) = 0;
    qArea_grid.fx['omd',gridDBII,btype]$(not sameas[gridDBii,'grid1'] and (qArea_grid.l['omd',gridDBII,btype]<100) and (qArea_grid.l['omd',gridDBII-1,btype]=0) and (qArea_grid.l['omd',gridDBII+1,btype]=0)) = 0;
    Solve M_endoland using LP maximizing vProfit;

    #SKOV FRA GENNEMSNITLIG JORD
      qAreaskovfragnsjord_tot = sAreaskovfragnsjord * sum(btype, qArea.l['sko',btype]);

      #Vi regner kun skovscenarie, for mere end 1000 hektar skov...
      IF (qAreaskovfragnsjord_tot>1000,

        #Finder ud af hvor store arealer, der skal tages fra hver btype 
        qAreaskovfragnsjord[btype] = qAreaskovfragnsjord_tot * qArea_tot_ejudtbase[btype]$(btypexlav[btype])/sum(btypexlav_a, qArea_tot_ejudtbase[btypeXlav_a]);

        #Arealer fraregnes
        qArea_tot_ejudt[btype] =  qArea_tot_ejudtbase[btype] - UdtagLavbund[btype] - UdtagSolceller[btype] - qAreaskovfragnsjord[btype];

          loop(btype, 
          tjek = qArea_tot_ejudt[btype];
          ABORT$(tjek < 0) tjek, "Udtag giver negative arealer - juster hvordan arealer udtages i ovenstående kode.";
          );

        #NU KØRES HELE UDTAGNINGEN IGEN MEN MED GNS. SKOV SOM EN DEL AF UDTAGNINGEN
            #GLM cut-off beregnes efter arealer er justerede. Det bør ændres til at GLM er 4 pct. af omdrift. Ha' en god dag.
            @SOLVE(M_calculateGLM); 
            cutoff_GLM_atgrid['{grid}'] = cutoff_GLM.l;

            #STEP 2) Arealet over cut-off inddeles i et grid (indtil videre 100-steps grid). Arealet imellem cut-off og 3 standardafvigelser (så vi er langt ude på fordelingen)

              loop(gridDBII,
                DBIIongrid[gridDBII,btype] = (cutoff_GLM.l + (8.5*smax(btype_a,DBII_std[btype_a]))*(ord(gridDBII)-1)/(card(gridDBII)-1));
                 );

            #STEP 3) Compute the areas in each grid
              areasingrid[gridDBII,btype] = qArea_tot_ejudt[btype]  *  (@cdfNorm(DBIIongrid[gridDBII,btype],  DBII_gns[btype],DBII_std[btype])
                                                                      -(@cdfNorm(DBIIongrid[gridDBII-1,btype],DBII_gns[btype],DBII_std[btype]))$(not sameas[gridDBII,'grid1']));
                                                                                                       

              areasingrid[gridDBII,btype]$(areasingrid[gridDBII,btype]<1 and not sameas[gridDBII,'grid1']) = 0;

              #  areasingrid['grid1',btype]   = 0; #GLM - nothing to allocate

              areasingrid['grid100',btype] = qArea_tot_ejudt[btype] * (1-@cdfNorm(DBIIongrid['grid99',btype],DBII_gns[btype],DBII_std[btype]));


            #STEP 4) Maximize profits on all lands, allocating land to bio, brk and omd.
              qArea_grid.lo[udfaldsrum,gridDBII,btype] = 0; #No negative areas allowed
              qArea_grid.fx['sko',gridDBII,'11']       = 0; #JMN Ingen skov på lavbund - bør være et kriterie i støttepuljen.
              qArea_grid.fx['sko',gridDBII,'11_high']  = 0; #    Ingen skov på lavbund
              qArea_grid.fx['GLM','grid1',btype]       = areasingrid['grid1',btype];
              qArea_grid.fx['GLM',gridDBII,btype]$(not sameas[gridDBII,'grid1']) = 0;
            #STEP 5) Hand-held bio-diversity
              #  qArea_grid.l['bio',gridDBII,btype]$((DBIIongrid[gridDBII,btype]<vAlts['bio',btype]) and (vAlts['bio',btype]> vAlts['sko',btype]) and not sameas[gridDBII,'grid1']) = areasingrid[gridDBII,btype]; #Initial value on BIO
                qArea_grid.l['bio',gridDBII,btype] = 0; qArea_grid.up['bio',gridDBII,btype] = inf; qArea_grid.lo['bio',gridDBII,btype] = 0;  #Resetter bio
                qArea_grid.l['bio',gridDBII,btype]$((DBIIongrid[gridDBII,btype]<vAlts['bio',btype]) and not sameas[gridDBII,'grid1']) = areasingrid[gridDBII,btype]; #Initial value on BIO
                bioarea_ite = 0;
                bioarea_ite_lagged = 0;
                LOOP(gridDBII,
                  bioarea_ite = bioarea_ite + sum(btype,qArea_grid.l['bio',gridDBII,btype]);
                  bioarea_ite_lagged$(not (sameas[gridDBII,'grid1'] or sameas[gridDBII,'grid2']))
                              = bioarea_ite_lagged + sum(btype,qArea_grid.l['bio',gridDBII-1,btype]); #Den her ville starte på 1, hvis ikke 1 var reserveret til GLM allerede.

                  #Når vi overskrider 100 000 grænsen tildeles de sidste hektar proportionalt med hvor meget areal, der ligger for btypen. 
                  qArea_grid.fx['bio',gridDBII,btype]$(bioarea_ite>100000/scaleha and bioarea_ite_lagged<100000/scaleha)
                     = (100000/scaleha - bioarea_ite_lagged) * areasingrid[gridDBII,btype]/sum(btype_a, areasingrid[gridDBII,btype_a]);

                  #Efter grænsen på 100 000 er overskredet sættes alt til 0.
                  qArea_grid.fx['bio',gridDBII,btype]$(bioarea_ite>100000/scaleha and bioarea_ite_lagged>=100000/scaleha) = 0; 
                  );

                qArea_grid.fx['bio',gridDBII,btype]$(qArea_grid.l['bio',gridDBII,btype]<>0) = qArea_grid.l['bio',gridDBII,btype];
                Solve M_endoland using LP maximizing vProfit;

                qArea_grid.fx['sko',gridDBII,btype]$(not sameas[gridDBii,'grid1'] and (qArea_grid.l['sko',gridDBII,btype]<100) and (qArea_grid.l['sko',gridDBII-1,btype]=0) and (qArea_grid.l['sko',gridDBII+1,btype]=0)) = 0;
                qArea_grid.fx['omd',gridDBII,btype]$(not sameas[gridDBii,'grid1'] and (qArea_grid.l['omd',gridDBII,btype]<100) and (qArea_grid.l['omd',gridDBII-1,btype]=0) and (qArea_grid.l['omd',gridDBII+1,btype]=0)) = 0;
                Solve M_endoland using LP maximizing vProfit;
       
              );

  #UDSKRIVNING I UDTAGNINGSPARAMETRE. BÅDE DE DER BRUGES I UDTAGNINGSFUNKTIONEN OG TIL AFRAPPORTERING
    areasingrid_allite['{grid}','{gridCO2tax}','{HaUdtag}','{lavm}',gridDBII,udfaldsrum,btype] = qArea_grid.l[udfaldsrum,gridDBII,btype];
    DBII_allite['{grid}','{gridCO2tax}','{HaUdtag}','{lavm}',gridDBII,btype]                 = (DBIIongrid[gridDBII,btype]-ha_stoette-optionsvaerdi) * qArea_grid.l['omd',gridDBII,btype];

    areasingrid_allite_sumbtype['{grid}','{gridCO2tax}','{HaUdtag}','{lavm}',gridDBII,udfaldsrum] = sum(btype, areasingrid_allite['{grid}','{gridCO2tax}','{HaUdtag}','{lavm}',gridDBII,udfaldsrum,btype]);
    vDBII_allite_sumbtype['{grid}','{gridCO2tax}','{HaUdtag}','{lavm}',gridDBII] = sum(btype, DBII_allite['{grid}','{gridCO2tax}','{HaUdtag}','{lavm}',gridDBII,btype]);

    #Aflæsning af DBII på grid for givent modelsetup  
    DBII_ongrid_allite_xhastoette['{grid}','{gridCO2tax}','{HaUdtag}','{lavm}',gridDBII,btype] = DBIIongrid[gridDBII,btype]-ha_stoette-optionsvaerdi;


    DBIImarg_iomdrift['{grid}','{gridCO2tax}','{HaUdtag}','{lavm}',btype]    = sum(gridDBII$((areasingrid_allite['{grid}','{gridCO2tax}','{HaUdtag}','{lavm}',gridDBII,'omd',btype]=0) and (areasingrid_allite['{grid}','{gridCO2tax}','{HaUdtag}','{lavm}',gridDBII+1,'omd',btype]))
                                                                              , DBII_ongrid_allite_xhastoette['{grid}','{gridCO2tax}','{HaUdtag}','{lavm}',gridDBII,btype]); 


    DBIImarg_iomdrift_summminbtype['{grid}','{gridCO2tax}','{HaUdtag}','{lavm}'] = smin(btype, DBIImarg_iomdrift['{grid}','{gridCO2tax}','{HaUdtag}','{lavm}',btype]);


    ChangeInDBIIperha['{grid}','{gridCO2tax}','{HaUdtag}','{lavm}'] = -{grid}/1000; 
 
    #Samlet udtag inkl. baseline udtag
    udtag['{grid}','{gridCO2tax}','{HaUdtag}','{lavm}',btype] = qArea_tot_udtbase[btype] + qArea.l['brk',btype] + qArea.l['bio',btype] + qArea.l['sko',btype] + qArea.l['glm',btype]
                                                               +qAreaskovfragnsjord[btype];


    #Samlet udtag eksl. baseline udtag fordelt på alternativer
    udtag_udf['{grid}','{gridCO2tax}','{HaUdtag}','{lavm}',udfaldsrum,btype] = qArea.l[udfaldsrum,btype] + qAreaskovfragnsjord[btype]$(sameas[udfaldsrum,'sko']);
    udtag_udf_sumbtype['{grid}','{gridCO2tax}','{HaUdtag}','{lavm}',udfaldsrum] = sum(btype,udtag_udf['{grid}','{gridCO2tax}','{HaUdtag}','{lavm}',udfaldsrum,btype]);
    permanentgraestilskov_udf['{grid}','{gridCO2tax}','{HaUdtag}','{lavm}']  = qArea_skovfrapermanentgraes.l;

    #Samlet DBII i omdrift
    vDBII_iomdrift['{grid}','{gridCO2tax}','{HaUdtag}','{lavm}',btype]       =  sum(gridDBII, (DBIIongrid[gridDBII,btype]-ha_stoette-optionsvaerdi) * qArea_grid.l['omd',gridDBII,btype]);
    vDBII_iomdrift_total['{grid}','{gridCO2tax}','{HaUdtag}','{lavm}']       =  sum(btype, vDBII_iomdrift['{grid}','{gridCO2tax}','{HaUdtag}','{lavm}',btype]);  

    #Produktivitetsmål 
    produktion_perhaiomdrift['{grid}','{gridCO2tax}','{HaUdtag}','{lavm}'] = sum((gridDBII,btype), (DBIIongrid[gridDBII,btype]-ha_stoette-optionsvaerdi + ha_afgift + c_struct_perha) * qArea_grid.l['omd',gridDBII,btype])/sum((gridDBII,btype), qArea_grid.l['omd',gridDBII,btype]);
    fproduktion_perhaiomdrift['{grid}','{gridCO2tax}','{HaUdtag}','{lavm}']= produktion_perhaiomdrift['{grid}','{gridCO2tax}','{HaUdtag}','{lavm}']/produktion_perhaiomdrift['0','0','35000','0']; #Indekserer ift. baseline


    AarligKulstof['{grid}','{gridCO2tax}','{HaUdtag}','{lavm}',t]            = sum(btype, CO2perhaskov[btype,t]*udtag_udf['{grid}','{gridCO2tax}','{HaUdtag}','{lavm}','sko',btype]);
    vAlts_atgrid['{grid}','{gridCO2tax}','{HaUdtag}','{lavm}',alt,btype]     = vAlts[alt,btype];

    #Samlet afkast pÃ¥ skov beregnes. Der omregnes til engangstilskud
      AfkastTilskov['{gridCO2tax}',btypeH]           = sum(t$(npv_periods[t]), 1/(1+rDisk[t])**(t.val-t1.val) * {gridCO2tax}*inf_factor['2023']/scale_value * CO2perhaskov[btypeH,t]); # vAlts['sko',btypeH]  + 31937/scale_value + 5500/scale_value - 7000/scale_value; #
      AfkastTilskov['{gridCO2tax}',btypeL]           = sum(t$(npv_periods[t]), 1/(1+rDisk[t])**(t.val-t1.val) * {gridCO2tax}*inf_factor['2023']/scale_value * CO2perhaskov[btypeL,t]); # vAlts['sko',btypeL]  + 39776/scale_value + 5500/scale_value - 7000/scale_value;

    #Test af at vi ikke taber nogle arealer. Af en eller anden grund taber vi et par hektar - selv når jeg tager højde for at arealer på grids mindre end 1 sættes til nul: areasingrid[gridDBII,btype]$(areasingrid[gridDBII,btype]<1 and not sameas[gridDBII,'grid1']) = 0;
      #Da det kun er et par hektar lever vi med det...
      LOOP(btype, 
        tjek = qArea_tot_ejudtbase[btype] - sum(udfaldsrum, qArea.l[udfaldsrum,btype]) - UdtagLavbund[btype] - UdtagSolceller[btype] - qAreaskovfragnsjord[btype]; 
       ABORT$(abs(tjek)>20) tjek, "Der tabes mere end 20 hektar undervejs i løsningen af LP og/eller indledende manøvrer";
       );

    $ENDFOR2
  $ENDFOR1
$ENDFOR 

#Tjek at alt skov i højtilskudsscenarie summer til 250 000 hektar 
tjek = udtag_udf_sumbtype['0','750','35000','1','sko'] + permanentgraestilskov_udf['0','750','35000','1'];
abort$(tjek>250010 or tjek<249990) tjek, "Der bliver ikke udtaget 250 000 hektar i scenarie med højest mulige tilskud til skov - overvej om det er med vilje, eller en fejl."; #Vi tillader en tolerance på 10 ha.

set hoejlav/hoj,lav/;
  PARAMETER udtag_ops[gridtax,hoejlav,haudtag,lavbundsmodel,udfaldsrum], lagretkulstof[gridtax,btype,haudtag,lavbundsmodel], lagretkulstof_hoejlav[gridtax,hoejlav,haudtag,lavbundsmodel];
  
  udtag_ops[gridtax,'hoj',haudtag,lavbundsmodel,udfaldsrum] = sum(btypeH, udtag_udf['0',gridtax,haudtag,lavbundsmodel,udfaldsrum, btypeH]);
  udtag_ops[gridtax,'lav',haudtag,lavbundsmodel,udfaldsrum]  = sum(btypeL, udtag_udf['0',gridtax,haudtag,lavbundsmodel,udfaldsrum, btypeL]);
  
  lagretkulstof_hoejlav[gridtax,'hoj',haudtag,lavbundsmodel] = sum(btypeH, sum(t$(npv_periods[t]), CO2perhaskov[btypeH,t]*udtag_udf['0',gridtax,haudtag,lavbundsmodel,'sko', btypeH]))/(2099-2018);
  lagretkulstof_hoejlav[gridtax,'lav',haudtag,lavbundsmodel] = sum(btypeL, sum(t$(npv_periods[t]), CO2perhaskov[btypeL,t]*udtag_udf['0',gridtax,haudtag,lavbundsmodel,'sko', btypeL]))/(2099-2018);

#Skov tilskud omregnet fra årligt tilskud til tilskud af forskellige perioder
  set tilskudslaengde /laengde1*laengde101/; #Vi beregner tilskudslængder fra 1 op til 101 perioder 
  alias(tilskudslaengde,tilskudslaengde_a); #Til det skal bruges et alias af settet tilskudsperioder

  $PGROUP PGROUP_skovtilskud
            vAlts_sko_ekshastoette[btype]                         "Værdien af skov, fratrukket løbende hektar støtte"
            kapitaliseringsfaktor[tilskudslaengde]                "Kapitaliseringsfaktor v. forskellige længder af tilskud"
            SkovTilskud[tilskudslaengde,btype]                    "Løbende tilskudssats ved tilskuddet givet af varierende længde"
            ;
  vAlts_sko_ekshastoette[btype] = vAlts['sko',btype] - ha_stoette;     #Trækker hektar støtte fra løbende værdi 
  vAlts_sko_ekshastoette[btype] = vAlts_sko_ekshastoette[btype]/npv_f; #Regner tilbage til en 81 års diskonteringsperiode, i.e. fuld udbetaling år 1 

  #Loop, der beregner kapitaliseringsfaktor for varierende længde tilskudsgivning
  LOOP(tilskudslaengde,
   kapitaliseringsfaktor[tilskudslaengde] = sum(tilskudslaengde_a$(ord(tilskudslaengde_a) <=ord(tilskudslaengde)), 1/((1+rDisk['2019'])**(ord(tilskudslaengde) - ord(tilskudslaengde_a))));
    );

  #Beregning af tilskudsstørrelse for varierende tilskudslængde 
  SkovTilskud[tilskudslaengde,btype] = kapitaliseringsfaktor[tilskudslaengde] * vAlts_sko_ekshastoette[btype];


#====================================================================================================================================================================================#
# Laver opslagsparameter til teknisk potentiale for skov -AKB: SKAL OPDATERES MED GNS. SKOV!!!!
#====================================================================================================================================================================================#

vAlts['sko',btype] = vAlts['sko',btype] -2;

adj_vAlts_var.l = 2;

#Gider kun lave griddet op til 1000, da det er det der er relevant
$FOR {grid} in ['0']: #,'100','200','300','400','500','600','700','800','900','1000']: #,'1100','1200','1300','1400','1500','1600','1700','1800','1900','2000','2100','2200','2300','2400','2500','2600','2700','2800','2900','3000','3100','3200','3300','3400','3500','3600','3700','3800','3900','4000','4100','4200','4300','4400','4500','4600','4700','4800','4900','5000','5100','5200','5300','5400','5500','5600','5700','5800','5900','6000']:
   $FOR1 {HaUdtag},{lavm} in [('35000','1'),('70000','1'),('70000','2')]:

    #Start by unfixing everything
    qArea_grid.lo[udfaldsrum,gridDBII,btype] = 0; qArea_grid.up[udfaldsrum,gridDBII,btype] = inf;
   
    #Ha-afgift sættes og gns. DBII beregnes 
    ha_afgift                   = {grid}/scale_value;


    
    DBII_gns[btype]             = DBII_gns_base[btype] + ha_stoette + optionsvaerdi - ha_afgift $IF {lavm}==2: - 1.8$( (sameas[btype,'11'] or sameas[btype,'11_high'])) $ENDIF;
    DBII_atgrid['{grid}',btype] = DBII_gns[btype];
    #  cutoff_GLM.l                = cutoff_GLM_parm - ha_afgift;


  #Opdaterer arealer med evt. lavbund (og solceller, når de kommer )
  UdtagLavbund[btype]    =  0.42 * HaRand['{HaUdtag}','{lavm}']*qArea_tot_ejudtbase[btype]$(btypexlav[btype])/sum(btypexlav_a, qArea_tot_ejudtbase[btypeXlav_a])
                          + 0.42 * HaHoejV['{HaUdtag}','{lavm}']$(sameas[btype,'11_high'])
                          + 0.42 * HaLavV['{HaUdtag}','{lavm}']$(sameas[btype,'11']); 

  #Solceller
   UdtagSolceller[btype] = 0;
   $IF {lavm} !=0:  UdtagSolceller[btype] = qLandSolceller_tot * qArea_tot_ejudtbase[btype]$(btypexlav[btype])/sum(btypexlav_a, qArea_tot_ejudtbase[btypeXlav_a]); $ENDIF

  qArea_tot_ejudt[btype] =  qArea_tot_ejudtbase[btype] - UdtagLavbund[btype] - UdtagSolceller[btype];
  loop(btype, 
      tjek = qArea_tot_ejudt[btype];
      ABORT$(tjek < 0) tjek, "Udtag giver negative arealer - juster hvordan arealer udtages i ovenstående kode.";
      );

  #Skov - nulstiller evt. udtag fra gnsjord
    qAreaskovfragnsjord_tot = 0;


  #GLM cut-off beregnes efter arealer er justerede. Det bør ændres til at GLM er 4 pct. af omdrift. Ha' en god dag.
   @SOLVE(M_calculateGLM); 
   cutoff_GLM_atgrid['{grid}'] = cutoff_GLM.l;
  
  
    #Ok, indtil videre antages ingen rabatter.
    #  $IF {lavm}==2: vAlts[alt,btypelav] = vAlts_base[alt,btypelav] - 1.8*0.5; $ENDIF #Halvdelen af afgiften kan undgås ved ikke at dyrke jorden...
    #  $IF {lavm}==2: vAlts[alt,btypelav] = vAlts_base[alt,btypelav] - 1.8*0.5; $ENDIF #Halvdelen af afgiften kan undgås ved ikke at dyrke jorden...
    #  $IF {lavm}!=2: vAlts[alt,btypelav] = vAlts_base[alt,btypelav]; $ENDIF

 #STEP 2) Arealet over cut-off inddeles i et grid (indtil videre 100-steps grid). Arealet imellem cut-off og 3 standardafvigelser (så vi er langt ude på fordelingen)

    loop(gridDBII,
      DBIIongrid[gridDBII,btype] = (cutoff_GLM.l + (8.5*smax(btype_a,DBII_std[btype_a]))*(ord(gridDBII)-1)/(card(gridDBII)-1));
       );

  #STEP 3) Compute the areas in each grid
    areasingrid[gridDBII,btype] = qArea_tot_ejudt[btype]*  (@cdfNorm(DBIIongrid[gridDBII,btype],DBII_gns[btype],DBII_std[btype])
                                                               -(@cdfNorm(DBIIongrid[gridDBII-1,btype],DBII_gns[btype],DBII_std[btype]))$(not sameas[gridDBII,'grid1']));
                                                                                             

    areasingrid[gridDBII,btype]$(areasingrid[gridDBII,btype]<1 and not sameas[gridDBII,'grid1']) = 0;

    #  areasingrid['grid1',btype]   = 0; #GLM - nothing to allocate

    areasingrid['grid100',btype] = qArea_tot_ejudt[btype] * (1-@cdfNorm(DBIIongrid['grid99',btype],DBII_gns[btype],DBII_std[btype]));


  #STEP 4) Maximize profits on all lands, allocating land to bio, brk and omd.
    qArea_grid.lo[udfaldsrum,gridDBII,btype] = 0; #No negative areas allowed
    qArea_grid.fx['sko',gridDBII,'11']       = 0; #JMN Ingen skov på lavbund - bør være et kriterie i støttepuljen.
    qArea_grid.fx['sko',gridDBII,'11_high']  = 0; #    Ingen skov på lavbund
    qArea_grid.fx['GLM','grid1',btype]       = areasingrid['grid1',btype];
    qArea_grid.fx['GLM',gridDBII,btype]$(not sameas[gridDBII,'grid1']) = 0;

#STEP 5) Hand-held biodiversity 
    #  qArea_grid.l['bio',gridDBII,btype]$((DBIIongrid[gridDBII,btype]<vAlts['bio',btype]) and (vAlts['bio',btype]> vAlts['sko',btype]) and not sameas[gridDBII,'grid1']) = areasingrid[gridDBII,btype]; #Initial value on BIO
    qArea_grid.l['bio',gridDBII,btype] = 0; qArea_grid.up['bio',gridDBII,btype] = inf; qArea_grid.lo['bio',gridDBII,btype] = 0;  #Resetter bio
    qArea_grid.l['bio',gridDBII,btype]$((DBIIongrid[gridDBII,btype]<vAlts['bio',btype]) and not sameas[gridDBII,'grid1']) = areasingrid[gridDBII,btype]; #Initial value on BIO
    bioarea_ite = 0;
    bioarea_ite_lagged = 0;
    LOOP(gridDBII,
      bioarea_ite = bioarea_ite + sum(btype,qArea_grid.l['bio',gridDBII,btype]);
      bioarea_ite_lagged$(not (sameas[gridDBII,'grid1'] or sameas[gridDBII,'grid2']))
                  = bioarea_ite_lagged + sum(btype,qArea_grid.l['bio',gridDBII-1,btype]); #Den her ville starte på 1, hvis ikke 1 var reserveret til GLM allerede.

      #Når vi overskrider 100 000 grænsen tildeles de sidste hektar proportionalt med hvor meget areal, der ligger for btypen. 
      qArea_grid.fx['bio',gridDBII,btype]$(bioarea_ite>100000/scaleha and bioarea_ite_lagged<100000/scaleha)
         = (100000/scaleha - bioarea_ite_lagged) * areasingrid[gridDBII,btype]/sum(btype_a, areasingrid[gridDBII,btype_a]);

      #Efter grænsen på 100 000 er overskredet sættes alt til 0.
      qArea_grid.fx['bio',gridDBII,btype]$(bioarea_ite>100000/scaleha and bioarea_ite_lagged>=100000/scaleha) = 0; 
      );

    qArea_grid.fx['bio',gridDBII,btype]$(qArea_grid.l['bio',gridDBII,btype]<>0) = qArea_grid.l['bio',gridDBII,btype];

    Solve M_opslagskov using NLP maximizing vProfit;

    #SKOV FRA GENNEMSNITLIG JORD
      qAreaskovfragnsjord_tot = sAreaskovfragnsjord * sum(btype, qArea.l['sko',btype]);

      #Vi regner kun skovscenarie, for mere end 1000 hektar skov...
      IF (qAreaskovfragnsjord_tot>1000,

        #Finder ud af hvor store arealer, der skal tages fra hver btype 
        qAreaskovfragnsjord[btype] = qAreaskovfragnsjord_tot * qArea_tot_ejudtbase[btype]$(btypexlav[btype])/sum(btypexlav_a, qArea_tot_ejudtbase[btypeXlav_a]);

        #Arealer fraregnes
        qArea_tot_ejudt[btype] =  qArea_tot_ejudtbase[btype] - UdtagLavbund[btype] - UdtagSolceller[btype] - qAreaskovfragnsjord[btype];

          loop(btype, 
          tjek = qArea_tot_ejudt[btype];
          ABORT$(tjek < 0) tjek, "Udtag giver negative arealer - juster hvordan arealer udtages i ovenstående kode.";
          );

        #NU KØRES HELE UDTAGNINGEN IGEN MEN MED GNS. SKOV SOM EN DEL AF UDTAGNINGEN
            #GLM cut-off beregnes efter arealer er justerede. Det bør ændres til at GLM er 4 pct. af omdrift. Ha' en god dag.
            @SOLVE(M_calculateGLM); 
            cutoff_GLM_atgrid['{grid}'] = cutoff_GLM.l;

            #STEP 2) Arealet over cut-off inddeles i et grid (indtil videre 100-steps grid). Arealet imellem cut-off og 3 standardafvigelser (så vi er langt ude på fordelingen)

              loop(gridDBII,
                DBIIongrid[gridDBII,btype] = (cutoff_GLM.l + (8.5*smax(btype_a,DBII_std[btype_a]))*(ord(gridDBII)-1)/(card(gridDBII)-1));
                 );

            #STEP 3) Compute the areas in each grid
              areasingrid[gridDBII,btype] = qArea_tot_ejudt[btype]*  (@cdfNorm(DBIIongrid[gridDBII,btype],  DBII_gns[btype],DBII_std[btype])
                                                                    -(@cdfNorm(DBIIongrid[gridDBII-1,btype],DBII_gns[btype],DBII_std[btype]))$(not sameas[gridDBII,'grid1']));
                                                                                                       

              areasingrid[gridDBII,btype]$(areasingrid[gridDBII,btype]<1 and not sameas[gridDBII,'grid1']) = 0;

              #  areasingrid['grid1',btype]   = 0; #GLM - nothing to allocate

              areasingrid['grid100',btype] = qArea_tot_ejudt[btype] * (1-@cdfNorm(DBIIongrid['grid99',btype],DBII_gns[btype],DBII_std[btype]));


            #STEP 4) Maximize profits on all lands, allocating land to bio, brk and omd.
              qArea_grid.lo[udfaldsrum,gridDBII,btype] = 0; #No negative areas allowed
              qArea_grid.fx['sko',gridDBII,'11']       = 0; #JMN Ingen skov på lavbund - bør være et kriterie i støttepuljen.
              qArea_grid.fx['sko',gridDBII,'11_high']  = 0; #    Ingen skov på lavbund
              qArea_grid.fx['GLM','grid1',btype]       = areasingrid['grid1',btype];
              qArea_grid.fx['GLM',gridDBII,btype]$(not sameas[gridDBII,'grid1']) = 0;
            #STEP 5) Hand-held bio-diversity
              #  qArea_grid.l['bio',gridDBII,btype]$((DBIIongrid[gridDBII,btype]<vAlts['bio',btype]) and (vAlts['bio',btype]> vAlts['sko',btype]) and not sameas[gridDBII,'grid1']) = areasingrid[gridDBII,btype]; #Initial value on BIO
                qArea_grid.l['bio',gridDBII,btype] = 0; qArea_grid.up['bio',gridDBII,btype] = inf; qArea_grid.lo['bio',gridDBII,btype] = 0;  #Resetter bio
                qArea_grid.l['bio',gridDBII,btype]$((DBIIongrid[gridDBII,btype]<vAlts['bio',btype]) and not sameas[gridDBII,'grid1']) = areasingrid[gridDBII,btype]; #Initial value on BIO
                bioarea_ite = 0;
                bioarea_ite_lagged = 0;
                LOOP(gridDBII,
                  bioarea_ite = bioarea_ite + sum(btype,qArea_grid.l['bio',gridDBII,btype]);
                  bioarea_ite_lagged$(not (sameas[gridDBII,'grid1'] or sameas[gridDBII,'grid2']))
                              = bioarea_ite_lagged + sum(btype,qArea_grid.l['bio',gridDBII-1,btype]); #Den her ville starte på 1, hvis ikke 1 var reserveret til GLM allerede.

                  #Når vi overskrider 100 000 grænsen tildeles de sidste hektar proportionalt med hvor meget areal, der ligger for btypen. 
                  qArea_grid.fx['bio',gridDBII,btype]$(bioarea_ite>100000/scaleha and bioarea_ite_lagged<100000/scaleha)
                     = (100000/scaleha - bioarea_ite_lagged) * areasingrid[gridDBII,btype]/sum(btype_a, areasingrid[gridDBII,btype_a]);

                  #Efter grænsen på 100 000 er overskredet sættes alt til 0.
                  qArea_grid.fx['bio',gridDBII,btype]$(bioarea_ite>100000/scaleha and bioarea_ite_lagged>=100000/scaleha) = 0; 
                  );

                qArea_grid.fx['bio',gridDBII,btype]$(qArea_grid.l['bio',gridDBII,btype]<>0) = qArea_grid.l['bio',gridDBII,btype];
                Solve M_opslagskov using NLP maximizing vProfit;
                qArea_grid.fx['sko',gridDBII,btype]$(not sameas[gridDBii,'grid1'] and (qArea_grid.l['sko',gridDBII,btype]<100) and (qArea_grid.l['sko',gridDBII-1,btype]=0) and (qArea_grid.l['sko',gridDBII+1,btype]=0)) = 0;
                qArea_grid.fx['omd',gridDBII,btype]$(not sameas[gridDBii,'grid1'] and (qArea_grid.l['omd',gridDBII,btype]<100) and (qArea_grid.l['omd',gridDBII-1,btype]=0) and (qArea_grid.l['omd',gridDBII+1,btype]=0)) = 0;
                Solve M_endoland using LP maximizing vProfit;
         
              );
    
    #Vi kan nu regne tilbage til, hvad tilskuddet skal være eksl. 10 års hektarstøtte. Tilskuddet skal dog dække det negative DB, samt rejsningsomk.
    SkovTilskudOpslag250000['{grid}','{HaUdtag}','{lavm}',btype] 

      #Det der skal til for at udkonkurrere både dækningsbidrag, samt kilen imellem løbende uendelig hektarstøtte og 12-års hektarstøtte
      = vAlts_var.l['sko',btype] - ha_stoette_12aar -optionsvaerdi; # * npv_f - sum(t$(npv_periods[t]), 1/(1+rDisk[t])**(t.val-t1.val) * ha_stoette) + 32$(btypeH[btype]) + 40$(btypeL[btype]) + 5.5;

      #  @SOLVE(M_testy);
      #  cutoff_SKO.l[btype]$(cutoff_SKO.l[btype]<vAlts['brk',btype])    = vAlts['brk',btype];
      #  SkovTilskudOpslag250000['{grid}','{HaUdtag}','{lavm}',btype]     = cutoff_SKO.ljeg [btype];

  $ENDFOR1
$ENDFOR

  
#====================================================================================================================================================================================#
# KOBLING TIL RESTEN AF MODELLEN
#====================================================================================================================================================================================#

  $GROUP G_endolandlinks 
    NW_denom[grid,gridtax,t]  "Naraya-Watson-agtig vægtning i nævneren for den smooth udglatning af udtagningsfunktionen over griddet af hektarafgift"
    NW_nom[grid,gridtax,alt,btype,t]    "Naraya-Watson-agtig vægtning af udfaldet (hvor meget jord der udtages) i tælleren for den smooth udglatning af udtagningsfunktionen over griddet af hektarafgift"

    NW_denom_permg2sko[grid,gridtax,t]  "Naraya-Watson-agtig vægtning i nævneren for den smooth udglatning af udtagningsfunktionen over griddet af hektarafgift"
    NW_nom_permg2sko[grid,gridtax,t]    "Naraya-Watson-agtig vægtning af udfaldet (hvor meget jord der udtages) i tælleren for den smooth udglatning af udtagningsfunktionen over griddet af hektarafgift"


    vDBII_INPUT[t]                      "Input variabel i jordudtagninsfunktionen. Er lig CGE-modellens samlede DBII + et j-led, der i baseline tager forskellen imellem CGE-model og IFRO"
    vDBII_CGE[t]                        "Samlet DBII i CGE-modellen/GrønREFORMs landbrugsmodul"

    qLandUdtag[alt,btype,t]             "Jordudtag på tidspunkt t for alternativ alt og bedriftstype btype - benyttes pt. ikke"
    qLandUdtag_pot[alt,btype,gridtax,t] "Potentielt jordudtag på tidspunkt t for alt/btype/gridtax. Det potentielle udtag begrænses i nuværende af at skov ikke omlægges i et hug"
    qLandUdtag_pot_permg2sko[gridtax,t] ""

    qLandUdtag_tot[t]                   "Samlet jordudtag ved tidspunkt t for et givent samlet dækningsbidrag i CGE-modellen"
    qLandSko[t]                         "Skovareal udover baseline målt i mio. ha."      
    qLandSko_fraomd[t]                  "Skovareal på omlagte omdriftsarealer, mio. ha"
    qLandSko_fraper[t]                  "Skovareal på omlagte permanente græsarealer, mio. ha"     
    qLandSko_pot[t]                     "Potentielt skovareal, skæres ved 2050 pt. og der lægges en øvre grænse på 250 000 ha ind"
    qLandSko_pot_inp[t]                 "Potentielt skovareal, skæres ved 2050 pt. og der lægges en øvre grænse på 250 000 ha ind"
    qLandSko_pot_hoej[t]                ""
    qLandSko_pot_lav[t]                 ""
    qLandBRK[t]                         "Samlet braklagt areal målt i mio. ha."    
    qLandBRK_pot_base[t]                "Potentielt braklagt areal målt for en given ændring i DB, men uden negativ afgift på skov. Variablen benyttes, da skovrejsning er træg og det forventes at nogle arealer braklægges, før det kan svare sig at rejse skov på dem "
    jEndoLand[t]                        "J-led, der sørger for at jord i omdrift ikke ændrer sig i baseline fra ekstern fremskrivning"
    jvDBII_CGE[t]                       "J-led, der sørger for at jord i omdrift ikke ændrer sig i baseline fra ekstern fremskrivning"
    jLand_nonproductive[plant_sectors,landallocation,t] "J-led, der sørger for at jord i omdrift ikke ændrer sig i baseline fra ekstern fremskrivning"
    jLUC12_endoland[land12_s,land12_r,t]        ""

 
    p_min_skovrejs                      "Mindste pris på skovrejsning, vurdering fra MST og MIM. Målt i tkr per ha"
    xrejst[t]                           "Skov rejst imellem 2023-2030 målt i kha. ved omkostningsminimering"
    maxrejs[t]                          "Skov rejst imellem 2023-2030 mål i mio. ha."
    maxrejstot                          "Maksimal skovrejsning (250 000 ha)"
    maxrejs2030                         "Maksimal skovrejsning frem til 2030 på akkumuleret 70 000 ha"
    qLandSko2030                        "Valgt skovrejsning i 2030"
    inputk[t]                           ""

    #OPSLAG I UDTAG FOR AT FINDE HEKTAR AF HVER TYPE
      vDBII_maalsoeg[t] ""
      NW_denom_maal[grid,gridtax,alt,btype,t] ""
      NW_nom_maal[grid,gridtax,alt,btype,t] ""
      qLandUdtag_maalsoeg[alt,btype,gridtax,t] ""
      qLandSko_hoej[t] ""
      qLandSko_lav[t] ""

      qF5_AFF_baseline[skmodel,joe07,spec_type,acl,t] ""


    #Lavbund
      qLavEjUdtaget_hoej[t] ""
      qLavEjUdtaget_lav[t]  ""
      qLavEjUdtaget_rand[t] ""
      qLavUdtaget_hoej[t] ""
      qLavUdtaget_lav[t]  ""
      qLavUdtaget_rand[t] ""
      qLavEjUdtaget[t] ""
      qLavUdtaget[t] ""

    #Solceller
      qLandSolceller[t] ""

  #Landvind
      qLandLandvind[t] ""

    #Produktivitet
      TFPPlant_baseline_zeroshockagr[plant_sectors,t] ""
      qLandUdtag_pot_tot[t]               ""
      fProduktion_perhaiomdrift_CGE[gridtax,t] ""

      NW_nom_produktivitet[grid,gridtax,t] ""
      sUdtaget_af_pot[t] ""
      qLandUdtag_tot_zeroshock_agr[t] ""

    #Marg DBII 
      margDBII_2CGE_pot[gridtax,t] "" 
      margDBII_2CGE_act[t] ""
      NW_nom_margDBII[grid,gridtax,t] ""
      margDBII_2CGE_act_zeroshockagr[t] ""

    #Change DBII 
      ChangeDBII_pot[gridtax,t] "" 
      NW_nom_changeDBII[grid,gridtax,t] ""
      ChangeDBII_2CGE_act[t] ""
      ChangeDBII_2CGE_act_zeroshockagr[t] ""


  ;


  $PGROUP G_Pendolandlinks #Hældningsparametre i smooth min/max-funktionerne
    parm_brk ""
    parm_sko_2030 ""
    parm_sko ""
    KF22_skovrejsning_GSR[t] "Skovrejsning KF22, som det fremgår i GSR-korrespondance"
  ;

  #Til skovrejsning
    qF5_AFF_baseline.l[skmodel,joe07,spec_type,acl,t] = qF5_AFF.l[skmodel,joe07,spec_type,acl,t];

    KF22_skovrejsning_GSR['2025'] = 3.5; #Jf. mail fra MIM d.9.6.2023 
    KF22_skovrejsning_GSR['2026'] = 3.5;
    KF22_skovrejsning_GSR['2027'] = 3.5;
    KF22_skovrejsning_GSR['2028'] = 3.3;
    KF22_skovrejsning_GSR['2029'] = 3.4;
    KF22_skovrejsning_GSR['2030'] = 1.7;

    parm_sko      = 150;
    parm_brk      = 100;
    parm_sko_2030 = 100;

    inputk.l[tx0]    = 0.1;
    p_min_skovrejs.l = 18;
    maxrejstot.l     = 0.25; #Max 250 000 ha
    maxrejs2030.l    = 0.0679; #- KF22_skovrejsning_GSR['2030']/1000; #Max 67 900 ha frem til 2030 (inkl. det der ligger i KF)

  #Solceller 
    qLandSolceller.l['2025'] = qLandSolceller_tot*1/6;
    qLandSolceller.l['2026'] = qLandSolceller_tot*2/6;
    qLandSolceller.l['2027'] = qLandSolceller_tot*3/6;
    qLandSolceller.l['2028'] = qLandSolceller_tot*4/6;
    qLandSolceller.l['2029'] = qLandSolceller_tot*5/6;
    qLandSolceller.l['2030'] = qLandSolceller_tot*6/6;
    qLandSolceller.l[t]$(t.val >2030) = qLandSolceller_tot;

  #Landvind 
    qLandLandvind.l['2024'] = 1/7 * 23810/10**6;
    qLandLandvind.l['2025'] = 2/7 * 23810/10**6;
    qLandLandvind.l['2026'] = 3/7 * 23810/10**6;
    qLandLandvind.l['2027'] = 4/7 * 23810/10**6;
    qLandLandvind.l['2028'] = 5/7 * 23810/10**6;
    qLandLandvind.l['2029'] = 6/7 * 23810/10**6;
    qLandLandvind.l['2030'] = 7/7 * 23810/10**6;
    qLandLandvind.l[t]$(t.val >2030) = qLandLandvind.l['2030'];
    #Sætter ækvivalent årlig afkast på jorder, der kompenseres 
  
    pReturnPerHa_alt_landallocation.l['skov',plant_sectors,t]             =  1.51625745666522;   # 86 485 tusind kroner omregnet til løbende afkast med diskontering i partiel model. (Se skovtilskudssats, april 2024.xlsx)
    pReturnPerHa_alt_landallocation.l['VaadLagtLavbund',plant_sectors,t]  =  1.41882907389418;   # 57 før, nu 100 tusind omregnet til løbende afkast med modellens diskontering i partiel model, hvor modellen skal ramme 57 i 2025.
    pReturnPerHa_alt_landallocation.l['Solceller',plant_sectors,t]        = 3800*7.45/1.37/1000; # 3800 EUR per MW i gns. 2020-2030, gange 7,45 for EUR og div 1,37 for per ha., divideret med 1000 for at få i 1000 kroner per ha. (=Mia. kr. per mio. ha)																		#Det her giver 20 700 per ha
    pReturnPerHa_alt_landallocation.l['Landvind',plant_sectors,t]         = 6.5;




  #Initialværdier
  vDBII_CGE.l[t] = sum(plant_sectors,vDBII.l[plant_sectors,t])*10**6; 

  #Dummies
    d1UdtagOptions[gridtax,HaUdtag,lavbundsmodel] = NO; d1OptionsUdtag_xGrid[HaUdtag,lavbundsmodel] = NO; d1currentgrid[gridtax] = NO;

    #OLD BASELINE (KF24)
    # d1UdtagOptions['0','35000','0'] = yes; #Baseline er ingen støtte til skov, ingen lavbundsudtag - og ingen solceller i før-korrigeret baseline
    # d1OptionsUdtag_xGrid[HaUdtag,lavbundsmodel] = yes$(sum(gridtax, d1UdtagOptions[gridtax,HaUdtag,lavbundsmodel]));
    # d1currentgrid['0']              = yes;
  
    #KF25-BASELINE
    d1UdtagOptions[gridtax,HaUdtag,lavbundsmodel] = no;  #Sætter til "No" for alle elementer, just in case 
    d1OptionsUdtag_xGrid[HaUdtag,lavbundsmodel]   = no;
    d1UdtagOptions['0','70000','1']               = yes; #Første indgang er negativ afgift på skov. Anden indgang er antal hektar lavbund udtaget (i baseline er det 35000). Tredje indgang er hvilken lavbundsudtagsmodel (1 = støtte/komp)
    d1UdtagOptions['750','70000','1']               = yes; #Første indgang er negativ afgift på skov. Anden indgang er antal hektar lavbund udtaget (i baseline er det 35000). Tredje indgang er hvilken lavbundsudtagsmodel (1 = støtte/komp)
    d1OptionsUdtag_xGrid[HaUdtag,lavbundsmodel]   = yes$(sum(gridtax, d1UdtagOptions[gridtax,HaUdtag,lavbundsmodel]));
    d1currentgrid['750']              = yes;
  

    d1qLUC12['crop_u6','forest',tx0] = yes; #Åbner for at skovrejsning fra mineraljord kan være muligt i alle år. 


  $GROUP G_endoland_calib_should_not_change 
    qLand$(not t.val=2099)
    qLand_Nonproductive
    qLUC12 
  ;

  @Save(G_endoland_calib_should_not_change);
  

$BLOCK B_endolandlinks 
  #----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
  # Kernen af udtagningsfunktionen, det potentielle udtag, givet DBII
  #----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#  
   
    #Beregning af samlet DBII i CGE-modellen
    E_vDBII_CGE[t]$(tx0[t])..                              vDBII_CGE[t] =E= sum(plant_sectors$(not sameas[plant_sectors,'01020']), vDBII[plant_sectors,t])*10**6; #Omregner til tkr. så det er samme enhed som i jordudtagsmodulet

    #Beregning af input i jordudtagsfunktionen. = CGE-model + jLed, der tager forskel i baseline
    E_vDBII_INPUT[t]$(tx0E[t])..                            vDBII_INPUT[t] =E= vDBII_CGE[t+1] + jvDBII_CGE[t];

    #Vægt i nævneren jordudtagsfunktionens "glidende gennemsnit" over grid af hektarafgift for given samlet vDBII_INPUT
   E_NW_denom[grid,gridtax,HaUdtag,Lavbundsmodel,t]$(tx0E[t] and d1UdtagOptions[gridtax,HaUdtag,lavbundsmodel])..  
      NW_denom[grid,gridtax,t] =E=  @pdfNorm(vDBII_INPUT[t], vDBII_iomdrift_total[grid,gridtax,HaUdtag,lavbundsmodel], 100000);

    #Væg i tælleren af jordudtagsfunktionen "glidende gennemsnit" over grid af hektarafgift for et givent samlet vDBII_INPUT
    E_NW_nom[grid,gridtax,alt,btype,HaUdtag,lavbundsmodel,t]$(tx0E[t] and d1UdtagOptions[gridtax,HaUdtag,lavbundsmodel])..   
      NW_nom[grid,gridtax,alt,btype,t]   =E= udtag_udf[grid,gridtax,HaUdtag,lavbundsmodel,alt,btype] * @pdfNorm(vDBII_INPUT[t], vDBII_iomdrift_total[grid,gridtax,HaUdtag,lavbundsmodel], 100000);
   
    #Jordudtag til en given allokering for en given bedriftstype bestemt ved det "glidende gennemsnit" over grid af hektarafgift.
    E_qLandUdtag_pot[alt,btype,gridtax,HaUdtag,lavbundsmodel,t]$(tx0E[t] and d1UdtagOptions[gridtax,HaUdtag,lavbundsmodel])..
      qLandUdtag_pot[alt,btype,gridtax,t] * sum(grid, NW_denom[grid,gridtax,t]) 
        =E= sum(grid, NW_nom[grid,gridtax,alt,btype,t]);#/sum(grid, NW_denom[grid,gridtax,alt,btype,t]);

    #  E_qLandUdtag_pot_tEnd[alt,btype,gridtax,HaUd]$(tx0E[t] and d1UdtagOptions[gridtax,HaUdtag,lavbundsmodel])..
    #    qLandUdtag_pot[alt,btype,gridtax,t] =E= qLandUdtag_pot[alt,btype,gridtax,t-1];

    #Permanent græs til skov håndteres separat - overvej på sigt at det skal ind i settet "alt"
    E_NW_denom_permg2sko[grid,gridtax,HaUdtag,Lavbundsmodel,t]$(tx0E[t] and d1UdtagOptions[gridtax,HaUdtag,lavbundsmodel] and d1currentgrid[gridtax])..  
      NW_denom_permg2sko[grid,gridtax,t] =E=  @pdfNorm(vDBII_INPUT[t], vDBII_iomdrift_total[grid,gridtax,HaUdtag,lavbundsmodel], 100000);

    #Væg i tælleren af jordudtagsfunktionen "glidende gennemsnit" over grid af hektarafgift for et givent samlet vDBII_INPUT
    E_NW_nom_permg2sko[grid,gridtax,HaUdtag,lavbundsmodel,t]$(tx0E[t] and d1UdtagOptions[gridtax,HaUdtag,lavbundsmodel] and d1currentgrid[gridtax])..   
      NW_nom_permg2sko[grid,gridtax,t]   =E= permanentgraestilskov_udf[grid,gridtax,HaUdtag,lavbundsmodel] * @pdfNorm(vDBII_INPUT[t], vDBII_iomdrift_total[grid,gridtax,HaUdtag,lavbundsmodel], 100000);

    E_qLandUdtag_pot_permg2sko[gridtax,HaUdtag,lavbundsmodel,t]$(tx0E[t] and d1UdtagOptions[gridtax,HaUdtag,lavbundsmodel] and d1currentgrid[gridtax])..
      qLandUdtag_pot_permg2sko[gridtax,t] * sum(grid, NW_denom_permg2sko[grid,gridtax,t]) 
        =E= sum(grid, NW_nom_permg2sko[grid,gridtax,t]);


    #Vægt i tælleren af jordudtagsfunktionen "glidende gennemsnit" over grid af hektarafgift for et givent samlet vDBII_INPUT
    #  E_NW_nom_produktivitet[grid,gridtax,HaUdtag,lavbundsmodel,t]$(tx0E[t] and d1UdtagOptions[gridtax,HaUdtag,lavbundsmodel] and d1currentgrid[gridtax])..   
    #    NW_nom_produktivitet[grid,gridtax,t]   =E= fproduktion_perhaiomdrift[grid,gridtax,HaUdtag,lavbundsmodel] * @pdfNorm(vDBII_INPUT[t], vDBII_iomdrift_total[grid,gridtax,HaUdtag,lavbundsmodel], 100000);

    #  E_fProduktion_perhaiomdrift_CGE[gridtax,HaUdtag,lavbundsmodel,t]$(tx0E[t] and d1UdtagOptions[gridtax,HaUdtag,lavbundsmodel] and d1currentgrid[gridtax])..
    #    fProduktion_perhaiomdrift_CGE[gridtax,t] * sum(grid, NW_denom_permg2sko[grid,gridtax,t]) 
    #      =E= sum(grid, NW_nom_produktivitet[grid,gridtax,t]);

    #  E_fProduktion_perhaiomdrift_CGE_tEnd[gridtax,t]$(tEnd[t] and d1currentgrid[gridtax])..
    #    fProduktion_perhaiomdrift_CGE[gridtax,t] =E= fProduktion_perhaiomdrift_CGE[gridtax,t-1];


    # Vægt i tælleren af jordudtagsfunktionen "glidende gennemsnit" over grid af hektarafgift for et givent samlet vDBII_INPUT
    #  E_NW_nom_margDBII[grid,gridtax,HaUdtag,lavbundsmodel,t]$(tx0E[t] and d1UdtagOptions[gridtax,HaUdtag,lavbundsmodel] and d1currentgrid[gridtax])..   
    #    NW_nom_margDBII[grid,gridtax,t]   =E= DBIImarg_iomdrift_summminbtype[grid,gridtax,HaUdtag,lavbundsmodel] * @pdfNorm(vDBII_INPUT[t], vDBII_iomdrift_total[grid,gridtax,HaUdtag,lavbundsmodel], 100000);

    #  E_margDBII_2CGE_pot[gridtax,HaUdtag,lavbundsmodel,t]$(tx0E[t] and d1UdtagOptions[gridtax,HaUdtag,lavbundsmodel] and d1currentgrid[gridtax])..
    #    margDBII_2CGE_pot[gridtax,t] * sum(grid, NW_denom_permg2sko[grid,gridtax,t]) 
    #      =E= sum(grid, NW_nom_margDBII[grid,gridtax,t]);

    #  E_margDBII_2CGE_pot_tEnd[gridtax,t]$(tEnd[t] and d1currentgrid[gridtax])..
    #    margDBII_2CGE_pot[gridtax,t] =E= margDBII_2CGE_pot[gridtax,t-1];

    # Vægt i tælleren af jordudtagsfunktionen "glidende gennemsnit" over grid af hektarafgift for et givent samlet vDBII_INPUT
    E_NW_nom_changeDBII[grid,gridtax,HaUdtag,lavbundsmodel,t]$(tx0E[t] and d1UdtagOptions[gridtax,HaUdtag,lavbundsmodel])..   
      NW_nom_changeDBII[grid,gridtax,t]   =E= ChangeInDBIIperha[grid,gridtax,HaUdtag,lavbundsmodel] * @pdfNorm(vDBII_INPUT[t], vDBII_iomdrift_total[grid,gridtax,HaUdtag,lavbundsmodel], 100000);

    E_changeDBII[gridtax,HaUdtag,lavbundsmodel,t]$(tx0E[t] and d1UdtagOptions[gridtax,HaUdtag,lavbundsmodel])..
      ChangeDBII_pot[gridtax,t] * sum(grid, NW_denom[grid,gridtax,t]) 
        =E= sum(grid, NW_nom_changeDBII[grid,gridtax,t]);

    E_changeDBII_tEnd[gridtax,HaUdtag,lavbundsmodel,t]$(tEnd[t] and d1UdtagOptions[gridtax,HaUdtag,lavbundsmodel])..
      ChangeDBII_pot[gridtax,t] =E= ChangeDBII_pot[gridtax,t-1];

  #----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
  # Udtagning af LAVBUND
  #----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#  
  

    E_qLavEjUdtaget_hoej[t]$(tx0[t])..  qLavEjUdtaget_hoej[t] =E= (1-Effektandele[t]) * sum((HaUdtag,lavbundsmodel)$(d1OptionsUdtag_xGrid[HaUdtag,lavbundsmodel]), (HaHoejV[HaUdtag,lavbundsmodel] - HaHoejV['70000','1']));
    E_qLavEjUdtaget_lav[t]$(tx0[t])..   qLavEjUdtaget_lav[t]  =E= (1-Effektandele[t]) * sum((HaUdtag,lavbundsmodel)$(d1OptionsUdtag_xGrid[HaUdtag,lavbundsmodel]), (HaLavV[HaUdtag,lavbundsmodel]  - HaLavV['70000','1']));
    E_qLavEjUdtaget_rand[t]$(tx0[t])..  qLavEjUdtaget_rand[t] =E= (1-Effektandele[t]) * sum((HaUdtag,lavbundsmodel)$(d1OptionsUdtag_xGrid[HaUdtag,lavbundsmodel]), (HaRand[HaUdtag,lavbundsmodel]  - HaRand['70000','1']));

    E_qLavEjUdtaget[t]$(tx0[t])..     qLavEjUdtaget[t]        =E= qLavEjUdtaget_hoej[t] + qLavEjUdtaget_lav[t] + qLavEjUdtaget_rand[t];

    E_qLavUdtaget_hoej[t]$(tx0[t])..  qLavUdtaget_hoej[t]     =E= Effektandele[t] * sum((HaUdtag,lavbundsmodel)$(d1OptionsUdtag_xGrid[HaUdtag,lavbundsmodel]), (HaHoejV[HaUdtag,lavbundsmodel] - HaHoejV['70000','1']));
    E_qLavUdtaget_lav[t]$(tx0[t])..   qLavUdtaget_lav[t]      =E= Effektandele[t] * sum((HaUdtag,lavbundsmodel)$(d1OptionsUdtag_xGrid[HaUdtag,lavbundsmodel]), (HaLavV[HaUdtag,lavbundsmodel]  - HaLavV['70000','1']));
    E_qLavUdtaget_rand[t]$(tx0[t])..  qLavUdtaget_rand[t]     =E= Effektandele[t] * sum((HaUdtag,lavbundsmodel)$(d1OptionsUdtag_xGrid[HaUdtag,lavbundsmodel]), (HaRand[HaUdtag,lavbundsmodel]  - HaRand['70000','1']));
    
    E_qLavUdtagett[t]$(tx0[t])..           qLavUdtaget[t]     =E= qLavUdtaget_hoej[t] + qLavUdtaget_lav[t] + qLavUdtaget_rand[t];

    #Standard udtagningsfunktionen vil forsøge at udtage udtage det hele med det samme. Vi bruger derfor ovenstående til at modregne.

    E_qLUC_lavbund_crop_o12[t]$(tx0[t] and d1qLuc12['crop_o12','wetland',t]).. qLUC12['crop_o12','wetland',t]  =E= qLUC12_baseline['crop_o12','wetland',t] 
        + (qLavUdtaget_hoej[t] + qLavUdtaget_lav[t] - qLavUdtaget_hoej[t-1]-qLavUdtaget_lav[t-1])/0.78/1000;

    E_qLUC_lavbund_crop_6_12[t]$(tx0[t] and d1qLuc12['crop_6_12','wetland',t]).. qLUC12['crop_6_12','wetland',t]  =E= qLUC12_baseline['crop_6_12','wetland',t] 
        + (qLavUdtaget_hoej[t] + qLavUdtaget_lav[t] - qLavUdtaget_hoej[t-1]-qLavUdtaget_lav[t-1])/0.78/1000;

    E_qLUC_lavbund_grass_o12[t]$(tx0[t] and d1qLuc12['grass_o12','wetland',t]).. qLUC12['grass_o12','wetland',t]  =E= qLUC12_baseline['grass_o12','wetland',t] 
        + (qLavUdtaget_hoej[t] + qLavUdtaget_lav[t] - qLavUdtaget_hoej[t-1]-qLavUdtaget_lav[t-1])/0.78/1000;

    E_qLUC_lavbund_grass_6_12[t]$(tx0[t] and d1qLuc12['grass_6_12','wetland',t]).. qLUC12['grass_6_12','wetland',t]  =E= qLUC12_baseline['grass_6_12','wetland',t] 
        + (qLavUdtaget_hoej[t] + qLavUdtaget_lav[t] - qLavUdtaget_hoej[t-1]-qLavUdtaget_lav[t-1])/0.78/1000; 


     E_qLUC_lavbund_crop_u6[t]$(tx0[t] and d1qLuc12['crop_u6','wetland',t])..  
     qLUC12['crop_u6','Wetland',t] =E= qLUC12_baseline['crop_u6','Wetland',t] + (qLavUdtaget_rand[t]-qLavUdtaget_rand[t-1])/0.78/1000;                                                                          
                                                                                                     

    #40 kroner per tCO2e
    E_vtCO2_organicinproduction[t]$(tx0[t])..          vtCO2_organicinproduction[t] =E=  (40 * (qEmmLU12xF['crop_6_12',t] + qEmmLU12xF['crop_o12',t])/10**6)$(sum(HaUdtag,d1OptionsUdtag_xGrid[HaUdtag,'2']));
    E_vtCO2_organic_outofproduction[t]$(tx0[t])..  vtCO2_organic_outofproduction[t] =E=  (40 * (qEmmLU12xF['grass_6_12',t] + qEmmLU12xF['grass_o12',t])/10**6)$(sum(HaUdtag,d1OptionsUdtag_xGrid[HaUdtag,'2']));


  #----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
  # Udtagning til SKOV
  #----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#  

    #---------------------------------------------------------------------
    # Udtagning til skov a) udtagningsen, der går ind i landbrugsmodulet
    #------------------------------------- -------------------------------

     #Beregner, hvor meget skov der potentielt kan udtages for en given negativ afgift
     E_qLandSko_pot_inp[t]$(tx0E[t])..
        #  qLandSko_pot[t] =E= sum((btype,gridtax)$(d1currentgrid[gridtax]), qLandUdtag_pot['sko',btype,gridtax,t])/10**6;
        #Vi bruger 2050 som anker. Vi sætter loft over skovrejsning på 250 000 ha. 
        qLandSko_pot_inp[t] =E= sum((btype,gridtax)$(d1currentgrid[gridtax]), qLandUdtag_pot['sko',btype,gridtax,'2050'])/10**6 + sum(gridtax$(d1currentgrid[gridtax]), + qLandUdtag_pot_permg2sko[gridtax,'2050'])/10**6;

      #  E_qLandSko_pot_inp_tEnd[t]$(tEnd[t])..
      #    qLandSko_pot_inp[t] =E= qLandSko_pot_inp[t-1]; 

      E_qLandSkov_pot_hoej[t]$(tx0E[t])..                                                                                            #10 pct. permanent græs til skov på højbonitet
        qLandSko_pot_hoej[t] =E= sum((btypeH,gridtax)$(d1currentgrid[gridtax]), qLandUdtag_pot['sko',btypeH,gridtax,'2050'])/10**6 + 0.1 * sum(gridtax$(d1currentgrid[gridtax]), qLandUdtag_pot_permg2sko[gridtax,'2050'])/10**6;

      E_qLandSkov_pot_lav[t]$(tx0E[t])..                                                                                            #90 pct. permanent græs til skov på lavbonitet
        qLandSko_pot_lav[t] =E= sum((btypeL,gridtax)$(d1currentgrid[gridtax]), qLandUdtag_pot['sko',btypeL,gridtax,'2050'])/10**6  + 0.9 * sum(gridtax$(d1currentgrid[gridtax]), qLandUdtag_pot_permg2sko[gridtax,'2050'])/10**6;


      #Skov er i udtagninsmodellen begrænset til max 250 000. Vi bruger derfor ikke den approksimerede minimumsfunktion herunder (det udkommenterede)
      E_qLandSko_pot[t]$(tx0E[t])..
        qLandSko_pot[t] =E= qLandSko_pot_inp[t]; 

      #Det maksimale 2030-udtag beregnes som min[SkovPotentialei2050, MaksimaltMuligtUdtag2030]. Det er vurderet at der maksimalt kan omlægges yderligere 70 000 ha frem til 2030
      E_qLandSko2030..
        qLandSko2030 =E= min(qLandSko_pot['2050'], maxrejs2030);

     #Beregner potentiel brakline i "baseline", hvor der med baseline forstås ingen negativ afgift på skovrejsning.
     E_qLandBRK_pot[t]$(tx0E[t])..
        qLandBRK_pot_base[t] =E= sum((btype), qLandUdtag_pot['BRK',btype,'0',t])/10**6;


     #Før 2030 rejses skov ift. MIM's omkostningsminimeringskurve
     E_qLandSko_foer2030[t]$(tx0E[t] and t.val <=2030)..
        qLandSko[t] =E= qLandSko[t-1] + maxrejs[t];

      #Efter 2030 fortsættes med den maksimale kapacitet til hele potentialet er udtømt. Der benyttes (igen) en approksimativ minimumsfunktion:
      # Skov[t] = Skov[t-1] + min[TotalPotentielSkov - Skov[t-1], MaxRejsning2030]
      E_qLandSko_efter2030[t]$(tx0E[t] and t.val >2030)..
        qLandSko[t] =E= qLandSko[t-1] + min(qLandSko_pot[t]-qLandSko[t-1],maxrejs['2030']); 

      E_qLandSko_tEnd[t]$(tEnd[t])..
        qLandSko[t] =E= qLandSko[t-1];

      E_inputk[t]$(tx0[t] and t.val>=2025 and t.val<=2030)..      inputk[t] =E= qLandSko2030/3*1000; #Ganger m. 1000 for kha. sqr(sqrt(qLandSko_pot[t]/3));                #Sidste led her er en smooth dummy. Funktionen regner nemlig også skovrejsning for input[k] =0....Det vil vi ikke have
      E_rejs2527[t]$(tx0[t] and t.val>=2025 and t.val <=2027).. xrejst[t]   =E= [16 * inputk[t] - 12 - sqrt(36*(9-5*sqr(inputk[t])) + sqr(16*inputk[t]-12))]/p_min_skovrejs * errorf((inputk[t]-1)/0.01);
      E_rejs2830[t]$(tx0[t] and t.val>=2028 and t.val <=2030).. xrejst[t]   =E= inputk[t] - xrejst['2027'];
      E_maksrejs[t]$(tx0[t] and t.val>=2025 and t.val <=2030).. maxrejs[t]  =E= max(xrejst[t]-KF22_skovrejsning_GSR[t],0)/1000; # (xrejst[t] - KF22_skovrejsning_GSR[t])/1000 * errorf((xrejst[t] - KF22_skovrejsning_GSR[t])/0.000001); #Regner tilbage til mio. ha.

      #Skov fra permanent græsarealer
                                                          #qLandSko_pot_inp['2050'] er ganget over på den anden side for ikke at dividere med nul, når der ikke er skov
      E_qLandSko_fraper[t]$(tx0E[t]).. qLandSko_fraper[t]*(qLandSko_pot_inp['2050'] + 1/10**6) #Once again we add 1 hectar for this to compute (otherwise we have a zero=zero issue)
        =E= qLandSko[t] * sum(gridtax$(d1currentgrid[gridtax]), + qLandUdtag_pot_permg2sko[gridtax,'2050'])/10**6; 

      E_qLandSko_fraper_term[t]$(tEnd[t]).. qLandSko_fraper[t] =E= qLandSko_fraper[t-1];

      #Skov fra omdriftsjorder
      E_qLandSko_fraomd[t]$(tx0E[t]).. qLandSko_fraomd[t] =E= qLandSko[t] - qLandSko_fraper[t];

      E_qLandSko_fraomd_term[t]$(tEnd[t]).. qLandSko_fraomd[t] =E= qLandSko_fraomd[t-1];


    #---------------------------------------------------------------------
    # Udtagning til skov b) udtagning, der går ind i LULUCF-modulet
    #------------------------------------- -------------------------------

      #Fordeler skov på høj- og lavbonitet. Bemærk at nævneren er ganget over på venstre side i ligningerne 
      E_qLandSko_hoej[t]$(tx0E[t])..  #and not sameas[gridtax,'0'])..
        qLandSko_hoej[t]  =E= qLandSko[t]  *  qLandSko_pot_hoej[t]/(qLandSko_pot[t]+1/10**6); #We add 1 ha in the denominator to make the code run when there is no forest

      E_qLandSko_hoej_tEnd[t]$(tEnd[t])..
        qLandSko_hoej[t] =E= qLandSko_hoej[t-1];

      E_qLandSko_lav[t]$(tx0E[t]).. #and not sameas[gridtax,'0'])..
        qLandSko_lav[t]  =E= qLandSko[t]  *  qLandSko_pot_lav[t]/(qLandSko_pot[t]+1/10**6);

      E_qLandSko_lav_tEnd[t]$(tEnd[t])..
        qLandSko_lav[t] =E= qLandSko_lav[t-1];

      #Her beregnes omregnes skovrejsningen til 5-årige perioder. Der antages en 50/50 fordeling af hurtigvoksende og normal skov (det er de 0.5, der ganges med på tværs af bonitet)
      #Der ganges med 1000 for at omregne fra mio. ha. til kha. som er skovmodellens enhed. Dobbeltsummen gør følgende: Den indre sum beregner summen af ændringer på femårsperioder. Den anden sum henfører, hver af disse fem-årstotaler til t - igen via mappingen.

    
      #  E_qF5_aff_new_11_islands[t]$(tF[t] and d1qF5_aff['11','islands','C','acl5',t])..
      #     qF5_AFF['11','islands','C','acl5',t] =E= qF5_AFF_baseline['11','islands','C','acl5',t] + 0.5 * sum(ite$ite2t(ite,t), sum(tt$ite2t(ite,tt), qLandSko_hoej[tt]-qLandSko_hoej[tt-1]))*1000;

      #  E_qF5_aff_new_18_islands[t]$(tF[t] and d1qF5_aff['18','islands','B','acl5',t])..
      #     qF5_AFF['18','islands','B','acl5',t] =E= qF5_AFF_baseline['18','islands','B','acl5',t] + 0.5 * sum(ite$ite2t(ite,t), sum(tt$ite2t(ite,tt), qLandSko_hoej[tt]-qLandSko_hoej[tt-1]))*1000;

      #  E_qF5_aff_new_12_Jutland[t]$(tF[t] and d1qF5_aff['12','Jutland','C','acl5',t])..
      #     qF5_AFF['12','Jutland','C','acl5',t] =E= qF5_AFF_baseline['12','Jutland','C','acl5',t] + 0.5 * sum(ite$ite2t(ite,t), sum(tt$ite2t(ite,tt), qLandSko_lav[tt]-qLandSko_lav[tt-1]))*1000;

      #  E_qF5_aff_new_18_jutland[t]$(tF[t] and d1qF5_aff['18','Jutland','B','acl5',t])..
      #     qF5_AFF['18','Jutland','B','acl5',t] =E= qF5_AFF_baseline['18','Jutland','B','acl5',t] + 0.5 * sum(ite$ite2t(ite,t), sum(tt$ite2t(ite,tt), qLandSko_lav[tt]-qLandSko_lav[tt-1]))*1000;

      #Jordudtaget giver også en ændring i udtaget i LULUCF_modulet: NB: Dummyes d1qLUC12 bør opdateres, hvis der også skal inkluderes skovrejsning som alternativ
      # E_qLUC12_forestfromagr[t]$(tx0[t] and d1qLuc12['crop_u6','forest',t])..  qLUC12['crop_u6','forest',t] =E= qLUC12_baseline['crop_u6','forest',t] + (qLandSko[t]-qLandSko[t-1])*1000 + jLUC12_endoland['crop_u6','forest',t];


  #----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
  # DEN SAMLEDE UDTAGNING I LANDBRUGSMODULET OPSUMMERES SOM SUMMEN AF SKOV, LAVBUND OG BRAK
  #----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#  

    #Braklægning er givet ved max[PotentielBraklægningBaseline - Skov, 0] -> Altså, hvis der er mere skov end brak i baseline sættes brak til nul.
    E_qLandBRK[t]$(tx0E[t])..                                               
          qLandBRK[t] =E= max(qLandBRK_pot_base[t]-qLandSko_fraomd[t],0);

    E_qLandBRK_tEnd[t]$(tEnd[t])..
          qLandBRK[t] =E= qLandBRK[t-1];

    #Totalt udtaget jord målt i mio. ha. for et givent DBII målt ved opslag ved "glidende gennemsnit" i de kombinationer af hektarafgift og DBII, der bliver beregnet på IFRO's tal
    E_qLandUdtag_tot[t]$(tx0E[t])..
           qLandUdtag_tot[t] =E= (sum((alt,btype), qLandUdtag_pot[alt,btype,'0',t])*scaleha/10**6)$(d1currentgrid['0'])
                                                         +((sum((btype,gridtax)$(d1currentgrid[gridtax]), qLandUdtag_pot['GLM',btype,gridtax,t] + qLandUdtag_pot['BIO',btype,gridtax,t])*scaleha/10**6
                                                            + qLandSko_fraomd[t] + qLandBRK[t]))$(not d1currentgrid['0'])
                                                            + qLavUdtaget[t] * 0.85 *scaleha/10**6 #85% af lavbund på omdriftsjord
                                                            + (qLandSolceller[t]*scaleha/10**6)$(not d1OptionsUdtag_xGrid['35000','0']) 
                                                            ; #Lavbund der ikke er udtaget endnu lægges til

    E_qLandUdtag_tot_tEnd[t]$(tEnd[t])..
      qLandUdtag_tot[t] =E= qLandUdtag_tot[t-1];
                                                            
    #Totalt potentielt udtag (eksl. jord fra permanentegræsarealer) beregnes. Dette bruges til at vægte produktivitetsændring ind. Den helt korrekte måde ville være at vægte arealer ind med deres respektive produktivitet, men det er omstændigt, da produktiviteten så skal opdeles på alternative anvendelser
    E_qLandUdtag_pot_tot[t]$(tx0E[t])..  
      qLandUdtag_pot_tot[t] =E=  (sum((alt,btype), qLandUdtag_pot[alt,btype,'0',t])*scaleha/10**6)$(d1currentgrid['0'])
                               + (sum((btype,gridtax)$(d1currentgrid[gridtax]), qLandUdtag_pot['GLM',btype,gridtax,t] + qLandUdtag_pot['BIO',btype,gridtax,t])*scaleha/10**6
                               +  qLandBRK[t]
                               +  sum((btype,gridtax)$(d1currentgrid[gridtax]), qLandUdtag_pot['sko',btype,gridtax,'2050'])/10**6)$(not d1currentgrid['0'])
                               +  qLavUdtaget[t] * 0.85 *scaleha/10**6 #85% af lavbund på omdriftsjord
                               + (qLandSolceller[t]*scaleha/10**6)$(not d1OptionsUdtag_xGrid['35000','0']) 
                               ;

    E_qLandUdtag_pot_tot_tEnd[t]$(tEnd[t])..
      qLandUdtag_pot_tot[t] =E= qLandUdtag_pot_tot[t-1];


    E_sUdtaget_af_pot[t]$(tx0[t])..
      sUdtaget_af_pot[t] * (qLandUdtag_pot_tot[t] - qLandUdtag_tot_zeroshock_agr[t] + 1e-6) =E= (qLandUdtag_tot[t] - qLandUdtag_tot_zeroshock_agr[t] + 1e-6);

    #TFP bruges til at kalibrere til Landbrugsfremskrivningen, og det er kun i stødforløb produktiviteten ændrer sig pba. af jordudtag.
    E_TFP_plant[plant_sectors,t]$(tx0[t] and not sameas[plant_sectors,'01020'])..
      #  TFPPlant[plant_sectors,t] =E= TFPPlant_baseline_zeroshockagr[plant_sectors,t] * sUdtaget_af_pot[t] * sum(gridtax$(d1currentgrid[gridtax]), fProduktion_perhaiomdrift_CGE[gridtax,t]);
      TFPPlant[plant_sectors,t] =E= (1-sUdtaget_af_pot[t]) * TFPPlant.l[plant_sectors,t] 
                                      +sUdtaget_af_pot[t]  * TFPPlant_baseline_zeroshockagr[plant_sectors,t] * sum(gridtax$(d1currentgrid[gridtax]), fProduktion_perhaiomdrift_CGE[gridtax,t]);


    #

    #  E_margDBII_2CGE_act[t]$(tx0[t]).. 
    #    margDBII_2CGE_act[t] =E=      (1-sUdtaget_af_pot[t]) * margDBII_2CGE_act_zeroshockagr[t] 
    #                                    + sUdtaget_af_pot[t] *  sum(gridtax$(d1currentgrid[gridtax]), margDBII_2CGE_pot[gridtax,t]);

    E_ChangeDBII_2CGE_act[t]$(tx0[t])..
      #  ChangeDBII_2CGE_act[t] =E=      (1-sUdtaget_af_pot[t]) * ChangeDBII_2CGE_act_zeroshockagr[t] 
      #                                   + sUdtaget_af_pot[t] *  sum(gridtax$(d1currentgrid[gridtax]), ChangeDBII_pot[gridtax,t]);

      ChangeDBII_2CGE_act[t] =E=      (1-sUdtaget_af_pot[t]) *  ChangeDBII_pot['0',t]
                                       + sUdtaget_af_pot[t]  *  sum(gridtax$(d1currentgrid[gridtax]), ChangeDBII_pot[gridtax,t]);


    #Ændringen i samlet jordmængde i CGE-modellen bestemmes
    E_qLand_endo[t]$(tx0E[t]).. qLand[t] =E= qLand[t-1] - (qLandUdtag_tot[t]-qLandUdtag_tot[t-1]) 
                                                        
                                                        + jEndoLand[t];  

    E_qLand_endo_end[t]$(tEnd[t]).. qLand[t] =E= qLand[t-1];

    E_qLand_nonproductive_inmapping[plant_sectors,landallocation,t]$(tx0E[t] and not sameas[plant_sectors,'01020'] and sum(alt,alt2landallocation(alt,landallocation)))..  #or sameas[landallocation,'solceller']).. 
      qLand_nonproductive[landallocation,plant_sectors,t] =E= qLand_nonproductive[landallocation,plant_sectors,t-1] 
                                                    + qPlant[plant_sectors,'land',t-1]/sum(plant_sectorss$(not sameas[plant_sectorss,'01020']), qPlant[plant_sectorss,'land',t-1]) 
                                                  *  ((qLandBRK[t] - qLandBRK[t-1])$(alt2landallocation('BRK',landallocation)) 
                                                    + (qLandSko[t] - qLandSko[t-1])$(alt2landallocation('SKO',landallocation)))
                                                    + jLand_nonproductive[plant_sectors,landallocation,t];

    E_qLand_nonproductive_notinmapping[plant_sectors,landallocation,t]$(tx0E[t] and not sameas[plant_sectors,'01020'] and (sameas[landallocation,'VaadLagtLavbund'] or sameas[landallocation,'baseline'] or sameas[landallocation,'Solceller']))..  #or sameas[landallocation,'solceller']).. 
      qLand_nonproductive[landallocation,plant_sectors,t] =E= qLand_nonproductive[landallocation,plant_sectors,t-1] 
                                                    + qPlant[plant_sectors,'land',t-1]/sum(plant_sectorss$(not sameas[plant_sectorss,'01020']), qPlant[plant_sectorss,'land',t-1]) 
                                                    * ( ((qLavUdtaget[t]     - qLavUdtaget[t-1]) *scaleha/10**6)$(sameas[landallocation,'VaadLagtLavbund'])   #Vådlægningen sker både fra omdrift og udtaget i baseline
                                                       -((qLavUdtaget[t]     - qLavUdtaget[t-1]) *(1-0.85) *scaleha/10**6)$(sameas[landallocation,'Baseline']) #En del af vådlægningen sker på jorder, der er udtaget i baseline
                                                       -((qLandSko_fraper[t] - qLandSko_fraper[t-1])$(sameas[landallocation,'Baseline']))
                                                       +((qLandSolceller[t] - qLandSolceller[t-1])*scaleha/10**6)$(sameas[landallocation,'Solceller'] and not d1OptionsUdtag_xGrid['35000','0'])
                                                       +((qLandLandvind[t] - qLandLandvind[t-1])*scaleha/10**6)$(sameas[landallocation,'Landvind'] and not d1OptionsUdtag_xGrid['35000','0'])
                                                      )
                                                    + jLand_nonproductive[plant_sectors,landallocation,t];

    E_qLand_nonproductive_tEnd[plant_sectors,landallocation,t]$(tEnd[t])..
        qLand_Nonproductive[landallocation,plant_sectors,t] =E= qLand_Nonproductive[landallocation,plant_sectors,t-1];
$ENDBLOCK  

#Block af ligninger til kalibrering af endogen jordudtag til CGE-modellen. Pt. kalibreres, så der ikke udtages jord i baseline som følge af endogenjordudtagsmodulet.
$BLOCK B_endolandlinks_calib                                                      
                                                                                  #Ha=0, negCO2e=0
  # E_vDBII_INPUT_calib[t]$(tx0[t])..        vDBII_INPUT[t] =E= vDBII_iomdrift_total['0','0','35000','0']; #KF24 deadline
  E_vDBII_INPUT_calib[t]$(tx0[t])..        vDBII_INPUT[t] =E= vDBII_iomdrift_total['200','750','70000','1']; #KF25 deadline - the 200 kroner per hectare is roughly the decrease in DBII in KF24-model version in 2035 from the Tripartite

$ENDBLOCK

$MODEL M_endolandlinks 
  B_endolandlinks
  -E_TFP_plant
;

$GROUP G_endolandlinks_endo 
  qLand$(tx0[t])            #E_qLand_endo
  vDBII_INPUT               #E_vDBII_INPUT
  qLandUdtag_tot$(tx0[t])   #E_qLandUdtag_tot
  qLandSko_pot              #E_qLandSko_pot
  qLandSko_pot_inp          #E_qLandSko_pot_inp
  qLandSko2030           #E_qLandSko2030
  maxrejs$(tx0[t] and t.val>=2025 and t.val<=2030)  #E_maksrejs

  xrejst$(tx0[t])                     #E_rejs2527, E_rejs2830
  qLandBRK$(tx0[t])
  qLandSko$(tx0[t])
  qLandSko_fraper$(tx0[t])
  qLandSko_fraomd$(tx0[t])
  qLandSko_hoej$(tx0[t]) # and not sameas[gridtax,'0'])
  qLandSko_lav$(tx0[t])  #and not sameas[gridtax,'0'])r
  # qF5_AFF$(tF[t] and acl_init[acl] and d1qF5_AFF[skmodel,joe07,spec_type,acl,t] and sameas[skmodel,'11'] and sameas[joe07,'islands'] and sameas[spec_type,'C'])
  # qF5_AFF$(tF[t] and acl_init[acl] and d1qF5_AFF[skmodel,joe07,spec_type,acl,t] and sameas[skmodel,'18'] and sameas[joe07,'islands'] and sameas[spec_type,'B'])
  # qF5_AFF$(tF[t] and acl_init[acl] and d1qF5_AFF[skmodel,joe07,spec_type,acl,t] and sameas[skmodel,'12'] and sameas[joe07,'Jutland'] and sameas[spec_type,'C'])
  # qF5_AFF$(tF[t] and acl_init[acl] and d1qF5_AFF[skmodel,joe07,spec_type,acl,t] and sameas[skmodel,'18'] and sameas[joe07,'Jutland'] and sameas[spec_type,'B'])


  qLand_nonproductive$(tx0E[t] and sum(alt,alt2landallocation(alt,landallocation)) and not sameas[plant_sectors,'01020'])                                 #E_qLand_nonproductive_inmapping, og ingen udtag til brak hos gartnerierne
  qLand_nonproductive$(tx0E[t] and (sameas[landallocation,'VaadLagtLavbund'] or sameas[landallocation,'Baseline']) and not sameas[plant_sectors,'01020']) #E_qLand_nonproductive_notinmapping, og ingen udtag til brak hos gartnerierne
  qLand_nonproductive$(tx0E[t] and (sameas[landallocation,'Solceller'] or sameas[landallocation,'Baseline']) and not sameas[plant_sectors,'01020']) #E_qLand_nonproductive_notinmapping, og ingen udtag til brak hos gartnerierne
 
  qLand_nonproductive$(tEnd[t] and sum(alt,alt2landallocation(alt,landallocation)) and not sameas[plant_sectors,'01020'])                                 #E_qLand_nonproductive_inmapping, og ingen udtag til brak hos gartnerierne
  qLand_nonproductive$(tEnd[t] and (sameas[landallocation,'VaadLagtLavbund'] or sameas[landallocation,'Baseline']) and not sameas[plant_sectors,'01020']) #E_qLand_nonproductive_notinmapping, og ingen udtag til brak hos gartnerierne
  qLand_nonproductive$(tEnd[t] and (sameas[landallocation,'Solceller'] or sameas[landallocation,'Baseline']) and not sameas[plant_sectors,'01020']) #E_qLand_nonproductive_notinmapping, og ingen udtag til brak hos gartnerierne


  # qLUC12$(tx0[t] and sameas[land12_s,'crop_u6'] and sameas[land12_r,'Forest'] and d1qLuc12[land12_s,land12_r,t])        #SKOV!
 
  # qLUC12$(tx0[t] and sameas[land12_s,'crop_o12'] and sameas[land12_r,'Wetland'] and d1qLuc12[land12_s,land12_r,t])   #LAVBUND!
  # qLUC12$(tx0[t] and sameas[land12_s,'crop_6_12'] and sameas[land12_r,'Wetland'] and d1qLuc12[land12_s,land12_r,t])  #LAVBUND!
  # qLUC12$(tx0[t] and sameas[land12_s,'grass_6_12'] and sameas[land12_r,'Wetland'] and d1qLuc12[land12_s,land12_r,t]) #LAVBUND!
  # qLUC12$(tx0[t] and sameas[land12_s,'grass_o12'] and sameas[land12_r,'Wetland'] and d1qLuc12[land12_s,land12_r,t])  #LAVBUND!
  # qLUC12$(tx0[t] and sameas[land12_s,'crop_u6'] and sameas[land12_r,'Wetland'] and d1qLuc12[land12_s,land12_r,t])    #RANDAREAL!

  vtCO2_organicinproduction$(tx0[t])
  vtCO2_organic_outofproduction$(tx0[t])

  #Produktivitet 
  #  TFPPlant$(tx0[t] and not sameas[plant_sectors,'01020']) #Udgår for nu
  qLandUdtag_pot_tot$(tx0[t])
  sUdtaget_af_pot$(tx0[t])
  fProduktion_perhaiomdrift_CGE$(tx0[t])

  #Marg DBII
  #  margDBII_2CGE_pot$(tx0[t])
  ChangeDBII_pot$(tx0[t])

;

$GROUP G_endolandlinks_exo 
  jEndoLand                #E_qLand_endo
  qLand$(t0[t])            #E_qLand_endo og E_qLand_nonproductive
  vDBII                    #E_vDBII_INPUT
  jvDBII_CGE               #E_vDBII_CGE - burde måske flyttes til landbrugsmodulet
  qLandUdtag_tot$(t0[t])   #E_qLandUdtag_tot

  qPlant$((tx0[t] or t0[t]) and d1Plant[plant_sectors,plant_,t] and sameas[plant_,'land']) #E_qLand_nonproductive
  qLandBRK$(t0[t]) #E_qLand_nonproductive
  qLand_Nonproductive$(t0[t]) #E_qLand_nonproductive
  qLandSolceller$(t0[t])
  qLavUdtaget$(t0[t])
  jLand_nonproductive      #E_qLand_nonproductive
  
  qLandSko$(t0[t]) #E_qLandSko_foer2030
  qLandSko_fraper$(t0[t])
  qLandSko_fraomd$(t0[t])

  maxrejs2030      #E_inputk
  maxrejs          #E_maksrejs
  maxrejstot       #Benyttes ikke pt - de 250 000 ha max frem til 2050 kommer direkte fra E_maxskovi udtagningsmodellen i stedet
  p_min_skovrejs   #E_rejs2527
  qLandSko_hoej
  qLandSko_lav

  xrejst$(t.val <=t0.val)
  qLandSko$(t.val<=t0.val)

  qF5_AFF_baseline$(d1qF5_aff[skmodel,joe07,spec_type,acl,t])
  qLUC12_baseline$(d1qLuc12[land12_s,land12_r,t])
  jLUC12_endoland$(tx0[t] and sameas[land12_s,'crop_u6'] and sameas[land12_r,'Forest'] and d1qLuc12[land12_s,land12_r,t])

  qLavUdtaget_hoej$(t0[t]) ""
  qLavUdtaget_lav$(t0[t])  ""
  qLavUdtaget_rand$(t0[t]) ""
  qLU12$((tx0[t] or t0[t]) and d1qLU12[land12,t]) #LU er eksogen ift. udtagningsmodulet
  qEmmLU12xF$(tx0[t] and d1qEmmLU12xF[land12xF,t])

  qLandSolceller #Solceller indlægges exogent 
  qLandLandvind  #Landvind  indlægges exogent

  #Produktivitet
  TFPPlant_baseline_zeroshockagr
  qLandUdtag_tot_zeroshock_agr

  #DBII 
  #  margDBII_2CGE_act_zeroshockagr$(tx0[t])
  #  ChangeDBII_2CGE_act_zeroshockagr$(tx0[t])
;

$MODEL M_endolandlinks_calib 
  M_endolandlinks
  B_endolandlinks_calib
  -E_TFP_plant
;

$GROUP G_endolandlinks_calib_endo
  G_endolandlinks_endo
  -qLand$(tx0E[t])
  jEndoLand$(tx0E[t])            #E_qLand_endo - sørger for uændret jordforbrug i baseline ift. Landbrugsfremskrivningen
  jvDBII_CGE                    #E_vDBII_CGE - sørger for at dækningsbidraget ikke ændrer sig i baseline i udtagningsfunktionen (i.e. ingen udtag ift. Landbrugsfremskrivningen)
  jLand_nonproductive$(tx0E[t]) #E_qLand_nonproductive_brak, - ingen udtag i baseline
  -qLand_nonproductive          #E_qLand_nonproductive_brak, - ingen udtag i baseline
  # -qLUC12$(tx0[t] and sameas[land12_s,'crop_u6'] and sameas[land12_r,'Forest'] and d1qLuc12[land12_s,land12_r,t]), jLUC12_endoland$(tx0[t] and sameas[land12_s,'crop_u6'] and sameas[land12_r,'Forest'] and d1qLuc12[land12_s,land12_r,t])
  -TFPPlant
  margDBII_2CGE_act_zeroshockagr$(tx0[t])
  #  ChangeDBII_2CGE_act_zeroshockagr$(tx0[t])
;

$GROUP G_endolandlinks_calib_exo
  G_endolandlinks_exo
  -jEndoLand$(tx0E[t])
  qLand$(tx0E[t])
  -jvDBII_CGE #B_endolandlinks_calib
  -jLand_nonproductive$(tx1[t]) #E_qLand_nonproductive_brak
  qLand_nonproductive #E_qLand_nonproductive_brak
  # qLUC12$(tx0[t] and sameas[land12_s,'crop_u6'] and sameas[land12_r,'Forest'] and d1qLuc12[land12_s,land12_r,t]), -jLUC12_endoland$(tx0[t] and sameas[land12_s,'crop_u6'] and sameas[land12_r,'Forest'] and d1qLuc12[land12_s,land12_r,t])
  TFPPlant
  #  -margDBII_2CGE_act_zeroshockagr$(tx0[t])
  #  -ChangeDBII_2CGE_act_zeroshockagr$(tx0[t])
;

$FIX G_endolandlinks_calib_exo;
$UNFIX G_endolandlinks_calib_endo;
$IF %readfromprevious%!=1:
  @SOLVE(M_endolandlinks_calib);
$ENDIF

@assert_no_difference(G_endoland_calib_should_not_change,1e-8);



#TESTER UDTAGNINGSMODUL 
#  $MODEL M_udtagningtest 
#    M_endolandlinks
#    -E_vDBII_CGE
#    -E_vDBII_INPUT
#  ;

#  #Vi fodrer udtagningsmodulet med DBII, der ligger lige oven i grid. Den skulle gerne kunne ramme meget præcist. Hvis vi afviger mere end 100 ha. afbrydes kørsel
#  PARAMETER collectjek[grid,gridtax,HaUdtag,lavbundsmodel];
#  $FOR {gridCO2tax} in ['0','750']:
#  #      #£AKB: Skovgrid
#  #      #  $FOR1 {grid} in ['0','61','91','121','152','182','212','242','273','303','333','364','394','424','455','485','515','545','576','606','636','667','697','727','758','788','818','848','879','909','939','970','1000','1030','1061','1091','1121','1152','1182','1212','1242','1273','1303','1333','1364','1394','1424','1455','1485','1515','1545','1576','1606','1636','1667','1697','1727','1758','1788','1818','1848','1879','1909','1939','1970','2000','2030','2061','2091','2121','2152','2182','2212','2242','2273','2303','2333','2364','2394','2424','2455','2485','2515','2545','2576','2606','2636','2667','2697','2727','2758','2788','2818','2848','2879','2909','2939','2970','3000','3030']:
#      $FOR1 {grid} in ['0','100','200','300','400','500','600','700','800','900','1000']: #,'1100','1200','1300','1400','1500','1600','1700','1800','1900','2000','2100','2200','2300','2400','2500','2600','2700','2800','2900','3000','3100','3200','3300','3400','3500','3600','3700','3800','3900','4000','4100','4200','4300','4400','4500','4600','4700','4800','4900','5000','5100','5200','5300','5400','5500','5600','5700','5800','5900','6000']:
#  #      #  $FOR1 {grid} in ['0','100']:# ,'200','300','400','500','600','700','800']:
#         $FOR2 {HaUdtag},{lavm} in [('35000','1'),('70000','1'),('70000','2')]:

#         vDBII_INPUT.fx[tx0] = vDBII_iomdrift_total['{grid}','{gridCO2tax}','{HaUdtag}','{lavm}'];
#         $FIX G_endolandlinks_exo;
#         $UNFIX G_endolandlinks_endo;
#         $FIX vDBII_INPUT;

#         d1currentgrid[gridtax]                        = no;  #Sætter til "No" for alle elementer, just in case
#         d1currentgrid['{gridCO2tax}']                 = yes; #Negativ afgift på skovrejsning indlægges
#         d1UdtagOptions[gridtax,HaUdtag,lavbundsmodel] = no;  #Sætter til "No" for alle elementer, just in case 
#         d1OptionsUdtag_xGrid[HaUdtag,lavbundsmodel]   = no;
#         d1UdtagOptions['0','{HaUdtag}','{lavm}']               = yes; #Sætter baseline afgift til nul (så vi kan få regnet udtag hvis skatten havde været nul). Det relevante alternativ for lavbund er samme som stødet
#         d1UdtagOptions['{gridCO2tax}','{HaUdtag}','{lavm}']   = yes; #Sætter faktisk afgift til {negativetax} 
#         d1OptionsUdtag_xGrid[HaUdtag,lavbundsmodel]   = yes$(sum(gridtax, d1UdtagOptions[gridtax,HaUdtag,lavbundsmodel]));

#         @SOLVE(M_udtagningtest);
#         tjek = sum((alt,btype), qLandUdtag_pot.l[alt,btype,'{gridCO2tax}','2030']) - sum((alt,btype), udtag_udf['{grid}','{gridCO2tax}','{HaUdtag}','{lavm}',alt,btype]);
#         collectjek['{grid}','{gridCO2tax}','{HaUdtag}','{lavm}'] = tjek;
#         #  DISPLAY tjek;
#         #  Abort$(abs(tjek) > 2000) tjek, "Udtagningsfunktionen rammer mere end 100 ved siden af på trods af at den er givet DBII præcis på grid";
#         $ENDFOR2
#      $ENDFOR1 
#  $ENDFOR



#  execute_unload 'output\endoland.gdx';
          
          

#  PARAMETER vDBIII[t];

#  vDBIII['2019'] =   4626661.03856033;
#  vDBIII['2020'] =   4626661.03856033;
#  vDBIII['2021'] =   4626661.03856033;
#  vDBIII['2022'] =   4626661.03856033;
#  vDBIII['2023'] =   4626661.03856033;
#  vDBIII['2024'] =   4450444.12406427;
#  vDBIII['2025'] =   4347164.63933731;
#  vDBIII['2026'] =   3669223.48821768;
#  vDBIII['2027'] =   3462575.76644236;
#  vDBIII['2028'] =   3294176.28362862;
#  vDBIII['2029'] =   3167795.77337699;
#  vDBIII['2030'] =   3170450.19370108;
#  vDBIII['2031'] =   3179750.14757962;
#  vDBIII['2032'] =   3197900.85161605;
#  vDBIII['2033'] =   3214992.50081352;
#  vDBIII['2034'] =   3228981.41506783;
#  vDBIII['2035'] =   3245066.21537579;
#  vDBIII['2036'] =   3261083.39547754;
#  vDBIII['2037'] =   3276513.34753513;
#  vDBIII['2038'] =   3292897.67480214;
#  vDBIII['2039'] =   3309897.06335668;
#  vDBIII['2040'] =   3335324.11230474;
#  vDBIII['2041'] =   3348485.18654;
#  vDBIII['2042'] =   3352307.06705974;
#  vDBIII['2043'] =   3350433.90901333;
#  vDBIII['2044'] =   3345678.86251881;
#  vDBIII['2045'] =   3340174.63704607;
#  vDBIII['2046'] =   3334789.78560061;
#  vDBIII['2047'] =   3329595.6928935;
#  vDBIII['2048'] =   3324834.75721699;
#  vDBIII['2049'] =   3320227.91326736;
#  vDBIII['2050'] =   3315864.92418755;
#  vDBIII['2051'] =   3311681.26543978;
#  vDBIII['2052'] =   3307597.48935023;
#  vDBIII['2053'] =   3303734.49256472;
#  vDBIII['2054'] =   3300154.40220637;
#  vDBIII['2055'] =   3297174.33395787;
#  vDBIII['2056'] =   3294841.11493401;
#  vDBIII['2057'] =   3293221.7233943;
#  vDBIII['2058'] =   3292464.15311147;
#  vDBIII['2059'] =   3292659.92027064;
#  vDBIII['2060'] =   3293980.49599282;
#  vDBIII['2061'] =   3296314.4736382;
#  vDBIII['2062'] =   3299602.26150313;
#  vDBIII['2063'] =   3303766.08132784;
#  vDBIII['2064'] =   3308650.35752229;
#  vDBIII['2065'] =   3314287.00358039;
#  vDBIII['2066'] =   3320483.38173229;
#  vDBIII['2067'] =   3327037.13970903;
#  vDBIII['2068'] =   3333792.57432434;
#  vDBIII['2069'] =   3340599.77014262;
#  vDBIII['2070'] =   3347468.52237599;
#  vDBIII['2071'] =   3354270.48391988;
#  vDBIII['2072'] =   3360921.75352547;
#  vDBIII['2073'] =   3367381.7201535;
#  vDBIII['2074'] =   3373637.6204466;
#  vDBIII['2075'] =   3379794.85895529;
#  vDBIII['2076'] =   3385837.44614795;
#  vDBIII['2077'] =   3391751.44989165;
#  vDBIII['2078'] =   3397542.28138843;
#  vDBIII['2079'] =   3403263.16070597;
#  vDBIII['2080'] =   3409021.22303469;
#  vDBIII['2081'] =   3414733.11215983;
#  vDBIII['2082'] =   3420323.38301223;
#  vDBIII['2083'] =   3425783.18729101;
#  vDBIII['2084'] =   3431044.22500969;
#  vDBIII['2085'] =   3436180.09098065;
#  vDBIII['2086'] =   3441129.10384455;
#  vDBIII['2087'] =   3445836.23439176;
#  vDBIII['2088'] =   3450297.2981551;
#  vDBIII['2089'] =   3454532.62651991;
#  vDBIII['2090'] =   3458675.15168722;
#  vDBIII['2091'] =   3462715.07063519;
#  vDBIII['2092'] =   3466677.39118343;
#  vDBIII['2093'] =   3470596.13265939;
#  vDBIII['2094'] =   3474518.72980364;
#  vDBIII['2095'] =   3478535.19201086;
#  vDBIII['2096'] =   3482599.82464046;
#  vDBIII['2097'] =   3486714.36386086;
#  vDBIII['2098'] =   3490751.12683891;
#  vDBIII['2099'] =   4626661.03856033;

#  $MODEL M_endolandlinks_test 
#   M_endolandlinks
#   -E_vDBII_CGE
#   -E_vDBII_INPUT
#  ;

#  vDBII_INPUT.l[t] = vDBIII[t];

#  #  d1UdtagOptions[gridtax,HaUdtag,lavbundsmodel] = no;  #Sætter til "No" for alle elementer, just in case 
#  #  d1OptionsUdtag_xGrid[HaUdtag,lavbundsmodel]   = no;
#  #  d1UdtagOptions['0','70000','1']               = yes; #Første indgang er negativ afgift på skov. Anden indgang er antal hektar lavbund udtaget (i baseline er det 35000). Tredje indgang er hvilken lavbundsudtagsmodel (1 = støtte/komp)
#  #  d1OptionsUdtag_xGrid[HaUdtag,lavbundsmodel]   = yes$(sum(gridtax, d1UdtagOptions[gridtax,HaUdtag,lavbundsmodel]));

#  #SKOV
#  d1currentgrid[gridtax]                        = no;  #Sætter til "No" for alle elementer, just in case
#  d1currentgrid['750']                          = yes; #Negativ afgift på skovrejsning indlægges
#  d1UdtagOptions[gridtax,HaUdtag,lavbundsmodel] = no;  #Sætter til "No" for alle elementer, just in case 
#  d1OptionsUdtag_xGrid[HaUdtag,lavbundsmodel]   = no;
#  d1UdtagOptions['0','70000','1']               = yes; #Sætter baseline afgift til nul (så vi kan få regnet udtag hvis skatten havde været nul)
#  d1UdtagOptions['750','70000','1']             = yes; #Sætter faktisk afgift til {negativetax} 
#  d1OptionsUdtag_xGrid[HaUdtag,lavbundsmodel]   = yes$(sum(gridtax, d1UdtagOptions[gridtax,HaUdtag,lavbundsmodel]));


#  $FIX G_endolandlinks_exo;
#  $UNFIX G_endolandlinks_endo;
#  $FIX vDBII_input;
#  @SOLVE(M_endolandlinks_test);


#  execute_unload 'output\post.gdx';
#  $exit
