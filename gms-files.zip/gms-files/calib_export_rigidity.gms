#If model is with rigid export-prices then we re-calibrate Armington-shares to reflect this
$IF %rigid_export%:
    #Rigidity-share set at 60 percent previous periods price
    pX_traek.l[x,s,tx0] = 0.8;

    $MODEL M_calibrate_rigidexport 
        E_qX_y 
        E_pX_y_hat
        E_qX_m 
        E_pX_m_hat
    ;

    $GROUP G_calibrate_rigidexport_exo 
        qX_y$(d1x_y[x,s,t]) 
        qX_m$(d1x_m[x,s,t])
        ZE 
        pX_y$(d1x_y[x,s,t]) 
        pX_m$(d1x_m[x,s,t])
        eXF 
        pXF
        pX_traek

        pX_y_hat$((t0[t] or tData[t]) and d1x_y[x,s,t]) 
        pX_m_hat$((t0[t] or tData[t]) and d1x_m[x,s,t])
        j_qX_y
    ;

    $GROUP G_calibrate_rigidexport_endo 
        pX_y_hat$(tx0[t] and not tData[t] and d1x_y[x,s,t]) 
        pX_m_hat$(tx0[t] and not tData[t] and d1x_m[x,s,t])

        sX_y$(tx0[t] and d1x_y[x,s,t]) 
        sX_m$(tx0[t] and d1x_m[x,s,t])
    ;


    $FIX G_calibrate_rigidexport_exo;
    $UNFIX G_calibrate_rigidexport_endo;
    @SOLVE(M_calibrate_rigidexport);

    #Test of zero-shock in calibration model
    @save(G_EndoAndExo);
    $FIX G_dynamic_calibration_exo;
    $UNFIX G_dynamic_calibration_endo;
    @SOLVE(M_dynamic_calibration_instcost);
    @assert_no_difference(G_EndoAndExo,1e-8);
$ENDIF


