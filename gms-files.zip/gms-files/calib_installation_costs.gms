
#  ====================================================================================================================================================================================================================#
#   Modelændringer for mere realistiske tilpasningshastigheder
#  ====================================================================================================================================================================================================================#

$FIX G_dynamic_calibration_exo;
$UNFIX G_dynamic_calibration_endo;
@SOLVE(M_dynamic_calibration_KF);


#Mere realistiske tilpasningsomkostninger ved stød end i kalibrering. Installationsomkostningerne øges i "installationsomk.gms"
	$MODEL M_instcost_calib_loop
		E_qKInstCost
		E_dqKInstCost2dqK
		E_dqKInstCost2dqI_s
		E_dqKInstCostLead2dqI_s
		;

	$GROUP G_J 
		$LOOP M_instcost_calib_loop:
			{name}_j{sets} ""
		$ENDLOOP 
	;

	$BLOCK B_instcost_new 
		$LOOP M_instcost_calib_loop:
			{name}_new{sets}$({subsets})..
				{LHS} =E= {RHS} + {name}_j{sets};
		$ENDLOOP
	$ENDBLOCK 


#Partial model for calibration of installation costs
$MODEL M_instcost_new 
	B_instcost_new
;

$GROUP G_instcost_exo 
	qK 
	qI_s
	uKinstcost
	fKInstCost

	$LOOP M_instcost_calib_loop:
		{name}_j{sets}
	$ENDLOOP
;

$GROUP G_instcost_endo 
	qKInstCost
	dKInstCost2dK
	dKInstCost2dI
	dKInstCostLead2dI
;

$GROUP G_instcost_calib_exo 
	G_instcost_exo 
	#  qKInstCost, -fKinstcost
	#  dKInstCost2dK, -fKinstcost
	#  dKInstCost2dI, -fKinstcost

	qKInstCost,        -E_qKInstCost_j
	dKInstCost2dK,     -E_dqKInstCost2dqK_j
	dKInstCost2dI,     -E_dqKInstCost2dqI_s_j
	dKInstCostLead2dI, -E_dqKInstCostLead2dqI_s_j

;

$GROUP G_instcost_calib_endo
	G_instcost_endo 
	#  -qKinstcost, fKinstcost
	#  -dKInstCost2dK, fKinstcost
	#  -dKInstCost2dI, fKinstcost

	-qKInstCost, E_qKInstCost_j
	-dKInstCost2dK, E_dqKInstCost2dqK_j
	-dKInstCost2dI, E_dqKInstCost2dqI_s_j
	-dKInstCostLead2dI, E_dqKInstCostLead2dqI_s_j
;


uKInstCost.l['IB',sp,t]$(NOT sLan_sp[sp] and not sameas['35002',sp]) = 20;
uKInstCost.l['IM',sp,t]$(NOT sLan_sp[sp] and not sameas['35002',sp]) = 5;

$FIX G_instcost_calib_exo;
$UNFIX G_instcost_calib_endo;
@SOLVE(M_instcost_new,1);

$FIX G_instcost_exo;
$UNFIX G_instcost_endo;
@SOLVE(M_instcost_new,1);

#We check that the calibration model does not change from having installation costs changed
$GROUP G_EndoAndExo 
	G_dynamic_calibration_endo 
	G_dynamic_calibration_exo
	-sigmaID #Fungerer ikke ordentligt med gamY (prøv igen med fremtidig gamY-version, AKB 27.6.2024)
	-eAGG
;

$MODEL M_dynamic_calibration_instcost
	M_dynamic_calibration_KF
	$LOOP M_instcost_calib_loop:
	-{name}
	{name}_new 
	$ENDLOOP
;


#Testing that the calibration model does not change
@save(G_EndoAndExo);
$FIX G_dynamic_calibration_exo;
$UNFIX G_dynamic_calibration_endo;
@SOLVE(M_dynamic_calibration_instcost);

@assert_no_difference(G_EndoAndExo,1e-8);
@assert_no_difference(G_data,%tolerance_data%);
$import sanitycheck.gms;


