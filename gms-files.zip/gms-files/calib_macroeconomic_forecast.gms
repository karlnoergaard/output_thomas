#====================================================================================================================================================================================================================#
# OVERVIEW
#====================================================================================================================================================================================================================#
#
# 1) Creation of dummies to control the calibration
#
# 2) Creation of price/quantity indeces. Aggregation of KF21 to a comparable level
#
# 3) Calibration to MAKRO/KF21
#
#====================================================================================================================================================================================================================#
#====================================================================================================================================================================================================================#
# 1) Creation of dummies to control calibration 
#====================================================================================================================================================================================================================#

#Parameter to control what export items we calibrate to 
PARAMETER d1IncludeThese[maks];
d1IncludeThese['fre'] = yes;
d1IncludeThese['tje'] = yes;
d1IncludeThese['soe'] = yes;


#Create set to control imports, in case we try to calibrate to imports
parameter d1RxE_only_m[r,s,t];
d1RxE_only_m[r,s,t]$(d1RxE_m[r,s,t] and not d1RxE_y[r,s,t]) = yes;

#Set to control which export elements to calibrate 
parameter d1X_y_notthese[x,s,t];
d1X_y_notthese[x,'20000',t] = yes;
d1X_y_notthese[x,'16000',t] = yes; #We don't calibrate wood industries 
d1X_y_notthese[x,'53000',t] = yes;
d1X_y_notthese[x,'51001',t] = yes; 


#Create parameter to control calibration
PARAMETER psi; psi = 1;


tFadeOut.l['2023'] = 1;
tFadeOut.l['2024'] = 1-1/7;
tFadeOut.l['2025'] = 1-2/7;
tFadeOut.l['2026'] = 1-3/7;
tFadeOut.l['2027'] = 1-4/7;
tFadeOut.l['2028'] = 1-5/7;
tFadeOut.l['2029'] = 1-6/7;
tFadeOut.l['2030'] = 0;

tFadeOut_2030_2050.l[t]$(tMediumLongTerm[t]) = 1-(t.val-2030)/(2050-2030);
#====================================================================================================================================================================================================================#
# 1) Creation of new variables 
#====================================================================================================================================================================================================================#

$GROUP G_calibrate2_KP_or_MAKRO 
	adj_sX_y[maks,t]  "Variable used to adjust model exports to KF21"
	pX_y_GR2KP[maks,t] "Price index of export. GreenREFORM exports mapped to MAKRO-sectors"
	qX_y_GR2KP[Maks,t] "Quantity index of exports. GreenREFORM exports mapped to MAKRO-sectors"
	vX_y_GR2KP[Maks,t] "Value of exports. GreenREFORM exports mapped to MAKRO-sectors"
	adj_xTur[t] "Variable used to adjust exports to tourists in calibration to KF21"
	adj_sX_m[t] "Variable used to adjust imports to re-export in calibration to KF21"
	vRxE_m_GR2KP[maks,makss,t] "Value of imports to sectors, mapped to MAKRO-sectors"
	pRxE_m_GR2KP[maks,makss,t] "Price index of imports, mapped to MAKRO-sectors"
	qRxE_m_GR2KP[maks,makss,t] "Quantity index of imports, mapped to MAKRO-sectors"
	adj_sRxE_m[maks,makss,t] "Variable used to adjust improt to KF21"
	pX_m_GR2KP[t] "Price index of imports to re-export"
	qX_m_GR2KP[t] "Quantity index of imports to-reexport"
	vX_m_GR2KP[t] "Value of imports to re-export"
	adj_M[t] ""
;


#=============================================================================================================================================================================================#
# 2) Creation of price/quantity-indeces  
#=============================================================================================================================================================================================#

#Parameters for new price/quantity-indeces
PARAMETER ExtFor_qXy_maks[Maks,t], ExtFor_vXy_maks[Maks,t], ExtFor_pXy_maks[maks,t], ExtFor_lXy_maks[Maks,t], ExtFor_pXm_2GR[t], ExtFor_qXm_2GR[t], ExtFor_vXm_2GR[t];

#We aggregate out the export-groups in MAKRO/ADAM to arrive at a level we can compare to GreeREFORM

ExtFor_pXy_maks[maks,t] = 1; #Inital value
#We create export variable in current as well as last years prices. 
$FOR {s} in ['udv','fre','ene','tje','soe','bol','off']:
	ExtFor_vXy_maks['{s}',t] = ExtFor_vIOy['xTje','{s}',t]   + ExtFor_vIOy['xVar','{s}',t] + ExtFor_vIOy['xSoe','{s}',t];
	ExtFor_lXy_maks['{s}',t] = ExtFor_pIOy['xTje','{s}',t-1] * ExtFor_qIOy['xTje','{s}',t] + ExtFor_pIOy['xVar','{s}',t-1] * ExtFor_qIOy['xVar','{s}',t] + ExtFor_pIOy['xSoe','{s}',t-1] * ExtFor_qIOy['xSoe','{s}',t];
$ENDFOR 

#Creation of price/quantity-indeces for exports
LOOP(t$(t.val >=2010),
	ExtFor_pXy_maks[Maks,t]$ExtFor_lXy_maks[Maks,t] = ExtFor_pXy_maks[Maks,t-1] * ExtFor_vXy_maks[Maks,t]/ExtFor_lXy_maks[Maks,t];
	ExtFor_qXy_maks[Maks,t]$ExtFor_pXy_maks[Maks,t] = ExtFor_vXy_maks[Maks,t]/ExtFor_pXy_maks[Maks,t]; 
	);

	parameter whodat[maks,t];
	
	#Inital values
	pX_y_GR2KP.l[Maks,t] = 1; pX_m_GR2KP.l[t] = 1;
	loop(t$(tx0[t]),
	qX_y_GR2KP.l[Maks,t]$(not (sameas[maks,'bol'] or sameas[Maks,'ene']))                 = sum(s$(Maks2s(Maks,s) and d1X_y['xOth',s,t]), pX_y.l['xOth',s,t-1] * qX_y.l['xOth',s,t])/pX_y_GR2KP.l[Maks,t-1];
	pX_y_GR2KP.l[Maks,t]$(not (sameas[maks,'bol'] or sameas[Maks,'ene']))                 = sum(s$(Maks2s(Maks,s) and d1X_y['xOth',s,t]), pX_y.l['xOth',s,t] * qX_y.l['xOth',s,t])/qX_y_GR2KP.l[Maks,t];
	vX_y_GR2KP.l[Maks,t]$(not (sameas[maks,'bol'] or sameas[Maks,'ene'])) = pX_y_GR2KP.l[Maks,t] * qX_y_GR2KP.l[Maks,t];
	);



#For import to re-exports we create price/quantity-indeces.
ExtFor_pXm_2GR[t] = 1;
ExtFor_vXm_2GR[t] = ExtFor_pXm['xVar',t]*ExtFor_qXm['xVar',t] + ExtFor_pXm['xSoe',t]*ExtFor_qXm['xSoe',t] + ExtFor_pXm['xTje',t]*ExtFor_qXm['xTje',t];
LOOP(t$(t.val >=2010),
ExtFor_qXm_2GR[t] = (ExtFor_pXm['xVar',t-1]*ExtFor_qXm['xVar',t] + ExtFor_pXm['xSoe',t-1]*ExtFor_qXm['xSoe',t] + ExtFor_pXm['xTje',t-1]*ExtFor_qXm['xTje',t])/ExtFor_pXm_2GR[t-1];
ExtFor_pXm_2GR[t] = ExtFor_vXm_2GR[t]/ExtFor_qXm_2GR[t];
	);

	#Inital values
	LOOP(t$(tx0[t]),
	qX_m_GR2KP.l[t] = sum((x,s)$(d1X_m[x,s,t]), pX_m.l[x,s,t-1]*qX_m.l[x,s,t])/pX_m_GR2KP.l[t-1];
	pX_m_GR2KP.l[t] = sum((x,s)$(d1X_m[x,s,t]), pX_m.l[x,s,t]*qX_m.l[x,s,t])/qX_m_GR2KP.l[t];
	vX_m_GR2KP.l[t] = pX_m_GR2KP.l[t] * qX_m_GR2KP.l[t];
	);




#Aggregate GR imports to MAKRO/ADAM-sectors
vRxE_m_GR2KP.l[Maks,Maksss,t] = sum(makss$Maks2impgroup(Makss,Maksss),sum((r,s)$(Maks2s(Maks,r) and Maks2s(Makss,s) and d1RxE_m[r,s,t]), vRxE_m.l[r,s,t]));
pRxE_m_GR2KP.l[maks,maksss,t]$(vRxE_m_GR2KP.l[maks,maksss,t]) = 1;

	#Inital values
	LOOP(t$(tx0[t]),
	qRxE_m_GR2KP.l[maks,maksss,t]$vRxE_m_GR2KP.l[Maks,maksss,t] = sum(makss$Maks2impgroup(Makss,Maksss), sum((r,s)$(Maks2s(Maks,r) and Maks2s(Makss,s) and d1RxE_m[r,s,t]), pRxE_m.l[r,s,t-1]*qRxE_m.l[r,s,t]))/pRxE_m_GR2KP.l[maks,maksss,t-1];
	pRxE_m_GR2KP.l[maks,maksss,t]$vRxE_m_GR2KP.l[Maks,maksss,t] = vRxE_m_GR2KP.l[maks,maksss,t]/qRxE_m_GR2KP.l[maks,maksss,t];
	);

#=============================================================================================================================================================================================#
# 2.2) Print pre- and MAKRO-values to calibrate2_output-parameter
#=============================================================================================================================================================================================#

Parameter calibrate2_output;

calibrate2_output['qGDP',t,'MAKRO']$ (t.val ge t1.val) = ExtFor_qBNP[t] * qGDP.l[t1]/ExtFor_qBNP[t1];
calibrate2_output['qGDP',t,'GRpre']$ (t.val ge t1.val) = qGDP.l[t];
calibrate2_output['qCtot',t,'MAKRO']$ (t.val ge t1.val) = ExtFor_qC['ctot',t] * qCHH.l['ctot',t1]/ExtFor_qC['ctot',t1];
calibrate2_output['qCtot',t,'GRpre']$ (t.val ge t1.val) = qCHH.l['cTot',t];
calibrate2_output['qG',t,'MAKRO']$ (t.val ge t1.val) = ExtFor_qG['Gtot',t] * qG.l['Gtot',t1]/ExtFor_qG['Gtot',t1];
calibrate2_output['qG',t,'GRpre']$ (t.val ge t1.val) = qG.l['Gtot',t];
calibrate2_output['qX',t,'MAKRO']$ (t.val ge t1.val) = sum(maks,ExtFor_qXy_maks[maks,t]) * sum(maks,qX_y_GR2KP.l[maks,t1])/sum(maks,ExtFor_qXy_maks[maks,t1]);
calibrate2_output['qX',t,'GRpre']$ (t.val ge t1.val) = sum(maks,qX_y_GR2KP.l[maks,t]);

calibrate2_output['pGDP',t,'MAKRO']$ (t.val ge t1.val) = ExtFor_vGDP[t]/ExtFor_qBNP[t] * vGDP.l[t1]/qGDP.l[t1]/ExtFor_vGDP[t1]*ExtFor_qBNP[t1];
calibrate2_output['pGDP',t,'GRpre']$ (t.val ge t1.val) = vGDP.l[t]/qGDP.l[t];
calibrate2_output['w',t,'MAKRO']$ (t.val ge t1.val) = ExtFor_vhw[t] * w.l[t1]/ExtFor_vHw[t1];
calibrate2_output['w',t,'GRpre']$ (t.val ge t1.val) = w.l[t];

calibrate2_output['qCCar',t,'MAKRO']$ (t.val ge t1.val) = ExtFor_qC['cBil',t] * qCHH.l['cCar',t1]/ExtFor_qC['cBil',t1];
calibrate2_output['qCCar',t,'GRpre']$ (t.val ge t1.val) = qCHH.l['cCar',t];
calibrate2_output['qCtou',t,'MAKRO']$ (t.val ge t1.val) = ExtFor_qC['ctur',t] * qCHH.l['ctou',t1]/ExtFor_qC['ctur',t1];
calibrate2_output['qCtou',t,'GRpre']$ (t.val ge t1.val) = qCHH.l['cTou',t];
calibrate2_output['qCGoo',t,'MAKRO']$ (t.val ge t1.val) = ExtFor_qC['cVar',t] * qCHH.l['cGoo',t1]/ExtFor_qC['cVar',t1];
calibrate2_output['qCGoo',t,'GRpre']$ (t.val ge t1.val) = qCHH.l['cGoo',t];

#  calibrate2_output['qCEne',t,'MAKRO']$ (t.val ge t1.val) = ExtFor_qC['cEne',t] * qCHH.l['cEne',t1]/ExtFor_qC['cEne',t1];
#  calibrate2_output['qCEne',t,'GRpre']$ (t.val ge t1.val) = qCHH.l['cEne',t];
calibrate2_output['qCCarEne',t,'MAKRO']$ (ExtFor_qC['cENE',t] and (t.val ge t1.val)) = ExtFor_qC['cENE',t] * qCHH.l['cCarEne',t1]/ExtFor_qC['cENE',t1];
calibrate2_output['qCCarEne',t,'GRpre']$ (t.val ge t1.val) = qCHH.l['cCarEne',t];
calibrate2_output['qCHouEne',t,'MAKRO']$ (ExtFor_qC['cENE',t] and (t.val ge t1.val)) = ExtFor_qC['cENE',t] * qCHH.l['cHouEne',t1]/ExtFor_qC['cENE',t1];
calibrate2_output['qCHouEne',t,'GRpre']$ (t.val ge t1.val) = qCHH.l['cHouEne',t];

calibrate2_output['qCSer',t,'MAKRO']$ (t.val ge t1.val) = ExtFor_qC['cTje',t] * qCHH.l['cSer',t1]/ExtFor_qC['cTje',t1];
calibrate2_output['qCSer',t,'GRpre']$ (t.val ge t1.val) = qCHH.l['cSer',t];
calibrate2_output['qCHou',t,'MAKRO']$ (t.val ge t1.val) = ExtFor_qC['cBol',t] * qCHH.l['cHou',t1]/ExtFor_qC['cBol',t1];
calibrate2_output['qCHou',t,'GRpre']$ (t.val ge t1.val) = qCHH.l['cHou',t];

calibrate2_output['qXfre',t,'MAKRO']$ (t.val ge t1.val) = ExtFor_qXy_maks['fre',t] * qX_y_GR2KP.l['fre',t1]/ExtFor_qXy_maks['fre',t1];
calibrate2_output['qXfre',t,'GRpre']$ (t.val ge t1.val) = qX_y_GR2KP.l['fre',t];
calibrate2_output['qXtje',t,'MAKRO']$ (t.val ge t1.val) = ExtFor_qXy_maks['tje',t] * qX_y_GR2KP.l['tje',t1]/ExtFor_qXy_maks['tje',t1];
calibrate2_output['qXtje',t,'GRpre']$ (t.val ge t1.val) = qX_y_GR2KP.l['tje',t];
calibrate2_output['qXsoe',t,'MAKRO']$ (t.val ge t1.val) = ExtFor_qXy_maks['soe',t] * qX_y_GR2KP.l['soe',t1]/ExtFor_qXy_maks['soe',t1];
calibrate2_output['qXsoe',t,'GRpre']$ (t.val ge t1.val) = qX_y_GR2KP.l['soe',t];
#  calibrate2_output['qXlan',t,'MAKRO']$ (t.val ge t1.val) = ExtFor_qXy_maks['lan',t] * qX_y_GR2KP.l['lan',t1]/ExtFor_qXy_maks['lan',t1];
calibrate2_output['qXlan',t,'GRpre']$ (t.val ge t1.val) = qX_y_GR2KP.l['lan',t];


calibrate2_output['qCtotY',t,'MAKRO']$ (t.val ge t1.val) = ExtFor_qC['ctot',t] / ExtFor_qBNP[t];
calibrate2_output['qCtotY',t,'GRpre']$ (t.val ge t1.val) = qCHH.l['cTot',t] / qGDP.l[t];
calibrate2_output['qGY',t,'MAKRO']$ (t.val ge t1.val) = ExtFor_qG['Gtot',t] / ExtFor_qBNP[t];
calibrate2_output['qGY',t,'GRpre']$ (t.val ge t1.val) = qG.l['Gtot',t] / qGDP.l[t];
calibrate2_output['qIY',t,'MAKRO']$ (t.val ge t1.val) = sum(s_, ExtFor_qI_s['Itot',s_,t]) / ExtFor_qBNP[t];
calibrate2_output['qIY',t,'GRpre']$ (t.val ge t1.val) = qI.l['Itot',t] / qGDP.l[t];
calibrate2_output['qXY',t,'MAKRO']$ (t.val ge t1.val) = ExtFor_qX['Xtot',t] / ExtFor_qBNP[t];
calibrate2_output['qXY',t,'GRpre']$ (t.val ge t1.val) = qX.l['xtot',t] / qGDP.l[t];
#  calibrate2_output['qMY',t,'MAKRO']$ (t.val ge t1.val) = ExtFor_qM['tot',t] / ExtFor_qBNP[t]; 
calibrate2_output['qMY',t,'GRpre']$ (t.val ge t1.val) = qM.l['tot',t] / qGDP.l[t];



#  #=============================================================================================================================================================================================#
#  # KORRIGERER KP21-variable til 2015-niveau
#  #=============================================================================================================================================================================================#

#  $FOR {r} in ['lan','udv','fre','ene','tje','soe','bol','off']:
#  	$FOR1 {s} in ['tje','fre','ene','udv']:
		
#  		ExtFor_qIOm['{r}','{s}',t]$(ExtFor_qIOm['{r}','{s}','2015']) = ExtFor_qIOm['{r}','{s}',t]/ExtFor_qIOm['{r}','{s}','2015'] * ExtFor_vIOm['{r}','{s}','2015']*fv**5;
#  		ExtFor_pIOm['{r}','{s}',t]$(ExtFor_pIOm['{r}','{s}','2015']) = ExtFor_pIOm['{r}','{s}',t]/ExtFor_pIOm['{r}','{s}','2015'];
#  		ExtFor_vIOm['{r}','{s}',t] = ExtFor_vIOm['{r}','{s}',t]*fv**5; 
		
#  	$ENDFOR1
#  $ENDFOR

PARAMETER d1exemptthis_m[r,s,t];
d1exemptthis_m[r,s,t] = no;
d1exemptthis_m[r,s,t] = yes;
#  d1exemptthis_m['13150',s,t] = no; #Maskinindustri (280 mia.)
#  d1exemptthis_m['25000',s,t] = no; #Farma (116 mia.)

set dontexempthese_m[s]/45000,46000,47000,55560,64000,71000,49509,off/;

d1exemptthis_m['45000',dontexempthese_m,t] = no; #Bilhandel (51 mia.)
d1exemptthis_m['46000',dontexempthese_m,t] = no; #Engros (322 mia.)
d1exemptthis_m['47000',dontexempthese_m,t] = no; #Detail (106.)
d1exemptthis_m['55560',dontexempthese_m,t] = no; #Service til forbrugere (272 mia.)
d1exemptthis_m['64000',dontexempthese_m,t] = no; #Finansiel service (187 mia.)
d1exemptthis_m['71000',dontexempthese_m,t] = no; #Service til erhverv og eksport (541 mia.)
d1exemptthis_m['49509',dontexempthese_m,t] = no; #Mærsk (+) (268 mia.)
d1exemptthis_m['off',  dontexempthese_m,t] = no; #Off, (641 mia.)


#  d1exemptthis_m['01020',s,t] = yes; # No adjustment of horticulture
#  d1exemptthis_m['20000',s,t] = yes; # No adjustment of chemical industry because of the significant input to agriculture
#  d1exemptthis_m[agri_sectors,s,t] = yes;
#  d1exemptthis_m['01080',s,t] = yes;
#  d1exemptthis_m[r,agri_sectors,t] = yes;
#  d1exemptthis_m[r,'01080',t] = yes;
#  d1exemptthis_m['41430',s,t] = yes;
#  d1exemptthis_m[r,'41430',t] = yes;


#  d1exemptthis_m[foodprocessingSectors,s,t] = yes;
#  d1exemptthis_m[r,FoodProcessingSectors,t] = yes;
#  d1exemptthis_m[r,'02000',t] = yes;
#  d1exemptthis_m['13150',s,t] = yes;





#=============================================================================================================================================================================================#
# 3) Calibration to MAKRO/KF21
#=============================================================================================================================================================================================#


$BLOCK B_calibrate_to_KP_or_MAKRO

	#EXPORTS
		#Exports are aggregated to a level, where they can be compared to KF/MAKRO 
		E_qX_y_2_KP21[Maks,t]$(tx0[t] and qX_y_GR2KP.l[Maks,t] and d1IncludeThese[maks])..
			pX_y_GR2KP[Maks,t-1] * qX_y_GR2KP[Maks,t] =E= sum(s$(Maks2s(Maks,s) and d1X_y['xOth',s,t]), pX_y['xOth',s,t-1]$(d1X_y['xOth',s,t-1]) * qX_y['xOth',s,t]);

		E_vX_y_2_KP21[Maks,t]$(tx0[t] and qX_y_GR2KP.l[Maks,t] and d1IncludeThese[maks]).. 
			vX_y_GR2KP[Maks,t] =E= sum(s$(Maks2s(Maks,s) and d1X_y['xOth',s,t]), pX_y['xOth',s,t] * qX_y['xOth',s,t]);

		
		E_pX_y_2_KP21[Maks,t]$(tx0[t] and qX_y_GR2KP.l[maks,t] and d1IncludeThese[maks])..
			pX_y_GR2KP[Maks,t] =E= vX_y_GR2KP[Maks,t]/qX_y_GR2KP[Maks,t];


		#  #We create quations that says the growth-rate of the export-component of GreenREFORM should follow that of MAKRO. This equation thereby determine the variable "adj_sX_y"
		$FOR {s} in ['soe','tje','fre']: #,'soe']: # 'lan'
			E_qX_y_tofollow_{s}[t]$(tx1[t])..
				qX_y_GR2KP['{s}',t]/qX_y_GR2KP['{s}',t-1] =E=  psi *ExtFor_qXy_maks['{s}',t]/ExtFor_qXy_maks['{s}',t-1] 
														+ (1-psi)*qX_y_GR2KP.l['{s}',t]/qX_y_GR2KP.l['{s}',t-1]; 
		$ENDFOR


		E_sX_y_tofollow_tje[x,sTje,t]$(tx1[t] and d1X_y[x,sTje,t] and not d1X_y_notthese[x,sTje,t])..
			#  sX_y[x,sTje,t] =E= sX_y.l[x,sTje,t] * adj_sX_y['tje',t];
			qX_y[x,sTje,t] =E= qX_y.l[x,sTje,t] * adj_sX_y['tje',t];

		#AKB: We only adjust non-food processing sectors, because food processing sectors are used in calibration of agricultural module. This could mean that non-food processing sectors need to take a larger part of the adjustment.
		E_sX_y_tofollow_fre[x,sFreXFoodProcess,t]$(tx1[t] and d1X_y[x,sFreXFoodProcess,t] and not d1X_y_notthese[x,sFreXFoodProcess,t])..
			sX_y[x,sFreXFoodProcess,t] =E= sX_y.l[x,sFreXFoodProcess,t] * adj_sX_y['fre',t];

		E_sX_y_tofollow_soe[x,sSoe,t]$(tx1[t] and d1X_y[x,sSoe,t] and not d1X_y_notthese[x,sSoe,t])..
			sX_y[x,sSoe,t] =E= sX_y.l[x,sSoe,t] * adj_sX_y['soe',t];

	#  #Import to re-export
		E_qX_m_2_KP21[t]$(tx0[t])..
		    pX_m_GR2KP[t-1] * qX_m_GR2KP[t] =E=  sum((x,s)$(d1X_m[x,s,t]), pX_m[x,s,t-1]$(d1x_m[x,s,t-1]) * qX_m[x,s,t]);

		E_vX_m_2_KP21[t]$(tx0[t])..
			vX_m_GR2KP[t] =E=  sum((x,s)$(d1X_m[x,s,t]), pX_m[x,s,t] * qX_m[x,s,t]);
		
		E_pX_m_2_KP21[t]$(tx0[t]).. 
			vX_m_GR2KP[t] =E= pX_m_GR2KP[t] * qX_m_GR2KP[t];


		E_qX_m_tofollow[t]$(tx1[t])..
			qX_m_GR2KP[t]/qX_m_GR2KP[t-1] =E= psi * ExtFor_qXm_2GR[t]/ExtFor_qXm_2GR[t-1]	+ (1-psi) * qX_m_GR2KP.l[t]/qX_m_GR2KP.l[t-1];
		

		E_sX_m_tofollow[x,s,t]$(tx1[t] and d1X_m[x,s,t])..
			sX_m[x,s,t] =E= sX_m.l[x,s,t]*adj_sX_m[t];


		#Exports to tourists
		E_qX_tur_tofollow[t]$(tx1[t])..
			qX['xTur',t]/qX['xTur',t-1] =E= psi * ExtFor_qX['xTur',t]/ExtFor_qX['xTur',t-1] + (1-psi) * qX.l['xTur',t]/qX.l['xTur',t-1];


		E_sX_tur[t]$(tx1[t])..
			sX_tur[t] =E= sX_tur.l[t] * adj_xTur[t];


		E_qG_tot_tofollow[t]$(tx1[t])..
			qG['gtot',t]/qG['gtot',t-1] =E= ExtFor_qG['gtot',t]/ExtFor_qG['gtot',t-1];


		E_wage_by_m[r,s,t]$(tx1[t] and d1RxE_m[r,s,t] and not d1exemptthis_m[r,s,t])..  #Including 50001 and 50002 seemingly lead to a too large productivity boost for 50002, which in turn spills into 50001 when model is shocked and causes prices in 50001 to go below zero
			sRxE_m[r,s,t] =E= sRxE_m.l[r,s,t] * adj_M[t];

		
	#IMPORTS TO PRODUCTION
		E_vRxE_m_GR2KP[Maks,Makss,t]$(tx0[t] and vRxE_m_GR2KP.l[Maks,Makss,t]).. 
			vRxE_m_GR2KP[Maks,Makss,t] =E= sum(maksss$Maks2impgroup(Maksss,Makss), sum((r,s)$(Maks2s(Maks,r) and Maks2s(Maksss,s) and d1RxE_m[r,s,t]), vRxE_m[r,s,t]));

		E_qRxE_m_GR2KP[Maks,makss,t]$(tx0[t] and vRxE_m_GR2KP.l[Maks,Makss,t])..
			pRxE_m_GR2KP[Maks,makss,t-1] * qRxE_m_GR2KP[Maks,makss,t] =E= sum(maksss$Maks2impgroup(Maksss,Makss), sum((r,s)$(Maks2s(Maks,r) and Maks2s(Maksss,s) and d1RxE_m[r,s,t]), pRxE_m[r,s,t-1]$(d1RxE_m[r,s,t-1]) * qRxE_m[r,s,t]));

		E_pRxE_m_GR2KP[Maks,Makss,t]$(tx0[t] and vRxE_m_GR2KP.l[Maks,Makss,t])..
			pRxE_m_GR2KP[Maks,makss,t]*qRxE_m_GR2KP[Maks,makss,t] =E= vRxE_m_GR2KP[Maks,makss,t];

			

	E_vWealth_ShortTerm[t]$(tShortTerm[t]).. vWealth[t] * ExtFor_qBNP[t] =E= ExtFor_vWealth['tot',t] * qGDP[t];
	E_vWealth_End[t]$(tEnd[t])..             vWealth[t] * ExtFor_qBNP[t] =E= ExtFor_vWealth['tot',t] * qGDP[t];	


$ENDBLOCK

$BLOCK B_ConsumptionNest_partial_calib
	E_qCHH_calib[cNest_MAKRO,t]$(tx1[t] and not sameas[cNest_MAKRO,'cCarSer'])..
		pCHH[cNest_MAKRO,t-1]*qCHH[cNest_MAKRO,t] =E= sum(c_$cNest2c_[cNest_MAKRO,c_], pCHH[c_,t-1]*qCHH[c_,t]);

	E_qCHH_calib_cCarSer[cNest_MAKRO,t]$(tx1[t] and sameas[cNest_MAKRO,'cCarSer'])..
		pCHH[cNest_MAKRO,t-1]*qCHH[cNest_MAKRO,t] =E= pCHH['cCarEne',t-1]*qCHH['cCarEne',t] + pCHH['cCar',t-1] * qCHH['cCar',t-1]/fq;


$ENDBLOCK


$MODEL M_ConsumptionNest_partial 
	E_pCHH_cCar	
	E_qC_cCars
	E_qC_cCars_tEnd
	E_pCHH_nests
	E_pCHH_nests_cCarSer
	E_qCHH
	E_qCHH_cars
;

$GROUP G_ConsumptionNest_partial_endo
	qCHH$(tx0[t] and not sameas[c_,'ctot'])
	qC$(tx0[t] and sameas[c_,'cCar'])
	-qCHH$(t1[t] and sameas[c_,'cCar'])
	pCHH$(cNest(c_))
	pCHH$(tx0[t] and sameas[c_,'cCar'])

;  

$GROUP G_ConsumptionNest_partial_exo
	qCHH$(tx0[t] and sameas[c_,'ctot'])
	qCHH$(t1[t] and sameas[c_,'cCar'])
	pCHH$(not cNest(c_))
	pCHH$(t0[t])
	qCHH$(t0[t])
	pC
;  

$FIX G_ConsumptionNest_partial_exo;
$UNFIX G_ConsumptionNest_partial_endo;
@Solve(M_ConsumptionNest_partial,1);
#  execute_unload 'output\ConsumptionNest_partial.gdx';



# Calibration to MAKRO for partial consumption nest
$MODEL M_ConsumptionNest_partial_calib M_ConsumptionNest_partial, B_ConsumptionNest_partial_calib;

$GROUP G_ConsumptionNest_partial_endo
	G_ConsumptionNest_partial_endo
	uC$(tx1[t] and c_MAKRO_(c_) and not sameas[c_,'cCar']), -qCHH$(tx1[t] and c_MAKRO(c_) and not sameas[c_,'ctot'] and not sameas[c_,'cCar'])
	uC$(tx1[t] and not t2[t] and sameas[c_,'cCar'])
	qCHH$(tx1[t] and sameas[c_,'cCar']), -qC$(tx1[t] and not tEnd[t] and sameas[c_,'cCar'])
;  

$GROUP G_ConsumptionNest_partial_exo
	G_ConsumptionNest_partial_exo
	-uC$(tx1[t] and c_MAKRO_(c_) and not sameas[c_,'cCar']), qCHH$(tx1[t] and c_MAKRO(c_) and not sameas[c_,'ctot'] and not sameas[c_,'cCar'])
	-uC$(tx1[t] and not t2[t] and sameas[c_,'cCar'])
	-qCHH$(tx1[t] and sameas[c_,'cCar']), qC$(tx1[t] and not tEnd[t] and sameas[c_,'cCar'])
;  
 	
loop(t$(tx0[t]),
qC.FX['cCar',t+1]             						    = qC.l['cCar',t]    * ExtFor_qC['cBil',t+1]/ExtFor_qC['cBil',t];
qCHH.FX['cTou',t+1]             						= qCHH.l['cTou',t]    * ExtFor_qC['cTur',t+1]/ExtFor_qC['cTur',t];
qCHH.FX['cGoo',t+1]             						= qCHH.l['cGoo',t]    * ExtFor_qC['cVar',t+1]/ExtFor_qC['cVar',t];
qCHH.FX['cCarEne',t+1]						            = qCHH.l['cCarEne',t] * ExtFor_qC['cENE',t+1]/ExtFor_qC['cEne',t];
qCHH.FX['cHouEne',t+1]						            = qCHH.l['cHouEne',t] * ExtFor_qC['cENE',t+1]/ExtFor_qC['cEne',t];
qCHH.FX['cSer',t+1]             						= qCHH.l['cSer',t]    * ExtFor_qC['cTje',t+1]/ExtFor_qC['cTje',t];
qCHH.FX['cHou',t+1]             						= qCHH.l['cHou',t]    * ExtFor_qC['cBol',t+1]/ExtFor_qC['cBol',t];
qCHH.FX['cTot',t+1]          							= qCHH.l['cTot',t]    * ExtFor_qC['cTot',t+1]/ExtFor_qC['cTot',t];
);

#  execute_unload 'output\ConsumptionNest_partial_calib_pre.gdx';
$FIX G_ConsumptionNest_partial_exo;
$UNFIX G_ConsumptionNest_partial_endo;
@Solve(M_ConsumptionNest_partial_calib);
#  execute_unload 'output\ConsumptionNest_partial_calib.gdx';
#  $exit
$MODEL M_dynamic_calibration_calib2ExtFor
	M_dynamic_calibration_agr 
	# M_dynamic_calibration_cement
	M_endolandlinks_calib
	B_calibrate_to_KP_or_MAKRO
	B_ConsumptionNest_partial_calib
	-E_ConstantvWealth
;



$GROUP G_dynamic_calibration_endo
	G_dynamic_calibration_endo
	G_endolandlinks_calib_endo
	sX_y$(tx1[t] and d1X_y[x,s,t] and sSoe[s] and not d1X_y_notthese[x,s,t])
	sX_y$(tx1[t] and d1X_y[x,s,t] and sTje[s] and not d1X_y_notthese[x,s,t])
	sX_y$(tx1[t] and d1X_y[x,s,t] and sFreXFoodProcess[s] and not d1X_y_notthese[x,s,t])
	adj_sX_y$(tx1[t] and sameas[maks,'soe'])
	adj_sX_y$(tx1[t] and sameas[maks,'tje'])
	adj_sX_y$(tx1[t] and sameas[maks,'fre'])

	sX_tur$(tx1[t]), adj_xTur$(tx1[t])
	sX_m$(tx1[t] and d1X_m[x,s,t])

	#Privatforbrug
	uC$(tx1[t] and c_MAKRO_[c_] and not sameas[c_,'cCar']), -qCHH$(tx1[t]and c_MAKRO[c_] and not sameas[c_,'cCar'] and not sameas[c_,'ctot'])
	uC$(tx1[t] and not t2[t] and sameas[c_,'cCar']), -qC$(tx1[t] and not tEnd[t] and sameas[c_,'cCar']), qCHH$(tx1[t] and sameas[c_,'cCar'])
	shareC$(tx1[t]), -qCHH$(tx1[t] and sameas[c_,'ctot'])

	uvGxDepr$(tx1[t])
	-qGDP, prod_a
	-w$(tx1[t]), adj_M$(tx1[t]), sRxE_m$(tx1[t] and d1RxE_m[r,s,t] and not d1exemptthis_m[r,s,t])

	JvWealth_ShortTerm$(tShortTerm[t])

;




$GROUP G_dynamic_calibration_exo 
	G_dynamic_calibration_exo
	G_endolandlinks_calib_exo
	pX_y_GR2KP$(t0[t])
	pRxE_m$(t0[t] and d1RxE_m[r,s,t])
	pRxE_m_GR2KP$(t0[t])
	pRxE_m$(t0[t])
	pX_m_GR2KP$(t0[t])

	#Privatforbrug
	-uC$(tx1[t]and c_MAKRO_[c_] and not sameas[c_,'cCar']), qCHH$(tx1[t] and c_MAKRO[c_] and not sameas[c_,'cCar'] and not sameas[c_,'ctot'])
	-uC$(tx1[t] and not t2[t] and sameas[c_,'cCar']), qC$(tx1[t] and not tEnd[t] and sameas[c_,'cCar']), -qCHH$(tx1[t] and sameas[c_,'cCar'])
	-shareC$(tx1[t]), qCHH$(tx1[t] and sameas[c_,'ctot'])


	-uvGxDepr$(tx1[t])
	qGDP, -prod_a
	w$(tx1[t]), -adj_M$(tx1[t]), -sRxE_m$(tx1[t] and d1RxE_m[r,s,t] and not d1exemptthis_m[r,s,t])

	-JvWealth_ShortTerm$(tShortTerm[t])
;

#Minkene gør kalibreringen ustabil. Da vi alligevel allerhelst skal have lukket branchen på sigt holder vi efterspørgslen fast.
$GROUP G_dynamic_calibration_endo
	G_dynamic_calibration_endo
	-qY_CET$(d1vY_CET[out,s,t] and sameas[s,'01070'])
	sX_y$(d1x_y[x,s,t] and sameas[x,'xOth'] and sameas[s,'01070'])
;

$GROUP G_dynamic_calibration_exo
	G_dynamic_calibration_exo
	qY_CET$(d1vY_CET[out,s,t] and sameas[s,'01070'])
	-sX_y$(d1x_y[x,s,t] and sameas[x,'xOth'] and sameas[s,'01070'])
;



$FIX G_dynamic_calibration_exo;
$UNFIX G_dynamic_calibration_endo;
#  execute_unload 'output\pre.gdx';


PARAMETER psi;
#  $FOR {psi} in ['0.1','0.25','0.5','0.75','1']:
$FOR {psi} in ['0.5','1']:

	psi = {psi};
	loop(t$(tx0[t]),

	pM_CET.FX['out_other',sBOL,t+1]                        = psi *  pM_CET.l['out_other',sBOL,t]   * ExtFor_pM['Fre',t+1]/ExtFor_pM['Fre',t] + (1-psi) * pM_CET.l['out_other',sBOL,t];
	pM_CET.FX['out_other',sBYG,t+1]                        = psi *  pM_CET.l['out_other',sBYG,t]   * ExtFor_pM['tje',t+1]/ExtFor_pM['tje',t] + (1-psi) * pM_CET.l['out_other',sBYG,t];
	#  pM_CET.FX['out_other',sSoe,t+1]                     = psi *  pM_CET.l['out_other',sSOe,t]   * ExtFor_pM['tje',t+1]/ExtFor_pM['tje',t] + (1-psi) * pM_CET.l['out_other',sSOe,t];
	pM_CET.FX['out_other',sENE,t+1]                        = psi *  pM_CET.l['out_other',sENE,t]   * ExtFor_pM['Fre',t+1]/ExtFor_pM['Fre',t] + (1-psi) * pM_CET.l['out_other',sENE,t];
	pM_CET.FX['out_other',sTjeX,t+1]$(NOT sameas[sTjeX,'45000'])   = psi *  pM_CET.l['out_other',sTjeX,t]   * ExtFor_pM['Tje',t+1]/ExtFor_pM['Tje',t] + (1-psi) * pM_CET.l['out_other',sTjeX,t];
	#  pM_CET.FX['out_other',sUDV,t+1]                     = psi *  pM_CET.l['out_other',sUDV,t]   * ExtFor_pM['Tje',t+1]/ExtFor_pM['Tje',t] + (1-psi) * pM_CET.l['out_other',sUDV,t];
	#  pM_CET.FX['out_other',sOFF,t+1]                     = psi *  pM_CET.l['out_other',sOFF,t]   * ExtFor_pM['Tje',t+1]/ExtFor_pM['Tje',t] + (1-psi) * pM_CET.l['out_other',sOFF,t];
	pM_CET.FX['out_other',sFreXFoodProcess,t+1]$(NOT sameas[sFreXFoodProcess,'13150'])   = psi *  pM_CET.l['out_other',sFreXFoodProcess,t]   * ExtFor_pM['Fre',t+1]/ExtFor_pM['Fre',t] + (1-psi) * pM_CET.l['out_other',sFreXFoodProcess,t];



	#  qC.FX['cCar',t+1]             					   		= psi *  qC.l['cCar',t]    	 * ExtFor_qC['cBil',t+1]/ExtFor_qC['cBil',t] + (1-psi) * qC.l['cCar',t];

	qCHH.FX['cTou',t+1]             						= psi *  qCHH.l['cTou',t]    * ExtFor_qC['cTur',t+1]/ExtFor_qC['cTur',t] + (1-psi) * qCHH.l['cTou',t];
	qCHH.FX['cGoo',t+1]             						= psi *  qCHH.l['cGoo',t]    * ExtFor_qC['cVar',t+1]/ExtFor_qC['cVar',t] + (1-psi) * qCHH.l['cGoo',t];
	qCHH.FX['cCarEne',t+1]						          = psi *  qCHH.l['cCarEne',t] * ExtFor_qC['cENE',t+1]/ExtFor_qC['cEne',t] + (1-psi) * qCHH.l['cCarEne',t];
	qCHH.FX['cHouEne',t+1]						          = psi *  qCHH.l['cHouEne',t] * ExtFor_qC['cENE',t+1]/ExtFor_qC['cEne',t] + (1-psi) * qCHH.l['cHouEne',t];
	qCHH.FX['cSer',t+1]             						= psi *  qCHH.l['cSer',t]    * ExtFor_qC['cTje',t+1]/ExtFor_qC['cTje',t] + (1-psi) * qCHH.l['cSer',t];
	qCHH.FX['cHou',t+1]             						= psi *  qCHH.l['cHou',t]    * ExtFor_qC['cBol',t+1]/ExtFor_qC['cBol',t] + (1-psi) * qCHH.l['cHou',t];
	qCHH.FX['cTot',t+1]         						    = psi *  qCHH.l['cTot',t]    * ExtFor_qC['cTot',t+1]/ExtFor_qC['cTot',t] + (1-psi) * qCHH.l['cTot',t];




	w.FX[t+1]                    = psi *  w.l[t]    * ExtFor_vhw[t+1]/ExtFor_vhw[t]   + (1-psi) * w.l[t];
	qGDP.FX[t+1]                 = psi *  qGDP.l[t] * ExtFor_qBNP[t+1]/ExtFor_qBNP[t] + (1-psi) * qGDP.l[t];
	);
	
  	@print("------------------------ Calibration to external forecast: Iteration {psi} -------------------------------------------------------")
  	$IF %readfromprevious%!=1:
  		# execute_unload 'output\pre.gdx';
		@Solve(M_dynamic_calibration_calib2ExtFor); 
		#  execute_unload 'output\ExtFor_calib_{psi}.gdx';
	$ENDIF
$ENDFOR


#=============================================================================================================================================================================================#
# 3.2) Print post-values to calibrate2_output-parameter
#=============================================================================================================================================================================================#

calibrate2_output['qGDP',t,'GRpost']$ (t.val ge t1.val) = qGDP.l[t];
calibrate2_output['qCtot',t,'GRpost']$ (t.val ge t1.val) = qCHH.l['cTot',t];
calibrate2_output['qG',t,'GRpost']$ (t.val ge t1.val) = qG.l['Gtot',t];
calibrate2_output['qX',t,'GRpost']$ (t.val ge t1.val) = sum(maks,qX_y_GR2KP.l[maks,t]);

calibrate2_output['pGDP',t,'GRpost']$ (t.val ge t1.val) = vGDP.l[t]/qGDP.l[t];
calibrate2_output['w',t,'GRpost']$ (t.val ge t1.val) = w.l[t];

calibrate2_output['qCCar',t,'GRpost']$ (t.val ge t1.val) = qCHH.l['cCar',t];
calibrate2_output['qCtou',t,'GRpost']$ (t.val ge t1.val) = qCHH.l['cTou',t];
calibrate2_output['qCGoo',t,'GRpost']$ (t.val ge t1.val) = qCHH.l['cGoo',t];
calibrate2_output['qCCarEne',t,'GRpost']$ (t.val ge t1.val) = qCHH.l['cCarEne',t];
calibrate2_output['qCHouEne',t,'GRpost']$ (t.val ge t1.val) = qCHH.l['cHouEne',t];
calibrate2_output['qCSer',t,'GRpost']$ (t.val ge t1.val) = qCHH.l['cSer',t];
calibrate2_output['qCHou',t,'GRpost']$ (t.val ge t1.val) = qCHH.l['cHou',t];

calibrate2_output['qXfre',t,'GRpost']$ (t.val ge t1.val) = qX_y_GR2KP.l['fre',t];
calibrate2_output['qXtje',t,'GRpost']$ (t.val ge t1.val) = qX_y_GR2KP.l['tje',t];
calibrate2_output['qXsoe',t,'GRpost']$ (t.val ge t1.val) = qX_y_GR2KP.l['soe',t];
#  calibrate2_output['qXlan',t,'GRpost']$ (t.val ge t1.val) = qX_y_GR2KP.l['lan',t];

calibrate2_output['qCtotY',t,'GRpost']$ (t.val ge t1.val) = qCHH.l['cTot',t] / qGDP.l[t];
calibrate2_output['qGY',t,'GRpost']$ (t.val ge t1.val) = qG.l['Gtot',t] / qGDP.l[t];
calibrate2_output['qIY',t,'GRpost']$ (t.val ge t1.val) = qI.l['Itot',t] / qGDP.l[t];
calibrate2_output['qXY',t,'GRpost']$ (t.val ge t1.val) = qX.l['xtot',t] / qGDP.l[t];
calibrate2_output['qMY',t,'GRpost']$ (t.val ge t1.val) = qM.l['tot',t] / qGDP.l[t];

#  execute_unload 'output\ExtFor_calib.gdx';
@assert_no_difference(G_data,%tolerance_data%);
$import check_DS.gms;