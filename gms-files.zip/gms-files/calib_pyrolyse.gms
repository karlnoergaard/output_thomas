Parameter
  sigmaPyrolyse_norm[PyrolyseTech] "Standard deviation of the normal distribution for the pyrolysis technology"
  ;


PyrolysePot.l['PyrolyseTech1',t]$(t.val = 2027)         = -90; 
PyrolysePot.l['PyrolyseTech1',t]$(t.val = 2028)         = -120; 
PyrolysePot.l['PyrolyseTech1',t]$(t.val = 2029)         = -180; 
PyrolysePot.l['PyrolyseTech1',t]$(t.val > 2029)         = -300; 

PyrolysePot.l['PyrolyseTech2',t]$(t.val = 2031)         = -100; 
PyrolysePot.l['PyrolyseTech2',t]$(t.val = 2032)         = -200; 
PyrolysePot.l['PyrolyseTech2',t]$(t.val = 2033)         = -400; 
PyrolysePot.l['PyrolyseTech2',t]$(t.val > 2033)         = -500; 

PyrolysePot.l['PyrolyseTech3',t]$(t.val = 2034)         = -200;
PyrolysePot.l['PyrolyseTech3',t]$(t.val > 2034)         = -400;

pPyrolyse.l['PyrolyseTech1',t]$(t.val >= 2027)      = 800;  # Average price per tonne of CO2 reduced with 50 production facilities
pPyrolyse.l['PyrolyseTech2',t]$(t.val >= 2031)      = 1000; # Average price per tonne of CO2 reduced with 50 production facilities
pPyrolyse.l['PyrolyseTech3',t]$(t.val >= 2034)      = 1200; # Average price per tonne of CO2 reduced with 50 production facilities
  
sigmaPyrolyse_norm['PyrolyseTech1']     = 1;
sigmaPyrolyse_norm['PyrolyseTech2']     = 75;
sigmaPyrolyse_norm['PyrolyseTech3']     = 50;

sigmaPyrolyse.l[PyrolyseTech]     = sigmaPyrolyse_norm[PyrolyseTech]/pPyrolyse.l[PyrolyseTech,'2035'];

# tSubsidy_Pyrolyse.l[PyrolyseTech,t]$(t.val > 2024)   = pPyrolyse.l[PyrolyseTech,t]*(1-5*sigmaPyrolyse.l[PyrolyseTech]); # A perfect subsidy per tonne abated
tSubsidy_Pyrolyse.l[PyrolyseTech,t]$(t.val > 2024)   = 805; 

# Depreciation rate for pyrolysis technology
rDepr_Pyrolyse.l[t]      = 1/25; # KEFM assumes that facilities have a lifespan of 25 years

# Dummy controlling the pyrolysis technology
d1PyrolysePot[PyrolyseTech,t]   = yes$(PyrolysePot.l[PyrolyseTech,t]);

# Fordeling af pyrolyseomkostninger på kapital og biomasse
shPyrolysePrice_type[PyrolyseTech,'Capital',t]$(tx0[t] and d1PyrolysePot[PyrolyseTech,t]) = 1; 
shPyrolysePrice_type[PyrolyseTech,'Biomass',t]$(tx0[t] and d1PyrolysePot[PyrolyseTech,t]) = 1 - shPyrolysePrice_type[PyrolyseTech,'Capital',t];

# Korrektion af omkostninger for investeringspris i grundscenariet (OBS: husk at ændre dette, hvis kapitalandelen er mindre en 100 pct.)
pPyrolyse.l[PyrolyseTech,t]$(tx0[t]) = pPyrolyse.l[PyrolyseTech,t]/pI_s.l['iM','01011',t];

# Initialization of the variables
rPyrolyse_gains.l[PyrolyseTech,t]$(tx0[t] and d1PyrolysePot[PyrolyseTech,t]) 
  = @max(0.00001,tSubsidy_Pyrolyse.l[PyrolyseTech,t]);

rPyrolyse_costs.l[PyrolyseTech,t]$(tx0[t] and d1PyrolysePot[PyrolyseTech,t]) 
  = shPyrolysePrice_type[PyrolyseTech,'Capital',t] * pPyrolyse.l[PyrolyseTech,t]*pI_s.l['iM','01011',t]
  + shPyrolysePrice_type[PyrolyseTech,'Biomass',t] * pPyrolyse.l[PyrolyseTech,t];


Parameter
  pPyrolyse_dist[PyrolyseTech,t] "Distributed price of the pyrolysis technology"
  ;

pPyrolyse_dist[PyrolyseTech,t]$(rPyrolyse.l[PyrolyseTech,t]) 
  = rPyrolyse_costs.l[PyrolyseTech,t] 
  * @Int_cdfLogNorm(rPyrolyse_gains.l[PyrolyseTech,t],rPyrolyse_costs.l[PyrolyseTech,t],sigmaPyrolyse.l[PyrolyseTech])
      / @cdfLogNorm(rPyrolyse_gains.l[PyrolyseTech,t],rPyrolyse_costs.l[PyrolyseTech,t],sigmaPyrolyse.l[PyrolyseTech]);


execute_unloaddi 'Output\calib_pyrolyse.gdx';