# ======================================================================================================================
# Static calibration
# ======================================================================================================================
# ----------------------------------------------------------------------------------------------------------------------
# Set time periods
# ----------------------------------------------------------------------------------------------------------------------

  set_time_periods(%cal_start%, %cal_end%);
  set_bf_calib_periods(%BF_calib_start%,%BF_calib_end%, %BF_calib_prices_start%,%BF_calib_prices_end%);
  set_lulucf_periods(1990,%terminal_year%,2021,%terminal_year%);

  #Check that demand equals supply for energi in quantities and values
  $import check_ds.gms

# ----------------------------------------------------------------------------------------------------------------------
# Import the static calibration models from the modules and combine them
# ----------------------------------------------------------------------------------------------------------------------

  @import_from_modules("static_calibration")

  $MODEL M_static_calibration
    M_taxes_static_calibration
    M_taxes_energy_static_calibration
    M_energy_markets_static_calibration
    M_aggregates_static_calibration
    M_labor_market_static_calibration
    M_government_static_calibration
    M_consumers_static_calibration
    M_exports_static_calibration
    M_IO_static_calibration
    M_production_private_static_calibration
    M_production_public_static_calibration
    M_emissions_static_calibration
    M_LULUCF_static_calibration
    M_abatement_static_calibration
    M_production_plant_static_calibration
    M_production_ani_static_calibration
    M_production_agr_static_calibration
    M_waste_static_calibration
    M_leakage_static_calibration
    M_udvaskning_static_calibration
    M_pyrolyse_static_calibration
  ;

  $GROUP G_static_calibration
    G_taxes_static_calibration
    G_taxes_energy_static_calibration
    G_energy_markets_static_calibration
    G_aggregates_static_calibration
    G_labor_market_static_calibration
    G_government_static_calibration #, qG$(gtot[g_])
    G_consumers_static_calibration #, vPersincome$(t0[t])
    G_production_private_static_calibration
    G_production_public_static_calibration
    G_IO_static_calibration
    G_exports_static_calibration
    G_emissions_static_calibration
    G_LULUCF_static_calibration 
    G_abatement_static_calibration
    G_production_plant_static_calibration
    G_production_ani_static_calibration
    G_production_agr_static_calibration
    G_waste_static_calibration
    G_leakage_static_calibration
    G_udvaskning_static_calibration
    G_pyrolyse_static_calibration
        qProd$(d1prod[prd,sp,t] and prdBotUlt(prd) and t0[t])  
  ;

  $GROUP G_static_calibration_exo
    G_taxes_static_calibration_exo
    G_taxes_energy_static_calibration_exo
    G_energy_markets_static_calibration_exo
    G_aggregates_static_calibration_exo
    G_labor_market_static_calibration_exo 
    G_Government_static_calibration_exo
    G_consumers_static_calibration_exo
    G_production_public_static_calibration_exo
    G_production_private_static_calibration_exo
    G_IO_static_calibration_exo
    G_exports_static_calibration_exo
    G_emissions_static_calibration_exo
    G_lulucf_static_calibration_exo
    G_abatement_static_calibration_exo
    G_production_agr_static_calibration_exo
    G_production_plant_static_calibration_exo
    G_production_ani_static_calibration_exo
    G_waste_static_calibration_exo  
    G_leakage_static_calibration_exo
    G_udvaskning_static_calibration_exo
    G_pyrolyse_static_calibration
    -    qProd$(d1prod[prd,sp,t] and prdBotUlt(prd) and t0[t])  
  ;

  $GROUP ALLREFORM  
     ALL
    -G_energiIO_in
  ;

#Population korrigeres
  nPop.l[t]        = nPop.l[t]        * correction_factor_pop;
  nEmployed.l[t]   = nEmployed.l[t]   * correction_factor_pop;
  nUnemployed.l[t] = nUnemployed.l[t] * correction_factor_pop;
  nLaborForce.l[t] = nLaborForce.l[t] * correction_factor_pop;

# Marginal tax-rate option? 
  d1tREmarg[s] = 1; #Set to 1 for marginal tax-rates and 0 for average tax-rates

# ----------------------------------------------------------------------------------------------------------------------
# Solve static calibration model in years where we have full data
# ----------------------------------------------------------------------------------------------------------------------

  set_time_periods(%cal_start%, %cal_end%);

  #The static calibration takes three steps (1) the cost structure is computed given capital-stock, (2) capital-stock is adjusted for food- and beverages industries (we only have data for the aggregate), (3) static calibration is computed with new cost-structure
  #(1)

  $FIX G_static_calibration_exo;
  $UNFIX G_static_calibration;
  execute_unload 'output\pre.gdx';
  @solve(M_static_calibration);
  #  execute_unload 'output\static_raw.gdx';
  
  #(2)
  $FIX G_production_static_calibration_capital_incl_agrcapital_exo;
  $UNFIX(0,inf) pY0$(sum(ns69,ns692s(ns69,s))), qI_s$(sum(ns69,ns692s(ns69,s))), qFin_k$(sum(ns69,ns692s(ns69,r))), qFin_y$(sum(ns69,ns692s(ns69,r))), qFin_m$(sum(ns69,ns692s(ns69,r)));
  $UNFIX(0.1,inf) qK$(sum(ns69,ns692s(ns69,s)));
  Solve M_production_static_calibration_capital_incl_agrcapital using NLP minimizing obj;

  qAni_capital.l[Ani_sectors,'Buildings',t]            = qK.l['ib',Ani_sectors,t-1]/fq; #uK 
  qAni_capital.l[Ani_sectors,'MachinesPrivate',t]      = qK.l['im',Ani_sectors,t-1]/fq; #uK
  qAni_capital.l[Ani_sectors,'TransportCapital',t]     = qK.l['it',Ani_sectors,t-1]/fq; #uK 

  qPlant_capital.l[Plant_sectors,'Buildings',t]        = qK.l['ib',Plant_sectors,t-1]/fq; #uK
  qPlant_capital.l[Plant_sectors,'MachinesPrivate',t]  = qK.l['im',Plant_sectors,t-1]/fq; #uK
  qPlant_capital.l[Plant_sectors,'TransportCapital',t] = qK.l['it',Plant_sectors,t-1]/fq; #uK

  #(3)
  $FIX G_static_calibration_exo; 
  $UNFIX G_static_calibration;
  #  execute_unload 'output\pre.gdx';
  @solve(M_static_calibration);

  $import sanitycheck.gms 
  execute_unload 'output\static_calibration.gdx';

  #Various checks
    #Check that demand equals supply for energy-goods. The check is carried out for both values and quantities
    $import check_ds.gms

    # Check that input-data is not changed after static-calibration
      $GROUP G_load_G_data G_data;
      @load_previous_difference(G_load_G_data,'..\data\cal_dyn_load\previous_differences_static_calibration.gdx');
      @assert_no_difference(G_data,%tolerance_data%);

    #  UNLOAD NEW DIFFERENCES - TO BE COMMENTED IN IF YOU WANT TO CHANGE THE DIFFERENCE-GDX. PROCEED ONLY WITH CAUTION, thank you :) 
        #  @unload_differences(G_data,'..\data\cal_dyn_load\previous_differences_static_calibration.gdx');

# ----------------------------------------------------------------------------------------------------------------------
# Extend the last calibration as our forecast of parameters
# ----------------------------------------------------------------------------------------------------------------------
  set_time_periods(%cal_start%, %terminal_year%);

  $PGROUP pG_dummies_Flat 
    pG_dummies
    -PGROUP_taxes_NonFlat_Dummies
    -PGROUP_emissions_NonFlat_Dummies
    -PGROUP_Waste_NonFlat_Dummies
    -PGROUP_WasteKlimaplan_NonFlat_Dummies
    -PGROUP_LULUCF_NonFlat_Dummies
    -PGROUP_Abatement_NonFlat_Dummies
    -PGROUP_production_plant_NonFlat_Dummies
    -PGROUP_production_ani_NonFlat_Dummies
  ;

  $LOOP PGROUP_Waste_NonFlat_Dummies:
      {name}{sets}{$}[<t>tForecastWaste_dst] = {name}{sets}{$}[<t>tWasteEnd_dst];
  $ENDLOOP

  $LOOP PGROUP_WasteKlimaplan_NonFlat_Dummies:
      {name}{sets}{$}[<t>tForecastWaste_klimaplan] = {name}{sets}{$}[<t>tWasteEnd_klimaplan];
  $ENDLOOP


  $GROUP G_flat_initial_values 
    ALLREFORM
    -G_production_non_flat_initial_values_from_MAKRO
    -G_Government_non_flat_initial_values_from_MAKRO
    -G_labor_market_non_flat_initial_values_from_MAKRO
    -G_no_forecast_lulucf
    -G_non_flat_from_energy_taxes
    -G_agr_non_flat_initial_values
    -G_ani_non_flat_initial_values
    -G_plant_non_flat_initial_values
    -G_udvaskning_noforecast
    -G_waste_projection_data_arima
    -G_PSO_taxes_to_zero
    -G_waste_klimaplan_virkemidler
    -G_waste_2014_2020
    -uWaste_arima_hus_adjust
    -G_waste_CET_function
    -G_emissions_non_flat_initial_values
  ;

  $LOOP G_waste_projection_data_arima:
      {name}.l{sets}{$}[<t>tForecastWaste_arima] = {name}.l{sets}{$}[<t>tWasteEnd_arima];
  $ENDLOOP

  $LOOP G_waste_klimaplan_virkemidler:
      {name}.l{sets}{$}[<t>tForecastWaste_klimaplan] = {name}.l{sets}{$}[<t>tWasteEnd_klimaplan];
  $ENDLOOP

  $LOOP G_waste_2014_2020:
      {name}.l{sets}{$}[<t>tForecastWaste_dst] = {name}.l{sets}{$}[<t>tWasteEnd_dst];
  $ENDLOOP

  $LOOP G_waste_CET_function:
      {name}.l{sets}{$}[<t>tForecastWaste_CET] = {name}.l{sets}{$}[<t>'2025'];
  $ENDLOOP


  $LOOP G_flat_initial_values: #Important to subset as long as variables in G_glat_initial_values are subsetted
    {name}.l{sets}{$}[<t>tForecast]$({subsets}) = {name}.l{sets}{$}[<t>tDataEnd];
  $ENDLOOP

  $LOOP G_agr_qK:
    {name}.l{sets}$({name}.l{sets}=0 and {subsets} and tForecast[t]) = {name}.l{sets}{$}[<t>tForecastStart];
  $ENDLOOP


