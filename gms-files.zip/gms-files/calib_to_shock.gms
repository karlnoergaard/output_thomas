
#====================================================================================================================================================================================================================#
# transforming the model from a calibration model to a shock model
#====================================================================================================================================================================================================================#


	$GROUP G_shockEndo
	correction_rHH[t]   "rHH holdes konstant i stødet, hvilket kræver en korrektion i afkastet, som antages at komme fra udlandet"
	;

	$GROUP G_shockExo
  	sDomesticEquity$(t0[t]) #Tilføjet ifm. endo-exo (Rasmus)
	;


  $BLOCK B_shock

    E_vBoP_shock[t]$(tx0[t])..       vBoP[t] =E= vNFE[t] - (vForeignWealth[t] - vForeignWealth[t-1]/fv) + vGovReval[t] + JvWealth[t] + correction_rHH[t]
                                         
                                           ;


    E_vHHxAfk_shock[t]$(tx0[t])..         vHHxAfk[t] =E=  rBonds['71000',t] * (1-sDomesticEquity[t]-sForeignEquity[t]) * vWealth[t-1]/fv
                                                          #  + sum(agri_sectors, (rBonds[agri_sectors,t]-rBonds['71000',t]) * vFirmDebt[agri_sectors,t-1]/fv)
                                                          + sum(sp,rInvestor[sp,t]*vEquity[sp,t])/sum(sp,vEquity[sp,t]) 
                                                             * (sDomesticEquity[t]+sForeignEquity[t]) * vWealth[t-1]/fv
                                                          + correction_rHH[t]
                                                        ; 


    E_vWealth_shock[t]$(tx0[t])..              vWealth[t] =E= vWealth[t-1]/fv + vPersIncome[t] - vC['ctot',t] + JvWealth[t] + vWealth_shockCorrection[t-1]/fv;

    E_vWealth_shockCorrection2[t]$(t0[t])..     vWealth_shockCorrection[t] =E=  (sum(sp,vEquity[sp,t])-sum(sp,vEquity_baseline[sp,t]))*sEquityDKownedEndo[t] + sum(s_DK, (vEquity[s_DK,t]-vEquity_baseline[s_DK,t])*(sEquityDKownedExo[s_DK,t]-sEquityDKownedEndo[t]));

    E_qC_shock[c,t]$(tx0[t]).. qC[c,t] * pC_baseline[c,t-1] =E= pCHh_baseline[c,t-1] * qCHh[c,t] + pCtourist_baseline[c,t-1] * qCtourist[c,t]$(d1CTourist[c,t]);

    E_qC_tot_shock[t]$(tx0[t])..   qC['cTot',t] * pC_baseline['cTot',t-1] =E= sum(c$d1C[c,t], pC_baseline[c,t-1]$d1C[c,t] * qC[c,t] - pCtourist_baseline[c,t-1] * qCtourist[c,t]$(d1CTourist[c,t]));

    E_qX_tot_shock[t]$(tx0[t]).. qX['xtot',t]*pX_baseline['xtot',t-1] =E= sum(s$(d1X_y['xoth',s,t]), pX_y_baseline['xoth',s,t-1]$(d1X_y['xoth',s,t]) * qX_y['xoth',s,t])
                                           +sum(s$(d1X_m['xoth',s,t]), pX_m_baseline['xoth',s,t-1]$(d1X_m['xoth',s,t]) * qX_m['xoth',s,t])
                                           +sum((purpose,energy19)$(d1vXE[purpose,energy19,t] and d1vXE[purpose,energy19,t]), pXE_baseline[purpose,energy19,t-1] * qXE[purpose,energy19,t])
                                           +pX_baseline['xTur',t-1]*qX['xTur',t]
                                           +(pXE_ElNl_baseline[t-1]*qXE_ElNl[t])$(t.val <=2019) #�rsted
                                           ;

    E_qX_s_shock[s,t]$(tx0[t] and d1x_s[s,t]).. 
      pX_s_baseline[s,t-1]*qX_s[s,t] =E= (pX_y_baseline['xOth',s,t-1]*qX_y['xOth',s,t])$(d1x_y['xOth',s,t] and d1x_y['xOth',s,t]) + (pX_s_baseline[s,t-1]*qX_y['xOth',s,t])$(d1x_y['xOth',s,t] and not d1x_y['xOth',s,t])
                                + sum(energy19$(d1vXE['unspecified',energy19,t] and d1Xe_y[energy19,s,t]), pXE_baseline['unspecified',energy19,t-1] *qXE['unspecified',energy19,t] *qY[s,t]/sum(ss$d1Xe_y[energy19,ss,t], qY[ss,t]))
                                + (pXE_ElNl_baseline[t-1]*qXE_ElNl[t])$(sameas[s,'35011'] and t.val <=2019)  #�rsted
                                ;


  $ENDBLOCK

#Baseline landbrugsproduktivitet 
TFPPlant_baseline_zeroshockagr.l[plant_sectors,t]  = TFPPlant.l[plant_sectors,t];
TFPPlant_baseline_zeroshockagr.l[plant_sectors,t0] = TFPPlant_baseline_zeroshockagr.l[plant_sectors,t1];
qLandUdtag_tot_zeroshock_agr.l[t]                  = qLandUdtag_tot.l[t];



sEquityDKownedEndo.l[t0] = sEquityDKownedEndo.l[t1];


#Setting up model
$MODEL M_zeroshock
	M_base
	,-E_ConstantvWealth
	,-B_leakage

	#Model changes in last_calib
	B_Last_Calib

  #Landbrugsintegration...
	-E_pY_CET0
	-E_qY
	E_pY_CET0_notagri  
	E_qY_notagri     

	#  M_energy 
	#  B_CGE_ENERGY_LINK

	B_shock, -E_vBoP, -E_vHHxAfk, -E_vWealth
	-E_qC, -E_qC_tot, -E_qX_tot, -E_qX_s

	-E_vPersIncome_t0 #Tilføjet ifm. endo-exo (Rasmus)

	M_endolandlinks
;


$GROUP G_endo 
	G_endo
	G_energy_endo 
	#  G_CGE_ENERGY_LINK_ENDO
	G_endolandlinks_endo
	G_shockEndo, vWealth_shockCorrection$(t0[t]), -rHHxAfk

	G_Last_Calib_Endo

	-qY$(agri_sectors_s_[s_])
	-pY0_CET$(agri_sectors_[s])

	-rForeignWealth$(t1[t])

	-vPersIncome$(t0[t]) #Tilføjet ifm. endo-exo (Rasmus)
;

$GROUP G_exo 
	G_exo 
	G_energy_exo
	#  G_CGE_ENERGY_LINK_EXO
	G_endolandlinks_exo
	pLand$(t0[t])
	G_shockExo, -G_shockEndo, rHHxAfk

	G_Last_calib_Exo

	#  G_energy_endo 
	#  G_CGE_ENERGY_LINK_ENDO
	G_endolandlinks_endo
	qY$(agri_sectors_s_[s_])
	pY0_CET$(agri_sectors_[s])
	vEquity_baseline
    
  pC_baseline
  pCtourist_baseline
	pCHh_baseline
  pX_baseline
  pX_y_baseline
  pX_m_baseline
  pX_s_baseline
  pXE_ElNl_baseline
  pXE_baseline	

  rForeignWealth$(t1[t])

  vWealth$(t.val <= t0.val) #Tilføjet ifm. endo-exo (Rasmus)
  vPersIncome$(t0[t])       #Tilføjet ifm. endo-exo (Rasmus)
;

$GROUP G_EndoAndExo 
	G_endo 
	G_exo
	-sigmaID #Fungerer ikke ordentligt med gamY (prøv igen med fremtidig gamY-version, AKB 27.6.2024)
	-sEquityDKownedEndo
	-qX
;


#Save variable values to have something to compare with after shock
@save(G_EndoAndExo);

#  $SETGLOBAL start_shock_year 2022 #Year where we start the 0-shock
#  set_time_periods(%start_shock_year%,%terminal_year%);
#Zero-shock, unchanged b
$FIX G_exo;
$UNFIX G_endo;
@SOLVE(M_zeroshock);

$import sanitycheck.gms;


execute_unload 'Output\calib_to_shock.gdx';

#  @assert_no_difference(G_EndoAndExo,1e-8);
