PARAMETER demandtot[energy19,t], supplytot[energy19,t], diff_demand_supply[energy19,t];

#Computing quantity demanded of energy-goods
demandtot[energy19,t] = sum((purpose,r)$(d1pRE_base[purpose,energy19,r,t]), qREgj.l[purpose,energy19,r,t]) 
                      + sum(purpose$(d1vCE[purpose,energy19,t]), qCE.l[purpose,energy19,t])
                      + sum(purpose$(d1vLE[purpose,energy19,t]), qLE.l[purpose,energy19,t])
                      + sum(purpose$(d1vXE[purpose,energy19,t]), qXE.l[purpose,energy19,t])
                      + sum(purpose$(d1TL[purpose,energy19,t]), qTL.l[purpose,energy19,t]);

#Computing quantity supplied of energy-goods 
supplytot[energy19,t] = sum(s$d1vY_CET[energy19,s,t], qY_CET.l[energy19,s,t]) + sum(s$d1vM_CET[energy19,s,t], qM_CET.l[energy19,s,t]);  #+ qRENEWABLE.l[energy19,t]$(sameas['Oil products',energy19]);

#Computing the difference beween supply and demand (should be zero)
diff_demand_supply[energy19,t] =demandtot[energy19,t] - supplytot[energy19,t];
display demandtot, supplytot,  diff_demand_supply;

#Check if supply equals demand
LOOP(t$tx0[t],
tjek = sum(energy19, diff_demand_supply[energy19,t]);
ABORT$(abs(tjek) gt 1e-6) tjek, "Demand not equal to supply (q)"
);

#Computing value of demanded energy-goods
demandtot[energy19,t] = sum((purpose,r), pRE_base.l[purpose,energy19,r,t] * qREgj.l[purpose,energy19,r,t]$(d1pRE_base[purpose,energy19,r,t]))
                                                                         +  sum(purpose$d1vCE[purpose,energy19,t], pCE_base.l[purpose,energy19,t] * qCE.l[purpose,energy19,t]) 
                                                                         +  sum(purpose$d1vLE[purpose,energy19,t], pLE_base.l[purpose,energy19,t] * qLE.l[purpose,energy19,t])
                                                                         +  sum(purpose$d1vXE[purpose,energy19,t], pXE_base.l[purpose,energy19,t] * qXE.l[purpose,energy19,t])
                                                                         -  vDistributionProfits.l[energy19,t];     

#Computing value of supplied energy-goods
supplytot[energy19,t] = sum(s$d1vY_CET[energy19,s,t], pY_CET.l[energy19,s,t] * qY_CET.l[energy19,s,t]) + sum(s$d1vM_CET[energy19,s,t], pM_CET.l[energy19,s,t] *qM_CET.l[energy19,s,t]);# + EN_vCUS[energy19,t];

#Computing the difference beween supply and demand (should be zero)
diff_demand_supply[energy19,t] =demandtot[energy19,t] - supplytot[energy19,t];
display demandtot, supplytot, diff_demand_supply;

#Check if supply equals demand
LOOP(t$tx0[t],
tjek = sum(energy19, diff_demand_supply[energy19,t]);
ABORT$(abs(tjek) gt 1e-6) tjek, "Demand not equal to supply (v)"
);
