
#====================================================================================================================================================================================================================#
# This is a clean shock file. Take a copy and start making your onw shock
#====================================================================================================================================================================================================================#


	#  $GROUP G_CleanShockEndo
	#  ;

	#  $GROUP G_CleanShockExo
	#  ;

#Setting up model
$MODEL M_CleanShock 
	M_zeroshock
;


$GROUP G_endo 
	G_endo
	#  G_CleanShockEndo
;


$GROUP G_exo 
	G_exo 
	#  G_CleanShockExo
;



# Set your start year for the shock   
$SETLOCAL start_shock_year 2023 #Year where we start the 0-shock

set_time_periods(%start_shock_year%,%terminal_year%);
#  t_BU_start[t] = yes$(t.val =%start_shock_year%+1);
#  t_BU_xStart[t] = yes$(t_BU[t] and t.val > t_BU_Start.val and tx1[t]);

$FIX G_exo;
$UNFIX G_endo;
@SOLVE(M_CleanShock);


$import Report_and_steps/report_all.gms
execute_unload 'Output\clean_shock.gdx';
#  @check_vBoP();
