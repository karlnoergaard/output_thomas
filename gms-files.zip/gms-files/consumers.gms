# ======================================================================================================================
# Consumers
# ======================================================================================================================
# Consumption decision and budget constraint


# ======================================================================================================================
# Variable definition
# ======================================================================================================================
$IF %stage% == "variables":
  $GROUP G_consumers_prices
    pCHh[c_,t]$(tx0[t] and ((c[c_] or cNest[c_]) or sameas[c_,'cTot']))       "Imputed price index for consumption components for households - i.e. excl. consumption from tourism"
    rHHxAfk[t]$(tx0[t])                                                       "Implicit rate of return on vwealth"
  ;
  
  $GROUP G_consumers_quantities
    qCHh[c_,t]$(tx0[t])                         "Total household consumption divided by consumption goods and aggregates"
    

    qDisUtility[t]$(tx0[t])                      "Disutility from work"
    qCHH_R[t]$(tx0[t])                           "Rational consumers consumption"
    qCHH_nR[t]$(tx0[t])                          "Hand-to-mouth consumers consumption"          
    qUtility_R[t]$(tx0[t])                       "Rational consumers utility"
    qUtility_nR[t]$(tx0[t])                      "Hand-to-mouth consumers utility"    
  ;

$GROUP G_consumers_values 
   vWealth[t]$(tx0[t])                           "Total wealth of consumers"
   vPersIncome[t]$(t0[t] or tx0[t])              "Total income of consumers"
   vHHxAfk[t]$(tx0[t])                           "Households' return on wealth (excl. real estate)"   
   vLeisureAdjustedIncome[t]$(tx0[t])            "Leasure acjusted income"
   H[t]$(t0[t] or tx0[t])                        "Future (leisure adjusted) income"   
   omega[t]$(t0[t] or tx0[t])                    "Auxiliary parameter"    
   JvWealth[t]$(tx0[t])                          "Correction item on household wealth (included in household income)"
;

  $GROUP G_consumers_other
    # CES demand
    eC[c_]$(cNest[c_])                                                    "Substitution elasticity in private consumption nests"
    uC[c_,t]$(tx0[t] and sum(cNest, cNest2c_[cNest,c_]))                  "Correction item for CES-skale parameter in private consumption nests"
    rBonds[s,t]$(tx0[t] and sameas(s,'71000'))                            "Return on bonds"
    t_r[t]$(tx0[t])                                                       "Tax on capital income"
  
    shareC[t]$(tx0[t])                          "When forward looking consumers are turned off, total consumption is determined as shareC times total gross value added"
    rDepr_car[t]$(tx0[t])                       "Depreciation rate for vehicles owned by the household"
    sDomesticEquity[t]$(tx0[t])                 "Share of household net-wealth (vHHWealth) as domestic equity"
    sForeignEquity[t]$(tx0[t])                  "Share of household net-wealth (vHHWealth) as foreign equity"

    beta[t]$(tx0[t])                            "Intertemporal discount-factor of rational consumers"
    eC_R                                        "Intertemporal elasticity of substitution for rational consumers"
    pDeath                                      "The age-invariant risk of dying"
    s_R[t]$(tx0[t])                             "Share of consumers who are rational"
    d1qCHH_EV[t]$(tx0[t])                       "Dummy for private consumption based on EV-consistent behaviour"

    JvWealth_ShortTerm[t]$(tShortTerm[t])            "Correction on household wealth" 
    JvWealth_MediumTerm                              "Correction on household wealth to be consistent with the development in consumption up until to 2030"
    JvWealth_MediumLongTerm                          "Correction on household wealth to be consistent with the development in consumption from 2030 to 2050"
    JvWealth_LongTerm                                "Correction on household weakth to be consistent with a constant development in consumtion"
    tFadeOut[t]$(tMediumTerm[t])                     "A parameter in the adjustment of vWealth to fit the level of consumption to an external projection. "
    tFadeOut_2030_2050[t]$(tMediumLongTerm[t])       "A parameter in the adjustment of vWealth to fit the level of consumption to an external projection. "
    j_pCHH_car[t]$(tx1[t])                                    "" 
  ;

  $GROUP G_consumers_report
    rHHU[t]                            "Return on households incl. the probability of dying"
    rHH[t]                             "Return on housholds excl. the probability of dying"
    pU[t]                              "Utility price for EV"
    Rdis[t]                            "Discount rate for rational housholds"
    Sdis[t]                            "Discount rate for rational housholds"

    Hwage[t]                           "Income from wages"
    Htrans[t]                          "Income from transfers"
    Htax[t]                            "Negative income to taxation"
    Hleisure[t]                        "Negative lack of leisure income"
    Hother[t]                          "Other (leisure adjusted) income"

    PVvLeisureAdjustedIncome[t]        "Present value of future vLeisureAdjustedIncome"
    PVweightedPrices[t]                "Present value of consumption prices weighted by future vLeisureAdjustedIncome"
    PVunbornFutureIncome[t]            "Present value of unborns's future income and inheritance"
    PVweightedPU[t]                    "Present value of PU weighted by unborn's future income and inheritance"
    PVyears[t]                         "Present value of an infinite number of years"
    PVHwage[t]                         "Present value of salary"
    PVHtrans[t]                        "Present value of transfers"
    PVHtax[t]                          "Present value of taxes"
    PVHleisure[t]                      "Present value of disutility from working"
    PVHother[t]                        "Present value of other income"
  ;

$ENDIF

$IF %stage% =="groupcompilation":

  $GROUP G_consumers_endo
    G_consumers_prices
    G_consumers_quantities
    G_consumers_values
    qC$(tx0[t] and sameas[c_,'cCar'])
  ;

  $GROUP G_consumers_exo
    G_consumers_other 
    qCHH$(t0[t] and sameas[c_,'cCar'])
 
    vC$(tx0[t] and (c[c_] and not sameas[c_,'cCar'] or sameas[c_,'ctot']))   
    vGrossValAdd$(tx0[t] and s[s_])

    vWealth$(t0[t])
    vCtourist$(d1CTourist[c,t] and tx0[t])

    hours$(tx0[t])
    prod_a$(tx0[t])
    nEmployed$(tx0[t])
    vTrans$(tx0[t])
    vtDirect$(tx0[t])
    vtCorp$(tx0[t])
    jvtIndirect$(tx0[t])
    vLumpsum$(tx0[t])
    vGovProfit$(tx0[t])
    vGovReceiveHH$(tx0[t])
    vtBequest$(tx0[t])
    vtChurch$(tx0[t])
    vCont$(tx0[t])
    vGov2HH$(tx0[t])
    vGovLand$(tx0[t])

    rInvestor$(tx0[t])
    vEquity$(tx0[t] and s[s_] and not sameas(s_,'off'))
    eHt
    Eta_Hours$(tx0[t])
    w$(tx0[t])
    pC$(tx0[t] and sameas[c_,'cCar']) 
  ;



$ENDIF


# ======================================================================================================================
# Equations
# ======================================================================================================================
$IF %stage% == "equations":
  $BLOCK B_consumers

    # ------------------------------------------------------------------------------------------------------------------
    # Coupling of CES tree and IO system  (household consumption and tourist consumption are aggregated)
    # ------------------------------------------------------------------------------------------------------------------
    E_pCHH[c,t]$(tx0[t] and not sameas[c,'cCar']).. pCHH[c,t] * qCHH[c,t] + vCtourist[c,t]$(d1CTourist[c,t]) =E= vC[c,t];

    E_pCHH_cCar[t]$(tx0E[t]).. pCHH['cCar',t+1]*fp =E= (1.03)*pC['cCar',t] - (1-rDepr_car[t+1])*pC['cCar',t+1]*fp + j_pCHH_car[t+1]; 

    E_qC_cCars[t]$(tx0[t])..                   qCHH['cCar',t]    =E= (1-rDepr_car[t]) * qCHH['cCar',t-1]/fq + qC['cCar',t];

  #Terminal condition 
    E_qC_cCars_tEnd[t]$(tEnd[t]).. qCHH['cCar',t] =E= qCHH['cCar',t-1];
   
    # ------------------------------------------------------------------------------------------------------------------
    # CES demand for non-durable consumption
    # ------------------------------------------------------------------------------------------------------------------
    
    # Budget constraint
    E_pCHH_nests[cNest,t]$(tx0[t] and not sameas[cNest,'cCarSer']).. pCHH[cNest,t] * qCHH[cNest,t] =E= sum(c_$(cNest2c_[cNest,c_]), pCHH[c_,t] * qCHH[c_,t]);

    E_pCHH_nests_cCarSer[cNest,t]$(tx0[t] and sameas[cNest,'cCarSer']).. pCHH[cNest,t] * qCHH[cNest,t] =E= 
                sum(c_$(cNest2c_[cNest,c_] and not sameas[c_,'cCar']), pCHH[c_,t] * qCHH[c_,t]) + pCHH['cCar',t] * qCHH['cCar',t-1]/fq;


    # FOC
    E_qCHH[c_,cNest,t]$(tx0[t] and cNest2c_[cNest,c_] and not sameas[c_,'cCar']).. 
      qCHH[c_,t] =E= uC[c_,t]  * ((pCHH[cNest,t] / pCHH[c_,t])**eC(cNest)) * qCHH[cNest,t]; 


    E_qCHH_cars[c_,cNest,t]$(tx0[t] and cNest2c_[cNest,c_] and sameas[c_,'cCar']).. 
      qCHH[c_,t-1] =E= uC[c_,t]  * ((pCHH[cNest,t] / pCHH[c_,t])**eC(cNest)) * qCHH[cNest,t]; 





    E_vPersIncome[t]$(tx0[t])..           vPersIncome[t]  =E= w[t] * Hours[t] * prod_a[t] * nEmployed[t]
                                                            + vTrans[t]
                                                            - (vtDirect[t]-vtCorp[t])
                                                            - jvtIndirect[t]
                                                            - vGovProfit[t] - vGovReceiveHH[t] - vtBequest[t] - vtChurch[t] - vCont[t]
                                                            - vLumpsum[t] 
                                                            + vGov2HH[t] + vGovLand[t]
                                                            + vHHxAfk[t]
                                                            + rInvestor['68203',t]*vEquity['68203',t]
                                                            ;

    # Property income from housholds excl. reevaluations 
    E_vHHxAfk[t]$(tx0[t])..                vHHxAfk[t]   =E=   rBonds['71000',t] * (1-sDomesticEquity[t]-sForeignEquity[t]) * vWealth[t-1]/fv
                                                            + sum(sp,rInvestor[sp,t]*vEquity[sp,t])/sum(sp,vEquity[sp,t]) 
                                                              * (sDomesticEquity[t]+sForeignEquity[t]) * vWealth[t-1]/fv
                                                            ; 

    E_rHHxAfk[t]$(tx0[t])..               rHHxAfk[t]    =E=  vHHxAfk[t] / (vWealth[t-1]/fv);                                                         

    E_vWealth[t]$(tx0[t])..               vWealth[t]    =E= vWealth[t-1]/fv + vPersIncome[t] - vC['ctot',t] + JvWealth[t];


    E_vPersIncome_t0[t]$(t0[t])..       vPersIncome[t]  =E= vPersIncome[t+1]; # Added because vPersincome[t0] is skewed heavily by the introduction of the lump-sum tax in t1.



    E_JvWealth_ShortTerm[t]$(tShortTerm[t])..                 JvWealth[t] =E= JvWealth_ShortTerm[t];    
    E_JvWealth_MediumTerm[t]$(tMediumTerm[t])..               JvWealth[t] =E= JvWealth_MediumTerm*tFadeOut[t] + JvWealth_MediumLongTerm + JvWealth_LongTerm;
    E_JvWealth_MediumLongTerm[t]$(tMediumLongTerm[t])..       JvWealth[t] =E= JvWealth_MediumLongTerm*tFadeOut_2030_2050[t] + JvWealth_LongTerm;
    E_JvWealth_LongTerm[t]$(tLongTerm[t])..                   JvWealth[t] =E= JvWealth_LongTerm;


    # d1qCHH_EV equal to 1 determines private consumtion of EV-consistent consumtion decisions. d1qCHH_EV equal to 0 fixes private consumtion as a constant share of BVT.
    E_qCHH_tot_2[t]$(tx0[t])..        qCHH['ctot',t]  =E=   d1qCHH_EV[t]  * (qCHH_R[t]+qCHH_nR[t]) + (1-d1qCHH_EV[t]) * shareC[t] * sum(s, vGrossValAdd[s,t]) / pCHH['ctot',t];



  $ENDBLOCK

  $BLOCK B_consumers_olg 

    E_qDisUtilityFromWork[t]$(tx0[t])..   qDisUtility[t]  =E= Eta_Hours[t]**eHt * prod_a[t] * nEmployed[t] * Hours[t]**((1+eHt)/eHt) * eHt/(1+eHt);    

    E_LeisureAdjustedIncome[t]$(tx0[t])..   vLeisureAdjustedIncome[t] =E= vPersIncome[t] + JvWealth[t]           # income after tax incl. return on assets and correction in wealth
                                                                        - (1-t_r[t])*rHHxAfk[t]*vWealth[t-1]/fv  # return on assets from the utility optimization is subtracted. Other retuns are consideres as income non dependent of the choise of assets
                                                                        - pCHH['cTot',t] * qDisUtility[t]; 

    # Consumption for hand-to-mouth consumers 
    E_qCHH_nR[t]$(tx0[t]).. pCHH['cTot',t] * qUtility_nR[t] =E= (1-s_R[t])*vLeisureAdjustedIncome[t];

    # Current 'flow' of utility to rational consumers
    E_qUtility_R[t]$(tx0[t]).. qUtility_R[t] =E= qCHH_R[t] - s_R[t]*qDisUtility[t];

    # Current 'flow' of utility to hand-to-mouth consumers 
    E_qUtility_nR[t]$(tx0[t]).. qUtility_nR[t] =E= qCHH_nR[t] - (1-s_R[t])*qDisUtility[t];

    # Dynamic behavior of rational consumers. The rational consumers consumption is implicitly chosen here 
    E_qCHH_R[t]$(tx0[t]).. qUtility_R[t] =E= (beta[t]*(1+(1-t_r[t])*rHHxAfk[t])/pCHH['cTot',t])**eC_R * [(1-pDeath) * vWealth[t-1] + H[t-1]]/Omega[t-1] * 1/fq; 

    # Equation can't be called E_H because one of the sets in energy-module is called e_h
    E_H_aux[t]$(tx0[t]).. H[t-1]/fv =E= (1-pDeath)/(1+(1-t_r[t])*rHHxAfk[t]) * (s_R[t]*vLeisureAdjustedIncome[t] + H[t]);    

    E_H_Terminal[t]$(tEnd[t]).. H[t] =E= H[t-1];

    E_Omega[t]$(tx0[t]).. Omega[t-1] =E= (1-pDeath)/(1+(1-t_r[t])*rHHxAfk[t]) * (beta[t]*(1+(1-t_r[t])*rHHxAfk[t]))**eC_R * fp**(1-eC_R) * (pCHH['cTot',t]**(1-eC_R)+Omega[t]);


    E_Omega_Terminal[t]$(tEnd[t]).. Omega[t] =E= Omega[t-1];

  $ENDBLOCK 


  $BLOCK B_consumers_report

    E_pU[t]$(tEndo[t])..     omega[t]    =E= pU[t]**(1-eC_R);    
    E_rHHU[t]$(tx0[t])..     rHHU[t]     =E= (1+(1-t_r[t])*rHHxAfk[t])/(1-pDeath)/fv - 1;
    E_rHH[t]$(tx0[t])..      rHH[t]      =E= (1+(1-t_r[t])*rHHxAfk[t])/fv - 1;    
    E_Sdis[t]$(tEndo[t])..   Sdis[t]     =E= prod(tt $ (ord(t) ge ord(tt) and tt.val gt t0.val), 1/(1+rHH[tt]));  
    E_Rdis[t]$(tEndo[t])..   Rdis[t]     =E= prod(tt $ (ord(t) ge ord(tt) and tt.val gt t0.val), 1/(1+rHHU[tt]));


    E_Hwage[t]$(tx0[t])..    Hwage[t]    =E= w[t] * Hours[t] * prod_a[t] * nEmployed[t];
    E_Htrans[t]$(tx0[t])..   Htrans[t]   =E= vTrans[t];
    E_Htax[t]$(tx0[t])..     Htax[t]     =E= - (vtDirect[t]-vtCorp[t]-t_r[t]*rHHxAfk[t]*vWealth[t-1]/fv) -jvtIndirect[t]-vGovProfit[t]-vGovReceiveHH[t]-vtBequest[t]-vtChurch[t]-vCont[t]-vLumpsum[t]+vGov2HH[t]+vGovLand[t];
    E_Hleisure[t]$(tx0[t]).. Hleisure[t] =E= - pCHH['cTot',t] * qDisUtility[t];
    E_Hother[t]$(tx0[t])..   Hother[t]   =E= vLeisureAdjustedIncome[t]-Hwage[t]-Htrans[t]-Htax[t]-Hleisure[t];      


    E_PVvLeisureAdjustedIncome[t]$(tEndo[t]).. PVvLeisureAdjustedIncome[t]       
                                         =E= sum(tt $ (ord(tt) gt ord(t)), Sdis[tt]/Sdis[t] * vLeisureAdjustedIncome[tt]) 
                                             + 1/rHH[tEnd]*Sdis[tEnd]/Sdis[t]               * vLeisureAdjustedIncome[tEnd] ;

    E_PVyears[t]$(tEndo[t])..       PVyears[t]       
                                         =E= sum(tt $ (ord(tt) gt ord(t)), Sdis[tt]/Sdis[t] * 1) 
                                             + 1/rHH[tEnd]*Sdis[tEnd]/Sdis[t]               * 1 ;

    E_PVHwage[t]$(tEndo[t])..       PVHwage[t]       
                                         =E= sum(tt $ (ord(tt) gt ord(t)), Sdis[tt]/Sdis[t] * Hwage[tt]) 
                                             + 1/rHH[tEnd]*Sdis[tEnd]/Sdis[t]               * Hwage[tEnd] ;

    E_PVHtrans[t]$(tEndo[t])..      PVHtrans[t]       
                                         =E= sum(tt $ (ord(tt) gt ord(t)), Sdis[tt]/Sdis[t] * Htrans[tt]) 
                                             + 1/rHH[tEnd]*Sdis[tEnd]/Sdis[t]               * Htrans[tEnd] ;

    E_PVHtax[t]$(tEndo[t])..        PVHtax[t]       
                                         =E= sum(tt $ (ord(tt) gt ord(t)), Sdis[tt]/Sdis[t] * Htax[tt]) 
                                             + 1/rHH[tEnd]*Sdis[tEnd]/Sdis[t]               * Htax[tEnd] ;

    E_PVHleisure[t]$(tEndo[t])..    PVHleisure[t]       
                                         =E= sum(tt $ (ord(tt) gt ord(t)), Sdis[tt]/Sdis[t] * Hleisure[tt]) 
                                             + 1/rHH[tEnd]*Sdis[tEnd]/Sdis[t]               * Hleisure[tEnd] ;

    E_PVHother[t]$(tEndo[t])..      PVHother[t]       
                                         =E= sum(tt $ (ord(tt) gt ord(t)), Sdis[tt]/Sdis[t] * Hother[tt]) 
                                             + 1/rHH[tEnd]*Sdis[tEnd]/Sdis[t]               * Hother[tEnd] ;

  $ENDBLOCK 


  $MODEL M_consumers B_consumers, B_consumers_olg;  
 
 $ENDIF


$IF %stage% == "exogenous_values":  
# ======================================================================================================================
# Exogenous variables
# ======================================================================================================================

qCHh.l[c_,t] = IO_qCHh[c_,t];
pCHh.l[c_,t] = IO_pCHh[c_,t];

 # Elasticities of substitution in the private consumption nests
 eC.L(c_)              = 0.3;
 eC.L('ctot')          = 0.3;

 eC.l('cNonHou')       = 1.04; # Elasticity between housing and other 
 #  eC.l("cTouSerGooEne") = 0.26; #Elasiticitet imellem transport (bil pt. - på sigt transport) og andet 
 eC.l("cTouSerGoo")    = 0.94; # Elasticity between services and tourism on one side and foods and non-foods on the other side
 eC.l("cTouSer")       = 1.25; # Elasticity between tourism and services 
 eC.l("cGoo")          = 0.3;  # Elasticity between foods and non-foods 
 eC.l("cFood")         = 1.1;  # Elasticity between the food-goups: "vegetable, dairy, meat, and other" "
 eC.l("cFoodMeat")     = 1.3;  # Elasticity between pigs, cattle, fish and poultry
 eC.l("cCar")          = 0;    # Elasticity between manufacture of machines and electr., other manufacture industries, wholesale and retail trade ect., wholesale, retail. 

* Kapitalindomstskat
t_r.l[tData]           = 0.308;


d1qCHH_EV.l[tData]     = 0;

qChh.l['ccar',t]       = ExtFor_qCars[t]/MAKRO_growth_factor[t];



vPersincome.l[tData]   = 1000;

# Initial values. Actual return and wealth is calculated in the adjustment to MAKRO
vWealth.l[t]           = (ExtFor_vHH['IndlAktier','tot',t]+ExtFor_vHH['UdlAktier','tot',t]+ExtFor_vHH['Obl','tot',t]+ExtFor_vHH['Bank','tot',t]-ExtFor_vHH['BankGaeld','tot',t]+ExtFor_vHH['Pens','tot',t]*0.5)/MAKRO_inf_growth_factor[t];  
vHHxAfk.l[t]           = vWealth.l[t] * 0.05;

# The share of equity in stocks reflects the shares (in 2030) in MAKRO. 50 pct. of the pension assets are included in the calculation due to the pensions assets being part of the finansiel wealth in GrønREFORM. However, the pension-share is downscaled to match MAKRO in which the pension assets are (primarily) taxed at the time of payment
sDomesticEquity.l[t]   = (ExtFor_vHH['IndlAktier','tot','2030']+ExtFor_vPension['IndlAktier','2030']*0.5)/MAKRO_inf_growth_factor[t] /  vWealth.l['2030'];
sForeignEquity.l[t]    =  (ExtFor_vHH['UdlAktier','tot','2030'] +ExtFor_vPension['UdlAktier','2030']*0.5)/MAKRO_inf_growth_factor[t]  /  vWealth.l['2030'];


# OLG-consumers 
  eC_R.l               = 0.5;
  pDeath.l             = 0.01;  
  beta.l[tData]        = 0.995;
  s_R.l[tData]         = 0.6;

# Just starting values
  omega.l[tData]      = 1;
  H.l[tData]          = 1;

 $GROUP G_consumers_data 

; 
$ENDIF


# ======================================================================================================================
# Static calibration
# ======================================================================================================================
$IF %stage% == "static_calibration":
  $BLOCK B_consumers_static_calib 
      $LOOP00 E_pCHH_cCar:
        {name}_t0{sets}$(t0[t]).. {LHS} =E= {RHS};
      $ENDLOOP00 
  $ENDBLOCK
  $GROUP G_consumers_static_calibration
    G_consumers_endo
      uC[c_,t]$(tx0[t] and sum(cNest, cNest2c_[cNest,c_]))
     -qCHH[c_,t], shareC$(tx0[t]) 
     -qC$(tx0[t] and sameas[c_,'cCar']), rDepr_car$(tx0[t])
     -JvWealth
     -qCHH_nR, -qCHH_R

     -H, -omega, -qDisUtility, -qUtility_R, -qUtility_nR, -vLeisureAdjustedIncome
  ;

  $GROUP G_consumers_static_calibration_exo
    G_consumers_exo
    qCHH[c_,t]$(tx0[t]), -uC[c_,t]
    -shareC
     qC$(tx0[t] and sameas[c_,'cCar']), -rDepr_car
    JvWealth$(tx0[t])
    pC$(t0[t]  and sameas[c_,'cCar']) 
    j_pCHH_car$(tx0[t])
    qCHH_nR$(tx0[t]), qCHH_R$(tx0[t])


    -Eta_Hours, -beta, -eC_R, -eHt, -pDeath, -s_R, -t_r
    -JvWealth_LongTerm, -JvWealth_MediumTerm, -JvWealth_MediumLongTerm
  ;


  $MODEL M_consumers_static_calibration
    B_consumers
   B_consumers_static_calib

    -E_pCHH_cCar
    -E_qC_cCars_tEnd
  ;

$ENDIF

# ======================================================================================================================
# Dynamic calibration
# ======================================================================================================================
$IF %stage% == "dynamic_calibration":

  $BLOCK B_consumers_calib 
        E_ConstantvWealth[t]$(tEnd[t])..                          vWealth[t]  =E= vWealth[t-1];  # Only used in the dynamic calibration
  $ENDBLOCK


 $GROUP G_consumers_calib    
    G_consumers_endo 
    JvWealth_LongTerm #E_ConstantvWealth
    j_pCHH_car$(t2[t]), -qCHH$(t1[t] and sameas[c_,'cCar'])
  ;
 
 $GROUP G_consumers_calib_exo
    G_consumers_exo
    -JvWealth_LongTerm #E_ConstantvWealth
     -j_pCHH_car$(t2[t]), qCHH$(t1[t] and sameas[c_,'cCar'])
  ;

  $MODEL M_consumers_calib 
  B_consumers
  B_consumers_calib
  B_consumers_olg
 ;

$ENDIF