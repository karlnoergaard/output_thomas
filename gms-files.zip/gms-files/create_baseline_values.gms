$GROUP G_baseline # Variables that we want to be reported as baseline values (her listes de modelvariable, som man vil have en baseline-værdi af)
	G_baseline
       
       qEmmF
       qEmmLUC12
	thetaID
	qEmmProdE
	qEmmProdxE
       qEmmProdS
       qLand
       pLand
       qPlant 
       pPlant 
       qAni 
       pAni
       qREgj
	vREa
       sumqEmmCCSubio
       tHectareSubsidy

       #Til B_shock
       pC #Også til EV-mål
       pCtourist
       pCHh
       pX
       pX_y
       pX_m
       pX_s
       pXE_ElNl
       pXE

       #EV-mål
       vLeisureAdjustedIncome
       Hwage
       Htrans
       Htax
       Hleisure
       Hother
       pU
       sEquityDKownedEndo 

       pY
       qY
       qC_y
       qX_y
       pC_y
       pY_CET
       qY_CET
       vY
       pY0
       nEmployed_s
       w
       vGrossValAdd
       pPlant
       vX_y
       pX_y_hat
       qX_y
       qEmmTot
       qX
       qCHh
       qL
       vWealth_shockCorrection
       qGDP
       Z
       thetaProd
       qL
       qRxE
       qK
       qE
       qProd$(sameas[prd,'Eother'])
       pE_CGE
       pProd$(sameas[prd,'Eother'])
       pProd$(sameas[prd,'Etrans'])
       qProd$(sameas[prd,'Etrans'])
       pRxE
       pK
       qRxE_y 
       qRxE_m
       pL
       pM_CET
       pGovDepr
       qGovDepr
       tCO2_REmarg
       vLeisureAdjustedIncome
       pKELBM
       pProd$(sameas[prd,'KE'])
       qProd$(sameas[prd,'KE'])
       qKELBM
       qEmmF
       qEmmLUC12
       qF5_aff_denom
       pHV2_hoved_AFF
       pV2_tynd_AFF
       pC_ym
       qLandUdtag_pot
       qLandUdtag_tot
       qLandBRK 
       qLandSKO
       pI_s
       uEmmAgrAni
       uManurePerAnimal
       pAfkastPerHa_alternativjordbrug ""
       pTotalRevenue_aff_perHA ""
       qEmmAgrxE
       pPlant_cet
       pAni_cet
       pPlant_cet 
       qAni_cet
       qPlant_cet 
       pD_manure 
       qD_manure 
       qLand_nonproductive
       pAni
       qAni 
       pPlant 
       qPlant
       pPlant_base
       pRxE
       pK
       pAni_pK_alt
       pTobinsQ_ani_alt
       pPlant_pK_alt
       pTobinsQ_plant_alt
       pK_alt
       pTobinsQ_alt
       qI_s
       pLand_avg
       tHectareSubsidy
       pREgj 
       pRE_base
       pRE_base_marg
       qEmmTot
       tvRE 
       tvREmarg 
       tqRE 
       tqREmarg
       tCO2_ProdxE
       vRxE_m_Shutdown_E[purpose,s,t] "Energy-related import costs of shutting down sector"
       vRxE_m_Shutdown_xE[s,t] "Non-energy related import costs of shutting down sector"
       vBottomDeduction_EAFG[purpose,energy19,r,t] ""
       vBottomDeduction_CO2[purpose,energy19,r,t] ""
       vBottomDeduction_CO2_ETS[r,t] ""
       pEP 
       qEP 
       rShutdown[purpose,s,t] ""
       uShutdownE[purpose,s,t] ""
       vtCO2_ETS_marg
;

$GROUP G_baseline_KF #For these varaibles changed are measured relative to KF-baseline, and hence should only be set once
       qF5_AFF
       qLand 
       vDBII
       pReturnPerHa_alt_landallocation
       pTotalOperatingSurplus_AFF
       
;

# Create baseline variables for reporting
$onmultiR
$GROUP G_baseline_newvars # (her dannes _baseline-variablene)
       $LOOP G_baseline:
              {name}_baseline{sets} ""
       $ENDLOOP

       $LOOP G_baseline_KF:
              {name}_baseline{sets} ""
       $ENDLOOP

;       
$offmulti

$LOOP G_baseline: # (her får _baseline-variablene sin værdi)
{name}_baseline.l{sets} = {name}.l{sets};
$ENDLOOP

$IF %setKFbaselinevalues%==1:
       $LOOP G_baseline_KF: # (her får _baseline-variablene sin værdi)
       {name}_baseline.l{sets} = {name}.l{sets};
       $ENDLOOP
$ENDIF