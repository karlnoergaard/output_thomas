# ======================================================================================================================
# Data
# ======================================================================================================================
# In this file we import data from various sources and re-arrange the data as needed.
# We then assign data values to model variables.
# Finally, we adjust the model variables for inflation and growth.

set_time_periods(2016,2019);
set_data_periods(2016,2019);
set_bf_calib_periods(%BF_calib_start%,%BF_calib_end%, %BF_calib_prices_start%,%BF_calib_prices_end%);

# ----------------------------------------------------------------------------------------------------------------------
# Adjustment for inflation and growth
# ----------------------------------------------------------------------------------------------------------------------
parameters
  fq "1 year adjustment factor for growth in quantities"
  fp "1 year adjustment factor for price inflation"
  fv "1 year composite growth and inflation factor to adjust for growth in values"
  growth_factor[t] "Geometric series of fq, set to 1 in base_year"
  inf_factor[t] "Geometric series of fp, set to 1 in base_year"
  inf_growth_factor[t] "Geometric series of fv, set to 1 in base_year"
;
fq = (1 + gq);
fp = (1 + gp);
fv = fq * fp;
growth_factor[t] = 1/fq**(t.val - %base_year%);
inf_factor[t]    = 1/fp**(t.val - %base_year%);
inf_growth_factor[t] = inf_factor[t] * growth_factor[t];

# ======================================================================================================================
# Import data
# ======================================================================================================================

# ======================================================================================================================
# External forecast data. We can use either KP21 or MAKRO as external Macroeconomic forecast 
# ======================================================================================================================

# Indlæsning af MAKRO-databank. Bemærk MAKRO-databanken er vækst- og inflationskorrigeret til 2010-niveau. Alt data indlæses normalvis uden at
# være korrigeret. GrønREFORM-variable sættes til disse ukorrigerede variable, hvorefter alle  GrønREFORM-variable vækst- og inflationskorrigeres 
# til 2015-niveau i model.gms (via inf_growth_adjust). Derfor skal alle MAKRO-værdier løftes med vækst og inflation og alle mængder skal løftes 
# med vækst. Til dette anvendes MAKRO's vækst- og inflationskorrektion, da der dermed også korrigeres i forhold til MAKROs anvende af 2010-niveau. 

parameters MAKRO_growth_factor[t],MAKRO_inf_growth_factor[t]
ExtFor_nPop[*,t],ExtFor_nLaborForce[*,t],ExtFor_nEmployed[*,t], 
ExtFor_nUnEmployed[*,t],ExtFor_u[t], ExtFor_uStruct[t], ExtFor_tCorp[t],ExtFor_rInterest[*,t],ExtFor_w[t],ExtFor_vTrans[*,t], ExtFor_vtSource[t], 
ExtFor_vGovRev[t], ExtFor_tLSubsidy[*,t],ExtFor_vTransCivilServants[*,t], ExtFor_vtAM[*,t], ExtFor_vtMedia[t], 
ExtFor_vtPersIncRest[*,t], ExtFor_vtCapPen[*,t], ExtFor_vPensReceiveCap[*,t], ExtFor_vtEU[t], ExtFor_rReval[*,t], ExtFor_vHH[*,*,t], ExtFor_vHHPens[*,*,t], 
ExtFor_vtPAL[t], ExtFor_vInterestGovAssets[t], ExtFor_vInterestGovDebt[t], ExtFor_vGovAssets[*,t], ExtFor_vGovDebt[*,t], ExtFor_vtCarWeight[*,t], 
ExtFor_qCars[t], ExtFor_vSubEU[t], ExtFor_vSubProductionRest[*,t], ExtFor_vBequest[*,t], ExtFor_vtBequest[*,t], ExtFor_vGovProfit[t], 
ExtFor_vGovRent[t], ExtFor_vGovReceiveF[t], ExtFor_vGovReceiveF_EU[t], ExtFor_vGovReceiveF_Kap[t], ExtFor_vGovReceiveF_Rest[t], ExtFor_vGovReceiveHH[t], ExtFor_vGovReceiveFirms[t], ExtFor_vtChurch[*,t], ExtFor_sChurch[t], ExtFor_vIncTaxable[*,t], 
ExtFor_vPersAllowance[*,t], ExtFor_vCont[*,t],  ExtFor_vGov2Foreign[t], ExtFor_vGov2HH[t], ExtFor_vGov2Firms[t], ExtFor_vGovLand[t], 
ExtFor_rEmploymentGap[t], ExtFor_rOutputGap[t], ExtFor_vGovNetWealth[t], ExtFor_vGov[*,t], ExtFor_vGovFunds[t], ExtFor_vGovReval[t], 
ExtFor_sGovAssets[*,t], ExtFor_sGovMortgages2Debt[t], ExtFor_vPensionReceiveMain[*,t], ExtFor_vSubProduct[t], ExtFor_vGovPrimBalance[t], 
ExtFor_vSubProduction[t], ExtFor_vtCorp[*,t], ExtFor_vtCorpNorth[t], ExtFor_pGovDepr[*,t], ExtFor_qGovDepr[*,t], ExtFor_vtIndirect[t], ExtFor_vWealth[*,t]
ExtFor_vHHxAfk[*,t], ExtFor_vPension[*,t], ExtFor_vPensUdb[*,*,t], ExtFor_vPensIndb[*,*,t], ExtFor_vCLejebolig[*,t], ExtFor_vBoligUdgift[*,t], ExtFor_pC[*,t], ExtFor_vGDP[t]
ExtFor_vOffFraUdlKap[t], ExtFor_vOffFraUdlEU[t], ExtFor_vOffFraUdRest[t], ExtFor_uC[*,t], ExtFor_qCTurist[*,t], ExtFor_vC[*,t];

singleton set tBasisMAKRO[t]/2020/;

#  execute_loaddc %MACRODATA% tBasisMAKRO=tBase;
#  display tBasisMAKRO;
#  $exit
MAKRO_growth_factor[t] = growth_factor[t]/growth_factor[tBasisMAKRO];
MAKRO_inf_growth_factor[t] = inf_growth_factor[t]/inf_growth_factor[tBasisMAKRO];

#  execute_load %MACRODATA% MAKRO_inf_growth_factor=inf_growth_factor;
#  execute_load %MACRODATA% MAKRO_growth_factor=growth_factor;


# MAKRO-variable til arbejdsmarkedet ((v) == variablen også er i KP21-databank)
execute_load %MACRODATA% ExtFor_nPop=nPop.l; #(v) 
execute_load %MACRODATA% ExtFor_nLaborForce=nSoegBaseHh.l; #(v)
#  execute_load %MACRODATA% ExtFor_nEmployed=nLHh.l; #(v) £:AKB: Skal den her ikke bare være nL[stot]?
execute_load %MACRODATA% ExtFor_nEmployed=nL.l;
execute_load %MACRODATA% ExtFor_nUnEmployed=nSoegHh.l; $IF %calib2KP%==1: ExtFor_nUnEmployed['tot',t] = ExtFor_nLaborForce['tot',t] - ExtFor_nEmployed['tot',t]; $ENDIF

$IF %calib2KP%!=1: execute_load %MACRODATA% ExtFor_u=rBruttoLedig.l; $ENDIF $IF %calib2KP%==1:  execute_load %MACRODATA% ExtFor_u=rLedig.l; $ENDIF 
$IF %calib2KP%!=1: execute_load %MACRODATA% ExtFor_uStruct=srBruttoLedig.l; $ENDIF $IF %calib2KP%==1:  execute_load %MACRODATA% ExtFor_uStruct=srLedig.l; $ENDIF 

execute_load %MACRODATA% ExtFor_vTrans=vOvf.l; #(v)


# MAKRO-variable til produktion
execute_load %MACRODATA% ExtFor_rInterest = rRente.l; #(v)
execute_load %MACRODATA% ExtFor_tCorp=tSelskab.l; #(v)


# MAKRO-variable til io-modul
execute_load %MACRODATA% ExtFor_w=vhW.l; #(v)




# MAKRO-variable til government

#Primær balance
execute_load %MACRODATA% ExtFor_vGovPrimBalance = vPrimSaldo.l;

#Renter og formuer. 
execute_load %MACRODATA% ExtFor_vInterestGovAssets=vOffRenteInd.l; #(v)			 		
execute_load %MACRODATA% ExtFor_vInterestGovDebt=vOffRenteUd.l; #(v)						
execute_load %MACRODATA% ExtFor_vGovAssets=vOffAkt.l; #(v)					
execute_load %MACRODATA% ExtFor_vGovDebt=vOffPas.l; #(v)						
#  execute_load %MACRODATA% ExtFor_vGovFunds=vOffFonde.l; #(v) AKB: Bruges ikke?
#  execute_load %MACRODATA% ExtFor_vGovNetWealth=vOffNetFormue.l; #(v) AKB: Bruges ikke?								
#Direkte skatter
execute_load %MACRODATA% ExtFor_vtSource=vtKilde.l; #(v)
execute_load %MACRODATA% ExtFor_vPersAllowance=vPersFradrag.l; #(v)				
execute_load %MACRODATA% ExtFor_vtAM=vtHhAM.l; #(v) 						
execute_load %MACRODATA% ExtFor_vtMedia=vtMedie.l; #(v) 	
execute_load %MACRODATA% ExtFor_vtPersIncRest=vtPersRest.l; #(v)
execute_load %MACRODATA% ExtFor_vtCarWeight=vtHhVaegt.l; #(v)
execute_load %MACRODATA% ExtFor_vtPAL=vtPAL.l; #(v)
$IF %calib2KP%!=1: execute_load %MACRODATA% ExtFor_vHH=vHHAkt.l; $ENDIF $IF %calib2KP%==1:  execute_load %MACRODATA% ExtFor_vHH=vHh.l; $ENDIF 
execute_load %MACRODATA% ExtFor_vHHPens = vHHpens.l;
ExtFor_vHHpens['penstot','tot',t] = ExtFor_vHHpens['pensx','tot',t] + ExtFor_vHHpens['Kap','tot',t] + ExtFor_vHHpens['Alder','tot',t];
execute_load %MACRODATA% ExtFor_vtCorp = vtSelskab.l;
# execute_load %MACRODATA% ExtFor_vtCorpNorth = vtSelskabNord.l;

#Indirekte skatter
execute_load %MACRODATA% ExtFor_vtIndirect=vtIndirekte.l; #(v)						
execute_load %MACRODATA% ExtFor_vtEU=vtEU.l; #(v)														
#Øvrige indtægter
execute_load %MACRODATA% ExtFor_vGovProfit=vOffVirk.l; #(v)						
execute_load %MACRODATA% ExtFor_vGovRent=vJordrente.l; #(v)							

$IF %calib2KP%==1: execute_load %MACRODATA% ExtFor_vGovReceiveF=vOffFraUdl.l; $ENDIF $IF %calib2KP%!=1: execute_load %MACRODATA% ExtFor_vGovReceiveF_EU=vOffFraUdlEu.l; $ENDIF $IF %calib2KP%!=1: execute_load %MACRODATA% ExtFor_vGovReceiveF_Kap=vOffFraUdlKap.l; $ENDIF $IF %calib2KP%!=1: execute_load %MACRODATA% ExtFor_vGovReceiveF_Rest=vOffFraUdlRest.l; $ENDIF $IF %calib2KP%!=1: ExtFor_vGovReceiveF[t] = ExtFor_vGovReceiveF_EU[t] + ExtFor_vGovReceiveF_Kap[t] + ExtFor_vGovReceiveF_Rest[t] $ENDIF

execute_load %MACRODATA% ExtFor_vGovReceiveHH=vOffFraHh.l; #(v)				
execute_load %MACRODATA% ExtFor_vGovReceiveFirms=vOffFraVirk.l; #(v)				
execute_load %MACRODATA% ExtFor_vtBequest=vtArv.l;  #(v) 						
execute_load %MACRODATA% ExtFor_vBequest=vArv.l; $IF %calib2KP%==1: execute_load %MACRODATA2% ExtFor_vBequest = vArv.l; $ENDIF   #(-)		 			
execute_load %MACRODATA% ExtFor_vtChurch=vtKirke.l; #(v)							
execute_load %MACRODATA% ExtFor_vCont=vBidrag.l; #(v)						
#udgifter

$IF %calib2KP%!=1: execute_load %MACRODATA% ExtFor_vSubProductionRest=vSubYRest.l;$ENDIF $IF %calib2KP%==1: execute_load %MACRODATA2% ExtFor_vSubProductionRest = vSubYRest.l; $ENDIF #(-)	

execute_load %MACRODATA% ExtFor_vSubEU=vSubEU.l; #(v)	
#note: != betyder "ikke-lig"
$IF %calib2KP%!=1: execute_load %MACRODATA2% ExtFor_vGovLand=vOffLandKoeb.l; $ENDIF
$IF %calib2KP%==1: execute_load %MACRODATA% ExtFor_vGovLand=vOffLandKoeb.l; $ENDIF  

execute_load %MACRODATA% ExtFor_vGov2Firms=vOffTilVirk.l; #(v)				
execute_load %MACRODATA% ExtFor_vGov2HH=vOffTilHh.l;  $IF %calib2KP%==1: execute_load %MACRODATA2% ExtFor_vGov2HH=vOffTilHh.l; $ENDIF 	#(-)					
execute_load %MACRODATA% ExtFor_vGov2Foreign=vOffTilUdl.l; #(v)			
#Strukturel saldo (er ikke modelleret endnu)
execute_load %MACRODATA% ExtFor_rEmploymentGap=rBeskGab.l; #(v)			
execute_load %MACRODATA% ExtFor_rOutputGap=rBVTGab.l;  $IF %calib2KP%==1: execute_load %MACRODATA2% ExtFor_rOutputGap=rBVTGab.l; $ENDIF#(-)				



# MAKRO-variable til consumers
execute_load %MACRODATA% ExtFor_qCars=qBiler.l; #(v)
execute_load %MACRODATA% ExtFor_vWealth =vHhx.l; 
execute_load %MACRODATA% ExtFor_vHHxAfk =vHHxAfk.l;
execute_load %MACRODATA% ExtFor_vPension = vPens.l; 
execute_load %MACRODATA% ExtFor_vCLejebolig = vCLejebolig.l; 
execute_load %MACRODATA% ExtFor_vBoligUdgift = vBoligUdgift.l; 
execute_load %MACRODATA% ExtFor_pC = pC.l;
execute_load %MACRODATA% ExtFor_vGDP = vBNP.l;
execute_load %MACRODATA% ExtFor_uC = uC.l;
execute_load %MACRODATA% ExtFor_qCTurist=qCTurist.l
execute_load %MACRODATA% ExtFor_vC = vC.l;  
#  execute_load %MACRODATA% ExtFor_vPensUdb = vPensUdb.l;
#  execute_load %MACRODATA% ExtFor_vPensIndb = vPensIndb.l;

execute_load %MACRODATA% ExtFor_vPensUdb  = vHHPensUdb.l; 
execute_load %MACRODATA% ExtFor_vPensIndb = vHHPensIndb.l;


#Anm.: Ovenstående MAKRO-variable og vækst- og inflationskorrektion er tjekket igennem af THN. Nedenstående MAKRO-variable er ikke. /THN 29-6-2021


#Makrovariable til offentlig produtkion/sektor
parameter ExtFor_vOffDirInv[t],ExtFor_pOffAfskr[k_,t],ExtFor_vOffAfskr[k_,t],ExtFor_qOffAfskr[k_,t],ExtFor_fDemoTraek[*,t],ExtFor_qI_s(*,*,t),ExtFor_qProd_s(*,t),ExtFor_fLProd_s[*,t],ExtFor_rL2nL[t];
execute_load %MACRODATA% ExtFor_vOffDirInv = vOffDirInv.l; #(v), i productoin
execute_load %MACRODATA% ExtFor_pOffAfskr  = pOffAfskr.l; #(v)
execute_load %MACRODATA% ExtFor_qOffAfskr  = qOffAfskr.l; #(v) 
execute_load %MACRODATA% ExtFor_vOffAfskr  = vOffAfskr.l; #(v)
execute_load %MACRODATA% ExtFor_fDemoTraek = fDemoTraek.l; #(v)

execute_load %MACRODATA% ExtFor_qI_s=qI_s.l; #(v)
PARAMETER ExtFor_vI_s[*,*,t];
execute_load %MACRODATA% ExtFor_vI_s=vI_s.l;


$IF %calib2KP%!=1: execute_load %MACRODATA% ExtFor_qProd_s=qProd.l; $ENDIF $IF %calib2KP%==1: execute_load %MACRODATA% ExtFor_qProd_s = fProd.l; $ENDIF


#  execute_load %MACRODATA% ExtFor_rL2nL=rL2nL.l; #(v)
#  execute_load %MACRODATA2% ExtFor_rL2nL=rL2nL.l; #(v)


#Makrovariable til grundforløb
parameter ExtFor_nL(*,t), ExtFor_rAfskr[*,*,t];
execute_load %MACRODATA% ExtFor_nL=nL.l; #(v)
execute_load %MACRODATA% ExtFor_rAfskr=rAfskr.l; $IF %calib2KP%==1: execute_load %MACRODATA2% ExtFor_rAfskr=rAfskr.l;$ENDIF #(Since both MAKRO and ADAM uses same IO-data this is the same depreciation rate)


#Til kalibrering af IO
PARAMETER ExtFor_qBNP[t], ExtFor_vhw[t], ExtFor_qXy[*,t], ExtFor_qXm[*,t], ExtFor_qX[*,t], ExtFor_qC[*,t], ExtFor_pXUdl[*,t], ExtFor_pX[*,t], ExtFor_pXm[*,t], ExtFor_eXUdl[*], 
			   ExtFor_pM[*,t], ExtFor_pIOy[*,*,t], ExtFor_qIOy[*,*,t], ExtFor_vIOy[*,*,t], ExtFor_vX[*,t], ExtFor_vIOm[*,*,t], ExtFor_qIOm[*,*,t], ExtFor_pIOm[*,*,t], ExtFor_qG[*,t];
execute_load %MACRODATA% ExtFor_qBNP=qBNP.l;
execute_load %MACRODATA% ExtFor_vhw=vhw.l;
execute_load %MACRODATA% ExtFor_qXy=qXy.l;
execute_load %MACRODATA% ExtFor_qXm=qXm.l;
execute_load %MACRODATA% ExtFor_qX=qX.l;
execute_load %MACRODATA% ExtFor_qC=qC.l;
execute_load %MACRODATA% ExtFor_pXUdl=pXudl.l;
execute_load %MACRODATA% ExtFor_pX=pX.l;
execute_load %MACRODATA% ExtFor_eXUdl=eXudl.l;
execute_load %MACRODATA% ExtFor_pM=pM.l;

execute_load %MACRODATA% ExtFor_pIOy=pIOy.l;
execute_load %MACRODATA% ExtFor_qIOy=qIOy.l;
execute_load %MACRODATA% ExtFor_vIOy=vIOy.l;
execute_load %MACRODATA% ExtFor_vX=vX.l;
execute_load %MACRODATA% ExtFor_pXm=pXm.l;
execute_load %MACRODATA% ExtFor_vIOm=vIOm.l;
execute_load %MACRODATA% ExtFor_pIOm=pIOm.l;
execute_load %MACRODATA% ExtFor_qIOm=qIOm.l;
execute_load %MACRODATA% ExtFor_qG=qG.l;

# ----------------------------------------------------------------------------------------------------------------------
# Kvote-data
# ----------------------------------------------------------------------------------------------------------------------

PARAMETER kvotedata[brch,t], vkvote_data[brch,t];
execute_loaddc '../Data/CO2kvoter/kvotedata.gdx' kvotedata = kvotedata.l vkvote_data = vkvote.l;

#---------------------------------------------------------------------------------------------
#  Andele til opsplitning af slagteribranche
#---------------------------------------------------------------------------------------------

$PGROUP OPSPLITNINGSANDELE
  sYS56[IO_56_c_] ""
  sMS56[IO_56_c_] ""
  sXS56[IO_56_c_] ""
  sCORR56[IO_56_c_,t] ""
  sLS56[IO_56_c_] ""

  sCORR56afgsub[IO_56_c_,afgsub,t] ""

  sYS[sSlagteri] ""

  sYS_cement[sMineralogi] ""
  sYS_svin[sSvin] ""
  sL_cement[sMineralogi] ""
  sL_svin[sSvin] ""
;

#2019-nøgler brugt på alle år. Burde laves for alle år
sYS56['10012'] = 0.845720663;
sYS56['10013'] = 0.063726313;
sYS56['10011'] = 1 - sYS56['10012'] - sYS56['10013'];

sYS['10012']   = 0.845720663;
sYS['10013']   = 0.063726313;
sYS['10011']   = 1 - sYS['10012'] - sYS['10013'];

sMS56['10012'] = 0.622507544;
sMS56['10013'] = 0.169845866;
sMS56['10011'] = 1 - sMS56['10012'] - sMS56['10013'];

sXS56['10012'] = 0.882744421;
sXS56['10013'] = 0.036418332;
sXS56['10011'] = 1 - sXS56['10012'] - sXS56['10013'];

#Nøgler til cement 
sYS56['23001'] = 0.087;
sYS56['23002'] = 1-sYS56['23001'];

sYS_cement['23001'] = 0.087;
sYS_cement['23002'] = 1-sYS_cement['23001'];

sMS56['23001'] = 0.038;
sMS56['23002'] = 1-sMS56['23001'];

sXS56['23001'] = 0.09;
sXS56['23002'] = 1-sXS56['23001'];

sLS56['23001'] = 0.037;
sLS56['23002'] = 1-sLS56['23001'];

sL_cement['23001'] = 0.037;
sL_cement['23002'] = 1-sL_cement['23001'];

#Nøgler til svin 
sYS56['01051'] = 0.46; sYS56['01052'] = 1 - sYS56['01051'];
sMS56['01051'] = 0.05; sMS56['01052'] = 1 - sMS56['01051']; #Antager 5% import af smågrise -> Tjek med fuld IO

sYS_svin['01051'] = 0.46; sYS_svin['01052'] = 1-sYS_svin['01051'];

sXS56['01051'] = 0.95; sXS56['01052'] = 1-sXS56['01051'];
# ----------------------------------------------------------------------------------------------------------------------
# ENERGY & EMISSIONS
# ----------------------------------------------------------------------------------------------------------------------

execute_loaddc '../Data/Energimatricer/energy_2017_2019.gdx' $LOOP G_energiIO_in: {name}={name} $ENDLOOP;
execute_loaddc '../Data/Energimatricer/energy_2017_2019.gdx' $LOOP G_emissions_in: {name}={name} $ENDLOOP;


parameter  GWP_obs[emm], GWP_UN_obs[emm];

execute_load "../Data/Emissionskoefficienter/gdx_emissionskoefficienter.gdx" GWP_obs=GWP_conversion.l;
execute_load "../Data/Emissionskoefficienter/gdx_emissionskoefficienter.gdx" GWP_UN_obs=GWP_conversion_UN.l;

GWP_UN_obs['CH4'] = 28; GWP_UN_obs['N2O'] = 265; GWP_UN_obs['SF6'] = 23500/22800;#We update to AR5 standard. For SF6, since the emissions inventory from DST is measured in CO2e, we use the fraction: GWP_new/GWP_old

  #AKB: KF24_National_Energibalance.xlsx
  PARAMETER uEmmHardCoded[emm,energy19];
   uEmmHardCoded['CO2ubio','refinery gas']             = 53.25;
   uEmmHardCoded['CO2ubio','gasoline for transport']   = 73.03;
   uEmmHardCoded['CO2ubio','jet petroleum']            = 72.18;
   uEmmHardCoded['CO2ubio','Oil products']             = 77.6; #Taget som vægtet gennemsnit af LPG og Fuelolie i 2030, for KF23 energibalance med vægtede emissionsfaktorer.
   uEmmHardCoded['CO2ubio','Diesel for transport']     = 75;
   uEmmHardCoded['CO2ubio','Natural gas (Extraction)'] = 55.55;
   uEmmHardCoded['CO2ubio','Natural gas incl. biongas']= 55.55;
   uEmmHardCoded['CO2bio','Natural gas incl. biongas'] = 55.55;
   uEmmHardCoded['CO2ubio','Coal and coke']            = 94.3;
   uEmmHardCoded['CO2ubio','Waste']                    = 42.5;  # 
   uEmmHardCoded['CO2bio','Waste']                     = (1-(42.5/94.44))*107.64; #42.5/94.44 er ubio andelen (94.44 er den tekniske ubio emmkoeff). 107.64 er den tekniske emissionskoefficient for bioaffald
   uEmmHardCoded['CO2ubio','Waste oil']                = 128; 
   uEmmHardCoded['CO2bio','Biodiesel']                 = 77.7; 
   uEmmHardCoded['CO2bio','Bioethanol']                = 72; 

$IMPORT data_DSTenergy.gms;
  
  #NOX-afgift (2019-værdi). Bør opdateres med seneste dataår. Alle taget fra https://info.skat.dk/data.aspx?oid=1946602 i 2019.
  PARAMETER tNOx_REomregner[energy19], tNOX_CEomregner[energy19];
   tNOx_REomregner['Oil products']              = 3744;   # 
   tNOx_REomregner['Refinery gas']              = 5200;   #
   tNOx_REomregner['Diesel for transport']      = 3629.5; #
   tNOx_REomregner['Natural gas incl. biongas'] = 3960; 
   tNOx_REomregner['Gasoline for transport']    = 3290;
   tNOx_REomregner['Coal and coke']             = 26496;
   tNOx_REomregner['Firewood and woodchips']    = 1000;
   tNOx_REomregner['Wood pellets']              = 1000;
   tNOx_REomregner['Biogas']                    = 1000;

   tNOx_CEomregner['Gasoline for transport']    = 3290;   #
   tNOx_CEomregner['Oil products']              = 3744;   #
   tNOx_CEomregner['Diesel for transport']      = 3629.5; #
   tNOx_CEomregner['Natural gas incl. biongas'] = 3960; 


	#---------------------------------------------------------------------------------------------------------------------
	# Remove extremely small values (The raw energy-data contains extremely small values. We remove these. Currently we filter out values below 0.0001 PJ = 100GJ, which roughly corresponds to the electricty consumption of 6 households.)
	#---------------------------------------------------------------------------------------------------------------------

	#Creates groups of auxiliary variables to adjust energy-data
	$GROUP G_energy_VQ 
	   $LOOP G_energy_modellevel_V:
	   	{name}_VAR{sets} ""
	   $ENDLOOP 
	   $LOOP G_energy_modellevel_Q:
    	{name}_VAR{sets} ""
	   $ENDLOOP
	 ;

	$GROUP G_energy_V 
	   $LOOP G_energy_modellevel_V:
	   	{name}_VAR{sets} ""
	   $ENDLOOP 
	;

  $GROUP G_energy_P 
    $LOOP G_energy_modellevel_P:
      {name}_VAR{sets} ""
    $ENDLOOP 
  ; 

	$GROUP G_energy_Q
	   $LOOP G_energy_modellevel_Q:
    	{name}_VAR{sets} ""
	   $ENDLOOP
	;

	$GROUP G_energy_taxes 
	   $LOOP G_energy_modellevel_taxes:
	   	{name}_VAR{sets} ""
	   $ENDLOOP
	;

	#Trim data 
	$SETLOCAL min_level_energy 0.0001
		EN_qCE[purpose,energy19,t]$(EN_qCE[purpose,energy19,t] < %min_level_energy%) = 0; 
		EN_qLE[purpose,energy19,t]$(abs(EN_qLE[purpose,energy19,t]) < %min_level_energy%) = 0;
		EN_qRE[purpose,energy19,r,t]$(EN_qRE[purpose,energy19,r,t] < %min_level_energy%) = 0; 
		EN_qXE[purpose,energy19,t]$(EN_qXE[purpose,energy19,t] < %min_level_energy%) = 0;

		EN_vnCE[purpose,energy19,t]$(not EN_qCE[purpose,energy19,t]) = 0;
		EN_vnLE[purpose,energy19,t]$(not EN_qLE[purpose,energy19,t]) = 0;
		EN_vnRE[purpose,energy19,r,t]$(not EN_qRE[purpose,energy19,r,t]) = 0;
		EN_vnXE[purpose,energy19,t]$(not EN_qXE[purpose,energy19,t]) = 0;

		EN_vCO2_CE[purpose,energy19,t]$(not EN_qCE[purpose,energy19,t]) 	   = 0;
		EN_vCO2_RE[purpose,energy19,r,t]$(not EN_qRE[purpose,energy19,r,t])    = 0; 
		EN_vEAFG_CE[purpose,energy19,t]$(not EN_qCE[purpose,energy19,t])       = 0; 
		EN_vEAFG_RE[purpose,energy19,r,t]$(not EN_qRE[purpose,energy19,r,t])   = 0;
		EN_vEAFG_XE[purpose,energy19,t]$(not EN_qXE[purpose,energy19,t])       = 0;  
		EN_vSO2_CE[purpose,energy19,t]$(not EN_qCE[purpose,energy19,t])        = 0;
		EN_vSO2_RE[purpose,energy19,r,t]$(not EN_qRE[purpose,energy19,r,t])    = 0;
    EN_vPSO_CE[purpose,energy19,t]$(not EN_qCE[purpose,energy19,t])        = 0;
    EN_vPSO_RE[purpose,energy19,r,t]$(not EN_qRE[purpose,energy19,r,t])    = 0;
    EN_vPSO_XE[purpose,energy19,t]$(not EN_qXE[purpose,energy19,t])        = 0;
    EN_vNOx_CE[purpose,energy19,t]$(not EN_qCE[purpose,energy19,t])        = 0;
    EN_vNOx_RE[purpose,energy19,r,t]$(not EN_qRE[purpose,energy19,r,t])    = 0;
		EN_vMOMS_CE[purpose,energy19,t] $(not EN_qCE[purpose,energy19,t])      = 0;
		EN_vMOMS_RE[purpose,energy19,r,t]$(not EN_qRE[purpose,energy19,r,t])   = 0; 
		EN_vEAV_RE[purpose,energy19,r,t]$(not EN_qRE[purpose,energy19,r,t])    = 0;
		EN_vEAV_CE[purpose,energy19,t]$(not EN_qCE[purpose,energy19,t])        = 0;
		EN_vDAV_RE[purpose,energy19,r,t]$(not EN_qRE[purpose,energy19,r,t])    = 0;
		EN_vDAV_CE[purpose,energy19,t]$(not EN_qCE[purpose,energy19,t])        = 0;
		EN_vCAV_RE[purpose,energy19,r,t]$(not EN_qRE[purpose,energy19,r,t])    = 0;
		EN_vCAV_CE[purpose,energy19,t]$(not EN_qCE[purpose,energy19,t])        = 0;

	#Loads data into auxiliary variables
	$LOOP G_energy_modellevel_VPQ:
	{name}_VAR.l{sets} = {name}{sets};
	$ENDLOOP 

	$GROUP G_obj obj "";


	#Create snap-shot of input to see how much its changed by the method
	@SAVE(G_energy_VQ);

	#Block of equations to adjust quantities
	$BLOCK B_afstemeqE

		#OBJECTIVE
		#The first equation is the objective function. We minimize the sum of squared deviations from input-values
		E_qObjQ..    obj =E= sum((purpose,energy19,r,t)$(EN_qRE_VAR.l[purpose,energy19,r,t]), sqr(EN_qRE_VAR[purpose,energy19,r,t]/EN_qRE_VAR.l[purpose,energy19,r,t]-1)) 
						            +sum((purpose,energy19,t)$(EN_qLE_VAR.l[purpose,energy19,t]),     sqr(EN_qLE_VAR[purpose,energy19,t]/EN_qLE_VAR.l[purpose,energy19,t] -1))
						            +sum((purpose,energy19,t)$(EN_qCE_VAR.l[purpose,energy19,t]),     sqr(EN_qCE_VAR[purpose,energy19,t]/EN_qCE_VAR.l[purpose,energy19,t] -1))
						            +sum((purpose,energy19,t)$(EN_qXE_VAR.l[purpose,energy19,t]),     sqr(EN_qXE_VAR[purpose,energy19,t]/EN_qXE_VAR.l[purpose,energy19,t] -1))
						            +sum((energy19,r,t)$(EN_qE_y_VAR.l[energy19,r,t]), sqr(EN_qE_y_VAR[energy19,r,t]/EN_qE_y_VAR.l[energy19,r,t] -1))
						            +sum((energy19,t)$(EN_qE_m_VAR.l[energy19,t]), sqr(EN_qE_m_VAR[energy19,t]/EN_qE_m_VAR.l[energy19,t] - 1))
						            +sum((energy19,types_renewable,t)$(EN_qRENEWABLE_VAR.l[energy19,types_renewable,t]), sqr(EN_qRENEWABLE_VAR[energy19,types_renewable,t]/EN_qRENEWABLE_VAR.l[energy19,types_renewable,t] - 1))
						            +sum((purpose,energy19,t)$(EN_qTL_VAR.l[purpose,energy19,t]), (sqr(EN_qTL_VAR[purpose,energy19,t]/EN_qTL_VAR.l[purpose,energy19,t]-1)));

		#CONSTRAINTS 
		#This constraint states that demand should equal supply
		E_TILANV_Q[energy19,t]$(tData[t])..  sum((purpose,r)$(EN_qRE_VAR.l[purpose,energy19,r,t]), EN_qRE_VAR[purpose,energy19,r,t]) + 
															           sum((purpose)$(EN_qCE_VAR.l[purpose,energy19,t]), EN_qCE_VAR[purpose,energy19,t]) + 
															           sum((purpose)$(EN_qLE_VAR.l[purpose,energy19,t]), EN_qLE_VAR[purpose,energy19,t]) + 
															           sum((purpose)$(EN_qXE_VAR.l[purpose,energy19,t]), EN_qXE_VAR[purpose,energy19,t]) +
															           sum((purpose)$(EN_qTL_VAR.l[purpose,energy19,t]), EN_qTL_VAR[purpose,energy19,t])
															   =E=     sum(s$(EN_qE_y_VAR.l[energy19,s,t]), EN_qE_y_VAR[energy19,s,t]) 
															         + EN_qE_m_VAR[energy19,t]$(EN_qE_m_VAR.l[energy19,t])
														           + sum((types_renewable)$(EN_qRENEWABLE_VAR.l[energy19,types_renewable,t]), EN_qRENEWABLE_VAR[energy19,types_renewable,t]);

		#This constraint states that we should hit the total supply should equal that of the raw-data (qTIL_tot). qTIL_tot is created in the file energi2model.gms.
		E_initialQ[energy19,t]$(tData[t])..  qTIL_tot[energy19,t] =E= 
																     sum(s$(EN_qE_y_VAR.l[energy19,s,t]), EN_qE_y_VAR[energy19,s,t]) 
															     + EN_qE_m_VAR[energy19,t]$(EN_qE_m_VAR.l[energy19,t])
														       + sum((types_renewable)$(EN_qRENEWABLE_VAR.l[energy19,types_renewable,t]), EN_qRENEWABLE_VAR[energy19,types_renewable,t]);
	$ENDBLOCK

	#Sets up model
	$MODEL M_afstemqE B_afstemeqE;

	#All variables, except from inventory variables, requires a lower bound (for them to make sense)
	$GROUP G_qXLE G_energy_Q, -EN_qLE_VAR;

	#Sets lower-bound to be our tolerance level 
  $LOOP G_qXLE: 
  $UNFIX(0.0001,inf) {name}$({name}.l{sets});
  $ENDLOOP


	SOLVE M_afstemqE using NLP minimizing obj;
	 execute_unload 'output/post.gdx';

	#  @assert_no_difference(G_energy_VQ,1e-6);



	PARAMETER energybefore[purpose,energy19,sLan,t], energyafter[purpose,energy19,sLan,t];
	energybefore[purpose,energy19,sLan,t] =  EN_vnRE_VAR.l[purpose,energy19,sLan,t]
									       + EN_vEAFG_RE_VAR.l[purpose,energy19,sLan,t] 
									       + EN_vSO2_RE_VAR.l[purpose,energy19,sLan,t] 
                         + EN_vPSO_RE_VAR.l[purpose,energy19,sLan,t]
                         + EN_vNOx_RE_VAR.l[purpose,energy19,sLan,t]
									       + EN_vCO2_RE_VAR.l[purpose,energy19,sLan,t];
													


	#£ OUTSTANDING: INCLUDE TAXES IN THE BELOW
	#Block of equations to adjust values
	$BLOCK B_afstemevE
		#OBJECTIVE
		#The first equation is the objective function. We minimize the sum of squared deviations from input-values	
		E_qObjV..    obj =E= sum((purpose,energy19,r,t)$(EN_vnRE_VAR.l[purpose,energy19,r,t]), sqr(EN_vnRE_VAR[purpose,energy19,r,t]/EN_vnRE_VAR.l[purpose,energy19,r,t] -1)) 
						   +sum((purpose,energy19,t)$(EN_vnCE_VAR.l[purpose,energy19,t]), sqr(EN_vnCE_VAR[purpose,energy19,t]/EN_vnCE_VAR.l[purpose,energy19,t] -1))
						   +0.5*sum((purpose,energy19,t)$(EN_vnLE_VAR.l[purpose,energy19,t]), sqr(EN_vnLE_VAR[purpose,energy19,t]/EN_vnLE_VAR.l[purpose,energy19,t] -1))
						   +sum((purpose,energy19,t)$(EN_vnXE_VAR.l[purpose,energy19,t]), sqr(EN_vnXE_VAR[purpose,energy19,t]/EN_vnXE_VAR.l[purpose,energy19,t] -1))
						   +sum((energy19,r,t)$(EN_vE_y_VAR.l[energy19,r,t]), sqr(EN_vE_y_VAR[energy19,r,t]/EN_vE_y_VAR.l[energy19,r,t] -1))
						   +sum((energy19,t)$(EN_vE_m_VAR.l[energy19,t]), sqr(EN_vE_m_VAR[energy19,t]/EN_vE_m_VAR.l[energy19,t] - 1))
						   +sum((energy19,t)$(EN_vCUS_VAR.l[energy19,t]), sqr(EN_vCUS_VAR[energy19,t]/EN_vCUS_VAR.l[energy19,t] - 1))

						   #  +sum((purpose,energy19,sLan,t)$(EN_qRE_VAR.l[purpose,energy19,sLan,t]), sqr(EN_qRE_VAR[purpose,energy19,sLan,t]/EN_qRE_VAR.l[purpose,energy19,sLan,t]-1))
						   ;

		#CONSTRAINTS 
		#This constraint states that demand should equal supply
		E_TILANV_V[energy19,t]$(tData[t])..  sum((purpose,r)$(EN_vnRE_VAR.l[purpose,energy19,r,t]), EN_vnRE_VAR[purpose,energy19,r,t]) + 
															   sum((purpose)$(EN_vnCE_VAR.l[purpose,energy19,t]), EN_vnCE_VAR[purpose,energy19,t]) + 
															   sum((purpose)$(EN_vnLE_VAR.l[purpose,energy19,t]), EN_vnLE_VAR[purpose,energy19,t]) + 
															   sum((purpose)$(EN_vnXE_VAR.l[purpose,energy19,t]), EN_vnXE_VAR[purpose,energy19,t])
															   =E= sum(s$(EN_vE_y_VAR.l[energy19,s,t]), EN_vE_y_VAR[energy19,s,t]) 
															   + EN_vE_m_VAR[energy19,t]$(EN_vE_m_VAR.l[energy19,t])
															   + EN_vCUS_VAR[energy19,t]$(EN_vCUS_VAR.l[energy19,t]);

		#This constraint states that we should hit the total supply should equal that of the raw-data (vTIL_tot). vTIL_tot is created in the file energi2model.gms.
	   	E_initialV[energy19,t]$(tData[t])..  vTIL_tot[energy19,t] =E= 
																 sum(s$(EN_vE_y_VAR.l[energy19,s,t]), EN_vE_y_VAR[energy19,s,t]) 
															   + EN_vE_m_VAR[energy19,t]$(EN_vE_m_VAR.l[energy19,t])
														       + EN_vCUS_VAR[energy19,t]$(EN_vCUS_VAR.l[energy19,t]);


		#For energy-values we add constraints ensuring that we also hit the IO-totals for each USE-item. This should make the resulting data-input consistent with the EnergyIO (Provided that the matrices from Statistics Denmark were consistent in the first place).
		E_vnRE_tot[r,t]$(tData[t])..           vnRE_tot_r[r,t] =E= 
																sum((purpose,energy19)$(EN_vnRE_VAR.l[purpose,energy19,r,t]), EN_vnRE_VAR[purpose,energy19,r,t]);

		E_vnCE_tot[t]$(tData[t])..             vnCE_tot[t] =E= sum((purpose,energy19)$(EN_vnCE_VAR.l[purpose,energy19,t]), EN_vnCE_VAR[purpose,energy19,t]);

		#We give up restriction on inventories to hit targets
		E_vnLE_tot[t]$(tData[t])..             vnLE_tot[t] =E= sum((purpose,energy19)$(EN_vnLE_VAR.l[purpose,energy19,t]), EN_vnLE_VAR[purpose,energy19,t]);

		E_vnXE_tot[t]$(tData[t])..             vnXE_tot[t] =E= sum((purpose,energy19)$(EN_vnXE_VAR.l[purpose,energy19,t]), EN_vnXE_VAR[purpose,energy19,t]);


		#  HORTICULTURE
		#  E_vnRE_hort[t]$(t.val = 2019)..             0.32 =E= sum((purpose,energy19), EN_vnRE_VAR[purpose,energy19,'01020',t]$(EN_vnRE_VAR.l[purpose,energy19,'01020',t])
		#  																	   + EN_vEAFG_RE_VAR[purpose,energy19,'01020',t]$(EN_vEAFG_RE_VAR.l[purpose,energy19,'01020',t]) 
		#  																	   + EN_vSO2_RE_VAR[purpose,energy19,'01020',t]$(EN_vSO2_RE_VAR.l[purpose,energy19,'01020',t]) 
    #                                      + EN_vPSO_RE_VAR[purpose,energy19,'01020',t]$(EN_vPSO_RE_VAR.l[purpose,energy19,'01020',t])
    #                                      + EN_vNOx_RE_VAR[purpose,energy19,'01020',t]$(EN_vNOx_RE_VAR.l[purpose,energy19,'01020',t]) 
		#  																	   + EN_vCO2_RE_VAR[purpose,energy19,'01020',t]$(EN_vCO2_RE_VAR.l[purpose,energy19,'01020',t]));

		#  #TOTAL VALUE IN AGRICULTURE IS UNCHANGED 
		#  E_vnAGR[t]$(t.val = 2019)..                  sum((purpose,energy19,sLan), EN_vnRE_VAR.l[purpose,energy19,sLan,t]
		#  																     + EN_vEAFG_RE_VAR.l[purpose,energy19,sLan,t] 
		#  																     + EN_vSO2_RE_VAR.l[purpose,energy19,sLan,t] 
    #                                      + EN_vPSO_RE_VAR.l[purpose,energy19,sLan,t]
    #                                      + EN_vNOx_RE_VAR.l[purpose,energy19,sLan,t]
		#  																     + EN_vCO2_RE_VAR.l[purpose,energy19,sLan,t])
		#  										=E= sum((purpose,energy19,sLan), EN_vnRE_VAR[purpose,energy19,sLan,t]$(EN_vnRE_VAR.l[purpose,energy19,sLan,t]) 
		#  																		+ EN_vEAFG_RE_VAR[purpose,energy19,sLan,t]$(EN_vEAFG_RE_VAR.l[purpose,energy19,sLan,t]) 
		#  																		+ EN_vSO2_RE_VAR[purpose,energy19,sLan,t]$(EN_vSO2_RE_VAR.l[purpose,energy19,sLan,t])
    #                                     + EN_vPSO_RE_VAR[purpose,energy19,sLan,t]$(EN_vPSO_RE_VAR.l[purpose,energy19,sLan,t])
    #                                     + EN_vNOx_RE_VAR[purpose,energy19,sLan,t]$(EN_vNOx_RE_VAR.l[purpose,energy19,sLan,t]) 
		#  																		+ EN_vCO2_RE_VAR[purpose,energy19,sLan,t]$(EN_vCO2_RE_VAR.l[purpose,energy19,sLan,t]));


		#  #PER PJ VALUES SHOULD HOLD AFTER 

		#  E_PERPJ_vnRE[purpose,energy19,sLan,t]$(t.val = 2019 and EN_vnRE_VAR.l[purpose,energy19,sLan,t])..               EN_vnRE_VAR[purpose,energy19,sLan,t]/EN_qRE_VAR[purpose,energy19,sLan,t] =E= EN_vnRE_VAR.l[purpose,energy19,sLan,t]/EN_qRE_VAR.l[purpose,energy19,sLan,t]; 
	
		#  E_PERPJ_vEAFG[purpose,energy19,sLan,t]$(t.val = 2019 and EN_vEAFG_RE_VAR.l[purpose,energy19,sLan,t])..            EN_vEAFG_RE_VAR[purpose,energy19,sLan,t]/EN_qRE_VAR[purpose,energy19,sLan,t] =E= EN_vEAFG_RE_VAR.l[purpose,energy19,sLan,t]/EN_qRE_VAR.l[purpose,energy19,sLan,t]; 
	
		#  E_PERPJ_vSO2[purpose,energy19,sLan,t]$(t.val = 2019 and EN_vSO2_RE_VAR.l[purpose,energy19,sLan,t])..               EN_vSO2_RE_VAR[purpose,energy19,sLan,t]/EN_qRE_VAR[purpose,energy19,sLan,t] =E= EN_vSO2_RE_VAR.l[purpose,energy19,sLan,t]/EN_qRE_VAR.l[purpose,energy19,sLan,t]; 
	
    #  E_PERPJ_vPSO[purpose,energy19,sLan,t]$(t.val = 2019 and EN_vPSO_RE_VAR.l[purpose,energy19,sLan,t])..               EN_vPSO_RE_VAR[purpose,energy19,sLan,t]/EN_qRE_VAR[purpose,energy19,sLan,t] =E= EN_vPSO_RE_VAR.l[purpose,energy19,sLan,t]/EN_qRE_VAR.l[purpose,energy19,sLan,t]; 

    #  E_PERPJ_vNOx[purpose,energy19,sLan,t]$(t.val = 2019 and EN_vNOx_RE_VAR.l[purpose,energy19,sLan,t])..               EN_vNOx_RE_VAR[purpose,energy19,sLan,t]/EN_qRE_VAR[purpose,energy19,sLan,t] =E= EN_vNOx_RE_VAR.l[purpose,energy19,sLan,t]/EN_qRE_VAR.l[purpose,energy19,sLan,t]; 

		#  E_PERPJ_vCO2[purpose,energy19,sLan,t]$(t.val = 2019 and EN_vCO2_RE_VAR.l[purpose,energy19,sLan,t])..               EN_vCO2_RE_VAR[purpose,energy19,sLan,t]/EN_qRE_VAR[purpose,energy19,sLan,t] =E= EN_vCO2_RE_VAR.l[purpose,energy19,sLan,t]/EN_qRE_VAR.l[purpose,energy19,sLan,t]; 
														      

	$ENDBLOCK

	#All variables, except from inventory variables, requires a lower bound (for them to make sense)
	$GROUP G_vXLE G_energy_v, -EN_vnLE_VAR;

	#Sets lower-bound to be our tolerance level 
  $LOOP G_vXLE: 
  $UNFIX(0.000001,inf) {name}$({name}.l{sets});
  $ENDLOOP

	$MODEL M_afstemvE B_afstemevE;
	SOLVE M_afstemvE using NLP minimizing obj;

	energyafter[purpose,energy19,sLan,t] =  EN_vnRE_VAR.l[purpose,energy19,sLan,t]
								       + EN_vEAFG_RE_VAR.l[purpose,energy19,sLan,t] 
								       + EN_vSO2_RE_VAR.l[purpose,energy19,sLan,t] 
                       + EN_vPSO_RE_VAR.l[purpose,energy19,sLan,t]
                       + EN_vNOx_RE_VAR.l[purpose,energy19,sLan,t]
								       + EN_vCO2_RE_VAR.l[purpose,energy19,sLan,t];

	#Reads the adjusted data into data-parameters
	$LOOP G_energy_modellevel_VPQ: {name}{sets} = 0; {name}{sets} = {name}_VAR.l{sets}; $ENDLOOP

	#£HACKFIREWOOD 
	EN_qE_y['firewood and woodchips','02000',t] = EN_qE_y['firewood and woodchips','02000',t] - EN_qCE['process_special','firewood and woodchips',t];

   #Redo prices
	EN_pCE_base[purpose,energy19,t]$(EN_vnCE[purpose,energy19,t])     = EN_vnCE[purpose,energy19,t]/EN_qCE[purpose,energy19,t];  
	EN_pLE_base[purpose,energy19,t]$(EN_vnLE[purpose,energy19,t])     = EN_vnLE[purpose,energy19,t]/EN_qLE[purpose,energy19,t];  
	EN_pRE_base[purpose,energy19,r,t]$(EN_vnRE[purpose,energy19,r,t]) = EN_vnRE[purpose,energy19,r,t]/EN_qRE[purpose,energy19,r,t]; 
	EN_pXE_base[purpose,energy19,t]$(EN_vnXE[purpose,energy19,t])     = EN_vnXE[purpose,energy19,t]/EN_qXE[purpose,energy19,t]; 

	EN_pE_y[energy19,s,t]$(EN_vE_y[energy19,s,t])                     = EN_vE_y[energy19,s,t]/EN_qE_y[energy19,s,t];
	EN_pE_m[energy19,t]$(EN_vE_m[energy19,t])                         = (EN_vE_m[energy19,t] + EN_vCUS[energy19,t])/EN_qE_m[energy19,t]; 

	EN_pCE[purpose,energy19,t]$(EN_vnCE[purpose,energy19,t])          = (EN_vEAV_CE[purpose,energy19,t] + EN_vDAV_CE[purpose,energy19,t]+ EN_vCAV_CE[purpose,energy19,t] + EN_vCO2_CE[purpose,energy19,t] + EN_vEAFG_CE[purpose,energy19,t] + EN_vSO2_CE[purpose,energy19,t] + EN_vPSO_CE[purpose,energy19,t] + EN_vNOx_CE[purpose,energy19,t] + EN_vMOMS_CE[purpose,energy19,t] + EN_vnCE[purpose,energy19,t])/EN_qCE[purpose,energy19,t];  
	EN_pLE[purpose,energy19,t]$(EN_vnLE[purpose,energy19,t])          = EN_vnLE[purpose,energy19,t]/EN_qLE[purpose,energy19,t];  
	EN_pRE[purpose,energy19,r,t]$(EN_vnRE[purpose,energy19,r,t])      = (EN_vCO2_RE[purpose,energy19,r,t] + EN_vEAFG_RE[purpose,energy19,r,t] + EN_vSO2_RE[purpose,energy19,r,t] + EN_vPSO_RE[purpose,energy19,r,t] + EN_vNOx_RE[purpose,energy19,r,t] + EN_vMOMS_RE[purpose,energy19,r,t] + EN_vnRE[purpose,energy19,r,t])/EN_qRE[purpose,energy19,r,t]; 
	EN_pXE[purpose,energy19,t]$(EN_vnXE[purpose,energy19,t])          = (EN_vEAFG_XE[purpose,energy19,t] + EN_vPSO_XE[purpose,energy19,t] + EN_vnXE[purpose,energy19,t])/EN_qXE[purpose,energy19,t]; 

	EN_pEAV_CE[purpose,energy19,t]$EN_vEAV_CE[purpose,energy19,t] = EN_vEAV_CE[purpose,energy19,t]/EN_qCE[purpose,energy19,t];
	EN_pDAV_CE[purpose,energy19,t]$EN_vDAV_CE[purpose,energy19,t] = EN_vDAV_CE[purpose,energy19,t]/EN_qCE[purpose,energy19,t];
	EN_pCAV_CE[purpose,energy19,t]$EN_vCAV_CE[purpose,energy19,t] = EN_vCAV_CE[purpose,energy19,t]/EN_qCE[purpose,energy19,t];
	
	EN_pEAV_RE[purpose,energy19,r,t]$(EN_vEAV_RE[purpose,energy19,r,t]) = EN_vEAV_RE[purpose,energy19,r,t]/EN_qRE[purpose,energy19,r,t];
	EN_pDAV_RE[purpose,energy19,r,t]$(EN_vDAV_RE[purpose,energy19,r,t]) = EN_vDAV_RE[purpose,energy19,r,t]/EN_qRE[purpose,energy19,r,t];
	EN_pCAV_RE[purpose,energy19,r,t]$(EN_vCAV_RE[purpose,energy19,r,t]) = EN_vCAV_RE[purpose,energy19,r,t]/EN_qRE[purpose,energy19,r,t];
 	
	#Adjust taxes (very rudimentary - needs to be more sophisticated)
	#Secondly, adjust totals to match input-data
	EN_vCO2_CE[purpose,energy19,t]$(EN_vCO2_CE[purpose,energy19,t])       = vCO2_CE_tot[t]  / sum((purposee,energy19a),   EN_vCO2_CE[purposee,energy19a,t])    * EN_vCO2_CE[purpose,energy19,t];
	EN_vCO2_RE[purpose,energy19,r,t]$(EN_vCO2_RE[purpose,energy19,r,t])   = vCO2_RE_tot[t]  / sum((purposee,energy19a,s), EN_vCO2_RE[purposee,energy19a,s,t])  * EN_vCO2_RE[purpose,energy19,r,t];
	EN_vEAFG_CE[purpose,energy19,t]$(EN_vEAFG_CE[purpose,energy19,t])     = vEAFG_CE_tot[t] / sum((purposee,energy19a),   EN_vEAFG_CE[purposee,energy19a,t])   * EN_vEAFG_CE[purpose,energy19,t];
	EN_vEAFG_RE[purpose,energy19,r,t]$(EN_vEAFG_RE[purpose,energy19,r,t]) = vEAFG_RE_tot[t] / sum((purposee,energy19a,s), EN_vEAFG_RE[purposee,energy19a,s,t]) * EN_vEAFG_RE[purpose,energy19,r,t];
	EN_vEAFG_XE[purpose,energy19,t]$(EN_vEAFG_XE[purpose,energy19,t])     = vEAFG_XE_tot[t] / sum((purposee,energy19a),   EN_vEAFG_XE[purposee,energy19a,t])   * EN_vEAFG_XE[purpose,energy19,t];
	EN_vSO2_CE[purpose,energy19,t]$(EN_vSO2_CE[purpose,energy19,t])       = vSO2_CE_tot[t]  / sum((purposee,energy19a),   EN_vSO2_CE[purposee,energy19a,t])    * EN_vSO2_CE[purpose,energy19,t];
	EN_vSO2_RE[purpose,energy19,r,t]$(EN_vSO2_RE[purpose,energy19,r,t])   = vSO2_RE_tot[t]  / sum((purposee,energy19a,s), EN_vSO2_RE[purposee,energy19a,s,t])  * EN_vSO2_RE[purpose,energy19,r,t];
  EN_vPSO_CE[purpose,energy19,t]$(EN_vPSO_CE[purpose,energy19,t])       = vPSO_CE_tot[t]  / sum((purposee,energy19a),   EN_vPSO_CE[purposee,energy19a,t])    * EN_vPSO_CE[purpose,energy19,t];
  EN_vPSO_RE[purpose,energy19,r,t]$(EN_vPSO_RE[purpose,energy19,r,t])   = vPSO_RE_tot[t]  / sum((purposee,energy19a,s), EN_vPSO_RE[purposee,energy19a,s,t])  * EN_vPSO_RE[purpose,energy19,r,t];
  EN_vPSO_XE[purpose,energy19,t]$(EN_vPSO_XE[purpose,energy19,t])       = vPSO_XE_tot[t]  / sum((purposee,energy19a),   EN_vPSO_XE[purposee,energy19a,t])    * EN_vPSO_XE[purpose,energy19,t];
  EN_vNOx_CE[purpose,energy19,t]$(EN_vNOx_CE[purpose,energy19,t])       = vNOx_CE_tot[t]  / sum((purposee,energy19a),   EN_vNOx_CE[purposee,energy19a,t])    * EN_vNOx_CE[purpose,energy19,t];
  EN_vNOx_RE[purpose,energy19,r,t]$(EN_vNOx_RE[purpose,energy19,r,t])   = vNOx_RE_tot[t]  / sum((purposee,energy19a,s), EN_vNOX_RE[purposee,energy19a,s,t])  * EN_vNOx_RE[purpose,energy19,r,t];
	EN_vMOMS_CE[purpose,energy19,t]$(EN_vMOMS_CE[purpose,energy19,t])     = vMOMS_CE_tot[t] / sum((purposee,energy19a),   EN_vMOMS_CE[purposee,energy19a,t])   * EN_vMOMS_CE[purpose,energy19,t];
	EN_vMOMS_RE[purpose,energy19,r,t]$(EN_vMOMS_RE[purpose,energy19,r,t]) = vMOMS_RE_tot[t] / sum((purposee,energy19a,s), EN_vMOMS_RE[purposee,energy19a,s,t]) * EN_vMOMS_RE[purpose,energy19,r,t];


	#Adjust emissions to account for adjusted energy-data (i.e we don't want emissions where we have removed energy-entries)
	#Firstly, remove emissions where no quantity is consumed
	EM_CE[emm,purpose,energy19,t]$(not EN_qCE[purpose,energy19,t])     = 0;
	EM_RE[emm,purpose,energy19,r,t]$(not EN_qRE[purpose,energy19,r,t]) = 0;

	#Secondly, adjust totals to match input-data
	EM_CE[emm,purpose,energy19,t]$(EM_CE[emm,purpose,energy19,t])    = EM_CE_tot[emm,t]/sum((purposee,energy19a),   EM_CE[emm,purposee,energy19a,t])   * EM_CE[emm,purpose,energy19,t]; 
	EM_RE[emm,purpose,energy19,r,t]$(EM_RE[emm,purpose,energy19,r,t])= EM_RE_tot[emm,t]/sum((purposee,energy19a,s), EM_RE[emm,purposee,energy19a,s,t]) * EM_RE[emm,purpose,energy19,r,t];

# ----------------------------------------------------------------------------------------------------------------------
# IO-TABLE
# ----------------------------------------------------------------------------------------------------------------------

$IMPORT IO_data.gms;

#BESKÆFTIGELSE
PARAMETER data_besk_out[Brch,t], data_besk_out_s[s,t];
execute_loaddc '../Data/Beskaeftigelse/besk.gdx' data_besk_out = besk_out;
data_besk_out_s[s,t]         = sum(ns105$(map1052five(s,ns105)), sum(nsGR$(nsGR2ns105(ns105,nsGR)), sum(brch$(brch2nsGR(brch,nsGR)), data_besk_out[Brch,t])));

data_besk_out_s[sSlagteri,t]   = sYS[sSlagteri]*data_besk_out_s['10011',t];
data_besk_out_s[sMineralogi,t] = sL_cement[sMineralogi]*data_besk_out_s['23001',t];

# ----------------------------------------------------------------------------------------------------------------------
# Leakage
# ----------------------------------------------------------------------------------------------------------------------

#  # Leakage coefficients:
set leak_cat /import, export, ETS, tot/;
set impexp(leak_cat) /import, export/;
parameters d1leak_coef[impexp,s,t];

parameters leak_coef_in[impexp,s,t];
execute_load "../Data/Leakage/leakage_coefs.gdx" leak_coef_in=leak_coef;
d1leak_coef[impexp,s,t] = yes$(leak_coef_in[impexp,s,t]);

# ----------------------------------------------------------------------------------------------------------------------
# LULUCF
# ----------------------------------------------------------------------------------------------------------------------

	$PGROUP LULUCF_from_LULUCF_forestry_gdx
		pSurvival_data[joe07,spec_type,acl] ""
		content_coeffs_data[joe07,spec_type,acl,content_type] ""
		NFI_HWP_coeff_data[joe07,spec_type,acl] ""
	 	AFF_area_data[t,joe07,spec_type,skmodel] ""
	 	AFF_coeffs_data[skmodel,joe07,spec_type,acl,content_type] ""
	 	AFF_HWP_coeff_data[skmodel,joe07,spec_type,acl] ""
	 	FRF_area_data[joe07,spec_type,acl] ""
		NRE_area_data[joe07,spec_type,acl] ""
		Tabel_11_11[ite,joe07,forvalt,spec_type,acl,skmodel,items] ""
		Tabel_11_6[joe07,acl,l_n,area_category] ""
		Tabel_11_10[ite,forvalt,spec_type,joe07,acl,output_11_10] ""
		enduse_share[enduse_wood,t] ""
	;

	PARAMETERS
		LULUCF_data(*,*,*)	 
	;

	$PGROUP LULUCF_from_arealmatrice_gdx
	    arealmatrice[t,land8_s,land8_r] ""
      arealmatrice_KF23[t,land8_s,land8_r] ""
	;

	$PGROUP LULUCF_from_KF25_dataark_LULUCF_gdx 
		 peatland_nonCO2[t,emm] "",
		 peatland_CO2[t] ""
		 kulstofpulje_levendebiomasse[t,land12] ""
		 forest_carbonsoil_total[t] ""
		 Table4III_bebyggelse[t] ""
     organic_soils[land12xF,t] ""
	;


	$PGROUP PG_lavbundsudtag 
		AendringStoettePerHa[HaUdtag,Lavbundsmodel] ""
		HaHoejV[HaUdtag,Lavbundsmodel] ""
		HaLavV[HaUdtag,Lavbundsmodel] ""
		HaRand[HaUdtag,Lavbundsmodel] ""
		Komp120pct[HaUdtag,Lavbundsmodel] ""
		VaadOmk[HaUdtag,Lavbundsmodel] ""

	;

		execute_loaddc '../Data/LULUCF/LULUCF_forestry.gdx' pSurvival_data      = pSurvival.l;
		execute_loaddc '../Data/LULUCF/LULUCF_forestry.gdx' content_coeffs_data = content_coeffs.l;
		execute_loaddc '../Data/LULUCF/LULUCF_forestry.gdx' NFI_HWP_coeff_data  = NFI_HWP_coeff.l;
		execute_loaddc '../Data/LULUCF/LULUCF_forestry.gdx' AFF_area_data       = AFF_area.l;
		execute_loaddc '../Data/LULUCF/LULUCF_forestry.gdx' AFF_coeffs_data     = AFF_coeffs.l;
		execute_loaddc '../Data/LULUCF/LULUCF_forestry.gdx' AFF_HWP_coeff_data  = AFF_HWP_coeff.l;
		execute_loaddc '../Data/LULUCF/LULUCF_forestry.gdx' FRF_area_data       = NFI2020_area_FRF.l;
		execute_loaddc '../Data/LULUCF/LULUCF_forestry.gdx' NRE_area_data       = NFI2020_area_NRE.l;
		execute_loaddc '../Data/LULUCF/LULUCF_forestry.gdx' Tabel_11_11         = Tabel_11_11.l;
		execute_loaddc '../Data/LULUCF/LULUCF_forestry.gdx' Tabel_11_6          = NRE_area.l;
		execute_loaddc '../Data/LULUCF/LULUCF_forestry.gdx' Tabel_11_10         = Tabel_11_10.l;
		execute_loaddc "../Data/LULUCF/LULUCF_forestry.gdx" enduse_share        = enduse_share.l;

	#GSR-skov 	 
	  Parameter Table2_GSRmaj2023[joe07,aclTable2] "DB fra skov antal år efter skovrejsning, kroner/ha/år (faste 2019-priser)";

	  Table2_GSRmaj2023['Islands','20_30']  = 600; #
	  Table2_GSRmaj2023['Islands','30_40']  = 3200; #
	  Table2_GSRmaj2023['Islands','40_100'] = 14000; #
	  Table2_GSRmaj2023['Jutland','30_40']  = 612;
	  Table2_GSRmaj2023['Jutland','40_100'] = 8400;

	#Arealmatrice 
		execute_loaddc "../Data/LULUCF/arealmatrice.gdx" arealmatrice = arealmatrice.l;
		execute_loaddc "../Data/LULUCF/arealmatrice.gdx" arealmatrice_KF23 = arealmatrice_KF23.l;

	#Peatland
		execute_loaddc "../Data/LULUCF/KF25 dataark - LULUCF.gdx" peatland_nonCO2 = totaler_nonCO2.l;
		execute_loaddc "../Data/LULUCF/KF25 dataark - LULUCF.gdx" peatland_CO2    = kulstofpulje.l;
		peatland_nonCO2[t,'CH4'] = peatland_nonCO2[t,'CH4']/28; peatland_nonCO2[t,'N2O'] = peatland_nonCO2[t,'N2O']/265; #The model computes CO2eq

	#Carbon stocks for living biomass
		execute_loaddc "../Data/LULUCF/KF25 dataark - LULUCF.gdx" kulstofpulje_levendebiomasse = kulstofpulje_levendebiomasse.l;

	#Carbons stocks in forest soil
		execute_loaddc "../Data/LULUCF/KF25 dataark - LULUCF.gdx" forest_carbonsoil_total = forest_carbonsoil_total.l;

	#Table 4III settlements
		execute_loaddc "../Data/LULUCF/KF25 dataark - LULUCF.gdx" Table4III_bebyggelse = Table4III_bebyggelse.l;

  #Organic soils
		execute_loaddc "../Data/LULUCF/KF25 dataark - LULUCF.gdx" organic_soils = organic_soils.l;


	#Gammelt URB - få det ændret
		$GDXIN "../Data/LULUCF/LULUCF_data.gdx"
		$load LULUCF_data


	#Lavbund
		VaadOmk[HaUdtag,Lavbundsmodel]    = VaadOmk[HaUdtag,Lavbundsmodel]    * inf_growth_factor['2022']; #Omkostningerne kommer i 2022-priser  
		Komp120pct[HaUdtag,Lavbundsmodel] = Komp120pct[HaUdtag,Lavbundsmodel] * inf_growth_factor['2022']; #Omkostningerne kommer i 2022-priser
		
	
		execute_loaddc '../Data/LULUCF/GSR/lavbundsudtagGSR.gdx' $LOOP PG_lavbundsudtag: {name} = {name}.l $ENDLOOP
		parameter Effektandele[t]; 

    #AD HOC LAVBUND TIL KF24-BASELINE OG GSR/Trepartsstød. Se mail fra Julie, KEFM, fra 11/12/2024.
      #Baseline
      HaRand['35000','0']  = 0.5 * 70000 * 0.78;        #KF24/Baselineudtag (50 pct. randarealer i baseline). 78 pct. sker på IMK-arealer.
      HaHoejV['35000','0'] = 0.5 * 70000 * 0.78 * 0.16; #KF24/Baselineudtag (50 pct. randarealer i baseline).
      HaLavV['35000','0']  = 0.5 * 70000 * 0.78 * (1-0.16); #KF24/Baselineudtag (50 pct. randarealer i baseline)
  
      #Baseline m. solceller
      HaRand['35000','1']  = 0.5 * 70000 * 0.78;        #KF24/Baselineudtag (50 pct. randarealer i baseline). 78 pct. sker på IMK-arealer.
      HaHoejV['35000','1'] = 0.5 * 70000 * 0.78 * 0.16; #KF24/Baselineudtag (50 pct. randarealer i baseline).
      HaLavV['35000','1']  = 0.5 * 70000 * 0.78 * (1-0.16); #KF24/Baselineudtag (50 pct. randarealer i baseline)

      #GSR/Trepart
      HaRand['70000','1']  = 0.5 * 140000 * 0.78;        #KF24/Baselineudtag (50 pct. randarealer i baseline). 78 pct. sker på IMK-arealer.
      HaHoejV['70000','1'] = 0.5 * 140000 * 0.78 * 0.16; #KF24/Baselineudtag (50 pct. randarealer i baseline).
      HaLavV['70000','1']  = 0.5 * 140000 * 0.78 * (1-0.16); #KF24/Baselineudtag (50 pct. randarealer i baseline)

      HaRand['70000','2']  = 0.5 * 140000 * 0.78;        #KF24/Baselineudtag (50 pct. randarealer i baseline). 78 pct. sker på IMK-arealer.
      HaHoejV['70000','2'] = 0.5 * 140000 * 0.78 * 0.16; #KF24/Baselineudtag (50 pct. randarealer i baseline).
      HaLavV['70000','2']  = 0.5 * 140000 * 0.78 * (1-0.16); #KF24/Baselineudtag (50 pct. randarealer i baseline)


    #TREPARTSEFFEKTANDELE (hurtigere indfasning end i GSR)
      Effektandele['2028'] = 1/3;
      Effektandele['2029'] = 2/3;
      Effektandele[t]$(t.val>=2030) = 1;

# ----------------------------------------------------------------------------------------------------------------------
# Eksogene skattesatser på energiforbrug fra SKM 
# ----------------------------------------------------------------------------------------------------------------------

	parameter tEAFG_REmarg_SKM_in(tREbase_SKM,t),tSO2_REmarg_SKM_in(tREbase_SKM,t),tCO2_REmarg_SKM_in(tREbase_SKM,t);
  $GROUP G_SKM_taxes_in 
    tEAFG_REmarg_SKM[tREbase_SKM,t] "" 
    tSO2_REmarg_SKM[tREbase_SKM,t] ""  
    tCO2_REmarg_SKM[tREbase_SKM,t] ""
  ;
  
  $gdxin "../Data/Energiafgifter_marginal/Kopi_af_SKM_base_old_lobende_priser_v2_REFORM_korrFiskogIndenrigsfaerger.gdx"
	$onUNDF
	$load tEAFG_REmarg_SKM_in tSO2_REmarg_SKM_in tCO2_REmarg_SKM_in
	$gdxin


	tEAFG_REmarg_SKM.l(tREbase_SKM,t)      = tEAFG_REmarg_SKM_in(tREbase_SKM,t); 
	tEAFG_REmarg_SKM.l('el_ikke-proces',t) = tEAFG_REmarg_SKM.l('el_privat',t);
	#tEAFG_REmarg_SKM.l('el_ikke-proces',t)= tEAFG_REmarg_SKM.l('el_proces',t);
	tSO2_REmarg_SKM.l(tREbase_SKM,t)       = tSO2_REmarg_SKM_in(tREbase_SKM,t); 
	tSO2_REmarg_SKM.l('el_ikke-proces',t)  = tSO2_REmarg_SKM.l('el_privat',t);
	tCO2_REmarg_SKM.l(tREbase_SKM,t)       = tCO2_REmarg_SKM_in(tREbase_SKM,t); 
	tCO2_REmarg_SKM.l('el_ikke-proces',t)  = tCO2_REmarg_SKM.l('el_privat',t);

	# Afgiftssatserne skal tolkes som en pris, og skal derfor inflationskorrigeres, når de kommer ind i modellen.  
	#  tEAFG_REmarg_SKM.l(tREbase_SKM,t) = tEAFG_REmarg_SKM.l(tREbase_SKM,t)*inf_factor[t]; 
	#  tSO2_REmarg_SKM.l(tREbase_SKM,t)  = tSO2_REmarg_SKM.l(tREbase_SKM,t)*inf_factor[t];  
	#  tCO2_REmarg_SKM.l(tREbase_SKM,t)  = tCO2_REmarg_SKM.l(tREbase_SKM,t)*inf_factor[t];  

	#AKB: Vi inflationskorrigerer med skats inflationsfaktor for at få samme satser i 2021 som skat (341 pr tCO2)
	tEAFG_REmarg_SKM.l(tREbase_SKM,t) = tEAFG_REmarg_SKM.l(tREbase_SKM,t)*fp**(t.val-2021)/((1.019)**(t.val-2021))*inf_factor[t];
	tSO2_REmarg_SKM.l(tREbase_SKM,t)  = tSO2_REmarg_SKM.l(tREbase_SKM,t)*fp**(t.val-2021) /((1.019)**(t.val-2021))*inf_factor[t];
	tCO2_REmarg_SKM.l(tREbase_SKM,t)  = tCO2_REmarg_SKM.l(tREbase_SKM,t)*fp**(t.val-2021) /((1.019)**(t.val-2021))*inf_factor[t];

	#Efter 2030 antages det, at afgifterne indekseres, så de følger prisudviklingen, hvormed de ikke skal inflationskorrigeres.
	tEAFG_REmarg_SKM.l(tREbase_SKM,t) $ (ord(t) GT (2030+1-1967))   = tEAFG_REmarg_SKM.l(tREbase_SKM,'2030');
	tSO2_REmarg_SKM.l(tREbase_SKM,t)  $ (ord(t) GT (2030+1-1967))   = tSO2_REmarg_SKM.l(tREbase_SKM,'2030');
	tCO2_REmarg_SKM.l(tREbase_SKM,t)  $ (ord(t) GT (2030+1-1967))   = tCO2_REmarg_SKM.l(tREbase_SKM,'2030');

	#Dog indekseres elafgiften på proces-el ikke, hvormed den inflationskorrigeres.
	tEAFG_REmarg_SKM.l('el_proces',t) $ (ord(t) GT (2030+1-1967))   = tEAFG_REmarg_SKM.l('el_proces','2030')*inf_factor[t]/inf_factor['2030'];
	tEAFG_REmarg_SKM.l('proces',t) $ (ord(t) GT (2030+1-1967))      = tEAFG_REmarg_SKM.l('proces','2030')*inf_factor[t]/inf_factor['2030'];
	tEAFG_REmarg_SKM.l('proces_ets',t) $ (ord(t) GT (2030+1-1967))  = tEAFG_REmarg_SKM.l('proces_ets','2030')*inf_factor[t]/inf_factor['2030'];
	tEAFG_REmarg_SKM.l('landbrug',t) $ (ord(t) GT (2030+1-1967))    = tEAFG_REmarg_SKM.l('landbrug','2030')*inf_factor[t]/inf_factor['2030'];
	tEAFG_REmarg_SKM.l('gartner_ETS',t) $ (ord(t) GT (2030+1-1967)) = tEAFG_REmarg_SKM.l('gartner_ETS','2030')*inf_factor[t]/inf_factor['2030'];

	#HACK: Vi indekserer dog efter 2050 for at få pæne shock/baseline-forløb, når vi laver SKM-stød
	tEAFG_REmarg_SKM.l('el_proces',t)$(t.val >=2050)   = tEAFG_REmarg_SKM.l('el_proces','2050');
	tEAFG_REmarg_SKM.l('proces',t)$(t.val >=2050)      = tEAFG_REmarg_SKM.l('proces','2050');
	tEAFG_REmarg_SKM.l('proces_ets',t) $(t.val >=2050) = tEAFG_REmarg_SKM.l('proces_ets','2050'); 
	tEAFG_REmarg_SKM.l('landbrug',t)$(t.val >=2050)    = tEAFG_REmarg_SKM.l('landbrug','2050');
	tEAFG_REmarg_SKM.l('gartner_ETS',t)$(t.val >=2050) = tEAFG_REmarg_SKM.l('gartner_ETS','2050');


# ----------------------------------------------------------------------------------------------------------------------
# Waste
# ----------------------------------------------------------------------------------------------------------------------
# --------------------------------------------------------------------------------------------------------------------
  #  Loading waste data for danish generated waste (generated waste is calculated in "..\Data\Affaldsdata\data_til_ARIMA\ARIMA_data_GEN.gms")
  #  --------------------------------------------------------------------------------------------------------------------
  PARAMETERS
              dataGen_Waste[sec,n,t]     "Final dataset for generated waste"
  ;
  # Generated waste data for sectors and households (measured in kilo ton)
  execute_loaddc "../Data/Affaldsdata/GEN_waste_2012_2020_23000.gdx", dataGEN_Waste 

  #  execute_unload "output\GEN_waste_2012_2020.gdx" dataGen_Waste;
  #  execute 'gdxxrw.exe output\GEN_waste_2012_2020.gdx o=output\GEN_waste_2012_2020.xlsx par=dataGen_Waste'

  # --------------------------------------------------------------------------------------------------------------------
  # Loading waste data for danish sorted waste 
  # --------------------------------------------------------------------------------------------------------------------
  PARAMETERS
              dataLand_brch[brch,n,t]    "Dataset for landfill waste split into 146 sectors"
              dataBurn_brch[brch,n,t]    "Dataset for burned waste split into 146 sectors"
              dataRecy_brch[brch,n,t]    "Dataset for recycled waste split into 146 sectors"
              dataUtilize_brch[brch,n,t] "Dataset for other utilized waste split into 146 sectors"
              dataLand_hus[n,t]          "Dataset for landfill waste for household"
              dataBurn_hus[n,t]          "Dataset for burned waste for household"
              dataRecy_hus[n,t]          "Dataset for recycled waste for household"
              dataUtilize_hus[n,t]       "Dataset for other utilized waste for household"
              dataLand[sec,n,t]          "Final dataset for landfill waste"
              dataBurn[sec,n,t]          "Final dataset for burned waste"
              dataRecy[sec,n,t]          "Final dataset for recycled waste"
              dataUtilize[sec,n,t]       "Final dataset for other utilized waste"

              dataUtilize_share[sec,n]   "Share of utilized waste relative to recycled waste in 2018"
  ;
  # Sorted waste data for sectors and households
  execute_loaddc "../Data/Affaldsdata/SORT_waste_2014_2020.gdx", dataLand_brch, dataBurn_brch, dataRecy_brch, dataUtilize_brch, dataLand_hus, dataBurn_hus, dataRecy_hus, dataUtilize_hus;
  # Mapping from 146 sectors 'brch' to model sectors 'sec'
  dataLand[sec,n,t]      = sum(r$(sec2r[r,sec]), sum(ns105$(map1052five(r,ns105)), sum(nsGR$(nsGR2ns105(ns105,nsGR)), sum(brch$(brch2nsGR(brch,nsGR)), dataLand_brch[brch,n,t]))));
  dataBurn[sec,n,t]      = sum(r$(sec2r[r,sec]), sum(ns105$(map1052five(r,ns105)), sum(nsGR$(nsGR2ns105(ns105,nsGR)), sum(brch$(brch2nsGR(brch,nsGR)), dataBurn_brch[brch,n,t]))));
  dataRecy[sec,n,t]      = sum(r$(sec2r[r,sec]), sum(ns105$(map1052five(r,ns105)), sum(nsGR$(nsGR2ns105(ns105,nsGR)), sum(brch$(brch2nsGR(brch,nsGR)), dataRecy_brch[brch,n,t]))));
  dataUtilize[sec,n,t]   = sum(r$(sec2r[r,sec]), sum(ns105$(map1052five(r,ns105)), sum(nsGR$(nsGR2ns105(ns105,nsGR)), sum(brch$(brch2nsGR(brch,nsGR)), dataUtilize_brch[brch,n,t]))));
  # Values for the household sector
  dataLand['hus',n,t]    = dataLand_hus[n,t];
  dataBurn['hus',n,t]    = dataBurn_hus[n,t];
  dataRecy['hus',n,t]    = dataRecy_hus[n,t];
  dataUtilize['hus',n,t] = dataUtilize_hus[n,t];
  # The measure is changed from ton to kilo ton
  dataLand[sec,n,t]      = dataLand[sec,n,t]/1000;
  dataBurn[sec,n,t]      = dataBurn[sec,n,t]/1000;
  dataRecy[sec,n,t]      = dataRecy[sec,n,t]/1000;
  dataUtilize[sec,n,t]   = dataUtilize[sec,n,t]/1000;

  # Calculating the share of waste utilized relative to the total amount of waste utilized or recycled in 2018
  dataUtilize_share[sec,n]$(dataUtilize[sec,n,'2018'] and not sameas[n,'Jord'])
                             = dataUtilize[sec,n,'2018']/(dataUtilize[sec,n,'2018']+dataRecy[sec,n,'2018']);
  # For 2014-2017 there is no data on utilized waste (utilized waste is part of recycled waste in 2014-2017).
  # We use the share of utilized waste in 2018 to split recycled waste into utilized waste and recycled waste for 2014-2017.
  dataUtilize[sec,n,t]$((sameas[t,'2014'] or sameas[t,'2015'] or sameas[t,'2016'] or sameas[t,'2017']) and not sameas[n,'Jord'])    
                             = dataUtilize_share[sec,n]*dataRecy[sec,n,t];
  dataRecy[sec,n,t]$((sameas[t,'2014'] or sameas[t,'2015'] or sameas[t,'2016'] or sameas[t,'2017']) and not sameas[n,'Jord'])    
                             = (1-dataUtilize_share[sec,n])*dataRecy[sec,n,t];   

#  SET waste_type
#    /
#    Land
#    Burn
#    Recy 
#    Utilize 
#    /;                           

#    PARAMETERS dataSORT_waste[sec,n,t,waste_type];
#    dataSORT_waste[sec,n,t,'Land'] = dataLand[sec,n,t];
#    dataSORT_waste[sec,n,t,'Burn'] = dataBurn[sec,n,t];
#    dataSORT_waste[sec,n,t,'Recy'] = dataRecy[sec,n,t];
#    dataSORT_waste[sec,n,t,'Utilize'] = dataUtilize[sec,n,t];


#    execute_unload "output\SORT_waste_2012_2020.gdx" dataSORT_waste;
#    execute 'gdxxrw.exe output\SORT_waste_2012_2020.gdx o=output\SORT_waste_2012_2020.xlsx par=dataSORT_waste'
                             
  # --------------------------------------------------------------------------------------------------------------------
  # Loading waste import data
  # --------------------------------------------------------------------------------------------------------------------
  PARAMETERS
              dataLand_im[n,t]                   "Dataset for imported landfill waste"
              dataBurn_im[n,t]                   "Dataset for imported burned waste"
              dataRecy_im[n,t]                   "Dataset for imported recycled waste"
              dataUtilize_im[n,t]                "Dataset for imported other utilized waste"

              dataUtilize_im_share[n]            "Share of imported utilized waste relative to imported recycled waste in 2018"

  ;
  execute_loaddc "../Data/Affaldsdata/Waste_Import_2014_2020.gdx", dataLand_im, dataBurn_im, dataRecy_im, dataUtilize_im;
  # The measure is changed from ton to kilo ton
  dataLand_im[n,t]               = dataLand_im[n,t]/1000;     
  dataBurn_im[n,t]               = dataBurn_im[n,t]/1000;  
  dataRecy_im[n,t]               = dataRecy_im[n,t]/1000;     
  dataUtilize_im[n,t]            = dataUtilize_im[n,t]/1000;

  # Calculating the share of waste utilized relative to the total amount of waste utilized or recycled in 2018
  dataUtilize_im_share[n]$(dataUtilize_im[n,'2018'])
                             = dataUtilize_im[n,'2018']/(dataUtilize_im[n,'2018']+dataRecy_im[n,'2018']);
  # For 2014-2017 there is no data on utilized waste (utilized waste is part of recycled waste in 2014-2017).
  # We use the share of utilized waste in 2018 to split recycled waste into utilized waste and recycled waste for 2014-2017.
  dataUtilize_im[n,t]$(sameas[t,'2014'] or sameas[t,'2015'] or sameas[t,'2016'] or sameas[t,'2017'])    
                             = dataUtilize_im_share[n]*dataRecy_im[n,t];
  dataRecy_im[n,t]$(sameas[t,'2014'] or sameas[t,'2015'] or sameas[t,'2016'] or sameas[t,'2017'])    
                             = (1-dataUtilize_im_share[n])*dataRecy_im[n,t];   

  #  PARAMETERS dataImport_waste[n,t,waste_type];
  #  dataImport_waste[n,t,'Land'] = dataLand_im[n,t];
  #  dataImport_waste[n,t,'Burn'] = dataBurn_im[n,t];
  #  dataImport_waste[n,t,'Recy'] = dataRecy_im[n,t];
  #  dataImport_waste[n,t,'Utilize'] = dataUtilize_im[n,t];


  #  execute_unload "output\Waste_Import_2014_2020.gdx" dataImport_waste;
  #  execute 'gdxxrw.exe output\Waste_Import_2014_2020.gdx o=output\Waste_Import_2014_2020.xlsx par=dataImport_waste'                             

  # --------------------------------------------------------------------------------------------------------------------
  # Loading waste export data
  # --------------------------------------------------------------------------------------------------------------------
  PARAMETERS
              dataLand_ex_brch[brch,n,t]     "Dataset for exported landfill waste for 146-sectors"
              dataBurn_ex_brch[brch,n,t]     "Dataset for exported burned waste for 146-sectors"
              dataRecy_ex_brch[brch,n,t]     "Dataset for exported recycled waste for 146-sectors"
              dataUtilize_ex_brch[brch,n,t]  "Dataset for exported other utilized waste for 146-sectors"
              dataLand_ex_hus[n,t]           "Dataset for exported landfill waste for household"
              dataBurn_ex_hus[n,t]           "Dataset for exported burned waste for household"
              dataRecy_ex_hus[n,t]           "Dataset for exported recycled waste for household"
              dataUtilize_ex_hus[n,t]        "Dataset for exported other utilized waste for household"
              dataLand_ex[sec,n,t]           "Dataset for exported landfill waste"
              dataBurn_ex[sec,n,t]           "Dataset for exported burned waste"
              dataRecy_ex[sec,n,t]           "Dataset for exported recycled waste"
              dataUtilize_ex[sec,n,t]        "Dataset for exported other utilized"

              dataUtilize_ex_share[sec,n]    "Share of exported utilized waste relative to exported recycled waste in 2018"
  ;
  execute_loaddc "../Data/Affaldsdata/Waste_Export_2014_2020.gdx", dataLand_ex_brch, dataBurn_ex_brch, dataRecy_ex_brch, dataUtilize_ex_brch, dataLand_ex_hus, dataBurn_ex_hus, dataRecy_ex_hus, dataUtilize_ex_hus;
  # Mapping from 146 sectors 'brch' to model sectors 'sec'
  dataLand_ex[sec,n,t]      = sum(r$(sec2r[r,sec]), sum(ns105$(map1052five(r,ns105)), sum(nsGR$(nsGR2ns105(ns105,nsGR)), sum(brch$(brch2nsGR(brch,nsGR)), dataLand_ex_brch[brch,n,t]))));
  dataBurn_ex[sec,n,t]      = sum(r$(sec2r[r,sec]), sum(ns105$(map1052five(r,ns105)), sum(nsGR$(nsGR2ns105(ns105,nsGR)), sum(brch$(brch2nsGR(brch,nsGR)), dataBurn_ex_brch[brch,n,t]))));
  dataRecy_ex[sec,n,t]      = sum(r$(sec2r[r,sec]), sum(ns105$(map1052five(r,ns105)), sum(nsGR$(nsGR2ns105(ns105,nsGR)), sum(brch$(brch2nsGR(brch,nsGR)), dataRecy_ex_brch[brch,n,t]))));
  dataUtilize_ex[sec,n,t]   = sum(r$(sec2r[r,sec]), sum(ns105$(map1052five(r,ns105)), sum(nsGR$(nsGR2ns105(ns105,nsGR)), sum(brch$(brch2nsGR(brch,nsGR)), dataUtilize_ex_brch[brch,n,t]))));
  # Values for the household sector
  dataLand_ex['hus',n,t]    = dataLand_ex_hus[n,t];
  dataBurn_ex['hus',n,t]    = dataBurn_ex_hus[n,t];
  dataRecy_ex['hus',n,t]    = dataRecy_ex_hus[n,t];
  dataUtilize_ex['hus',n,t] = dataUtilize_ex_hus[n,t];
  # The measure is changed from ton to kilo ton
  dataLand_ex[sec,n,t]       = dataLand_ex[sec,n,t]/1000;     
  dataBurn_ex[sec,n,t]       = dataBurn_ex[sec,n,t]/1000;  
  dataRecy_ex[sec,n,t]       = dataRecy_ex[sec,n,t]/1000;   
  dataUtilize_ex[sec,n,t]    = dataUtilize_ex[sec,n,t]/1000;  

  # Calculating the share of waste utilized relative to the total amount of waste utilized or recycled in 2018
  dataUtilize_ex_share[sec,n]$(dataUtilize_ex[sec,n,'2018'])
                             = dataUtilize_ex[sec,n,'2018']/(dataUtilize_ex[sec,n,'2018']+dataRecy_ex[sec,n,'2018'])  ;
  # For 2014-2017 there is no data on utilized waste (utilized waste is part of recycled waste in 2014-2017).
  # We use the share of utilized waste in 2018 to split recycled waste into utilized waste and recycled waste for 2014-2017.
  dataUtilize_ex[sec,n,t]$(sameas[t,'2014'] or sameas[t,'2015'] or sameas[t,'2016'] or sameas[t,'2017'])    
                             = dataUtilize_ex_share[sec,n]*dataRecy_ex[sec,n,t];
  dataRecy_ex[sec,n,t]$(sameas[t,'2014'] or sameas[t,'2015'] or sameas[t,'2016'] or sameas[t,'2017'])    
                             = (1-dataUtilize_ex_share[sec,n])*dataRecy_ex[sec,n,t];                                  

  #  PARAMETERS dataExport_waste[sec,n,t,waste_type];
  #  dataExport_waste[sec,n,t,'Land'] = dataLand_ex[sec,n,t];
  #  dataExport_waste[sec,n,t,'Burn'] = dataBurn_ex[sec,n,t];
  #  dataExport_waste[sec,n,t,'Recy'] = dataRecy_ex[sec,n,t];
  #  dataExport_waste[sec,n,t,'Utilize'] = dataUtilize_ex[sec,n,t];


  #  execute_unload "output\Waste_Export_2014_2020.gdx" dataExport_waste;
  #  execute 'gdxxrw.exe output\Waste_Export_2014_2020.gdx o=output\Waste_Export_2014_2020.xlsx par=dataExport_waste'

  # --------------------------------------------------------------------------------------------------------------------
  # Loading emission and energy coefficients
  # --------------------------------------------------------------------------------------------------------------------  
  PARAMETERS 
              emission_coef[n,emm] 
              energy_coef[n]
  ;
  execute_loaddc "../Data/Affaldsdata/Emissions_koefficienter.gdx", emission_coef;
  execute_loaddc "../Data/Affaldsdata/Energi_koefficienter.gdx", energy_coef;

  # --------------------------------------------------------------------------------------------------------------------
  # Loading ARIMA generating coefficients
  # --------------------------------------------------------------------------------------------------------------------
  PARAMETERS 
              arima_GEN[sec,n,t]
              arima_GEN_hus[sec,n,t]
  ;
  #  execute_loaddc "..\Data\Affaldsdata\GEN_coef_ARIMAforecast_notLastPeriodValue.gdx", arima_GEN; 
  execute_loaddc "../Data/Affaldsdata/GEN_coef_ARIMAforecast_23000.gdx", arima_GEN; 
  execute_loaddc "../Data/Affaldsdata/GEN_coef_ARIMAforecast_hus.gdx", arima_GEN_hus = arima_GEN; 

  arima_GEN['hus',n,t] = arima_GEN_hus['hus',n,t];

  # --------------------------------------------------------------------------------------------------------------------
  # Loading ARIMA sorting coefficients
  # --------------------------------------------------------------------------------------------------------------------
  PARAMETERS 
              arima_SORT[sec,n,t]
  ;
  execute_loaddc "../Data/Affaldsdata/SORT_coef_ARIMAforecast_23000.gdx", arima_SORT; 


  # --------------------------------------------------------------------------------------------------------------------
  # Loading coefficients for residual waste
  # --------------------------------------------------------------------------------------------------------------------
  PARAMETERS 
              dataRESMetal[g_waste,n]                  "Share of total residual waste from recycling 'n' that goes into Metal"
              dataRESDag [g_waste,n]                   "Share of total residual waste from recycling 'n' that goes into Dag"
              dataRESDep[g_waste,n]                    "Share of total residual waste from recycling 'n' that goes into Dep"
              dataRESFarlig[g_waste,n]                 "Share of total residual waste from recycling 'n' that goes into Farlig"
              dataRESPlast[g_waste,n]                  "Share of total residual waste from recycling 'n' that goes into Plast"
              dataRESGlas[g_waste,n]                   "Share of total residual waste from recycling 'n' that goes into Glas"
              dataBetaLevel[g_waste,n]         "Data for residual waste coefficient - level"
  ;
  execute_loaddc "../Data/Affaldsdata/ResidualWaste_ny.gdx", dataRESMetal, dataRESDag, dataRESDep, dataRESFarlig, dataRESPlast, dataRESGlas;
  execute_loaddc "../Data/Affaldsdata/ResOutcome_ny.gdx", dataBetaLevel;

  # --------------------------------------------------------------------------------------------------------------------
  # Loading parameter values for the CET-function 
  # --------------------------------------------------------------------------------------------------------------------
  PARAMETERS
              xiE_w[g_waste,n]                 "Parameter in CET function"
              xiR_w[g_waste,n]                 "Parameter in CET function"
              epsilon_w[g_waste,n]             "Parameter in CET function"
              gamma_w[g_waste,n]               "Parameter in CET function"
              omega_w[g_waste,n]               "Parameter in CET function"

              xiE_klimaplan[g_waste,n]         "Parameter in CET function affected by the climate plan"
              xiR_klimaplan[g_waste,n]         "Parameter in CET function affected by the climate plan"
              epsilon_klimaplan[g_waste,n]     "Parameter in CET function affected by the climate plan"
              gamma_klimaplan[g_waste,n]       "Parameter in CET function affected by the climate plan"
              omega_klimaplan[g_waste,n]       "Parameter in CET function affected by the climate plan"
  ;
  execute_loaddc "../Data/Affaldsdata/CET_parameter_values_Dec2023.gdx", xiE_w, xiR_w, epsilon_w, gamma_w, omega_w
                                                                      xiE_klimaplan, xiR_klimaplan, epsilon_klimaplan, gamma_klimaplan, omega_klimaplan; 

  # --------------------------------------------------------------------------------------------------------------------
  # Loading data for municipal waste shares
  # --------------------------------------------------------------------------------------------------------------------
  PARAMETERS
              #  MW_share_117[ns117,n]               "Share of municipal waste - 117-sectors"
              MW_share_s56[r,n]                   "Share of municipal waste - 56-sectors"
              MW_share_hus[n]                     "Share of municipal waste - household"
              MW_share[sec,n]                     "Share of municipal waste"
  ;
  execute_loaddc "../Data/Affaldsdata/MW_share_23000.gdx", MW_share_s56, MW_share_hus; 

  #  MW_share[sec,n] = sum(s56$(s56_2_sec[s56,sec]), sum(ns146$(ns146_2_s56(ns146,s56)), sum(ns117$(IOns117_2_IOns146(ns117,ns146)), MW_share_117[ns117,n])));
  MW_share_s56['10012',n] = MW_share_s56['10011',n];
  MW_share_s56['10013',n] = MW_share_s56['10011',n];
  
  MW_share[sec,n] = sum(r$(sec2r[r,sec]), MW_share_s56[r,n]);
  MW_share['hus',n] = MW_share_hus[n];

  #  execute_unload "output\MW_share.gdx" MW_share;
  #  execute 'gdxxrw.exe output\MW_share.gdx o=output\MW_share.xlsx par=MW_share'

  # --------------------------------------------------------------------------------------------------------------------
  # Loading effects from the climate plan (Effekter af virkemidlerne fra klimaplanen - MST)
  # --------------------------------------------------------------------------------------------------------------------
  PARAMETERS
              virkemiddel_GEN[sec,g_waste,n,t]         "Effects on waste generation from the climate plan"
              virkemiddel_SORT_hus[sec,g_waste,n,t]    "Effects on waste sorting for households from the climate plan"
              virkemiddel_SORT_erhv[g_waste,n,t]       "Effects on waste sorting for the sectors from the climate plan"
              virkemiddel_SORT[sec,g_waste,n,t]        "Effects on waste sorting from the climate plan"
              virkemiddel_affaldshierarki[g_waste,n,t] "Effects on utilized and burned waste from the climate plan"
  ;
  execute_loaddc "../Data/Affaldsdata/Klimaplan_virkemidler_procent.gdx", virkemiddel_GEN, virkemiddel_SORT_hus,virkemiddel_SORT_erhv,
                                                                  virkemiddel_affaldshierarki;
  #  # The measure is changed from ton to kilo ton
  #  virkemiddel_GEN[sec,g_waste,n,t]         = virkemiddel_GEN[sec,g_waste,n,t]/1000;  
  #  virkemiddel_SORT_hus[sec,g_waste,n,t]    = virkemiddel_SORT_hus[sec,g_waste,n,t]/1000;
  #  virkemiddel_SORT_erhv[g_waste,n,t]       = virkemiddel_SORT_erhv[g_waste,n,t]/1000;  
  #  virkemiddel_affaldshierarki[g_waste,n,t] = virkemiddel_affaldshierarki[g_waste,n,t]/1000;

  # --------------------------------------------------------------------------------------------------------------------
  # Loading hardcoded parameters for degree of recycling from MST
  # --------------------------------------------------------------------------------------------------------------------
  PARAMETERS
              uWasteR_DATA[g_waste,n]                  "Hardcoded degree of recycling from MST"
  ;
  execute_loaddc "../Data/Affaldsdata/Genanvendelsesgrad.gdx", uWasteR_DATA = Genanvendelsesgrad;


# ----------------------------------------------------------------------------------------------------------------------
# Energy-IO 
# ----------------------------------------------------------------------------------------------------------------------

IO_vY_CET[energy19,s,t] =  EN_vE_y[energy19,s,t];
IO_qY_CET[energy19,s,t] =  EN_qE_y[energy19,s,t];

IO_pY_CET[energy19,s,t]$(IO_vY_CET[energy19,s,t]) = IO_vY_CET[energy19,s,t]/IO_qY_CET[energy19,s,t];
IO_pY_CET[out,s,t]$(not IO_vY_CET[out,s,t]) = 0;

IO_vY_CET['WholeAndRetailSaleMarginE','46000',t] = sum(energy19,EN_vWholeSaleE_y[energy19,t]);
IO_vY_CET['WholeAndRetailSaleMarginE','47000',t] = sum(energy19,EN_vDetailSaleE_y[energy19,t]);
IO_vY_CET['WholeAndRetailSaleMarginE','45000',t] = sum(energy19,EN_vCaretradeEsale_y[energy19,t]);

IO_qY_CET['WholeAndRetailSaleMarginE','46000',t] = sum(energy19,EN_qWholeSaleE_y[energy19,t]);
IO_qY_CET['WholeAndRetailSaleMarginE','47000',t] = sum(energy19,EN_qDetailSaleE_y[energy19,t]);
IO_qY_CET['WholeAndRetailSaleMarginE','45000',t] = sum(energy19,EN_qCaretradeEsale_y[energy19,t]);

IO_pY_CET['WholeAndRetailSaleMarginE','46000',t]$(IO_vY_CET['WholeAndRetailSaleMarginE','46000',t]) = IO_vY_CET['WholeAndRetailSaleMarginE','46000',t]/IO_qY_CET['WholeAndRetailSaleMarginE','46000',t];
IO_pY_CET['WholeAndRetailSaleMarginE','47000',t]$(IO_vY_CET['WholeAndRetailSaleMarginE','47000',t]) = IO_vY_CET['WholeAndRetailSaleMarginE','47000',t]/IO_qY_CET['WholeAndRetailSaleMarginE','47000',t];
IO_pY_CET['WholeAndRetailSaleMarginE','45000',t]$(IO_vY_CET['WholeAndRetailSaleMarginE','45000',t]) = IO_vY_CET['WholeAndRetailSaleMarginE','45000',t]/IO_qY_CET['WholeAndRetailSaleMarginE','45000',t];


#Egetforbrug - skal lægges over i python
PARAMETER vnRE_IO[purpose,energy19,r,t], qRE_IO[purpose,energy19,r,t], qRE_IO_noV[purpose,energy19,r,t], qCE_IO_noV[purpose,energy19,t], qLE_IO_noV[purpose,energy19,t], qXE_IO_noV[purpose,energy19,t];

vnRE_IO[purpose,energy19,r,t] = EN_vnRE[purpose,energy19,r,t];
qRE_IO[purpose,energy19,r,t]  = EN_qRE[purpose,energy19,r,t];

qRE_IO_noV[purpose,energy19,r,t]$(not vnRE_IO[purpose,energy19,r,t]) = qRE_IO[purpose,energy19,r,t];
qCE_IO_noV[purpose,energy19,t]$(not EN_vnCE[purpose,energy19,t])     = EN_qCE[purpose,energy19,t];
qLE_IO_noV[purpose,energy19,t]$(not EN_vnLE[purpose,energy19,t])     = EN_qLE[purpose,energy19,t];
qXE_IO_noV[purpose,energy19,t]$(not EN_vnXE[purpose,energy19,t])     = EN_qXE[purpose,energy19,t];


Parameter nonmarketstraw[t], nonmarketbiogas[t], nonmarket_naturalgasbion[t];
nonmarketstraw[t] =  sum(purpose, sum(r, qRE_IO_noV[purpose,'Straw for energy purposes',r,t])   
						               + qCE_IO_noV[purpose,'Straw for energy purposes',t]);  


nonmarketbiogas[t] = sum(purpose, sum(r, qRE_IO_noV[purpose,'Biogas',r,t]) 
						               + qCE_IO_noV[purpose,'Biogas',t]);  

nonmarket_naturalgasbion[t] = sum(purpose, sum(r, qRE_IO_noV[purpose,'Natural gas incl. biongas',r,t]) 
						               + qCE_IO_noV[purpose,'Natural gas incl. biongas',t]);  

						               
#  display qRE_IO_noV, qCE_IO_noV, qLE_IO_nov, qXE_IO_noV;
#  display nonmarketstraw, nonmarketbiogas, IO_qY_CET;

PARAMETER ownconsumption_RE[purpose,energy19,r,t], ownproduction[energy19,s,t], ownconsumption_CE[purpose,energy19,r,t];
ownproduction[energy19,s,t]$(not IO_vY_CET[energy19,s,t]) = IO_qY_CET[energy19,s,t];
ownconsumption_RE[purpose,energy19,r,t]$(IO_qY_CET[energy19,r,t]) = qRE_IO_noV[purpose,energy19,r,t];
ownconsumption_CE[purpose,energy19,r,t]$(IO_qY_CET[energy19,r,t]) = qCE_IO_noV[purpose,energy19,t];


#Trækker egetforbrug ud, NB - skal have placeret egetforbrug et sted igen. 	
PARAMETER MarketShareStraw[s,t];
MarketShareStraw['01011',t]$(IO_qY_CET['Straw for energy purposes','01011',t]+ IO_qY_CET['Straw for energy purposes','01012',t]) = IO_qY_CET['Straw for energy purposes','01011',t]/(IO_qY_CET['Straw for energy purposes','01011',t]+ IO_qY_CET['Straw for energy purposes','01012',t]);
MarketShareStraw['01012',t]$(IO_qY_CET['Straw for energy purposes','01011',t]+ IO_qY_CET['Straw for energy purposes','01012',t]) = IO_qY_CET['Straw for energy purposes','01012',t]/(IO_qY_CET['Straw for energy purposes','01011',t]+ IO_qY_CET['Straw for energy purposes','01012',t]);


IO_qY_CET['Straw for energy purposes','01011',t]
	= IO_qY_CET['Straw for energy purposes','01011',t] - nonmarketstraw[t] * MarketShareStraw['01011',t]; 
IO_qY_CET['Straw for energy purposes','01012',t]
	= IO_qY_CET['Straw for energy purposes','01012',t] - nonmarketstraw[t] * MarketShareStraw['01012',t]; 
#  display IO_qY_CET;

#  IO_qY_CET['Straw for energy purposes','01011',t] = IO_qY_CET['Straw for energy purposes','01011',t] - nonmarketstraw[t];


#Trækker ikke-markedsmæssig biogas ud
IO_qY_CET['Biogas','35002',t] = IO_qY_CET['Biogas','35002',t] - nonmarketbiogas[t];

#Trækker ikke-markedsmæssig naturgas+biongas ud 
	IO_qY_CET['Natural gas incl. biongas','35002',t] = IO_qY_CET['Natural gas incl. biongas','35002',t] - nonmarket_naturalgasbion[t];


#Korrigerer naturgas
	IO_qY_CET['Natural gas (Extraction)','0600a',t]  = IO_qY_CET['Natural gas (Extraction)','0600a',t]  - sum(purpose, qRE_IO_noV[purpose,'Natural gas (Extraction)','0600a',t]);    

#Genberegner priser
	IO_pY_CET['Straw for energy purposes','01011',t]$(IO_vY_CET['Straw for energy purposes','01011',t])       =  IO_vY_CET['Straw for energy purposes','01011',t]/IO_qY_CET['Straw for energy purposes','01011',t]; 
	IO_pY_CET['Straw for energy purposes','01012',t]$(IO_vY_CET['Straw for energy purposes','01012',t])       =  IO_vY_CET['Straw for energy purposes','01012',t]/IO_qY_CET['Straw for energy purposes','01012',t]; 
	IO_pY_CET['Biogas','35002',t]$(IO_vY_CET['Biogas','35002',t])                                             =  IO_vY_CET['biogas','35002',t]/IO_qY_CET['biogas','35002',t];
	IO_pY_CET['Natural gas (Extraction)','0600a',t]$(IO_vY_CET['Natural gas (Extraction)','0600a',t])         =  IO_vY_CET['Natural gas (Extraction)','0600a',t]/IO_qY_CET['Natural gas (Extraction)','0600a',t]; 
	IO_pY_CET['Natural gas incl. biongas','35002',t]$(IO_vY_CET['Natural gas incl. biongas','35002',t])       =  IO_vY_CET['Natural gas incl. biongas','35002',t]/IO_qY_CET['Natural gas incl. biongas','35002',t]; 

	
#Importen af alle energi-varer ligges i 19000 - det skal enten rettes, eller acceptere at vi ikke er tro imod data.
	IO_vM_CET[energy19,'19000',t] = (EN_vE_m[energy19,t] + EN_vCUS[energy19,t]);
	IO_qM_CET[energy19,'19000',t] = EN_qE_m[energy19,t];
	IO_pM_CET[energy19,'19000',t]$(IO_vM_CET[energy19,'19000',t]) = IO_vM_CET[energy19,'19000',t]/IO_qM_CET[energy19,'19000',t];
	IO_pM_CET[out,s,t]$(not IO_vM_CET[out,s,t]) = 0;
# #Prisen på brænde er bizart lav i DST's data ift. hos ENS (ca. halvdelen). For det private forbrug er prisen endnu lavere. Her skyldes en stor del egenproduktion


# ----------------------------------------------------------------------------------------------------------------------
# Landbrug 
# ----------------------------------------------------------------------------------------------------------------------

	PARAMETER NM_IO[modtager_pgren,afsender_pgren,regnskabspost,t], vFertilizer_data[r,t], Napplied[Nsource,t], FracLeach[t]; #qPlant_land_data[ns105,t], qPlant_land_OEKO_BDF[ns105,t], pLand_data[t],
	execute_load "../Data/IkkeMarkedsligIO/Non-market_IO_without_small_values.gdx" NM_IO = NON_market_IO;
	execute_load "../Data/External_data/out/external_data_new.gdx" vFertilizer_data = vFertilizer.l;

	execute_loaddc "../Data/LULUCF/N_in_agr.gdx" Napplied  = Napplied.l; #AKB: Kilder til N i landbruget fra CRF-tabeller 
	execute_loaddc "../Data/LULUCF/N_in_agr.gdx" FracLeach = FracLeach.l; #Udvaskningskoefficient. Jf. korrespondance med Rikke fra DCE trækkes denne konstant efter sidste dataår, når de fremskriver.
	Napplied[Nsource,t] = Napplied[Nsource,t]/10**9; #Omregner til mio. tN.

	#Kystvand 2022 
	PARAMETER data_LGT_kystvand_kon[KystomraadeID,LGTkystvandCols], data_LGT_kystvand_oek[KystomraadeID,LGTkystvandCols],data_LGT_kystvand_tot[KystomraadeID,LGTkystvandCols], udvaskningsdata[idKystvand,ColumnsKystvand];
	execute_loaddc '../Data/Kystvand/kystvand2022.gdx' udvaskningsdata       = udvaskningsdata.l;
	
	#CAP 2023-2027
	PARAMETER capbudget2023_2027[kat,t];
	execute_loaddc '../Data/CAP/capbudget2023_2027.gdx' capbudget2023_2027 = capbudget.l;

	#omregner til mia. kr.
	capbudget2023_2027[kat,t] = capbudget2023_2027[kat,t]/1000; 

	#Vækst- og inflationskorrigerer 
	capbudget2023_2027[kat,t] = capbudget2023_2027[kat,t]*inf_growth_factor[t];

	#I mangel af data trækkes budgette fladt før 2023 og efter 2027
	capbudget2023_2027[kat,t]$(t.val<2023 and t.val>=2018) = capbudget2023_2027[kat,'2023'];
	capbudget2023_2027[kat,t]$(t.val>2027) = capbudget2023_2027[kat,'2027'];

	PARAMETER capitaldistREGNPRO[k,agri_sectors,t];

	execute_loaddc '../Data/Klimafremskrivningen/capitaldistREGNPRO.gdx' capitaldistREGNPRO = capitaldistREGNPRO.l;




# ----------------------------------------------------------------------------------------------------------------------
# Klimafremskrivningen 
# ----------------------------------------------------------------------------------------------------------------------

	  #E----------ENERGY AND EMISSIONS---------------#
		$PGROUP G_KF_energy_and_emissions_1_data_in KF_ANV_NatBal[e28,sENS,t] "", KF_TIL_NatBal[e28,sENS,t] "", KF_emm[emm_eq,sCRF,t] "";

		$PGROUP G_KF_energy_and_emissions_2_data_in
				   KF25_energybalance_ENS[t,sENSny,ENS32,GSR] "",
				   KF25_energybalance_ENS_EMM[t,sENSny,ENS32,GSR] "",
				   KF_EMM_xE[t,sENSny,GSR] ""
				   KF_EmmKoeff[ENS32,t] ""
           KF25_energybalance_ENS_KF24[t,sENSny,ENS32] ""        
	 ;

   $PGROUP G_KF_energy_prices_data_in 
           KF25_baseprice_e_tau[e_tau,t] ""
           KF25_deflator[t] ""
           KF25_delcost_e_tau[s_tau,e_tau,t] ""
           KF25_gastariffs[s_tau,ets_uk,e_tau,t] ""

           KF25_baseprice_ENS32[ENS32,t] ""
           KF25_delcost_ENS32[sENSny,ENS32,t] ""
           KF25_gastariffs_ENS32[sENSny,purpose,ENS32,t] ""

           KF25_pETS[t] ""
           KF25_pETS2[t] ""
           KF25_pCrudeoil[t] ""
  ;

  		execute_loaddc '../Data/Klimafremskrivningen/klimafremskrivning_2025_ebalagg_crf_prices.gdx' $LOOP G_KF_energy_and_emissions_1_data_in: {name} = {name}.l $ENDLOOP;
  		execute_loaddc '../Data/Klimafremskrivningen/klimafremskrivning_2025_ebalagg_crf_prices.gdx' KF_EmmKoeff      = EmmKoeff.l; 

  		execute_loaddc '../Data/Klimafremskrivningen/energybalance_KF25.gdx' KF25_energybalance_ENS              = KF_ANV.l;
  		execute_loaddc '../Data/Klimafremskrivningen/energybalance_KF25.gdx' KF25_energybalance_ENS_EMM          = KF_EMM_E.l;
  		execute_loaddc '../Data/Klimafremskrivningen/energybalance_KF25.gdx' KF_EMM_xE                      = KF_EMM_xE.l;


      # Check of energy balance data (we take the official energy-balance "KF_ANV_NatBal, and ") 
      #  set opgoerelse/KF_ANV,KF25_energybalance_ENS,diff/;
      #  PARAMETER testebals[opgoerelse,e28,t];
      #  testebals['KF_ANV',e28,t] = -sum(sENS$TestPurpose(sENS),KF_ANV_NatBal[e28,sENS,t])/1000;
      #  testebals['KF25_energybalance_ENS',e28,t] = sum((ENS32,sENSNy,GSR)$(mappinge28_ENS32(e28,ENS32) and not mappingTestExceptions(sENSny,e28)), KF25_energybalance_ENS[t,sENSny,ENS32,GSR]);
      #  testebals['diff',e28,t] = testebals['KF_ANV',e28,t] - testebals['KF25_energybalance_ENS',e28,t];
      #  testebals['diff',e28,t]$(abs(testebals['diff',e28,t])<2) = 0;
      #  execute_unload 'output\testbal.gdx';

      #Testen fejler på elektricitet, fordi eksporten er højere i den disaggregerede energibalance vis-a-vis den officielle energibalance.
      LOOP((e28,t)$(t.val >= 2024 and not sameas[e28,'elektricitet']), 
        tjek = sum(sENS$(TestPurpose(sENS)), -KF_ANV_NatBal[e28,sENS,t])/1000 - 
          sum((ENS32,sENSNy,GSR)$(mappinge28_ENS32(e28,ENS32) and not mappingTestExceptions(sENSny,e28)), KF25_energybalance_ENS[t,sENSny,ENS32,GSR]); 
        ABORT$(abs(tjek) > 2) tjek, "Non-compatible energy balances";       
      );

	  #E----------PRICES---------------#
      #Not in intERACT data
  		execute_loaddc '../Data/Klimafremskrivningen/klimafremskrivning_2025_ebalagg_crf_prices.gdx' KF25_pETS               = KF_tETS1.l;
  		execute_loaddc '../Data/Klimafremskrivningen/klimafremskrivning_2025_ebalagg_crf_prices.gdx' KF25_pETS2              = KF_tETS2.l;
  		execute_loaddc '../Data/Klimafremskrivningen/klimafremskrivning_2025_ebalagg_crf_prices.gdx' KF25_pCrudeoil          = KF_crudeoilprice.l;

      #IntERAT data 
      execute_loaddc 'Abatement/Python_databehandling/data/Output/Abatement_data.gdx' KF25_deflator = deflator;
      execute_loaddc 'Abatement/Python_databehandling/data/Output/Abatement_data.gdx' KF25_baseprice_e_tau = BasePrice;
      execute_loaddc 'Abatement/Python_databehandling/data/Output/Abatement_data.gdx' KF25_delcost_e_tau = DelCost;
      execute_loaddc 'Abatement/Python_databehandling/data/Output/Abatement_data.gdx' KF25_gastariffs = GasTariff;

      #Omregner inputpriser til løbende priser 
      $PGROUP G_KF_energy_prices_data_in_x G_KF_energy_prices_data_in, -KF25_deflator;

      KF25_pETS[t]= KF25_pETS[t] * KF25_deflator['2024']; #Omregner til 2019-priser som resten
      KF25_pETS2[t]= KF25_pETS2[t] * KF25_deflator['2024']; #Omregner til 2019-priser som resten
      KF25_pCrudeoil[t] = KF25_pCrudeoil[t]  * KF25_deflator['2024']; #Omregner til 2019-priser som resten

      $LOOP G_KF_energy_prices_data_in_x: 
      {name}{sets}$(KF25_deflator[t]) = {name}{sets}/KF25_deflator[t];
      $ENDLOOP 

      KF25_baseprice_ENS32['Raaolie',t] = KF25_pCrudeoil[t];

      KF25_baseprice_ENS32[ENS32,t] = sum(map_e_tau2ENS32(e_tau,ENS32), KF25_baseprice_e_tau[e_tau,t]);
      KF25_delcost_ENS32[sENSny,ENS32,t] = sum((s_tau,e_tau)$(map_e_tau2ENS32(e_tau,ENS32) and s_tau2sENSny(s_tau,sENSny)), KF25_delcost_e_tau[s_tau,e_tau,t]);
      KF25_gastariffs_ENS32[sENSny,'in_ETS',ENS32,t] = sum((s_tau,e_tau)$(map_e_tau2ENS32(e_tau,ENS32) and s_tau2sENSny(s_tau,sENSny)), KF25_gastariffs[s_tau,'ETS',e_tau,t]);     
      KF25_gastariffs_ENS32[sENSny,purpose,ENS32,t]$(not sameas[purpose,'in_ETS']) = sum((s_tau,e_tau)$(map_e_tau2ENS32(e_tau,ENS32) and s_tau2sENSny(s_tau,sENSny)), KF25_gastariffs[s_tau,'notETS',e_tau,t]);

	    #Further treatment of KF-energydata
		$import data_KFenergy.gms

	#-------------AGRICULTURE--------------------#

    $PGROUP G_agr_fremskrivning_KF25
      # From agricultural forecast
      KF_qAni[Ani_sectors,t] "Production quantities from KF (with growth)" 
      KF_pAni[Ani_sectors,t] "Production prices from KF (nominal)"
      KF_qPlant[plant_sectors,t] "Production quantities from KF (with growth)"
      KF_pPlant[plant_sectors,t] "Production prices from KF (nominal)"
      KF_qPlant_landProductive[plant_sectors,t] "Agricultural land from KF (1000 hectares)"
      KF_qLand_nonproductive[landallocation,plant_sectors,t] "Non-productive agricultural land from KF (1000 hectares)"
      # From climate outlook
      KF_animals[Ani_sectors,Animals,t] "Number of animals from KF (mio.)"
      KF_NPK[t] "" # LBS: Indgår i integration_agr.gms
      KF_uEmmAgrAnimals[emmtype,Animals,ani_sectors,t,emm_eq] "Animal emission factors from KF (kg per animal)"
      KF_qEmmAgrAnimalsOther[emmtype,t,emm_eq] "Emissions from other animals from KF (kt)"
      KF_landemissions[emmtype_dis,emm,t] "Emissions from land (mio. tCO2e)" 
      KF_NabDyrViaLager[Ani_sectors,Animals,t] ""
      KF_NabDyrViaLager_OtherAnimals[t] ""
      KF_IndN2O_NH3[Ani_sectors,Animals,t] ""
      KF_IndN2O_NH3_OtherAnimals[t] ""
      KF_IndN2O_NOx[Ani_sectors,Animals,t] ""
      KF_IndN2O_NOx_OtherAnimals[t] ""
      KF_qEmmAgrAnimals_NH3[emmtype,animals,t] ""

    ; 

		
		#LOAD DATA
      execute_loaddc '../Data/Klimafremskrivningen/KF25_landbrug.gdx' $LOOP G_agr_fremskrivning_KF25: {name} = {name}.l $ENDLOOP;

      #Der mangler økokvæg før 2024 i data. Der ekstrapoleres baglæns med produktionsmængde 
      KF_animals['01032',animals,'2023'] = KF_animals['01032',animals,'2024'] * KF_qAni['01032','2023']/KF_qAni['01032','2024'];
      KF_animals['01032',animals,'2022'] = KF_animals['01032',animals,'2023'] * KF_qAni['01032','2022']/KF_qAni['01032','2023'];
      KF_animals['01032',animals,'2021'] = KF_animals['01032',animals,'2022'] * KF_qAni['01032','2021']/KF_qAni['01032','2022'];
      KF_animals['01032',animals,'2020'] = KF_animals['01032',animals,'2021'] * KF_qAni['01032','2020']/KF_qAni['01032','2021'];
      KF_animals['01032',animals,'2019'] = KF_animals['01032',animals,'2020'] * KF_qAni['01032','2019']/KF_qAni['01032','2020'];

      #Der mangler også økokvægsemissionskoefficienter før 2023 i data 
      KF_uEmmAgrAnimals[emmtype,animals,'01032','2019',emm] = KF_uEmmAgrAnimals[emmtype,animals,'01032','2024',emm];
      KF_uEmmAgrAnimals[emmtype,animals,'01032','2020',emm] = KF_uEmmAgrAnimals[emmtype,animals,'01032','2024',emm];
      KF_uEmmAgrAnimals[emmtype,animals,'01032','2021',emm] = KF_uEmmAgrAnimals[emmtype,animals,'01032','2024',emm];
      KF_uEmmAgrAnimals[emmtype,animals,'01032','2022',emm] = KF_uEmmAgrAnimals[emmtype,animals,'01032','2024',emm];
      KF_uEmmAgrAnimals[emmtype,animals,'01032','2023',emm] = KF_uEmmAgrAnimals[emmtype,animals,'01032','2024',emm];

      #Og gødning
      KF_NabDyrViaLager['01032',animals,'2023'] = KF_NabDyrViaLager['01032',animals,'2024'] * KF_qAni['01032','2023']/KF_qAni['01032','2024'];
      KF_NabDyrViaLager['01032',animals,'2022'] = KF_NabDyrViaLager['01032',animals,'2023'] * KF_qAni['01032','2022']/KF_qAni['01032','2023'];
      KF_NabDyrViaLager['01032',animals,'2021'] = KF_NabDyrViaLager['01032',animals,'2022'] * KF_qAni['01032','2021']/KF_qAni['01032','2022'];
      KF_NabDyrViaLager['01032',animals,'2020'] = KF_NabDyrViaLager['01032',animals,'2021'] * KF_qAni['01032','2020']/KF_qAni['01032','2021'];
      KF_NabDyrViaLager['01032',animals,'2019'] = KF_NabDyrViaLager['01032',animals,'2020'] * KF_qAni['01032','2019']/KF_qAni['01032','2020'];





      PARAMETER KF_qAni_dis[husdyrtype,ani_sectors_,animals,t];
      execute_loaddc '../Data/Klimafremskrivningen/Agriculture/KF25/Variable/husdyr_data.gdx' KF_qAni_dis = husdyrdata;
      KF_qAni_dis[husdyrtype,ani_sectors_,animals,t]$(t.val>2050) = KF_qAni_dis[husdyrtype,ani_sectors_,animals,'2050']; #Trækker data fremad i tid

		#Trunkerer NH3 på tidspunktet t=2040 (5 år efter øvrige emissionskoefficienter)
		   KF_landemissions[emmtype_dis,'NH3',t]$(t.val>2050) = 0;


    #Afgiftsfritagede 
      PARAMETER afgiftsfritagede[t,animals,ani_sectors];
      execute_load '../Data/Klimafremskrivningen/Agriculture/KF25/Afgiftsfritagede.gdx' afgiftsfritagede = Afgiftsfritagede;
      afgiftsfritagede[t,animals,ani_sectors]$afgiftsfritagede[t,animals,ani_sectors] = 1 - afgiftsfritagede[t,animals,ani_sectors];
      afgiftsfritagede[t,animals,ani_sectors]$(t.val>2050) = afgiftsfritagede['2050',animals,ani_sectors];

    #Bundfradrag per dyr
      PARAMETER pBotdedPerAnimal_data[emmtype,ani_sectors,animals,t,emm_eq];
      execute_loaddc '../Data/Klimafremskrivningen/Agriculture/KF25/botdeduction_animals.gdx' pBotdedPerAnimal_data=pBotdedPerAnimal.l;

    #Smågrise/slagtesvin
    $IF %smaagrisesplit%:

      KF_qAni['01052',t] = KF_qAni['01051',t];
      KF_pAni['01052',t] = KF_qAni['01051',t];

      KF_animals['01051','Piglets',t]       = KF_animals['01051','Piglets',t]       + KF_animals['01052','Piglets',t]; KF_animals['01052','Piglets',t] = 0;
      KF_animals['01051','PigsSows',t]      = KF_animals['01051','PigsSows',t]      + KF_animals['01052','PigsSows',t]; KF_animals['01052','PigsSows',t] = 0;
      KF_animals['01052','PigsFattening',t] = KF_animals['01051','PigsFattening',t] + KF_animals['01052','PigsFattening',t]; KF_animals['01051','PigsFattening',t] = 0;


      KF_uEmmAgrAnimals[emmtype,'Piglets','01051',t,emm_eq]       = KF_uEmmAgrAnimals[emmtype,'Piglets','01051',t,emm_eq]; KF_uEmmAgrAnimals[emmtype,'Piglets','01052',t,emm_eq] = 0;
      KF_uEmmAgrAnimals[emmtype,'PigsSows','01051',t,emm_eq]      = KF_uEmmAgrAnimals[emmtype,'PigsSows','01051',t,emm_eq]; KF_uEmmAgrAnimals[emmtype,'PigsSows','01052',t,emm_eq] = 0;
      KF_uEmmAgrAnimals[emmtype,'PigsFattening','01052',t,emm_eq] = KF_uEmmAgrAnimals[emmtype,'PigsFattening','01051',t,emm_eq]; KF_uEmmAgrAnimals[emmtype,'PigsFattening','01051',t,emm_eq] = 0;

      KF_NabDyrViaLager['01051','Piglets',t]       = KF_NabDyrViaLager['01051','Piglets',t]       + KF_NabDyrViaLager['01052','Piglets',t]; KF_NabDyrViaLager['01052','Piglets',t] = 0;
      KF_NabDyrViaLager['01051','PigsSows',t]      = KF_NabDyrViaLager['01051','PigsSows',t]      + KF_NabDyrViaLager['01052','PigsSows',t]; KF_NabDyrViaLager['01052','PigsSows',t] = 0;
      KF_NabDyrViaLager['01052','PigsFattening',t] = KF_NabDyrViaLager['01051','PigsFattening',t] + KF_NabDyrViaLager['01052','PigsFattening',t]; KF_NabDyrViaLager['01051','PigsFattening',t] = 0;

      KF_IndN2O_NH3['01051','Piglets',t]       = KF_IndN2O_NH3['01051','Piglets',t]       + KF_IndN2O_NH3['01052','Piglets',t]; KF_IndN2O_NH3['01052','Piglets',t] = 0;
      KF_IndN2O_NH3['01051','PigsSows',t]      = KF_IndN2O_NH3['01051','PigsSows',t]      + KF_IndN2O_NH3['01052','PigsSows',t]; KF_IndN2O_NH3['01052','PigsSows',t] = 0;
      KF_IndN2O_NH3['01052','PigsFattening',t] = KF_IndN2O_NH3['01051','PigsFattening',t] + KF_IndN2O_NH3['01052','PigsFattening',t]; KF_IndN2O_NH3['01051','PigsFattening',t] = 0;

      KF_IndN2O_NOx['01051','Piglets',t]       = KF_IndN2O_NOx['01051','Piglets',t]       + KF_IndN2O_NOx['01052','Piglets',t]; KF_IndN2O_NOx['01052','Piglets',t] = 0;
      KF_IndN2O_NOx['01051','PigsSows',t]      = KF_IndN2O_NOx['01051','PigsSows',t]      + KF_IndN2O_NOx['01052','PigsSows',t]; KF_IndN2O_NOx['01052','PigsSows',t] = 0;
      KF_IndN2O_NOx['01052','PigsFattening',t] = KF_IndN2O_NOx['01051','PigsFattening',t] + KF_IndN2O_NOx['01052','PigsFattening',t]; KF_IndN2O_NOx['01051','PigsFattening',t] = 0;

      pBotdedPerAnimal_data[emmtype,'01051','piglets',t,emm_eq] = pBotdedPerAnimal_data[emmtype,'01051','piglets',t,emm_eq] + pBotdedPerAnimal_data[emmtype,'01052','piglets',t,emm_eq]; pBotdedPerAnimal_data[emmtype,'01052','piglets',t,emm_eq] = 0;
      pBotdedPerAnimal_data[emmtype,'01051','PigsSows',t,emm_eq] = pBotdedPerAnimal_data[emmtype,'01051','PigsSows',t,emm_eq] + pBotdedPerAnimal_data[emmtype,'01052','PigsSows',t,emm_eq]; pBotdedPerAnimal_data[emmtype,'01052','PigsSows',t,emm_eq] = 0;
      pBotdedPerAnimal_data[emmtype,'01052','PigsFattening',t,emm_eq] = pBotdedPerAnimal_data[emmtype,'01051','PigsFattening',t,emm_eq] + pBotdedPerAnimal_data[emmtype,'01052','PigsFattening',t,emm_eq]; pBotdedPerAnimal_data[emmtype,'01051','PigsFattening',t,emm_eq] = 0;


      afgiftsfritagede[t,'Piglets','01051'] = afgiftsfritagede[t,'Piglets','01051'] + afgiftsfritagede[t,'Piglets','01052']; afgiftsfritagede[t,'Piglets','01052'] = 0; 
      afgiftsfritagede[t,'PigsSows','01051'] = afgiftsfritagede[t,'PigsSows','01051'] + afgiftsfritagede[t,'PigsSows','01052']; afgiftsfritagede[t,'PigsSows','01052'] = 0; 
      afgiftsfritagede[t,'PigsFattening','01052'] = afgiftsfritagede[t,'PigsFattening','01051'] + afgiftsfritagede[t,'PigsFattening','01052']; afgiftsfritagede[t,'PigsFattening','01051'] = 0; 


      KF_qAni_dis[husdyrtype,'01051','Piglets',t] = KF_qAni_dis[husdyrtype,'01051','Piglets',t] + KF_qAni_dis[husdyrtype,'01052','Piglets',t]; KF_qAni_dis[husdyrtype,'01052','Piglets',t] = 0;
      KF_qAni_dis[husdyrtype,'01051','PigsSows',t] = KF_qAni_dis[husdyrtype,'01051','PigsSows',t] + KF_qAni_dis[husdyrtype,'01052','PigsSows',t]; KF_qAni_dis[husdyrtype,'01052','PigsSows',t] = 0;
      KF_qAni_dis[husdyrtype,'01052','PigsFattening',t] = KF_qAni_dis[husdyrtype,'01051','PigsFattening',t] + KF_qAni_dis[husdyrtype,'01052','PigsFattening',t]; KF_qAni_dis[husdyrtype,'01051','PigsFattening',t] = 0;
    $ENDIF
  #-------------CEMENT--------------------#

    #På side 3 i nedenstående link står der "I KF25 forventes et sammenligneligt produktionsniveau frem mod 2035, til det anvendt i KF24. ". Derfor fastholdes produktionen i fremskrivningen på KF24-niveau.
    #https://www.kefm.dk/Media/638822915555028584/Kapitel%2023%20Fremstillings%20og%20bygge-anlgserhverv.pdf
    $PGROUP G_cem_fremskrivning_KF24 
      KF_cementprod[cementtype,t] ""
    ;

      execute_loaddc '../Data/Klimafremskrivningen/KF_cementprod.gdx' KF_cementprod = KF_cementprod.l;
      KF_cementprod[cementtype,t]$(t.val>2035) = KF_cementprod[cementtype,'2035'];
      KF_cementprod[cementtype,t] = KF_cementprod[cementtype,t]*growth_factor[t]; #Vækstkorrigerer

    #For historisk cement-data indlæses fra DST tabel VARER1
      $PGROUP G_cem_historisk_dst 
        p_grey[t] ""
        q_grey[t] ""
        p_white[t] ""
        q_white[t] ""         
      ;

      execute_loaddc '../Data/Cement/cement_DST.gdx' $LOOP G_cem_historisk_dst: {name} = {name}.l $ENDLOOP

# ----------------------------------------------------------------------------------------------------------------------
# Struktureffekter, alm. proces (kvote/ikk-kvote) + cement 
# ----------------------------------------------------------------------------------------------------------------------

	parameter emm_base[Vsh,t], produktionsomk_base[Vsh], elasticiteter[Vsh,Elasticiteterogandelsparametre];


	execute_loaddc '../Data/Alm_kvote_proces/alm_kvote_proces.gdx' emm_base      			    = emm.l;
	execute_loaddc '../Data/Alm_kvote_proces/alm_kvote_proces.gdx' produktionsomk_base    = Okonomiskenogletal.l;
	execute_loaddc '../Data/Alm_kvote_proces/alm_kvote_proces.gdx' elasticiteter      		= Elasticiteter_og_andelsparametre.l;

	#Interpolation imellem 2020 og 2030 udl.
	LOOP(t$(t.val>2020 and t.val < 2030),
	    emm_base[Vsh,t] = emm_base[Vsh,t-1] + (emm_base[Vsh,'2030']-emm_base[vsh,'2020'])/10;
	);


	Parameter uEmm_[categoryENS,eENS2GR,GSR_ag,t];
	uEmm_[categoryENS,eENS2GR,GSR_ag,t]$(KF25_energybalance_ENS_[categoryENS,eENS2GR,GSR_ag,t]) 
		= KF25_energybalance_ENS_EMM_[categoryENS,eENS2GR,GSR_ag,t]/KF25_energybalance_ENS_[categoryENS,eENS2GR,GSR_ag,t]/1000;


# ----------------------------------------------------------------------------------------------------------------------
# Export elasticity estimates 
# ----------------------------------------------------------------------------------------------------------------------
PARAMETER eXF_s[s]; 
execute_loaddc '../Data/Export_elasticity_estimates/export_elasticities_foedevarerrenamedtil10011.gdx' eXF_s = export_elasticity.l;

eXF_s['10012'] = eXF_s['10011'];
eXF_s['10013'] = eXF_s['10011'];
eXF_s['23002'] = eXF_s['23001'];


# @JHB - Reset the data time periods
set_data_periods(%cal_start%,%cal_end%);

execute_unload 'output/data.gdx';
