# =============================================================================================================================================#
# Mapping of raw-data to model level (a bit neater than having all the mappings in the 'exogenous values' stage)
# =============================================================================================================================================#

#Biodiesel/bioethanol 2019 
parameter pbiodies2019, pbioethan2019; 
pbiodies2019 = 0.35; pbioethan2019 = 0.35;

#Yderligere "databehandling" Flytter bionaturgas, så bionaturgasandelen fordelt på formål svarer til andelen når man summer over formål. Det er 51 (biongas) og 24 (natgas)
	ANV_qRE.l[purpose,'51',brch,t]$(ANV_qRE.l[purpose,'24',brch,t])     = sum(purposee, ANV_qRE.l[purposee,'51',brch,t]) * ANV_qRE.l[purpose,'24',brch,t]/sum(purposee,ANV_qRE.l[purposee,'24',brch,t]);
	ANV_vnRE.l[purpose,'51',brch,t]$(ANV_qRE.l[purpose,'24',brch,t])    = sum(purposee, ANV_vnRE.l[purposee,'51',brch,t]) * ANV_vnRE.l[purpose,'24',brch,t]/sum(purposee,ANV_vnRE.l[purposee,'24',brch,t]);

	#Skatter og afgifter fordeles ift. bye vægte. Det er næsten overflødigt, da der kun bliver betalt en my moms på lidt bionaturgas for some reason. 
	ANV_vCO2_RE.l[purpose,'51',brch,t]$(ANV_qRE.l[purpose,'24',brch,t])   = sum(purposee, ANV_vCO2_RE.l[purposee,'51',brch,t])   * ANV_qRE.l[purpose,'24',brch,t]/sum(purposee,ANV_qRE.l[purposee,'24',brch,t]);
	ANV_vSO2_RE.l[purpose,'51',brch,t]$(ANV_qRE.l[purpose,'24',brch,t])   = sum(purposee, ANV_vSO2_RE.l[purposee,'51',brch,t])   * ANV_qRE.l[purpose,'24',brch,t]/sum(purposee,ANV_qRE.l[purposee,'24',brch,t]);
	ANV_vPSO_RE.l[purpose,'51',brch,t]$(ANV_qRE.l[purpose,'24',brch,t])	  = sum(purposee, ANV_vPSO_RE.l[purposee,'51',brch,t])	 * ANV_qRE.l[purpose,'24',brch,t]/sum(purposee,ANV_qRE.l[purposee,'24',brch,t]);
	ANV_vNOx_RE.l[purpose,'51',brch,t]$(ANV_qRE.l[purpose,'24',brch,t])	  = sum(purposee, ANV_vNOx_RE.l[purposee,'51',brch,t])	 * ANV_qRE.l[purpose,'24',brch,t]/sum(purposee,ANV_qRE.l[purposee,'24',brch,t]);
	ANV_vEAFG_RE.l[purpose,'51',brch,t]$(ANV_qRE.l[purpose,'24',brch,t]) = sum(purposee, ANV_vEAFG_RE.l[purposee,'51',brch,t]) * ANV_qRE.l[purpose,'24',brch,t]/sum(purposee,ANV_qRE.l[purposee,'24',brch,t]);
	ANV_vMOMS_RE.l[purpose,'51',brch,t]$(ANV_vnRE.l[purpose,'24',brch,t])  = sum(purposee, ANV_vMOMS_RE.l[purposee,'51',brch,t]) * ANV_vnRE.l[purpose,'24',brch,t]/sum(purposee,ANV_vnRE.l[purposee,'24',brch,t]);

	#Emissioner fordeles ligeledes 
	EM_E_R.l[emm,purpose,'51',brch,t]$(ANV_qRE.l[purpose,'24',brch,t]) = sum(purposee, EM_E_R.l[emm,purposee,'51',brch,t]) * ANV_qRE.l[purpose,'24',brch,t]/sum(purposee,ANV_qRE.l[purposee,'24',brch,t]);



#Yderligere databehandling - togenes elforbrug lader til at være placeret i opvarmning
	ANV_qRE.l['process_normal','46','490011',t] = ANV_qRE.l['process_normal','46','490011',t] + ANV_qRE.l['heating','46','490011',t];
	ANV_qRE.l['heating','46','490011',t] = 0; 

	ANV_vnRE.l['process_normal','46','490011',t] = ANV_vnRE.l['process_normal','46','490011',t] + ANV_vnRE.l['heating','46','490011',t];
	ANV_vnRE.l['heating','46','490011',t] = 0; 

	ANV_qRE.l['process_normal','46','490022',t] = ANV_qRE.l['process_normal','46','490022',t] + ANV_qRE.l['heating','46','490022',t];
	ANV_qRE.l['heating','46','490022',t] = 0; 

	ANV_vnRE.l['process_normal','46','490022',t] = ANV_vnRE.l['process_normal','46','490022',t] + ANV_vnRE.l['heating','46','490022',t];
	ANV_vnRE.l['heating','46','490022',t] = 0; 


	#Skatter og afgifter 
	ANV_vCO2_RE.l['process_normal','46','490011',t] = ANV_vCO2_RE.l['process_normal','46','490011',t] + ANV_vCO2_RE.l['heating','46','490011',t];
	ANV_vCO2_RE.l['heating','46','490011',t] = 0; 

	ANV_vSO2_RE.l['process_normal','46','490011',t] = ANV_vSO2_RE.l['process_normal','46','490011',t] + ANV_vSO2_RE.l['heating','46','490011',t];
	ANV_vSO2_RE.l['heating','46','490011',t] = 0; 

	ANV_vPSO_RE.l['process_normal','46','490011',t] = ANV_vPSO_RE.l['process_normal','46','490011',t] + ANV_vPSO_RE.l['heating','46','490011',t];
	ANV_vPSO_RE.l['heating','46','490011',t] = 0; 

	ANV_vNOx_RE.l['process_normal','46','490011',t] = ANV_vNOx_RE.l['process_normal','46','490011',t] + ANV_vNOx_RE.l['heating','46','490011',t];
	ANV_vNOx_RE.l['heating','46','490011',t] = 0; 

	ANV_vEAFG_RE.l['process_normal','46','490011',t] = ANV_vEAFG_RE.l['process_normal','46','490011',t] + ANV_vEAFG_RE.l['heating','46','490011',t];
	ANV_vEAFG_RE.l['heating','46','490011',t] = 0; 

	ANV_vMOMS_RE.l['process_normal','46','490011',t] = ANV_vMOMS_RE.l['process_normal','46','490011',t] + ANV_vMOMS_RE.l['heating','46','490011',t];
	ANV_vMOMS_RE.l['heating','46','490011',t] = 0; 


	ANV_vCO2_RE.l['process_normal','46','490022',t] = ANV_vCO2_RE.l['process_normal','46','490022',t] + ANV_vCO2_RE.l['heating','46','490022',t];
	ANV_vCO2_RE.l['heating','46','490022',t] = 0; 

	ANV_vSO2_RE.l['process_normal','46','490022',t] = ANV_vSO2_RE.l['process_normal','46','490022',t] + ANV_vSO2_RE.l['heating','46','490022',t];
	ANV_vSO2_RE.l['heating','46','490022',t] = 0; 

	ANV_vPSO_RE.l['process_normal','46','490022',t] = ANV_vPSO_RE.l['process_normal','46','490022',t] + ANV_vPSO_RE.l['heating','46','490022',t];
	ANV_vPSO_RE.l['heating','46','490022',t] = 0; 

	ANV_vNOx_RE.l['process_normal','46','490022',t] = ANV_vNOx_RE.l['process_normal','46','490022',t] + ANV_vNOx_RE.l['heating','46','490022',t];
	ANV_vNOx_RE.l['heating','46','490022',t] = 0; 

	ANV_vEAFG_RE.l['process_normal','46','490022',t] = ANV_vEAFG_RE.l['process_normal','46','490022',t] + ANV_vEAFG_RE.l['heating','46','490022',t];
	ANV_vEAFG_RE.l['heating','46','490022',t] = 0; 

	ANV_vMOMS_RE.l['process_normal','46','490022',t] = ANV_vMOMS_RE.l['process_normal','46','490022',t] + ANV_vMOMS_RE.l['heating','46','490022',t];
	ANV_vMOMS_RE.l['heating','46','490022',t] = 0; 

	#Emissioner - ingen el.


#Det lader til at være en fejl at forbrændingen af affald ikke er kvoteomfattet. Så vidt vides er det kun 'ægte' overskudsvarme, der er kvotefritaget - og det er ikke det, der laves på de danske forbrændingsanlæg 
	ANV_qRE.l['in_ETS','29','383903',t] = ANV_qRE.l['in_ETS','29','383903',t] + ANV_qRE.l['process_special','29','383903',t];
	ANV_qRE.l['process_special','29','383903',t] = 0; 

	ANV_vnRE.l['in_ETS','29','383903',t] = ANV_vnRE.l['in_ETS','29','383903',t] + ANV_vnRE.l['process_special','29','383903',t];
	ANV_vnRE.l['process_special','29','383903',t] = 0; 


	#Skatter og afgifter 
	ANV_vCO2_RE.l['in_ETS','29','383903',t] = ANV_vCO2_RE.l['in_ETS','29','383903',t] + ANV_vCO2_RE.l['process_special','29','383903',t];
	ANV_vCO2_RE.l['process_special','29','383903',t] = 0; 

	ANV_vSO2_RE.l['in_ETS','29','383903',t] = ANV_vSO2_RE.l['in_ETS','29','383903',t] + ANV_vSO2_RE.l['process_special','29','383903',t];
	ANV_vSO2_RE.l['process_special','29','383903',t] = 0;

	ANV_vPSO_RE.l['in_ETS','29','383903',t] = ANV_vPSO_RE.l['in_ETS','29','383903',t] + ANV_vPSO_RE.l['process_special','29','383903',t];
	ANV_vPSO_RE.l['process_special','29','383903',t] = 0;

	ANV_vNOx_RE.l['in_ETS','29','383903',t] = ANV_vNOx_RE.l['in_ETS','29','383903',t] + ANV_vNOx_RE.l['process_special','29','383903',t];
	ANV_vNOx_RE.l['process_special','29','383903',t] = 0;

	ANV_vEAFG_RE.l['in_ETS','29','383903',t] = ANV_vEAFG_RE.l['in_ETS','29','383903',t] + ANV_vEAFG_RE.l['process_special','29','383903',t];
	ANV_vEAFG_RE.l['process_special','29','383903',t] = 0; 

	ANV_vMOMS_RE.l['in_ETS','29','383903',t] = ANV_vMOMS_RE.l['in_ETS','29','383903',t] + ANV_vMOMS_RE.l['process_special','29','383903',t];
	ANV_vMOMS_RE.l['process_special','29','383903',t] = 0; 

	#Emissioner 
	EM_E_R.l[emm,'in_ETS','29','383903',t] = EM_E_R.l[emm,'in_ETS','29','383903',t] + EM_E_R.l[emm,'process_special','29','383903',t];
	EM_E_R.l[emm,'process_special','29','383903',t] = 0;


	ANV_qRE.l['in_ETS','30','383903',t] = ANV_qRE.l['in_ETS','30','383903',t] + ANV_qRE.l['process_special','30','383903',t];
	ANV_qRE.l['process_special','30','383903',t] = 0; 

	ANV_vnRE.l['in_ETS','30','383903',t] = ANV_vnRE.l['in_ETS','30','383903',t] + ANV_vnRE.l['process_special','30','383903',t];
	ANV_vnRE.l['process_special','30','383903',t] = 0; 


	#Skatter og afgifter 
	ANV_vCO2_RE.l['in_ETS','30','383903',t] = ANV_vCO2_RE.l['in_ETS','30','383903',t] + ANV_vCO2_RE.l['process_special','30','383903',t];
	ANV_vCO2_RE.l['process_special','30','383903',t] = 0; 

	ANV_vSO2_RE.l['in_ETS','30','383903',t] = ANV_vSO2_RE.l['in_ETS','30','383903',t] + ANV_vSO2_RE.l['process_special','30','383903',t];
	ANV_vSO2_RE.l['process_special','30','383903',t] = 0;

	ANV_vPSO_RE.l['in_ETS','30','383903',t] = ANV_vPSO_RE.l['in_ETS','30','383903',t] + ANV_vPSO_RE.l['process_special','30','383903',t];
	ANV_vPSO_RE.l['process_special','30','383903',t] = 0;

	ANV_vNOx_RE.l['in_ETS','30','383903',t] = ANV_vNOx_RE.l['in_ETS','30','383903',t] + ANV_vNOx_RE.l['process_special','30','383903',t];
	ANV_vNOx_RE.l['process_special','30','383903',t] = 0; 

	ANV_vEAFG_RE.l['in_ETS','30','383903',t] = ANV_vEAFG_RE.l['in_ETS','30','383903',t] + ANV_vEAFG_RE.l['process_special','30','383903',t];
	ANV_vEAFG_RE.l['process_special','30','383903',t] = 0; 

	ANV_vMOMS_RE.l['in_ETS','30','383903',t] = ANV_vMOMS_RE.l['in_ETS','30','383903',t] + ANV_vMOMS_RE.l['process_special','30','383903',t];
	ANV_vMOMS_RE.l['process_special','30','383903',t] = 0; 


	#Emissioner 
	EM_E_R.l[emm,'in_ETS','30','383903',t] = EM_E_R.l[emm,'in_ETS','30','383903',t] + EM_E_R.l[emm,'process_special','30','383903',t];
	EM_E_R.l[emm,'process_special','30','383903',t] = 0;

#Raffinaderiernes forbrug af råolie er ved en fejl placeret i opvarmning i 2019 
	ANV_qRE.l['process_special','1','190000','2019'] = ANV_qRE.l['heating','1','190000','2019']; ANV_qRE.l['heating','1','190000','2019'] = 0;
	ANV_vnRE.l['process_special','1','190000','2019'] = ANV_vnRE.l['heating','1','190000','2019']; ANV_vnRE.l['heating','1','190000','2019'] = 0;
	#Der er ikke nogen produktskatter, eller subsidier på råolien


#Fiskeriets forbrug på kuttere er fejlagtigt placeret i opvarmningskategorien. Det flyttes derfor
	ANV_qRE.l['process_special',energy48,'030000',t] = ANV_qRE.l['process_special',energy48,'030000',t] + ANV_qRE.l['heating',energy48,'030000',t];
	ANV_qRE.l['heating',energy48,'030000',t] = 0; 

	ANV_vnRE.l['process_special',energy48,'030000',t] = ANV_vnRE.l['process_special',energy48,'030000',t] + ANV_vnRE.l['heating',energy48,'030000',t];
	ANV_vnRE.l['heating',energy48,'030000',t] = 0; 

	#Skatter og afgifter 
	ANV_vCO2_RE.l['process_special',energy48,'030000',t] = ANV_vCO2_RE.l['process_special',energy48,'030000',t] + ANV_vCO2_RE.l['heating',energy48,'030000',t];
	ANV_vCO2_RE.l['heating',energy48,'030000',t] = 0; 

	ANV_vSO2_RE.l['process_special',energy48,'030000',t] = ANV_vSO2_RE.l['process_special',energy48,'030000',t] + ANV_vSO2_RE.l['heating',energy48,'030000',t];
	ANV_vSO2_RE.l['heating',energy48,'030000',t] = 0; 

	ANV_vPSO_RE.l['process_special',energy48,'030000',t] = ANV_vPSO_RE.l['process_special',energy48,'030000',t] + ANV_vPSO_RE.l['heating',energy48,'030000',t];
	ANV_vPSO_RE.l['heating',energy48,'030000',t] = 0; 

	ANV_vNOx_RE.l['process_special',energy48,'030000',t] = ANV_vNOx_RE.l['process_special',energy48,'030000',t] + ANV_vNOx_RE.l['heating',energy48,'030000',t];
	ANV_vNOx_RE.l['heating',energy48,'030000',t] = 0; 

	ANV_vEAFG_RE.l['process_special',energy48,'030000',t] = ANV_vEAFG_RE.l['process_special',energy48,'030000',t] + ANV_vEAFG_RE.l['heating',energy48,'030000',t];
	ANV_vEAFG_RE.l['heating',energy48,'030000',t] = 0; 

	ANV_vMOMS_RE.l['process_special',energy48,'030000',t] = ANV_vMOMS_RE.l['process_special',energy48,'030000',t] + ANV_vMOMS_RE.l['heating',energy48,'030000',t];
	ANV_vMOMS_RE.l['heating',energy48,'030000',t] = 0; 

	ANV_vDAV_RE.l['process_special',energy48,'030000',t] = ANV_vDAV_RE.l['process_special',energy48,'030000',t] + ANV_vDAV_RE.l['heating',energy48,'030000',t];
	ANV_vDAV_RE.l['heating',energy48,'030000',t] = 0; 

	ANV_vEAV_RE.l['process_special',energy48,'030000',t] = ANV_vEAV_RE.l['process_special',energy48,'030000',t] + ANV_vEAV_RE.l['heating',energy48,'030000',t];
	ANV_vEAV_RE.l['heating',energy48,'030000',t] = 0; 

	ANV_vCAV_RE.l['process_special',energy48,'030000',t] = ANV_vCAV_RE.l['process_special',energy48,'030000',t] + ANV_vCAV_RE.l['heating',energy48,'030000',t];
	ANV_vCAV_RE.l['heating',energy48,'030000',t] = 0; 


	#Emissioner 
	EM_E_R.l[emm,'process_special',energy48,'030000',t] = EM_E_R.l[emm,'process_special',energy48,'030000',t] + EM_E_R.l[emm,'heating',energy48,'030000',t];
	EM_E_R.l[emm,'heating',energy48,'030000',t] = 0;

	#Rettelse af CO2bio/CO2ubio emissioner fra bioCNG og CNG hos forbrugerne - problemet vil også være hos virksomhederne, men bliver sandsynligvis maskeret.
	#DST er underrettet mhbp. at få rettet i næste dataleverance. 
	     #Problemet er kun i 2019-leverance
		 EM_E_C.l['CO2ubio','transport','49','2019'] = ANV_qCE.l['transport','49','2019'] * 56/correction_factor_joule;
		 EM_E_C.l['CO2bio','transport','50','2019']  = ANV_qCE.l['transport','50','2019'] * 56/correction_factor_joule;

		 #Tager fra emissionerne forbundet med opvarmning ved ledningsgas
		 EM_E_C.l['CO2ubio','heating','24','2019'] = EM_E_C.l['CO2ubio','heating','24','2019'] - EM_E_C.l['CO2ubio','transport','49','2019'];
		 EM_E_C.l['CO2bio','heating','24','2019']  = EM_E_C.l['CO2bio','heating','24','2019']  - EM_E_C.l['CO2bio','transport','50','2019'];



	#Values
	EN_vnCE[purpose,energy19,t]   = sum(energy48$(energy19_2_energy48(energy19,energy48)), ANV_vnCE.l[purpose,energy48,t])/correction_factor_values;
	EN_vnLE[purpose,energy19,t]   = sum(energy48$(energy19_2_energy48(energy19,energy48)), ANV_vnLE.l[purpose,energy48,t])/correction_factor_values;
		

	#Engros- og detailavancer 
	EN_vEAV_RE[purpose,energy19,r,t]         = sum(energy48$(energy19_2_energy48(energy19,energy48)), sum(ns105$(map1052five(r,ns105)), sum(nsGR$(nsGR2ns105(ns105,nsGR)), sum(brch$(brch2nsGR(brch,nsGR)), ANV_vEAV_RE.l[purpose,energy48,Brch,t]))))/correction_factor_values;
	EN_vDAV_RE[purpose,energy19,r,t]         = sum(energy48$(energy19_2_energy48(energy19,energy48)), sum(ns105$(map1052five(r,ns105)), sum(nsGR$(nsGR2ns105(ns105,nsGR)), sum(brch$(brch2nsGR(brch,nsGR)), ANV_vDAV_RE.l[purpose,energy48,Brch,t]))))/correction_factor_values;
	EN_vCAV_RE[purpose,energy19,r,t] 		 = sum(energy48$(energy19_2_energy48(energy19,energy48)), sum(ns105$(map1052five(r,ns105)), sum(nsGR$(nsGR2ns105(ns105,nsGR)), sum(brch$(brch2nsGR(brch,nsGR)), ANV_vCAV_RE.l[purpose,energy48,Brch,t]))))/correction_factor_values;		

	EN_vEAV_CE[purpose,energy19,t] = sum(energy48$(energy19_2_energy48(energy19,energy48)), ANV_vEAV_CE.l[purpose,energy48,t])/correction_factor_values;
	EN_vDAV_CE[purpose,energy19,t] = sum(energy48$(energy19_2_energy48(energy19,energy48)), ANV_vDAV_CE.l[purpose,energy48,t])/correction_factor_values;
	EN_vCAV_CE[purpose,energy19,t] = sum(energy48$(energy19_2_energy48(energy19,energy48)), ANV_vCAV_CE.l[purpose,energy48,t])/correction_factor_values;

									  


EN_vnXE[purpose,energy19,t]   = sum(energy48$(energy19_2_energy48(energy19,energy48)), ANV_vnXE.l[purpose,energy48,t])/correction_factor_values;
EN_vE_y[energy19,s,t]         = sum(energy48$(energy19_2_energy48(energy19,energy48)), sum(ns105$(map1052five(s,ns105)), sum(nsGR$(nsGR2ns105(ns105,nsGR)), sum(brch$(brch2nsGR(brch,nsGR)), TIL_vE_y.l[energy48,brch,t]))))/correction_factor_values;

EN_vE_y[energy19,sSlagteri,t]   = sYS[sSlagteri]*EN_vE_y[energy19,'10011',t];
EN_vE_y[energy19,sMineralogi,t] = sYS_cement[sMineralogi]*EN_vE_y[energy19,'23001',t];


EN_vE_m[energy19,t]           = sum(energy48$(energy19_2_energy48(energy19,energy48)), TIL_vE_m.l[energy48,t])/correction_factor_values;
EN_vCUS[energy19,t]           = sum(energy48$(energy19_2_energy48(energy19,energy48)), TIL_vCUS.l[energy48,t])/correction_factor_values;

#Quantities
EN_qCE[purpose,energy19,t]    = sum(energy48$(energy19_2_energy48(energy19,energy48)), ANV_qCE.l[purpose,energy48,t])/correction_factor_joule;
EN_qLE[purpose,energy19,t]    = sum(energy48$(energy19_2_energy48(energy19,energy48)), ANV_qLE.l[purpose,energy48,t])/correction_factor_joule;
EN_qRE[purpose,energy19,r,t]  = sum(energy48$(energy19_2_energy48(energy19,energy48)), sum(ns105$(map1052five(r,ns105)), sum(nsGR$(nsGR2ns105(ns105,nsGR)), sum(brch$(brch2nsGR(brch,nsGR)), ANV_qRE.l[purpose,energy48,brch,t]))))/correction_factor_joule; 


EN_vnRE[purpose,energy19,r,t] = sum(energy48$(energy19_2_energy48(energy19,energy48)), sum(ns105$(map1052five(r,ns105)), sum(nsGR$(nsGR2ns105(ns105,nsGR)), sum(brch$(brch2nsGR(brch,nsGR)), ANV_vnRE.l[purpose,energy48,brch,t]))))/correction_factor_values; 

EN_vnRE['in_ETS',energy19fos,'19000',t] = sum(purpose_xt,EN_vnRE[purpose_xt,energy19fos,'19000',t]);
EN_vnRE[purpose_xt,energy19fos,'19000',t]$(not sameas[purpose_xt,'in_ETS']) = 0;


EN_qRE['in_ETS',energy19fos,'19000',t] = sum(purpose_xt,EN_qRE[purpose_xt,energy19fos,'19000',t]);
EN_qRE[purpose_xt,energy19fos,'19000',t]$(not sameas[purpose_xt,'in_ETS']) = 0;
 
EN_qXE[purpose,energy19,t]    = sum(energy48$(energy19_2_energy48(energy19,energy48)), ANV_qXE.l[purpose,energy48,t])/correction_factor_joule;
EN_qE_y[energy19,s,t]         = sum(energy48$(energy19_2_energy48(energy19,energy48)), sum(ns105$(map1052five(s,ns105)), sum(nsGR$(nsGR2ns105(ns105,nsGR)), sum(brch$(brch2nsGR(brch,nsGR)), TIL_qE_y.l[energy48,brch,t]))))/correction_factor_joule;

EN_qE_y[energy19,sSlagteri,t] = sYS[sSlagteri]*EN_qE_y[energy19,'10011',t];
EN_qE_y[energy19,sMineralogi,t] = sYS_cement[sMineralogi]*EN_qE_y[energy19,'23001',t];


EN_qE_m[energy19,t]           = sum(energy48$(energy19_2_energy48(energy19,energy48)), TIL_qE_m.l[energy48,t])/correction_factor_joule;
EN_qTL[purpose,energy19,t]    = sum(energy48$(energy19_2_energy48(energy19,energy48)), ANV_qTL.l[purpose,energy48,t])/correction_factor_joule;
EN_qRENEWABLE[energy19,types_renewable,t]     = sum(energy48$(energy19_2_energy48(energy19,energy48)), TIL_qRENEWABLE.l[energy48,types_renewable,t])/correction_factor_joule;

#Electricity hack
#Flytter forbruget af el i eldistributionsbrancen fra process_normal til process_special 
EN_qRE['process_special', 'El from y and m', '35012', t] = EN_qRE['process_normal', 'El from y and m', '35012', t];
EN_qRE['process_normal', 'El from y and m', '35012', t] = 0; 

EN_vnRE['process_special', 'El from y and m', '35012', t] = EN_vnRE['process_normal', 'El from y and m', '35012', t];
EN_vnRE['process_normal', 'El from y and m', '35012', t] = 0; 

#Øger forbruget af el til distribution i 35012 svarende til den importerede mængde, så TIL/ANV stemmer i 2019.
EN_qRE['process_special', 'El from y and m', '35012', '2019'] = EN_qRE['process_special', 'El from y and m', '35012', '2019'] + EN_qE_m['El from y and m','2019']; 
EN_vnRE['process_special', 'El from y and m', '35012', '2019'] = EN_vnRE['process_special', 'El from y and m', '35012', '2019'] + EN_vE_m['El from y and m','2019'];
#Øger produktionen af el til distribution i 35012 svarende til den importerede mængde, så TIL/ANV stemmer i 2019. 
EN_qE_y['electricity','35012','2019'] = EN_qE_y['electricity','35012','2019'] + EN_qE_m['El from y and m','2019']; 
EN_vE_y['electricity', '35012', '2019'] = EN_vE_y['electricity', '35012', '2019'] + EN_vE_m['El from y and m','2019']; 

#Taxes
EN_vCO2_CE[purpose,energy19,t]    = sum(energy48$(energy19_2_energy48(energy19,energy48)), ANV_vCO2_CE.l[purpose,energy48,t])/correction_factor_values;
EN_vCO2_RE[purpose,energy19,r,t]  = sum(energy48$(energy19_2_energy48(energy19,energy48)), sum(ns105$(map1052five(r,ns105)), sum(nsGR$(nsGR2ns105(ns105,nsGR)), sum(brch$(brch2nsGR(brch,nsGR)), ANV_vCO2_RE.l[purpose,energy48,brch,t]))))/correction_factor_values;



EN_vEAFG_CE[purpose,energy19,t]   = sum(energy48$(energy19_2_energy48(energy19,energy48)), ANV_vEAFG_CE.l[purpose,energy48,t])/correction_factor_values;
EN_vEAFG_RE[purpose,energy19,r,t] = sum(energy48$(energy19_2_energy48(energy19,energy48)), sum(ns105$(map1052five(r,ns105)), sum(nsGR$(nsGR2ns105(ns105,nsGR)), sum(brch$(brch2nsGR(brch,nsGR)), ANV_vEAFG_RE.l[purpose,energy48,brch,t]))))/correction_factor_values;
EN_vEAFG_XE[purpose,energy19,t]   = sum(energy48$(energy19_2_energy48(energy19,energy48)), ANV_vEAFG_XE.l[purpose,energy48,t])/correction_factor_values;


EN_vSO2_CE[purpose,energy19,t]    = sum(energy48$(energy19_2_energy48(energy19,energy48)), ANV_vSO2_CE.l[purpose,energy48,t])/correction_factor_values;
EN_vSO2_RE[purpose,energy19,r,t]  = sum(energy48$(energy19_2_energy48(energy19,energy48)), sum(ns105$(map1052five(r,ns105)), sum(nsGR$(nsGR2ns105(ns105,nsGR)), sum(brch$(brch2nsGR(brch,nsGR)), ANV_vSO2_RE.l[purpose,energy48,brch,t]))))/correction_factor_values;



EN_vNOx_CE[purpose,energy19,t] 	  = sum(energy48$(energy19_2_energy48(energy19,energy48)), ANV_vNOx_CE.l[purpose,energy48,t])/correction_factor_values;
EN_vNOx_RE[purpose,energy19,r,t]  = sum(energy48$(energy19_2_energy48(energy19,energy48)), sum(ns105$(map1052five(r,ns105)), sum(nsGR$(nsGR2ns105(ns105,nsGR)), sum(brch$(brch2nsGR(brch,nsGR)), ANV_vNOx_RE.l[purpose,energy48,Brch,t]))))/correction_factor_values;


EN_vPSO_CE[purpose,energy19,t] 	  = sum(energy48$(energy19_2_energy48(energy19,energy48)), ANV_vPSO_CE.l[purpose,energy48,t])/correction_factor_values;
EN_vPSO_RE[purpose,energy19,r,t]  = sum(energy48$(energy19_2_energy48(energy19,energy48)), sum(ns105$(map1052five(r,ns105)), sum(nsGR$(nsGR2ns105(ns105,nsGR)), sum(brch$(brch2nsGR(brch,nsGR)), ANV_vPSO_RE.l[purpose,energy48,Brch,t]))))/correction_factor_values;
EN_vPSO_XE[purpose,energy19,t] 	  = sum(energy48$(energy19_2_energy48(energy19,energy48)), ANV_vPSO_XE.l[purpose,energy48,t])/correction_factor_values;



EN_vMOMS_CE[purpose,energy19,t]   = sum(energy48$(energy19_2_energy48(energy19,energy48)), ANV_vMOMS_CE.l[purpose,energy48,t])/correction_factor_values;
EN_vMOMS_RE[purpose,energy19,r,t] = sum(energy48$(energy19_2_energy48(energy19,energy48)), sum(ns105$(map1052five(r,ns105)), sum(nsGR$(nsGR2ns105(ns105,nsGR)), sum(brch$(brch2nsGR(brch,nsGR)), ANV_vMOMS_RE.l[purpose,energy48,brch,t]))))/correction_factor_values;



EN_vCO2_RE['in_ETS',energy19fos,'19000',t] = sum(purpose_xt,EN_vCO2_RE[purpose_xt,energy19fos,'19000',t]);
EN_vEAFG_RE['in_ETS',energy19fos,'19000',t] = sum(purpose_xt,EN_vEAFG_RE[purpose_xt,energy19fos,'19000',t]);
EN_vSO2_RE['in_ETS',energy19fos,'19000',t] = sum(purpose_xt,EN_vSO2_RE[purpose_xt,energy19fos,'19000',t]);
EN_vMOMS_RE['in_ETS',energy19fos,'19000',t] = sum(purpose_xt,EN_vMOMS_RE[purpose_xt,energy19fos,'19000',t]);
EN_vPSO_RE['in_ETS',energy19fos,'19000',t] 	 = sum(purpose_xt,EN_vPSO_RE[purpose_xt,energy19fos,'19000',t]);
EN_vNOx_RE['in_ETS',energy19fos,'19000',t] 	 = sum(purpose_xt,EN_vNOx_RE[purpose_xt,energy19fos,'19000',t]);
EN_vDAV_RE['in_ETS',energy19fos,'19000',t] = sum(purpose_xt,EN_vDAV_RE[purpose_xt,energy19fos,'19000',t]);
EN_vEAV_RE['in_ETS',energy19fos,'19000',t] = sum(purpose_xt,EN_vEAV_RE[purpose_xt,energy19fos,'19000',t]);
EN_vCAV_RE['in_ETS',energy19fos,'19000',t] = sum(purpose_xt,EN_vCAV_RE[purpose_xt,energy19fos,'19000',t]);

EN_vCO2_RE[purpose_xt,energy19fos,'19000',t]$(not sameas[purpose_xt,'in_ETS']) = 0;
EN_vEAFG_RE[purpose_xt,energy19fos,'19000',t]$(not sameas[purpose_xt,'in_ETS']) = 0;
EN_vSO2_RE[purpose_xt,energy19fos,'19000',t]$(not sameas[purpose_xt,'in_ETS'])  = 0;
EN_vMOMS_RE[purpose_xt,energy19fos,'19000',t]$(not sameas[purpose_xt,'in_ETS']) = 0;
EN_vPSO_RE[purpose_xt,energy19fos,'19000',t]$(not sameas[purpose_xt,'in_ETS'])   = 0;
EN_vNOx_RE[purpose_xt,energy19fos,'19000',t]$(not sameas[purpose_xt,'in_ETS'])  = 0;
EN_vDAV_RE[purpose_xt,energy19fos,'19000',t]$(not sameas[purpose_xt,'in_ETS']) = 0;
EN_vEAV_RE[purpose_xt,energy19fos,'19000',t]$(not sameas[purpose_xt,'in_ETS']) = 0;
EN_vCAV_RE[purpose_xt,energy19fos,'19000',t]$(not sameas[purpose_xt,'in_ETS']) = 0;


#Gartneri-korrektion 
	#Når man skeler til regnskabsstatistikkens udlægning af energiforbrug kommer man til konklusionen at al fjernevarme og kul forbruges af gartnerierne. Derfor flyttes det her
	EN_qRE[purpose,'District heat','01020',t] = sum(agri_sectors,EN_qRE[purpose,'District heat',agri_sectors,t]);
	EN_qRE[purpose,'District heat',agri_sectors,t]$(not sameas[agri_sectors,'01020']) = 0;
	
	EN_vnRE[purpose,'District heat','01020',t] = sum(agri_sectors,EN_vnRE[purpose,'District heat',agri_sectors,t]);
	EN_vnRE[purpose,'District heat',agri_sectors,t]$(not sameas[agri_sectors,'01020']) = 0;

set tGartkorr[t]/2017*2019/;

	$FOR {item} in ['EN_qRE','EN_vnRE','EN_vEAFG_RE','EN_vCO2_RE','EN_vSO2_RE','EN_vPSO_RE','EN_vNOx_RE','EN_vMOMS_RE','EN_vEAV_RE','EN_vDAV_RE','EN_vCAV_RE']:
		{item}[purpose,'District heat','01020',t] = sum(agri_sectors,{item}[purpose,'District heat',agri_sectors,t]);
		{item}[purpose,'District heat',agri_sectors,t]$(not sameas[agri_sectors,'01020']) = 0;

		{item}['process_normal','District heat','01020',t] = sum(purpose, {item}[purpose,'District heat','01020',t]);
		{item}[purpose,'District heat','01020',t]$(not sameas[purpose,'process_normal']) = 0;

		{item}[purpose,'Coal and coke','01020',t] = sum(agri_sectors,{item}[purpose,'Coal and coke',agri_sectors,t]);
		{item}[purpose,'Coal and coke',agri_sectors,t]$(not sameas[agri_sectors,'01020']) = 0;

		{item}['process_normal','Natural gas incl. biongas','01020',tGartkorr] = {item}['process_special','Natural gas incl. biongas','01020',tGartkorr] + 2/3*{item}['in_ETS','Natural gas incl. biongas','01020',tGartkorr];
		{item}['in_ETS','Natural gas incl. biongas','01020',tGartkorr] = 1/3*{item}['in_ETS','Natural gas incl. biongas','01020',tGartkorr];
		{item}['heating','Natural gas incl. biongas','01020',tGartkorr] = 0;
		{item}['process_special','Natural gas incl. biongas','01020',tGartkorr] = 0;

		# {item}['intern_trans',energy19,'01020',t] = {item}['transport',energy19,'01020',t];
		# {item}['transport',energy19,'01020',t] = 0;			

		# Flytter lanbrugets transport til intern_trans:
		{item}['intern_trans',energy19,agri_sectors,t] = {item}['transport',energy19,agri_sectors,t];
		{item}['transport',energy19,agri_sectors,t] = 0;	

		# Maskinstation:
		{item}['intern_trans',energy19,'01080',t] = {item}['transport',energy19,'01080',t];
		{item}['transport',energy19,'01080',t] = 0;	

		# Skovbrug:
		{item}['intern_trans',energy19,'02000',t] = {item}['transport',energy19,'02000',t];
		{item}['transport',energy19,'02000',t] = 0;		
	$ENDFOR


	#I KF placeres fjernvarmeforbruget som proces og ikke heating. Vi flytter det derfor 
	$FOR {item} in ['EN_qRE','EN_vnRE','EN_vEAFG_RE','EN_vCO2_RE','EN_vSO2_RE','EN_vPSO_RE','EN_vNOx_RE','EN_vMOMS_RE','EN_vEAV_RE','EN_vDAV_RE','EN_vCAV_RE']:
		{item}['process_normal','district heat','01020',t] = {item}['process_special','district heat','01020',t] + {item}['heating','district heat','01020',t];
		{item}['process_special','district heat','01020',t] = 0;
		{item}['heating','district heat','01020',t] = 0;
	$ENDFOR

	#Det virker som om al landbrugsdiesel er placeret i opvarmning (udledningerne bliver klaret længere nede)
	PARAMETER savedatdiesel19[s], savedatdiesel19emm[emm,s];

	$FOR {item} in ['EN_qRE','EN_vnRE','EN_vEAFG_RE','EN_vCO2_RE','EN_vSO2_RE','EN_vPSO_RE','EN_vNOx_RE','EN_vMOMS_RE','EN_vEAV_RE','EN_vDAV_RE','EN_vCAV_RE']:
		savedatdiesel19[agri_sectors] = {item}['heating','diesel for transport',agri_sectors,'2019']; 
		savedatdiesel19['01080']      = {item}['heating','diesel for transport','01080','2019'];
		savedatdiesel19['02000']      = {item}['heating','diesel for transport','02000','2019'];

		{item}['heating','diesel for transport',agri_sectors,'2019']$(not sameas[agri_sectors,'01070'])   = {item}['intern_trans','diesel for transport',agri_sectors,'2019'];
		{item}['heating','diesel for transport','01080','2019']        = {item}['intern_trans','diesel for transport','01080','2019'];
		{item}['heating','diesel for transport','02000','2019']        = {item}['intern_trans','diesel for transport','02000','2019'];

		{item}['intern_trans','diesel for transport',agri_sectors,'2019']$(not sameas[agri_sectors,'01070'])   = savedatdiesel19[agri_sectors];
		{item}['intern_trans','diesel for transport','01080','2019']        = savedatdiesel19['01080'];
		{item}['intern_trans','diesel for transport','02000','2019']        = savedatdiesel19['02000']; 
	$ENDFOR

	#Mere landbrugskorrektion. Der korrigeres ift. hvordan det ser ud i de KF tal vi har fået...

	$FOR {item} in ['EN_qRE','EN_vnRE','EN_vEAFG_RE','EN_vCO2_RE','EN_vSO2_RE','EN_vPSO_RE','EN_vNOx_RE','EN_vMOMS_RE','EN_vEAV_RE','EN_vDAV_RE','EN_vCAV_RE']:
		{item}['intern_trans','diesel for transport',agri_sectors,'2019'] = {item}['intern_trans','diesel for transport',agri_sectors,'2019'] + 0.9 *{item}['heating','diesel for transport',agri_sectors,'2019']; 
		{item}['heating','diesel for transport',agri_sectors,'2019']   = 0.1 *{item}['heating','diesel for transport',agri_sectors,'2019'];

		{item}['intern_trans','diesel for transport',s,'2019']$(sameas(s,'01080') or sameas(s,'02000')) = {item}['intern_trans','diesel for transport',s,'2019'] + 0.9 *{item}['heating','diesel for transport',s,'2019']; 
		{item}['heating','diesel for transport',s,'2019']$(sameas(s,'01080') or sameas(s,'02000'))   = 0.1 *{item}['heating','diesel for transport',s,'2019'];

		{item}['process_normal','electricity',agri_sectors,'2019']     = {item}['process_normal','electricity',agri_sectors,'2019'] + 0.995 *{item}['heating','electricity',agri_sectors,'2019']; 
		{item}['heating','electricity',agri_sectors,'2019']            = 0.005 *{item}['heating','electricity',agri_sectors,'2019'];


		#Correcting straw. In ENS-data there is straw for non-heating purposes (large quantities in fact). Wer therefore move this energy to process_normal (not for horticulture though to keep mappings simple). In JORD9 horticulture use hardly none, if any, straw for any pyrpose
		{item}['heating','straw for energy purposes',agri_sectors,'2019']$(not sameas[agri_sectors,'01020'])		= {item}['heating','straw for energy purposes',agri_sectors,'2019'] + 
																														{item}['heating','straw for energy purposes','01020','2019'] *
																														EN_qRE['heating','straw for energy purposes',agri_sectors,'2019'] / 
																														sum(agri_sectorss$(not sameas(agri_sectorss,'01020')), EN_qRE['heating','straw for energy purposes',agri_sectorss,'2019']);
		{item}['process_normal','straw for energy purposes',agri_sectors,'2019']$(not sameas[agri_sectors,'01020']) = 0.9 * {item}['heating','straw for energy purposes',agri_sectors,'2019'];
		{item}['heating','straw for energy purposes',agri_sectors,'2019']$(not sameas[agri_sectors,'01020'])        = 0.1 * {item}['heating','straw for energy purposes',agri_sectors,'2019'];
		{item}['heating','straw for energy purposes','01020','2019']        										= 0;


	$ENDFOR

	#Korrektion af indenrigsflyvning. 
	$FOR {item} in ['EN_qRE','EN_vnRE','EN_vEAFG_RE','EN_vCO2_RE','EN_vSO2_RE','EN_vPSO_RE','EN_vNOx_RE','EN_vMOMS_RE','EN_vEAV_RE','EN_vDAV_RE','EN_vCAV_RE']:
		#Flytter jet-fuel til ETS 

		{item}['in_ETS','Jet petroleum','51001',t]    = {item}['Transport','Jet petroleum','51001',t];
		{item}['Transport','Jet petroleum','51001',t] = 0;


	$ENDFOR 
	#£HACKFIREWOOD 
	#For brænde og træflis laves en kategori for brænde u. pris
	EN_qCE['process_special','firewood and woodchips',t]$(EN_qE_m['firewood and woodchips',t])
		=EN_qCE['heating','firewood and woodchips',t] - EN_vnCE['heating','firewood and woodchips',t]/(EN_vE_m['firewood and woodchips',t]/EN_qE_m['firewood and woodchips',t]); 
	
	EN_qCE['heating','firewood and woodchips',t]$(EN_qE_m['firewood and woodchips',t])
		= EN_qCE['heating','firewood and woodchips',t] - EN_qCE['process_special','firewood and woodchips',t];


#Mineralogi- og slagterikorrektion

PARAMETER share_ETS[energy19];
#Tal taget fra KF25_energybalance_ENS_ for cement
share_ETS['Oil products']           = 0.0492283817337946;
share_ETS['Coal and coke']          = 3.76709100604904;
share_ETS['Waste']                  = 1.93657185012545;
share_ETS['Wood pellets']           = 0.191579547158169;
share_ETS['Firewood and woodchips'] = 1.25838178510563;
share_ETS['Diesel for transport']   = 0.128360230353086;

share_ETS[energy19]$EN_qRE['in_ETS',energy19,'23001','2019'] = share_ETS[energy19]/EN_qRE['in_ETS',energy19,'23001','2019'];


$FOR {item} in ['EN_vEAV_RE','EN_vDAV_RE','EN_vCAV_RE','EN_vnRE','EN_qRE','EN_vCO2_RE','EN_vEAFG_RE','EN_vSO2_RE','EN_vNOX_RE','EN_vPSO_RE','EN_vMOMS_RE']:
	{item}[purpose,energy19,sSlagteri,t] = {item}[purpose,energy19,'10011',t] * sYS[sSlagteri];
	$IF %smaagrisesplit%:
	{item}[purpose,energy19,sSvin,t] =     sum(sSvin_a, {item}[purpose,energy19,sSvin_a,t]) * sYS_svin[ssvin];
	$ENDIF
	{item}[purpose,energy19,'23002',t]    = {item}[purpose,energy19,'23001',t];  #* sYS_cement[sMineralogi];	
	{item}['in_ETS',energy19,'23002',t]   = (1-share_ETS[energy19])*{item}['in_ETS',energy19,'23002',t];
	{item}['in_ETS',energy19,'23001',t]   = share_ETS[energy19]    *{item}['in_ETS',energy19,'23001',t];
	{item}[purpose,energy19,'23001',t]$(not sameas[purpose,'in_ETS']) = 0;
$ENDFOR

#For biogas flytter vi det hele i svineslagterierne
$FOR {item} in ['EN_vEAV_RE','EN_vDAV_RE','EN_vCAV_RE','EN_vnRE','EN_qRE','EN_vCO2_RE','EN_vEAFG_RE','EN_vSO2_RE','EN_vNOX_RE','EN_vPSO_RE','EN_vMOMS_RE']:
	{item}[purpose,'biogas','10012',t] = sum(sSlagteri,{item}[purpose,'biogas',sSlagteri,t]);
	{item}[purpose,'biogas',sSlagteri,t]$(not sameas[sSlagteri,'10012']) = 0;
$ENDFOR


	PARAMETER EN_vnRE_before[purpose,energy19,r,t]; EN_vnRE_before[purpose,energy19,r,t] = EN_vnRE[purpose,energy19,r,t];
	PARAMETER EN_vnCE_before[purpose,energy19,t]; EN_vnCE_before[purpose,energy19,t] = EN_vnCE[purpose,energy19,t];
	
#Bioethanol og biodiesel (Vi splitter ikke energiafgifter, CO2-afgifter mm. da vi regner med at det er knyttet til den fossile andel)
	#  $FOR {item} in ['EN_vnRE','EN_vMOMS_RE','EN_vEAV_RE','EN_vDAV_RE','EN_vCAV_RE']:
	#  	{item}['Transport','Biodiesel',r,t]$(tData[t] and {item}['Transport','Diesel for transport',r,t]) = {item}['Transport','Diesel for transport',r,t] * pbiodies2019 * EN_qRE['Transport','Biodiesel',r,t]/(pbiodies2019 * EN_qRE['Transport','Biodiesel',r,t] + EN_vnRE_before['Transport','Diesel for transport',r,t]); 
	#  	{item}['Transport','Diesel for transport',r,t]$(tData[t] and {item}['Transport','Biodiesel',r,t]) = {item}['Transport','Diesel for transport',r,t] - {item}['Transport','Biodiesel',r,t];

	#  	{item}['Transport','Bioethanol',r,t]$(tData[t] and {item}['Transport','Gasoline for transport',r,t]) = {item}['Transport','Gasoline for transport',r,t] * pbioethan2019 * EN_qRE['Transport','Bioethanol',r,t]/(pbioethan2019 * EN_qRE['Transport','Bioethanol',r,t] + EN_vnRE_before['Transport','Gasoline for transport',r,t]); 
	#  	{item}['Transport','Gasoline for transport',r,t]$(tData[t] and {item}['Transport','Bioethanol',r,t]) = {item}['Transport','Gasoline for transport',r,t] - {item}['Transport','Bioethanol',r,t];
	#  $ENDFOR 

	#  $FOR {item} in ['EN_vnCE','EN_vMOMS_CE','EN_vEAV_CE','EN_vDAV_CE','EN_vCAV_CE']:
	#  	{item}['Transport','Biodiesel',t]$(tData[t] and {item}['Transport','Diesel for transport',t]) = {item}['Transport','Diesel for transport',t] * pbiodies2019 * EN_qCE['Transport','Biodiesel',t]/(pbiodies2019 * EN_qCE['Transport','Biodiesel',t] + EN_vnCE_before['Transport','Diesel for transport',t]); 
	#  	{item}['Transport','Diesel for transport',t]$(tData[t] and {item}['Transport','Biodiesel',t]) = {item}['Transport','Diesel for transport',t] - {item}['Transport','Biodiesel',t];

	#  	{item}['Transport','Bioethanol',t]$(tData[t] and {item}['Transport','Gasoline for transport',t])= {item}['Transport','Gasoline for transport',t] * pbioethan2019 * EN_qCE['Transport','Bioethanol',t]/(pbioethan2019 * EN_qCE['Transport','Bioethanol',t] + EN_vnCE_before['Transport','Gasoline for transport',t]); 
	#  	{item}['Transport','Gasoline for transport',t]$(tData[t] and {item}['Transport','Bioethanol',t]) = {item}['Transport','Gasoline for transport',t] - {item}['Transport','Bioethanol',t];
	#  $ENDFOR

	$FOR {item} in ['EN_vnRE']:
		{item}['Transport','Biodiesel',r,t]$(tData[t] and {item}['Transport','Diesel for transport',r,t]) = pbiodies2019 * EN_qRE['Transport','Biodiesel',r,t]; 
		{item}['Transport','Diesel for transport',r,t]$(tData[t] and {item}['Transport','Biodiesel',r,t]) = {item}['Transport','Diesel for transport',r,t] - {item}['Transport','Biodiesel',r,t];

		{item}['Transport','Bioethanol',r,t]$(tData[t] and {item}['Transport','Gasoline for transport',r,t]) = pbioethan2019 * EN_qRE['Transport','Bioethanol',r,t]; 
		{item}['Transport','Gasoline for transport',r,t]$(tData[t] and {item}['Transport','Bioethanol',r,t]) = {item}['Transport','Gasoline for transport',r,t] - {item}['Transport','Bioethanol',r,t];
	$ENDFOR 

	$FOR {item} in ['EN_vnRE']:
		{item}['intern_trans','Biodiesel',r,t]$(tData[t] and {item}['intern_trans','Diesel for transport',r,t]) = pbiodies2019 * EN_qRE['intern_trans','Biodiesel',r,t]; 
		{item}['intern_trans','Diesel for transport',r,t]$(tData[t] and {item}['intern_trans','Biodiesel',r,t]) = {item}['intern_trans','Diesel for transport',r,t] - {item}['intern_trans','Biodiesel',r,t];

		{item}['intern_trans','Bioethanol',r,t]$(tData[t] and {item}['intern_trans','Gasoline for transport',r,t]) = pbioethan2019 * EN_qRE['intern_trans','Bioethanol',r,t]; 
		{item}['intern_trans','Gasoline for transport',r,t]$(tData[t] and {item}['intern_trans','Bioethanol',r,t]) = {item}['intern_trans','Gasoline for transport',r,t] - {item}['intern_trans','Bioethanol',r,t];
	$ENDFOR 

	$FOR {item} in ['EN_vnCE']:
		{item}['Transport','Biodiesel',t]$(tData[t] and {item}['Transport','Diesel for transport',t]) = pbiodies2019 * EN_qCE['Transport','Biodiesel',t]; 
		{item}['Transport','Diesel for transport',t]$(tData[t] and {item}['Transport','Biodiesel',t]) = {item}['Transport','Diesel for transport',t] - {item}['Transport','Biodiesel',t];

		{item}['Transport','Bioethanol',t]$(tData[t] and {item}['Transport','Gasoline for transport',t]) = pbioethan2019 * EN_qCE['Transport','Bioethanol',t]; 
		{item}['Transport','Gasoline for transport',t]$(tData[t] and {item}['Transport','Bioethanol',t]) = {item}['Transport','Gasoline for transport',t] - {item}['Transport','Bioethanol',t];
	$ENDFOR

	#No exports/stocks of biodiesel/bioethanol
	#  $FOR {item} in ['EN_vnLE']:
	#  	{item}['Transport','Biodiesel',t]$(tData[t] and {item}['Transport','Diesel for transport',t]) = {item}['Transport','Diesel for transport',t] * EN_qLE['Transport','Biodiesel',t]/(EN_qLE['Transport','Biodiesel',t] + EN_qLE['Transport','Diesel for transport',t]); 
	#  	{item}['Transport','Diesel for transport',t]$(tData[t] and {item}['Transport','Biodiesel',t]) = {item}['Transport','Diesel for transport',t] - {item}['Transport','Biodiesel',t];

	#  	{item}['Transport','Bioethanol',t]$(tData[t] and {item}['Transport','Gasoline for transport',t]) = {item}['Transport','Gasoline for transport',t] * EN_qLE['Transport','Bioethanol',t]/(EN_qLE['Transport','Bioethanol',t] + EN_qLE['Transport','Gasoline for transport',t]); 
	#  	{item}['Transport','Gasoline for transport',t]$(tData[t] and {item}['Transport','Bioethanol',t])  = {item}['Transport','Gasoline for transport',t] - {item}['Transport','Bioethanol',t];
	#  $ENDFOR

	#  $FOR {item} in ['EN_vnXE']:
	#  	{item}['Transport','Biodiesel',t]$(tData[t] and {item}['Transport','Diesel for transport',t]) = {item}['Transport','Diesel for transport',t] * EN_qXE['Transport','Biodiesel',t]/(EN_qXE['Transport','Biodiesel',t] + EN_qXE['Transport','Diesel for transport',t]); 
	#  	{item}['Transport','Diesel for transport',t]$(tData[t] and {item}['Transport','Biodiesel',t]) = {item}['Transport','Diesel for transport',t] - {item}['Transport','Biodiesel',t];

	#  	{item}['Transport','Bioethanol',t]$(tData[t] and {item}['Transport','Gasoline for transport',t]) = {item}['Transport','Gasoline for transport',t] * EN_qXE['Transport','Bioethanol',t]/(EN_qXE['Transport','Bioethanol',t] + EN_qXE['Transport','Gasoline for transport',t]); 
	#  	{item}['Transport','Gasoline for transport',t]$(tData[t] and {item}['Transport','Bioethanol',t]) = {item}['Transport','Gasoline for transport',t] - {item}['Transport','Bioethanol',t];
	#  $ENDFOR


	#Produktionsværdi og importværdi 
		EN_vE_y['Biodiesel',s,t]$(tData[t] and EN_vE_y['Diesel for transport',s,t])  = sum(purpose, sum(r,EN_vnRE[purpose,'Biodiesel',r,t]) + EN_vnCE[purpose,'Biodiesel',t]);     #* EN_qE_y['Biodiesel',s,t]/(EN_qE_y['Biodiesel',s,t] + EN_qE_y['Diesel for transport',s,t]);
		EN_vE_y['Diesel for transport',s,t]  = EN_vE_y['Diesel for transport',s,t]   - EN_vE_y['Biodiesel',s,t];

		EN_vE_m['Bioethanol',t]$(tData[t] and EN_vE_m['Gasoline for transport',t]) = sum(purpose, sum(r,EN_vnRE[purpose,'Bioethanol',r,t]) + EN_vnCE[purpose,'Bioethanol',t]); # * EN_qE_m['Bioethanol',t]/(EN_qE_m['Bioethanol',t] + EN_qE_m['Gasoline for transport',t]);
		EN_vE_m['Gasoline for transport',t]$(tData[t])                             = EN_vE_m['Gasoline for transport',t] - EN_vE_m['Bioethanol',t];

		#Flytter den smule bioethanol, der laves i DK til import. Sådan kører det også rundt i KF.
		EN_qE_m['Bioethanol',t] = EN_qE_m['Bioethanol',t] + EN_qE_y['Bioethanol','19000',t]; EN_qE_y['Bioethanol','19000',t] = 0;
		#  EN_qE_m['Bioethanol',t] = sum(purpose, sum(r,EN_qRE[purpose,'Bioethanol',r,t]) + EN_qCE[purpose,'Bioethanol',t]);

#Engros og detailhandel. Vigtigt at det kommer ovenpå korrektioner ovenfor
	EN_vWholeSaleE_y[energy19,t]     = sum((purpose,r), EN_vEAV_RE[purpose,energy19,r,t]) + sum(purpose, EN_vEAV_CE[purpose,energy19,t]);
	EN_vDetailSaleE_y[energy19,t]    = sum((purpose,r), EN_vDAV_RE[purpose,energy19,r,t]) + sum(purpose, EN_vDAV_CE[purpose,energy19,t]); 
	EN_vCaretradeEsale_y[energy19,t] = sum((purpose,r), EN_vCAV_RE[purpose,energy19,r,t]) + sum(purpose, EN_vCAV_CE[purpose,energy19,t]); 

	EN_qWholeSaleE_y[energy19,t]$EN_vWholeSaleE_y[energy19,t]         = sum((purpose,r)$(EN_vEAV_RE[purpose,energy19,r,t]), EN_qRE[purpose,energy19,r,t]) + sum(purpose$EN_vEAV_CE[purpose,energy19,t], EN_qCE[purpose,energy19,t]);
	EN_qDetailSaleE_y[energy19,t]$EN_vDetailSaleE_y[energy19,t]       = sum((purpose,r)$(EN_vDAV_RE[purpose,energy19,r,t]), EN_qRE[purpose,energy19,r,t]) + sum(purpose$EN_vDAV_CE[purpose,energy19,t], EN_qCE[purpose,energy19,t]);
	EN_qCaretradeEsale_y[energy19,t]$EN_vCaretradeEsale_y[energy19,t] = sum((purpose,r)$(EN_vCAV_RE[purpose,energy19,r,t]), EN_qRE[purpose,energy19,r,t]) + sum(purpose$EN_vCAV_CE[purpose,energy19,t], EN_qCE[purpose,energy19,t]);

#Prices
EN_pCE_base[purpose,energy19,t]$(EN_vnCE[purpose,energy19,t])     = EN_vnCE[purpose,energy19,t]/EN_qCE[purpose,energy19,t];  
EN_pLE_base[purpose,energy19,t]$(EN_vnLE[purpose,energy19,t])     = EN_vnLE[purpose,energy19,t]/EN_qLE[purpose,energy19,t]; 
EN_pRE_base[purpose,energy19,r,t]$(EN_vnRE[purpose,energy19,r,t]) = EN_vnRE[purpose,energy19,r,t]/EN_qRE[purpose,energy19,r,t]; 

EN_pXE_base[purpose,energy19,t]$(EN_vnXE[purpose,energy19,t])     = EN_vnXE[purpose,energy19,t]/EN_qXE[purpose,energy19,t]; 
EN_pE_y[energy19,s,t]$(EN_vE_y[energy19,s,t])                     = EN_vE_y[energy19,s,t]/EN_qE_y[energy19,s,t];
EN_pE_m[energy19,t]$(EN_vE_m[energy19,t])                         = EN_vE_m[energy19,t]/EN_qE_m[energy19,t]; 

EN_pCE[purpose,energy19,t]$(EN_vnCE[purpose,energy19,t])     = (EN_vDAV_CE[purpose,energy19,t] + EN_vEAV_CE[purpose,energy19,t] + EN_vCAV_CE[purpose,energy19,t] + EN_vCO2_CE[purpose,energy19,t] + EN_vEAFG_CE[purpose,energy19,t] + EN_vSO2_CE[purpose,energy19,t] + EN_vMOMS_CE[purpose,energy19,t] + EN_vPSO_CE[purpose,energy19,t] + EN_vNOx_CE[purpose,energy19,t]  + EN_vnCE[purpose,energy19,t])/EN_qCE[purpose,energy19,t];  
EN_pLE[purpose,energy19,t]$(EN_vnLE[purpose,energy19,t])     = EN_vnLE[purpose,energy19,t]/EN_qLE[purpose,energy19,t];  
EN_pRE[purpose,energy19,r,t]$(EN_vnRE[purpose,energy19,r,t]) = (EN_vDAV_RE[purpose,energy19,r,t] + EN_vEAV_RE[purpose,energy19,r,t] + EN_vCAV_RE[purpose,energy19,r,t] + EN_vCO2_RE[purpose,energy19,r,t] + EN_vEAFG_RE[purpose,energy19,r,t] + EN_vSO2_RE[purpose,energy19,r,t] + EN_vMOMS_RE[purpose,energy19,r,t] + EN_vPSO_RE[purpose,energy19,r,t] + EN_vNOx_RE[purpose,energy19,r,t]  + EN_vnRE[purpose,energy19,r,t])/EN_qRE[purpose,energy19,r,t]; 
EN_pXE[purpose,energy19,t]$(EN_vnXE[purpose,energy19,t])     = (EN_vEAFG_XE[purpose,energy19,t] + EN_vPSO_XE[purpose,energy19,t] + EN_vnXE[purpose,energy19,t])/EN_qXE[purpose,energy19,t]; 

EN_pEAV_CE[purpose,energy19,t]$EN_vEAV_CE[purpose,energy19,t] = EN_vEAV_CE[purpose,energy19,t]/EN_qCE[purpose,energy19,t];
EN_pDAV_CE[purpose,energy19,t]$EN_vDAV_CE[purpose,energy19,t] = EN_vDAV_CE[purpose,energy19,t]/EN_qCE[purpose,energy19,t];
EN_pCAV_CE[purpose,energy19,t]$EN_vCAV_CE[purpose,energy19,t] = EN_vCAV_CE[purpose,energy19,t]/EN_qCE[purpose,energy19,t];

EN_pEAV_RE[purpose,energy19,r,t]$(EN_vEAV_RE[purpose,energy19,r,t]) = EN_vEAV_RE[purpose,energy19,r,t]/EN_qRE[purpose,energy19,r,t];
EN_pDAV_RE[purpose,energy19,r,t]$(EN_vDAV_RE[purpose,energy19,r,t]) = EN_vDAV_RE[purpose,energy19,r,t]/EN_qRE[purpose,energy19,r,t];
EN_pCAV_RE[purpose,energy19,r,t]$(EN_vCAV_RE[purpose,energy19,r,t]) = EN_vCAV_RE[purpose,energy19,r,t]/EN_qRE[purpose,energy19,r,t];

#Totals 
vANV_tot[energy19,t] = sum(purpose, EN_vnCE[purpose,energy19,t] + EN_vnLE[purpose,energy19,t] + EN_vnXE[purpose,energy19,t] + sum(r, EN_vnRE[purpose,energy19,r,t]));
qANV_tot[energy19,t] = sum(purpose, EN_qCE[purpose,energy19,t]  + EN_qLE[purpose,energy19,t]  + EN_qXE[purpose,energy19,t]  + sum(r, EN_qRE[purpose,energy19,r,t]) + EN_qTL[purpose,energy19,t]);
vTIL_tot[energy19,t] = sum(s, EN_vE_y[energy19,s,t]) + EN_vE_m[energy19,t] + EN_vCUS[energy19,t];
qTIL_tot[energy19,t] = sum(s, EN_qE_y[energy19,s,t]) + EN_qE_m[energy19,t] + sum(types_renewable, EN_qRENEWABLE[energy19,types_renewable,t]);
vDiff_TA[energy19,t] = vANV_tot[energy19,t] - vTIL_tot[energy19,t];
qDiff_TA[energy19,t] = qANV_tot[energy19,t] - qTIL_tot[energy19,t];
vCO2_CE_tot[t] 		 = sum((purpose,energy19),   EN_vCO2_CE[purpose,energy19,t]);
vCO2_RE_tot[t]       = sum((purpose,energy19,r), EN_vCO2_RE[purpose,energy19,r,t]);
vEAFG_CE_tot[t]      = sum((purpose,energy19),   EN_vEAFG_CE[purpose,energy19,t]);
vEAFG_RE_tot[t]      = sum((purpose,energy19,r), EN_vEAFG_RE[purpose,energy19,r,t]);
vEAFG_XE_tot[t]      = sum((purpose,energy19),   EN_vEAFG_XE[purpose,energy19,t]);
vSO2_CE_tot[t] 		 = sum((purpose,energy19),   EN_vSO2_CE[purpose,energy19,t]);
vSO2_RE_tot[t] 		 = sum((purpose,energy19,r), EN_vSO2_RE[purpose,energy19,r,t]);
vPSO_CE_tot[t] 		 = sum((purpose,energy19), 	 EN_vPSO_CE[purpose,energy19,t]);
vPSO_RE_tot[t] 		 = sum((purpose,energy19,r), EN_vPSO_RE[purpose,energy19,r,t]);
vPSO_XE_tot[t] 		 = sum((purpose,energy19), 	 EN_vPSO_XE[purpose,energy19,t]);
vNOx_CE_tot[t] 		 = sum((purpose,energy19), 	 EN_vNOx_CE[purpose,energy19,t]);
vNOx_RE_tot[t] 		 = sum((purpose,energy19,r), EN_vNOx_RE[purpose,energy19,r,t]);
vMOMS_CE_tot[t] 	 = sum((purpose,energy19),   EN_vMOMS_CE[purpose,energy19,t]);
vMOMS_RE_tot[t] 	 = sum((purpose,energy19,r), EN_vMOMS_RE[purpose,energy19,r,t]);
vnRE_tot_r[r,t]      = sum((purpose,energy19),   EN_vnRE[purpose,energy19,r,t]);
vnCE_tot[t]          = sum((purpose,energy19),   EN_vnCE[purpose,energy19,t]);
vnLE_tot[t]          = sum((purpose,energy19),   EN_vnLE[purpose,energy19,t]);
vnXE_tot[t]          = sum((purpose,energy19),   EN_vnXE[purpose,energy19,t]);




#EMISSIONS
	EM_CE[emm,purpose,energy19,t]     = sum(energy48$(energy19_2_energy48(energy19,energy48)), EM_E_C.l[emm,purpose,energy48,t]);
	EM_RE[emm,purpose,energy19,r,t]   = sum(energy48$(energy19_2_energy48(energy19,energy48)), sum(ns105$(map1052five(r,ns105)), sum(nsGR$(nsGR2ns105(ns105,nsGR)), sum(brch$(brch2nsGR(brch,nsGR)), EM_E_R.l[emm,purpose,energy48,brch,t]))));

	#£HACKFIREWOOD 
	#Brænde 
	EM_CE[emm,'process_special','firewood and woodchips',t]$((EN_qCE['heating','firewood and woodchips',t] + EN_qCE['process_special','firewood and woodchips',t]))
														    = EM_CE[emm,'heating','firewood and woodchips',t] 
															* EN_qCE['process_special','firewood and woodchips',t]/(EN_qCE['heating','firewood and woodchips',t] + EN_qCE['process_special','firewood and woodchips',t]);
	EM_CE[emm,'heating','firewood and woodchips',t] = EM_CE[emm,'heating','firewood and woodchips',t] - EM_CE[emm,'process_special','firewood and woodchips',t];

#Landbrugskorrektion 
	EM_RE[emm,purpose,energy19,agri_sectors,'2019']$sum(agri_sectorss, EN_qRE[purpose,energy19,agri_sectorss,'2019']) = sum((agri_sectorss,purposee), EM_RE[emm,purposee,energy19,agri_sectorss,'2019']) * EN_qRE[purpose,energy19,agri_sectors,'2019']/sum((agri_sectorss,purposee), EN_qRE[purposee,energy19,agri_sectorss,'2019']);
	EM_RE[emm,purpose,energy19,agri_sectors,'2019']$(not EN_qRE[purpose,energy19,agri_sectors,'2019']) = 0;

	EM_RE[emm,purpose,energy19,'01080','2019']$(EN_qRE[purpose,energy19,'01080','2019']) = sum(purposee, EM_RE[emm,purposee,energy19,'01080','2019']) * EN_qRE[purpose,energy19,'01080','2019']/sum(purposee, EN_qRE[purposee,energy19,'01080','2019']);
	EM_RE[emm,purpose,energy19,'01080','2019']$(not EN_qRE[purpose,energy19,'01080','2019']) = 0;

	EM_RE[emm,purpose,energy19,'02000','2019']$(EN_qRE[purpose,energy19,'02000','2019']) = sum(purposee, EM_RE[emm,purposee,energy19,'02000','2019']) * EN_qRE[purpose,energy19,'02000','2019']/sum(purposee, EN_qRE[purposee,energy19,'02000','2019']);
	EM_RE[emm,purpose,energy19,'02000','2019']$(not EN_qRE[purpose,energy19,'02000','2019']) = 0;
	

#Indenringsfly 
   EM_RE[emm,'in_ETS','Jet petroleum','51001',t] = EM_RE[emm,'transport','Jet petroleum','51001',t]; EM_RE[emm,'transport','Jet petroleum','51001',t] = 0;

#Deler slagteriemissioner
	EM_RE[emm,purpose,energy19,sSlagteri,t]   = sYS[sSlagteri]*EM_RE[emm,purpose,energy19,'10011',t];
	#  EM_RE[emm,purpose,energy19,sMineralogi,t]   = sYS_cement[sMineralogi]*EM_RE[emm,purpose,energy19,'23001',t];


#Svin
	$IF %smaagrisesplit%:
	EM_RE[emm,purpose,energy19,sSvin,t]   = sYS_svin[sSvin]*sum(sSvin_a, EM_RE[emm,purpose,energy19,sSvin_a,t]);
	$ENDIF

#Mineralogi
	EM_RE[emm,purpose,energy19,'23002',t]     =  EM_RE[emm,purpose,energy19,'23001',t];
	EM_RE[emm,'in_ETS',energy19,'23002',t]    =  0.1*EM_RE[emm,'in_ETS',energy19,'23002',t];
	EM_RE[emm,'in_ETS',energy19,'23001',t]    =  0.9*EM_RE[emm,'in_ETS',energy19,'23001',t];
	EM_RE[emm,purpose,energy19,'23001',t]$(not sameas[purpose,'in_ETS'])  = 0;

#Raffinaderier
	EM_RE[emm,'in_ETS',energy19fos,'19000',t] = sum(purpose_xt,EM_RE[emm,purpose_xt,energy19fos,'19000',t]);
	EM_RE[emm,purpose_xt,energy19fos,'19000',t]$(not sameas[purpose_xt,'in_ETS']) = 0;

# Træindustri (energiforbrug i data, men ingen emissioner i data)
	EM_RE['CO2ubio','in_ETS','Oil products','16000',t] 	= EN_qRE['in_ETS','Oil products','16000',t]*uEmmHardCoded['CO2ubio','Oil products'];
	EM_RE['CO2ubio','heating','Oil products','16000',t] = EN_qRE['heating','Oil products','16000',t]*uEmmHardCoded['CO2ubio','Oil products'];

 #  Finansiel sektor (energiforbrug i data, men ingen emissioner i data)
	EM_RE['CO2ubio','heating','Oil products','64000',t] = EN_qRE['heating','Oil products','64000',t]*uEmmHardCoded['CO2ubio','Oil products'];

#Bionaturgasandele 
	sBionatgas_in[purpose,r,t]$((EM_RE['CO2bio',purpose,'Natural gas incl. biongas',r,t] + EM_RE['CO2ubio',purpose,'Natural gas incl. biongas',r,t])) 
		= EM_RE['CO2bio',purpose,'Natural gas incl. biongas',r,t]/(EM_RE['CO2bio',purpose,'Natural gas incl. biongas',r,t] + EM_RE['CO2ubio',purpose,'Natural gas incl. biongas',r,t]);

#Compute biongas share of total for consumers 
	sBioNatgasC_in[purpose,t]$((ANV_qCE.l[purpose,'48',t] + ANV_qCE.l[purpose,'49',t] + ANV_qCE.l[purpose,'50',t] + ANV_qCE.l[purpose,'51',t] + ANV_qCE.l[purpose,'24',t]))
		 = (ANV_qCE.l[purpose,'50',t] + ANV_qCE.l[purpose,'51',t])/(ANV_qCE.l[purpose,'48',t] + ANV_qCE.l[purpose,'49',t] + ANV_qCE.l[purpose,'50',t] + ANV_qCE.l[purpose,'51',t] + ANV_qCE.l[purpose,'24',t]);


EM_NEC[emm,t]                     = EM_NE_C.l[emm,t];
EM_NER[emm,r,t]                   = sum(ns105$(map1052five(r,ns105)), sum(nsGR$(nsGR2ns105(ns105,nsGR)), sum(brch$(brch2nsGR(brch,nsGR)), EM_NE_R.l[emm,brch,t])));

#Slagteri, mineralogi og svin
EM_NER[emm,sSlagteri,t]   = sYS[sSlagteri]*EM_NER[emm,'10011',t];
EM_NER[emm,'23002',t]     = 0.1*EM_NER[emm,'23001',t];
EM_NER[emm,'23001',t]     = 0.9*EM_NER[emm,'23001',t];
$IF %smaagrisesplit%:
EM_NER[emm,sSvin,t]       = sYS_svin[sSvin] * sum(sSvin_a, EM_NER[emm,sSvin_a,t]);
$ENDIF
#Totals 
PARAMETER EM_CE_tot[emm,t], EM_RE_tot[emm,t], EM_CE_RES_tot[emm,t], EM_RE_RES_tot[emm,t], EM_NEC_tot[emm,t],EM_NER_tot[emm,t];
EM_CE_tot[emm,t]     = sum((purpose,energy19), EM_CE[emm,purpose,energy19,t]);
EM_RE_tot[emm,t]     = sum((purpose,energy19,r), EM_RE[emm,purpose,energy19,r,t]);
EM_NEC_tot[emm,t]    = EM_NEC[emm,t];
EM_NER_tot[emm,t]    = sum(r, EM_NER[emm,r,t]); 


 