$PGROUP data_KF_energy_parameters 
	KF25_energybalance_ENS_[categoryENS,eENS2GR,GSR_ag,t] ""
	KF25_energybalance_ENS_KF24_aux[categoryENS,eENS2GR,t] ""
	KF25_energybalance_ENS_KF24_[categoryENS,eENS2GR,GSR_ag,t] "" 
	KF25_energybalance_ENS_DST[categoryENS,eENS2DST,GSR_ag,t]  ""
	KF25_energybalance_ENS_EMM_[categoryENS,eENS2GR,GSR_ag,t] ""
	KF_EMM_xE_[categoryENS,GSR_ag,t] ""
	KF_ANV_NatBal_[eENS2GR,sENS,t] ""
	KF_TIL_NatBal_[eENS2GR,sENS,t] ""
	DST_ANV[eENS2GR,sENS,t] ""
	DST_TIL[eENS2GR,sENS,t] ""
	check_sENS2GR[categoryENS,GSR_ag,eENS2GR] ""
  KF_emm_[emm_eq,sCRF,t] ""
  emissions_ENS[t,sENSny,ENS32,GSR] ""
  KF_EmmKoeff_[energy19,t] ""

	KF25_pE_supply[energy19,t] ""
	KF25_CostDel_RE_natgas[purpose,s,t] ""
		
 	KF25_CostDel_RE[energy19,s,t] ""
 	KF25_CostDel_CE[energy19,t] ""
 	KF25_pRE_base[purpose,energy19,s,t] "" 
 	KF25_pCE_base[purpose,energy19,t] ""
;



#Regner bionaturgas emissioner 
	KF25_energybalance_ENS_EMM[t,sENSny,'Bionaturgas',GSR] = KF25_energybalance_ENS[t,sENSny,'Bionaturgas',GSR]*56.093; 

	#  execute_unload 'output\pre.gdx';

	#Det meste data er fucked før 2024, derfor benyttes 2024-tallene til at lave en nøgle, der fordeler totaler for de foregående år. (der laves desuden lidt yderligere 2019-2021 rettelser i for-loopet længere nede i filen her - søg på 2019-2021 for at finde)
	PARAMETER TotalEnergie[ENS32,t], ShareofTotalEnergie[sENsny,GSR,ENS32,t];

	set excludethesesENSny(sENSny)/'Vejtransport','Electricity transmission correction','Distributionstab','Graensehandel','Bunkering','InternationalLuft','DataCentre','Registered exports'/;
	set excludethesesENSny_domestic(sENSny)/'Vejtransport'/;

	#Ny opsplitning! 
	TotalEnergie[ENS32,t] = sum((GSR,sENSny)$(not excludethesesENSny(sENSny)), 
			KF25_energybalance_ENS[t,sENSny,ENS32,GSR]);


	ShareofTotalEnergie[sENsny,GSR,ENS32,t]$(KF25_energybalance_ENS[t,sENSny,ENS32,GSR] and not excludethesesENSny[sENSny]) 
		= KF25_energybalance_ENS[t,sENSny,ENS32,GSR]/TotalEnergie[ENS32,t];


	KF25_energybalance_ENS['2019',sENSny,ENS32,GSR]$(not excludethesesENSny[sENsny]) = 0; KF25_energybalance_ENS['2019',sENSny,ENS32,GSR]$(not excludethesesENSny[sENsny]) = ShareofTotalEnergie[sENsny,GSR,ENS32,'2024'] *  TotalEnergie[ENS32,'2019'];
	KF25_energybalance_ENS['2020',sENSny,ENS32,GSR]$(not excludethesesENSny[sENsny]) = 0; KF25_energybalance_ENS['2020',sENSny,ENS32,GSR]$(not excludethesesENSny[sENsny]) = ShareofTotalEnergie[sENsny,GSR,ENS32,'2024'] *  TotalEnergie[ENS32,'2020'];
	KF25_energybalance_ENS['2021',sENSny,ENS32,GSR]$(not excludethesesENSny[sENsny]) = 0; KF25_energybalance_ENS['2021',sENSny,ENS32,GSR]$(not excludethesesENSny[sENsny]) = ShareofTotalEnergie[sENsny,GSR,ENS32,'2024'] *  TotalEnergie[ENS32,'2021'];
	KF25_energybalance_ENS['2022',sENSny,ENS32,GSR]$(not excludethesesENSny[sENsny]) = 0; KF25_energybalance_ENS['2022',sENSny,ENS32,GSR]$(not excludethesesENSny[sENsny]) = ShareofTotalEnergie[sENsny,GSR,ENS32,'2024'] *  TotalEnergie[ENS32,'2022'];
	KF25_energybalance_ENS['2023',sENSny,ENS32,GSR]$(not excludethesesENSny[sENsny]) = 0; KF25_energybalance_ENS['2023',sENSny,ENS32,GSR]$(not excludethesesENSny[sENsny]) = ShareofTotalEnergie[sENsny,GSR,ENS32,'2024'] *  TotalEnergie[ENS32,'2023'];

	TotalEnergie[ENS32,t] = sum((GSR,sENSny)$(not excludethesesENSny[sENsny]), KF25_energybalance_ENS_EMM[t,sENSny,ENS32,GSR]);
	ShareofTotalEnergie[sENsny,GSR,ENS32,t]$(KF25_energybalance_ENS_EMM[t,sENSny,ENS32,GSR] and not excludethesesENSny[sENsny]) 
		= KF25_energybalance_ENS_EMM[t,sENSny,ENS32,GSR]/TotalEnergie[ENS32,t];

	KF25_energybalance_ENS_EMM['2019',sENSny,ENS32,GSR]$(not excludethesesENSny[sENsny]) = 0; KF25_energybalance_ENS_EMM['2019',sENSny,ENS32,GSR]$(not excludethesesENSny[sENSny]) = ShareofTotalEnergie[sENsny,GSR,ENS32,'2024'] *  TotalEnergie[ENS32,'2019'];
	KF25_energybalance_ENS_EMM['2020',sENSny,ENS32,GSR]$(not excludethesesENSny[sENsny]) = 0; KF25_energybalance_ENS_EMM['2020',sENSny,ENS32,GSR]$(not excludethesesENSny[sENSny]) = ShareofTotalEnergie[sENsny,GSR,ENS32,'2024'] *  TotalEnergie[ENS32,'2020'];
	KF25_energybalance_ENS_EMM['2021',sENSny,ENS32,GSR]$(not excludethesesENSny[sENsny]) = 0; KF25_energybalance_ENS_EMM['2021',sENSny,ENS32,GSR]$(not excludethesesENSny[sENSny]) = ShareofTotalEnergie[sENsny,GSR,ENS32,'2024'] *  TotalEnergie[ENS32,'2021'];
	KF25_energybalance_ENS_EMM['2022',sENSny,ENS32,GSR]$(not excludethesesENSny[sENsny]) = 0; KF25_energybalance_ENS_EMM['2022',sENSny,ENS32,GSR]$(not excludethesesENSny[sENSny]) = ShareofTotalEnergie[sENsny,GSR,ENS32,'2024'] *  TotalEnergie[ENS32,'2022'];
	KF25_energybalance_ENS_EMM['2023',sENSny,ENS32,GSR]$(not excludethesesENSny[sENsny]) = 0; KF25_energybalance_ENS_EMM['2023',sENSny,ENS32,GSR]$(not excludethesesENSny[sENSny]) = ShareofTotalEnergie[sENsny,GSR,ENS32,'2024'] *  TotalEnergie[ENS32,'2023'];



#Aggregerer 'brancher/formål' og energivarer	

	KF25_energybalance_ENS_[categoryENS,eENS2GR,GSR_ag,t] = sum(GSR$(GSR_ag2GSR(GSR_ag,GSR)), 
														sum(sENsny$(categoryENS2sENSny(categoryENS,sENSny)), 
															sum((ENS32,eENS2DST)$(ENS322eENS2DST(ENS32, eENS2DST) and eENS2DST2eENS2GR(eENS2DST,eENS2GR)), 
																KF25_energybalance_ENS[t,sENSny,ENS32,GSR])));


																							
	#HJÆLPEPARAMETER, DER KAN KOMMENTERES IND, HVIS NEDENSTÅENDE TEST IKKE BESTÅS
	 PARAMETER whatisnotmappedEBAL[t,sENSny,ENS32,GSR];
	 whatisnotmappedEBAL[t,sENSny,ENS32,GSR] = KF25_energybalance_ENS[t,sENSny,ENS32,GSR] - KF25_energybalance_ENS[t,sENSny,ENS32,GSR]$sum((GSR_ag,categoryENS,eENS2DST,eENS2GR),(ENS322eENS2DST(ENS32, eENS2DST) and eENS2DST2eENS2GR(eENS2DST,eENS2GR) and GSR_ag2GSR(GSR_ag,GSR) and categoryENS2sENSny(categoryENS,sENSny)));
	#  execute_unload 'output\post.gdx';

	
	#There is one exception, the "Electricity transmission correction", which is an item in data-years and not in forecast
	ABORT$(abs(sum((categoryENS,eENS2GR,GSR_ag,tBF_calib), KF25_energybalance_ENS_[categoryENS,eENS2GR,GSR_ag,tBF_calib]) 
				- sum((sENSny,ENS32,GSR,tBF_calib)$(not sameas[sENSny,'Electricity transmission correction'] and not sameas[ENS32,'E-fuel'] and not sameas[sEnsny,'Registered exports']),
					 KF25_energybalance_ENS[tBF_calib,sENSny,ENS32,GSR])) >1e-5) "Not all of Energy-data passes through mapping";


	KF25_energybalance_ENS_DST[categoryENS,eENS2DST,GSR_ag,t] = sum(GSR$(GSR_ag2GSR(GSR_ag,GSR)), 
														sum(sENsny$(categoryENS2sENSny(categoryENS,sENSny)), 
															sum((ENS32)$(ENS322eENS2DST(ENS32, eENS2DST)), 
																KF25_energybalance_ENS[t,sENSny,ENS32,GSR])));

	KF25_energybalance_ENS_EMM_[categoryENS,eENS2GR,GSR_ag,t] = sum(GSR$(GSR_ag2GSR(GSR_ag,GSR)), 
															sum(sENsny$(categoryENS2sENSny(categoryENS,sENSny)), 
																sum((ENS32,eENS2DST)$(ENS322eENS2DST(ENS32, eENS2DST) and eENS2DST2eENS2GR(eENS2DST,eENS2GR)), 
																	KF25_energybalance_ENS_EMM[t,sENSny,ENS32,GSR])));

	 #HJÆLPEPARAMETER, DER KAN KOMMENTERES IND, HVIS NEDENSTÅENDE TEST IKKE BESTÅS
	 whatisnotmappedEBAL[t,sENSny,ENS32,GSR] = 0;
	 whatisnotmappedEBAL[t,sENSny,ENS32,GSR] = KF25_energybalance_ENS_EMM[t,sENSny,ENS32,GSR] - KF25_energybalance_ENS_EMM[t,sENSny,ENS32,GSR]$sum((GSR_ag,categoryENS,eENS2DST,eENS2GR),(ENS322eENS2DST(ENS32, eENS2DST) and eENS2DST2eENS2GR(eENS2DST,eENS2GR) and GSR_ag2GSR(GSR_ag,GSR) and categoryENS2sENSny(categoryENS,sENSny)));
	#  execute_unload 'output\post.gdx';

	ABORT$(abs(sum((categoryENS,eENS2GR,GSR_ag,tBF_calib), KF25_energybalance_ENS_EMM_[categoryENS,eENS2GR,GSR_ag,tBF_calib]) 
			- sum((sENSny,ENS32,GSR,tBF_calib)$(not sameas[sENSny,'Electricity transmission correction'] and not sameas[ENS32,'E-fuel'] and not sameas[sEnsny,'Registered exports']),
				 KF25_energybalance_ENS_EMM[tBF_calib,sENSny,ENS32,GSR])) >1e-5) "Not all of emissions-data passes through mapping";

	#Ikke-energimæssige emissioner
	KF_EMM_xE_[categoryENS,GSR_ag,t] = sum(GSR$(GSR_ag2GSR(GSR_ag,GSR)), 
														sum(sENsny$(categoryENS2sENSny(categoryENS,sENSny)), 
																KF_EMM_xE[t,sENSny,GSR]))/1000; #Dividerer m. 1000 for at få ktCO2e


	#Herunder laves diverse ad hoc rettelser. Nogle af rettelserne var relevante på 2022 data, så på et tidspunkt er det en ide at tjekke om de også er relevante på 2023 data
	Parameter savedis[t], enbaltot_sumGSR[categoryENS,eENS2GR,t], enbal_GSRdist22[categoryENS,eENS2GR,GSR_ag], total_e[t], total_e_[t], total_xe[t], total_xe_[t], total[t], total_[t];

	total_e[t]    = sum((sENSny,ENS32,GSR), KF25_energybalance_ENS_EMM[t,sENSny,ENS32,GSR])/10**6;
	total_e_[t]   = sum((categoryENS,eENS2GR,GSR_ag), KF25_energybalance_ENS_EMM_[categoryENS,eENS2GR,GSR_ag,t])/10**6;
	total_xe[t]   = sum((sENSny,GSR), KF_EMM_xE[t,sENSny,GSR])/10**6; 
	total_xe_[t]  = sum((categoryENS,GSR_ag), KF_EMM_xE_[categoryENS,GSR_ag,t])*1000/10**6;
	total[t] = total_e[t] + total_xe[t];
	total_[t] = total_e_[t] + total_xe_[t];

#-----------------------------------------------------------------------------------------------#
	# Rettelser og hacks til KF25_energybalance_ENS
#-----------------------------------------------------------------------------------------------#
	$FOR {ENSITEM} in ['KF25_energybalance_ENS_','KF25_energybalance_ENS_EMM_']:
			#Rettelser
			{ENSITEM}['Kraftvarme',eENS2GR,'BraendslertilElOgFjernvarme_notETS',t] = {ENSITEM}['Kraftvarme',eENS2GR,'BraendslertilElOgFjernvarme_notETS',t] + {ENSITEM}['Kraftvarme',eENS2GR,'notinGSR',t]; 
			{ENSITEM}['Kraftvarme',eENS2GR,'notinGSR',t] = 0;
			{ENSITEM}['Husholdninger',eENS2GR,'Rumvarme',t] = {ENSITEM}['Husholdninger',eENS2GR,'Rumvarme',t] + {ENSITEM}['Husholdninger',eENS2GR,'Husholdninger_ejRumvarme',t];
			{ENSITEM}['Husholdninger',eENS2GR,'Husholdninger_ejRumvarme',t] = 0;

			{ENSITEM}['Raffinaderier',eENS2GR,'Raffinaderier',t] = {ENSITEM}['Raffinaderier',eENS2GR,'Raffinaderier',t] + {ENSITEM}['Raffinaderier',eENS2GR,'flaring_ETS',t];
			{ENSITEM}['Raffinaderier',eENS2GR,'flaring_ETS',t] = 0;

			{ENSITEM}['AffaldsForb','Waste','notinGSR_ETS',t] = sum(GSR_ag, {ENSITEM}['Kraftvarme','Waste',GSR_ag,t]);
			{ENSITEM}['Kraftvarme','Waste',GSR_ag,t] = 0;

			# {ENSITEM}['LandOgSkov',eENS2GR,'LandOgSkov_diesel',t] = {ENSITEM}['LandOgSkov',eENS2GR,'LandOgSkov_diesel',t] + {ENSITEM}['LandOgSkov',eENS2GR,'intern_trans',t];
			# {ENSITEM}['LandOgSkov',eENS2GR,'intern_trans',t]      = 0;

			# {ENSITEM}['LandOgSkov','Straw','LandOgSkov_gartneri_non_ETS',t] = EN_qRE['heating','Straw for energy purposes','01020','2019']/sum(agri_sectors, EN_qRE['heating','Straw for energy purposes',agri_sectors,'2019'])*{ENSITEM}['LandOgSkov','Straw','Rumvarme',t];
			# {ENSITEM}['LandOgSkov','Straw','Rumvarme',t]  					= {ENSITEM}['LandOgSkov','Straw','Rumvarme',t] - {ENSITEM}['LandOgSkov','Straw','LandOgSkov_gartneri_non_ETS',t];

			#Udvinding 
			{ENSITEM}['Udvinding','Natural gas (Extraction)','Nordsoeen',t] = {ENSITEM}['Udvinding','Natural gas incl. biongas','Nordsoeen',t];
			{ENSITEM}['Udvinding','Natural gas incl. biongas','Nordsoeen',t] = 0; 


			#Flytter sidste raffinaderigas til raffinaderier 
			{ENSITEM}['Raffinaderier','Refinery gas','Raffinaderier',t] = KF25_energybalance_ENS_['Raffinaderier','Refinery gas','Raffinaderier',t] 
																				+ KF25_energybalance_ENS_['Kraftvarme','Refinery gas','BraendslertilElOgFjernvarme_notETS',t];

			{ENSITEM}['Kraftvarme','Refinery gas','BraendslertilElOgFjernvarme_notETS',t] = 0;

			#Hacks - ingen fjernvarme på raffianderier (der er meget meget lidt...)
			{ENSITEM}['Raffinaderier','District heat','notinGSR',t] = 0;
			#Hack - #Er overskudsvarme, der ikke som sådan skal prissættes...
			{ENSITEM}['Kraftvarme','District heat',GSR_ag,t] = 0; 


		$ENDFOR


	#Emission-coefficient for waste
	PARAMETER IEC_waste[GSR_ag,categoryENS,t];
	IEC_waste[GSR_ag,categoryENS,t]$(sum(GSR$(GSR_ag2GSR(GSR_ag,GSR)), sum(sENSny$(categoryENS2sENSny(categoryENS,sENSny)), KF25_energybalance_ENS[t,sENSny,'Affald, bionedbrydeligt',GSR] + KF25_energybalance_ENS[t,sENSny,'Affald, ikke bionedbrydeligt',GSR])))
		=	sum(GSR$(GSR_ag2GSR(GSR_ag,GSR)), sum(sENSny$(categoryENS2sENSny(categoryENS,sENSny)), KF25_energybalance_ENS[t,sENSny,'Affald, bionedbrydeligt',GSR] * 0 + KF25_energybalance_ENS[t,sENSny,'Affald, ikke bionedbrydeligt',GSR] * 94.44))
		/	sum(GSR$(GSR_ag2GSR(GSR_ag,GSR)), sum(sENSny$(categoryENS2sENSny(categoryENS,sENSny)), KF25_energybalance_ENS[t,sENSny,'Affald, bionedbrydeligt',GSR]     + KF25_energybalance_ENS[t,sENSny,'Affald, ikke bionedbrydeligt',GSR])); 


    IEC_waste[GSR_ag,categoryENS,t]$(t.val > tBF_calib_end.val) =  IEC_waste[GSR_ag,categoryENS,tBF_calib_end];



#Forlænger
	KF25_energybalance_ENS_[categoryENS,eENS2GR,GSR_ag,t]$(t.val > tBF_calib_end.val) = KF25_energybalance_ENS_[categoryENS,eENS2GR,GSR_ag,tBF_calib_End];

#There used to be some ridicoulusly small entries in the data. If still here we remove them
	KF25_energybalance_ENS_[categoryENS,eENS2GR,GSR_ag,t]$(KF25_energybalance_ENS_[categoryENS,eENS2GR,GSR_ag,t] < 1e-4) = 0; 

#Forlænger
	KF25_energybalance_ENS_DST[categoryENS,eENS2DST,GSR_ag,t]$(t.val > tBF_calib_end.val) = KF25_energybalance_ENS_DST[categoryENS,eENS2DST,GSR_ag,tBF_calib_End];

#There used to be some ridicoulusly small entries in the data. If still here we remove them
	KF25_energybalance_ENS_DST[categoryENS,eENS2DST,GSR_ag,t]$(KF25_energybalance_ENS_DST[categoryENS,eENS2DST,GSR_ag,t] < 1e-4) = 0; 

#We want to check that all energybalance items pass through mapping (with a few specified exceptions), the exceptions are in the set below (categoryENS2exclude)
set categoryENS2exclude[categoryENS]/Graensehandel,solceller,Vandkraftanlaeg,vindmoeller,distributionstab,
										flaring_raff,flaring_udv,Oevrigtransport,Biogasopg,Bunkering,
										KraftVarme,ptX,InternationalLuft,'Greenland & Faroe Islands, vessels'/; 
ene192eENS2GR('Natural gas (Extraction)','Natural gas (Extraction)') = yes;

check_sENS2GR[categoryENS,GSR_ag,eENS2GR]$(not categoryENS2exclude[categoryENS])
											 = 1$sum((purpose,energy19,s)$(ene192eENS2GR(energy19,eENS2GR)), sENS2GR(categoryENS, GSR_ag, purpose, energy19, s)) 
											   - 1$sum(t, KF25_energybalance_ENS_[categoryENS,eENS2GR,GSR_ag,t]);

tjek = sum((categoryENS,GSR_ag,eENS2GR)$(check_sENS2GR[categoryENS,GSR_ag,eENS2GR]<0 and not categoryENS2exclude[categoryENS]), check_sENS2GR[categoryENS,GSR_ag,eENS2GR]); 
# execute_unload 'output\pre.gdx';
ABORT$(tjek <> 0) tjek, "Der er elementer i ENS-energibalancer, der ikke bliver mappet til modellen via mappingen sENS2GR. For at fejlsoege display check_sENS2GR og se, hvor der staar -1";

#Vækstkorrigerer 
KF25_energybalance_ENS_[categoryENS,eENS2GR,GSR_ag,t] = KF25_energybalance_ENS_[categoryENS,eENS2GR,GSR_ag,t]*growth_factor[t];
KF25_energybalance_ENS_DST[categoryENS,eENS2DST,GSR_ag,t] = KF25_energybalance_ENS_DST[categoryENS,eENS2DST,GSR_ag,t]*growth_factor[t];

#Vender fortegn på anvendelsen
	KF_ANV_NatBal[e28,sENS,t] = -KF_ANV_NatBal[e28,sENS,t]; 
	KF_ANV_NatBal[e28,sENS,t] = sum(sENSS$(sENS2sENS(sENS,e28,sENSS)), KF_ANV_NatBal[e28,sENSS,t]);
	KF_TIL_NatBal[e28,sENS,t] = sum(sENSS$(sENS2sENS(sENS,e28,sENSS)), KF_TIL_NatBal[e28,sENSS,t]);


#Korrektioner
	#DST antager at 15 pct. af udenrigsbunkring hos ENS går til danske residenter til transport. Det gør vi også herefter
	KF_ANV_NatBal['Fuelolie og Spildolie','Transport',t]        = 0.15 * KF_ANV_NatBal['Fuelolie og Spildolie','Udenrigsbunkring',t];
	KF_ANV_NatBal['Fuelolie og Spildolie','Udenrigsbunkring',t] = 0.85 * KF_ANV_NatBal['Fuelolie og Spildolie','Udenrigsbunkring',t];


	KF_ANV_NatBal_[eENS2GR,sENS,t] = sum(e28$sENS2eENS2GR(e28,eENS2GR), KF_ANV_NatBal[e28,sENS,t]);


	#-----------------------------------------------------------------------------------------------#
	# Rettelser til KF_TIL_NatBal_ og KF_ANV_NatBal_
	#-----------------------------------------------------------------------------------------------#
		#  BF_TIL_NatBal_['Natural gas (Extraction)','Primaer produktion',t]    = BF_TIL_NatBal['Naturgas','Primaer produktion',t];
		KF_TIL_NatBal_['Natural gas (Extraction)','Energisektor',t]          = KF_TIL_NatBal['Naturgas','Primaer produktion',t]; #Flytter til samme branche som GR bliver mappet til
		KF_TIL_NatBal_['Natural gas (Extraction)','Import',t]                = KF_TIL_NatBal['Naturgas','Import',t];
		KF_ANV_NatBal_['Natural gas (Extraction)','Energisektor',t]          = KF_ANV_NatBal['Naturgas','Energisektor',t]; #Egetforbrug på boreplatform
		KF_ANV_NatBal_['Natural gas (Extraction)','Konverteringssektor',t]   = KF_TIL_NatBal['Naturgas','Primaer produktion',t]; #Raffinaderierne forbruger det producerede
		KF_ANV_NatBal_['Natural gas (Extraction)','Distributionstab m.m.',t] = KF_ANV_NatBal['Naturgas','Flaring',t];

		#HACK!!!
		KF_ANV_NatBal_['Renewable energy','offentlig service',t]$(tx0[t] and t.val <= 2019) 								     = KF_ANV_NatBal_['Renewable energy','offentlig service','2020'];
		KF_ANV_NatBal_['Renewable energy','Privat service inkl. soe-, jernbane-, og lufttransport',t]$(tx0[t] and t.val <= 2019) = KF_ANV_NatBal_['Renewable energy','Privat service inkl. soe-, jernbane-, og lufttransport','2020'];

		

		#  BF_TIL_NatBal_['Natural gas (Incl. city-gas)','Primaer produktion',t]   = BF_TIL_NatBal_['Natural gas (Extraction)','Primaer produktion',t];  #Should subtract flaring here! Make sure to include in next revision
		KF_TIL_NatBal_['Natural gas incl. biongas','Konverteringssektor',t]  = KF_TIL_NatBal_['Natural gas (Extraction)','Energisektor',t];  #Should subtract flaring here! Make sure to include in next revision
		KF_ANV_NatBal_['Natural gas incl. biongas','Konverteringssektor',t]  = KF_TIL_NatBal_['Natural gas incl. biongas','Primaer produktion',t] + KF_TIL_NatBal_['Natural gas (Extraction)','Import',t] - KF_ANV_NatBal_['Natural gas incl. biongas','Eksport',t];

		$FOR {Demanditem} in ['Konverteringssektor','Distributionstab m.m.','Vejtransport','Jernbanetransport','Soetransport, indenrigs','Forsvarets transport','Lufttransport, indenrigs','Lufttransport, udenrigs','Landbrug, skovbrug og gartneri',
							  'fiskeri','Fremstillingsvirksomhed','Byggeri- og anlaegsvirksomhed','Privat service','Engros- og detailhandel','Offentlig service','Husholdninger','Lufttransport','Privat service inkl. soe-, jernbane-, og lufttransport','Transport']:
			KF_ANV_NatBal_['Natural gas incl. biongas','{Demanditem}',t] = KF_ANV_NatBal['Naturgas','{Demanditem}',t] + KF_ANV_NatBal['Bionaturgas','{Demanditem}',t];
		$ENDFOR

		KF_ANV_NatBal_['Refinery gas','Energisektor',t] = KF_ANV_NatBal_['Refinery gas','Energisektor',t] + KF_ANV_NatBal_['Refinery gas','Konverteringssektor',t]; #All refinery-gas is used in energy-sector in DST-data, we therefore move all use to said sector in BF
		KF_ANV_NatBal_['Refinery gas','Konverteringssektor',t] = 0;

		KF_ANV_NatBal_['Waste','Konverteringssektor',t] = KF_ANV_NatBal_['Waste','Konverteringssektor',t] + KF_ANV_NatBal_['Waste','Privat service',t]; #No use of waste in privat service sector in ENS data.
		KF_ANV_NatBal_['Waste','Privat service',t] = 0;

		KF_ANV_NatBal_['Renewable energy','Konverteringssektor',t] = KF_ANV_NatBal_['Renewable energy','Konverteringssektor',t] + KF_ANV_NatBal_['Renewable energy','Fremstillingsvirksomhed',t]; 
		KF_ANV_NatBal_['Renewable energy','Fremstillingsvirksomhed',t] = 0;


		KF_TIL_NatBal_[eENS2GR,sENS,t] =  KF_TIL_NatBal_[eENS2GR,sENS,t] + sum(e28$sENS2eENS2GR(e28,eENS2GR), KF_TIL_NatBal[e28,sENS,t]);

	#Korrektioner af produktion
		KF_TIL_NatBal_['Biogas','Konverteringssektor',t] = KF_TIL_NatBal_['Biogas','Primaer produktion',t]; KF_TIL_NatBal_['Biogas','Primaer produktion',t] = 0;
		KF_TIL_NatBal_['Crude oil and semi-refined oil','Energisektor',t] = KF_TIL_NatBal_['Crude oil and semi-refined oil','Primaer produktion',t]; KF_TIL_NatBal_['Crude oil and semi-refined oil','Primaer produktion',t] = 0; 


		#Nettoimport
		KF_TIL_NatBal_[eENS2GR,'nettoimport',t] = KF_TIL_NatBal_[eENS2GR,'import',t] - KF_ANV_NatBal_[eENS2GR,'eksport',t];
		KF_TIL_NatBal_['Natural gas incl. biongas','nettoimport',t] = KF_TIL_NatBal['Naturgas','Import',t] - KF_ANV_NatBal['Naturgas','Eksport',t];
		KF_TIL_NatBal_['Natural gas (Extraction)','nettoimport',t] = 0; 
		#  KF_TIL_NatBal_[eENS2GR,'import',t] = 0;
		#  KF_ANV_NatBal_[eENS2GR,'eksport',t] = 0;

		#Elektricitet
		#  KF_TIL_NatBal_['El from y and m',sENS,t] = KF_TIL_NatBal_['electricity',sENS,t]; #Ligger allerede i den korrekte energivare. 
		KF_ANV_NatBal_['electricity',sENS,t]$(not sameas [sENS,'Konverteringssektor']) 	 = KF_ANV_NatBal_['El from y and m',sENS,t];
		KF_ANV_NatBal_['El from y and m',sENS,t]$(not sameas [sENS,'Konverteringssektor']) = 0;  

	#Vækstkorrektion og omregning til PJ
	KF_ANV_NatBal_[eENS2GR,sENS,t] = KF_ANV_NatBal_[eENS2GR,sENS,t]*growth_factor[t]/1000; 
	KF_TIL_NatBal_[eENS2GR,sENS,t] = KF_TIL_NatBal_[eENS2GR,sENS,t]*growth_factor[t]/1000; 


	#  #
	DST_ANV[eENS2GR,sENS,t]                                   = sum(energy19$energy192eENS2GR(energy19,eENS2GR), sum((purpose,s)$e192s2sENS_USE(energy19,purpose,s,sENS), EN_qRE[purpose,energy19,s,t])); 
	DST_ANV[eENS2GR,'Lagertraek og statistisk difference',t]  = sum(energy19$energy192eENS2GR(energy19,eENS2GR), sum(purpose, EN_qLE[purpose,energy19,t]));
	DST_ANV[eENS2GR,'Husholdninger',t]                        = DST_ANV[eENS2GR,'Husholdninger',t] + sum(energy19$energy192eENS2GR(energy19,eENS2GR), sum(purpose$e192s2sENS_USE(energy19,purpose,'68203','Husholdninger'), EN_qCE[purpose,energy19,t]));
	DST_ANV[eENS2GR,'Distributionstab m.m.',t]                = sum(energy19$energy192eENS2GR(energy19,eENS2GR), sum(purpose, EN_qTL[purpose,energy19,t]));
	DST_ANV[eENS2GR,'Transport',t]                            = DST_ANV[eENS2GR,'Transport',t] + sum(energy19$energy192eENS2GR(energy19,eENS2GR),EN_qCE['transport',energy19,t]); #Adds transportation to households 

	DST_TIL[eENS2GR,sENS,t]                                   = sum(energy19$energy192eENS2GR(energy19,eENS2GR), sum(s$e192s2sENS_IN(energy19,s,sENS), EN_qE_y[energy19,s,t]));
	DST_TIL[eENS2GR,'import',t]                               = sum(energy19$energy192eENS2GR(energy19,eENS2GR), EN_qE_m[energy19,t]);
	DST_ANV[eENS2GR,'eksport',t]                              = sum(energy19$energy192eENS2GR(energy19,eENS2GR), EN_qXE['unspecified',energy19,t]);

	DST_TIL[eENS2GR,'Primaer produktion',t]                   = DST_TIL[eENS2GR,'Primaer produktion',t] + sum(energy19$energy192eENS2GR(energy19,eENS2GR), sum(types_renewable, EN_qRENEWABLE[energy19,types_renewable,t]));


	#EMISSIONS
	KF_emm_[emm_eq,sCRF,t] = sum(sCRFF$sCRC2SCRF(sCRF,sCRFF), KF_emm[emm_eq,sCRFF,t]);
	LOOP(t$(sum((emm_eq,sCRF), KF_emm[emm_eq,sCRF,t])),
		tjek = sum((emm_eq,sCRF),KF_emm_[emm_eq,sCRF,t]) - sum((emm_eq,sCRF), KF_emm[emm_eq,sCRF,t]);
        Abort$(abs(tjek) > 1e-6) tjek, "All emissions do not pass through (or too many pass through) the mapping sCRC2SCRF";
        );

	KF_emm_[emm_eq,'Total (UNFCCC-LULUCF)',t] = sum(sCRF, KF_emm_[emm_eq,sCRF,t]);

	PARAMETER testwhereCRF[emm_eq,sCRF,t];
	testwhereCRF[emm,sCRF,t]$(not (sum(s,sCRF_2_sENS2GR_xE(sCRF,s,emm)) 
										or nonmappedCRFxE[sCRF] 
										or nonmapped_elsewhereinmodelCRFxE[sCRF] 
										or sum((s,categoryENS,GSR_ag,purpose,energy19),sCRF_2_sENS2GR_e(sCRF,categoryENS,GSR_ag,purpose,energy19,s)))) 	
	= KF_emm_[emm,sCRF,t]; 
	# execute_unload 'output\pre.gdx';

	#IF THE TEST BELOW FAILS, WRITE PRE.GDX ABOVE AND LOOK IN "testwhereCRF" TO SEE WHERE THE PROBLEM IS
	LOOP(t$(sum((emm,sCRF), KF_emm[emm,sCRF,t])),
		tjek = sum((emm,sCRF)$(sum(s,sCRF_2_sENS2GR_xE(sCRF,s,emm)) or nonmappedCRFxE[sCRF] or nonmapped_elsewhereinmodelCRFxE[sCRF] or sum((s,categoryENS,GSR_ag,purpose,energy19),sCRF_2_sENS2GR_e(sCRF,categoryENS,GSR_ag,purpose,energy19,s))) ,KF_emm_[emm,sCRF,t]) 
			- sum((emm,sCRF), KF_emm[emm,sCRF,t]);
        Abort$(abs(tjek) > 1e-6) tjek, "All emissions do not pass through (or too many pass through) the mapping sCRF_2_sENS2GR_xE combined with nonmappedCRFxE";
        );

	
#Emission coefficients 

	emissions_ENS[t,sENSny,ENS32,GSR] = KF_EmmKoeff[ENS32,t] * KF25_energybalance_ENS[t,sENSny,ENS32,GSR];


	#We aggregate emission-coefficients based on an assumption of same distribution of fuel use across sectors and purposes. This could be refined by calculating on KF25_energybalance_ENS and distributing according to mapping.
	KF_EmmKoeff[ENS32,t]$(t.val > 2035)    = KF_EmmKoeff[ENS32,'2035']; 

	KF_EmmKoeff_[energy19,t]$(sum(eENS2GR$ene192eENS2GR(energy19,eENS2GR), sum((ENS32,eENS2DST,sENSny,GSR)$(ENS322eENS2DST(ENS32, eENS2DST) and eENS2DST2eENS2GR(eENS2DST,eENS2GR)), KF25_energybalance_ENS[t,sENSny,ENS32,GSR])))
								 = sum(eENS2GR$ene192eENS2GR(energy19,eENS2GR),
								  sum((ENS32,eENS2DST,sENSny,GSR)$(ENS322eENS2DST(ENS32, eENS2DST) and eENS2DST2eENS2GR(eENS2DST,eENS2GR)), KF_EmmKoeff[ENS32,t]*KF25_energybalance_ENS[t,sENSny,ENS32,GSR])
								 /sum((ENS32,eENS2DST,sENSny,GSR)$(ENS322eENS2DST(ENS32, eENS2DST) and eENS2DST2eENS2GR(eENS2DST,eENS2GR)), KF25_energybalance_ENS[t,sENSny,ENS32,GSR]));

	KF_EmmKoeff_[energy19,t]$(t.val > 2030) = KF_EmmKoeff_[energy19,'2030'];

#-----------------------------------------------------------------------------------------------#
# Priser
#-----------------------------------------------------------------------------------------------#
	
	#Some useful mappings are made (should be moved to intERACT.sets.gms maybe...)
	set ENS32_2_e19(ENS32,energy19);
	ENS32_2_e19(ENS32,energy19) = yes$(sum((eENS2GR,eENS2DST), ene192eENS2GR(energy19, eENS2GR) and ENS322eENS2DST(ENS32, eENS2DST) and eENS2DST2eENS2GR(eENS2DST,eENS2GR)));

	set sENSny2s_delcost(sENSny,s);
	sENSny2s_delcost(sENSny,s) = yes$(sum((categoryENS,purpose,GSR_ag,energy19), sENS2GR(categoryENS,GSR_ag,purpose,energy19,s) and categoryENS2sENSny(categoryENS,sENSny)) and sum((ens32,t),KF25_delcost_ENS32[sENSny,ENS32,t]));

	#Now base-priecs are mapped to the model. They are mappped as the consumption weighted averages, i.e. multiplied by KF25_energybalance_ENS in the numerator
	KF25_pE_supply[energy19,t]$(sum((sENSny,GSR,ENS32)$(ENS32_2_e19(ENS32,energy19) and not nonpricedenergy[energy19]), KF25_energybalance_ENS[t,sENSny,ENS32,GSR])) 
														 = sum((sENSny,GSR,ENS32)$(ENS32_2_e19(ENS32,energy19) and not nonpricedenergy[energy19]), KF25_energybalance_ENS[t,sENSny,ENS32,GSR] * KF25_baseprice_ENS32[ENS32,t])
														  /sum((sENSny,GSR,ENS32)$(ENS32_2_e19(ENS32,energy19) and not nonpricedenergy[energy19]), KF25_energybalance_ENS[t,sENSny,ENS32,GSR]);									

	#Testing mapped prices 
	PARAMETER test_pE_supply[energy19,t], max_pE_supply[energy19,t], min_pE_supply[energy19,t];
	
	max_pE_supply[energy19,t] = smax(ENS32_2_e19(ENS32,energy19), KF25_baseprice_ENS32[ENS32,t]) + 0.01;
	min_pE_supply[energy19,t] = smin(ENS32_2_e19(ENS32,energy19), KF25_baseprice_ENS32[ENS32,t]) -0.01;
	test_pE_supply[energy19,t]$(KF25_pE_supply[energy19,t]> max_pE_supply[energy19,t] or KF25_pE_supply[energy19,t]<min_pE_supply[energy19,t]) = KF25_pE_supply[energy19,t];

	LOOP((energy19,t)$(test_pE_supply[energy19,t]),
		ABORT$(abs(test_pE_supply[energy19,t])>1e-4) 'Base-prices are not mapped correctly';
		);

	KF25_pE_supply['Natural gas (extraction)',t] = KF25_pE_supply['Natural gas incl. biongas',t];
	KF25_pE_supply['el from y and m',t] = KF25_pE_supply['Electricity',t];
	
	#Delivery-costs, hvor der er energivarer i data.
	KF25_CostDel_RE[energy19,s,t]$(sum((sENSny,GSR,ENS32)$(ENS32_2_e19(ENS32,energy19) and sENSny2s_delcost(sENSny,s) and not nonpricedenergy[energy19]),  KF25_energybalance_ENS[t,sENSny,ENS32,GSR])) 
															 = sum((sENSny,GSR,ENS32)$(ENS32_2_e19(ENS32,energy19) and sENSny2s_delcost(sENSny,s) and not nonpricedenergy[energy19]),  KF25_energybalance_ENS[t,sENSny,ENS32,GSR] * KF25_delcost_ENS32[sENSny,ENS32,t])
 															  /sum((sENSny,GSR,ENS32)$(ENS32_2_e19(ENS32,energy19) and sENSny2s_delcost(sENSny,s) and not nonpricedenergy[energy19] ), KF25_energybalance_ENS[t,sENSny,ENS32,GSR]);

	#Delivery-costs, hvor der ikke er energivarer er bare aritmetisk gennemsnit af delivery costs
	KF25_CostDel_RE[energy19,s,t]$((sum((sENSny,GSR,ENS32)$(ENS32_2_e19(ENS32,energy19) and sENSny2s_delcost(sENSny,s) and not nonpricedenergy[energy19]),  KF25_energybalance_ENS[t,sENSny,ENS32,GSR])=0)
																	and sum((sENSny,GSR,ENS32)$(ENS32_2_e19(ENS32,energy19) and sENSny2s_delcost(sENSny,s) and not nonpricedenergy[energy19]), KF25_delcost_ENS32[sENSny,ENS32,t]))
		=  sum((sENSny,GSR,ENS32)$(ENS32_2_e19(ENS32,energy19) and sENSny2s_delcost(sENSny,s) and not nonpricedenergy[energy19]), KF25_delcost_ENS32[sENSny,ENS32,t])/
			 sum((sENSny,GSR,ENS32)$(ENS32_2_e19(ENS32,energy19) and sENSny2s_delcost(sENSny,s) and not nonpricedenergy[energy19]), 1);	

	#Delivery costs for households
	KF25_CostDel_CE[energy19,t] = KF25_CostDel_RE[energy19,'68203',t];


	#Testing delivery costs
	PARAMETER test_CostDel_RE[energy19,s,t], max_CostDel_RE[energy19,s,t], min_CostDel_RE[energy19,s,t];
	 
		#First of all a mapping is created where energy-goods are transferred 1:1 between ENS32 and energy19. In those cases, it is easy to evaluate if the mappings have transferred prices correctly.
		set directmappingENS32sENSny_2_energy19s(s,energy19);
		directmappingENS32sENSny_2_energy19s(s,energy19)$(sum((ENS32,sENSny)$(sENSny2s_delcost(sENSny,s) and ENS32_2_e19(ENS32,energy19)), 1) = 1) = yes;

		#For the 1:1 mappings of energy we now subtract the ENS32 price from the energy19-price. The difference should equal zero if everything has gone well.
		test_CostDel_RE[energy19,s,t]$(t.val >=2019 and directmappingENS32sENSny_2_energy19s(s,energy19)) = KF25_CostDel_RE[energy19,s,t] - sum((ENS32,sENSny)$(ENS32_2_e19(ENS32,energy19) and sENSny2s_delcost(sENSny,s)), KF25_delcost_ENS32[sENSny,ENS32,t]);
		
		#Now, for energy-prices that do not have a 1:1 energy/sector mapping the criteria is that the mapped price should lie within the maximum and minimum price of the sENSny x ENS32 cluster that is mapped.
		
		#First we compute maximum price for a cluster
		max_CostDel_RE[energy19,s,t]$(t.val >=2019 and not directmappingENS32sENSny_2_energy19s(s,energy19) and sum(ENS32,ENS32_2_e19(ENS32,energy19))) =
				smax((ENS32,sENSny)$(ENS32_2_e19(ENS32,energy19) and sENSny2s_delcost(sENSny,s)), KF25_delcost_ENS32[sENSny,ENS32,t])+0.01; #adding and subtracting 0.01 because of numerical imprecision

		#We remove -inf (the smax yields -inf when there is no entry)
		max_CostDel_RE[energy19,s,t]$(max_CostDel_RE[energy19,s,t]=-inf) = 0;

		#Then we compute the maximum price for sENSny x ENS32 cluster.
		min_CostDel_RE[energy19,s,t]$(t.val >=2019 and not directmappingENS32sENSny_2_energy19s(s,energy19) and sum(ENS32,ENS32_2_e19(ENS32,energy19))) =
				smin((ENS32,sENSny)$(ENS32_2_e19(ENS32,energy19) and sENSny2s_delcost(sENSny,s)), KF25_delcost_ENS32[sENSny,ENS32,t])-0.01; 

		#Remove inf
		min_CostDel_RE[energy19,s,t]$(min_CostDel_RE[energy19,s,t]=inf) = 0;
		test_CostDel_RE[energy19,s,t]$(t.val >=2019 and not directmappingENS32sENSny_2_energy19s(s,energy19) and sum(ENS32,ENS32_2_e19(ENS32,energy19)) 
																										and (KF25_CostDel_RE[energy19,s,t]>max_CostDel_RE[energy19,s,t] or KF25_CostDel_RE[energy19,s,t]<min_CostDel_RE[energy19,s,t])) = KF25_CostDel_RE[energy19,s,t];

		#Now we can test the mapped prices. In all cases the parameter test_delCostre should equal zero if everything has gone well. We set a tolerance of 1e-4.
		LOOP((energy19,s,t), 
			ABORT$(abs(test_CostDel_RE[energy19,s,t])>1e-4) 'Aggregation of delivery costs to energy19-level has either a price that is not mapped 1:1 correctly or an aggregated price that exceeds its smin/smax correspondent';
		);

		
		#Gas-tariffs 
		KF25_CostDel_RE_natgas[purpose,s,t]$(sum((sENSny,GSR)$sENSny2s_delcost(sENSny,s), KF25_energybalance_ENS[t,sENSny,'Naturgas',GSR])) 
																				=  sum((sENSny,GSR)$sENSny2s_delcost(sENSny,s), KF25_gastariffs_ENS32[sENSny,purpose,'Naturgas',t] * KF25_energybalance_ENS[t,sENSny,'Naturgas',GSR])
																					/sum((sENSny,GSR)$sENSny2s_delcost(sENSny,s), KF25_energybalance_ENS[t,sENSny,'Naturgas',GSR]);

		KF25_CostDel_RE_natgas[purpose,s,t]$(not sum((sENSny,GSR)$sENSny2s_delcost(sENSny,s), KF25_energybalance_ENS[t,sENSny,'Naturgas',GSR]) and sum((sENSny,GSR)$sENSny2s_delcost(sENSny,s), KF25_gastariffs_ENS32[sENSny,purpose,'Naturgas',t])) 
																				=  sum((sENSny,GSR)$sENSny2s_delcost(sENSny,s), KF25_gastariffs_ENS32[sENSny,purpose,'Naturgas',t])
																					/sum((sENSny,GSR)$sENSny2s_delcost(sENSny,s), 1);




	#Moving delivery costs to base price for electricity for distribution, district heat and natural gas
		KF25_pE_supply['Electricity',t]$(sum(s, sum((ENS32,sENSny,GSR)$(ENS32_2_e19(ENS32,'electricity') and sENSny2s_delcost(sENSny,s) and not nonpricedenergy['electricity']),  KF25_energybalance_ENS[t,sENSny,ENS32,GSR]))) 
																		= KF25_pE_supply['Electricity',t] +
																			sum(s, sum((ENS32,sENSny,GSR)$(ENS32_2_e19(ENS32,'electricity') and sENSny2s_delcost(sENSny,s) and not nonpricedenergy['electricity']),  KF25_energybalance_ENS[t,sENSny,ENS32,GSR])*KF25_CostDel_RE['electricity',s,t])
																		 /sum(s, sum((ENS32,sENSny,GSR)$(ENS32_2_e19(ENS32,'electricity') and sENSny2s_delcost(sENSny,s) and not nonpricedenergy['electricity']),  KF25_energybalance_ENS[t,sENSny,ENS32,GSR]));
		

		KF25_pE_supply['District heat',t]$(sum(s, sum((ENS32,sENSny,GSR)$(ENS32_2_e19(ENS32,'District heat') and sENSny2s_delcost(sENSny,s) and not nonpricedenergy['District heat']),  KF25_energybalance_ENS[t,sENSny,ENS32,GSR])))
																			 = KF25_pE_supply['District heat',t] +
																			sum(s, sum((ENS32,sENSny,GSR)$(ENS32_2_e19(ENS32,'District heat') and sENSny2s_delcost(sENSny,s) and not nonpricedenergy['District heat']),  KF25_energybalance_ENS[t,sENSny,ENS32,GSR])*KF25_CostDel_RE['District heat',s,t])
																			 /sum(s, sum((ENS32,sENSny,GSR)$(ENS32_2_e19(ENS32,'District heat') and sENSny2s_delcost(sENSny,s) and not nonpricedenergy['District heat']),  KF25_energybalance_ENS[t,sENSny,ENS32,GSR]));

		KF25_pE_supply['Biogas',t]$(sum(s, sum((ENS32,sENSny,GSR)$(ENS32_2_e19(ENS32,'Biogas') and sENSny2s_delcost(sENSny,s) and not nonpricedenergy['Biogas']),  KF25_energybalance_ENS[t,sENSny,ENS32,GSR])))
																			 = KF25_pE_supply['Biogas',t] +
																			sum(s, sum((ENS32,sENSny,GSR)$(ENS32_2_e19(ENS32,'Biogas') and sENSny2s_delcost(sENSny,s) and not nonpricedenergy['Biogas']),  KF25_energybalance_ENS[t,sENSny,ENS32,GSR])*KF25_CostDel_RE['Biogas',s,t])
																			 /sum(s, sum((ENS32,sENSny,GSR)$(ENS32_2_e19(ENS32,'Biogas') and sENSny2s_delcost(sENSny,s) and not nonpricedenergy['Biogas']),  KF25_energybalance_ENS[t,sENSny,ENS32,GSR]));

		KF25_pE_supply['Natural gas incl. biongas',t]$(sum(s, sum((ENS32,sENSny,GSR)$(ENS32_2_e19(ENS32,'Biogas') and sENSny2s_delcost(sENSny,s) and not nonpricedenergy['Biogas']),  KF25_energybalance_ENS[t,sENSny,ENS32,GSR])))
																			 = KF25_pE_supply['Natural gas incl. biongas',t] +
																			 	sum((s,purpose),  sum((categoryENS,GSR_ag)$sENS2GR(categoryENS,GSR_ag,purpose,'Natural gas incl. biongas',s), KF25_energybalance_ENS_[categoryENS,'Natural gas incl. biongas',GSR_ag,t]) * KF25_CostDel_RE_natgas[purpose,s,t])
																			/ sum((s,purpose),  sum((categoryENS,GSR_ag)$sENS2GR(categoryENS,GSR_ag,purpose,'Natural gas incl. biongas',s), KF25_energybalance_ENS_[categoryENS,'Natural gas incl. biongas',GSR_ag,t]));	



	#We now create base-prices 

		KF25_pRE_base[purpose,energy19,s,t] = KF25_pE_supply[energy19,t] + KF25_CostDel_RE[energy19,s,t] + KF25_CostDel_RE_natgas[purpose,s,t]$(sameas[energy19,'Natural gas incl. biongas']);
		
		KF25_pCE_base[purpose,energy19,t] = KF25_pE_supply[energy19,t] + KF25_CostDel_CE[energy19,t] + KF25_CostDel_RE_natgas[purpose,'68203',t]$(sameas[energy19,'natural gas incl. biongas']); #68203 is housing sector, which is hh.

		#For energy-goods where the delivery costs is contained in base price we remove delivery-cost parameter entry
		KF25_CostDel_RE['electricity',s,t] = 0; KF25_CostDel_CE['electricity',t] = 0;
		KF25_CostDel_RE['district heat',s,t] = 0; KF25_CostDel_CE['district heat',t] = 0;
		KF25_CostDel_RE['biogas',s,t] = 0; KF25_CostDel_CE['biogas',t] = 0;
		KF25_CostDel_RE['natural gas incl. biongas',s,t] = 0;

		#Adding missing energy
		KF25_pRE_base[purpose,'jet petroleum',s,t]                                  				   = KF25_pRE_base[purpose,'gasoline for transport',s,t]; 
		KF25_pRE_base[purpose,'Bunkering of Danish operated vessels on foreign territory',s,t] = KF25_pRE_base[purpose,'Oil products',s,t];  
		KF25_pRE_base[purpose,'Bunkering of Danish operated planes on foreign territory',s,t]  = KF25_pRE_base[purpose,'Jet petroleum',s,t];
		KF25_pRE_base[purpose,'Bunkering of Danish operated trucks on foreign territory',s,t]  = KF25_pRE_base[purpose,'Diesel for transport',s,t];


		#Scaling to 1000 kroner per GJ
		KF25_pRE_base[purpose,energy19,s,t] = KF25_pRE_base[purpose,energy19,s,t]/1000;
		KF25_pCE_base[purpose,energy19,t]   = KF25_pCE_base[purpose,energy19,t]/1000;
		KF25_CostDel_RE[energy19,s,t] 			= KF25_CostDel_RE[energy19,s,t]/1000;
		KF25_CostDel_CE[energy19,t]         = KF25_CostDel_CE[energy19,t]/1000;	
		KF25_pE_supply[energy19,t] = KF25_pE_supply[energy19,t]/1000;
		# KF25_pETS[t]/1000
		# KF25_pETS2[t]/1000

		#To inflation adjusted prices
		# KF25_pRE_base[purpose,energy19,s,t]$KF25_deflator[t] = KF25_pRE_base[purpose,energy19,s,t]/KF25_deflator[t]*inf_factor[t];
		# KF25_pCE_base[purpose,energy19,t]$KF25_deflator[t]   = KF25_pCE_base[purpose,energy19,t]/KF25_deflator[t]*inf_factor[t];
		# KF25_CostDel_RE[energy19,s,t]$KF25_deflator[t] 			= KF25_CostDel_RE[energy19,s,t]/KF25_deflator[t]*inf_factor[t];
		# KF25_CostDel_CE[energy19,t]$KF25_deflator[t]         = KF25_CostDel_CE[energy19,t]/KF25_deflator[t]*inf_factor[t];	
		# KF25_pE_supply[energy19,t]$KF25_deflator[t]				  = KF25_pE_supply[energy19,t]/KF25_deflator[t]*inf_factor[t];
		# KF25_pETS[t]$KF25_deflator[t]	= KF25_pETS[t]/KF25_deflator[t]*inf_factor[t];
		# KF25_pETS2[t]$KF25_deflator[t] = KF25_pETS2[t]/KF25_deflator[t]*inf_factor[t];

		KF25_pRE_base[purpose,energy19,s,t]$KF25_deflator[t] = KF25_pRE_base[purpose,energy19,s,t]*inf_factor[t];
		KF25_pCE_base[purpose,energy19,t]$KF25_deflator[t]   = KF25_pCE_base[purpose,energy19,t]*inf_factor[t];
		KF25_CostDel_RE[energy19,s,t]$KF25_deflator[t] 			= KF25_CostDel_RE[energy19,s,t]*inf_factor[t];
		KF25_CostDel_CE[energy19,t]$KF25_deflator[t]         = KF25_CostDel_CE[energy19,t]*inf_factor[t];	
		KF25_pE_supply[energy19,t]$KF25_deflator[t]				  = KF25_pE_supply[energy19,t]*inf_factor[t];
		KF25_pETS[t]$KF25_deflator[t]	= KF25_pETS[t]*inf_factor[t];
		KF25_pETS2[t]$KF25_deflator[t] = KF25_pETS2[t]*inf_factor[t];


		#Extending beyond 2050 (to use parameters as dummies)	
		KF25_pRE_base[purpose,energy19,s,t]$(t.val > 2050) = KF25_pRE_base[purpose,energy19,s,'2050'];
		KF25_pCE_base[purpose,energy19,t]$(t.val > 2050) =KF25_pCE_base[purpose,energy19,'2050']; 
		KF25_CostDel_RE[energy19,s,t]$(t.val > 2050) = KF25_CostDel_RE[energy19,s,'2050'];
		KF25_CostDel_CE[energy19,t]$(t.val > 2050) =KF25_CostDel_CE[energy19,'2050']; 
		KF25_pE_supply[energy19,t]$(t.val > 2050) = KF25_pE_supply[energy19,'2050'];
		KF25_pETS[t]$(t.val > 2050) = KF25_pETS['2050']; 
		KF25_pETS2[t]$(t.val > 2050) = KF25_pETS2['2050']; 


