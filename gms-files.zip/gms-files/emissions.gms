# ======================================================================================================================
# Emissions
# ======================================================================================================================

# ======================================================================================================================
# Variable definition
# ======================================================================================================================


$IF %stage% == "variables":

  $GROUP G_qEmm
      qEmmProdxE[s,t,emm_eq]$(d1EmmProdxE[s,t,emm_eq])                                                                    "Non-energy production emissions"
      qEmmConsxE[t,emm_eq]$(d1EmmConsxE[t, emm_eq])                                                                       "Household non-energy related emissions"
      qEmmBorderTrade[t,emm_eq]                                                                                           "Border-trade"
      qEmmDomesticAviationDCE[t]                                                                                          "Emissions from domestic aviation in CRF-tables from DCE"
      qEmmFromCRFnotinModel[t,emm_eq,accounts]                                                                            "CRF-categories not modelled"
  ;


    $GROUP G_emissions_coefficients
      uEmmProdxE[s, t, emm]$(tx0[t] and d1EmmProdxE[s,t,emm])                                                             "Production Non-energy emission coefficients"
      uEmmConsxE[t, emm]$(tx0[t] and d1EmmConsxE[t,emm])                                                                  "Consumption Non-energy emission coefficients"
      uEmmProdE[s,t,emm,energy19]$(tx0[t] and sum(purpose, d1EmmProdE[s,t,emm,purpose, energy19]))                        "Emission coefficients - production"
      uEmmConsE[t,emm,energy19]$(tx0[t] and sum(purpose, d1qCE[purpose,energy19,t]) and sum(purpose, d1EmmConsE[t,emm,purpose,energy19]))     "Emission coefficients - consumption"
            
      sBioNatgas[purpose,r,t]$(tx0[t] and (d1EmmProdE[r,t,'CO2ubio',purpose,'Natural gas incl. biongas'] xor d1EmmProdE[r,t,'CO2bio',purpose,'Natural gas incl. biongas']))                     "Ha en god dag"
      sBioNatgas[purpose,r,t]$(tDataEnd[t] and not tx0[t] and d1EmmProdE[r,t,'CO2ubio',purpose,'Natural gas incl. biongas'] and d1EmmProdE[r,t,'CO2bio',purpose,'Natural gas incl. biongas'])   ""
      sBionatgasC[purpose,t]$(tDataEnd[t] and d1EmmConsE[t,'CO2ubio',purpose,'Natural gas incl. biongas'] and d1EmmConsE[t,'CO2bio',purpose,'Natural gas incl. biongas'])    ""
      sBionatgasX[t] "Bionatural-gas share in exported gas"	
      sBioNatgasX_inp[t] ""

      sBioNatgasAvg[t]$(tx0[t]) ""
      sBioNatGasAvgAdj[t]$(tx0[t]) "What it do, didgeridoo"
      adj_sBioNatGas[purpose,s] ""
      adj_sBioNatGasC[purpose] ""
      adjqLE[t]  ""
      jEmmTot_UNFCCC_LULUCF_Calib2KF[t] "Calibration parameter in calibratition to Climate Outlook. Should ideally be zero."                                                                                                                                                                          
  ;


  $GROUP G_qEmm_aggregates
      qEmmProdE[s,t,emm_eq,purpose,energy19]$(d1EmmProdE[s,t,emm_eq,purpose,energy19] and emm[emm_eq])                                                           "Production energy related emissions"
      qEmmProdE[s,t,emm_eq,purpose,energy19]$(sameas[emm_eq,'CO2e'] and (d1EmmProdE[s,t,'CO2e',purpose,energy19] or d1CCSbio[purpose,energy19,s,t,'CCSbio']))   ""

      qEmmConsE[t,emm_eq,purpose,energy19]$(tx0[t] and d1EmmConsE[t,emm_eq,purpose,energy19] and d1qCE[purpose,energy19,t] and not sameas[emm_eq,'CCSbio'])     "Household energy related emissions"     
        
      qEmmProdEP[s,t,emm,energy19]$(sum(purpose,d1EmmProdE[s,t,emm,purpose, energy19]) )              "Production energy related emissions not split by purpose"
      qEmmConsEP[t,emm,energy19]$(sum(purpose, d1EmmConsE[t,emm,purpose,energy19]))                   "Household energy related emissions not split by purpose"
      
      qEmmProdS[s,t,emm_eq,accounts]$(d1EmmProdS[s,t,emm_eq,accounts])                                "Sector secific emissions "
      qEmmProd[t,emm_eq,accounts]$(d1EmmProd[t,emm_eq] )                                              "Production-related total emissions"
                                  
      qEmmCons[t,emm_eq,accounts]$(d1EmmCons[t,emm_eq])                                               "Total emissions from consumption"
                                  
      qEmmE[t,emm_eq,accounts]$(d1EmmE[t,emm_eq,accounts] )                                           "Total energy related emissions"    
      qEmmxE[t,emm_eq,accounts]$(d1EmmxE[t,emm_eq,accounts] )                                         "Total non-energy related emissions"

      qEmmCO2ETS[r,t]$(d1CO2_ETS[r,t])                                                                "Total ETS-encompassed emissions by sector "
                                  
      qEmmTot[t,emm_eq,accounts_all]$(accounts[accounts_all] and d1EmmTot[t,emm_eq,accounts_all])      ""
      qEmmTot[t,emm_eq,accounts_all]$(accounts_lulucf[accounts_all] and d1EmmTot[t,emm_eq,accounts_all] and sameas(emm_eq,'CO2e')) ""
  ;  

  $GROUP G_qEmm_CCS
      qGrossEmmE[s,t,emm,purpose,energy19]$(d1EmmProdE[s,t,emm,purpose,energy19] and (sameas[emm,'CO2ubio'] or sameas[emm,'CO2bio']))         "Total energy related emissions (excl. CCS)"
      qGrossEmmxE[s,t,emm]$(d1EmmProdxE[s,t,emm] and sameas[emm,'CO2ubio'] and sum(techCCS, d1thetaCCSxE[techCCS,s,t,'CO2ubio']))             "Total non-energy related emissions (excl. CCS)"
      qGrossEmmE_REE[purpose,energy19a,energy19,s,t,emm]$(tx0[t] and d1qREE[purpose,energy19a,energy19,s,t] and d1EmmProdE[s,t,emm,purpose,energy19] and sum(techCCS, d1thetaCCS[techCCS,purpose,energy19,s,t,emm]))  ""
      qEmmProdE_CCSubio[s,t,purpose,energy19]$(d1EmmProdE[s,t,'CO2ubio',purpose,energy19] and sum(techCCS,d1thetaCCS[techCCS,purpose,energy19,s,t,'CO2ubio']))   "CCS on energy related CO2ubio emissions"
      qEmmProdE$(d1CCSbio[purpose,energy19,s,t,emm_eq] and sameas[emm_eq,'CCSbio'])                                                           "CCS on energy related CO2bio emissions"
      qEmmProdxE_CCSubio[s,t]$(tx0[t] and d1EmmProdxE[s,t,'CO2ubio'] and sum(techCCS,d1thetaCCSxE[techCCS,s,t,'CO2ubio']))                    "CCS on non-energy related CO2ubio emissions"
      sumqEmmCCSubio[s,t]$(d1EmmProdE_sumPE[s,'CO2ubio',t] and (sum(techCCS, sum(purpose, sum(energy19, d1thetaCCS[techCCS,purpose,energy19,s,t,'CO2ubio'])) or d1thetaCCSxE[techCCS,s,t,'CO2ubio'])))    "Aggregate of CCS on CO2ubio emissions"
      sumqEmmCCSbio[s,t]$(sum(purpose, sum(energy19, d1CCSbio[purpose,energy19,s,t,'CCSbio'])))  "Aggregate of CCS on CO2bio emissions"# or sum(techCCS, d1thetaCCSxE[techCCS,s,t,'CO2bio'])))          
  ;         

  $GROUP G_bionatgas_exports 
    qXE_bionatgas[t] ""
    ;                     


$ENDIF

$IF %stage% == "groupcompilation":

  $GROUP G_emissions_endo
    G_qEmm,-qEmmBorderTrade, -qEmmDomesticAviationDCE, -qEmmFromCRFnotinModel   
    G_qEmm_aggregates
    G_qEmm_CCS

    sBioNatgas$(tx0[t] and not tDataEnd[t] and (d1EmmProdE[r,t,'CO2ubio',purpose,'Natural gas incl. biongas'] and d1EmmProdE[r,t,'CO2bio',purpose,'Natural gas incl. biongas']))
    sBioNatgasAvg[t]$(tx0[t])
    sBioNatGasAvgAdj[t]$(tx0[t])
    sBioNatGasC$(tx0[t] and not tDataEnd[t] and (d1EmmConsE[t,'CO2ubio',purpose,'Natural gas incl. biongas'] and d1EmmConsE[t,'CO2bio',purpose,'Natural gas incl. biongas']))
    sBionatgasX$(tx0[t] and t.val>2023)
    sBionatgasX_inp$(tx0[t] and t.val>2023)
    qXE_bionatgas$(tx0[t] and t.val>2023)
    #  adjqLE[t]
    qDbionatgas[t] ""
    qSbionatgas[t] ""
    #  qLE$(tx0[t] and d1vLE[purpose,energy19,t] and sameas[energy19,'natural gas incl. biongas'] and sameas[purpose,'unspecified'] and t.val>2029)
  ;


  $GROUP G_emissions_endo
    G_emissions_endo$(tx0[t])
    adj_sBioNatGas
    adj_sBioNatGasC

  ;

  $GROUP G_emissions_exo
    G_emissions_coefficients

    qKELBM[s,t]$(tx0[t] and sum(emm,d1EmmProdxE[s,t,emm]))

    GWP[emm]          "GWP conversion"

    qREgj[purpose,energy19,s,t]$(tx0[t] and sum(emm,d1EmmProdE[r,t,emm,purpose, energy19]))
    qREE[purpose,energy19a,energy19,s,t]$(tx0[t] and d1qREE[purpose,energy19a,energy19,s,t] and sum(emm, d1EmmProdE[s,t,emm,purpose,energy19]) and sum(emm, (sum(techCCS, d1thetaCCS[techCCS,purpose,energy19,s,t,emm]))))   
    qCHH['ctot', t]$(tx0[t] and sameas[c_, 'cTot'])
    qCE[purpose,energy19,t]$(tx0[t] and d1qCE[purpose,energy19,t] and sum(emm, d1EmmConsE[t,emm,purpose,energy19]))       "Energy consumption - consumers"
    qEmmAgrAnimalsOther[emmtype,t,emm_eq]$(tx0[t] and d1EmmAgrAniOther[emmtype,t,emm_eq] and not t.val=2019)


    qEmmLULUCF[t]$(tx0[t])        "Total LULUCF emissions"
    qREgj['process_special','biogas','35002',t]$(tx0[t] and not tDataEnd[t] and sameas[purpose,'process_special'] and sameas[energy19,'biogas'] and sameas[r,'35002'])


    #E_sBioNatGasAvg and E_sBioNatGasAvgAdj
    qREgj$(tx0[t] and d1qREgj[purpose,energy19,r,t] and sameas[energy19,'Natural gas incl. biongas'])
    qCE$(tx0[t] and d1qCE[purpose,energy19,t] and sameas[energy19,'Natural gas incl. biongas'])
    -adj_sBioNatGas
    -adj_sBioNatGasC

    sBioNatgas$((d1EmmProdE[r,t,'CO2ubio',purpose,'Natural gas incl. biongas']) and (d1EmmProdE[r,t,'CO2bio',purpose,'Natural gas incl. biongas']))
    sBionatgasC$((d1EmmConsE[t,'CO2ubio',purpose,'Natural gas incl. biongas']) and (d1EmmConsE[t,'CO2bio',purpose,'Natural gas incl. biongas']))

    sBioNatgas$((t0[t] or tDataEnd[t]) and (d1EmmProdE[r,t,'CO2ubio',purpose,'Natural gas incl. biongas'] and d1EmmProdE[r,t,'CO2bio',purpose,'Natural gas incl. biongas']))
    sBioNatgasC$((t0[t] or tDataEnd[t]) and (d1EmmConsE[t,'CO2ubio',purpose,'Natural gas incl. biongas'] and d1EmmConsE[t,'CO2bio',purpose,'Natural gas incl. biongas']))

    uEOPProdE[purpose,energy19,s,t,emm]$(tx0[t] and d1EmmProdE[s,t,emm,purpose, energy19])                              
    uEOPProdxE[s,t,emm]$(tx0[t] and d1EmmProdxE[s,t,emm])                                                               

    sBionatgasX$(tx0[t] and t.val<=2023)
    qXE_bionatgas$(tx0[t] and t.val<=2023)
    qXE['unspecified','natural gas incl. biongas',t]


    #E_qEmmE
    qEmmBorderTrade
    qEmmDomesticAviationDCE
    qEmmFromCRFnotinModel
  ;

  $GROUP G_emissions_non_flat_initial_values
    uEmmProdE$(uEmmHardCoded[emm,energy19]) #For emissions in forecast we use technical coefficients rather than imputed coefficients
    qEmmBorderTrade
    qEmmDomesticAviationDCE
    qEmmFromCRFnotinModel
  ;

  $GROUP G_emissions_data
     qEmmProdEP[s,t,emm,energy19]$(sum(purpose,d1EmmProdE[s,t,emm,purpose, energy19]))    "Production energy related emissions not split by purpose (this is the real data level of emissions - RAS-afstemning means that emisions split by purpose change during calibration)"
     qEmmConsEP[t,emm,energy19]$(sum(purpose, d1EmmConsE[t,emm,purpose,energy19]))        "Household energy related emissions not split by purpose (this is the real data level of emissions - RAS-afstemning means that emisions split by purpose change during calibration)"
     qEmmProdxE[s,t,emm_eq]$(d1EmmProdxE[s,t,emm_eq])                                     "Non-energy production emissions"
     qEmmConsxE[t,emm_eq]$(d1EmmConsxE[t, emm_eq])                                        "Household non-energy related emissions"                          
  ;

  $PGROUP PGROUP_emissions_NonFlat_Dummies
    d1EmmFromCRFnotinModel
  ;

$ENDIF


# ====================================================================================================================
# Equations
# ====================================================================================================================
$IF %stage% == "equations":
  
  $BLOCK B_emissions
  # //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  # //////////////////////////////       EMISSIONS FROM THE DANISH ECONOMY       /////////////////////////////////////
  # //////////////////////////////////////////////////////////////////////////////////////////////////////////////////

  # ------------------------------------------------------------------------------------------------------------------
  # Emissions from production
  # ------------------------------------------------------------------------------------------------------------------

  E_qEmmProdxE[s,t,emm]$(tx0[t] and d1EmmProdxE[s,t,emm])..                 
      qEmmProdxE[s,t,emm] =E= (qKELBM[s,t]/growth_factor[t])*uEmmProdxE[s,t,emm]*uEOPProdxE[s,t,emm];

  E_qEmmProdxE_CO2e[s,t]$(tx0[t] and d1EmmProdxE[s,t,'CO2e'])..    
    qEmmProdxE[s,t, 'CO2e'] =E= sum(emm$(d1EmmProdxE[s,t,emm]), qEmmProdxE[s,t,emm]*GWP[emm]);

  # Emissions excluding natural gas
  E_qEmmProdE_exnatgas[s,t,emm,purpose,energy19]$(tx0[t] and d1EmmProdE[s,t,emm,purpose,energy19] and not sameas[energy19,'Natural gas incl. biongas'])..                 
      qEmmProdE[s,t,emm,purpose,energy19] =E= ((qREgj[purpose,energy19,s,t]/growth_factor[t]) * uEmmProdE[s,t,emm,energy19]*uEOPProdE[purpose,energy19,s,t,emm]);
  
  #Natural gas (incl. biongas) emissions 
   #Før 2023
   E_qEmmProdE_natgas_before23[s,t,emm,purpose,energy19]$(tx0[t] and d1EmmProdE[s,t,emm,purpose,energy19] and sameas[energy19,'Natural gas incl. biongas'] and t.val <= 2023)..
       qEmmProdE[s,t,emm,purpose,energy19] =E= (qREgj[purpose,energy19,s,t]/growth_factor[t] * uEmmProdE[s,t,emm,energy19]*uEOPProdE[purpose,energy19,s,t,emm])$(not sameas[emm,'CO2ubio'] and not sameas[emm,'CO2bio'])
                                           +  ( sBioNatgas[purpose,s,t]   * qREgj[purpose,energy19,s,t]/growth_factor[t] * uEmmProdE[s,t,emm,energy19]*uEOPProdE[purpose,energy19,s,t,emm])$(sameas[emm,'CO2bio'])
                                           + ((1-sBioNatgas[purpose,s,t]) * qREgj[purpose,energy19,s,t]/growth_factor[t] * uEmmProdE[s,t,emm,energy19]*uEOPProdE[purpose,energy19,s,t,emm])$(sameas[emm,'CO2ubio']);

   #Efter 2023
   E_qEmmProdE_natgas_after23[s,t,emm,purpose,energy19]$(tx0[t] and d1EmmProdE[s,t,emm,purpose,energy19] and sameas[energy19,'Natural gas incl. biongas'] and t.val>2023)..
       qEmmProdE[s,t,emm,purpose,energy19] =E= (qREgj[purpose,energy19,s,t]/growth_factor[t] * uEmmProdE[s,t,emm,energy19]*uEOPProdE[purpose,energy19,s,t,emm])$(not sameas[emm,'CO2ubio'] and not sameas[emm,'CO2bio'])
                                            +  (qREgj[purpose,energy19,s,t]/growth_factor[t] * uEmmProdE[s,t,emm,energy19]*uEOPProdE[purpose,energy19,s,t,emm])$(sameas[emm,'CO2bio'] and d1sBioNatGas[purpose,s,t]) #If it's only bionatgas in the pipe
                                            +  (qREgj[purpose,energy19,s,t]/growth_factor[t] * uEmmProdE[s,t,emm,energy19]*uEOPProdE[purpose,energy19,s,t,emm])$(sameas[emm,'CO2ubio'] and d1sBioNatGaszero[purpose,s,t]) #If it is only non-bionatgas in the pipe
                                            +  ( sBioNatGasAvgAdj[t]   * qREgj[purpose,energy19,s,t]/growth_factor[t] * uEmmProdE[s,t,emm,energy19]*uEOPProdE[purpose,energy19,s,t,emm])$(sameas[emm,'CO2bio']  and not d1sBioNatGas[purpose,s,t])
                                            + ((1-sBioNatGasAvgAdj[t]) * qREgj[purpose,energy19,s,t]/growth_factor[t] * uEmmProdE[s,t,emm,energy19]*uEOPProdE[purpose,energy19,s,t,emm])$(sameas[emm,'CO2ubio'] and not d1sBioNatGaszero[purpose,s,t])
                                           ;




  E_qEmmProdEP[s,t,emm,energy19]$(tx0[t] and sum(purpose,d1EmmProdE[s,t,emm,purpose, energy19]))..                 
   qEmmProdEP[s,t,emm,energy19] =E= sum(purpose$(d1EmmProdE[s,t,emm,purpose,energy19]), qEmmProdE[s,t,emm,purpose,energy19]);

  E_qEmmProdE_CO2e[s,t,purpose,energy19]$(tx0[t] and (d1EmmProdE[s,t,'CO2e', purpose,energy19] or d1CCSbio[purpose,energy19,s,t,'CCSbio']))..            
    qEmmProdE[s,t,'CO2e',purpose,energy19] =E= sum(emm$(d1EmmProdE[s,t,emm,purpose,energy19]), qEmmProdE[s,t,emm,purpose,energy19]*GWP[emm]) 
                                             + qEmmProdE[s,t,'CCSbio',purpose,energy19]$(d1CCSbio[purpose,energy19,s,t,'CCSbio']);

  E_qEmmProdS[s,t,emm_eq,accounts]$(tx0[t] and d1EmmProdS[s,t,emm_eq,accounts])..  
     qEmmProdS[s,t,emm_eq,accounts] =E=
           qEmmProdxE[s,t,emm_eq]$(d1EmmProdxE[s,t,Emm_eq] and not sameas(emm_eq,'CCSbio')) 
           + sum((purpose, energy19)$(energy2accounts(energy19,accounts) and (d1EmmProdE[s,t,emm_eq,purpose,energy19] or d1CCSbio[purpose,energy19,s,t,emm_eq])), qEmmProdE[s,t,emm_eq,purpose,energy19]);

  E_qEmmProd[t,emm_eq,accounts]$(tx0[t]  and d1EmmProd[t,emm_eq])..        
     qEmmProd[t,emm_eq,accounts] =E= sum(s$(d1EmmProdS[s,t,emm_eq,accounts]), qEmmProdS[s,t,emm_eq,accounts]);

  #   ------------------------------------------------------------------------------------------------------------------
  #   Emissions from consumption
  #   ------------------------------------------------------------------------------------------------------------------

  E_qEmmConsxE[t, emm]$(tx0[t] and d1EmmConsxE[t,emm])..                        
    qEmmConsxE[t, emm] =E= (qCHH['ctot', t]/growth_factor[t])*uEmmConsxE[t, emm];

  E_qEmmConsxE_CO2e[t]$(tx0[t] and d1EmmConsxE[t,'CO2e'])..                    
    qEmmConsxE[t, 'CO2e'] =E= sum(emm$(d1EmmConsxE[t, emm]), qEmmConsxE[t, emm]$(d1EmmConsxE[t, emm])*GWP[emm]);

  E_qEmmConsE_exnatgas[t, emm, purpose, energy19]$(tx0[t] and d1EmmConsE[t,emm,purpose,energy19] and d1qCE[purpose,energy19,t] and not sameas[energy19,'Natural gas incl. biongas']).. 
    qEmmConsE[t, emm, purpose, energy19] =E=  (qCE[purpose,energy19,t]/growth_factor[t]) * uEmmConsE[t,emm,energy19];

  #Før 2023
  E_qEmmConsE_natgas_before23[t, emm, purpose, energy19]$(tx0[t] and d1EmmConsE[t,emm,purpose,energy19] and d1qCE[purpose,energy19,t] and sameas[energy19,'Natural gas incl. biongas'] and t.val<=2023).. 
    qEmmConsE[t, emm, purpose, energy19] =E=  (qCE[purpose,energy19,t]/growth_factor[t]) * uEmmConsE[t,emm,energy19]$(not sameas[emm,'CO2ubio'] and not sameas[emm,'CO2bio'])
                                          + (   sBioNatgasC[purpose,t]  * qCE[purpose,energy19,t]/growth_factor[t] * uEmmConsE[t,emm,energy19])$(sameas[emm,'CO2bio'])
                                          + ((1-sBioNatgasC[purpose,t]) * qCE[purpose,energy19,t]/growth_factor[t] * uEmmConsE[t,emm,energy19])$(sameas[emm,'CO2ubio']);

  #efter 2023
  E_qEmmConsE_natgas_after23[t, emm, purpose, energy19]$(tx0[t] and d1EmmConsE[t,emm,purpose,energy19] and d1qCE[purpose,energy19,t] and sameas[energy19,'Natural gas incl. biongas'] and t.val>2023).. 
    qEmmConsE[t, emm, purpose, energy19] =E=  (qCE[purpose,energy19,t]/growth_factor[t]) * uEmmConsE[t,emm,energy19]$(not sameas[emm,'CO2ubio'] and not sameas[emm,'CO2bio'])
                                          + (                             qCE[purpose,energy19,t]/growth_factor[t] * uEmmConsE[t,emm,energy19])$(sameas[emm,'CO2bio'] and d1sBioNatGasC[purpose,t])
                                          + (                             qCE[purpose,energy19,t]/growth_factor[t] * uEmmConsE[t,emm,energy19])$(sameas[emm,'CO2ubio'] and d1sBioNatGasCzero[purpose,t])
                                          + (sBioNatgasAvgAdj[t]        * qCE[purpose,energy19,t]/growth_factor[t] * uEmmConsE[t,emm,energy19])$(sameas[emm,'CO2bio'] and not d1sBioNatGasC[purpose,t])
                                          + ((1-sBioNatgasC[purpose,t]) * qCE[purpose,energy19,t]/growth_factor[t] * uEmmConsE[t,emm,energy19])$(sameas[emm,'CO2ubio'] and not d1sBioNatGasCzero[purpose,t]);  


  E_uEmmConsEP[t,emm,energy19]$(tx0[t] and sum(purpose, d1EmmConsE[t,emm,purpose,energy19]))..
   qEmmConsEP[t,emm,energy19] =E= sum(purpose$(d1EmmConsE[t,emm,purpose,energy19]), qEmmConsE[t,emm,purpose,energy19]);
                                
   
   
  E_qEmmConsE_CO2e[t, purpose, energy19]$(tx0[t] and d1EmmConsE[t,'CO2e',purpose,energy19])..              
    qEmmConsE[t, 'CO2e', purpose, energy19] =E= sum(emm$(d1EmmConsE[t, emm, purpose, energy19]), qEmmConsE[t, emm, purpose, energy19]*GWP[emm]);

   E_qEmmCons[t,emm_eq,accounts]$(tx0[t] and d1EmmCons[t,emm_eq])..  
   qEmmCons[t,emm_eq,accounts] =E=
         qEmmConsxE[t,emm_eq]$(d1EmmConsxE[t,Emm_eq])  +
         sum((purpose, energy19)$(energy2accounts(energy19,accounts) and d1EmmConsE[t,emm_eq,purpose,energy19]), qEmmConsE[t,emm_eq,purpose,energy19]$(d1EmmConsE[t,emm_eq,purpose,energy19]));
 
  #   ------------------------------------------------------------------------------------------------------------------
  #   Energy and non-energy emissions
  #   ------------------------------------------------------------------------------------------------------------------

  E_qEmmE[t,emm_eq,accounts]$(tx0[t] and d1EmmE[t, emm_eq,accounts])..               
    qEmmE[t,emm_eq,accounts] =E= sum((purpose, energy19, s)$(energy2accounts(energy19,accounts) and (d1EmmProdE[s,t,emm_eq,purpose,energy19] or d1CCSbio[purpose,energy19,s,t,emm_eq])), qEmmProdE[s,t,emm_eq,purpose,energy19])
                             + sum((purpose, energy19)$(energy2accounts(energy19,accounts) and d1EmmConsE[t,emm_eq,purpose,energy19] and not sameas(emm_eq,'CCSbio')), qEmmConsE[t, emm_eq, purpose, energy19])
                             + qEmmBorderTrade[t,emm_eq]$(not sameas(emm_eq,'CCSbio') and sameas[accounts,'GNA']) #Grænsehandel tæller kun med i GNA og ikke UNFCCC, jf. mail fra Niels Christian i DØR
                              -qEmmProdE['51009',t,emm_eq,'Transport','Jet petroleum']$(d1EmmProdE['51009',t,emm_eq,'Transport','Jet petroleum'] and sameas[accounts,'UNFCCC'])      # Jet petroleum tanket af danske selskaber i Danmark til udenrigsflyvning tæller ikke med i UNFCCC
                             + qEmmDomesticAviationDCE[t]$(sameas[emm_eq,'CO2e']) #Jf. mail fra Steffen ENS tilføjer DCE nogle udledninger her.
                             ;

  E_qEmmxE[t,emm_eq,accounts]$(tx0[t]  and d1EmmxE[t, emm_eq,accounts])..       
    qEmmxE[t,emm_eq,accounts] =E= sum(s$d1EmmProdxE[s,t,emm_eq], qEmmProdxE[s,t,emm_eq])
                                + qEmmConsxE[t, emm_eq]$(d1EmmConsxE[t,emm_eq])
                                + sum(emmtype$(d1EmmAgrAniOther[emmtype,t,emm_eq]), qEmmAgrAnimalsOther[emmtype,t,emm_eq])$(not t.val=tDataEnd.val)
                                ;
                                  # Emissions from enteric fermentation from other animals (not linked to production). In 2019 these emissions are part of DST baseline and data and hence are kept out of total emissions.

  #   ------------------------------------------------------------------------------------------------------------------
  #   Total ETS1 encompassed emissions
  #   ------------------------------------------------------------------------------------------------------------------

    E_qEmmCO2ETS[r,t]$(tx0[t] and d1CO2_ETS[r,t]).. qEmmCO2ETS[r,t] =E= sum(energy19,           qEmmProdE[r,t,'CO2e','in_ETS',energy19]$(d1EmmProdE[r,t,'CO2e','in_ETS',energy19]) 
                                                                                              + qEmmProdE[r,t,'CO2bio','in_ETS',energy19]$(d1EmmProdE[r,t,'CO2bio','in_ETS',energy19] and sameas[energy19,'Natural gas incl. biongas'])
                                                                                              - qEmmProdE[r,t,'CCSbio','in_ETS',energy19]$(d1CCSbio['in_ETS',energy19,r,t,'CCSbio']))
                                                                                              + qEmmProdxE[r,t,'CO2e']$(d1EmmProdxE[r,t,'CO2e']) ;
  #   ------------------------------------------------------------------------------------------------------------------
  #   Total emissions 
  #   ------------------------------------------------------------------------------------------------------------------

  E_qEmmTot[t,emm_eq,accounts]$(tx0[t]  and d1EmmTot[t,emm_eq,accounts])..                
    qEmmTot[t,emm_eq,accounts] =E= qEmmE[t,emm_eq,accounts]$(d1EmmE[t,emm_eq,accounts]) 
                                 + qEmmxE[t,emm_eq,accounts]$(d1EmmxE[t,emm_eq,accounts] and not sameas(emm_eq,'CCSbio'))
                                 + qEmmFromCRFnotinModel[t,emm_eq,accounts]$(d1EmmFromCRFnotinModel[t,emm_eq,accounts]);

  E_qEmmTot_lulucf[t,accounts_lulucf]$(tx0[t] and d1EmmTot[t,'CO2e',accounts_lulucf])..                
    qEmmTot[t,'CO2e',accounts_lulucf] =E= sum(accounts$(accounts_map[accounts,accounts_lulucf]), qEmmTot[t,'CO2e',accounts]) + qEmmLULUCF[t]
                                        + jEmmTot_UNFCCC_LULUCF_Calib2KF[t];

  #   ------------------------------------------------------------------------------------------------------------------
  #   Biogas conversion 
  #   ------------------------------------------------------------------------------------------------------------------
    # total demand of bionatgas
    #  E_qDbionatgas[t]$tx0[t].. qDbionatgas[t] =E= Sum((purpose,s)$(d1qREgj[purpose,'Natural gas incl. biongas',s,t]), qREgj[purpose,'Natural gas incl. biongas',s,t])
    #                                             + Sum(purpose$(d1qCE[purpose,'Natural gas incl. biongas',t]), qCE[purpose,'Natural gas incl. biongas',t])
    #                                             + sum(purpose$(d1vXE[purpose,'Natural gas incl. biongas',t]), qXE[purpose,'Natural gas incl. biongas',t]*sBionatgasX[t]);


    #  # total supply of bionatgas
    #  E_qSbionatgas[t]$tx0[t].. qSbionatgas[t] =E= qREgj['process_special','Biogas','35002',t];

    E_sBioNatGasAvg[t]$tx0[t].. 
      sBioNatGasAvg[t] =E= (qREgj['process_special','Biogas','35002',t])
                      /(sum((purpose,s)$(d1qREgj[purpose,'Natural gas incl. biongas',s,t]), qREgj[purpose,'Natural gas incl. biongas',s,t])
                       +sum(purpose$(d1qCE[purpose,'Natural gas incl. biongas',t]), qCE[purpose,'Natural gas incl. biongas',t]));

    E_sBioNatGasAvgAdj_before23[t]$(tx0[t] and t.val <=2023)..
      sBioNatGasAvgAdj[t] =E= min((qREgj['process_special','Biogas','35002',t] - Sum((purpose,s)$(d1qREgj[purpose,'Natural gas incl. biongas',s,t] and d1sBioNatGas[purpose,s,t]), qREgj[purpose,'Natural gas incl. biongas',s,t])) 
                        /(Sum((purpose,s)$(d1qREgj[purpose,'Natural gas incl. biongas',s,t] and not  d1sBioNatgas[purpose,s,t]), qREgj[purpose,'Natural gas incl. biongas',s,t])
      +Sum(purpose$(d1qCE[purpose,'Natural gas incl. biongas',t] and not d1sBioNatgasC[purpose,t]), qCE[purpose,'Natural gas incl. biongas',t])),0.99);

    E_sBioNatGasAvgAdj_after23[t]$(tx0[t] and t.val >2023)..
      sBioNatGasAvgAdj[t] =E= min((qREgj['process_special','Biogas','35002',t] - Sum((purpose,s)$(d1qREgj[purpose,'Natural gas incl. biongas',s,t] and d1sBioNatGas[purpose,s,t]), qREgj[purpose,'Natural gas incl. biongas',s,t])) 
                        /(Sum((purpose,s)$(d1qREgj[purpose,'Natural gas incl. biongas',s,t] and not d1sBioNatgas[purpose,s,t]), qREgj[purpose,'Natural gas incl. biongas',s,t])
      +Sum(purpose$(d1qCE[purpose,'Natural gas incl. biongas',t] and not d1sBioNatgasC[purpose,t]), qCE[purpose,'Natural gas incl. biongas',t])),0.99);

     #The assumption for exported bio-natural gas is that exports of bionatgas start only when the whole domestic market is served with bio-natural gas. I.e. qREgj['process_special','biogas','35002',t] is the biogas converted to bionatgas
     #It is assumed to be converted 1:1 in PJ. That is the supply. The domestic demand is what is subtracted. The max-function ensures that only when the domestic demand is served exports begin.

     E_sBionatgasX_inp[t]$(tx0[t] and t.val > 2023)..
     		qXE['unspecified','natural gas incl. biongas',t] * sBionatgasX_inp[t] =E= max(qREgj['process_special','Biogas','35002',t] -  Sum((purpose,s)$(d1qREgj[purpose,'Natural gas incl. biongas',s,t] and d1sBioNatGas[purpose,s,t]), qREgj[purpose,'Natural gas incl. biongas',s,t])
     																		   -  Sum((purpose,s)$(d1qREgj[purpose,'Natural gas incl. biongas',s,t] and not (d1sBioNatGas[purpose,s,t] or d1sBioNatGaszero[purpose,s,t])), sBioNatGasAvgAdj[t] * qREgj[purpose,'natural gas incl. biongas',s,t])
     																		   -  sum((purpose)$(d1qCE[purpose,'Natural gas incl. biongas',t] and d1sBioNatgasC[purpose,t]), qCE[purpose,'natural gas incl. biongas',t])
     																		   -  sum((purpose)$(d1qCE[purpose,'Natural gas incl. biongas',t] and not (d1sBioNatgasC[purpose,t] or d1sBioNatGasCzero[purpose,t])), sBioNatGasAvgAdj[t] * qCE[purpose,'Natural gas incl. biongas',t]), 0);

    E_sBionatgasX[t]$(tx0[t] and t.val>2023)..
      sBioNatgasX[t] =E= min(sBionatgasX_inp[t], 1);
    
    E_qXE_bionatgas[t]$(tx0[t] and t.val > 2023)..
      qXE_bionatgas[t] =E= max(qREgj['process_special','Biogas','35002',t] -  Sum((purpose,s)$(d1qREgj[purpose,'Natural gas incl. biongas',s,t] and d1sBioNatGas[purpose,s,t]), qREgj[purpose,'Natural gas incl. biongas',s,t])
     																		                                   -  Sum((purpose,s)$(d1qREgj[purpose,'Natural gas incl. biongas',s,t] and not (d1sBioNatGas[purpose,s,t] or d1sBioNatGaszero[purpose,s,t])), sBioNatGasAvgAdj[t] * qREgj[purpose,'natural gas incl. biongas',s,t])
     																		                                   -  sum((purpose)$(d1qCE[purpose,'Natural gas incl. biongas',t] and d1sBioNatgasC[purpose,t]), qCE[purpose,'natural gas incl. biongas',t])
     																		                                   -  sum((purpose)$(d1qCE[purpose,'Natural gas incl. biongas',t] and not (d1sBioNatgasC[purpose,t] or d1sBioNatGasCzero[purpose,t])), sBioNatGasAvgAdj[t] * qCE[purpose,'Natural gas incl. biongas',t])
      							                                                       -  qXE['unspecified','natural gas incl. biongas',t]$d1vXE['unspecified','natural gas incl. biongas',t] * sBioNatgasX[t],0);
                                       
    E_adj_sBioNatgas[purpose,s,t]$(tx0[t] and not tDataEnd[t] and t.val <= 2023 and (d1EmmProdE[s,t,'CO2ubio',purpose,'Natural gas incl. biongas'] and d1EmmProdE[s,t,'CO2bio',purpose,'Natural gas incl. biongas']) and (d1EmmProdE[s,t-1,'CO2ubio',purpose,'Natural gas incl. biongas'] and d1EmmProdE[s,t-1,'CO2bio',purpose,'Natural gas incl. biongas']))..
      sBionatgas[purpose,s,t] =E= sBionatgas[purpose,s,t-1] + adj_sBioNatGas[purpose,s];


    E_adj_sBioNatgas_glitchinthematrix[purpose,s,t]$(tx0[t] and not tDataEnd[t] and t.val <= 2023 and (d1EmmProdE[s,t,'CO2ubio',purpose,'Natural gas incl. biongas'] and d1EmmProdE[s,t,'CO2bio',purpose,'Natural gas incl. biongas']) and not (d1EmmProdE[s,t-1,'CO2ubio',purpose,'Natural gas incl. biongas'] and d1EmmProdE[s,t-1,'CO2bio',purpose,'Natural gas incl. biongas']) and (d1EmmProdE[s,t-2,'CO2ubio',purpose,'Natural gas incl. biongas'] and d1EmmProdE[s,t-2,'CO2bio',purpose,'Natural gas incl. biongas']))..
      sBionatgas[purpose,s,t] =E= sBionatgas[purpose,s,t-2] + 2*adj_sBioNatGas[purpose,s];


    E_adj_sBioNatgas_after2023[purpose,s,t]$(tx0[t] and t.val>=2023 and d1EmmProdE[s,t,'CO2ubio',purpose,'Natural gas incl. biongas'] and d1EmmProdE[s,t,'CO2bio',purpose,'Natural gas incl. biongas'])..
       sBionatgas[purpose,s,t] =E= sBioNatGasAvgAdj[t];

    E_adj_sBioNatgasC[purpose,t]$(tx0[t] and not tDataEnd[t] and t.val <= 2023 and (d1EmmConsE[t,'CO2ubio',purpose,'Natural gas incl. biongas'] and d1EmmConsE[t,'CO2bio',purpose,'Natural gas incl. biongas']) and (d1EmmConsE[t-1,'CO2ubio',purpose,'Natural gas incl. biongas'] and d1EmmConsE[t-1,'CO2bio',purpose,'Natural gas incl. biongas']))..
      sBionatgasC[purpose,t] =E= sBionatgasC[purpose,t-1] + adj_sBioNatGasC[purpose];

    E_adj_sBioNatgasC_glitchinthematrix[purpose,t]$(tx0[t] and not tDataEnd[t] and t.val <= 2023 and (d1EmmConsE[t,'CO2ubio',purpose,'Natural gas incl. biongas'] and d1EmmConsE[t,'CO2bio',purpose,'Natural gas incl. biongas']) and not (d1EmmConsE[t-1,'CO2ubio',purpose,'Natural gas incl. biongas'] and d1EmmConsE[t-1,'CO2bio',purpose,'Natural gas incl. biongas']))..
      sBionatgasC[purpose,t] =E= sBionatgasC[purpose,t-2] + 2*adj_sBioNatGasC[purpose];

    E_adj_sBioNatgasC_after2023[purpose,t]$(tx0[t] and t.val>=2023 and d1EmmConsE[t,'CO2ubio',purpose,'Natural gas incl. biongas'] and d1EmmConsE[t,'CO2bio',purpose,'Natural gas incl. biongas'])..
      sBionatgasC[purpose,t] =E= sBioNatGasAvgAdj[t];

    E_adj_sBioNatgas_glitchierthematrices[purpose,s,t]$(tx0[t] and not tDataEnd[t] and t.val <= 2023 and (d1EmmProdE[s,t,'CO2ubio',purpose,'Natural gas incl. biongas'] and d1EmmProdE[s,t,'CO2bio',purpose,'Natural gas incl. biongas']) and not (d1EmmProdE[s,t-1,'CO2ubio',purpose,'Natural gas incl. biongas'] and d1EmmProdE[s,t-1,'CO2bio',purpose,'Natural gas incl. biongas']) and not (d1EmmProdE[s,t-2,'CO2ubio',purpose,'Natural gas incl. biongas'] and d1EmmProdE[s,t-2,'CO2bio',purpose,'Natural gas incl. biongas']) and not (d1EmmProdE[s,t-3,'CO2ubio',purpose,'Natural gas incl. biongas'] and d1EmmProdE[s,t-3,'CO2bio',purpose,'Natural gas incl. biongas']))..# and t.val-3>2019).. 
      sBionatgas[purpose,s,t] =E= sBionatgas[purpose,s,t-4] + 4*adj_sBioNatGas[purpose,s];

    E_adj_sBioNatgas_glitchiestmatrices[purpose,s,t]$(tx0[t] and not tDataEnd[t] and t.val <= 2023 and (d1EmmProdE[s,t,'CO2ubio',purpose,'Natural gas incl. biongas'] and d1EmmProdE[s,t,'CO2bio',purpose,'Natural gas incl. biongas']) and not (d1EmmProdE[s,t-1,'CO2ubio',purpose,'Natural gas incl. biongas'] and d1EmmProdE[s,t-1,'CO2bio',purpose,'Natural gas incl. biongas']) and not (d1EmmProdE[s,t-2,'CO2ubio',purpose,'Natural gas incl. biongas'] and d1EmmProdE[s,t-2,'CO2bio',purpose,'Natural gas incl. biongas']) and (d1EmmProdE[s,t-3,'CO2ubio',purpose,'Natural gas incl. biongas'] and d1EmmProdE[s,t-3,'CO2bio',purpose,'Natural gas incl. biongas']))..# and t.val-2>2019)..
      sBionatgas[purpose,s,t] =E= sBionatgas[purpose,s,t-3] + 3*adj_sBioNatGas[purpose,s];

$ENDBLOCK

  #   ------------------------------------------------------------------------------------------------------------------
  #   Emissions related to CCS
  #   ------------------------------------------------------------------------------------------------------------------

$BLOCK B_emissions_CCS

## GROSS EMISSIONS
  # Total energy related emissions (excl. CCS)
  E_qGrossEmmE[s,t,emm,purpose,energy19]$(tx0[t] and d1EmmProdE[s,t,emm,purpose,energy19] and (sameas[emm,'CO2ubio'] or sameas[emm,'CO2bio']))..
    qGrossEmmE[s,t,emm,purpose,energy19] =E= qEmmProdE[s,t,emm,purpose,energy19]/uEOPProdE[purpose,energy19,s,t,emm];

  # Total non-energy related emissions (excl. CCS)
  E_qGrossEmmxE[s,t,emm]$(tx0[t] and d1EmmProdxE[s,t,emm] and sum(techCCS, d1thetaCCSxE[techCCS,s,t,emm]))..
    qGrossEmmxE[s,t,emm] =E= qEmmProdxE[s,t,emm]/uEOPProdxE[s,t,emm];

  # Total non-energy emissions defined on energy activity
  E_qGrossEmmE_REE[purpose,energy19a,energy19,s,t,emm]$(tx0[t] and d1qREE[purpose,energy19a,energy19,s,t] and d1EmmProdE[s,t,emm,purpose,energy19] and sum(techCCS, d1thetaCCS[techCCS,purpose,energy19,s,t,emm]))..
    qGrossEmmE_REE[purpose,energy19a,energy19,s,t,emm] =E= (qREE[purpose,energy19a,energy19,s,t]/growth_factor[t] * uEmmProdE[s,t,emm,energy19])$(d1EmmProdE[s,t,emm,purpose,energy19] and not sameas[energy19,'Natural gas incl. biongas'] and (sameas[emm,'CO2ubio'] or sameas[emm,'CO2bio']))
                                                         + (qREE[purpose,energy19a,energy19,s,t]/growth_factor[t] * sBioNatgas[purpose,s,t] * uEmmProdE[s,t,emm,energy19])$(d1EmmProdE[s,t,emm,purpose,energy19] and sameas[energy19,'Natural gas incl. biongas'] and sameas[emm,'CO2bio'])
                                                         + (qREE[purpose,energy19a,energy19,s,t]/growth_factor[t] * (1-sBioNatgas[purpose,s,t]) * uEmmProdE[s,t,emm,energy19])$(d1EmmProdE[s,t,emm,purpose,energy19] and sameas[energy19,'Natural gas incl. biongas'] and sameas[emm,'CO2ubio'])
                                                          ;

## CCS
  # CCS on energy related CO2ubio-emissions
  E_qEmmProdECCSubio[s,t,purpose,energy19]$(tx0[t] and d1EmmProdE[s,t,'CO2ubio',purpose,energy19] and sum(techCCS, d1thetaCCS[techCCS,purpose,energy19,s,t,'CO2ubio']))..
    qEmmProdE_CCSubio[s,t,purpose,energy19] =E= qEmmProdE[s,t,'CO2ubio',purpose,energy19] - qGrossEmmE[s,t,'CO2ubio',purpose,energy19];

  # CCS on energy related CO2bio-emissions
  E_qEmmProdECCSbio[s,t,purpose,energy19]$(tx0[t] and d1CCSbio[purpose,energy19,s,t,'CCSbio'])..  #or sum(techCCS, d1thetaCCSxE[techCCS,s,t,'CO2ubio']))))..
    qEmmProdE[s,t,'CCSbio',purpose,energy19] =E= qEmmProdE[s,t,'CO2bio',purpose,energy19] - qGrossEmmE[s,t,'CO2bio',purpose,energy19];

  # CCS on non-energy related CO2ubio emissions
  E_qEmmProdxECCSubio[s,t]$(tx0[t] and d1EmmProdxE[s,t,'CO2ubio'] and sum(techCCS, d1thetaCCSxE[techCCS,s,t,'CO2ubio']))..        
    qEmmProdxE_CCSubio[s,t] =E= qEmmProdxE[s,t,'CO2ubio'] - qGrossEmmxE[s,t,'CO2ubio'];

# CCS-AGGREGATES
  E_sumqEmmCCSubio[s,t]$(tx0[t] and sum((purpose,energy19),d1EmmProdE[s,t,'CO2ubio',purpose,energy19]) and (sum((techCCS,purpose,energy19), d1thetaCCS[techCCS,purpose,energy19,s,t,'CO2ubio']) or sum(techCCS, d1thetaCCSxE[techCCS,s,t,'CO2ubio'])))..
    sumqEmmCCSubio[s,t] =E= sum((purpose,energy19)$(d1EmmProdE[s,t,'CO2ubio',purpose,energy19] and sum(techCCS, d1thetaCCS[techCCS,purpose,energy19,s,t,'CO2ubio'])), 
                                  qEmmProdE_CCSubio[s,t,purpose,energy19])
                            + qEmmProdxE_CCSubio[s,t]$(d1EmmProdxE[s,t,'CO2ubio'] and sum(techCCS,d1thetaCCSxE[techCCS,s,t,'CO2ubio'])); 

  E_sumqEmmCCSbio[s,t]$(tx0[t] and sum((purpose,energy19), d1CCSbio[purpose,energy19,s,t,'CCSbio'])).. 
    sumqEmmCCSbio[s,t] =E= sum((purpose,energy19)$(d1CCSbio[purpose,energy19,s,t,'CCSbio']), 
                                  qEmmProdE[s,t,'CCSbio',purpose,energy19]);

$ENDBLOCK

$MODEL M_emissions
  B_emissions
  B_emissions_CCS
  ;

$ENDIF


# ======================================================================================================================
# Exogenous variables
# ======================================================================================================================
$IF %stage% == "exogenous_values":

  # READ-DATA
  GWP.l[emm] = GWP_UN_obs[emm]; # We use GWP's that exclude biomass when calculating our measure of CO2e. We could include it by using this other GWP variable

  qEmmProdE.l[s,t,emm,purpose,energy19]    = EM_RE[emm,purpose,energy19,s,t];  
  qEmmProdE.l['35002',t,'CO2bio','process_special','biogas'] = (84.1-55.55) * EN_qRE['process_special','biogas','35002',t]; 
  # Emissions from conversion of biogas is not part of the emissions-data. We compute it ourselves here. However it might be an error to include it in the UNFCCC emissions inventory, as it is a so-called "MEMO"-item

  qEmmProdE.l[s,t,'CO2e',purpose,energy19] = sum(emm, qEmmProdE.l[s,t,emm,purpose,energy19]*GWP.l[emm]);

  qEmmProdEP.l[s,t,emm,energy19] = sum(purpose, qEmmProdE.l[s,t,emm,purpose,energy19]);

  qEmmProdxE.l[s, t, emm] = EM_NER[emm,s,t];

  qEmmProdxE.l[s,t, 'CO2e'] = sum(emm, qEmmProdxE.l[s,t,emm]*GWP.l[emm]);

  
  qEmmProdS.l[s,t,emm_eq,accounts] = qEmmProdxE.l[s,t,emm_eq] + sum((purpose, energy19)$(energy2accounts[energy19,accounts]), qEmmProdE.l[s,t,emm_eq,purpose,energy19]);
  qEmmProd.l[t,emm_eq,accounts] = sum(s, qEmmProdS.l[s,t,emm_eq,accounts]);

  qEmmConsE.l[t,emm,purpose,energy19] = EM_CE[emm,purpose,energy19,t];         
  qEmmConsE.l[t,'CO2e',purpose,energy19] = sum(emm, qEmmConsE.l[t,emm,purpose,energy19]*GWP.l[emm]);

  qEmmConsEP.l[t,emm,energy19] = sum(purpose, qEmmConsE.l[t,emm,purpose,energy19]);

  qEmmConsxE.l[t, emm] = EM_NEC[emm,t];  
  qEmmConsxE.l[t, 'CO2e'] = sum(emm, qEmmConsxE.l[t,emm]*GWP.l[emm]);


  qEmmCons.l[t,emm_eq,accounts] = qEmmConsxE.l[t,emm_eq] + sum((purpose, energy19)$(energy2accounts[energy19,accounts]), qEmmConsE.l[t,emm_eq,purpose,energy19]);


  # READ LULUCF
  qEmmLULUCF5.l[land5,t] = LULUCF_data["tot_ktco2",land5,t];
  qEmmLULUCF.l[t] = sum(land5,qEmmLULUCF5.l[land5,t]) + qEmmHWP.l[t];

  # INITIAL VALUES 
  uEmmProdE.l[s,t,emm,energy19]$(sum(purpose, qEmmProdE.l[s,t,emm,purpose,energy19]) and tData[t]) = sum(purpose, qEmmProdE.l[s,t,emm,purpose,energy19])/sum(purpose,qREgj.l[purpose,energy19,s,t]);
  uEmmProdxE.l[s,t,emm]$(qEmmProdxE.l[s,t,emm] and tData[t])                                       = qEmmProdxE.l[s,t,emm]/qKELBM.l[s,t];


  # Initial value again
  uEmmConsE.l[t,emm,energy19]$(sum(purpose,qEmmConsE.l[t,emm,purpose,energy19]) and tData[t]) = sum(purpose,qEmmConsE.l[t,emm,purpose,energy19])/sum(purpose,qCE.l[purpose,energy19,t]);
  uEmmConsxE.l[t,emm]$(qEmmConsxE.l[t,emm] and tData[t])                                      = qEmmConsxE.l[t,emm]/qCHH.l['ctot', t];

  # EOP COEFFICIENTS:
  uEOPProdE.l[purpose,energy19,s,tx0,emm]$(qEmmProdE.l[s,tx0,emm,purpose,energy19]) = 1;
  uEOPProdxE.l[s,tx0,emm]$(qEmmProdxE.l[s,tx0,emm])                                 = 1;


  # Biogas conversion
  sBioNatgas.l[purpose,r,t]     = sBioNatgas_in[purpose,r,t];
  sBionatgasC.l[purpose,t]      = sBioNatgasC_in[purpose,t];


  #From CRF-tables
    #CRF-categories not in model
    qEmmFromCRFnotinModel.l[t,emm,accounts]$(t.val > tBF_calib_start.val and GWP.l[emm]) = sum(sCRF$nonmappedCRFxE[sCRF], KF_emm_[emm,sCRF,t]/GWP.l[emm]*1000);
    qEmmFromCRFnotinModel.l[t,emm,accounts]$(t.val > tBF_calib_end.val) =   qEmmFromCRFnotinModel.l[tBF_calib_end,emm,accounts];
    qEmmFromCRFnotinModel.l[t,'CO2e',accounts] = sum(emm, qEmmFromCRFnotinModel.l[t,emm,accounts]*GWP.l[emm]);

   #Boarder trade
    qEmmBorderTrade.l[t,emm]$(t.val > tBF_calib_start.val and GWP.l[emm]) = KF_emm[emm,'Road transport - bordertrade',t]/GWP.l[emm]*1000; #Omregner til rigtige enheder (kt udl.)
    qEmmBorderTrade.l[t,emm]$(t.val > tBF_calib_end.val)                  = qEmmBorderTrade.l[tBF_calib_end, emm];
    qEmmBorderTrade.l[t,'CO2e']                                           = sum(emm,qEmmBorderTrade.l[t,emm]*GWP.l[emm]);



  # DUMMIES
  d1CCSbio[purpose,energy19,s,t,'CCSbio']   = yes$(d1EmmProdE[s,t,'CO2bio',purpose,energy19] and sum(techCCS, d1thetaCCS[techCCS,purpose,energy19,s,t,'CO2bio']));
  d1EmmProdE[s,t,emm_eq,purpose, energy19]  = yes$(qEmmProdE.l[s,t,emm_eq,purpose, energy19] and included_gases(emm_eq));
  d1EmmProdE_sumPE[s,emm,t]                 = sum((purpose,energy19), d1EmmProdE[s,t,emm,purpose,energy19]);

  d1EmmProdxE[s,t,emm_eq]                   = yes$(qEmmProdxE.l[s,t,emm_eq] and included_gases(emm_eq));
  
  d1EmmProdS[s,t,emm_eq,accounts]           = yes$((qEmmProdS.l[s,t,emm_eq,accounts] and included_gases(emm_eq)) or sum((purpose,energy19), d1CCSbio[purpose,energy19,s,t,emm_eq]));
  d1EmmProd[t,emm_eq]                       = yes$((sum(accounts,qEmmProd.l[t,emm_eq,accounts]) and included_gases(emm_eq)) or sum((purpose,energy19,s), d1CCSbio[purpose,energy19,s,t,emm_eq]));  
  
  d1EmmConsE[t, 'co2e', purpose,energy19]   = yes$(qEmmConsE.l[t, 'co2e', purpose, energy19] and d1qCE[purpose,energy19,t]);
  d1EmmConsE[t, emm, purpose,energy19]      = yes$(qEmmConsE.l[t, emm, purpose, energy19]  and uEmmConsE.l[t,emm,energy19] and included_gases(emm) and d1qCE[purpose,energy19,t]);



  d1EmmConsxE[t,emm_eq]               = yes$(qEmmConsxE.l[t, emm_eq] and included_gases(emm_eq));
  d1EmmCons[t, emm_eq]                = yes$(sum(accounts,qEmmCons.l[t,emm_eq,accounts]) and included_gases(emm_eq));

  d1EmmE[t,emm_eq,accounts]           = yes$(included_gases(emm_eq) or sameas(emm_eq, 'CCSbio'));
  d1EmmxE[t,emm_eq,accounts]          = yes$(included_gases(emm_eq));
  d1EmmTot[t,emm_eq,accounts_all]     = yes$(included_gases(emm_eq) or sameas(emm_eq, 'CCSbio'));

  d1EmmFromCRFnotinModel[t,emm_eq,accounts] = yes$(qEmmFromCRFnotinModel.l[t,emm_eq,accounts]);


$ENDIF


# ======================================================================================================================
# Static calibration
# ======================================================================================================================




$IF %stage% == "static_calibration":


#  $BLOCK B_CCStjek
#    E_qEmmProdECCSbio2[s,t,purpose,energy19]$(tx0[t] and d1EmmProdE[s,t,'CO2',purpose, energy19] and sum(techCCS, d1_tech_s_CCS[techCCS,s]))..
#      qEmmProdE[s,t,'CCSbio',purpose,energy19] =E= 
#      -(qEmmProdE[s,t,'CO2',purpose,energy19]*(1-uEOPProdE[s,t,'CO2',energy19]) - qEmmProdE[s,t,'CO2ubio',purpose,energy19]*(1-uEOPProdE[s,t,'CO2ubio',energy19]));

#    E_qEmmProdS2[s,t,emm_eq,accounts]$(tx0[t] and d1EmmProdS[s,t,emm_eq,accounts])..  
#       qEmmProdS[s,t,emm_eq,accounts] =E=
#             qEmmProdxE[s,t,emm_eq]$(d1EmmProdxE[s,t,Emm_eq]) 
#             + sum((purpose, energy19)$(energy2accounts(energy19,accounts) and (d1EmmProdE[s,t,emm_eq,purpose,energy19] or (d1CCSbio[s,emm_eq] and d1EmmProdE[s,t,'CO2',purpose, energy19]))), qEmmProdE[s,t,emm_eq,purpose,energy19]);
#  $ENDBLOCK

#  $GROUP ccs_endo
#  qEmmProdE[s,t,'CCSbio',purpose,energy19]$(tx0[t] and sum(emm,d1EmmProdE[s,t,emm,purpose, energy19]) and sum(techCCS, d1_tech_s_CCS[techCCS,s]))
#  qEmmProdS2[s,t,emm_eq,accounts]$(tx0[t] and d1EmmProdS[s,t,emm_eq,accounts])
#  ;

#  $GROUP ccs_exo
#  uEOPProdE
#  qEmmProdE
#  qEmmProdxE

#  ;

#    $FIX ccs_exo;
#    $UNFIX ccs_endo;
#    @solve(B_CCStjek);

#  $display qEmmProdE$(sameas(emm_eq, 'CCSbio'));
#  $display qEmmProdS$(sameas(emm_eq, 'CCSbio'));

  
  $GROUP G_emissions_static_calibration
    G_emissions_endo
    uEmmProdxE$(tx0[t] and d1EmmProdxE[s,t,emm]),- qEmmProdxE$(tx0[t] and d1EmmProdxE[s,t,emm_eq] and emm(emm_eq))
    uEmmConsxE$(tx0[t] and  d1EmmConsxE[t,emm]) ,- qEmmConsxE$(tx0[t] and d1EmmConsxE[t,emm_eq] and emm(emm_eq))
    uEmmProdE$(tx0[t] and sum(purpose,d1EmmProdE[s,t,emm,purpose, energy19])) , -qEmmProdEP[s,t,emm,energy19]$(tx0[t] and sum(purpose,d1EmmProdE[s,t,emm,purpose, energy19]) ) 
    uEmmConsE$(tx0[t] and sum(purpose,d1EmmConsE[t, emm, purpose,energy19]))  ,-qEmmConsEP[t,emm,energy19]$(tx0[t] and sum(purpose, d1EmmConsE[t,emm,purpose,energy19]))
  ;

  $GROUP G_emissions_static_calibration_exo
    G_emissions_exo
    -uEmmProdxE[s, t, emm]$(tx0[t] and d1EmmProdxE[s,t,emm]),     qEmmProdxE[s,t,emm]$(tx0[t] and d1EmmProdxE[s,t,emm_eq] and emm(emm_eq))
    -uEmmConsxE[t, emm]$(tx0[t] and  d1EmmConsxE[t,emm]),         qEmmConsxE[t,emm]$(tx0[t] and d1EmmConsxE[t,emm_eq] and emm(emm_eq))
    -uEmmProdE$(tx0[t] and sum(purpose,d1EmmProdE[s,t,emm,purpose, energy19])), qEmmProdEP[s,t,emm,energy19]$(tx0[t] and sum(purpose,d1EmmProdE[s,t,emm,purpose, energy19]) ) 
    -uEmmConsE$(tx0[t] and sum(purpose,d1EmmConsE[t, emm, purpose,energy19])), qEmmConsEP[t,emm,energy19]$(tx0[t] and sum(purpose, d1EmmConsE[t,emm,purpose,energy19]))
  ;

  $MODEL M_emissions_static_calibration
    B_emissions 
    B_emissions_CCS
  ;

  $FIX G_emissions_static_calibration_exo;
  $UNFIX G_emissions_static_calibration;
  @solve(M_emissions_static_calibration);
$ENDIF

# ======================================================================================================================
# Dynamic calibration
# ======================================================================================================================
$IF %stage% == "dynamic_calibration":

  uEmmProdE.l[s,tForecast,emm,energy19]$(uEmmHardCoded[emm,energy19] and uEmmProdE.l[s,tDataEnd,emm,energy19]) = uEmmHardCoded[emm,energy19];
  uEmmConsE.l[tForecast,emm,energy19]$(uEmmHardCoded[emm,energy19] and uEmmConsE.l[tDataEnd,emm,energy19])     = uEmmHardCoded[emm,energy19];
  
  $GROUP G_emissions_calib
    G_emissions_endo
  ;

  $GROUP G_emissions_calib_exo
    G_emissions_exo
  ;

  $MODEL M_emissions_calib
    B_emissions
    B_emissions_CCS
  ;

$ENDIF
