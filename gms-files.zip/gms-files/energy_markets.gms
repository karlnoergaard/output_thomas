# =====================================================================================================================
# Energy-markets
# =====================================================================================================================
# This module handles the details of the energi-markets in the model
# The different demand components are satisfied with domestic production competing with imports.

# ========================================================================================================================
# Variable definition
# ========================================================================================================================
  
  $IF %stage% == "variables":
  
      # ---------------------------------------------------------------------------------------------------------------------
    # MARKET-CLEARING
    # ---------------------------------------------------------------------------------------------------------------------
  
    $GROUP G_energy_markets_clearing_prices 
        pEtot[energy19,t]$(d1pEtot[energy19,t])                 "Average price of energy, thousand kroners per GJ/bio. kroner per PJ"
        pMNatgasNL[t]                                           "Price of imported natural gas to the Netherlands, Ørsted joint-venture up until 2019"
    ;

    $GROUP G_energy_markets_clearing_quantities 
          qY_CET[out,s,t]$(d1vY_CET[out,s,t] and energy19[out])   "Domestic production of various products and services - the set 'out' contains all out puts of the economy"
          qM_CET[out,s,t]$(d1vM_CET[out,s,t] and energy19[out])   "Import of various producets (out)"
          qTL[purpose,energy19,t]$(d1TL[purpose,energy19,t])      "Transmission-losses"
          qRENEWABLE[energy19,t]$(d1RENEWABLE[energy19,t])        "Renewable energy" 
          qEtot[energy19,t]$(d1pEtot[energy19,t])                 "Total demand/supply of energy in the models energy-market"
          qREgj[purpose,energy19,r,t]$(d1pREgj[purpose,energy19,r,t]) "Quantity of energy demeand (=qRE if abatement module is not included)"
          qMNatgasNL[t]                                           "Import of natural gas to Ørsted joint-venture in Netherlands"
    ;

    $GROUP G_energy_markets_clearing_values 
        vDistributionProfits[energy19,t]$(d1pEtot[energy19,t])  "Distributors profits"
    ;

    $GROUP G_energy_markets_clearing_other 
        sY_AGG[energy19,s,t]$((tx0[t] and not d1vE_onesupplier[energy19,t]) and (d1vY_CET[energy19,s,t] or (d1vM_CET[energy19,s,t] and d1vY_CET[energy19,s,t])) or (tx0[t] and sameas[s,'19000'] and d1vY_CET[energy19,s,t] and (sameas[energy19,'LVN'] or sameas[energy19,'semi-refined oil']))) "The energy-distributors portfolio weight of energy-good from domestic suppliers"
        sM_AGG[energy19,s,t]$((tx0[t] and not d1vE_onesupplier[energy19,t]) and (d1vM_CET[energy19,s,t]))             "The energy-distributors portfolio weight of energy-good from import"
        eAGG[energy19]                      "The energy-distributors elasticity of substition between energy-goods"
        j_qREgj[purpose,energy19,r,t]$(tx0[t] and d1pREgj[purpose,energy19,r,t])                                      "Correction term  (=0 if abatement is not active)"
    ;
    # ---------------------------------------------------------------------------------------------------------------------
    # PRICES
    # ---------------------------------------------------------------------------------------------------------------------
    $GROUP G_energy_demand_prices 
      pXE[purpose,energy19,t]$(tx0[t] and d1vXE[purpose,energy19,t])                                "Export price of energy"
      pLE[purpose,energy19,t]$(tx0[t] and d1vLE[purpose,energy19,t] and tx0[t])                     "Price of energy split on purposes for inventories"
      pREgj[purpose,energy19,r,t]$(d1pREgj[purpose,energy19,r,t])                                   "Price of energy split on purposes paid by firms"
      pCE[purpose,energy19,t]$(tx0[t] and d1vCE[purpose,energy19,t])                                "Price of energy split on purposes paid by consumers"
  
      pXE_base[purpose,energy19,t]$(d1vXE[purpose,energy19,t])                                      "Base-price of energy, exports (including mark-up, excluding taxes)"
      pLE_base[purpose,energy19,t]$(d1vLE[purpose,energy19,t])                                      "Base-price of energy, inventories (including mark-up, excluding taxes)"
      pRE_base[purpose,energy19,r,t]$(d1pRE_base[purpose,energy19,r,t])                             "Base-price of energy, firms (including mark-up, excluding taxes)"
      pRE_base_marg[purpose,energy19,r,t]$(d1pRE_base[purpose,energy19,r,t])                                       "Marginal base-price of energy, firms (including mark-up, excluding taxes)"
      pREown[purpose,energy19,r,t]$(d1pREown[purpose,energy19,r,t])                                 "Base-price of energy, firms (including mark-up, excluding taxes)"
      pCE_base[purpose,energy19,t]$(d1vCE[purpose,energy19,t])                                      "Base-price of energy, consumers (including mark-up, excluding taxes)"
  
      pXE_bionatgas[t]$(tx0[t]) ""
  
    ;
    $GROUP G_energy_demand_prices_other 
      fpXE[purpose,energy19,t]$(tx0[t] and d1vXE[purpose,energy19,t])              "Distributors mark-up on energy, exports"
      fpLE[purpose,energy19,t]$(tx0[t] and d1vLE[purpose,energy19,t])              "Distributors mark-up on energy, inventories"
      fpRE[purpose,energy19,r,t]$(tx0[t] and d1pRE_base[purpose,energy19,r,t])     "Distributors mark-up on energy, firms"
      fpCE[purpose,energy19,t]$(tx0[t] and d1vCE[purpose,energy19,t])              "Distributors mark-up on energy, consumers"
      adj_pRE_base_marg[purpose,energy19,r,t]$(tx0[t] and d1pRE_base[purpose,energy19,r,t])  ""
    #    sCE[purpose,energy19,t]$(tx0[t] and d1vCE[purpose,energy19,t])               "Scale parameter in consumers utility function"
    #    sCEPE[purpose,t]$(tx0[t] and d1vCEPE[purpose,t])                             "Scale parameter in consumers utility function" 
    #    eCEPE[purpose]                                                               "Elasticity of substition between energy-goods for the consumer"    
    #    eCE                                                                          "Elasticity of substition between energy-purposes for the consumer" 
    ;
  
  
    # ---------------------------------------------------------------------------------------------------------------------
    # MARGINS
    # ---------------------------------------------------------------------------------------------------------------------
  
    $GROUP G_energy_markets_margins_values 
      vEAV_RE[purpose,energy19,r,t]$(d1EAV_RE[purpose,energy19,r,t]) ""
      vDAV_RE[purpose,energy19,r,t]$(d1DAV_RE[purpose,energy19,r,t]) ""
      vCAV_RE[purpose,energy19,r,t]$(d1CAV_RE[purpose,energy19,r,t]) ""
  
      vEAV_CE[purpose,energy19,t]$(d1EAV_CE[purpose,energy19,t]) ""
      vDAV_CE[purpose,energy19,t]$(d1DAV_CE[purpose,energy19,t]) ""
      vCAV_CE[purpose,energy19,t]$(d1CAV_CE[purpose,energy19,t]) ""
  
      vOtherDistributionProfits_EAV[t] ""
      vOtherDistributionProfits_DAV[t] ""
      vOtherDistributionProfits_CAV[t] ""
    ;
  
    $GROUP G_energy_markets_margins_prices 
      pEAV_RE[purpose,energy19,r,t]$(d1vY_CET['WholeAndRetailSaleMarginE','46000',t] and d1EAV_RE[purpose,energy19,r,t]) ""
      pDAV_RE[purpose,energy19,r,t]$(d1vY_CET['WholeAndRetailSaleMarginE','47000',t] and d1DAV_RE[purpose,energy19,r,t]) ""
      pCAV_RE[purpose,energy19,r,t]$(d1vY_CET['WholeAndRetailSaleMarginE','45000',t] and d1CAV_RE[purpose,energy19,r,t]) ""

      pEAV_CE[purpose,energy19,t]$(d1vY_CET['WholeAndRetailSaleMarginE','46000',t] and d1EAV_CE[purpose,energy19,t]) ""
      pDAV_CE[purpose,energy19,t]$(d1vY_CET['WholeAndRetailSaleMarginE','47000',t] and d1DAV_CE[purpose,energy19,t]) ""
      pCAV_CE[purpose,energy19,t]$(d1vY_CET['WholeAndRetailSaleMarginE','45000',t] and d1CAV_CE[purpose,energy19,t]) ""
    ;
  
    $GROUP G_energy_markets_margins_other 
      fpEAV_RE[purpose,energy19,r,t]$(tx0[t] and d1vY_CET['WholeAndRetailSaleMarginE','46000',t] and d1EAV_RE[purpose,energy19,r,t]) ""
      fpDAV_RE[purpose,energy19,r,t]$(tx0[t] and d1vY_CET['WholeAndRetailSaleMarginE','47000',t] and d1DAV_RE[purpose,energy19,r,t]) ""
      fpCAV_RE[purpose,energy19,r,t]$(tx0[t] and d1vY_CET['WholeAndRetailSaleMarginE','45000',t] and d1CAV_RE[purpose,energy19,r,t]) ""

      fpEAV_CE[purpose,energy19,t]$(tx0[t] and d1vY_CET['WholeAndRetailSaleMarginE','46000',t] and d1EAV_CE[purpose,energy19,t]) ""
      fpDAV_CE[purpose,energy19,t]$(tx0[t] and d1vY_CET['WholeAndRetailSaleMarginE','47000',t] and d1DAV_CE[purpose,energy19,t]) ""
      fpCAV_CE[purpose,energy19,t]$(tx0[t] and d1vY_CET['WholeAndRetailSaleMarginE','45000',t] and d1CAV_CE[purpose,energy19,t]) ""
    ;
  
    # ---------------------------------------------------------------------------------------------------------------------
    # Bio fuels in gasoline for transport and diesel for transport
    # ---------------------------------------------------------------------------------------------------------------------
  
    $GROUP G_biofuelsintransport_quantities 
      qREE_transport[purpose,energy19a,energy19,s,t]$(tx0[t] and d1vREE_transport[purpose,energy19a,energy19,s,t]) ""
    ;
    
    $GROUP G_biofuelsintransport_other
      uREExID_transport[purpose,energy19a,energy19,s,t]$(tx0[t] and d1qREE_transport[purpose,energy19a,energy19,s,t]) ""
      j_pREa[purpose,energy19a,s,t]$(tx0[t] and sum(energy19, d1vREE_transport[purpose,energy19a,energy19,s,t])) ""
      j_qREgj[purpose,energy19,r,t]$(tx0[t] and sum(energy19a, d1vREE_transport[purpose,energy19a,energy19,r,t])) ""
    ; 
  

  $ENDIF 

# ========================================================================================================================
# Group compilation
# ========================================================================================================================
  
  $IF %stage%=='groupcompilation':
  
    # ---------------------------------------------------------------------------------------------------------------------
    # Quantities, prices, values
    # ---------------------------------------------------------------------------------------------------------------------
      $GROUP G_energy_markets_quantities
        G_energy_markets_clearing_quantities
        G_biofuelsintransport_quantities
      ;
  
      $GROUP G_energy_markets_prices 
        G_energy_markets_clearing_prices
        G_energy_markets_margins_prices
        G_energy_demand_prices
      ;
  
      $GROUP G_energy_markets_values 
        G_energy_markets_clearing_values
        G_energy_markets_margins_values
      ;
  
    # ---------------------------------------------------------------------------------------------------------------------
    # Energy-markets clearing 
    # ---------------------------------------------------------------------------------------------------------------------
      $GROUP G_energy_markets_clearing_endo 
        pEtot[energy19,t]$(tx0[t] and d1pEtot[energy19,t])

        qY_CET[out,s,t]$(tx0[t] and d1vY_CET[out,s,t] and energy19[out])   "Domestic production of various products and services - the set 'out' contains all out puts of the economy"
        -qY_CET$(sameas[out,'Natural gas (Extraction)']), -qY_CET$(sameas[out,'Crude oil'])                     # Northsea production is exogenous
        -qY_CET$(d1vY_CET[out,s,t] and energy19[out] and (sameas[out,'Gasoline for transport'] or sameas[out,'Diesel for transport'] or sameas[out,'Jet petroleum'] or sameas[out,'Oil products'] or sameas[out,'biodiesel']) and sameas[s,'19000'])  # Refinery productions is exogenous as a default. In shocks the sector is subject to special modelling   

        qM_CET[out,s,t]$(tx0[t] and d1vM_CET[out,s,t] and energy19[out])   "Import of various producets (out)"

        vDistributionProfits[energy19,t]$(tx0[t] and d1pEtot[energy19,t])  "Distributors profits"

        qEtot[energy19,t]$(tx0[t] and d1pEtot[energy19,t])                 "Total demand/supply of energy in the models energy-market"

        qREgj[purpose,energy19,r,t]$(tx0[t] and d1pREgj[purpose,energy19,r,t] and not (sum(techID, sum(energy19a, d1thetaID[techID,purpose,energy19a,energy19,r,t])) or sum(energy19a, d1vREE_transport[purpose,energy19a,energy19,r,t]))) 
        j_qREgj[purpose,energy19,r,t]$(tx0[t] and d1pREgj[purpose,energy19,r,t] and (sum(techID, sum(energy19a, d1thetaID[techID,purpose,energy19a,energy19,r,t])) or sum(energy19a, d1vREE_transport[purpose,energy19a,energy19,r,t]))) 
      ; 

      $GROUP G_energy_markets_clearing_fromothermodules_exo
        pM_CET$(tx0[t] and d1vM_CET[out,s,t] and energy19[out])
        pY_CET$(tx0[t] and d1vY_CET[out,s,t] and energy19[out])
#          qREgj$(tx0[t] and d1pRE_base[purpose,energy19,r,t])
        qCE$(tx0[t] and d1vCE[purpose,energy19,t])
        qLE$(tx0[t] and d1vLE[purpose,energy19,t])
        qXE$(tx0[t] and d1vXE[purpose,energy19,t])
        qREa$(tx0[t] and d1pREgj[purpose,energy19a,s,t] and d1pREa[purpose,energy19a,s,t])
      ;


      $GROUP G_energy_markets_clearing_exo 
        G_energy_markets_clearing_fromothermodules_exo
#          pMNatgasNL[t]
#          qMNatgasNL
        qY_CET$(tx0[t] and d1vY_CET[out,s,t] and energy19[out] and (sameas[out,'Natural gas (Extraction)'] or sameas[out,'Crude oil']   or sameas[out,'Gasoline for transport']   or sameas[out,'Diesel for transport']   or sameas[out,'Jet petroleum']  or sameas[out,'Oil products']  or sameas[out,'Semi-refined oil'] or sameas[out,'Coal and coke'] or sameas[out,'biodiesel']  or sameas[out,'Bioethanol'] or sameas[out,'Bunkering of Danish operated vessels on foreign territory']   or sameas[out,'Bunkering of Danish operated planes on foreign territory']  or sameas[out,'Bunkering of Danish operated trucks on foreign territory'] ))
        -qY_CET$(tx0[t] and d1vY_CET['semi-refined oil','19000',t] and energy19[out] and sameas[out,'semi-refined oil'] and sameas[s,'19000'])   

#          qY_CET$(sameas[out,'Natural gas (Extraction)']), qY_CET$(sameas[out,'Crude oil'])                     # Northsea production is exogenous
#          qY_CET$(d1vY_CET[out,s,t] and energy19[out] and (sameas[out,'Gasoline for transport'] or sameas[out,'Diesel for transport'] or sameas[out,'Jet petroleum'] or sameas[out,'Oil products'] or sameas[out,'Biodiesel']) and sameas[s,'19000'])  # Refinery productions is exogenous as a default. In shocks the sector is subject to special modelling   

        qTL[purpose,energy19,t]$(tx0[t] and d1TL[purpose,energy19,t] )      "Transmission-losses"
        qRENEWABLE[energy19,t]$(d1RENEWABLE[energy19,t])        "Renewable energy" 

#          qREgj[purpose,energy19,r,t]$(tx0[t] and d1pREgj[purpose,energy19,r,t] and (sum(techID, sum(energy19a, d1thetaID[techID,purpose,energy19a,energy19,r,t])) or sum(energy19a, d1vREE_transport[purpose,energy19a,energy19,r,t]))) 
        j_qREgj[purpose,energy19,r,t]$(tx0[t] and d1pREgj[purpose,energy19,r,t] and not (sum(techID, sum(energy19a, d1thetaID[techID,purpose,energy19a,energy19,r,t])) or sum(energy19a, d1vREE_transport[purpose,energy19a,energy19,r,t]))) 

        G_energy_markets_clearing_other

      ;
    # ---------------------------------------------------------------------------------------------------------------------
    # Demand prices
    # --------------------------------------------------------------------------------------------------------------------- 
      $GROUP G_energy_demand_prices_endo 
        G_energy_demand_prices
      ;
      $GROUP G_energy_prices_fromothermodules_exo
        pEtot$(tx0[t] and sum(purpose, d1vXE[purpose,energy19,t]))
        # E_pXE
        tXE_$(tx0[t] and d1vXE[purpose,energy19,t] and d1tXE[purpose,energy19,t])
        # E_pLE_base
        pEtot$(tx0[t] and sum(purpose, d1vLE[purpose,energy19,t]))
        # E_pRE_base
        pEtot$(tx0[t] and sum(purpose, sum(r, d1pRE_base[purpose,energy19,r,t])))
        # E_pREgj_market_taxed
        tvREmarg$(tx0[t] and d1tRE[purpose,energy19,r,t] and (d1pRE_base[purpose,energy19,r,t] or d1pREown[purpose,energy19,r,t]))
        # E_pREgj_nonmarket
        tqREmarg$(tx0[t] and d1tRE[purpose,energy19,r,t] and not (d1pRE_base[purpose,energy19,r,t] or d1pREown[purpose,energy19,r,t]))
        # E_pREown
        pY0_CET$(tx0[t] and d1pY0_CET[out,s,t] and energy19[out] and not agri_sectors_s[s])
        pY_CET$(tx0[t] and d1pY0_CET[out,s,t] and energy19[out] and agri_sectors_s[s])
        # E_pCE_base
        pEtot$(tx0[t] and sum(purpose, d1vCE[purpose,energy19,t]))
        # E_pCE
        tCE$(tx0[t] and d1vCE[purpose,energy19,t] and d1tCE[purpose,energy19,t])
        #E_pXE_bionatgas
        pY_CET$(tx0[t] and d1vY_CET[out,s,t] and sameas[out,'natural gas incl. biongas'] and sameas[s,'35002'])
      ;
    
        $GROUP G_energy_demand_prices_exo 
          G_energy_demand_prices_other
          G_energy_prices_fromothermodules_exo
        ;
  

    # ---------------------------------------------------------------------------------------------------------------------
    # Margins
    # ---------------------------------------------------------------------------------------------------------------------
      $GROUP G_energy_markets_margins_endo   
        G_energy_markets_margins_values
        G_energy_markets_margins_prices
      ;
  
      $GROUP G_energy_markets_margins_endo G_energy_markets_margins_endo$(tx0[t]);
  
      $GROUP G_energy_markets_margins_fromothermodules_exo 
            pY_CET$(tx0[t] and sameas[s,'45000'] and sameas[out,'WholeAndRetailSaleMarginE'])
            pY_CET$(tx0[t] and sameas[s,'46000'] and sameas[out,'WholeAndRetailSaleMarginE'])
            pY_CET$(tx0[t] and sameas[s,'47000'] and sameas[out,'WholeAndRetailSaleMarginE'])

            qY_CET$(tx0[t] and d1vY_CET['WholeAndRetailSaleMarginE','45000',t] and sameas[s,'45000'] and sameas[out,'WholeAndRetailSaleMarginE'])
            qY_CET$(tx0[t] and d1vY_CET['WholeAndRetailSaleMarginE','46000',t] and sameas[s,'46000'] and sameas[out,'WholeAndRetailSaleMarginE'])
            qY_CET$(tx0[t] and d1vY_CET['WholeAndRetailSaleMarginE','47000',t] and sameas[s,'47000'] and sameas[out,'WholeAndRetailSaleMarginE'])


#              qREgj$(tx0[t] and d1EAV_RE[purpose,energy19,r,t])
#              qREgj$(tx0[t] and d1DAV_RE[purpose,energy19,r,t])
#              qREgj$(tx0[t] and d1CAV_RE[purpose,energy19,r,t])

            qCE$(tx0[t] and (d1EAV_CE[purpose,energy19,t] or d1CAV_CE[purpose,energy19,t] or d1DAV_CE[purpose,energy19,t]))
      ;
  
      $GROUP G_energy_markets_margins_exo 
        G_energy_markets_margins_fromothermodules_exo
        G_energy_markets_margins_other 
      ;

    # ---------------------------------------------------------------------------------------------------------------------
    # Bio fuels in gasoline for transport and diesel for transport
    # ---------------------------------------------------------------------------------------------------------------------
    
      $GROUP G_biofuelsintransport_endo 
        G_biofuelsintransport_quantities
        pREa[purpose,energy19a,s,t]$(tx0[t] and sum(energy19, d1vREE_transport[purpose,energy19a,energy19,s,t]))
        qREgj[purpose,energy19,r,t]$(tx0[t] and sum(energy19a, d1vREE_transport[purpose,energy19a,energy19,r,t]))
      ;
  
      $GROUP G_biofuelsintransport_fromothermodules_exo 
        qREa$(tx0[t] and sum(energy19,d1vREE_transport[purpose,energy19a,energy19,s,t]))
#          pREgj$(tx0[t] and d1pREgj[purpose,energy19,r,t] and sameas[purpose,'transport'])
      ;

      $GROUP G_biofuelsintransport_exo 
          uREExID_transport[purpose,energy19a,energy19,s,t]$(tx0[t] and d1qREE_transport[purpose,energy19a,energy19,s,t])
          G_biofuelsintransport_fromothermodules_exo

      ;
   

  
    # ---------------------------------------------------------------------------------------------------------------------
    # Full module
    # ---------------------------------------------------------------------------------------------------------------------
  
      $GROUP G_energy_markets_endo 
        G_energy_markets_clearing_endo
        G_energy_demand_prices_endo
        G_energy_markets_margins_endo
        G_biofuelsintransport_endo
  
      ; 
  
      $GROUP G_energy_markets_endo G_energy_markets_endo$(tx0[t]); # Restrict endo group to tx0[t]
  
      $GROUP G_energy_markets_exo 
        G_energy_markets_clearing_exo
  	    G_energy_demand_prices_exo
        G_biofuelsintransport_exo
        G_energy_markets_margins_exo
        -qRENEWABLE
        -pEtot
        -j_qREgj[purpose,energy19,r,t]$(tx0[t] and d1pREgj[purpose,energy19,r,t] and (sum(techID, sum(energy19a, d1thetaID[techID,purpose,energy19a,energy19,r,t])) or sum(energy19a, d1vREE_transport[purpose,energy19a,energy19,r,t]))) 
        -eAGG, eAGG[energy19]$(sum(s,sum(t,d1vY_CET[energy19,s,t])) and not sum(t,d1vE_onesupplier[energy19,t]))
      ;
  
    
    #DATA
      $GROUP G_energy_markets_data 
        pEtot[energy19,t]$(d1pEtot[energy19,t])                     "Average price of energy, thousand kroners per GJ/bio. kroner per PJ"
        pMNatgasNL[t]                                               "Price of imported natural gas to the Netherlands, Ørsted joint-venture up until 2019"

        qY_CET[out,s,t]$(d1vY_CET[out,s,t] and energy19[out])       "Domestic production of various products and services - the set 'out' contains all out puts of the economy"
        qM_CET[out,s,t]$(d1vM_CET[out,s,t] and energy19[out])       "Import of various producets (out)"
        qTL[purpose,energy19,t]$(d1TL[purpose,energy19,t])          "Transmission-losses"
        qRENEWABLE[energy19,t]$(d1RENEWABLE[energy19,t])            "Renewable energy" 
        qEtot[energy19,t]$(d1pEtot[energy19,t])                     "Total demand/supply of energy in the models energy-market"
        qREgj[purpose,energy19,r,t]$(d1pREgj[purpose,energy19,r,t]) "Quantity of energy demeand (=qRE if abatement module is not included)"
        qMNatgasNL[t]                                               "Import of natural gas to Ørsted joint-venture in Netherlands"
  
        pXE_base$(d1vXE[purpose,energy19,t])
        pLE_base$(d1vLE[purpose,energy19,t])
        pCE_base$(d1vCE[purpose,energy19,t])
        pRE_base$(d1pRE_base[purpose,energy19,r,t])
      ;
  
  
  $ENDIF


# ========================================================================================================================
# Energy-markets equations  
# ========================================================================================================================

  $IF %stage%=='equations':

   # ---------------------------------------------------------------------------------------------------------------------
    # MARKET CLEARING
    # ---------------------------------------------------------------------------------------------------------------------

    $BLOCK B_energy_markets_clearing
      E_qY_CET_energy19[energy19,s,t]$(tx0[t] and d1vY_CET[energy19,s,t] and not d1vE_onesupplier[energy19,t])..      
        qY_CET[energy19,s,t] * (sum(ss$d1vY_CET[energy19,ss,t], sY_AGG[energy19,ss,t] * pY_CET[energy19,ss,t] ** (-eAGG[energy19])) + sum(ss$d1vM_CET[energy19,ss,t], sM_AGG[energy19,ss,t] * pM_CET[energy19,ss,t]**(-eAGG[energy19]))) 
          =E= sY_AGG[energy19,s,t] * pY_CET[energy19,s,t] **(-eAGG[energy19]) * qEtot[energy19,t];

      E_qY_CET_SemiRefinedOil[t]$(tx0[t] and d1vY_CET['semi-refined oil','19000',t])..
        qY_CET['Semi-refined oil','19000',t] =E= sY_AGG['Semi-refined oil','19000',t] * qREgj['process_special','crude oil','19000',t];

      E_qM_CET_energy19[energy19,s,t]$(tx0[t] and d1vM_CET[energy19,s,t] and not d1vE_onesupplier[energy19,t])..      
        qM_CET[energy19,s,t]*(sum(ss$d1vY_CET[energy19,ss,t], sY_AGG[energy19,ss,t] * pY_CET[energy19,ss,t] ** (-eAGG[energy19])) + sum(ss$d1vM_CET[energy19,ss,t], sM_AGG[energy19,ss,t] * pM_CET[energy19,ss,t]**(-eAGG[energy19]))) 
          =E= sM_AGG[energy19,s,t] * pM_CET[energy19,s,t] **(-eAGG[energy19]) * qEtot[energy19,t];

      E_qM_CET_onesupplier[energy19,t]$(tx0[t] and d1pEtot[energy19,t] and d1vE_onesupplier[energy19,t]).. 
        sum(s$d1vM_CET[energy19,s,t], qM_CET[energy19,s,t]) =E= qEtot[energy19,t] - sum(s$d1vY_CET[energy19,s,t], qY_CET[energy19,s,t]);

      # Average annual price 
      E_pEtot[energy19,t]$(tx0[t] and d1pEtot[energy19,t])..          
        pEtot[energy19,t] * qEtot[energy19,t] =E=  
          sum(s$d1vY_CET[energy19,s,t], pY_CET[energy19,s,t] * qY_CET[energy19,s,t]) + sum(s$d1vM_CET[energy19,s,t], pM_CET[energy19,s,t] * qM_CET[energy19,s,t]);

      E_qREgj_j[purpose,energy19,r,t]$(tx0[t] and d1pREgj[purpose,energy19,r,t]).. 
        qREgj[purpose,energy19,r,t] =E= qREa[purpose,energy19,r,t]$(d1pREa[purpose,energy19,r,t]) + j_qREgj[purpose,energy19,r,t];

  # Total demand
      E_qEtot[energy19,t]$(tx0[t] and d1pEtot[energy19,t])..  qEtot[energy19,t] =E= sum((purpose,r), qREgj[purpose,energy19,r,t]$(d1pRE_base[purpose,energy19,r,t])) 
                                                                                 +  sum(purpose$d1vCE[purpose,energy19,t], qCE[purpose,energy19,t]) 
                                                                                 +  sum(purpose$d1vLE[purpose,energy19,t], qLE[purpose,energy19,t])
                                                                                 +  sum(purpose$d1vXE[purpose,energy19,t], qXE[purpose,energy19,t]) 
                                                                                 +  sum(purpose$d1TL[purpose,energy19,t],  qTL[purpose,energy19,t]);      

      E_vDistributionProfits[energy19,t]$(tx0[t] and d1pEtot[energy19,t]).. 
        vDistributionProfits[energy19,t] =E= sum((purpose,r)$(d1pRE_base[purpose,energy19,r,t]), pRE_base[purpose,energy19,r,t] * qREgj[purpose,energy19,r,t])
                                           + sum(purpose, pCE_base[purpose,energy19,t] * qCE[purpose,energy19,t]$d1vCE[purpose,energy19,t])
                                           + sum(purpose, pLE_base[purpose,energy19,t] * qLE[purpose,energy19,t]$d1vLE[purpose,energy19,t])
                                           + sum(purpose, pXE_base[purpose,energy19,t] * qXE[purpose,energy19,t]$d1vXE[purpose,energy19,t])
                                           - sum(s$d1vY_CET[energy19,s,t], pY_CET[energy19,s,t] * qY_CET[energy19,s,t])
                                           - sum(s$d1vM_CET[energy19,s,t], pM_CET[energy19,s,t] * qM_CET[energy19,s,t]);
      $ENDBLOCK
 

    # ---------------------------------------------------------------------------------------------------------------------
    # DEMAND PRICES FOR ENERGY
    # ---------------------------------------------------------------------------------------------------------------------
  
  
    $BLOCK B_energy_prices
      # Exports
        E_pXE_base[purpose,energy19,t]$(tx0[t] and d1vXE[purpose,energy19,t]).. pXE_base[purpose,energy19,t] =E= (1+fpXE[purpose,energy19,t]) * pEtot[energy19,t];
  
        E_pXE[purpose,energy19,t]$(tx0[t] and d1vXE[purpose,energy19,t]).. pXE[purpose,energy19,t] =E= (1+tXE_[purpose,energy19,t]$d1tXE[purpose,energy19,t]) * pXE_base[purpose,energy19,t];
  
      # Inventories
        E_pLE_base[purpose,energy19,t]$(tx0[t] and d1vLE[purpose,energy19,t]).. pLE_base[purpose,energy19,t] =E= (1+fpLE[purpose,energy19,t]) * pEtot[energy19,t];
  
        E_pLE[purpose,energy19,t]$(tx0[t] and d1vLE[purpose,energy19,t]).. pLE[purpose,energy19,t] =E= (1+tLE[purpose,energy19,t]$d1tLE[purpose,energy19,t]) * pLE_base[purpose,energy19,t];
  
      # Consumption 
        E_pCE_base[purpose,energy19,t]$(tx0[t] and d1vCE[purpose,energy19,t]).. 
          pCE_base[purpose,energy19,t] =E= (1+fpCE[purpose,energy19,t])  * pEtot[energy19,t];
  
  
        E_pCE[purpose,energy19,t]$(tx0[t] and d1vCE[purpose,energy19,t]).. 
          pCE[purpose,energy19,t] =E= (1+tCE[purpose,energy19,t]$d1tCE[purpose,energy19,t]) * pCE_base[purpose,energy19,t];
  
  
      # Firms
        E_pRE_base[purpose,energy19,r,t]$(tx0[t] and d1pRE_base[purpose,energy19,r,t]).. pRE_base[purpose,energy19,r,t] =E=  (1+fpRE[purpose,energy19,r,t]) * pEtot[energy19,t];
       
        E_pRE_base_marg[purpose,energy19,r,t]$(tx0[t] and d1pRE_base[purpose,energy19,r,t]).. pRE_base_marg[purpose,energy19,r,t] =E=  pEtot[energy19,t] + adj_pRE_base_marg[purpose,energy19,r,t];
  
      
        E_pREgj_market_taxed[purpose,energy19,r,t]$(tx0[t] and d1tRE[purpose,energy19,r,t] and d1pRE_base[purpose,energy19,r,t]).. 
          pREgj[purpose,energy19,r,t] =E= (1+tvREmarg[purpose,energy19,r,t]$d1tRE[purpose,energy19,r,t]) * pRE_base_marg[purpose,energy19,r,t];
  
  
        E_pREgj_market_untaxed[purpose,energy19,r,t]$(tx0[t] and not d1tRE[purpose,energy19,r,t] and d1pRE_base[purpose,energy19,r,t]).. 
          pREgj[purpose,energy19,r,t] =E=  pRE_base_marg[purpose,energy19,r,t];
  
        E_pREgj_nonmarket[purpose,energy19,r,t]$(tx0[t] and d1tRE[purpose,energy19,r,t] and not (d1pRE_base[purpose,energy19,r,t] or d1pREown[purpose,energy19,r,t])).. 
           pREgj[purpose,energy19,r,t] =E= tqREmarg[purpose,energy19,r,t]$d1tRE[purpose,energy19,r,t];
        
        E_pREown[purpose,energy19,r,s,t]$(tx0[t] and d1pREown[purpose,energy19,r,t] and mapownproduction(energy19,r,s)).. 
          pREown[purpose,energy19,r,t] =E= pY0_CET[energy19,s,t]$(not agri_sectors_s[s]) # Price on own-consumption is equal to marginal cost  
                                         + pY_CET[energy19,s,t]$(agri_sectors_s[s]);      # Hack: When linking the agricultural module and forecast agriculture with LF23 there's a significant rise in productivity (Variables TFPAni & TFPPlant), which spills over in the marginal cost of energy-straw for own-consumption
                                                                              # We have no link-equations for productivity currently though. When we fix outputprices and costs this means that the only way the CET-transformation can work 
  
        E_pREgj_owncons[purpose,energy19,r,s,t]$(tx0[t] and d1pREown[purpose,energy19,r,t] and mapownproduction(energy19,r,s)).. 
          pREgj[purpose,energy19,r,t] =E= (1+ tvREmarg[purpose,energy19,r,t]$d1tRE[purpose,energy19,r,t]) *pREown[purpose,energy19,r,t] ;
  
        E_pXE_bionatgas[t]$(tx0[t] and d1vY_CET['Natural gas incl. biongas','35002',t])..
          pXE_bionatgas[t] =E= pY_CET['Natural gas incl. biongas','35002',t];
  
    $ENDBLOCK 
  
  # ---------------------------------------------------------------------------------------------------------------------
  #  ENERGY MARGINS 
  # ---------------------------------------------------------------------------------------------------------------------

      $BLOCK B_energy_margins 
        E_vEAV_RE[purpose,energy19,r,t]$(tx0[t] and d1EAV_RE[purpose,energy19,r,t])..      
            vEAV_RE[purpose,energy19,r,t] =E= pEAV_RE[purpose,energy19,r,t] * qREgj[purpose,energy19,r,t];

        E_vDAV_RE[purpose,energy19,r,t]$(tx0[t] and d1DAV_RE[purpose,energy19,r,t])..      
            vDAV_RE[purpose,energy19,r,t] =E= pDAV_RE[purpose,energy19,r,t] * qREgj[purpose,energy19,r,t];

        E_vCAV_RE[purpose,energy19,r,t]$(tx0[t] and d1CAV_RE[purpose,energy19,r,t])..      
            vCAV_RE[purpose,energy19,r,t] =E= pCAV_RE[purpose,energy19,r,t] * qREgj[purpose,energy19,r,t];

        E_vEAV_CE[purpose,energy19,t]$(tx0[t] and d1EAV_CE[purpose,energy19,t])..      
            vEAV_CE[purpose,energy19,t] =E= pEAV_CE[purpose,energy19,t] * qCE[purpose,energy19,t];

        E_vDAV_CE[purpose,energy19,t]$(tx0[t] and d1DAV_CE[purpose,energy19,t])..      
            vDAV_CE[purpose,energy19,t] =E= pDAV_CE[purpose,energy19,t] * qCE[purpose,energy19,t];

        E_vCAV_CE[purpose,energy19,t]$(tx0[t] and d1CAV_CE[purpose,energy19,t])..      
            vCAV_CE[purpose,energy19,t] =E= pCAV_CE[purpose,energy19,t] * qCE[purpose,energy19,t];

        E_pEAV_RE[purpose,energy19,r,t]$(tx0[t] and d1vY_CET['WholeAndRetailSaleMarginE','46000',t] and d1EAV_RE[purpose,energy19,r,t])..
          pEAV_RE[purpose,energy19,r,t] =E=  (1+fpEAV_RE[purpose,energy19,r,t]) * pY_CET['WholeAndRetailSaleMarginE','46000',t];

        E_pDAV_RE[purpose,energy19,r,t]$(tx0[t] and d1vY_CET['WholeAndRetailSaleMarginE','47000',t] and d1DAV_RE[purpose,energy19,r,t])..
          pDAV_RE[purpose,energy19,r,t] =E=  (1+fpDAV_RE[purpose,energy19,r,t]) * pY_CET['WholeAndRetailSaleMarginE','47000',t];

        E_pCAV_RE[purpose,energy19,r,t]$(tx0[t] and d1vY_CET['WholeAndRetailSaleMarginE','45000',t] and d1CAV_RE[purpose,energy19,r,t])..
          pCAV_RE[purpose,energy19,r,t] =E=  (1+fpCAV_RE[purpose,energy19,r,t]) * pY_CET['WholeAndRetailSaleMarginE','45000',t];


        E_pEAV_CE[purpose,energy19,t]$(tx0[t] and d1vY_CET['WholeAndRetailSaleMarginE','46000',t] and d1EAV_CE[purpose,energy19,t])..
          pEAV_CE[purpose,energy19,t]  =E=  (1+fpEAV_CE[purpose,energy19,t]) * pY_CET['WholeAndRetailSaleMarginE','46000',t];

        E_pDAV_CE[purpose,energy19,t]$(tx0[t] and d1vY_CET['WholeAndRetailSaleMarginE','47000',t] and d1DAV_CE[purpose,energy19,t])..
          pDAV_CE[purpose,energy19,t]  =E=  (1+fpDAV_CE[purpose,energy19,t]) * pY_CET['WholeAndRetailSaleMarginE','47000',t];

        E_pCAV_CE[purpose,energy19,t]$(tx0[t] and d1vY_CET['WholeAndRetailSaleMarginE','45000',t] and d1CAV_CE[purpose,energy19,t])..
          pCAV_CE[purpose,energy19,t]  =E=  (1+fpCAV_CE[purpose,energy19,t]) * pY_CET['WholeAndRetailSaleMarginE','45000',t];


        E_vOtherDistributionProfits_EAV[t]$(tx0[t])..
          vOtherDistributionProfits_EAV[t] =E= sum((purpose,energy19,r)$(d1EAV_RE[purpose,energy19,r,t]), vEAV_RE[purpose,energy19,r,t])
                                              +sum((purpose,energy19)$(d1EAV_CE[purpose,energy19,t]), vEAV_CE[purpose,energy19,t])
                                              - pY_CET['WholeAndRetailSaleMarginE','46000',t]*qY_CET['WholeAndRetailSaleMarginE','46000',t]
                                              ;

        E_vOtherDistributionProfits_DAV[t]$(tx0[t])..
          vOtherDistributionProfits_DAV[t] =E= sum((purpose,energy19,r)$(d1DAV_RE[purpose,energy19,r,t]), vDAV_RE[purpose,energy19,r,t])
                                              +sum((purpose,energy19)$(d1DAV_CE[purpose,energy19,t]), vDAV_CE[purpose,energy19,t])
                                              - pY_CET['WholeAndRetailSaleMarginE','47000',t]*qY_CET['WholeAndRetailSaleMarginE','47000',t]
                                              ;

        E_vOtherDistributionProfits_CAV[t]$(tx0[t])..
          vOtherDistributionProfits_CAV[t] =E= sum((purpose,energy19,r)$(d1CAV_RE[purpose,energy19,r,t]), vCAV_RE[purpose,energy19,r,t])
                                              +sum((purpose,energy19)$(d1CAV_CE[purpose,energy19,t]), vCAV_CE[purpose,energy19,t])
                                              - pY_CET['WholeAndRetailSaleMarginE','45000',t]*qY_CET['WholeAndRetailSaleMarginE','45000',t]
                                              ;

      $ENDBLOCK
  

    # ---------------------------------------------------------------------------------------------------------------------
    # BIO-FUELS IN TRANSPORTATION
    # ---------------------------------------------------------------------------------------------------------------------

  
    $BLOCK B_biofuelsintransport 
          # Leontief demand:
      E_qREE_transport[purpose,energy19a,energy19,s,t]$(tx0[t] and d1vREE_transport[purpose,energy19a,energy19,s,t]).. 
        qREE_transport[purpose,energy19a,energy19,s,t] =E= uREExID_transport[purpose,energy19a,energy19,s,t] * qREa[purpose,energy19a,s,t];
  
      # CES price of energy activities:
      E_j_pREa_transport[purpose,energy19a,s,t]$(tx0[t] and sum(energy19,d1vREE_transport[purpose,energy19a,energy19,s,t])).. 
        pREa[purpose,energy19a,s,t] =E= 
        #Energy costs:
        sum(energy19$(d1vREE_transport[purpose,energy19a,energy19,s,t]), pREgj[purpose,energy19,s,t]*uREExID_transport[purpose,energy19a,energy19,s,t]); 
        
      # Energy demand by sector and purpose (replaces E_qRE in aggregates.gms)
      E_j_qREgj_transport[purpose,energy19,s,t]$(tx0[t] and sum(energy19a,d1vREE_transport[purpose,energy19a,energy19,s,t])).. 
        qREgj[purpose,energy19,s,t] =E= 
        sum(energy19a$(d1vREE_transport[purpose,energy19a,energy19,s,t]), 
          qREE_transport[purpose,energy19a,energy19,s,t]);
  
    $ENDBLOCK


    # ---------------------------------------------------------------------------------------------------------------------
    # Linking bio-fuels to non-energy feedstock bio-oils
    # ---------------------------------------------------------------------------------------------------------------------

    #  $BLOCK B_biofuel_feedstock_for_mixing 
    #      #Refineries bye biodiesel in the following proportions
    #      E_qFAME_from_foodindustries_y.. 0.4 * pY_CET['Biodiesel','19000',t]*qY_CET['Biodiesel','19000',t] * jFAME_from_foodindustries_y[t] 
    #            =E= pY_CET['out_other','10120',t]*qFAME_from_foodindustries_y[t];

    #      E_qFAME_from_chemicalindustry_y.. 0.4 * pY_CET['Biodiesel','19000',t]*qY_CET['Biodiesel','19000',t] * jFAME_from_chemicalindustry_y[t] 
    #            =E= pY_CET['out_other','20000',t]*qFAME_from_chemicalindustry_y[t];

    #      E_qFAME_from_foodindustries_m.. 0.1 * pY_CET['Biodiesel','19000',t]*qY_CET['Biodiesel','19000',t] * jFAME_from_foodindustries_m[t] 
    #            =E= pM_CET['out_other','10120',t]*qFAME_from_foodindustries_m[t];

    #      E_qFAME_from_chemicalindustry_m.. 0.1 * pY_CET['Biodiesel','19000',t]*qY_CET['Biodiesel','19000',t] * jFAME_from_chemicalindustry_m[t] 
    #            =E= pM_CET['out_other','20000',t]*qFAME_from_chemicalindustry_m[t];
    #  $ENDBLOCK


  
    $MODEL M_energy_markets_clearing B_energy_markets_clearing;
    $MODEL M_energy_prices B_energy_prices;
    $MODEL M_energy_margins B_energy_margins;
    $MODEL M_biofuelsintransport B_biofuelsintransport;

    $MODEL M_energy_markets 
      B_energy_markets_clearing
    	B_energy_prices
      B_energy_margins
      B_biofuelsintransport
    ;
  
  $ENDIF 


# ========================================================================================================================
# Exogenous variables
# ========================================================================================================================

  $IF %stage% == "exogenous_values":
  
  #1) READ DATA 
  
  	#Energy-prices 
  	  pRE_base.l[purpose,energy19,r,t] = EN_pRE_base[purpose,energy19,r,t];
  	  pCE_base.l[purpose,energy19,t]   = EN_pCE_base[purpose,energy19,t];
  	  pLE_base.l[purpose,energy19,t]   = EN_pLE_base[purpose,energy19,t];
  	  pXE_base.l[purpose,energy19,t]   = EN_pXE_base[purpose,energy19,t];
  
    # Energy-markets, clearing
      pY_CET.l[out,s,t]$(energy19[out])      = IO_pY_CET[out,s,t]; 
      qY_CET.l[out,s,t]$(energy19[out])      = IO_qY_CET[out,s,t];
      pM_CET.l[out,s,t]$(energy19[out])      = IO_pM_CET[out,s,t]; 
      qM_CET.l[out,s,t]$(energy19[out])      = IO_qM_CET[out,s,t]; 
      qMNatgasNL.l[t]                        = TIL_qE_m_NatgasNL.l[t]/correction_factor_joule; # ØRSTED
      pMNatgasNL.l[t]$TIL_qE_m_NatgasNL.l[t] = (TIL_vE_m_NatgasNL.l[t]/correction_factor_values)/(TIL_qE_m_NatgasNL.l[t]/correction_factor_joule); # ØRSTED
      

      qTL.l[purpose,energy19,t] = EN_qTL[purpose,energy19,t];

      qRENEWABLE.l[energy19,t] = sum(types_renewable, EN_qRENEWABLE[energy19,types_renewable,t]);


      # Energy activity and consumption in firms (including consumption of own-produced energy input)
        qREgj.l[purpose,energy19,r,t] = EN_qRE[purpose,energy19,r,t];


    #Margins
      pEAV_RE.l[purpose,energy19,r,t]  = EN_pEAV_RE[purpose,energy19,r,t];
      pEAV_CE.l[purpose,energy19,t]    = EN_pEAV_CE[purpose,energy19,t];
      pDAV_RE.l[purpose,energy19,r,t]  = EN_pDAV_RE[purpose,energy19,r,t];
      pDAV_CE.l[purpose,energy19,t]    = EN_pDAV_CE[purpose,energy19,t];
      pCAV_RE.l[purpose,energy19,r,t]  = EN_pCAV_RE[purpose,energy19,r,t];
      pCAV_CE.l[purpose,energy19,t]    = EN_pCAV_CE[purpose,energy19,t];
    
      vEAV_RE.l[purpose,energy19,r,t]  = EN_vEAV_RE[purpose,energy19,r,t];
      vEAV_CE.l[purpose,energy19,t]    = EN_vEAV_CE[purpose,energy19,t];
      vDAV_RE.l[purpose,energy19,r,t]  = EN_vDAV_RE[purpose,energy19,r,t];
      vDAV_CE.l[purpose,energy19,t]    = EN_vDAV_CE[purpose,energy19,t];
      vCAV_RE.l[purpose,energy19,r,t]  = EN_vCAV_RE[purpose,energy19,r,t];
      vCAV_CE.l[purpose,energy19,t]    = EN_vCAV_CE[purpose,energy19,t];  

  #2) EXOGENOUS VALUES 
  
    #Energy-markets clearing
      eAGG.l(energy19)      = 5;
      #  eAGG.l('Electricity') = 0.5;
      eAGG.l('electricity') = 0.5; 
      eAGG.l('El from y and m') = 0.5;
  
  
  
  #3) COMPUTATIONS
  
    #Bio-fuels in transportation

      uREExID_transport.l[purpose,'Gasoline for transport','Gasoline for transport',s,t]$(sENS2GR('vejtransport','vejtransport',purpose,'Gasoline for transport',s) 
                                                                          and ((EN_qRE[purpose,'Gasoline for transport',s,t] + EN_qRE[purpose,'Bioethanol',s,t])))
                                                                                = EN_qRE[purpose,'Gasoline for transport',s,t]/(EN_qRE[purpose,'Gasoline for transport',s,t] + EN_qRE[purpose,'Bioethanol',s,t]); 

      uREExID_transport.l[purpose,'Gasoline for transport','Bioethanol',s,t]$(sENS2GR('vejtransport','vejtransport',purpose,'Gasoline for transport',s) 
                                                                                and ((EN_qRE[purpose,'Gasoline for transport',s,t] + EN_qRE[purpose,'Bioethanol',s,t]))) 
                                                                                = 1 -uREExID_transport.l[purpose,'Gasoline for transport','Gasoline for transport',s,t];

      uREExID_transport.l[purpose,'Diesel for transport','Diesel for transport',s,t]$(sENS2GR('vejtransport','vejtransport',purpose,'Diesel for transport',s) 
                                                                                and (EN_qRE[purpose,'Diesel for transport',s,t] + EN_qRE[purpose,'Biodiesel',s,t])) 
                                                                                  = EN_qRE[purpose,'Diesel for transport',s,t]/(EN_qRE[purpose,'Diesel for transport',s,t] + EN_qRE[purpose,'Biodiesel',s,t]);  

      uREExID_transport.l[purpose,'Diesel for transport','Biodiesel',s,t]$(sENS2GR('vejtransport','vejtransport',purpose,'Diesel for transport',s) 
                                                                                and (EN_qRE[purpose,'Diesel for transport',s,t] + EN_qRE[purpose,'Biodiesel',s,t])) 
                                                                                =  1- uREExID_transport.l[purpose,'Diesel for transport','Diesel for transport',s,t];
          
  #5) DUMMIES 
  
      d1TL[purpose,energy19,t]      = yes$(qTL.l[purpose,energy19,t]);
      d1RENEWABLE[energy19,t]       = yes$(qRENEWABLE.l[energy19,t]);

      d1qREgj[purpose,energy19,r,t] = yes$(qREgj.l[purpose,energy19,r,t]);

  	#Energy prices 
  	  d1pREown[purpose,energy19,r,t] = no; 
  	  d1pREown['in_ETS','Natural gas (Extraction)','0600a',tData]   = yes;  #Dummy hard-codes da ikke al egetforbrug er modelleret endnu 
  	  # d1pREown['heating','straw for energy purposes','01020',tData] = yes; 
  	  d1pREown['heating','straw for energy purposes','01051',tData] = yes; 
      $IF1 %smaagrisesplit%:
  	  d1pREown['heating','straw for energy purposes','01052',tData] = yes; 
      $ENDIF1
  	  d1pREown['heating','straw for energy purposes','01061',tData] = yes; 
  	  d1pREown['heating','straw for energy purposes','01062',tData] = yes; 
  	  d1pREown['process_normal','straw for energy purposes','01051',tData] = yes; 
      $IF1 %smaagrisesplit%:
  	  d1pREown['process_normal','straw for energy purposes','01052',tData] = yes; 
      $ENDIF1
  	  d1pREown['process_normal','straw for energy purposes','01061',tData] = yes; 
  	  d1pREown['process_normal','straw for energy purposes','01062',tData] = yes; 
  
  	  pREown.l[purpose,energy19,r,t]$(d1pREown[purpose,energy19,r,t]) = sum(s$mapownproduction(energy19,r,s), IO_pY_CET[energy19,s,t]);
  
  
  	  d1pRE_base[purpose,energy19,r,t] = yes$(pRE_base.l[purpose,energy19,r,t]);
  	  d1vCE[purpose,energy19,t]        = yes$(EN_vnCE[purpose,energy19,t]);
    	d1vLE[purpose,energy19,t]        = yes$(EN_vnLE[purpose,energy19,t]);
      d1vXE[purpose,energy19,t]        = yes$(EN_vnXE[purpose,energy19,t]);
  
    #Margins 
      d1EAV_RE[purpose,energy19,r,t] = yes$(EN_vEAV_RE[purpose,energy19,r,t]);
      d1EAV_CE[purpose,energy19,t]   = yes$(EN_vEAV_CE[purpose,energy19,t]);
      d1DAV_RE[purpose,energy19,r,t] = yes$(EN_vDAV_RE[purpose,energy19,r,t]);
      d1DAV_CE[purpose,energy19,t]   = yes$(EN_vDAV_CE[purpose,energy19,t]);
      d1CAV_RE[purpose,energy19,r,t] = yes$(EN_vCAV_RE[purpose,energy19,r,t]);
      d1CAV_CE[purpose,energy19,t]   = yes$(EN_vCAV_CE[purpose,energy19,t]);

    #Bio-fuels in transportation 
  
      d1qREE_transport[purpose,energy19a,energy19,s,t] = yes$(uREExID_transport.l[purpose,energy19a,energy19,s,t]);
      #d1vREE_transport is set in "update_dummies.gms"
  
  $ENDIF 

# ========================================================================================================================
# Static calibration
# ========================================================================================================================


  $IF %stage% == "static_calibration":
  
    $BLOCK B_energy_markets_clearing_static_calibration
      E_qAGG_y_static_calib[energy19,s,t]$(tx0[t] and d1vY_CET[energy19,s,t] and not d1vE_onesupplier[energy19,t]).. 
        sY_AGG[energy19,s,t] =E= qY_CET[energy19,s,t]/qEtot[energy19,t] * pY_CET[energy19,s,t]**eAGG(energy19);

      E_qAGG_m_static_calib[energy19,s,t]$(tx0[t] and d1vM_CET[energy19,s,t] and not d1vE_onesupplier[energy19,t]).. 
        sM_AGG[energy19,s,t] =E= qM_CET[energy19,s,t]/qEtot[energy19,t] * pM_CET[energy19,s,t]**eAGG(energy19);

   $ENDBLOCK
  
  
  	$GROUP G_energy_markets_static_calibration 
  		G_energy_markets_endo 
      #Energy-markets clearing 
        sY_AGG$(tx0[t] and d1vY_CET[energy19,s,t]  and not d1vE_onesupplier[energy19,t]) 
        sY_AGG$(tx0[t] and d1vY_CET[energy19,s,t] and sameas[energy19,'semi-refined oil'] and sameas[s,'19000'])
        -qY_CET$(energy19[out])
        sM_AGG$(tx0[t] and d1vM_CET[energy19,s,t] and not d1vE_onesupplier[energy19,t]), -qM_CET$(energy19[out])
        -qTL$(d1TL[purpose,energy19,t]) 

      #Energy-prices
        fpCE$(tx0[t] and d1vCE[purpose,energy19,t]),     fpRE$(tx0[t] and d1pRE_base[purpose,energy19,r,t]),     fpLE$(tx0[t] and d1vLE[purpose,energy19,t]),     fpXE$(tx0[t] and d1vXE[purpose,energy19,t]) 
        -pCE_base$(d1vCE[purpose,energy19,t]),-pRE_base$(d1pRE_base[purpose,energy19,r,t]),-pLE_base$(d1vLE[purpose,energy19,t]),-pXE_base$(d1vXE[purpose,energy19,t])
  
      #Margins
      -pEAV_CE$(d1EAV_CE[purpose,energy19,t])   , fpEAV_CE$(tx0[t] and d1EAV_CE[purpose,energy19,t])
      -pEAV_RE$(d1EAV_RE[purpose,energy19,r,t]) , fpEAV_RE$(tx0[t] and d1EAV_RE[purpose,energy19,r,t])
      -pDAV_CE$(d1DAV_CE[purpose,energy19,t])   , fpDAV_CE$(tx0[t] and d1DAV_CE[purpose,energy19,t])
      -pDAV_RE$(d1DAV_RE[purpose,energy19,r,t]) , fpDAV_RE$(tx0[t] and d1DAV_RE[purpose,energy19,r,t])
      -pCAV_CE$(d1CAV_CE[purpose,energy19,t])   , fpCAV_CE$(tx0[t] and d1CAV_CE[purpose,energy19,t])
      -pCAV_RE$(d1CAV_RE[purpose,energy19,r,t]) , fpCAV_RE$(tx0[t] and d1CAV_RE[purpose,energy19,r,t])
  	;
  
  	$GROUP G_energy_markets_static_calibration_exo
  		G_energy_markets_exo 
      #Energy-markets clearing 
        qY_CET$(tx0[t] and d1vY_CET[out,s,t] and energy19[out]), -sY_AGG 
        qM_CET$(tx0[t] and d1vM_CET[out,s,t] and energy19[out]), -sM_AGG
        qTL$(tx0[t] and d1TL[purpose,energy19,t]) 

        #Energy-prices
        -fpCE$(d1vCE[purpose,energy19,t])   ,-fpRE$(d1pRE_base[purpose,energy19,r,t]),   -fpLE$(d1vLE[purpose,energy19,t]),    -fpXE$(d1vXE[purpose,energy19,t])
        pCE_base$(tx0[t] and d1vCE[purpose,energy19,t]), pRE_base$(tx0[t] and d1pRE_base[purpose,energy19,r,t]), pLE_base$(tx0[t] and d1vLE[purpose,energy19,t]) ,pXE_base$(tx0[t] and d1vXE[purpose,energy19,t]) 

      #Margins
        pEAV_CE$(tx0[t] and d1EAV_CE[purpose,energy19,t])   , -fpEAV_CE$(d1EAV_CE[purpose,energy19,t])
        pEAV_RE$(tx0[t] and d1EAV_RE[purpose,energy19,r,t]) , -fpEAV_RE$(d1EAV_RE[purpose,energy19,r,t])
        pDAV_CE$(tx0[t] and d1DAV_CE[purpose,energy19,t])   , -fpDAV_CE$(d1DAV_CE[purpose,energy19,t])
        pDAV_RE$(tx0[t] and d1DAV_RE[purpose,energy19,r,t]) , -fpDAV_RE$(d1DAV_RE[purpose,energy19,r,t])
        pCAV_CE$(tx0[t] and d1CAV_CE[purpose,energy19,t])   , -fpCAV_CE$(d1CAV_CE[purpose,energy19,t])
        pCAV_RE$(tx0[t] and d1CAV_RE[purpose,energy19,r,t]) , -fpCAV_RE$(d1CAV_RE[purpose,energy19,r,t])
  	;
  
  
  	$MODEL M_energy_markets_static_calibration 
  		M_energy_markets
      B_energy_markets_clearing_static_calibration
      -E_qM_CET_onesupplier
      -E_qY_CET_energy19
      -E_qM_CET_energy19

  	;
  
  $ENDIF 
  
  
  # ========================================================================================================================
  # Dynamic calibration
  # ========================================================================================================================
  
  $IF %stage% == "dynamic_calibration":
  
    $BLOCK B_energy_markets_clearing_calib
     E_qTL[purpose,energy19,t]$(tx1[t] and d1TL[purpose,energy19,t]).. qTL[purpose,energy19,t] =E= qTL[purpose,energy19,tDataEnd];
     E_qRENEWABLE[energy19,t]$(tx1[t] and d1RENEWABLE[energy19,t] and not d1waste_module[energy19,t]).. qRENEWABLE[energy19,t] =E= qRENEWABLE[energy19,tDataEnd];
    $ENDBLOCK  
 
    #We want a clean model wrt. semi-refined oil, which is not in ENS-data. Hence "distributors mark-ups below", as well as the variable markup is set to zero.
    fpRE.l[purpose,'semi-refined oil',s,tForecast] = 0;
    fpxE.l[purpose,'semi-refined oil',tForecast]   = 0;

    pM_CET.l['Biodiesel','19000',t]$(tx0[t] or t0[t]) = pY_CET.l['Biodiesel','19000',t];
    d1vM_CET['Biodiesel','19000',t]$(tx0[t] or t0[t]) = yes;

    $GROUP G_data 
        G_data 
        -pM_CET$(d1vM_CET[out,s,t] and sameas[s,'19000'] and sameas[out,'biodiesel'])
    ;

  	$GROUP G_energy_markets_calib 
  		G_energy_markets_endo 
      qTL$(d1TL[purpose,energy19,t] and tx1[t]) 
      qRENEWABLE$(d1RENEWABLE[energy19,t] and tx1[t] and not d1waste_module[energy19,t])
  
  
  	;
  
  	$GROUP G_energy_markets_calib_exo
  		G_energy_markets_exo 
      -qTL$(d1TL[purpose,energy19,t] and tx1[t]) 
      qRENEWABLE$(d1RENEWABLE[energy19,t] and tDataEnd[t] and not d1waste_module[energy19,t])
  	;
  
  
  	$MODEL M_energy_markets_calib 
  		M_energy_markets
      B_energy_markets_clearing_calib
  	;
  	
  $ENDIF 