
$MODEL M_Energy_price_partial
    # Base prices
    E_pRE_base
    E_pRE_base_marg
    E_pREown

    #ETS 
    E_tCO2_ETS_GJ
    E_tCO2_ETS2_GJ

    # Carbon taxes
    E_tCO2_REmarg_GJ
    E_tCO2_REmarg_GJ_districtheat
    #ETS 
    E_tCO2_ETS_GJ
    E_tCO2_ETS2_GJ

    # Margins
    E_pEAV_RE
    E_pDAV_RE
    E_pCAV_RE
    
    # Total taxes
    E_tREmarg_market
    E_tREmarg_market_own
    E_tREmarg_nonmarket
    # Consumer prices
    E_pREgj_market_taxed
    E_pREgj_market_untaxed
    E_pREgj_nonmarket
    E_pREgj_owncons
;

$GROUP G_Energy_price_endo
    #E_pRE_base_marg
    pRE_base_marg$(tx0[t] and d1pRE_base[purpose,energy19,r,t])
    #E_pREown
    pREown$(tx0[t] and d1pREown[purpose,energy19,r,t])

    #E_tCO2_ETS_GJ
    tCO2_ETS_GJ$(tx0[t] and d1tCO2_ETS_marg[purpose,energy19,r,t])    

    #E_tCO2_ETS2_GJ
    tCO2_ETS2_GJ$(tx0[t] and d1CO2_ETS2_marg[purpose,energy19,r,t])

    #E_tCO2_REmarg_GJ
    tCO2_REmarg_GJ$(tx0[t] and d1CO2_REmarg[purpose,energy19,r,t,emm_eq] and not sameas[energy19,'district heat'] and (sameas[emm_eq,'CO2ubio'] or sameas[emm_eq,'CO2bio']))
    #E_tCO2_REmarg_GJ_districtheat
    tCO2_REmarg_GJ$(tx0[t] and d1CO2_REmarg[purpose,energy19,r,t,'CO2ubio'] and sameas[energy19,'district heat'])
    #E_pEAV_RE
    pEAV_RE$(tx0[t] and d1vY_CET['WholeAndRetailSaleMarginE','46000',t] and d1EAV_RE[purpose,energy19,r,t])
    #E_pDAV_RE
    pDAV_RE$(tx0[t] and d1vY_CET['WholeAndRetailSaleMarginE','47000',t] and d1DAV_RE[purpose,energy19,r,t])
    #E_pCAV_RE
    pCAV_RE$(tx0[t] and d1vY_CET['WholeAndRetailSaleMarginE','45000',t] and d1CAV_RE[purpose,energy19,r,t])
    #E_tREmarg_market
    tvREmarg$(tx0[t] and d1tRE[purpose,energy19,r,t] and d1pRE_base[purpose,energy19,r,t])
    #E_tREmarg_market_own
    tvREmarg$(tx0[t] and d1tRE[purpose,energy19,r,t] and d1pREown[purpose,energy19,r,t])
    #E_tREmarg_nonmarket
    tqREmarg$(tx0[t] and d1tRE[purpose,energy19,r,t] and not (d1pRE_base[purpose,energy19,r,t] or d1pREown[purpose,energy19,r,t]))
    #E_pREgj_market_taxed
    pREgj$(tx0[t] and d1tRE[purpose,energy19,r,t] and d1pRE_base[purpose,energy19,r,t])
    #E_pREgj_market_untaxed
    pREgj$(tx0[t] and not d1tRE[purpose,energy19,r,t] and d1pRE_base[purpose,energy19,r,t])
    #E_pREgj_nonmarket
    pREgj$(tx0[t] and d1tRE[purpose,energy19,r,t] and not (d1pRE_base[purpose,energy19,r,t] or d1pREown[purpose,energy19,r,t]))
    #E_pREgj_owncons
    pREgj$(tx0[t] and d1pREown[purpose,energy19,r,t])
;

$GROUP G_Energy_price_exo
    #E_pRE_base_marg
    pEtot$(tx0[t] and sum(purpose,sum(r,d1pRE_base[purpose,energy19,r,t])))
    adj_pRE_base_marg$(tx0[t] and d1pRE_base[purpose,energy19,r,t])
    #E_pRE_base
    fpRE[purpose,energy19,r,t]$(d1pRE_base[purpose,energy19,r,t])
    pEtot


    #E_pREown
    pY0_CET$(not agri_sectors_s[s])
    pY_CET$(agri_sectors_s[s])

    #E_tCO2_REmarg_GJ and E_tCO2_REmarg_GJ_districtheat AND E_tCO2_ETS_GJ, E_tCO2_ETS2_GJ
    uEOPProdE$(sameas[emm,'CO2bio'] or sameas[emm,'CO2ubio'])
    uEmmProdE$(sameas[emm,'CO2bio'] or sameas[emm,'CO2ubio'])
    sBionatgas
    tCO2_REmarg$(tx0[t] and d1CO2_REmarg[purpose,energy19,r,t,emm_eq])

    #E_pEAV_RE
    fpEAV_RE$(tx0[t] and d1vY_CET['WholeAndRetailSaleMarginE','46000',t] and d1EAV_RE[purpose,energy19,r,t])
    pY_CET$(tx0[t] and d1vY_CET[out,s,t] and sameas[out,'WholeAndRetailSaleMarginE'] and sameas[s,'46000'])
    #E_pDAV_RE
    fpDAV_RE$(tx0[t] and d1vY_CET['WholeAndRetailSaleMarginE','47000',t] and d1DAV_RE[purpose,energy19,r,t])
    pY_CET$(tx0[t] and d1vY_CET[out,s,t] and sameas[out,'WholeAndRetailSaleMarginE'] and sameas[s,'47000'])
    #E_pCAV_RE
    fpCAV_RE$(tx0[t] and d1vY_CET['WholeAndRetailSaleMarginE','45000',t] and d1CAV_RE[purpose,energy19,r,t])
    pY_CET$(tx0[t] and d1vY_CET[out,s,t] and sameas[out,'WholeAndRetailSaleMarginE'] and sameas[s,'45000'])

    #E_tREmarg_market and E_tREmarg_market_own and E_tREmarg_nonmarket
    tVAT_RE$(d1VAT_RE[purpose,energy19,r,t])
    tEAFG_REmarg$(d1EAFG_RE[purpose,energy19,r,t])
    tSO2_RE$(d1SO2_RE[purpose,energy19,r,t])
    tPSO_RE$(d1PSO_RE[purpose,energy19,r,t])
    tNOx_RE$(d1NOx_RE[purpose,energy19,r,t])
    tCO2_REmarg_GJ$(d1CO2_REmarg[purpose,energy19,r,t,emm_eq])
    pEAV_RE$(d1EAV_RE[purpose,energy19,r,t])
    pDAV_RE$(d1DAV_RE[purpose,energy19,r,t])
    pCAV_RE$(d1CAV_RE[purpose,energy19,r,t])
    tCALIBENS$(d1pREgj[purpose,energy19,r,t])
    tCO2_ETS_GJ$(d1tCO2_ETS_marg[purpose,energy19,r,t]) 
    tCO2_ETS2_GJ$(d1CO2_ETS2_marg[purpose,energy19,r,t]) 
;


$FIX G_Energy_price_exo;
$UNFIX G_Energy_price_endo;
# execute_unloaddi '..\Output\Pre.gdx';
@SOLVE(M_Energy_price_partial);

# Check that prices are the same on existing energy use
LOOP((purpose,energy19,r,t)$(tx0[t] and pREgj_baseline.l[purpose,energy19,r,t]),
    tjek = (pREgj.l[purpose,energy19,r,t]/pREgj_baseline.l[purpose,energy19,r,t]-1)*100;
    ABORT$(abs(tjek) > 0.00001) tjek, "Prices change on existing energy use";
);

# execute_unload 'Output\Energy_Price_partial.gdx';