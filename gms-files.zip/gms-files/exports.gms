# =====================================================================================================================
# Foreign sector
# =====================================================================================================================

# =====================================================================================================================
# Variable definition
# =====================================================================================================================
$IF %stage% == "variables":
  $GROUP G_exports_prices
  pXF_ene[energy19,t]$(tx0[t] and sum(purpose,d1vXE[purpose,energy19,t]))       "Export competing foreign price level of energy goods"
  pXF[s,t]$(tx0[t] and sum(x,d1X_y[x,s,t]+d1X_m[x,s,t]))                        "Export competing foreign price level non energy goods"
  pXE_ElNl[t]                                                                   "Export of electricity in Netherlands" #�rsted
  ;

  $GROUP G_exports_quantities
     qX_y[x,s,t]$(tx0[t] and d1X_y[x,s,t])                                      "Exports of domestic origin"
     qX_m[x,s,t]$(tx0[t] and d1X_m[x,s,t])                                      "Exports of foreign origin (Import for reexport)"
     qXE[purpose,energy19,t]$(tx0[t] and d1vXE[purpose,energy19,t])             "Exports of energy-goods"
     qCtourist[c,t]$(tx0[t] and d1CTourist[c,t])                                "Tourist consumption in Denmark"
     qXE_ElNl[t]                                                                "Exports of electricity in netherlands" # �rsted
  ;

  $GROUP G_exports_sluggish_prices  
     pX_y_hat[x,s,t]$(tx0[t] and d1X_y[x,s,t] and not tData[t])                 "Price of exports of domestic origin with sluggishness"
     pX_m_hat[x,s,t]$(tx0[t] and d1X_m[x,s,t] and not tData[t])                 "Price of exports of foreign origin (Import for reexport) with sluggishness"
  ;

  $GROUP G_exports_other
    sX_y[x,s,t]$(tx0[t] and d1X_y[x,s,t])                                       "Export parameter"
    sX_m[x,s,t]$(tx0[t] and d1X_m[x,s,t])                                       "Export parameter"
    eXF[x,s]$((sum(tt,d1X_y[x,s,tt]) or sum(tt,d1X_m[x,s,tt])) and not sameas[s,'35011'])  "Export elasticity"
    sXE[purpose,energy19,t]$(tx0[t] and d1vXE[purpose,energy19,t])              "Scale parameter in exports of energy"
    eXF_ene[energy19]$(sum(tt,(sum(purpose,d1vXE[purpose,energy19,tt]))))       "Elasticity of substitution for foreign importers of Danish energy products"
    uCturisme[c,t]$(tx0[t] and d1CTourist[c,t])                                 "Adjustment parameter for private consumption by tourist in Denmark" 
    ZE[t]$(tx0[t] and (sum(purpose,sum(energy19, d1vXE[purpose,energy19,t])) or sum(x,sum(s, d1X_ym[x,s,t])))) ""
    pX_traek[x,s,t]$(tx0[t] and d1X_ym[x,s,t] and not tData[t])                 "Parameter to ensure sluggish export adjustments"
    j_pX_y_hat[x,s,t]$(tx0[t] and d1X_y[x,s,t] and not tData[t])                ""
 ;

$ENDIF 

$IF %stage% == "groupcompilation":

  $GROUP G_exports_endo
    G_exports_quantities
    G_exports_sluggish_prices
    -qXE_ElNl
  ;
  
  $GROUP G_exports_exo
    G_exports_prices
    G_exports_other
    -pXE_ElNl
    pXE$(tx0[t] and d1vXE[purpose,energy19,t])
    qX$(tx0[t] and sameas(x_,'xTur') and sum(c,d1CTourist[c,t]))
    pX$((t0[t] or tx0E[t]) and sameas(x_,'xTur') and sum(c,d1CTourist[c,t]))
    pCtourist$((t0[t] or tx0E[t]) and d1CTourist[c,t])
    j_qX_y[x,s,t]$(tx0[t] and d1X_y[x,s,t])                                     "Export slack variable (used for controlling exports elsewhere in the model when needed (i.e. in the waste module)"
    pX_y$(tx0[t] and d1X_y[x,s,t] and not tData[t])
    pX_y_hat$(((t0[t] and (tDataEnd[t] or not tData[t])) or (tx0[t] and tData[t])) and d1X_y[x,s,t])
    pX_m$(tx0[t] and d1X_m[x,s,t] and not tData[t])
    pX_m_hat$(((t0[t] and (tDataEnd[t] or not tData[t])) or (tx0[t] and tData[t])) and d1X_m[x,s,t])
  ;


$ENDIF


# =====================================================================================================================
# Equations
# =====================================================================================================================

$IF %stage% == "equations":
  $BLOCK B_exports
    #  # Exports                                                              
    E_qX_y[x,s,t]$(tx0[t] and d1X_y[x,s,t]).. qX_y[x,s,t] =E= ZE[t]*sX_y[x,s,t] * ( pX_y_hat[x,s,t] / pXF[s,t])**(-eXF[x,s]) + j_qX_y[x,s,t];

    E_pX_y_hat[x,s,t]$(tx0[t] and d1X_y[x,s,t] and not tData[t]).. pX_y_hat[x,s,t] =E= pX_traek[x,s,t] * pX_y_hat[x,s,t-1]/fp + (1-pX_traek[x,s,t]) * pX_y[x,s,t] + j_pX_y_hat[x,s,t];
 
    E_qX_m[x,s,t]$(tx0[t] and d1X_m[x,s,t]).. qX_m[x,s,t] =E= ZE[t]*sX_m[x,s,t] * ( pX_m_hat[x,s,t] / pXF[s,t])**(-eXF[x,s]);

    E_pX_m_hat[x,s,t]$(tx0[t] and d1X_m[x,s,t] and not tData[t]).. pX_m_hat[x,s,t] =E= pX_traek[x,s,t] * pX_m_hat[x,s,t-1]/fp + (1-pX_traek[x,s,t]) * pX_m[x,s,t];

    # Energy 
    E_qXE[purpose,energy19,t]$(tx0[t] and d1vXE[purpose,energy19,t]).. qXE[purpose,energy19,t] =E= ZE[t]*sXE[purpose,energy19,t] * (pXE[purpose,energy19,t]/pXF_ene[energy19,t]) ** (-eXF_ene[energy19]);

    # Tourist consumption in Denmark      
    E_qCtourist[c,t]$(tx0[t] and d1CTourist[c,t])..
      qCtourist[c,t] * pCtourist[c,t-1]$(d1CTourist[c,t-1]) =E= uCturisme[c,t] * qX['xTur',t] * pX['xTur',t-1];

   $ENDBLOCK

   $MODEL M_exports B_exports;
$ENDIF


$IF %stage% == "exogenous_values":
# =====================================================================================================================
# Exogenous variables
# =====================================================================================================================

  eXF.L[x,s]            = 5;

# =====================================================================================================================
# Data assignment
# =====================================================================================================================
  $GROUP G_exports_data  # Variables covered by data
    qX_y, qX_m
  ;

  qCtourist.l[c,t] = io_qCtourist[c,t];

  qX_y.l[x,s,t] = io_qX_y[x,s,t];
  qX_m.l[x,s,t] = io_qX_m[x,s,t];
 
  tX_y.l[x,s,t] = IO_tX_y[x,s,t];
  tX_m.l[x,s,t] = IO_tX_m[x,s,t]; 
 
  pM.l[s_,t] = IO_pM[s_,t];

  pX_y_hat.l[x,s,t]$(tData[t] and d1X_y[x,s,t]) = pX_y.l[x,s,t]$(tData[t] and d1X_y[x,s,t]);

  pX_m_hat.l[x,s,t]$(tData[t] and d1X_m[x,s,t]) = pX_m.l[x,s,t]$(tData[t] and d1X_m[x,s,t]);
  
  # In lack of better we set the export conpetitive price equal to the import price
  pXF.l[s,t]$(tData[t])  = pM.l[s,t];           
  pXF.l[s,t]$(qX_y.l['xOth',s,t] and pM.l[s,t]=0) = 1; #Hvis der ikke er 

  eXF_ene.l[energy19] = 5;
    
  # Energy
  qXE.l[purpose,energy19,t] = EN_qXE[purpose,energy19,t];

  pXF_ene.l[energy19,t]$sum(s, IO_qM_CET[energy19,s,t]) = (sum(s, IO_vM_CET[energy19,s,t])/correction_factor_values)/(sum(s, IO_qM_CET[energy19,s,t])/correction_factor_joule);
  pXF_ene.l['Natural gas incl. biongas',t] = EN_pE_y['Natural gas incl. biongas','35002',t];
  pXF_ene.l['electricity',t] = EN_pE_m['el from y and m',t];

  # There is only EAFG on exports
  pXE.l[purpose,energy19,t]$(EN_qXE[purpose,energy19,t]) = EN_pXE[purpose,energy19,t];
 

  qXE_ElNl.l[t] = ANV_qXE_elNL.l[t]/correction_factor_joule; #�rsted
  pXE_ElNl.l[t]$ANV_qXE_elNL.l[t] = (ANV_vnXE_elNl.l[t]/correction_factor_values)/(ANV_qXE_elNL.l[t]/correction_factor_joule); pXE_ElNl.l[t]$(not pXE_ElNl.l[t]) = 1; # We need to initialize a 1 in 2014 to create chain-indices properly


  ZE.l[tData] = 1;  
  parameter min_cell_size;
  min_cell_size = 0.0001;
  d1x_y[x,s,t]              = yes$(abs(qX_y.l[x,s,t]) > min_cell_size);
  d1x_m[x,s,t]              = yes$(abs(qX_m.l[x,s,t]) > min_cell_size);

  d1vXE[purpose,energy19,t] = yes$(EN_vnXE[purpose,energy19,t]);
  d1qXE[purpose,energy19,t] = yes$(EN_qXE[purpose,energy19,t]);

  # Mapping of exports to sector
  d1Xe_y[energy19,s,t]      = yes$(EN_pE_y[energy19,s,t] and EN_pXE['unspecified',energy19,t]);

  # Dummy for exports, when there is exports from the sector
  d1X_s[s,t]                = yes$(d1x_y['xOth',s,t] or sum(energy19, d1xe_y[energy19,s,t]));

  # Dummy for using estimated export elasticities when these are available
  d1eXF_s[s]                = yes$(eXF_s[s]);

  # Assign estimated export elasticities to the export elasticity variable
  eXF.l[x,s]$(d1eXF_s[s])   = eXF_s[s];

  $IF1 %FontagneGSR%==1:
   eXF.l[x,'01011'] = 5.359213;
   eXF.l[x,'01012'] = 5.359213;
   eXF.l[x,'01020'] = 7.500788;
   eXF.l[x,'01031'] = 8.105944;
   eXF.l[x,'01032'] = 8.105944;
   eXF.l[x,'01051'] = 1.25*5.131942;
   eXF.l[x,'01052'] = 1.25*5.131942;
   eXF.l[x,'01061'] = 7.733487;
   eXF.l[x,'01062'] = 7.733487;
   eXF.l[x,'10030'] = 5.455778;
   eXF.l[x,'10040'] = 6.672308;
   eXF.l[x,'10120'] = 6.931403;
   eXF.l[x,'10011'] = 5.691357;
   eXF.l[x,'10012'] = 12.09835;
   eXF.l[x,'10013'] = 5.839405;
  
    ## Change of elasticities to rule-of-half
   
    # Exports
   eX_tur.l         = 2.5;
  
   # Investments
   eI.L(i)          = 0;
   eI_s.L(i,s)      = 0.5 * eXF_s[s];

   ei_s.L(i,'01011')  = 0.5*eXF.l('xOth','01011');
   ei_s.L(i,'01012')  = 0.5*eXF.l('xOth','01012');
   ei_s.L(i,'01020')  = 0.5*eXF.l('xOth','01020');
   ei_s.L(i,'01031')  = 0.5*eXF.l('xOth','01031');
   ei_s.L(i,'01032')  = 0.5*eXF.l('xOth','01032');
   ei_s.L(i,'01051')  = 0.5*eXF.l('xOth','01051');
   ei_s.L(i,'01052')  = 0.5*eXF.l('xOth','01052');
   ei_s.L(i,'01061')  = 0.5*eXF.l('xOth','01061');
   ei_s.L(i,'01062')  = 0.5*eXF.l('xOth','01062');
   ei_s.L(i,'10030')  = 0.5*eXF.l('xOth','10030');
   ei_s.L(i,'10040')  = 0.5*eXF.l('xOth','10040');
   ei_s.L(i,'10120')  = 0.5*eXF.l('xOth','10120');
   ei_s.L(i,'10011')  = 0.5*eXF.l('xOth','10011');
   ei_s.L(i,'10012')  = 0.5*eXF.l('xOth','10012');
   ei_s.L(i,'10013')  = 0.5*eXF.l('xOth','10013');
  
   # Materials
   eRxE.L(r)            = 0;
   eRxE_s.L(r,s)        = 0.5 * eXF_s[s];

   eRxE_s.L(r,'01011')  = 0.5*eXF.l('xOth','01011');
   eRxE_s.L(r,'01012')  = 0.5*eXF.l('xOth','01012');
   eRxE_s.L(r,'01020')  = 0.5*eXF.l('xOth','01020');
   eRxE_s.L(r,'01031')  = 0.5*eXF.l('xOth','01031');
   eRxE_s.L(r,'01032')  = 0.5*eXF.l('xOth','01032');
   eRxE_s.L(r,'01051')  = 0.5*eXF.l('xOth','01051');
   eRxE_s.L(r,'01052')  = 0.5*eXF.l('xOth','01052');
   eRxE_s.L(r,'01061')  = 0.5*eXF.l('xOth','01061');
   eRxE_s.L(r,'01062')  = 0.5*eXF.l('xOth','01062');
   eRxE_s.L(r,'10030')  = 0.5*eXF.l('xOth','10030');
   eRxE_s.L(r,'10040')  = 0.5*eXF.l('xOth','10040');
   eRxE_s.L(r,'10120')  = 0.5*eXF.l('xOth','10120');
   eRxE_s.L(r,'10011')  = 0.5*eXF.l('xOth','10011');
   eRxE_s.L(r,'10012')  = 0.5*eXF.l('xOth','10012');
   eRxE_s.L(r,'10013')  = 0.5*eXF.l('xOth','10013');
  
   # Consumers
   eC.L(c)            = 0;
   eC_s.L(c,s)        = 0.5 * eXF_s[s];

   eC_s.L(c,'01011')  = 0.5*eXF.l('xOth','01011');
   eC_s.L(c,'01012')  = 0.5*eXF.l('xOth','01012');
   eC_s.L(c,'01020')  = 0.5*eXF.l('xOth','01020');
   eC_s.L(c,'01031')  = 0.5*eXF.l('xOth','01031');
   eC_s.L(c,'01032')  = 0.5*eXF.l('xOth','01032');
   eC_s.L(c,'01051')  = 0.5*eXF.l('xOth','01051');
   eC_s.L(c,'01052')  = 0.5*eXF.l('xOth','01052');
   eC_s.L(c,'01061')  = 0.5*eXF.l('xOth','01061');
   eC_s.L(c,'01062')  = 0.5*eXF.l('xOth','01062');
   eC_s.L(c,'10030')  = 0.5*eXF.l('xOth','10030');
   eC_s.L(c,'10040')  = 0.5*eXF.l('xOth','10040');
   eC_s.L(c,'10120')  = 0.5*eXF.l('xOth','10120');
   eC_s.L(c,'10011')  = 0.5*eXF.l('xOth','10011');
   eC_s.L(c,'10012')  = 0.5*eXF.l('xOth','10012');
   eC_s.L(c,'10013')  = 0.5*eXF.l('xOth','10013');
  $ENDIF1
$ENDIF


# =====================================================================================================================
# Static calibration
# =====================================================================================================================
$IF %stage% == "static_calibration":
  $GROUP G_exports_static_calibration
    G_exports_endo
    sX_y$(tx0[t] and d1X_y[x,s,t]) , -qX_y
    sX_m$(tx0[t] and d1X_m[x,s,t]), -qX_m
    sXE$(tx0[t] and d1vXE[purpose,energy19,t]), -qXE
    uCturisme$(tx0[t] and d1CTourist[c,t]), -qCtourist
  ;

  $GROUP G_exports_static_calibration_exo
    G_exports_exo
    -sX_y$(d1X_y[x,s,t]), qX_y$(tx0[t] and d1X_y[x,s,t]) 
    -sX_m$(d1X_m[x,s,t]), qX_m$(tx0[t] and d1X_m[x,s,t]) 
    -sXE, qXE$(tx0[t] and d1vXE[purpose,energy19,t]) 
    -uCturisme, qCtourist$(tx0[t] and d1CTourist[c,t]) 
  ;

  $MODEL M_exports_static_calibration
    B_exports
  ;

$ENDIF


# =====================================================================================================================
# Dynamic calibration
# =====================================================================================================================
$IF %stage% == "dynamic_calibration":
  $GROUP G_exports_calib
        G_exports_endo
  ;

  $GROUP G_exports_calib_exo
        G_exports_exo
  ;

  $MODEL M_exports_calib
    B_exports
  ;

$ENDIF