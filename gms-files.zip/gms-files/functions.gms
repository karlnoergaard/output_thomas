# ======================================================================================================================
# Functions
# ======================================================================================================================
# In this file we define functions and macros to be used elsewhere in the model
# Macros are a vanilla GAMS feature
# The FUNCTION command is is a gamY feature. It should be used when the user defined function includes other gamY commands.


# ----------------------------------------------------------------------------------------------------------------------
# Macros related to sets
# ----------------------------------------------------------------------------------------------------------------------
# See the sets files


# ----------------------------------------------------------------------------------------------------------------------
# Adjusting for growth and inflation
# ----------------------------------------------------------------------------------------------------------------------
# Shift variables to adjust for inflation and growth
variable INF_GROWTH_ADJUSTED "Dummy indicating if variables are growth and inflation adjusted";
INF_GROWTH_ADJUSTED.l = 0;

$FUNCTION inf_growth_adjust():
  abort$(INF_GROWTH_ADJUSTED.l) "Trying to adjust for inflation and growth, but model is already adjusted.";
  $offlisting
    $LOOP G_prices:
      {name}.l{sets} = {name}.l{sets} * inf_factor[t];
    $ENDLOOP
    $LOOP G_quantities:
      {name}.l{sets} = {name}.l{sets} * growth_factor[t];
    $ENDLOOP
    $LOOP G_values:
      {name}.l{sets} = {name}.l{sets} * inf_growth_factor[t];
    $ENDLOOP
  $onlisting
  INF_GROWTH_ADJUSTED.l = 1;
$ENDFUNCTION


# Remove inflation and growth adjustment
$FUNCTION remove_inf_growth_adjustment():
  abort$(not INF_GROWTH_ADJUSTED.l) "Trying to remove inflation and growth adjustment, but model is already nominal.";
  $offlisting
    $LOOP G_prices:
      {name}.l{sets} = {name}.l{sets} / inf_factor[t];
    $ENDLOOP
    $LOOP G_quantities:
      {name}.l{sets} = {name}.l{sets} / growth_factor[t];
    $ENDLOOP
    $LOOP G_values:
      {name}.l{sets} = {name}.l{sets} / inf_growth_factor[t];
    $ENDLOOP
  $onlisting
  INF_GROWTH_ADJUSTED.l = 0;
$ENDFUNCTION

# ----------------------------------------------------------------------------------------------------------------------
# Save and load states
# ----------------------------------------------------------------------------------------------------------------------
# Load levels of group from GDX file 
$FUNCTION load({group}, {gdx}):
  $offlisting
  $GROUP __load_group {group};
  $PGROUP __load_pgroup
    $LOOP __load_group:
      load_{name}{sets} ""
    $ENDLOOP
  ;
  execute_load {gdx} $LOOP __load_group: load_{name}={name}.l $ENDLOOP;
  $LOOP __load_group:
    {name}.l{sets}$({subsets}) = load_{name}{sets};
    {name}.scale{sets}$({subsets} and {name}.l{sets}$({subsets}) <> 0 ) = load_{name}{sets};
  $ENDLOOP
  $onlisting
$ENDFUNCTION

$FUNCTION load_nonzero({group}, {gdx}):
  $offlisting
  $GROUP __load_group {group};
  $PGROUP __load_pgroup
    $LOOP __load_group:
      load_{name}{sets} ""
    $ENDLOOP
  ;
  execute_load {gdx} $LOOP __load_group: load_{name}={name}.l $ENDLOOP;
  $LOOP __load_group:
    {name}.l{sets}$({subsets} and load_{name}{sets} <> 0) = load_{name}{sets};
  $ENDLOOP
  $onlisting
$ENDFUNCTION

# Export all variables to GDX files (with and without adjusment for inflation and growth).
$FUNCTION unload({fname}):
  execute_unloaddi '{fname}' $LOOP All:, {name} $ENDLOOP $LOOP pG_dummies:, {name} $ENDLOOP ADAM, inf_factor, growth_factor, inf_growth_factor, fp, fq, fv, INF_GROWTH_ADJUSTED.l
$ENDFUNCTION

# Export all variables to GDX files (with and without adjusment for inflation and growth).
$FUNCTION unloadREFORM({fname}):
  execute_unloaddi '{fname}' $LOOP AllREFORM:, {name} $ENDLOOP $LOOP pG_dummies:, {name} $ENDLOOP inf_factor, growth_factor, inf_growth_factor, fp, fq, fv, INF_GROWTH_ADJUSTED.l
$ENDFUNCTION


$FUNCTION unload_all_nominal({fname}):
  @remove_inf_growth_adjustment()
  execute_unloaddi '{fname}';
  @inf_growth_adjust()
$ENDFUNCTION

$FUNCTION unload_all({fname}):
  execute_unloaddi '{fname}';
$ENDFUNCTION

# Save the values of a group of variables, by creating parameters with the same names and a suffix added.
$FUNCTION save_as({group}, {suffix}):
  $offlisting
    $LOOP {group}:
      parameter {name}{suffix}{sets};
      {name}{suffix}{sets}${subsets} = {name}.l{sets};
    $ENDLOOP
  $onlisting
$ENDFUNCTION

# Save the values of a group of variables so that they can later be recalled.
$FUNCTION save({group}):
  @save_as({group}, _saved)
$ENDFUNCTION

# Reset the values of a group of variables to the levels saved previously. 
$FUNCTION reset_to({group}, {suffix}):
  $offlisting
    $LOOP {group}:
      {name}.l{sets}${subsets} = {name}{suffix}{sets};
    $ENDLOOP
  $onlisting
$ENDFUNCTION

$FUNCTION reset({group}):
  @reset_to({group}, _saved)
$ENDFUNCTION

# Display the difference between the current values of a group of variables and the previously saved values.
$FUNCTION display_difference({group}):
  $offlisting;
    $LOOP {group}:
      parameter {name}_difference{sets};
      {name}_difference{sets}${subsets} = {name}.l{sets} - {name}_saved{sets};
    $ENDLOOP

  # Differences above E-9:
    $LOOP {group}:
      display$(sum({sets}{$}[+t], abs(round({name}_difference{sets}, 9)))) {name}_difference;
    $ENDLOOP
  $onlisting;
$ENDFUNCTION

# Abort if differences exceed the threshold. Differences are between the current values of a group of variables and the previously saved values.
$FUNCTION assert_no_difference_from({group}, {threshold}, {suffix}, {msg}):
  $offlisting;
    $LOOP {group}:
      parameter {name}_difference{sets};
      {name}_difference{sets}${subsets} = {name}.l{sets} - {name}{suffix}{sets};
      {name}_difference{sets}$(abs({name}_difference{sets}) < {threshold}) = 0;
      if (sum({sets}{$}[+t]${subsets}, abs({name}_difference{sets})),
        display {name}_difference;
      );
    $ENDLOOP
    $LOOP {group}:
      loop({sets}{$}[+t]${subsets},
        abort$({name}_difference{sets} <> 0) '{name}_difference exceeds allowed threshold! {msg}';
      )
    $ENDLOOP
  $onlisting;
$ENDFUNCTION

$FUNCTION assert_no_difference({group}, {threshold}, {msg}):
  @assert_no_difference_from({group}, {threshold}, _saved, {msg})
$ENDFUNCTION


#Assert differences compared to a specified year in variable. If difference exceeds a specified threshold the program will abort
$FUNCTION assert_no_large_relative_difference({group}, {threshold}, {year}):
  $offlisting;
    $LOOP {group}:
      PARAMETER {name}_percentage_diff{sets};  #Computer the percentage difference to previous value
      {name}_percentage_diff{sets}$(t.val > {year} and {name}.l{sets}{$}[<t>'{year}']$({subsets}))   = ({name}.l{sets}$({subsets})/{name}.l{sets}{$}[<t>'{year}']$({subsets})-1) * 100;
      {name}_percentage_diff{sets}$(abs({name}_percentage_diff{sets}) < {threshold}) = 0;
      if (sum({sets}{$}[+t]${subsets}, abs({name}_percentage_diff{sets})) > {threshold},
       display {name}_percentage_diff;
       );
    $ENDLOOP 

    $LOOP {group}:
      loop({sets}{$}[+t]${subsets},
        abort$(abs({name}_percentage_diff{sets}) > {threshold}) '{name}_difference exceeds allowed threshold!'
        );
    $ENDLOOP
  $onlisting;
$ENDFUNCTION

#Load differences from a previous year into saved parameters for a given group
$FUNCTION load_previous_difference({group},{gdx}): #Create group to load previous difference
  $offlisting
  $PGROUP G_load_previous_differences
    $LOOP {group}:
      {name}_previous_difference{sets} ""
    $ENDLOOP
  ;

  $PGROUP G_current_difference #Create group to create current difference
    $LOOP {group}:
      {name}_difference{sets} ""
    $ENDLOOP 
  ;

  #Load previous data from GDX
  execute_load {gdx} $LOOP {group}: {name}_previous_difference = {name}_difference $ENDLOOP;

  $LOOP {group}: {name}_saved{sets} = {name}_saved{sets} + {name}_previous_difference{sets}; $ENDLOOP #Correct saved values from their previous difference
  $onlisting
$ENDFUNCTION

#Check BoP
$FUNCTION check_vBoP()
  $onMultiR
  PARAMETER vBop_save[t];
  $offMulti
  $IF %shockmodel%==0: execute_loaddc "%pathvbop%" vBoP_save = vBoP.l; $ENDIF 
  $IF %shockmodel%==1: execute_loaddc "..\%pathvbop%" vBoP_save = vBoP.l; $ENDIF
    
  LOOP(t$(tx1[t]),
    tjek = abs(vBoP.l[t]-vBoP_save[t]);
    display$(tjek >0.5) vBoP.l, vBoP_save;
    ABORT$(tjek >0.5) 'vBoP has changed more than 0.5 mia. from previous modelversion. Consider if your changes to the model are properly accounted for in the income circuit'
  );
$ENDFUNCTION


#Reset saved to be excluding correction for previous differences
$FUNCTION reset_saved_to_input_data({group}):
  $LOOP {group}:
    {name}_saved{sets} = {name}_saved{sets} - {name}_previous_difference{sets};
  $ENDLOOP
$ENDFUNCTION

$FUNCTION unload_differences({group},{gdx}):
    $PGROUP G_current_difference #Create group to create current difference
    $LOOP {group}:
      {name}_difference{sets} ""
    $ENDLOOP 
  ;

  #Create differences
  $LOOP {group}: {name}_difference{sets} = {name}.l{sets} - {name}_saved{sets}; $ENDLOOP

  #Unload to path 
  execute_unload {gdx} $LOOP {group}: ,{name}_difference $ENDLOOP;
$ENDFUNCTION


# ----------------------------------------------------------------------------------------------------------------------
# Math
# ----------------------------------------------------------------------------------------------------------------------
# Example: mean(t, a[t]) -> sum(t, a[t]) / sum(t, 1)
$FUNCTION mean({dim}, {expression}): sum({dim}, {expression}) / sum({dim}, 1) $ENDFUNCTION

# Smooth approximation of ABS function. The error is zero when {x} is zero and goes to -smooth_abs_delta as abs({x}) increases.
scalar smooth_abs_delta /0.01/;
$FUNCTION abs({x}): (sqrt(sqr({x}) + sqr(smooth_abs_delta)) - smooth_abs_delta)$ENDFUNCTION

# Smooth approximation of MAX function. The error is smooth_max_delta/2 when {x}=={y} and goes to zero as {x} and {y} diverge.
scalar smooth_max_delta /0.001/;
$FUNCTION max({x}, {y}): (({x} + {y} + Sqrt(Sqr({x} - {y}) + Sqr(smooth_max_delta))) / 2)$ENDFUNCTION

# Smooth approximation of MIN function. The error is -smooth_min_delta/2 when {x}=={y} and goes to zero as {x} and {y} diverge.
scalar smooth_min_delta /0.001/;
$FUNCTION min({x}, {y}): (({x} + {y} - Sqrt(Sqr({x} - {y}) + Sqr(smooth_min_delta))) / 2)$ENDFUNCTION

# Smooth approximation of min-max function
$FUNCTION InInterval({x},{y},{z}): (({x} + (({z} + {y} - Sqrt(Sqr({z} - {y}) + Sqr(smooth_min_delta))) / 2) + Sqrt(Sqr({x} - (({z} + {y} - Sqrt(Sqr({z} - {y}) + Sqr(smooth_min_delta))) / 2)) + Sqr(smooth_max_delta))) / 2) $ENDFUNCTION


# ----------------------------------------------------------------------------------------------------------------------
# Solving
# ----------------------------------------------------------------------------------------------------------------------
# Solve {model} as CNS with a number of solver options set
$FUNCTION solve({model},{dontbreakoffsolver}):
  {model}.optfile = 1;
  {model}.holdFixed = 1;
  {model}.workfactor = 2;
  #  {model}.workspace = 8000;
  #  {model}.tolinfeas = 1e-12;

  option threads = 16;

  solve {model} using CNS;
  $IF '{dontbreakoffsolver}'!='1':
    if(({model}.modelstat<>1 and {model}.modelstat<>15 and {model}.modelstat<>16),
    abort "Error when solving {model}";);
  $ENDIF

$ENDFUNCTION
# Set bounds on three groups, G_lower_bound, G_zero_bound, and G_lower_upper_bound
$FUNCTION set_bounds():
  @bound(G_lower_bound, 0.001, inf);
  @bound(G_zero_bound, 0.00001, inf);
  @bound(G_lower_upper_bound, 0.01, 20);
$ENDFUNCTION

# Set bounds on {group} to {lo}, {up}
$FUNCTION bound({group}, {lo}, {up}):
  $LOOP {group}:
    loop({sets}, if({conditions} and {name}.up{sets} <> {name}.l{sets},
      {name}.lo{sets} = {lo};
      {name}.up{sets} = {up};
    ););
  $ENDLOOP
$ENDFUNCTION

$FUNCTION NLP_solve({model}, {group}, {GDX}):
  @save({group})
  @load({group}, {GDX});
  @save_as({group}, _target)
  @reset({group})
  $GROUP G_endo G_endo, objective "dummy objective";
  $BLOCK B_{model}_{group}
    E_objective_{model}_{group}..
      objective =E= 0 
      $LOOP {group}:
        + sum({sets}${conditions}, sqr({name}{sets} - {name}_target{sets}))
      $ENDLOOP
    ;
  $ENDBLOCK
  $MODEL {model}_{group} {model}, E_objective_{model}_{group};
  $UNFIX {group};
  {model}_{group}.optfile = 1;
  {model}_{group}.holdFixed = 1;
  {model}_{group}.workfactor = 3;
  {model}_{group}.scaleopt = 1;
  solve {model}_{group} using NLP minimizing objective;
$ENDFUNCTION

$FUNCTION zero_bound({group}):
$LOOP {group}:
{name}.lo{sets}$({conditions} and {name}.up{sets} <> {name}.lo{sets}) = 0;
$ENDLOOP
$ENDFUNCTION

$FUNCTION pos({x}):
sqrt(sqr({x}))
$ENDFUNCTION


# ----------------------------------------------------------------------------------------------------------------------
# Other
# ----------------------------------------------------------------------------------------------------------------------

FILE logfile /''/;
$FUNCTION print({msg}):
  PUT logfile;
  PUT_UTILITY "log" / {msg};
$ENDFUNCTION

$FUNCTION copy_equation_to_period({equation},{time}):
  $LOOP00 {equation}:
    $REGEX("tx[01]?E?\[t\]","{time}[t]") {name}_{time}{sets}${subsets}.. {LHS} =E= {RHS}; $ENDREGEX
  $ENDLOOP00
$ENDFUNCTION


# ----------------------------------------------------------------------------------------------------------------------
# Local linear Regression functions
# ----------------------------------------------------------------------------------------------------------------------
# Smooth {var} using local linear regression with bandwidth {h}
$FUNCTION LLreg({var}, {h}, {dim}):
  parameters
    LLregBandwith "Bandwidth for Local linear smoothing"
    LLregStore_{var}[*,t] "Container for Local linear smoothing"
    start_year
    end_year
  ;
  LLregBandwith = {h};
  start_year = %cal_start%;
  end_year = %cal_end%;

  execute_unloaddi 'Output\LLreg_pre.gdx' {var}=y, LLregBandwith=h, {dim}=dim, start_year, end_year;
  execute "%R% --slave --vanilla --file=LLreg.R";  
  execute_load 'Saved\LLreg_post.gdx', LLregStore_{var}=gdx_variable;
$ENDFUNCTION


# ----------------------------------------------------------------------------------------------------------------------
# Creation of set complements for use in mappings
# ----------------------------------------------------------------------------------------------------------------------

#Function to create set-complement. Set complements created as "set_complement = not set" cannot be used in mappings. This is circumvented by using the Python function below
$FUNCTION define_set_complement({name_set_c},{set},{set_c},{isitalist}):   
  #Set compliment is defined on mother-set
  set {name_set_c}({set});

   $onMultiR    
      PARAMETER parm_error/0/;
      $onEmbeddedCode Python:

      #If set {set_c} is just a list of set-elements then we define the set-compliment with this code
      if {isitalist}=='yes':
        #Python is case-sensitive and this can cause problems. For this reason a check is run to make sure that {set_c} is contained in {set}
        import sys 
        if set({set_c}).issubset(set(gams.get("{set}")))==False:
          gams.set("parm_error",[1])
        else:
          gams.set("parm_error",[0])

        gams.set("{name_set_c}", list(set(gams.get("{set}")) - set({set_c})))
      
      #If set {set_c} is already a model set we use this to extract the compliment
      if {isitalist}=='no':
        gams.set("{name_set_c}", list(set(gams.get("{set}")) - set(gams.get("{set_c}"))))
        gams.set("parm_error",[0]) #Set to indicicate no error       

      $offEmbeddedCode {name_set_c} parm_error
    $OffMulti

    #Hvis fejl
    ABORT$(parm_error=1) parm_error, "Set-compliment not in set. Make sure that set elements are written as defined with upper/lower-case letters. This error is due to Python case-sensitivity"
$ENDFUNCTION


$FUNCTION set_adjustmentparms({Group_name_zero},{Group_name_one}):
  #Name_zero are adjustment parameters with baseline value of zero 
  $LOOP {Group_name_zero}: {name}.l{sets} = 0; $ENDLOOP 
  $LOOP {Group_name_one}:  {name}.l{sets} = 1; $ENDLOOP 
$ENDFUNCTION 

# ----------------------------------------------------------------------------------------------------------------------
# Deflation
# ----------------------------------------------------------------------------------------------------------------------

$FUNCTION convert_value_to_realprices({group},{year},{deflator}):

  $GROUP G_newvars 
    {group}
  ;

  $OnMultiR
  $GROUP G_newvars_real
   $LOOP G_newvars:
    {name}_real{sets}
   $ENDLOOP
  ;
  $OffMulti

 $IF '{deflator}'=='PC':
  $LOOP G_newvars:
  {name}_real.l{sets}$(tx0[t]) = {name}.l{sets}/inf_growth_factor[t] * (pC.l['cTot','{year}']/inf_factor['{year}'])/ (pC.l['cTot',t]/inf_factor[t]);
  $ENDLOOP
 $ENDIF
$ENDFUNCTION

# ----------------------------------------------------------------------------------------------------------------------
# Set dummies in forecast years
# ----------------------------------------------------------------------------------------------------------------------

$FUNCTION set_dummies(&year,&subset):
# Set dummy values to those of a specific year. 
# THIS SHOULD ONLY BE USED ON A SUBSET WHERE NO DATA EXISTS. 
    $LOOP pG_dummies_Flat:
        {name}{sets}{$}[<t>&subset]$({subsets}) = {name}{sets}{$}[<t>&year];
    $ENDLOOP
$ENDFUNCTION

# ======================f================================================================================================
# Set up function to assert modularity
# ======================================================================================================================

	$FUNCTION assert_modularity({group_exo},{group_endo},{model},{testoverexo}):

	
	  $SETGLOBAL tolerance_overexogenization 10
		#We use these dummy-equations to set up an DNLP for test of over-exogenization
    $OnMultiR
		variables xobj;
		$BLOCK B_obj
		EQ_obj.. xobj =e= 0 ;
		$ENDBLOCK
    $OffMulti
    
		$GROUP G_donotchecktheseforoverexogenization
			#Exogenous variables without dimensions. Makes test break down so they are removed
      eCE 
      eX_tur
      eHt
      uIDbeta
      uCCSbeta
      eC_R
      pDeath
      JvWealth_LongTerm
      JvWealth_MediumTerm
      JvWealth_MediumLongTerm
		;


		$FIX {group_exo};
		$UNFIX {group_endo};
		@SOLVE({model});
		$UNFIX {group_exo};
	 
			#If test of over-exogenization is turned on
			$IF ({testoverexo}=='testoverexo'):
					$OnMultiR
					$MODEL {model}_test_overexo
						{model}
						B_obj
					;
					#Set save-point option 
					{model}_test_overexo.savePoint = 1;
					$OffMulti

				#Save variable values so as to reset them after test for over-exogenization
				# @Save({group_endo}); 
				# @Save({group_exo});

				#Solve model with save-point. The savepoint-gdx now contains all variables that enter model equations
				# execute_unload '{model}_test_overexo_p.gdx' obj.l;
				Solve {model}_test_overexo using DNLP maximizing xobj;

        #Remove all values in exo-group
        $LOOP {group_exo}:
        option clear={name}; 
        $ENDLOOP

			 # We load the save-point gdx file, which contains all variables that enter model equations
				execute_loadpoint '{model}_test_overexo_p.gdx';


				#We now create parameters based on the exo-group with suffix "true_exo"
				$LOOP {group_exo}:
						parameter {name}_true_exo{sets};
				$ENDLOOP


				#We transfer all variable marginals (marginals for zero-entries) or levels into the "true_exo"-parameters
				$LOOP {group_exo}:
						{name}_true_exo{sets}$({subsets}) = {name}.m{sets} or {name}.l{sets};
				$ENDLOOP

				#We now reset variable values (the exo-group namely is important for this check, the endo-group is reset as well for the sake of running the rest of this file)
				$LOOP {group_endo}: {name}.l{sets} = {name}_saved{sets}; $ENDLOOP 
				$LOOP {group_exo}: {name}.l{sets} = {name}_saved{sets};  $ENDLOOP
				#  @reset({group_endo}); $FIX {group_endo};
				#  @reset({group_exo});  $FIX {group_exo};
			
				$GROUP G_{group_exo}_loop
					{group_exo}
					-G_donotchecktheseforoverexogenization
				;

				#We now check which variables are in the exo-group but are not truly exogenous in the model equations
					$LOOP G_{group_exo}_loop:
						$OnMultiR
						parameter {name}_check_exo{sets}, count_overexo_elements;
						$OffMulti
						count_overexo_elements = no; #Resetting counter

						#Inserting all elements in exo-group that are not not truly exogenous.
						{name}_check_exo{sets}$({subsets} and not {name}_true_exo{sets}) = {name}.l{sets};
						display {name}_check_exo; #Displaying over-exogenized elements

						#Counting number of over-exogenized elements
						count_overexo_elements = sum({sets}$({name}_check_exo{sets}), 1${name}_check_exo{sets});
						display count_overexo_elements; #Displaying counter

						if (count_overexo_elements>%tolerance_overexogenization%,
						    loop({sets}${subsets},
			       			abort$({subsets} and not {name}_true_exo{sets}) '{name} is over-exogenized in {group_exo} in {model}';
			     			));
				    $ENDLOOP

				execute 'rm -f {model}_test_overexo_p.gdx';
			$ENDIF
	$ENDFUNCTION 

# ----------------------------------------------------------------------------------------------------------------------
# Smoothing
# ----------------------------------------------------------------------------------------------------------------------

#Smooth straight line that bends off at 0 and 1. 
$FUNCTION smooth_linear01({inp},{slope}): [1+sqrt( sqr({inp}) + sqr({slope})) - sqrt((sqr({inp}-1) + sqr({slope})))]/2 $ENDFUNCTION

# Sluggish adoption of technologies
#  x: rCCS_preferred[techCCS,s,purpose,energy19,t]
#  y: rCCS_actual[techCCS,purpose,energy19,s,t-1,emm]
#  z: rCCS_max_sh[techCCS]
#  e: epsilon_CCS
$FUNCTION slugger({x},{y},{z},{e}): ({y} + ({x}-{y}+{z}-Sqrt(Sqr({x}-{y}-{z})+{e}))/2 - ({z}-Sqrt(Sqr(-{z})+{e}))/2) $ENDFUNCTION

# ----------------------------------------------------------------------------------------------------------------------
# Distribution normale
# ----------------------------------------------------------------------------------------------------------------------

#Cumulative normal
$FUNCTION cdfNorm({x},{mu},{std}): errorf(({x}-{mu})/({std})) $ENDFUNCTION

#Cumulative standard normal (we don't use it for the time being in this module)
$FUNCTION cdfStdNorm({x}): errorf({x}) $ENDFUNCTION 

#The density of the normal distribution
$FUNCTION pdfNorm({x},{mu},{std}): 1/({std} * sqrt(2*pi)) * exp(-1/2*sqr(({x}-{mu})/({std}))) $ENDFUNCTION

# ----------------------------------------------------------------------------------------------------------------------
# Distribution log-normale
# ----------------------------------------------------------------------------------------------------------------------

#Cumulative distribution of a log-normal distribution with expected value mu and standard deviation std 
$FUNCTION cdfLogNorm({x},{mu},{std}): errorf((log( ( ({x}/{mu})**2 )**0.5) + 0.5*{std}**2 )/{std}) $ENDFUNCTION                                                            

#Integral of cumulative distribution of a log-normal distribution with expected value mu and standard deviation std 
$FUNCTION Int_cdfLogNorm({x},{mu},{std}): errorf((log( ( ({x}/{mu})**2 )**0.5) - 0.5*{std}**2 )/{std}) $ENDFUNCTION 