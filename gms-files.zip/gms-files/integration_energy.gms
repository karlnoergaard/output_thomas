
#====================================================================================================================================================================================================================#
# 1) Read'n run energy model
#====================================================================================================================================================================================================================#

#Set input-gdx
$SETGLOBAL Baseline_AllT "EnergyModule\energy.gdx";

#Import model
$IMPORT EnergyModule\energy.gms;

#Load variables 
@load(G_energy_endo,"EnergyModule\energy.gdx");
@load(G_energy_exo,"EnergyModule\energy.gdx");

$GROUP G_energy_endoexo G_energy_endo, G_energy_exo,-VOMCGE;
@Save_as(G_energy_endoexo,_energy_endoexo);

#Run zero-shock
$UNFIX G_energy_endo; $FIX G_energy_exo;
#  @Solve(M_energy);
@assert_no_difference_from(G_energy_endoexo,1e-6,_energy_endoexo); #Interrupts if not a zero-shock (i.e variables have moved from their saved values)

#====================================================================================================================================================================================================================#
# 2) Create sets, mappings, dummies and variables for integration 
#====================================================================================================================================================================================================================#

#SETS
set EH2EH(e_eh_sectors,eh_sectors)/
	waste  . 38393 
	nwaste . 35011
	/
;

#Flyt de her
set EH_sectors_sp[sp]/set.EH_sectors/;
set purpose_xth[purpose]/process_normal,process_special,in_ETS/;
set ElHeat(energy19)/'Electricity','District heat'/;


#Time-periods
singleton set t_BU_start[t]/2019/; #First year of energy-model
singleton set t_BU_end[t]/2040/;   #Last year of energy-model
set t_BU_xStart[t]; t_BU_xStart[t] = yes$(t_BU[t] and t.val > t_BU_Start.val and t.val > t1.val and tx0[t]); #All energy-model periods, except from start. Furthermore this dummy is used to only work on time-sets after tStart in the CGE-model. That is to ensure that the integrated model can be used for a shock starting later than when the energy-model starts. 

#Mappings
set AggFT2Energy19(AggFT,energy19) "Mapping of aggregate energy-goods from the energy-model to corresponding energy-goods in CGE-model"/
	AggCoal   . 'Coal and coke'
	AggOil    .  'Diesel for transport'  #('Oil products')
	AggNatGas . 'Natural gas incl. biongas'
	AggStraw  . 'Straw for energy purposes'
	AggWood   . ('Wood pellets','Firewood and woodchips') #,'Wood waste'
	AggWaste  . 'Waste'
	AggBiogas . 'Biogas'
	AggBioOil . 'Biodiesel, bioethanol og bioolie'
	/;

set BFt2Energy19(BFt,energy19) "Mapping of energy-goods for prices. This mapping is used to feed prices from CGE-model to energy-model"/
	Waste       . Waste 
	BioOil      . 'Biodiesel, bioethanol og bioolie'
	Biogas      . Biogas 
	Coal        . 'Coal and coke'
	Fueloil     . 'Oil products'
	GasOil      . 'Diesel for transport' #Gasfyringsolie er lagt i diesel for transport*
	NatGas      . 'Natural gas incl. biongas'
	Straw       . 'Straw for energy purposes'
	WoodChips   . 'Firewood and woodchips'
	WoodPellets . 'Wood pellets'
	/;

set BFt2Energy19Calib(BFt,energy19) "Mapping of energy-goods for prices. This mapping is used to calibrate CGE-model energy-prices to those price-paths the energy-model uses"/
	Waste       . Waste 
	BioOil      . 'Biodiesel, bioethanol og bioolie'
	Biogas      . Biogas 
	Coal        . 'Coal and coke'
	Fueloil     . ('Oil products','LVN','Semi-refined oil','Jet petroleum','Bunkering of Danish operated vessels on foreign territory','Bunkering of Danish operated planes on foreign territory') #,'Crude oil'
	GasOil      . ('Diesel for transport','Gasoline for transport','Bunkering of Danish operated trucks on foreign territory') #Gasfyringsolie er lagt i diesel for transport*
	NatGas      . ('Natural gas incl. biongas','Natural gas (Extraction)')
	Straw       . 'Straw for energy purposes'
	WoodChips   . 'Firewood and woodchips'
	WoodPellets . 'Wood pellets'
	/;


#We create a few dummies necessary for integration
PARAMETER d1fueloverlap[purpose,energy19,s,t], d1fueloverlap_e19[out,t], d1fuelpriceoverlap[BFt,t], d1fuelpriceoverlape19[out,t], d1LargeEntries[purpose,energy19,s,t];

#This dummy dummies energy-goods where there is an overlap between energy-goods used in el/heat-production in the CGE-model and the energy-goods used in the energy-model
d1fueloverlap[purpose,energy19,EH_sectors,t] =  yes$(d1tRE[purpose,energy19,EH_sectors,t] and sum((e_EH_sectors,AggFt)$(AggFT2Energy19(AggFT,energy19) and EH2EH(e_eh_sectors,eh_sectors)), qFuel.l[t,e_EH_sectors,AggFt]));
d1fueloverlap[purpose,energy19,EH_sectors,t]$(t.val > t_BU_end.val) = d1fueloverlap[purpose,energy19,EH_sectors,t_BU_end]; #The dummy is extended beyond last energy-model year.

#The fueloverlap dummy is modified to work on the energy-goods encompassed. This is to balance supply/demand in the energy-accounts that is used in the calibration
d1fueloverlap_e19[energy19,t] = yes$(sum((purpose,EH_sectors), d1fueloverlap[purpose,energy19,EH_sectors,t]));

#A fueloverlap dummy is created to work on the fuel-set of the energy-model
d1fuelpriceoverlap[BFt,t] = yes$(fp_t.l[t,BFt] and sum(energy19$(BFt2Energy19(BFt,energy19)), d1pEtot[energy19,t])); 

#Fuel-price overlap dummy
d1fuelpriceoverlape19[energy19,t] = yes$(d1pEtot[energy19,t] and sum(BFt$(BFt2Energy19Calib(BFt,energy19)), fp_t.l[t,BFt]));
#We also extend this dummy after energy-model end year (2040) for the sake of creating initial values for the solver
d1fuelpriceoverlape19[energy19,t]$(t.val > t_BU_end.val) = d1fuelpriceoverlape19[energy19,t_BU_end];


#The CGE-model is at this stage calibrated to KF21 and hence electricity and heat consumption should be very close to what is in the baseline of the energy-model. To ensure that the energy-model does not move after the integration in baseline electricity and district heat demand needs to be adjusted a bit.
#We only adjust in places where the el/heat demand is larger than 0.5 PJ. This is to facilitate an easier calibration, as corners of the model hides very small uses of el/heat.
d1LargeEntries[purpose,energy19,s,t] = yes$(qREgj.l[purpose,energy19,s,t] > 0.5 and (sameas[energy19,'Electricity'] or sameas[energy19,'District heat']));
d1LargeEntries[purpose,energy19,s,t]$(t.val > t_BU_end.val) = d1LargeEntries[purpose,energy19,s,t_BU_end];
d1LargeEntries[purpose,energy19,s,t]$(qREgj.l[purpose,energy19,'35002',t]) = yes; #Hcak to help`?

#Another adjustment parameter enters the game...
PARAMETER chi; chi = 0.01;

#NEW VARIABLES 
$GROUP G_CGE_ENERGY_LINK 
	fDK1[t]$(t_BU[t])    "Kalibreringsparameter, der afgør hvor stor en del af væksten i den samlede el-efterspørgsel, der slår igennem på elområde 1 "
	fDK2[t]$(t_BU[t])    "Kalibreringsparameter, der afgør hvor stor en del af væksten i den samlede el-efterspørgsel, der slår igennem på elområde 2 "
	fHA_DK1[t]$(t_BU[t]) "Kalibreringsparameter, der afgør hvor stor en del af væksten i den samlede varme-efterspørgsel, der slår igennem på varmeområde 1 "
	fHA_DK2[t]$(t_BU[t]) "Kalibreringsparameter, der afgør hvor stor en del af væksten i den samlede varme-efterspørgsel, der slår igennem på varmeområde 2 "

	pE_consumption_CGE[t] "Average base price of electricity for domestic consumption"
	pH_consumption_CGE[t] "Average base price of heat for domestic consumption"
	qE_consumption_CGE[t] "Domestic demand for electricity"
	qH_consumption_CGE[t] "Domestic demand for district heat"

	adj_pE_consumption_CGE[t] "adjustment parameter that ensures that distributor's markup is adjusted to match domestic prices in energy-model"
	adj_pH_consumption_CGE[t] "adjustment parameter that ensures that distributor's markup is adjusted to match domestic prices in energy-model"

	adj_eD_CGE[t] "adjustment parameter for domestic eletricity demand"
	adj_hD_CGE[t] "adjustment parameter for domestic district heat demand"

	adj_EH[t] "adjustment parameter to hit demand for electricity for heat-pumps"

	adj_fuel_RE[purpose,energy19,EH_sectors,e_EH_sectors,AggFT,t] "Adjustment parameter that controls CES-shares in production function to match fuel-use in energy-model"
	adj_fuelprice_calib[t,BFt,energy19] "Adjustment pamareter used in calibration of fuel prices to price-paths from energy-model"
	adjEbalance[energy19,t] "Adjustment parameter used in calibration to ensure supply/demand balances for energy-goods"
;

#This group has to be zero in baseline for the model to be be able to produce a zero-shock
$GROUP G_CGE_ENERGY_LINK_ZERO_IN_BASE 
	adj_pE_consumption_CGE
	adj_pH_consumption_CGE
;

#This group has to be one in baseline for the model to be be able to produce a zero-shock
$GROUP G_CGE_ENERGY_LINK_ONE_IN_BASE 
	adj_EH
	adj_fuel_RE
;

#Exogenous variables from the linking equations in the final linked model
$GROUP G_CGE_ENERGY_LINK_EXO 
	fDK1[t]$(t_BU[t]) 
	fDK2[t]$(t_BU[t]) 
	fHA_DK1[t]$(t_BU[t]) 
	fHA_DK2[t]$(t_BU[t]) 
	pE_consumption_CGE$(t0[t]) 
	pH_consumption_CGE$(t0[t]) 
	qE_consumption_CGE$(t0[t]) 
	qH_consumption_CGE$(t0[t]) 

	jDistrictHeat[t] "J-term to capture that Energy-module is still KF21 data - should be removed when we get KF22 energymodule. The district heat development differs massively between the two"
	j_fp_t[t,BFt]
;

#Endogenous variables used in linking equations for the final linked model
$GROUP G_CGE_ENERGY_LINK_ENDO 
	pE_consumption_CGE$(t_BU[t] and not t0[t]) 
	pH_consumption_CGE$(t_BU[t] and not t0[t]) 
	qE_consumption_CGE$(t_BU[t] and not t0[t]) 
	qH_consumption_CGE$(t_BU[t] and not t0[t]) 

	#Domestic demand to energy-model
    eD_t$(t_BU_xStart[t] and (sameas[EA,'DK1'] or sameas[EA,'DK2']))  #E_demand_DK1, E_demand_DK2
    hD_t$(t_BU_xStart[t] and (sameas[HA,'HA_DK1'] or sameas[HA,'HA_DK2'])) #E_hdemand_HA_DK1, E_hdemand_HA_DK2

	#Domestic prices 
	adj_pE_consumption_CGE$(t_BU_xStart[t])
	adj_pH_consumption_CGE$(t_BU_xStart[t])

	fpRE$(t.val > t_BU_start.val and d1vRE[purpose,energy19,r,t] and sameas[energy19,'electricity'] and not (sameas[purpose,'process_special'] and sameas[r,'35011']))   #E_fpRE_e, E_fpRE_e_forecast
	fpCE$(t.val > t_BU_start.val and d1vCE[purpose,energy19,t] and sameas[energy19,'electricity'])     #E_fpCE_e, E_fpCE_e_forecast
	fpRE$(t.val > t_BU_start.val and d1vRE[purpose,energy19,r,t] and sameas[energy19,'district heat']) #E_fpRE_h, E_fpRE_h_forecast
 	fpCE$(t.val > t_BU_start.val and d1vCE[purpose,energy19,t] and sameas[energy19,'district heat'])   #E_fpCE_h, E_fpCE_h_forecast

 	#Export-price
	fpXE$(t.val > t_BU_start.val and sameas[energy19,'electricity'] and sameas[purpose,'unspecified']) #E_pXE_LINK, E_fpXE_forecast

	#Import prices and import-quantity
	pM_CET$(t.val > t_BU_start.val and sameas[out,'electricity'] and sameas[s,'19000'])               # E_pM_CET_LINK, E_pM_CET_LINK_forecast
	sM_AGG$(t.val > t_BU_start.val and sameas[energy19,'electricity'] and sameas[s,'19000'])   		  #E_qM_CET_LINK, E_qM_CET_LINK_forecast

	#Production
	sY_AGG$(t.val > t_BU_start.val and sameas[energy19,'electricity'] and sameas[s,'35011']), sXE$(t.val > t_BU_start.val and sameas[purpose,'unspecified'] and sameas[energy19,'electricity'])  #E_qY_CET_LINK_e, E_sY_AGG_e, E_sXE_e 
	sY_AGG$(t.val > t_BU_start.val and sameas[energy19,'district heat'] and  sameas[s,'38393']) #E_qY_CET_LINK_h, E_sY_AGG_h 

	markup$(t.val > t_BU_start.val and d1vY_CET[out,s,t] and EH_sectors[s] and (sameas[out,'electricity'] or sameas[out,'district heat']))

	#Adjustment of CES-shares to match fuel-use in energy-model
	adj_fuel_RE$(t_BU_xStart[t] and d1tRE[purpose,energy19,EH_sectors,t] and qFuel.l[t,e_EH_sectors,AggFt] and AggFT2Energy19(AggFT,energy19))

	uRE$(t.val > t_BU_start.val and d1tRE[purpose,energy19,s,t] and d1fueloverlap[purpose,energy19,s,t] and purpose_xth[purpose])
	#  uEP$(t.val > t_BU_start.val and d1EP[purpose,s,t] and EH_sectors[s] and purpose_xth[purpose])
	#  uE$(t.val > t_BU_start.val and EH_sectors[sp])

	#Electric heaters (Heat pumps)
	uRE$(t.val > t_BU_start.val and d1vRE[purpose,energy19,s,t] and sameas[purpose,'process_special'] and sameas[s,'35011'] and sameas[energy19,'electricity'])
	adj_EH$(t_BU_xStart[t])


	#Fuel prices 
	fp_t$(t_BU_xStart[t] and d1fuelpriceoverlap[BFt,t])
;


#Initial values 
fDK1.l[t]$(t_BU_xStart[t]) = (eD_t.l[t,'DK1']/eD_t.l[t-1,'DK1']) / [(eD_t.l[t,'DK1']+eD_t.l[t,'DK2'])/(eD_t.l[t-1,'DK1']+eD_t.l[t-1,'DK2'])];
fDK2.l[t]$(t_BU_xStart[t]) = (eD_t.l[t,'DK2']/eD_t.l[t-1,'DK2']) / [(eD_t.l[t,'DK1']+eD_t.l[t,'DK2'])/(eD_t.l[t-1,'DK1']+eD_t.l[t-1,'DK2'])];
fHA_DK1.l[t]$(t_BU_xStart[t]) = (hD_t.l[t,'HA_DK1']/hD_t.l[t-1,'HA_DK1']) / [(hD_t.l[t,'HA_DK1']+hD_t.l[t,'HA_DK2'])/(hD_t.l[t-1,'HA_DK1']+hD_t.l[t-1,'HA_DK2'])];
fHA_DK2.l[t]$(t_BU_xStart[t]) = (hD_t.l[t,'HA_DK2']/hD_t.l[t-1,'HA_DK2']) / [(hD_t.l[t,'HA_DK1']+hD_t.l[t,'HA_DK2'])/(hD_t.l[t-1,'HA_DK1']+hD_t.l[t-1,'HA_DK2'])];

qE_consumption_CGE.l[t] = sum(purpose,  sum(s,qREgj.l[purpose,'electricity',s,t]$(d1vRE[purpose,'electricity',s,t])) + qCE.l[purpose,'electricity',t]$(d1vCE[purpose,'electricity',t]) + qTL.l[purpose,'electricity',t]$(d1TL[purpose,'electricity',t]));
qH_consumption_CGE.l[t] = sum(purpose,  sum(s,qREgj.l[purpose,'district heat',s,t]$(d1vRE[purpose,'district heat',s,t])) + qCE.l[purpose,'district heat',t]$(d1vCE[purpose,'district heat',t])+ qTL.l[purpose,'district heat',t]$(d1TL[purpose,'district heat',t]));


jDistrictHeat.fx[t] = qH_consumption_CGE.l[t] - (hD_t.l[t,'HA_DK1'] + hD_t.l[t,'HA_DK2'])*3.6*growth_factor[t];



pE_consumption_CGE.l[t]$(tx0[t]) = sum(purpose, sum(s$(d1vRE[purpose,'electricity',s,t]), pRE_base.l[purpose,'electricity',s,t]  * qREgj.l[purpose,'electricity',s,t])
								                                                    + pCE_base.l[purpose,'electricity',t] * qCE.l[purpose,'electricity',t]$(d1vCE[purpose,'electricity',t]))
								/sum(purpose,  sum(s,qREgj.l[purpose,'electricity',s,t]$(d1vRE[purpose,'electricity',s,t])) + qCE.l[purpose,'electricity',t]$(d1vCE[purpose,'electricity',t]) + qTL.l[purpose,'electricity',t]$(d1TL[purpose,'electricity',t]));

pH_consumption_CGE.l[t]$(tx0[t]) = 	sum(purpose, sum(s$(d1vRE[purpose,'district heat',s,t]), pRE_base.l[purpose,'district heat',s,t] * qREgj.l[purpose,'district heat',s,t])
								                                                    + (pCE_base.l[purpose,'district heat',t] * qCE.l[purpose,'district heat',t])$(d1vCE[purpose,'district heat',t]))
								/sum(purpose,  sum(s,qREgj.l[purpose,'district heat',s,t]$(d1vRE[purpose,'district heat',s,t])) + qCE.l[purpose,'district heat',t]$(d1vCE[purpose,'district heat',t])+ qTL.l[purpose,'electricity',t]$(d1TL[purpose,'district heat',t]));


#  #HACK! Prøver at hjælpe dumme firewood and woodchips
#  LOOP(t$(t_BU_xStart[t]), 
#  		fpCE.fx['heating','firewood and woodchips',t]     = fpCE.l['heating','firewood and woodchips',t-1]    + 0.02;
#  		fpxE.l['unspecified','firewood and woodchips',t]  = fpxE.l['unspecified','firewood and woodchips',t-1] -0.02; 
#  	);



#  fpCE.fx['heating','firewood and woodchips',t]$(t.val >t_BU_end.val)    = fpCE.l['heating','firewood and woodchips',t_BU_end];
#  fpXE.l['unspecified','firewood and woodchips',t]$(t.val >t_BU_end.val) = fpXE.l['unspecified','firewood and woodchips',t_BU_end];




#====================================================================================================================================================================================================================#
# 3) Definition of link-equations in the block 'B_CGE_ENERGY_LINK' 
#====================================================================================================================================================================================================================#

$BLOCK B_CGE_ENERGY_LINK 

	#Domestic electricity demand in energy-model is set to follow demand in CGE-model
	E_demand_DK1[t]$(t_BU_xStart[t])..                eD_t[t,'DK1'] =E= fDK1[t] *  qE_consumption_CGE[t]/(qE_consumption_CGE[t-1]) * fq * eD_t[t-1,'DK1'];	
	E_demand_DK2[t]$(t_BU_xStart[t])..                eD_t[t,'DK2'] =E= fDK2[t] *  qE_consumption_CGE[t]/(qE_consumption_CGE[t-1]) * fq * eD_t[t-1,'DK2'];	

	#Domestic district heat demand in energy-model is set to follow demand in CGE-model
	E_hdemand_HA_DK1[t]$(t_BU_xStart[t])..                hD_t[t,'HA_DK1'] =E= fHA_DK1[t] *  qH_consumption_CGE[t]/qH_consumption_CGE[t-1] * fq * hD_t[t-1,'HA_DK1'];	
	E_hdemand_HA_DK2[t]$(t_BU_xStart[t])..                hD_t[t,'HA_DK2'] =E= fHA_DK2[t] *  qH_consumption_CGE[t]/qH_consumption_CGE[t-1] * fq * hD_t[t-1,'HA_DK2'];	


	#Computation of average domestic base price of electricity 
	E_pE_consumption_CGE[t]$(tx0[t] and t_BU[t])..      pE_consumption_CGE[t] =E=sum(purpose, sum(s$(d1vRE[purpose,'electricity',s,t]), pRE_base[purpose,'electricity',s,t]  * qREgj[purpose,'electricity',s,t])
								                                                    + pCE_base[purpose,'electricity',t] * qCE[purpose,'electricity',t]$(d1vCE[purpose,'electricity',t]))
								/sum(purpose,  sum(s,qREgj[purpose,'electricity',s,t]$(d1vRE[purpose,'electricity',s,t])) + qCE[purpose,'electricity',t]$(d1vCE[purpose,'electricity',t]) + qTL[purpose,'electricity',t]$(d1TL[purpose,'electricity',t]));

	#Computation of average domestic base price of district heat
	E_pH_consumption_CGE[t]$(tx0[t] and t_BU[t])..    pH_consumption_CGE[t] =E= 	sum(purpose, sum(s$(d1vRE[purpose,'district heat',s,t]), pRE_base[purpose,'district heat',s,t] * qREgj[purpose,'district heat',s,t])
								                                                    + (pCE_base[purpose,'district heat',t] * qCE[purpose,'district heat',t])$(d1vCE[purpose,'district heat',t]))
								/sum(purpose,  sum(s,qREgj[purpose,'district heat',s,t]$(d1vRE[purpose,'district heat',s,t])) + qCE[purpose,'district heat',t]$(d1vCE[purpose,'district heat',t])+ qTL[purpose,'electricity',t]$(d1TL[purpose,'district heat',t]));

	#Computation of domestic electricity demand
	E_qE_consumption_CGE[t]$(tx0[t] and t_BU[t])..   
		qE_consumption_CGE[t] =E= sum(purpose,  sum(s,qREgj[purpose,'electricity',s,t]$(d1vRE[purpose,'electricity',s,t])) + qCE[purpose,'electricity',t]$(d1vCE[purpose,'electricity',t]) + qTL[purpose,'electricity',t]$(d1TL[purpose,'electricity',t]));

	#Computation of domestic district heat demand 
	E_qH_consumption_CGE[t]$(tx0[t] and t_BU[t])..  
		qH_consumption_CGE[t] =E= sum(purpose,  sum(s,qREgj[purpose,'district heat',s,t]$(d1vRE[purpose,'district heat',s,t])) + qCE[purpose,'district heat',t]$(d1vCE[purpose,'district heat',t])+ qTL[purpose,'district heat',t]$(d1TL[purpose,'district heat',t]))
								  -jDistrictHeat[t];


	#Domestic electricity and district heat prices are set to follow the prices in the energy-model
	E_pE_consumption_CGE_adjust[t]$(t_BU_xStart[t])..        pE_consumption_CGE[t] =E= (chi * pE_consumption[t]/(pE_consumption[t-1]*fp) + (1-chi) * (pE_consumption_CGE.l[t]/pE_consumption_CGE.l[t-1])) * pE_consumption_CGE[t-1];
	E_pH_consumption_CGE_adjust[t]$(t_BU_xStart[t])..        pH_consumption_CGE[t] =E= (chi * pH_consumption[t]/(pH_consumption[t-1]*fp) + (1-chi) * (pH_consumption_CGE.l[t]/pH_consumption_CGE.l[t-1])) * pH_consumption_CGE[t-1];

	#The adjustment of domestic prices goes through adjustment of the 'energy-distributors' margins.
	E_fpRE_e[purpose,r,t]$(t_BU_xStart[t] and d1vRE[purpose,'electricity',r,t] and not (sameas[purpose,'process_special'] and sameas[r,'35011']))..  fpRE[purpose,'electricity',r,t] =E= adj_pE_consumption_CGE[t] + fpRE.l[purpose,'electricity',r,t];
	E_fpCE_e[purpose,t]$(t_BU_xStart[t] and d1vCE[purpose,'electricity',t]).. fpCE[purpose,'electricity',t] =E= adj_pE_consumption_CGE[t] + fpCE.l[purpose,'electricity',t];
	E_fpRE_h[purpose,r,t]$(t_BU_xStart[t] and d1vRE[purpose,'district heat',r,t])..  fpRE[purpose,'district heat',r,t] =E= adj_pH_consumption_CGE[t] + fpRE.l[purpose,'district heat',r,t];
	E_fpCE_h[purpose,t]$(t_BU_xStart[t] and d1vCE[purpose,'district heat',t]).. fpCE[purpose,'district heat',t] =E= adj_pH_consumption_CGE[t] + fpCE.l[purpose,'district heat',t];

	E_fpRE_e_forecast[purpose,r,t]$(t.val > t_BU_end.val and d1vRE[purpose,'electricity',r,t] and not (sameas[purpose,'process_special'] and sameas[r,'35011'])).. fpRE[purpose,'electricity',r,t] =E= fpRE[purpose,'electricity',r,t_BU_end];
	E_fpCE_e_forecast[purpose,t]$(t.val > t_BU_end.val and d1vCE[purpose,'electricity',t]).. fpCE[purpose,'electricity',t] =E= fpCE[purpose,'electricity',t_BU_end];
	E_fpRE_h_forecast[purpose,r,t]$(t.val > t_BU_end.val and d1vRE[purpose,'district heat',r,t]).. fpRE[purpose,'district heat',r,t] =E= fpRE[purpose,'district heat',r,t_BU_end];
	E_fpCE_h_forecast[purpose,t]$(t.val > t_BU_end.val and d1vCE[purpose,'district heat',t]).. fpCE[purpose,'district heat',t] =E= fpCE[purpose,'district heat',t_BU_end];



	#The base-price of exported electricity is set to follow that of the energy-model
	E_pXE_LINK[t]$(t_BU_xStart[t]).. 
		pXE_base['unspecified','electricity',t] =E= DistMarg_X + lambda * pe_EXPORT[t]/3600 *inf_factor[t] + (1-lambda) * pXE_base.l['unspecified','electricity',t];

	#The adjustment of export price is through distributors margin
	E_fpXE_forecast[t]$(t.val > t_BU_end.val).. fpXE['unspecified','electricity',t] =E= fpXE['unspecified','electricity',t-1]; 

	#Electricity imports of the CGE-model is set to follow the imports of the energy-model 
	E_qM_CET_LINK[t]$(t_BU_xStart[t])..            qM_CET['electricity','19000',t] =E= (chi * qE_import[t]/(qE_import[t-1]*fq) + (1-chi)*(qM_CET.l['electricity','19000',t]/qM_CET.l['electricity','19000',t-1])) * qM_CET['electricity','19000',t-1];
	#The adjustment goes through the distributors portfolio parameter
	E_qM_CET_LINK_forecast[t]$(t.val > t_BU_end.val)..  sM_AGG['electricity','19000',t] =E= sM_AGG['electricity','19000',t_BU_end]; 


	#Import prices are determined by the energy-model. Import-prices in the CGG-model are exogenous 
	E_pM_CET_LINK[t]$(t_BU_xStart[t]).. 
		pM_CET['electricity','19000',t] =E= DistMarg_M + lambda * pE_import[t]/3600*inf_factor[t] + (1-lambda) * pM_CET.l['electricity','19000',t];
	
	E_pM_CET_LINK_forecast[t]$(t.val > t_BU_end.val).. pM_CET['electricity','19000',t] =E= pM_CET['electricity','19000',t_BU_end];


	#PRODUCTION 
	#Production of electricity and district heat is set to follow the production in the energy-model 
	E_qY_CET_LINK_e[EH_sectors,E_EH_sectors,t]$(t_BU_xStart[t] and EH2EH(e_eh_sectors,eh_sectors))..   
		qY_CET['electricity',EH_sectors,t] =E= (chi * qY_E[t,E_EH_sectors]/(qY_E[t-1,E_EH_sectors]*fq) + (1-chi)* qY_CET.l['electricity',EH_sectors,t]/qY_CET.l['electricity',EH_sectors,t-1]) * qY_CET['electricity',EH_sectors,t-1];
	E_qY_CET_LINK_h[EH_sectors,E_EH_sectors,t]$(t_BU_xStart[t] and sameas[EH_sectors,'38393'] and EH2EH(e_eh_sectors,eh_sectors)).. 
		qY_CET['district heat',EH_sectors,t] =E= (chi * qY_H[t,E_EH_sectors]/(qY_H[t-1,E_EH_sectors]*fq) + (1-chi) * qY_CET.l['district heat',EH_sectors,t]/qY_CET.l['district heat',EH_sectors,t-1]) * qY_CET['district heat',EH_sectors,t-1];

	#The adjustment of production in the CGE-model goes through a) the distributors portfolio shares and b) the slack in the energy-balance is adjusted through exports for electricity and through the district heat production in 35011 for district heat
	E_sY_AGG_e[EH_sectors,t]$(t.val > t_BU_end.val and sameas[EH_sectors,'35011']).. sY_AGG['electricity',EH_sectors,t]   =E= sY_AGG['electricity',EH_sectors,t_BU_end];
	E_sXE_e[t]$(t.val > t_BU_end.val)..   sXE['unspecified','electricity',t] =E= sXE['unspecified','electricity',t-1];
	E_sY_AGG_h[EH_sectors,t]$(t.val > t_BU_end.val and sameas[EH_sectors,'38393']).. sY_AGG['district heat',EH_sectors,t] =E= sY_AGG['district heat',EH_sectors,t_BU_end];


	#Producer price of electricity and district heat in the CGE-model is set to follow that of the energy-model. The adjustment goes through the mark-ups.
	E_pY_CET_LINK_e[EH_sectors,E_EH_sectors,t]$(t_BU_xStart[t] and EH2EH[e_eh_sectors,eh_sectors]).. 
		pY_CET['electricity',EH_sectors,t] =E= DistMarg_Y_E[EH_sectors] + lambda * pY_E[t,e_EH_sectors]/3600*inf_factor[t] + (1-lambda) * pY_CET.l['electricity',EH_sectors,t];
	
	E_pY_CET_LINK_h[EH_sectors,E_EH_sectors,t]$(t_BU_xStart[t] and EH2EH[e_eh_sectors,eh_sectors]).. 
		pY_CET['district heat',EH_sectors,t] =E= DistMarg_Y_H[EH_sectors] + lambda * pY_H[t,e_EH_sectors]/3600*inf_factor[t] + (1-lambda) * pY_CET.l['district heat',EH_sectors,t];


	E_markup_LINK_e[EH_sectors,t]$(t.val > t_BU_end.val).. markup['electricity',EH_sectors,t]   =E= markup['electricity',EH_sectors,t_BU_end];
	E_markup_LINK_h[EH_sectors,t]$(t.val > t_BU_end.val).. markup['district heat',EH_sectors,t] =E= markup['district heat',EH_sectors,t_BU_end];



	#Fuel-use in CGE-model is adjusted to the fuel-use in the energy-model through CES-shares in the production function
	E_qRE_adj[purpose,energy19,EH_sectors,e_eH_sectors,AggFt,t]$(t_BU_xStart[t] and d1tRE[purpose,energy19,EH_sectors,t] and qFuel.l[t,e_EH_sectors,AggFt] and AggFT2Energy19(AggFT,energy19) and EH2EH(e_eh_sectors,eh_sectors) and purpose_xth[purpose])..  
		qREgj[purpose,energy19,EH_sectors,t] =E= (chi * qFuel[t,e_EH_sectors,AggFt]/(qFuel[t-1,e_EH_sectors,AggFt]*fq) + (1-chi) * qREgj.l[purpose,energy19,EH_sectors,t]/qREgj.l[purpose,energy19,EH_sectors,t-1]) *qREgj[purpose,energy19,EH_sectors,t-1];

	E_uRE_adj[purpose,energy19,EH_sectors,e_EH_sectors,AggFT,t]$(t_BU_xStart[t] and d1tRE[purpose,energy19,EH_sectors,t] and qFuel.l[t,e_EH_sectors,AggFt] and AggFT2Energy19(AggFT,energy19) and EH2EH(e_eh_sectors,eh_sectors) and purpose_xth[purpose])..  
		qREgj[purpose,energy19,EH_sectors,t] =E= qREgj.l[purpose,energy19,EH_sectors,t]* adj_fuel_RE[purpose,energy19,EH_sectors,e_EH_sectors,AggFT,t];

	E_uRE_adj_forecast[purpose,energy19,EH_sectors,t]$(t.val > t_BU_end.val and d1tRE[purpose,energy19,EH_sectors,t] and d1fueloverlap[purpose,energy19,EH_sectors,t] and purpose_xth[purpose])..  
		uRE[purpose,energy19,EH_sectors,t] =E= uRE[purpose,energy19,EH_sectors,t_BU_end];



	#Electric heaters are specifically modelled on their own.
	E_qRE_EH[t]$(t_BU_xStart[t] and d1vRE['process_special','electricity','35011',t])..
		 qREgj['process_special','electricity','35011',t]/qREgj['process_special','electricity','35011',t-1] =E= chi *  qFuel_EH[t]/(qFuel_EH[t-1]*fq) + (1-chi) * qREgj.l['process_special','electricity','35011',t]/qREgj.l['process_special','electricity','35011',t-1]; 


	E_uRE_adj_EH[t]$(t_BU_xStart[t] and d1vRE['process_special','electricity','35011',t])..
		uRE['process_special','electricity','35011',t] =E= uRE.l['process_special','electricity','35011',t]*adj_EH[t];

	E_uRE_adj_EH_forecast[t]$(t.val > t_BU_end.val and d1vRE['process_special','electricity','35011',t])..
		uRE['process_special','electricity','35011',t] =E= uRE['process_special','electricity','35011',t_BU_end]; 


	#  #Fuel-prices of the energy-model are adjusted to the fuel-prices in the CGE-model
	#  E_pFuel[t,BFt,energy19]$(t_BU_xStart[t] and sum(purpose, d1vRE[purpose,energy19,'35011',t]) and BFt2Energy19(BFt,energy19))..
	#  		(fp_t[t,BFt]* deflator_fm[t])/(fp_t[t-1,BFt] * deflator_fm[t-1]) 
	#  			=E= fp * (sum((purpose)$(d1vRE[purpose,energy19,'35011',t]), pRE_base[purpose,energy19,'35011',t]*qREgj[purpose,energy19,'35011',t])/sum((purpose)$(d1vRE[purpose,energy19,'35011',t]), qREgj[purpose,energy19,'35011',t]))
	#  					  /(sum((purpose)$(d1vRE[purpose,energy19,'35011',t-1]), pRE_base[purpose,energy19,'35011',t-1]*qREgj[purpose,energy19,'35011',t-1])/sum((purpose)$(d1vRE[purpose,energy19,'35011',t-1]), qREgj[purpose,energy19,'35011',t-1]));

	#We include J-term in calibrating to fuel-prices. We could have to adjust model prices to ensure consistent price pattern with RamsesData, but there is a trade-off therein as 
	#fuel prices are largely chosen consistently with KF22 in order to provide an accurate forecast of GVA in the refinery-sector
	E_pFuel[t,BFt,energy19]$(t_BU_xStart[t] and d1pEtot[energy19,t] and BFt2Energy19(BFt,energy19))..
		(fp_t[t,BFt]* deflator_fm[t])/(fp_t[t-1,BFt] * deflator_fm[t-1]) =E= fp * pEtot[energy19,t] /pEtot[energy19,t-1] + j_fp_t[t,BFt];


$ENDBLOCK 

#====================================================================================================================================================================================================================#
# 4) Definition of link-equations used in calibration only summarized in the block 'B_CGE_ENERGY_LINK_CALIB' 
#====================================================================================================================================================================================================================#


$BLOCK B_CGE_ENERGY_LINK_CALIB 
	#In the calibration we also determine higher-level CES-shares in the production functions of the el/heat producing sectors
    E_uEP_adj[purpose,EH_sectors,t]$(t_BU_xStart[t] and d1EP[purpose,EH_sectors,t] and purpose_xth[purpose]).. 
	   		pEP[purpose,EH_sectors,t-1] * qEP[purpose,EH_sectors,t] =E= sum(energy19$((d1tRE[purpose,energy19,EH_sectors,t] or d1vREown[purpose,energy19,EH_sectors,t]) and not eNotInEnergyNest[purpose,energy19,EH_sectors,t]), pREagg[purpose,energy19,EH_sectors,t-1] * qRE[purpose,energy19,EH_sectors,t]);

    E_uEP_adj_forecast[purpose,EH_sectors,t]$(t.val > t_BU_end.val and d1EP[purpose,EH_sectors,t] and purpose_xth[purpose])..
	   		uEP[purpose,EH_sectors,t] =E= uEP[purpose,EH_sectors,t_BU_end];  

   	#Øverste nest
    E_uE_adj[EH_sectors,t]$(t_BU_xStart[t]).. 
   		pE_CGE[EH_sectors,t-1] * qE[EH_sectors,t] =E= sum(purpose$d1EP[purpose,EH_sectors,t], pEP[purpose,EH_sectors,t-1] * qEP[purpose,EH_sectors,t]);

    E_uE_adj_forecast[EH_sectors_sp,t]$(t.val > t_BU_end.val)..
   		uE[EH_sectors_sp,t] =E= uE[EH_sectors_sp,t_BU_end];


   	#Demand 
	E_demand_e[t]$(t_BU_xStart[t]).. chi * (eD_t[t,'DK1'] + eD_t[t,'DK2'])/(eD_t[t-1,'DK1']+eD_t[t-1,'DK2'])/fq + (1-chi)*qE_consumption_CGE.l[t]/qE_consumption_CGE.l[t-1] =E= qE_consumption_CGE[t]/qE_consumption_CGE[t-1] ;
	E_demand_h[t]$(t_BU_xStart[t]).. chi * (hD_t[t,'HA_DK1'] + hD_t[t,'HA_DK2'])/(hD_t[t-1,'HA_DK1']+hD_t[t-1,'HA_DK2'])/fq + (1-chi) * qH_consumption_CGE.l[t]/qH_consumption_CGE.l[t-1] =E= qH_consumption_CGE[t]/qH_consumption_CGE[t-1];

	#We can then uniformly adjust the CES-shares to hit out demand target
	E_uRE_e[purpose,s,t]$(t_BU_xStart[t] and d1vRE[purpose,'electricity',s,t] and d1LargeEntries[purpose,'electricity',s,t] and not (sameas[purpose,'process_special'] and sameas[s,'35011']))..   qREgj[purpose,'electricity',s,t]   =E= qREgj.l[purpose,'electricity',s,t]*adj_eD_CGE[t];
	E_uRE_h[purpose,s,t]$(t_BU_xStart[t] and d1vRE[purpose,'district heat',s,t] and d1LargeEntries[purpose,'district heat',s,t]).. qREgj[purpose,'district heat',s,t] =E= qREgj.l[purpose,'district heat',s,t]*adj_hD_CGE[t];
	E_uRE_e_forecast[purpose,s,t]$(t.val > t_BU_end.val and d1vRE[purpose,'electricity',s,t] and d1LargeEntries[purpose,'electricity',s,t] and not (sameas[purpose,'process_special'] and sameas[s,'35011']))..       uRE[purpose,'electricity',s,t] =E= uRE[purpose,'electricity',s,t_BU_end];
	E_uRE_h_forecast[purpose,s,t]$(t.val > t_BU_end.val and d1vRE[purpose,'district heat',s,t] and d1LargeEntries[purpose,'district heat',s,t])..   uRE[purpose,'district heat',s,t] =E= uRE[purpose,'district heat',s,t_BU_end];

	E_uCE_e[purpose,t]$(t_BU_xStart[t] and d1vCE[purpose,'electricity',t])..   qCE[purpose,'electricity',t]   =E= qCE.l[purpose,'electricity',t]*adj_eD_CGE[t];
	E_uCE_h[purpose,t]$(t_BU_xStart[t] and d1vCE[purpose,'district heat',t]).. qCE[purpose,'district heat',t] =E= qCE.l[purpose,'district heat',t]*adj_hD_CGE[t];	
	E_uCE_e_forecast[purpose,t]$(t.val > t_BU_end.val and d1vCE[purpose,'electricity',t])..       sCE[purpose,'electricity',t] =E= sCE[purpose,'electricity',t_BU_end];
	E_uCE_h_forecast[purpose,t]$(t.val > t_BU_end.val and d1vCE[purpose,'district heat',t])..   sCE[purpose,'district heat',t] =E= sCE[purpose,'district heat',t_BU_end];	

	#  #Fuel price calib
	#  E_pFuel_calib[t,BFt,purpose,energy19]$(t_BU_xStart[t] and BFt2Energy19(BFt,energy19) and d1vRE[purpose,energy19,'35011',t])..
	#  	fpRE[purpose,energy19,'35011',t] =E= fpRE.l[purpose,energy19,'35011',t] + adj_fuelprice_calib[t,BFt,energy19];

	#  E_pFuel_calib_forecast[t,BFt,purpose,energy19]$(t.val > t_BU_end.val and BFt2Energy19(BFt,energy19) and d1vRE[purpose,energy19,'35011',t])..
	#  	fpRE[purpose,energy19,'35011',t] =E= fpRE[purpose,energy19,'35011',t_BU_end];

$ENDBLOCK 

#====================================================================================================================================================================================================================#
# 5) Definition of equations used in an energy-account model that provides initial values for the solver, only used for calibration 
#====================================================================================================================================================================================================================#

$BLOCK B_CGE_ENERGY_LINK_CALIB_ENERGY_ACCOUNT
	E_uRE_e_forecast_gj[purpose,s,t]$(t.val > t_BU_end.val and d1vRE[purpose,'electricity',s,t] and d1LargeEntries[purpose,'electricity',s,t] and not (sameas[purpose,'process_special'] and sameas[s,'35011']))..       
		qREgj[purpose,'electricity',s,t] =E= qREgj[purpose,'electricity',s,t-1];
	E_uRE_h_forecast_gj[purpose,s,t]$(t.val > t_BU_end.val and d1vRE[purpose,'district heat',s,t] and d1LargeEntries[purpose,'district heat',s,t])..   
		qREgj[purpose,'district heat',s,t] =E= qREgj[purpose,'district heat',s,t-1];

	E_uCE_e_forecast_gj[purpose,t]$(t.val > t_BU_end.val and d1vCE[purpose,'electricity',t])..       qCE[purpose,'electricity',t] =E= qCE[purpose,'electricity',t-1];
	E_uCE_h_forecast_gj[purpose,t]$(t.val > t_BU_end.val and d1vCE[purpose,'district heat',t])..   qCE[purpose,'district heat',t] =E= qCE[purpose,'district heat',t-1];	

	#Heat pumps
	E_qRE_EH_forecast[t]$(t.val > t_BU_end.val and d1vRE['process_special','electricity','35011',t])..
		qREgj['process_special','electricity','35011',t] =E= qREgj['process_special','electricity','35011',t_BU_end];



	E_qY_CET_LINK_e_forecast[EH_sectors,E_EH_sectors,t]$(t.val > t_BU_end.val and EH2EH(e_eh_sectors,eh_sectors)).. 
		qY_CET['electricity',EH_sectors,t]   =E= qY_CET['electricity',EH_sectors,t_BU_end];
	E_qY_CET_LINK_h_forecast[EH_sectors,E_EH_sectors,t]$(t.val > t_BU_end.val and sameas[EH_sectors,'38393'] and EH2EH(e_eh_sectors,eh_sectors)).. 
		qY_CET['district heat',EH_sectors,t] =E= qY_CET['district heat',EH_sectors,t_BU_end];

	#Heat production in 35011 is the residual
	E_qY_CET_LINK_h_residual[t]$(t.val > t_BU_start.val)..
		qY_CET['District heat','35011',t] + qY_CET['District heat','38393',t] + qM_CET['district heat','19000',t] =E=
													sum((purpose,r), qREgj[purpose,'District heat',r,t]$(d1vRE[purpose,'District heat',r,t]))   
                                                 +  sum(purpose$d1vCE[purpose,'District heat',t], qCE[purpose,'District heat',t]) 
                                                 +  sum(purpose$d1vLE[purpose,'District heat',t], qLE[purpose,'District heat',t])
                                                 +  sum(purpose$d1vXE[purpose,'District heat',t], qXE[purpose,'District heat',t]) 
                                                 +  sum(purpose$d1TL[purpose,'District heat',t],  qTL[purpose,'District heat',t]);   
    #Electricity exports is residual
	E_qY_CET_LINK_E_residual[t]$(t.val > t_BU_start.val)..
		qY_CET['Electricity','35011',t] + qY_CET['Electricity','38393',t] + qM_CET['electricity','19000',t] =E= 
													sum((purpose,r), qREgj[purpose,'Electricity',r,t]$(d1vRE[purpose,'Electricity',r,t]))   
                                                 +  sum(purpose$d1vCE[purpose,'Electricity',t], qCE[purpose,'Electricity',t]) 
                                                 +  sum(purpose$d1vLE[purpose,'Electricity',t], qLE[purpose,'Electricity',t])
                                                 +  sum(purpose$d1vXE[purpose,'Electricity',t], qXE[purpose,'Electricity',t]) 
                                                 +  sum(purpose$d1TL[purpose,'Electricity',t],  qTL[purpose,'Electricity',t]);   

 	E_pY_CET_LINK_e_forecast_account[EH_sectors,t]$(t.val > t_BU_end.val).. pY_CET['electricity',EH_sectors,t]   =E= pY_CET['electricity',EH_sectors,t_BU_end];
	E_pY_CET_LINK_h_forecast_account[EH_sectors,t]$(t.val > t_BU_end.val).. pY_CET['district heat',EH_sectors,t] =E= pY_CET['district heat',EH_sectors,t_BU_end];


	E_qM_CET_LINK_forecast_account[t]$(t.val > t_BU_end.val)..  qM_CET['electricity','19000',t] =E= qM_CET['electricity','19000',t_BU_end]; 


 	E_qRE_adj_forecast_account[purpose,energy19,EH_sectors,t]$(t.val > t_BU_end.val and d1tRE[purpose,energy19,EH_sectors,t] and d1fueloverlap[purpose,energy19,EH_sectors,t] and purpose_xth[purpose])..  
		qREgj[purpose,energy19,EH_sectors,t] =E= qREgj[purpose,energy19,EH_sectors,t_BU_end];

	#Afstemmer energibalancer vha. tilpasning af indenlandsk produktion (importen ville ellers være oplagt men a) for nogle energivarerne er importen stort set nul på det her tidspunkt og b) for energihalm er der ingen import)
	E_afstemEbalancer[energy19,t]$(t_BU_xStart[t] and sum((purpose,EH_sectors), d1fueloverlap[purpose,energy19,EH_sectors,t]) and not sameas[energy19,'waste'])..
		qEtot[energy19,t] =E= sum(s$(d1vY_CET[energy19,s,t]), qY_CET[energy19,s,t]) + sum(s$(d1vM_CET[energy19,s,t]), qM_CET[energy19,s,t]);

	E_afstemqY[energy19,s,t]$(t_BU_xStart[t] and d1vY_CET[energy19,s,t] and sum((purpose,EH_sectors), d1fueloverlap[purpose,energy19,EH_sectors,t]))..
		qY_CET[energy19,s,t] =E= qY_CET.l[energy19,s,t] * adjEbalance[energy19,t];

	E_afstemqM[energy19,s,t]$(t_BU_xStart[t] and d1vM_CET[energy19,s,t] and sum((purpose,EH_sectors), d1fueloverlap[purpose,energy19,EH_sectors,t]))..
		qM_CET[energy19,s,t] =E= qM_CET.l[energy19,s,t] * adjEbalance[energy19,t];


$ENDBLOCK 

#We set up the energy-account model
$MODEL M_CGE_ENERGY_LINK_CALIB_ENERGY_ACCOUNT
	#  B_CGE_ENERGY_LINK_CALIB_ENERGY_ACCOUNT
	E_demand_DK1
	E_demand_DK2

	E_hdemand_HA_DK1
	E_hdemand_HA_DK2

	E_uRE_e_forecast_gj
	E_uRE_h_forecast_gj 
	E_uCE_e_forecast_gj
	E_uCE_h_forecast_gj

	#Domestic demand
	E_qE_consumption_CGE
	E_qH_consumption_CGE

	E_demand_e 
	E_demand_h
	E_uRE_e #Bestemmer qREgj for el, fra 2019-2040. Calib equation
	E_uRE_h #Bestemmer qREgj for fjernvarme, fra 2019-2040. Calib equation
	E_uCE_e #Bestemmer qCE for el, fra 2019-2040. Calib equation
	E_uCE_h #Bestemmer qCE for fjernvarme, fra 2019-2040. Calib equation

	#  #  #Heat pumps
	E_qRE_EH #2019-2040 forbrug af el til varmepumper i forsyningssektoren
	E_qRE_EH_forecast


	E_pE_consumption_CGE #Definition af gennemsnitlige forbrugselpris i CGE-modellen
	E_pH_consumption_CGE #Definition af gennemsnitlige forbrugsfjernvarmepris i CGE-modellen

	#Production
	E_qY_CET_LINK_e #Produktion af el- og varme, 2019-2040
	E_qY_CET_LINK_h #Produktion af el- og varme, 2019-2040
	E_qY_CET_LINK_e_forecast #Produktion af el- og varme, 2041-2099
	E_qY_CET_LINK_h_forecast #Produktion af el- og varme, 2041-2099
	E_qY_CET_LINK_E_residual #Bestemmer eksport af el som residual i forsyningsbalancen
	E_qY_CET_LINK_h_residual #Bestemmer varmeproduktion i 35011 som residual i forsyningsbalancen

	E_pY_CET_LINK_e #Pris på el, 2019-2040
	E_pY_CET_LINK_h #Pris på fjernvarme, 2019-2040
	E_pY_CET_LINK_e_forecast_account
	E_pY_CET_LINK_h_forecast_account

	#To compute consumption prices we need to compute total D/S, average price and base prices
	E_qEtot
	E_pEtot
	E_pRE_base
	E_pCE_base

	#Domestic prices 
	E_pE_consumption_CGE_adjust
	E_pH_consumption_CGE_adjust
	E_fpRE_e
	E_fpRE_e_forecast
	E_fpRE_h 
	E_fpRE_h_forecast
	E_fpCE_e 
	E_fpCE_e_forecast
	E_fpCE_h
	E_fpCE_h_forecast

	#Export price on electricity
	E_pXE_base
	E_pXE_LINK
	E_fpXE_forecast

	#Import
	E_qM_CET_LINK
	E_qM_CET_LINK_forecast_account
	E_pM_CET_LINK
	E_pM_CET_LINK_forecast


	#  #Fuel input in production 
	E_qRE_adj
	E_qRE_adj_forecast_account

	#
	E_afstemEbalancer
	E_afstemqY
	E_afstemqM

	#Fuel prices 
	E_pFuel
	#  E_pFuel_calib
	#  E_pFuel_calib_forecast

;

$GROUP G_CGE_ENERGY_LINK_CALIB_ENERGY_ACCOUNT_EXO 
	eD_t$(t_BU[t])
	hD_t$(t_BU[t])

	#Heat pumps
	qREgj$(t.val=t_BU_start.val and d1vRE[purpose,energy19,r,t] and sameas[r,'35011'] and sameas[purpose,'process_special'] and sameas[energy19,'electricity'])
	qFuel_EH 

	qREgj$(d1vRE[purpose,energy19,r,t] and d1LargeEntries[purpose,energy19,r,t] and sameas[energy19,'electricity'] and t_BU[t]) # and not (sameas[purpose,'process_special'] and sameas[r,'35011'])) 		#E_uRE_e, E_uRE_e_forecast
	qREgj$(d1vRE[purpose,energy19,r,t] and d1LargeEntries[purpose,energy19,r,t] and sameas[energy19,'district heat'] and t_BU[t]) 		#E_uRE_h, E_uRE_h_forecast
	qCE$(d1vCE[purpose,energy19,t] and sameas[energy19,'electricity'] and t_BU[t]) 			#E_uCE_e, E_uCE_e_forecast
	qCE$(d1vCE[purpose,energy19,t] and sameas[energy19,'district heat'] and t_BU[t]) 		#E_uCE_h, E_uCE_h_forecast 
	qTL

	qY_CET$(t.val = t_BU_Start.val and EH_sectors[s])
	qY_E 
	qY_H
	pY_CEt$(t.val = t_BU_start.val and EH_sectors[s])

	pY_E, pY_H
	pY_CET$(t.val =  t_BU_Start.val and d1fuelpriceoverlape19[out,t] and d1vY_CET[out,s,t])
	pM_CET$(t.val =  t_BU_start.val and d1fuelpriceoverlape19[out,t] and d1vM_CEt[out,s,t])


	#E_qEtot
	qREgj$(d1vRE[purpose,energy19,r,t]), qCE$(d1vCE[purpose,energy19,t]), qXE$(d1vXE[purpose,energy19,t]), qLE$(d1vLE[purpose,energy19,t]), qTL$(d1TL[purpose,energy19,t]), 
	pCE_base$(d1vCE[purpose,energy19,t]), pRE_base$(d1vRE[purpose,energy19,r,t]), 

	#E_pE_tot
	qY_CET$(d1vY_CET[out,s,t] and energy19[out]), qM_CET$(d1vM_CET[out,s,t] and energy19[out]), pY_CET$(d1vY_CET[out,s,t] and energy19[out]), pM_CET$(d1vM_CET[out,s,t] and energy19[out])

	#
	pE_consumption #Is determined in energy-model
	pH_consumption

	pE_export, fPxE$(d1vXE[purpose,energy19,t])

	#Import 
	qE_import, qM_CET$(t_BU_start[t] and d1vM_CET[out,s,t] and sameas[out,'Electricity'])
	pE_import, pM_CET$(t_BU_start[t] and d1vM_CET[out,s,t] and sameas[out,'Electricity'])

 	qREgj$(t.val = t_BU_start.val and d1tRE[purpose,energy19,r,t] and d1fueloverlap[purpose,energy19,r,t]), qFuel

;

$GROUP G_CGE_ENERGY_LINK_CALIB_ENERGY_ACCOUNT_ENDO 
	qREgj$(d1vRE[purpose,energy19,r,t] and d1LargeEntries[purpose,energy19,r,t] and sameas[energy19,'electricity'] and t.val > t_BU_start.val and not (sameas[purpose,'process_special'] and sameas[r,'35011'])) 		#E_uRE_e, E_uRE_e_forecast
	qREgj$(d1vRE[purpose,energy19,r,t] and d1LargeEntries[purpose,energy19,r,t] and sameas[energy19,'district heat'] and t.val > t_BU_start.val) 		#E_uRE_h, E_uRE_h_forecast
	qCE$(d1vCE[purpose,energy19,t] and sameas[energy19,'electricity'] and t.val > t_BU_start.val) 			#E_uCE_e, E_uCE_e_forecast
	qCE$(d1vCE[purpose,energy19,t] and sameas[energy19,'district heat'] and t.val > t_BU_start.val) 		#E_uCE_h, E_uCE_h_forecast 

	#  #Heat pumps
	qREgj$(t.val>t_BU_start.val and d1vRE[purpose,energy19,r,t] and sameas[r,'35011'] and sameas[purpose,'process_special'] and sameas[energy19,'electricity'])

	qY_CET$(t.val > t_BU_Start.val and EH_sectors[s] and sameas[out,'electricity'])
	qY_CET$(t.val > t_BU_Start.val and sameas[s,'38393'] and sameas[out,'district heat'])
	qY_CET$(t.val > t_BU_start.val and sameas[s,'35011'] and sameas[out,'district heat'])
	qXE$(t.val > t_BU_Start.val and d1vXE[purpose,energy19,t] and sameas[energy19,'Electricity'])

	pY_CET$(t.val > t_BU_start.val and d1vY_CET[out,s,t] and EH_sectors[s] and (sameas[out,'electricity'] or sameas[out,'district heat']))

	pRE_base$(d1vRE[purpose,energy19,r,t]), pCE_base$(d1vCE[purpose,energy19,t])


	fpRE$(t.val > t_BU_Start.val and d1vRE[purpose,energy19,r,t] and sameas[energy19,'electricity'] and not (sameas[purpose,'process_special'] and sameas[r,'35011']))   #E_fpRE_e, E_fpRE_e_forecast
	fpCE$(t.val > t_BU_Start.val and d1vCE[purpose,energy19,t] and sameas[energy19,'electricity'])     #E_fpCE_e, E_fpCE_e_forecast
	fpRE$(t.val > t_BU_Start.val and d1vRE[purpose,energy19,r,t] and sameas[energy19,'district heat']) #E_fpRE_h, E_fpRE_h_forecast
 	fpCE$(t.val > t_BU_Start.val and d1vCE[purpose,energy19,t] and sameas[energy19,'district heat'])   #E_fpCE_h, E_fpCE_h_forecast



 	pXE_base$(d1vXE[purpose,energy19,t]) 
 	fpXE$(t.val > t_BU_Start.val and sameas[energy19,'electricity'] and sameas[purpose,'unspecified'])


 	qM_CET$(t.val > t_BU_Start.val and d1vM_CET[out,s,t] and sameas[out,'electricity'])
 	pM_CET$(t.val > t_BU_Start.val and d1vM_CET[out,s,t] and sameas[out,'electricity'])

 	#Fuelinput 
 	#  fpRE$(t.val > t_BU_start.val and sum(BFt, BFt2Energy19(BFt,energy19)) and d1vRE[purpose,energy19,r,t] and sameas[r,'35011'])
 	j_fp_t$(t_BU_xStart[t] and sum(energy19, d1pEtot[energy19,t] and BFt2Energy19(BFt,energy19)))

 	qREgj$(t.val > t_BU_start.val and d1tRE[purpose,energy19,r,t] and d1fueloverlap[purpose,energy19,r,t] and purpose_xth[purpose])

 	qY_CET$(t_BU_xStart[t] and d1vY_CET[out,s,t] and d1fueloverlap_e19[out,t])
 	qM_CET$(t_BU_xStart[t] and d1vM_CET[out,s,t] and d1fueloverlap_e19[out,t])

;

#  $FIX G_CGE_ENERGY_LINK_CALIB_ENERGY_ACCOUNT_EXO;
#  $UNFIX G_CGE_ENERGY_LINK_CALIB_ENERGY_ACCOUNT_ENDO;
#  @SOLVE(M_CGE_ENERGY_LINK_CALIB_ENERGY_ACCOUNT);
#  $exit

#====================================================================================================================================================================================================================#
# 6) For the years covered by Klimafremskrivningen (2015-2030) there's an overlap of some equations. To accomodate this an approach is KF21 equations are to furthest extend. The account model ensures that the KF21-equations become consistent with a calibration of the energy-model
#====================================================================================================================================================================================================================#

#Creation of alternative equations that only work on time-periods that do not overlap with KF time periods. The KF21 time periods are captured by the subset tBF_calib
$BLOCK B_CGE_ENERGY_LINK_postBFcalib
	$LOOP B_CGE_ENERGY_LINK:
	{name}_postBFcalib{sets}$(({subsets}) and not tBF_calib[t]).. {LHS} =E= {RHS};
	$ENDLOOP
$ENDBLOCK

$BLOCK B_CGE_ENERGY_LINK_CALIB_postBFcalib
	$LOOP B_CGE_ENERGY_LINK_CALIB:
	{name}_postBFcalib{sets}$(({subsets}) and not tBF_calib[t]).. {LHS} =E= {RHS};
	$ENDLOOP
$ENDBLOCK


#  $GROUP G_CGE_ENERGY_LINK_ENDO_postBFcalib
#  	$LOOP G_CGE_ENERGY_LINK_ENDO:
#  		{name}$({subsets} and not tBF_calib[t])
#  	$ENDLOOP
#  ;


#In KF21 calibration parameters are pulled flat after 2030 (last KF21 year). We don't want this to be done specifically for el/heat production and demand. We therefore create alternative equations that only pull flat when its not El/heat
$BLOCK B_CALIB_2_KF_xElHeat

    E_sY_AGG_forecast_xElHeat[energy19,s,t]$(tx0[t] and t.val > tBF_calib_End.val and d1vY_CET[energy19,s,t] and not d1vE_onesupplier[energy19,t] and not (sameas[s,'35011'] and sameas[energy19,'Electricity']) and not (sameas[s,'38393'] and sameas[energy19,'District heat'])).. 
     	 sY_AGG[energy19,s,t] =E= sY_AGG[energy19,s,tBF_calib_End];


  	E_sM_AGG_forecast_xElHeat[energy19,s,t]$(tx0[t] and t.val > tBF_calib_End.val and d1vM_CET[energy19,s,t] and not d1vE_onesupplier[energy19,t] and not ElHeat[energy19]).. 
	      sM_AGG[energy19,s,t] =E= sM_AGG[energy19,s,tBF_calib_End];

	#£ tænk over det her....
	E_sM_AGG_forecast_Heat[energy19,s,t]$(tx0[t] and t.val > tBF_calib_End.val and d1vM_CET[energy19,s,t] and not d1vE_onesupplier[energy19,t] and sameas[energy19,'district heat'])..
		sM_Agg[energy19,s,t] =E= sM_AGG[energy19,s,tBF_calib_end]; 

 	E_sXE_forecast_xElHeat[purpose,energy19,t]$(tx0[t] and t.val >tBF_calib_End.val and d1vXE[purpose,energy19,t] and not ElHeat[energy19]).. # and not sameas[energy19,'Natural gas incl. biongas']).. # NatGasCityLVN[energy19])..	
	 	#  E_sXE_forecast[purpose,energy19,t]$(tx0[t] and t.val >tBF_calib_End.val and d1vXE[purpose,energy19,t] and not eExcludeExportsGR[energy19] and not NatGasCityLVN[energy19])..
	 		sXE[purpose,energy19,t] =E= sXE[purpose,energy19,tBF_calib_End];


    E_uRE_forecast_xElHeat[purpose,energy19,s,t]$(tx0[t] and t.val > tBF_calib_End.val and (d1tRE[purpose,energy19,s,t] or d1vREown[purpose,energy19,s,t]) and not bunkering[energy19]
    											and not (d1tRE[purpose,energy19,s,t] and d1fueloverlap[purpose,energy19,s,t] and purpose_xth[purpose])
    											and not (d1vRE[purpose,energy19,s,t] and d1LargeEntries[purpose,energy19,s,t] and sameas[energy19,'electricity'] and not (sameas[purpose,'process_special'] and sameas[s,'35011']))
    											and not (d1vRE[purpose,energy19,s,t] and sameas[purpose,'process_special'] and sameas[energy19,'electricity'] and sameas[s,'35011']) #Heat-pumps
    											and not (d1vRE[purpose,energy19,s,t] and d1LargeEntries[purpose,energy19,s,t] and sameas[energy19,'district heat']))..
    	uRE[purpose,energy19,s,t] =E= uRE[purpose,energy19,s,tBF_calib_End];

    E_uEP_forecast_xElHeat[purpose,s,t]$(tx0[t] and t.val > tBF_calib_End.val and d1EP[purpose,s,t] and not agri_sectors_s[s]
    											and not (d1EP[purpose,s,t] and EH_sectors[s] and purpose_xth[purpose]))..
    	uEP[purpose,s,t] =E= uEP[purpose,s,tBF_calib_End];

    E_uE_forecast_xElHeat[sp,t]$(tx0[t] and t.val > tBF_calib_End.val and not EH_sectors[sp])..
	   		uE[sp,t] =E= uE[sp,tBF_calib_End];	

    E_sCE_forecast_xElHeat[purpose,energy19,t]$(tx0[t] and t.val > tBF_calib_End.val and d1vCE[purpose,energy19,t]
    											and not (sameas[energy19,'electricity'])
    											and not (sameas[energy19,'District heat']))..
	    	sCE[purpose,energy19,t] =E= sCE[purpose,energy19,tBF_calib_End];

	E_markup_forecast_xElHeat[energy19,s,t]$(tx0[t] and t.val > tBF_calib_prices_End.val and d1vY_CET[energy19,s,t] and d1pY_CET_overlap[energy19,s,t] and not sameas[energy19,'Straw for energy purposes'] and not sameas[s,'0600a']
							  and not (d1vY_CET[energy19,s,t] and not sameas[energy19,'Straw for energy purposes'] and d1fuelpriceoverlape19[energy19,t] and not sameas[s,'0600a'])).. # and not sameas[energy19,'Electricity'])..
			markup[energy19,s,t] =E= markup[energy19,s,tBF_calib_End];

	E_pM_CET_forecast_xElHeat[energy19,s,t]$(tx0[t] and t.val > tBF_calib_prices_end.val and d1vM_CET[energy19,s,t] and d1pM_CET_overlap[energy19,s,t]
											and not (d1vM_CET[energy19,s,t] and d1fuelpriceoverlape19[energy19,t]))..
			pM_CET[energy19,s,t] =E= pM_CET[energy19,s,tBF_calib_End];


$ENDBLOCK 

#====================================================================================================================================================================================================================#
# 7) Setting up calibration model
#====================================================================================================================================================================================================================#

#Der er markeret med tal (1) - (4) blokke af ligninger og variable, der kan kommenteres ud/ind og burde være square. Det er bare forslag til, hvordan man kan skille delene ad, hvis man løber ind i problemer

$MODEL M_dynamic_calibration_energy
	M_dynamic_calibration_KF22 #The calibration to KF22 is carried forward (some equations are subtracted and replaced in the below though)
	M_energy 

	#Domestic demand for el/heat
		E_demand_DK1
		E_demand_DK2
		E_hdemand_HA_DK1
		E_hdemand_HA_DK2

	#Domestic demand for el/heat in CGE-model
		E_pE_consumption_CGE
		E_pH_consumption_CGE
		E_qE_consumption_CGE
		E_qH_consumption_CGE

	#  #Domestic prices
		E_pE_consumption_CGE_adjust_postBFcalib
		E_pH_consumption_CGE_adjust_postBFcalib
		E_fpRE_e_postBFcalib
		E_fpCE_e_postBFcalib
		E_fpRE_h_postBFcalib
		E_fpCE_h_postBFcalib

		E_fpRE_e_forecast_postBFcalib 
		E_fpCE_e_forecast_postBFcalib
		E_fpRE_h_forecast_postBFcalib
		E_fpCE_h_forecast_postBFcalib


	# (4a) Export price
		#  -E_pXE_el
		#  E_pXE_LINK_postBFcalib, E_fpXE_forecast_postBFcalib
		#  E_pXE_LINK, E_fpXE_forecast

	#  #Import
		-E_sM_AGG_forecast, E_sM_AGG_forecast_xElHeat, E_sM_AGG_forecast_Heat
		E_qM_CET_LINK_postBFcalib 
		E_qM_CET_LINK_forecast_postBFcalib

	#  # (4b)
		#  E_pM_CET_LINK_postBFcalib 
		#  E_pM_CET_LINK_forecast_postBFcalib

	#  #Production
		-E_sXE_forecast, E_sXE_forecast_xElHeat
		-E_sY_AGG_forecast, E_sY_AGG_forecast_xElHeat
		E_qY_CET_LINK_e_postBFcalib
		E_qY_CET_LINK_h_postBFcalib
		E_sY_AGG_e_postBFcalib
		E_sXE_e_postBFcalib
		E_sY_AGG_h_postBFcalib

	# (4c)
		-E_markup_forecast_ElHeat
		#  E_pY_CET_LINK_e_postBFcalib 
		#  E_pY_CET_LINK_h_postBFcalib
		E_markup_LINK_e_postBFcalib
		E_markup_LINK_h_postBFcalib

	# (3) Demand
		#  Fuel
			-E_uRE_forecast, E_uRE_forecast_xElHeat #This equation is needed for el/heat demand as well
			E_qRE_adj_postBFcalib 
			E_uRE_adj_postBFcalib 
			E_uRE_adj_forecast_postBFcalib
			-E_uEP_forecast, E_uEP_forecast_xElHeat
			E_uEP_adj_postBFcalib 
			E_uEP_adj_forecast_postBFcalib
			-E_uE_forecast, E_uE_forecast_xElHeat
			E_uE_adj_postBFcalib
			E_uE_adj_forecast_postBFcalib

		#  El/Heat demand
			E_demand_e_postBFcalib, E_demand_h_postBFcalib
			-E_sCE_forecast, E_sCE_forecast_xElHeat 
			E_uRE_e_postBFcalib 
			E_uRE_h_postBFcalib
			E_uRE_e_forecast_postBFcalib 
			E_uRE_h_forecast_postBFcalib 

			E_uCE_e_postBFcalib 
			E_uCE_h_postBFcalib 
			E_uCE_e_forecast_postBFcalib 
			E_uCE_h_forecast_postBFcalib 

		#  Heat pumps
			E_qRE_EH_postBFcalib, E_uRE_adj_EH_postBFcalib, E_uRE_adj_EH_forecast_postBFcalib

;

$GROUP G_dynamic_calibration_endo 
	G_dynamic_calibration_endo
	G_energy_endo

		fDK1$(t_BU[t]) 
		fDK2$(t_BU[t]) 
		fHA_DK1$(t_BU[t]) 
		fHA_DK2$(t_BU[t]) 


	#Domestic prices
		adj_pE_consumption_CGE$(t_BU_xStart[t] and not tBF_calib[t])
		adj_pH_consumption_CGE$(t_BU_xStart[t] and not tBF_calib[t])

		fpRE$(t.val > t_BU_start.val and d1vRE[purpose,energy19,r,t] and sameas[energy19,'electricity'] and not (sameas[purpose,'process_special'] and sameas[r,'35011']) and not tBF_calib[t])   #E_fpRE_e, E_fpRE_e_forecast
		fpCE$(t.val > t_BU_start.val and d1vCE[purpose,energy19,t] and sameas[energy19,'electricity'] and not tBF_calib[t])     #E_fpCE_e, E_fpCE_e_forecast
		fpRE$(t.val > t_BU_start.val and d1vRE[purpose,energy19,r,t] and sameas[energy19,'district heat'] and not tBF_calib[t]) #E_fpRE_h, E_fpRE_h_forecast
	 	fpCE$(t.val > t_BU_start.val and d1vCE[purpose,energy19,t] and sameas[energy19,'district heat'] and not tBF_calib[t])   #E_fpCE_h, E_fpCE_h_forecast

 	#Export-price
		#  fpXE$(t.val > t_BU_start.val and sameas[energy19,'electricity'] and sameas[purpose,'unspecified'] and not tBF_calib[t]) #E_pXE_LINK, E_fpXE_forecast

	#  #Import
		sM_AGG$(t.val > t_BU_start.val and sameas[energy19,'electricity'] and sameas[s,'19000'] and not tBF_calib[t]) 
	#  	pM_CET$(t.val > t_BU_start.val and sameas[out,'electricity'] and sameas[s,'19000'] and not tBF_calib[t])


	#Production
		sY_AGG$(t.val > t_BU_start.val and sameas[energy19,'electricity'] and sameas[s,'35011'] and not tBF_calib[t]) 
		sXE$(t.val > t_BU_start.val and sameas[purpose,'unspecified'] and sameas[energy19,'electricity'] and not tBF_calib[t])  #E_qY_CET_LINK_e, E_sY_AGG_e, E_sXE_e 
		sY_AGG$(t.val > t_BU_start.val and sameas[energy19,'district heat'] and  sameas[s,'38393'] and not tBF_calib[t]) #E_qY_CET_LINK_h, E_sY_AGG_h 

		markup$(t.val > t_BU_start.val and d1vY_CET[out,s,t] and EH_sectors[s] and (sameas[out,'electricity'] or sameas[out,'district heat']) and not tBF_calib[t])

    #(3) Demand
		adj_eD_CGE$(t_BU_xStart[t] and not tBF_calib[t]), adj_hD_CGE$(t_BU_xStart[t] and not tBF_calib[t])
		uRE$(d1vRE[purpose,energy19,s,t] and d1LargeEntries[purpose,energy19,s,t] and sameas[energy19,'electricity'] and t.val > t_BU_start.val and not (sameas[purpose,'process_special'] and sameas[s,'35011']) and not tBF_calib[t]) 		#E_uRE_e, E_uRE_e_forecast
		uRE$(d1vRE[purpose,energy19,s,t] and d1LargeEntries[purpose,energy19,s,t] and sameas[energy19,'district heat'] and t.val > t_BU_start.val and not tBF_calib[t]) 		#E_uRE_h, E_uRE_h_forecast
		sCE$(d1vCE[purpose,energy19,t] and sameas[energy19,'electricity'] and t.val > t_BU_start.val and not tBF_calib[t]) 			#E_uCE_e, E_uCE_e_forecast
		sCE$(d1vCE[purpose,energy19,t] and sameas[energy19,'district heat'] and t.val > t_BU_start.val and not tBF_calib[t]) 		#E_uCE_h, E_uCE_h_forecast 

		uRE$(t.val > t_BU_start.val and d1vRE[purpose,energy19,s,t] and sameas[purpose,'process_special'] and sameas[s,'35011'] and sameas[energy19,'electricity'] and not tBF_calib[t])
		adj_EH$(t_BU_xStart[t] and not tBF_calib[t])

		#Fuel 
		adj_fuel_RE$(t_BU_xStart[t] and d1tRE[purpose,energy19,EH_sectors,t] and qFuel.l[t,e_EH_sectors,AggFt] and AggFT2Energy19(AggFT,energy19) and not tBF_calib[t])
		uRE$(t.val > t_BU_start.val and d1tRE[purpose,energy19,s,t] and d1fueloverlap[purpose,energy19,s,t] and purpose_xth[purpose] and not tBF_calib[t])
		uEP$(t.val > t_BU_start.val and d1EP[purpose,s,t] and EH_sectors[s] and purpose_xth[purpose] and not tBF_calib[t])
		uE$(t.val > t_BU_start.val and EH_sectors[sp] and not tBF_calib[t])

	#  #(4) Fuel prices
	#   	#  fpRE$(t.val > t_BU_start.val and sum(BFt, BFt2Energy19(BFt,energy19)) and d1vRE[purpose,energy19,r,t] and sameas[r,'35011'])

;


$GROUP G_dynamic_calibration_exo
	G_dynamic_calibration_exo
	G_energy_exo
	G_CGE_ENERGY_LINK_EXO
;

#====================================================================================================================================================================================================================#
# 8) Solving calibration model
#====================================================================================================================================================================================================================#

#In traditional fashion we iterate towards the fully-calibrated model
$FOR {chi} in ['0.3','1']:
   chi = {chi};
   $FIX G_CGE_ENERGY_LINK_CALIB_ENERGY_ACCOUNT_EXO;
   $UNFIX G_CGE_ENERGY_LINK_CALIB_ENERGY_ACCOUNT_ENDO;
   @SOLVE(M_CGE_ENERGY_LINK_CALIB_ENERGY_ACCOUNT);

   $FIX G_dynamic_calibration_exo;
   $UNFIX G_dynamic_calibration_endo;
   @print("------------------------------------------ Current iteration is: chi = {chi} --------------------------")
   $IF %readfromprevious%!=1:
   	@SOLVE(M_dynamic_calibration_energy);
   $ENDIF
$ENDFOR

#Energy-model should not move in calibration
@assert_no_difference_from(G_energy_endoexo,1e-6,_energy_endoexo);
@assert_no_difference(G_data,1e-6);
@set_adjustmentparms(G_CGE_ENERGY_LINK_ZERO_IN_BASE,G_CGE_ENERGY_LINK_ONE_IN_BASE);
execute_unload 'output\integrated_energy.gdx';