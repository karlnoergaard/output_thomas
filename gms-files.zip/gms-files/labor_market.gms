# =====================================================================================================================
# LABOR MARKET: UNEMPLOYMENT AND THE PHILLIPS-CURVE
# =====================================================================================================================

# =====================================================================================================================
# Variable definition
# =====================================================================================================================
$IF %stage% == "variables":
  $GROUP G_labor_market_prices
    empty_group_dummy[t]            ""
  ;

  $GROUP G_labor_market_quantities
    empty_group_dummy[t]            ""
  ;

  $GROUP G_labor_market_values
   vTrans[t]                        "Government transfer payment"
   vPrimIncome[t]                   "Individual income excl. capital income"
   vtPrimIncome[t]                  "Total tax revenue from personal income"
  ;

  $GROUP G_labor_market_other
      u[t]                          "Unemployment-rate"
      uStruct[t]$(tx0[t])           "Structural unemployment-rate"
      adj_philip[t]$(tx0[t])        "Adjustment-parameter in Phillips-curve so the unemployment rate equals that from external forecast (MAKRO or KP21)"
      uLaborForce[t]$(tx0[t])       "Laborforce share"
      nPop[t]$(tx0[t])              "Population in 1000 persons"
      tTrans[t]$(tx0[t])            "Government transfer payment share" 
      Eta_Hours[t]$(tx0[t])         "Preference parameter for hours"
      tMargIncome[t]$(tx0[t])       "(average) Tax rate for wage income - should be the marginal tax rate"
      eHt                           "Elasticity of labor supply"
      nEmployed[t]                  "Number of employed people"
      nUnemployed[t]                "Number of unemployed people"
      nLaborForce[t]                "Number of people in the Labor force"
      Hours[t]                      "Hours worked"

  ;

$ENDIF 

$IF %stage% =="groupcompilation":

  $GROUP G_labor_market_endo
    G_labor_market_values
    nEmployed
    nUnemployed
    nLaborForce
    Hours         
    u[t]
  ;

  $GROUP G_labor_market_endo G_labor_market_endo$(tx0[t]); # Restrict endo group to tx0[t]


  $GROUP G_labor_market_exo 
    G_labor_market_other, -nEmployed,-nUnemployed,-nLaborForce,-hours, -u 
    pC$((tx0[t] or t0[t]) and sameas[c_,'ctot']) 
    w$(tx0[t] or t0[t])
    #  vCont[t]
    #  vGov2HH[t]
    #  vGovReceiveHH[t]
    vtAM[t]$(tx0[t])
    vtSource[t]$(tx0[t])
    vtMedia[t]$(tx0[t])
    vtChurch[t]$(tx0[t])
    vtCarWeight[t]$(tx0[t])
    vtPersIncRest[t]$(tx0[t])
    vtPAL[t]$(tx0[t])
    vtBequest[t]$(tx0[t])
    prod_a$(tx0[t])
  ;

  $GROUP G_labor_market_non_flat_initial_values_from_MAKRO
    u
    uStruct
    nPop 
    nLaborForce
    nEmployed
    nUnemployed
  ;


$ENDIF 



# =====================================================================================================================
# Equations
# =====================================================================================================================
$IF %stage% == "equations":
  $BLOCK B_labor_market
# ---------------------------------------------------------------------------------------------------------------------
# Identities 
# ---------------------------------------------------------------------------------------------------------------------
 
     E_nEmployed[t]$(tx0[t])..        nEmployed[t] =E=  (1-u[t]) * nLaborForce[t];

     E_nUnemployed[t]$(tx0[t])..    nUnemployed[t] =E= nLaborForce[t] - nEmployed[t];
    
     E_nLaborForce[t]$(tx0[t])..    nLaborForce[t] =E=  uLaborForce[t]*nPop[t];
 
     E_vTrans[t]$(tx0[t])..              vTrans[t] =E=  tTrans[t] * w[t] * (nPop[t] - nLaborForce[t]); 
  
 # FOC for hours 
     E_Hours[t]$tx0[t]..                  Hours[t] =E= Eta_Hours[t]*( (1-tMargIncome[t]) * w[t]/pC['ctot',t] )**eHt  ; 

     E_vPrimIncome[t]$(tx0[t])..    vPrimIncome[t] =E= (1-tMargIncome[t]) * (w[t] * Hours[t] * prod_a[t] * nEmployed[t] 
                                                      + vTrans[t])
                                                      #  - vLumpsum[t] # From consumers.gms - if this (or/and the following) lines are commented back in, the variables must be added to the exo-group
                                                      #  - vtPrimIncome[t]
                                                      #  - vCont[t]
                                                      #  + (vGov2HH[t] - vGovReceiveHH[t])
                                                      ;

    E_vtPrimIncome[t]$(tx0[t])..   vtPrimIncome[t] =E= vtAM[t]
                                                      + vtSource[t]
                                                      + vtMedia[t]
                                                      + vtChurch[t]
                                                      + vtCarWeight[t]
                                                      + vtPersIncRest[t]
                                                      + vtPAL[t]
                                                      + vtBequest[t];


    E_w[t]$(tx0[t])..           w[t] / w[t-1] * fv =E= adj_philip[t] * [pC['ctot',t] / pC['ctot',t-1]* fp]**0.3 * exp[-0.55*[u[t]-ustruct[t]]] ; 
                                                                                                                                                          

  

  $ENDBLOCK

$MODEL M_labor_market B_labor_market;
$ENDIF


$IF %stage% == "exogenous_values":
# =====================================================================================================================
# Exogenous variables
# =====================================================================================================================
eHt.l                     = 0.1;
u.l[t]                    = ExtFor_u[t];
#  uStruct.l[t]              = ExtFor_uStruct[t];
uStruct.l[t]              = u.l[t];
adj_philip.l[t]$(tx0[t])  = 1;
tMargIncome.l[tData]      = 0.376;

# =====================================================================================================================
# Data assignment
# =====================================================================================================================

  # ---------------------------------------------------------------------------------------------------------------------
  # POPULATION SIZE
  # ---------------------------------------------------------------------------------------------------------------------

nLaborForce.l[t] = ExtFor_nL('tot',t)/(1 - u.l[t]);
nEmployed.l[t]   = ExtFor_nL('tot',t);
nUnEmployed.l[t] = nLaborForce.l[t] - nEmployed.l[t];;
vTrans.l[t]      = ExtFor_vTrans['tot',t]/MAKRO_inf_growth_factor[t];
Hours.l[tData]   = 1;
vPrimIncome.l[t] = (1-tMargIncome.l[t]) * (w.l[t] * Hours.l[t] * nEmployed.l[t] + vTrans.l[t]);
nPop.l[t]        = ExtFor_nPop['tot',t];

 
 # --------------------------------------------------------------------------------------------------------------------
# Variables that are covered by data
# --------------------------------------------------------------------------------------------------------------------
$GROUP G_labor_market_data 
  u 
  nPop 
  nLaborForce 
  nEmployed 
  nUnemployed 
  vTrans 
;
$ENDIF


# =====================================================================================================================
# Static calibration
# =====================================================================================================================
$IF %stage% == "static_calibration":
  $GROUP G_labor_market_static_calibration
    G_labor_market_endo
    uLaborForce[t]$(tx0[t]), -nLaborForce[t]
    Eta_Hours[t]$(tx0[t]),-Hours[t]
    tTrans[t]$(tx0[t]), -vTrans[t]
    -u, adj_philip$(tx0[t])
 ;

  $GROUP G_labor_market_static_calibration_exo
    G_labor_market_exo
    nLaborForce[t]$(tx0[t]), -uLaborForce[t]
    Hours[t]$(tx0[t]), -Eta_Hours[t]
    vTrans[t]$(tx0[t]), -tTrans[t]
    u$(tx0[t]), -adj_philip
 ;

  $MODEL M_labor_market_static_calibration
    M_labor_market
  ;

$ENDIF


# =====================================================================================================================
# Dynamic calibration
# =====================================================================================================================
$IF %stage% == "dynamic_calibration":
  $GROUP G_labor_market_calib
    G_labor_market_endo
    uLaborForce$(tx0[t]), -nLaborForce$(tx0[t])
    tTrans$(tx0[t]), -vTrans
    -u, adj_philip$(tx0[t])
;

$GROUP G_labor_market_calib_exo
    G_labor_market_exo
    -uLaborForce$(tx0[t]), nLaborForce$(tx0[t])
    vTrans$(tx0[t]), -tTrans
    u$(tx0[t]), -adj_philip
;

  $MODEL M_labor_market_calib
    M_labor_market
  ;
$ENDIF
 
