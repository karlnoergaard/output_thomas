
#====================================================================================================================================================================================================================#
# Various calibrations and changes of the model
#====================================================================================================================================================================================================================#

Sets s_DK[sp] "brancher hvor danskejerskab er sat eksogent" / 01011, 01012, 01020, 01031, 01032, 01051, 01052, 01061, 01062, 02000, 10011, 10012, 10013, 10030, 68203/; 


	$GROUP G_Last_Calib_Endo
  	sEquityDKownedEndo[t]$(tx0[t]) "Hvor stor en del af virksomhederne (uden eksogen antagelse om ejerskab) der af danskejet"
  	vWealth_shockCorrection[t]$(tx0[t]) "Korrektion i husholdningernes formue som følge af stødet"  	  	  	
	;

	$GROUP G_Last_calib_Exo
  	sEquityDKownedExo[s_,t]$(tEndo[t]) "Andelen af branchen som er danskejet"
  	sEquityDKownedEndo[t]$(t0[t])
	;


$IMPORT create_baseline_values.gms;


  $BLOCK B_Last_Calib

  	E_sEquityDKownedEndo[t]$(tx0[t])..  sEquityDKownedEndo[t] =E= (sDomesticEquity[t]*vWealth[t-1]/fv-sum(s_DK,sEquityDKownedExo[s_DK,t]*vEquity_baseline[s_DK,t])) / (sum(sp,vEquity_baseline[sp,t])-sum(s_DK,sEquityDKownedExo[s_DK,t]*vEquity_baseline[s_DK,t]));

  		E_vWealth_shockCorrection1[t]$(tx0[t])..    vWealth_shockCorrection[t] =E=  0;

  $ENDBLOCK

sEquityDKownedExo.l[s_DK,t]$(tEndo[t]) = 1;


#Setting up model
$MODEL M_dynamic_calibration_last
	M_dynamic_calibration_KF
	B_Last_Calib
;


$GROUP G_dynamic_calibration_endo 
	G_dynamic_calibration_endo
	G_Last_Calib_Endo
;

$GROUP G_dynamic_calibration_exo 
	G_dynamic_calibration_exo 
	G_Last_calib_Exo
	vEquity_baseline
;

# Højere installationsomkostninger for at ramme MAKROs kortsigtsdynamik
		#  uKInstCost.l['IB',sp,t]$(NOT sLan_sp[sp]) = 20;
		#  uKInstCost.l['IM',sp,t]$(NOT sLan_sp[sp]) = 5;



#Solve model
$FIX G_dynamic_calibration_exo;
$UNFIX G_dynamic_calibration_endo;

@SOLVE(M_dynamic_calibration_last);


	 	#Checks 
	 	$import sanitycheck.gms
		execute_unload 'output\dynamic_calibration_last.gdx'; 
		@assert_no_difference(G_data,%tolerance_data%); 
		$import check_DS.gms