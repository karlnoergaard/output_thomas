

# ======================================================================================================================
# //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#                                                  LEAKAGE module
# //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
# ======================================================================================================================


# ======================================================================================================================
# Variable definition
# ======================================================================================================================


$IF %stage% == "variables":

sets d1import_save[s,t], d1export_save[s,t];

d1import_save[s,t] = 1;
d1export_save[s,t] = 1;

parameters L_ETS_EU, L_ETS_DK;

L_ETS_EU           = 0.13;
L_ETS_DK           = 0.20;

parameter d1_s_leakage[s];
d1_s_leakage[s]    = 0;

$GROUP G_leakage_other_exo
    qM_CET$(tx0[t] and d1vM_CET[out,s,t])
    pM_CET$(tx0[t] and d1vM_CET[out,s,t])
    vX_y[x,s,t]$(tx0[t] and sameas(x,'xoth'))
    qEmmProdE[s,t,emm_eq, purpose, energy19]$(tx0[t] and d1EmmProdE[s,t,emm_eq,purpose, energy19] and sameas(emm_eq,'CO2e') and sameas(purpose,'in_ETS'))
    qEmmTot[t,emm_eq,accounts_all]$(tx0[t] and d1EmmTot[t,emm_eq,accounts_all] and sameas(emm_eq,'CO2e') and sameas(accounts_all,'UNFCCC'))
    qEmmProdS[s,t,emm_eq,accounts]$(tx0[t] and d1EmmProdS[s,t,emm_eq,accounts] and sameas(emm_eq,'CO2e') and sameas(accounts,'UNFCCC'))
;

$GROUP G_leakage_calib_endo
  import_save[s,t]$(tx0[t])                                   "Baseline imports"
  export_save[s,t]$(tx0[t])                                   "Baseline exports"
  qETSEmm_save[s,t]$(tx0[t])                                  "Baseline ETS emissions"
  qEmmTot_save[t]$(tx0[t])                                    "Baseline total emissions"
  qEmmProdS_save[s,t]$(tx0[t])                                "Baseline sector emissions"
;

$GROUP G_leakage_calib_exo
  G_leakage_other_exo
  leakage[s_,t, leak_cat]$(tx0[t] and not (sameas(s_,'rTot') or sameas(s_,'tot') or sameas[leak_cat,'tot']))  "Leakage"
  qEmmTot_change[t]$(tx0[t])                                  "Change in total emissions from shock"
  qEmmProdS_change[s,t]$(tx0[t])                              "Change in sector emissions from shock"
  leak_coef[s,t,impexp]$(tx0[t])                              "Leakage coefficient"
;

$GROUP G_leakage_shock_endo
  leakage[s_,t, leak_cat]$(tx0[t] and not sameas(s_,'rTot'))  "Leakage"
  leakage_rate[s_,t]$(tx0[t] and not sameas(s_,'rTot') and qEmmTot_change.l[t])       "Leakage rate"
  qEmmTot_change[t]$(tx0[t])                                  "Change in total emissions from shock"
  qEmmProdS_change[s,t]$(tx0[t])                              "Change in sector emissions from shock"
;

$GROUP G_leakage_shock_exo
  G_leakage_other_exo
  qETSEmm_save[s,t]$(tx0[t])                                  "Baseline ETS emissions"
  import_save[s,t]$(tx0[t])                                   "Baseline imports"
  export_save[s,t]$(tx0[t])                                   "Baseline exports"
  qEmmProdS_save[s,t]$(tx0[t])                                "Baseline sector emissions"
  qEmmTot_save[t]$(tx0[t])                                    "Baseline total emissions"
  leak_coef[s,t,impexp]$(tx0[t])                              "Leakage coefficient"
;

$ENDIF

$IF %stage% == "groupcompilation":

  #  $GROUP G_leakage_endo
  #    G_leakage_endo_group
  #  ;

  #  $GROUP G_leakage_exo
  #    G_leakage_exo_group
  #  ;

$ENDIF


# ====================================================================================================================
# Equations
# ====================================================================================================================

$IF %stage% == "equations":

  $BLOCK B_leakage

    E_leakage_import[s,t]$(tx0[t]).. leakage[s,t, 'import'] =E= leak_coef[s,t,'import'] * (sum(out$d1vM_CET[out,s,t], pM_CET[out,s,t] * qM_CET[out,s,t]) - import_save[s,t]);
    E_leakage_import_tot[t]$(tx0[t]).. leakage['tot',t, 'import'] =E= sum(s, leakage[s,t, 'import']);

    E_leakage_export[s,t]$(tx0[t]).. leakage[s,t, 'export'] =E= leak_coef[s,t,'export'] * (vX_y['xoth',s,t] - export_save[s,t]);
    E_leakage_export_tot[t]$(tx0[t]).. leakage['tot',t, 'export'] =E= sum(s, leakage[s,t, 'export']);

    E_leakage_ets[s,t]$(tx0[t]).. leakage[s,t, 'ETS'] =E= 
        -(1-L_ETS_EU)*L_ETS_DK*(sum(energy19$(d1EmmProdE[s,t, 'CO2e', 'in_ETS', energy19]), qEmmProdE[s,t,'CO2e', 'in_ETS', energy19]) - qETSEmm_save[s,t]);
    E_leakage_ets_tot[t]$(tx0[t]).. leakage['tot',t, 'ets'] =E= sum(s, leakage[s,t, 'ets']);

    E_leakage_total[s,t]$(tx0[t]).. leakage[s,t, 'tot'] =E= leakage[s,t, 'import'] + leakage[s,t, 'export'] + leakage[s,t, 'ETS'];
    E_leakage_total_tot[t]$(tx0[t]).. leakage['tot',t, 'tot'] =E= sum(s, leakage[s,t, 'tot']);

    E_qEmmTot_change[t]$(tx0[t]).. qEmmTot_change[t] =E= qEmmTot[t,'CO2e','UNFCCC']-qEmmTot_save[t];
    E_qEmmProdS_change[s,t]$(tx0[t]).. qEmmProdS_change[s,t] =E= qEmmProdS[s,t,'CO2e','UNFCCC']-qEmmProdS_save[s,t];

    E_leakage_rate[s,t]$(tx0[t] and d1EmmProdS[s,t,'CO2e','UNFCCC'] and d1_s_leakage[s]).. leakage_rate[s,t] =E= -leakage[s,t,'tot']/(qEmmProdS[s,t,'CO2e','UNFCCC']-qEmmProdS_save[s,t]);
    E_leakage_rate_tot_ny[t]$(tx0[t] and d1EmmTot[t,'CO2e','UNFCCC'] and qEmmTot_change.l[t]).. leakage_rate['tot',t] =E= -leakage['tot',t, 'tot']/(qEmmTot[t,'CO2e','UNFCCC']-qEmmTot_save[t]);

  $ENDBLOCK


  $BLOCK B_leakage_calib
    B_leakage
    -E_leakage_import_tot
    -E_leakage_export_tot
    -E_leakage_ets_tot
    -E_leakage_total_tot
  
    -E_qEmmTot_change
    -E_leakage_rate
    -E_leakage_rate_tot_ny

  $ENDBLOCK


  #  $BLOCK B_leakage
  #    B_leakage

  #  $ENDBLOCK

$ENDIF


# ======================================================================================================================
# Exogenous variables
# ======================================================================================================================
$IF %stage% == "exogenous_values":

import_save.l[s,t] = sum(out$d1vM_CET[out,s,t], pM_CET.l[out,s,t] * qM_CET.l[out,s,t]);
export_save.l[s,t] = vX_y.l['xoth',s,t];

d1import_save[s,t] = yes$(import_save.l[s,t]);
d1export_save[s,t] = yes$(export_save.l[s,t]);

#  qETSEmm_save.l[s,t] = sum(energy19$(d1EmmProdE[s,t, 'CO2e', 'in_ETS', energy19]), qEmmProdE.l[s,t,'CO2e', 'in_ETS', energy19]);

leak_coef.l[s,t,impexp]   = leak_coef_in[impexp,s,t];
leak_coef.l[s,t,impexp]$(t.val>2030) = leak_coef_in[impexp,s,'2030'];

leakage.l[s_,t, leak_cat] = 0;
qEmmTot_change.l[t]       = 0;
qEmmProdS_change.l[s,t]   = 0;


$ENDIF

  
# ======================================================================================================================
# Static calibration
# ======================================================================================================================
$IF %stage% == "static_calibration":

  
  $GROUP G_leakage_static_calibration
    G_leakage_calib_endo
  ;

  $GROUP G_leakage_static_calibration_exo
    G_leakage_calib_exo
  ;
  
  $MODEL M_leakage_static_calibration
    B_leakage
    -E_leakage_import_tot
    -E_leakage_export_tot
    -E_leakage_ets_tot
    -E_leakage_total_tot
  
    -E_qEmmTot_change
    -E_leakage_rate
    -E_leakage_rate_tot_ny
  ;

$ENDIF

# ======================================================================================================================
# Dynamic calibration
# ======================================================================================================================
$IF %stage% == "dynamic_calibration":

#  


  $GROUP G_leakage_calib
    G_leakage_calib_endo
  ;

  $GROUP G_leakage_calib_exo
    G_leakage_calib_exo
  ;

  $MODEL M_leakage_calib
    B_leakage
    -E_leakage_import_tot
    -E_leakage_export_tot
    -E_leakage_ets_tot
    -E_leakage_total_tot
  
    -E_qEmmTot_change
    -E_leakage_rate
    -E_leakage_rate_tot_ny
  ;

$ENDIF
