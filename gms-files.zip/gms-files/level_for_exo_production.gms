
#  Her sættes de eksogene cementproduktioner til et nyt eksogent niveau
qRxE_y.l[r,s,t] $(t.val ge 2025 and sameas[s,'23001'] and d1RxE_y[r,'23001',t] and d1RxE_m[r,'23001',t]) = cement_prod[t]*qRxE_y.l[r,s,t];
qX_y.l[x,s,t]$(t.val ge 2025 and sameas[x,'xOth'] and sameas[s,'23001']) = cement_prod[t]*qX_y.l[x,s,t];
qC_y.l[c,s,t]$(t.val ge 2025 and sameas[c,'cHou'] and sameas[s,'23001']) = cement_prod[t]*qC_y.l[c,s,t];

#  Her sættes produktionen af raffinaderiprodukter til et nyt eksogent niveau
qY_CET.l[out,s,t]$(t.val ge 2025 and d1ExoProdRaffi[out,s]) = qY_CET.l[out,s,t] * raffi_prod[t];

#  Her sættes forbruget af brændstof i fiskeriet til et nyt eksogent niveau
qREa.l['process_special','Diesel for transport','03000',t]$(t.val ge 2025) = qREa.l['process_special','Diesel for transport','03000',t] * fisk_prod[t];
#  Her hæves prisaggregatet for kapital-energi som følge af grænsehandlen
pProd.l['MKE','03000',t]$(t.val ge 2025) = pMKE_pre['03000',t] + (1-qREa.l['process_special','Diesel for transport','03000',t]/qREa_pre['process_special','Diesel for transport','03000',t])*0.1*pMKE_pre['03000',t];
