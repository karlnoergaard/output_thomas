

loop_CCS['%indsaet%','rCCS_diff',techCCS,s,purpose,energy19,t]$(abs(rCCS.l[techCCS,s,purpose,energy19,t] - rCCS_last[techCCS,s,purpose,energy19,t]) > 0.01) = rCCS.l[techCCS,s,purpose,energy19,t] - rCCS_last[techCCS,s,purpose,energy19,t];
loop_CCS2['%indsaet%','qEmmCCS',s,t] = sumqEmmCCSubio.l[s,t] + sumqEmmCCSbio.l[s,t] - qEmmCCS_last[s,t];


rCCS_last[techCCS,s,purpose,energy19,t] = rCCS.l[techCCS,s,purpose,energy19,t];
qEmmCCS_last[s,t] = sumqEmmCCSubio.l[s,t] + sumqEmmCCSbio.l[s,t];