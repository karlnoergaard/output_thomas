

# ======================================================================================================================
# //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#                                    LULUCF module - land stocks and flows and emissions
# //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
# ======================================================================================================================

#  This module describes land use, land use changes as well as emissions from LULUCF.

#  A note about the forestry model:
#  Survival rates and age classes enter the model as five-year parameters.
#  This means that if we wish to add 200 ha land in year t, we should in fact add 200 ha land in year t,t+1,t+2,t+3,t+4. 

# ======================================================================================================================
# Variable definition
# ======================================================================================================================


$IF %stage% == "variables":

  $GROUP G_luluc_endo
    # LAND-TRANSITION
      qLU5[land5,t]$(tLULUC[t])                                               "Land stock by land category, 1.000 hectares"
      qLUC5[land5_s,land5_r,t]$(tLULUC[t] and d1qLUC5[land5_s,land5_r,t])     "Land converted from land5 to land55, 1.000 hectares"

      qLU12[land12,t]$(tLULUC[t] and d1qLU12[land12,t])                       "Land stock by land category, 1.000 hectares"    
      
    # LU-EMISSIONS 
      qEmmLU[t]$(tLULUC[t])                                                   "Total Emissions from LU"
      qEmmLU5xF[land5xF,t]$(tLULUC[t] and d1LU_agg[land5xF,t])                "Emissions from Land use by land use category "
      qEmmLU12xF[land12xF,t]$(tLULUC[t] and d1qEmmLU12xF[land12xF,t])         "Emissions from Land use by Land use category"
      qEmmLUC12[land12,t]$(tLULUC[t])                                         "Emissions from LUC by land use cateogry"

    # LUC-EMISSIONS
      qEmmLUC5[land5,t]$(tLULUC[t])                       "Emissions from LUC by land use category"
      qEmmLUC12_BiomassStock[land12_r,t]                  "Change in biomass stock from changes in land category, ktCO2e"
      qEmmLUC12_OxiLuc[land12_r,t]                        "Oxidation of N from deforestation, measured in ktCO2e"  
      qEmmLUC12_SoilStock[land12_r,t]                     "Emissions from LUC - soil stock"
      qEmmLUC12_inflows[land12_r,land12_s,t]              "Emissions from LUC - inflows input-output"
      qEmmLUC12_outflows[land12_r,land12_s,t]             "Emissions from LUC - outflows input-output"
      qEmmLUC12_netflows[land12_r,land12_s,t]             "Emissions from LUC - netflows input-output"
      jqEmmLUC12_j0check                                  "Sum of Adjustment term 'jqEmmLUC12_check'"

    # AGGREGATES
      qEmmLUC[t]$(tLULUC[t])                              "Total emissions from LUC"
      qEmmLULUCF5[land5,t]$((tLULUC[t] and land5xF[land5]) or (tF[t] and sameas[land5,'forest'])) "Emissions from LULUCF by land use category"
     
      qEmmTable4ii_wetland[t]                              "Table 4II of the NIR's Wetland emissions. These consists of Methane emissions from re-wetted wetlands and exogenous peatland emissions, measured in ktCO2e"
      qEmmLULUCF[t]$(tLULUC[t])                            "Total LULUCF emissions"


  ;

  $GROUP G_luluc_exo
    
    # LAND-TRANSITION
      qLUC8[land8_s,land8_r,t]                                         "Land-change matrix on land8-resolution, measured in 1000 ha."
      qLU8[land8,t]                                                    "Land-use matrix on land8-resolution, measured in 1000 ha."
      qLU12[land12,t]$(tLULUCstart[t+1] and d1qLU12[land12,t])         "Land-use matrix on land12-resolution, measured in 1000 ha."
      qLUC12[land12_s,land12_r,t]                                      "Land stock by land category, 1.000 hectares"
      jLUC12[land12_s,land12_r,t]                                      "Adjustment term"
      qLUC12_baseline[land12_s,land12_r,t]$(not sameas[land12_s,land12_r] and d1qLUC12[land12_s,land12_r,t]) "Land converted from land12 til land129 in baseline"
      qLU12[land12,t]$(tLULUC[t] and d1qLU12[land12,t])                "Land stock by land category, 1.000 hectares"    

    # LU-EMISSIONS
      uLU12xF[land12xF,t]$(d1qEmmLU12xF[land12xF,t])   "Land use emissions coefficient, the emission-coefficient on organic soils GL/CL is endogenous as emissions here are calculated on a lower level"
      qEmmPeatland[emm,t] "Peat-land emissions. Exogenous in forecast - taken from KF22"
      qEmmHedgeRows[land12,t] "Kt CO2e, Emmisions and uptake of hedgerows, fruits and berries, etc."
      qEmmTable4iii_settlement[t]                          "Table 4III for settlements"
  
    # LUC-EMISSIONS
      qEmmLUC5[land5,t]$(tF[t] and not tLULUC[t] and sameas[land5,'forest'])                 "Emissions from LUC by land use category"
     
      uEmmInstantOxiLUCinF[land12_s,land12_r]$(d1uEmmInstantOxiLUCinF[land12_s,land12_r])    "Emission-coefficient for instant oxidization from deforestation"
      qBiomassStock9[land12]                                                                 "Carbon in biomass by land type"
      qSoilStock9[land12]                                                                    "Carbon in steady state soils by land type"
      uSoilStock12[tt,t,land12]$(tLULUC[t])                                                             "Adjustment parameter - controls rate of adjustment in soil stock (30/100 years)"
      uBiomass12[tt,t,land12]$(tLULUC[t])                                                                "Adjustment parameter - controls rate of adjustment in biomass when land is converted to forests"
      uDM2C[land12_r]                                                                        "Carbon per DM"
      uLUConv12xF[land12xF_a,land12xF]$(d1uLUConv12xF[land12xF_a,land12xF])                  "Extra LU emissions from conversions (used to account for OC>12 converted to wetlands"
      uLU12_LUC12[land12_r,t]$(tLULUC[t] and d1qLU12[land12_r,t])                            "Calibration parameter to absorb difference betwen LU and LUC in data years"
      jqEmmLUC12_check[land12_r,t]$(tLULUC[t])                                               "Adjustment term when checking for decomposition of LUC emissions is done right"

    # AGGREGATES
      jEmmLULUCF[land5,t]                                                                    "Adjustment term to ensure that we hit data years and energy outlook years"
      qEmmF_soil[t]$(tF[t] or tLULUC[t])                                                     "Emissions from forest soil, cf. DNFAP p. 48"  

      uEmmtable4ii[land5,t]$((tF[t] or tLULUC[t]) and d1qEmmtable4ii[land5,t])               "Emission coefficients for table 4ii-emissions"
      qEmmtable4ii[land5,t]$(d1qEmmtable4ii[land5,t])                                        "Emissions neither LU nor LUC but recorded in CRF table 4II (Emissions and removals from drainage and rewetting and other management of organic and mineral soils)"

      qEmmLULUCF5[land5,t]                                                                   "Emissions from LULUCF by land use category"
      qEmmLULUCF[t]                                                                          "Total LULUCF emissions"
      
      vV3[t]$(tF0[t])                                                                        "Value of forest at current prices."
      qEmmPyrolyse_tot[t]$(tx0[t] and sum(PyrolyseTech, d1PyrolysePot[PyrolyseTech,t]))       ""
  ;


  $GROUP G_f_endo
     #This one is not endogenous - group-compilation stage is still lacking for forests
     pSurvival_AFF[skmodel,joe07,spec_type,acl] "Conditional survival probability of afforestation"

    #FOREST-REMAINING-FORESTES
    
     qEmmFstock_FRF[joe07,spec_type,acl,t]$(tF[t])                                            "Forest-remaining-forest carbon stock measured in ktCO2e"
     qC5_FRF[joe07,spec_type,acl,t]$(tF[t])                                                   "Forest-remaining-forest carbon stock measured in ktC"
   
     qF5_FRF[joe07,spec_type,acl,t]$(tF[t] and acl_spec_type[acl,spec_type])                  "Forest area measured in hectares - five year increments"
     qF5_FRF_regenerated[joe07,spec_type,t]$(tF[t])                                           "Dead-end report variable measuring number of renewed kha in Forest-remaining-forest"
     qF5_FRF_fromAFF[joe07,spec_type,acl,t]$(tF[t]) ""

     qC5_hoved_FRF[joe07,spec_type,acl,t]$(tF[t])                                             "Flow of carbon from hovedskovning of the forest - note that this produces a 5-year flow. In contrast to thinning variable"
     qHV2_hoved_FRF[joe07,spec_type,acl,t]$(tF[t])                                            "Volume of wood from main-logging (hovedskovning), measured in kilo-cubic-tres"
     qHV2_hoved_FRF_fromAFF[joe07,spec_type,acl,t]$(tF[t] and sum(skmodel,d1qF5_aff[skmodel,joe07,spec_type,acl,t])) ""
     qV2_tynd_FRF[joe07,spec_type,acl,t]$(tF[t])                                              "Volume of wood from thinning (tynding), measured in kilo-cubic-metres"
     qV2_tynd_FRF_fromAFF[joe07,spec_type,acl,t]$(tF[t] and sum(skmodel,d1qF5_aff[skmodel,joe07,spec_type,acl,t])) ""
     qC5_tynd_FRF[joe07,spec_type,acl,t]$(tF[t])                                              "Flow of carbon from thinning of the forest - note that this is per year variable. So to arrive at a five-year total we multiply by 5"
     qC5_usestock_FRF[enduse_wood,spec_type,t]$(tF[t])                                        "Carbon stock of harwested wood, measured in kilo tonnes of C"
     qC5_usestock_FRF_depreciation[enduse_wood,spec_type,t]$(tF[t])                           "Carbon stock of harwested wood - Outflow from depreciation,  measured in kilo tonnes of C"
     qC5_usestock_FRF_HTynd[enduse_wood,spec_type,t]$(tF[t])                                  "Carbon stock of harwested wood - inflow from hovedskovning, measured in kilo tonnes of C"
     qC5_usestock_FRF_Tynd[enduse_wood,spec_type,t]$(tF[t])                                   "Carbon stock of harwested wood - inflow fra thinning, kilo tonnes of C"
     qC5_usestock_FRF_tot[t]                                                                  "Total usestock from FRF, kilo tonnes of C"

     qC5_GrossHarvest_FRF[t]                                                                  "Annual carbon in gross harvest. From Forest-remaining-forest"
     qC5_Energy_FRF[t]                                                                        "Annual carbon to energy, including waste in saw-mills assuming all non-utilized carbon is used as energy. From Forest-remaining-forest"
     qC5_Energy_FRF_xMill[t]                                                                  "Annual carbon to energy, excluding waste in saw-mills from Forest-remaining-forest"
     qC5_Energy_FRF_Mill[t]                                                                   "Annual carbon to energy, from saw-mills from Forest-remaining-forest, assuming all non-utilized carbon is used as energy."     
     qC5_Energy_FRF_fromAFF_xMill[joe07,spec_type,acl,t]$(tF[t] and sum(skmodel,d1qF5_aff[skmodel,joe07,spec_type,acl,t])) ""                                           
     qC5_Use_FRF[t]                                                                           "Annual carbon to use-stock, excluding any depreciations of stock. From Forest-remaining-forest"
     qC5_Loss_FRF[t]                                                                          "Annual loss of carbon from gross harvest stock. From Forest-remaining-forest"
     adjloss_C5_FRF[t]                                                                        ""


     vHV2_hoved_FRF[joe07,spec_type,acl,t]$(tF[t])                                            "Value of of harvested wood products from main logging of FRF, bio. DKR."
     vV2_tynd_FRF[joe07,spec_type,acl,t]$(tF[t])                                              "Value of of harvested wood products from thinning of FRF, bio. DKR."

     vHV2_hoved_FRF_tot[t]$(tF[t])                                                            "Total value of harvested wood products from main logging of FRF, bio. DKR."
     vV2_tynd_FRF_tot[t]$(tF[t])                                                              "Total value of harvested wood products from thinning of FRF. bio. DKR." 
     vV2_FRF[t]$(tF[t])                                                                       "Total value of harvested wood products from FRF, bio. DKR"


    #NATURAL RESERVES
     qEmmFstock_NRE[joe07,spec_type,acl,t]$(tF[t])                                            "Stock of carbon in natural-reserves, measured in kt. CO2e"
     qEmmFstock_LYS[joe07,spec_type,acl,t]$(tF[t])                                            "Stock of carbon in natural-reserves, measured in kt. CO2e"

     qF5_FRF_NST[joe07,spec_type,acl,t]$(tF[t] and d1qF5_FRF_NST[joe07,spec_type,acl,t])      "Forest area belonging to the Danish Nature Agency (Naturstyrelsen), kha. forest"
     qF5_NRE[joe07,spec_type,acl,t]$(tF[t] and acl_xinit_NRE[acl,spec_type] and d1qF5_NRE[joe07,spec_type,acl,t]) "Forest area measured in hectares - five year increments, kha. forest"
     qF5_LYS[joe07,spec_type,acl,t]$(tF[t])                                                   "Lysåbne arealer i Naturreservater, kha. forest"

     qC5_hoved_NRE[joe07,spec_type,acl,t]                                                     "Flow of carbon (ktC) from main-logging of Nature-reserves. This is a five-year total"
     qC5_tynd_NRE[joe07,spec_type,acl,t]                                                      "Flow of carbon (ktC) from thinning of the forest - note that this is per year variable. So to arrive at a five-year total we multiply by 5"
     qC5_tynd_LYS[joe07,spec_type,acl,t]                                                      "Flow of carbon (ktC) from thinning of the forest - note that this is per year variable. So to arrive at a five-year total we multiply by 5"
   
     qHV2_hoved_NRE[joe07,spec_type,acl,t]$(tF[t])                                            "Volume of wood from main-logging of Nature-reserves. Five year total. Kilo-cubic-metres"
     qV2_tynd_NRE[joe07,spec_type,acl,t]$(tF[t])                                              "Volume of wood from thinning of Nature-reserves. Yearly-thinning. Kilo-cubic-metres"
     qC5_usestock_NRE[enduse_wood,spec_type,t]$(tF[t])                                        "Flow of carbon (ktC) to use-stock from Nature-reserves. Five year total."
     qC5_usestock_NRE_tot[t]                                                                  "Total usestock (ktC) from Nature-reserves"                                           
     qC5_usestock_LYS_tot[t]                                                                  "Total usestock (ktC) from Light and open areas (lys åbne områder)"

     qFflow_hoved_NRE[joe07,spec_type,acl,t]                                                  "Flow of carbon from hovedskovning of the forest - note that this produces a 5-year flow. In contrast to thinning variable"
     qFflow_hoved_LYS[joe07,spec_type,acl,t]                                                  "Flow of carbon from hovedskovning of the forest - note that this produces a 5-year flow. In contrast to thinning variable"

     qC5_GrossHarvest_NRE[t]                                                                  "Annual carbon in gross harvest form Natural Reserves"
     qC5_Energy_NRE[t]                                                                        "Annual carbon to energy, including waste in saw-mills assuming all non-utilized carbon is used as energy from Natural reserves"
     qC5_Energy_NRE_xMill[t]                                                                  "Annual carbon to energy, excluding waste in saw-mills from Natureal Reserves"
     qC5_Energy_NRE_Mill[t]                                                                   "Annual carbon to energy, from saw-mills from Natural Reserves, assuming all non-utilized carbon is used as energy."  
     qC5_Use_NRE[t]                                                                           "Annual carbon to use-stock, excluding any depreciations of stock. From Natural Reserves"
     qC5_Loss_NRE[t]                                                                          "Annual loss of carbon from gross harvest stock. From Natural Reserves"
     sHTynd_NRE[ite,joe07,spec_type,acl,tynd]                                                 "Share of main harvest that goes to either fuel-production, tree for use, or simply loss"
     adjloss_C5_NRE[t]$(sum(joe07, sum(spec_type, sum(acl,  d1qF5_NRE[joe07,spec_type,acl,t] and sum(ite, sHTynd_NRE.l[ite,joe07,spec_type,acl,'tynd_loss'] and ite2t[ite,t])))))       "Adjustment parameter" 

     vHV2_hoved_NRE[joe07,spec_type,acl,t]$(tF[t])                                            "Value of kilo cubic meter of harvested wood products from main logging of NRE"
     vV2_tynd_NRE[joe07,spec_type,acl,t]$(tF[t])                                              "Value of kilo cubic meter of harvested wood products from thinning of NRE"

     vHV2_hoved_NRE_tot[t]$(tF[t])                                                            "Total value of harvested wood products from main logging of NRE"
     vV2_tynd_NRE_tot[t]$(tF[t])                                                              "Total value of harvested wood products from thinning of NRE" 
     vV2_NRE[t]$(tF[t])                                                                       "Total value of harvested wood products from NRE"


    #AFFORESTATION
     qEmmFstock_AFF[skmodel,joe07,spec_type,acl,t]                                            "Disaggregated carbon stock in afforestation, measured in tonnes CO2e per hectare"
     
     qF5_aff[skmodel,joe07,spec_type,acl,t]$(tF[t] and acl_xinit[acl,spec_type])              "Area of afforestation, disaggregated. Measured in kilo hectares"
     qF5_aff_denom[skmodel,joe07,spec_type,acl,t]$(tF[t])                                     "Area of afforestation, tracking all areas including those transitioning to FRF, disaggregated, measured in kilo hectares"
     qC5_AFF[skmodel,joe07,spec_type,acl,t]$(tF[t])                                           "Carbon stock in afforestation, disaggregated, measured in tonnes C per hectare"

     qHV2_hoved_AFF[skmodel,joe07,spec_type,acl,t]$(tF[t])                                    "Volume of main-logging in afforestation, disaggregated, measured in kilo cubic meters (Volumen hovedskovning i skovrejsning)"
     qV2_tynd_AFF[skmodel,joe07,spec_type,acl,t]$(tF[t])                                      "Volume of thinning in afforestation, disaggregated, measured in kilo cubic meters (Volumen af tynding i skovrejsning)"
     qC5_usestock_AFF[enduse_wood,spec_type,t]$(tF[t])                                        "Carbon stock of harwested wood from afforestation, meausred in kilo tonnes C"
   
     qC5_hoved_AFF[skmodel,joe07,spec_type,acl,t]                                             "Flow of carbon from main logging on afforested areas, kilo tonnes C"
     qC5_tynd_AFF[skmodel,joe07,spec_type,acl,t]                                              "Flow of carbon from thinning on afforested areas, kilo hectares forest"

     qFflow_hoved_AFF[skmodel,joe07,spec_type,acl,t]                                          "Flow of carbon from thinning of the forest, kilo tonnes C"
     qC5_usestock_AFF_tot[t]                                                                  "Total usestock from AFF, kilo tonnes C"

     qC5_GrossHarvest_AFF[t]                                          "Annual carbon in gross harvest. From afforestation after last data-year, kilo tonnes C"
     qC5_Energy_AFF[t]                                                "Annual carbon to energy, including waste in saw-mills assuming all non-utilized carbon is used as energy. From afforestation after last data-year, kilo tonnes C"
     qC5_Energy_AFF_xMill[t]$(tF[t] and sum(skmodel,sum(joe07,sum(spec_type,sum(acl, d1qF5_aff[skmodel,joe07,spec_type,acl,t]))))) "Annual carbon to energy, excluding waste in saw-mills from afforestation, kilo tonnes C"
     qV2_Energy_Aff_xMill[t]                                          "Total volume of energy-wood from afforestation, excluding the wood waste from saw mills, measured in kilo cubic meters"
     qV2_Energy_AFF_xMill_FullDim[skmodel,joe07,spec_type,acl,t]      "Disaggregated volume of energy-wood, excluding that from the saw-mill, kilo cubic meters"
     qC5_Energy_AFF_xMill_full[skmodel,joe07,spec_type,acl,t]         "Carbon in energy-wood from afforestation, excluding wood waste in saw mill, measured in kilo tonnes C"
     

     qC5_Energy_AFF_Mill[t]                                           "Annual carbon to energy, from saw-mills from afforestation, assuming all non-utilized carbon is used as energy."  
     qC5_Use_AFF[t]                                                   "Annual carbon to use-stock, excluding any depreciations of stock. From afforestation after last data-year"
     qC5_Loss_AFF[t]                                                  "Annual loss of carbon from gross harvest stock. From afforestation after last data-year"
     sHTynd_AFF[skmodel,joe07,spec_type,acl,tynd]                     "Share of main harvest that goes to either fuel-production, tree for use, or simply loss"  
     adjloss_C5_AFF[t]$(sum(skmodel, sum(joe07, sum(spec_type, sum(acl, d1qF5_aff[skmodel,joe07,spec_type,acl,t] and sHTynd_AFF.l[skmodel,joe07,spec_type,acl,'tynd_loss'])))))       ""


     vHV2_hoved_AFF[skmodel,joe07,spec_type,acl,t]$(tF[t])            "Value of harvested wood products from main logging from afforestation"
     vV2_tynd_AFF[skmodel,joe07,spec_type,acl,t]$(tF[t])              "Value of harvested wood products from thinning of from afforestation"

     qV2_tynd_AFF_firstgen[skmodel,joe07,spec_type,acl,t]             "Volume of thinned harvested wood from the first generation of afforestation in the model (generation 2021-2025), kilo cubic meters"
     qHV2_hoved_AFF_firstgen[skmodel,joe07,spec_type,acl,t]           "Volume of main-logged harvested wood from the first generation of afforestation in the model (generation 2021-2025), kilo cubic meters"

     vHV2_hoved_AFF_tot[t]$(tF[t])                                     "Total value of harvested wood products from main logging from afforestation, kilo cubic meters"
     vV2_tynd_AFF_tot[t]$(tF[t])                                       "Total value of harvested wood products from thinning from afforestation, kilo cubic meters" 
     vV2_AFF[t]$(tF[t])                                                "Total value of harvested wood products from afforestation, kilo cubic meters"
  
    #AGGREGATES
      qF5_tot[t]                                                        "Total forest area, kilo hectares"
      qEmmF[t]$(tF[t])                                                  "Total emissions from carbon stock in forests (ex HWP), kilo tonnes CO2e"
      qEmmHWP[t]$(tF[t])                                                "Emissions from harvested wood products, kilo tonnes CO2e"
      qEmmFStock[t]$(tF[t])                                             "Stock of carbon in the forest, measured i kilo tonnes CO2e"

      qC5_harvest[t]$(tF[t])                                            "Total carbon in harvest, kilo tonnes C"
      qC5_Use[t]$(tF[t])                                                "Total carbon in use wood, kilo tonnes C"
      qC5_energy[t]$(tF[t])                                             "Total carbon in energy-wood, kilo tonnes C"
      qC5_loss[t]$(tF[t])                                               "Total carbon lost in harvest, kilo tonnes C"    
      
      qEmmFstock_FRF_tot[t]                                             "Total CO2e stock in FRF-forest, kilo tonnes CO2e"
      qEmmFstock_NRE_tot[t]                                             "Total CO2e stock in NRE-forest, kilo tonnes CO2e"
      qEmmFstock_AFF_tot[t]                                             "Total CO2e stock in AFF-forest, kilo tonnes CO2e"
      qEmmFstock_LYS_tot[t]                                             "Total CO2e stock in LYS-forest, kilo tonnes CO2e"

      qC5_usestock_FRF_flow[t]                                          "Total carbon in use-wood from FRF-logging, kilo tonnes C"
      qC5_usestock_NRE_flow[t]                                          "Total carbon in use-wood from NRE-logging, kilo tonnes C"
      qC5_usestock_LYS_flow[t]                                          "Total carbon in use-wood from LYS-logging, kilo tonnes C"
      qC5_usestock_AFF_flow[t]                                          "Total carbon in use-wood from AFF-logging, kilo tonnes C"


      qC5_usestock_tot[t]                                              "Total carbon in use-wood from all forest-types, kilo tonnes C"
      qC5_usestock_inflow[enduse_wood,t]                               "Total inflow to HWP carbon stock, kilo tonnes C"
      qC5_usestock_outflow[enduse_wood,t]                              "Total outflow from HWP carbon stock, kilo tonnes C"
    
      qF5_FRF_tot[t]                                                   "Total area of FRF-forest, kilo hectares"
      qF5_NRE_tot[t]                                                   "Total area of NRE-forest, kilo hectares"
      qF5_LYS_tot[t]                                                   "Total area of LYS-forest, kilo hectares"
      qF5_AFF_tot[t]                                                   "Total area of AFF-forest, kilo hectares"
   
      vV2[t]$(tF[t])                                                   "Total value of main-logging and thinning, bio. kr. growth-and inf.-adjusted"
      qV2[t]$(tF[t])                                                   "Total volume of main-logging and thinning, kilo cubic meteres"
      qPJ_energyXmill[t]$(tF[t])                                       "Total amount of energy in energy-wood (excluding energy wood from wood-waste at saw mills), peta-Joules"
      qV2_spectype[spec_type,t]                                        "Total volume of main-logging and thinning, split by tree species, kilo cubic meters"
      vV2_spectype[spec_type,t]                                        "Total value of main-logging and thinning split by tree species, bio. kr. growth- and inf.-adjusted"

      vV3[t]$(tF[t])                                                   "Value of standing wood stock at current prices, bio. kr. growth- and infl.-adjusted"
  ;

  #We need a group-compilation stage. The adjustment factors that makes sure that total carbon in harvest is preserved, when IGN has made their funky HWP adjustments are exogenous. But were 
  #Added to endo-group to create them in order to condition on them for adjustment-factors for NRE and AFF (there are many zero-entries for these)
  #As a quick-fix to not having the group-compilation the variables are created in the endo-group and then removes here.
  $GROUP G_f_endo G_f_endo, -sHTynd_NRE, -sHTynd_AFF,-pSurvival_AFF;


  $GROUP G_f_exo 
    
    #FOREST-REMAINING-FOREST
      qF5_FRF[joe07,spec_type,acl,t]$(tFinit[t])          "See above in G_f_endo"
      jF5_FRF[joe07,spec_type,acl,t]$(tF[t])              "J-term used in trouble-shooting. Should be zero so we the model mimics projected areas from IGN"
      jF5_AFF[skmodel,joe07,spec_type,acl,t]$(tF[t] and acl_xinit[acl,spec_type] and d1qF5_aff[skmodel,joe07,spec_type,acl,t])      "J-term used in trouble-shooting. Should be zero so we the model mimics projected areas from IGN"
      qF5_FRF_fromAFF[joe07,spec_type,acl,t]$(tF[t])          "See above in G_f_endo" 

      pHV2_hoved_FRF[joe07,spec_type,acl,t]$(tF[t] or tF0[t]) "Price per kilo cubic meter of harvested wood products from main logging of FRF, bio. kr. per kilo cubic meter"
      pV2_tynd_FRF[joe07,spec_type,acl,t]$(tF[t] or tF0[t])   "Price per kilo cubic meter of harvested wood products from thinning of FRF, bio. kr. per kilo cubic meter"

      pHV2_hoved_AFF[skmodel,joe07,spec_type,acl,t]$((tF[t] and (d1qF5_aff[skmodel,joe07,spec_type,acl,t] or d1qF5_aff[skmodel,joe07,spec_type,acl,t+1])) or tF0[t]) "Price per kilo cubic meter of harvested wood products from main logging of AFF, bio. kr. per kilo cubic meter"
      pV2_tynd_AFF[skmodel,joe07,spec_type,acl,t]$((tF[t] and (d1qF5_aff[skmodel,joe07,spec_type,acl,t] or d1qF5_aff[skmodel,joe07,spec_type,acl,t+1])) or tF0[t])   "Price per kilo cubic meter of harvested wood products from thinning of AFF, bio. kr. per kilo cubic meter"
 
      pHV2_hoved_NRE[joe07,spec_type,acl,t]$((tF[t] and d1qF5_NRE[joe07,spec_type,acl,t]) or tF0[t]) "Price per cubic meter of harvested wood products from main logging of NRE, bio. kr. per kilo cubic meter"
      pV2_tynd_NRE[joe07,spec_type,acl,t]$((tF[t] and d1qF5_NRE[joe07,spec_type,acl,t]) or tF0[t])   "Price per cubic meter of harvested wood products from thinning of NRE, bio. kr. per kilo cubic meter"

 
      pHV2_hoved_AFF_data[skmodel,joe07,spec_type,acl,t]$(pHV2_hoved_AFF.l[skmodel,joe07,spec_type,acl,t]) "Price per kilo cubic meter of harvested wood products from main logging of AFF, bio. kr. per kilo cubic meter"
      pV2_tynd_AFF_data[skmodel,joe07,spec_type,acl,t]$(pV2_tynd_AFF.l[skmodel,joe07,spec_type,acl,t])     "Price per kilo cubic meter of harvested wood products from main logging of AFF, bio. kr. per kilo cubic meter"

    
      pSurvival[joe07, spec_type, acl]              "Survival probability of forest-remaining-forest"
      pSurvival_AFF[skmodel,joe07,spec_type,acl]    "Survival probability of afforestation"
      content_coefs[joe07, spec_type, acl]          "Carbon content in forest-remaining-forest, kilo tonnes C per kilo hectare"
      content_coefs_V3_FRF[joe07,spec_type,acl]     "Volume of wood in main-logging from FRF, kilo cubic meters per kilo hectare "
      Tynding_coefs[joe07,spec_type,acl]            "Carbon content in thinning of forest-remaining-forest, kilo tonnes C per kilo hectare"

      jC5_flow_hoved_FRF[joe07,spec_type,acl,t]     "J-term used in trouble-shooting. Should be zero so we the model mimics logging from IGN"
      jEmmFstock_FRF[joe07,spec_type,acl,t]         "J-term used in trouble-shooting. Should be zero so we the model mimics CO2e-stock from IGN"
      jC5_flow_tynd_FRF[joe07,spec_type,acl,t]      "J-term used in trouble-shooting. Should be zero so we the model mimics logging from IGN"

      
      qC5_usestock_FRF[enduse_wood,spec_type,t]$(tFinit[t]) "See above in G_f_endo"
      sTynd_FRF[ite,joe07,spec_type,acl,tynd]  "Share of thinning that goes to either fuel-production, tree for use, or simply loss"
      sHTynd_FRF[ite,joe07,spec_type,acl,tynd] "Share of main harvest that goes to either fuel-production, tree for use, or simply loss"
      sHTyndCorr_FRF[joe07,spec_type,acl]      "Correction factor that takes into account that the Carbon/HV factor used in HWP reporting differs from the one in output-tables"

      #Naturstyrelsens arealer 
      qF5_FRF_NST[joe07,spec_type,acl,t]$(tFinit[t]) "See above in G_f_endo"
      qC5_FRF_reduc_hugst_NST[joe07,spec_type,acl,t]$(d1qC5_FRF_reduc_hugst_NST[joe07,spec_type,acl,t]) "Reducered harvest in Nature Agencys forests, kt C reduced harvest on 51 200 ha (Reduceret hugst på Naturstyrelsens arealer)"
      qC5_FRF_reducNST[joe07,spec_type,acl,t]$(d1qC5_FRF_reducNST[joe07,spec_type,acl,t]) "Increased carbon uptake, as a result of reduced harvest in Nature Agency's forest, kt C (Yderligere optag på Naturestyrelsens arealer som følge af reduceret hugst)"
      
      
    #NATURAL RESERVES 
      qF5_LYS[joe07,spec_type,acl,t]$(tFinit[t])  "See above in G_f_endo"
      qF5_NRE_deforestation[joe07,spec_type,acl,t] "Deforestation of Natural Reserves. This particular deforestation transitions the forest from the NRE to LYS category"
      qF5_NRE[joe07,spec_type,acl,t]$(tFinit[t] or acl_init[acl] or not d1qF5_NRE[joe07,spec_type,acl,t])   "See above in G_f_endo"

      jC5_LYS[joe07,spec_type,acl,t] "J-term used in trouble-shooting. Should be zero so we the model mimics C-stock from IGN"
      jC5_NRE[joe07,spec_type,acl,t] "J-term used in trouble-shooting. Should be zero so we the model mimics C-stock from IGN"

      sTynd_NRE[ite,joe07,spec_type,acl,tynd]  "Share of thinning that goes to either fuel-production, tree for use, or simply loss"
      sHTynd_NRE[ite,joe07,spec_type,acl,tynd] "Share of main harvest that goes to either fuel-production, tree for use, or simply loss"
      sHTyndCorr_NRE[ite,joe07,spec_type,acl]   "Correction parameter"
      qC5_usestock_NRE$(tFinit[t])              "See G_f_endo above"
      content_coefs_V3_NRE[joe07,spec_type,acl] "Volumn content in NRE"

      adjloss_C5_NRE[t] "Adjustment parameter"

    #AFFORESTATION
      qF5_aff[skmodel,joe07,spec_type,acl,t]$(d1qF5_aff[skmodel,joe07,spec_type,acl,t] and acl_init[acl]) "See above in G_f_endo"
      qF5_aff_baseline[skmodel,joe07,spec_type,acl,t]$(d1qF5_aff[skmodel,joe07,spec_type,acl,t]) "Baseline level of afforestation, kilo hectares"    

      qC5_AFF[skmodel,joe07,spec_type,acl,t]$(d1qF5_aff[skmodel,joe07,spec_type,acl,t]) "See above in G_f_endo"
      jC5_flow_hoved_AFF[skmodel,joe07,spec_type,acl,t]$(d1qF5_aff[skmodel,joe07,spec_type,acl,t]) "J-term used in trouble-shooting. Should be zero so we the model mimics C-stock from IGN"
      jC5_flow_tynd_AFF[skmodel,joe07,spec_type,acl,t]$(d1qF5_aff[skmodel,joe07,spec_type,acl,t]) "J-term used in trouble-shooting. Should be zero so we the model mimics C-stock from IGN"
      jEmmFstock_AFF[skmodel,joe07,spec_type,acl,t]$(d1qF5_aff[skmodel,joe07,spec_type,acl,t]) "J-term used in trouble-shooting. Should be zero so we the model mimics CO2e-stock from IGN"
      
      #qC5_usestock_AFF[enduse_wood,spec_type,t]$(not sum((skmodel,acl),d1qF5_aff[skmodel,joe07,spec_type,acl,t-5]))
      sTynd_AFF[skmodel,joe07,spec_type,acl,tynd]   "Share of thinning that goes to either fuel-production, tree for use, or simply loss"
      sHTynd_AFF[skmodel,joe07,spec_type,acl,tynd]  "Share of main harvest that goes to either fuel-production, tree for use, or simply loss"
      sHtyndCorr_AFF[skmodel,joe07,spec_type,acl]   "Correction factor that takes into account that the Carbon/HV factor used in HWP reporting differs from the one in output-tables"
      qC5_usestock_AFF$(tFinit[t]) "See above in G_f_endo"
      qC5_Energy_AFF_xMill[t]$(tF[t] and not sum(skmodel,sum(joe07,sum(spec_type,sum(acl, d1qF5_aff[skmodel,joe07,spec_type,acl,t]))))) "See above in G_f_endo"

      carbon_content_aff[skmodel,joe07,spec_type,acl] "Carbon contents in afforestation, kilo tonnes C per kilo hectare"
      content_coefs_V3_AFF[skmodel,joe07,spec_type,acl] "Volume of wood in afforestation, kilo cubic meters per kilo hectare"
      Tynding_coefs_aff[skmodel,joe07,spec_type,acl] "Carbon content in thinning from afforestation"
    
      adj_loss_C5_AFF[t] "Adjustment parameter"
    #HWP
      sUtilization[enduse_wood,spec_type]              "Utilization rate for sawn wood and wood panels. The fraction is species dependant"
      sHCA2HV2[enduse_wood,spec_type]                  "Carbon per volume ratio in main harwest as in HWP-excel sheet. This rate differs from KF22-output tabels and together with the Corr-factors this ensure that we get same HWP as in KF"
      sCA2V2[spec_type]                                "Carbon per volume ration in thinning"
      sEnduse[enduse_wood]                             "Share of harwested wood that goes to either sawn wood or wood panels "
      depreciation_factor_usestock[enduse_wood]        "Depreciation of old HWP-stock from FRF"
      depreciation_factor_usestock_inflow[enduse_wood] "Depreciation of inflow to HWP-stock from FRF"
      
      adj_qC5_Fuserstoc_FRF[t]                         "Adjustment parameter"
      jEmmHWP[t]                                       "J-term used in trouble-shooting. Should be zero so we the model mimics HWP from IGN"

    #AGGREGATES 
      qEmmF[t]$(tLULUC[t] and not tF[t])                  "See G_f_endo above"
      qEmmFStock$(tFinit[t] or (tLULUC[t] and not tF[t])) "See G_f_endo above"
      qEmmFstock_FRF_tot[t]$(tLULUC[t] and not tF[t])     "See G_f_endo above"
      qEmmHWP[t]$(tLULUC[t] and not tF[t])                "See G_f_endo above" 
      qEmmForestsoil[t]                                   "Emissions from forest soil, kilo tonnes CO2e" 

      pY_CET_usewoodtot[t]                                "Price index of use-wood"
      pY_CET_usewoodtot_baseline[t]                       "Price index of use-wood, baseline"

  ;

  #LINKS 

  $GROUP G_lulucf_links 
    qY_CET_outother_02000_usewood[t]        "Chain-index of harvested use-wood, bio. kr."
    qY_CET_outother_02000_usewood_smooth[t] "Smoothed chain-index of harvested use-wood"
    pY_CET_outother_02000_usewood[t]        "Prices index of harvested use-wood"
    qY_CET_outother_02000_usewood_AFF[t]    "Chain-index of harvested use-wood from afforestation, bio. kr."
    qY_CET_outother_02000_usewood_AFF_smooth[t] "Smoothed chain-index of harvested use-wood from afforestation"
 
    qPJ_energyXmill_smooth[t]               "Total energy-wood form logging, excluding the energy from wood waste at saw-mills, measured in PJ"
    qC5_Energy_AFF_xMill_smooth[t]          "Total energy-wood from afforestation, excluding the wood waste at saw-mills, measured in kilo tonnes C"
    qD_usewood_CGE[t]                       "Total demand for use-wood from the CGE-sectors"

    sFireWood_AFF[t]                        "Adjustment parameter in production.gms, ensures low-logging costs when afforestation is harvested"
    sUseWood_AFF[t]                         "Adjustment parameter in production.gms, ensures low-logging costs when afforestation is harvested"

    pFirewoodWoodchips[t]                   "Producers price of energy-wood in the LULUCF-module"
    pHugstomk_usew[t]                       "Cost of logging use-wood, bio. kr. per kilo cubic meter of use-wood"
    pHugstomk_firew[t]                      "Cost of logging energy-wood, bio. kr. per cubic meter energy-wood"

    j_pHV2_hoved_FRF[joe07,spec_type,acl,t] "J-term"
    j_pV2_tynd_FRF[joe07,spec_type,acl,t]   "J-term"
    j_pHV2_hoved_NRE[joe07,spec_type,acl,t] "J-term"
    j_pV2_tynd_NRE[joe07,spec_type,acl,t]   "J-term"
    j_pHV2_hoved_AFF[skmodel,joe07,spec_type,acl,t] "J-term"
    j_pV2_tynd_AFF[skmodel,joe07,spec_type,acl,t] "J-term"


    j_qY_CET_outother_02000_usewood_CGE[t] "J-term"
    j_PJ_energyXmill_smooth[t]             "J-term"

    qI_s_afforestation[t]                  "Investments in afforestation, bio. kr. growth and inf.-adjusted"
    qI_s_afforestation_inst[t]             "Increased investment demand in afforestation, from scarcity of plant materiale, bio. kr. growth- and inf. -adjusted"

    pY_CET_usewoodtot[t]                    "Price index of use-wood"
    pY_CET_usewoodtot_baseline[t]           "Price index of use-wood baseline"

    vTotalCost_hugst[skmodel,joe07,spec_type,acl,t] "Cost of logging use-wood afforestation, bio. kr., growth- and inf.-adjusted"
    vTotalCost_hugst_sum[t]                         "Total cost of logging afforestation, bio. kr., growth- and inf.-adjusted"
    vTotalCost_targetfromIfro_hugst[t]              "Total cost of logging afforestation, bio. kr. growth- and inf.-adjusted, based on IFRO-data"
    vTotalCost_firew[skmodel,joe07,spec_type,acl,t] "Cost of harvesting energy-wood from afforestation, bio. kr., growth- and inf.-adjusted"
    vTotalCost_firew_sum[t]                         "Total cost of harvesting energy-wood from afforestation, bio. kr., growth- and inf.-adjusted"
    vTotalCost_targetfromIfro_firew[t]              "Total cost of harvesting energy-wood from afforestation, bio. kr., growth- and inf.-adjusted, based on IFRO-data"
    vTotalCost[skmodel,joe07,spec_type,acl,t]       "Cost of logging afforestation, both use- and energy wood, bio. kr., growth- and inf.-adjusted"

    pTotalOperatingSurplus_AFF[t]                   "Total operating surplus from afforestation, bio. kr. per kha., growth- and inf.-adjusted"

    pI_afforestation_external[joe07]               "External assessment of afforestation costs, kroner per ha, growth- and inf.-adjusted"
  ;

  PARAMETER ite1skov/1/;

$ENDIF







$IF %stage% == "groupcompilation":

  $GROUP G_lulucf_links_endo 
    pHV2_hoved_FRF$(tx0[t] and tF[t] and spec_type_xp[spec_type] and acl_spec_type[acl,spec_type] and pHV2_hoved_FRF.l[joe07,spec_type,acl,t])
    pV2_tynd_FRF$(tx0[t] and tF[t] and spec_type_xp[spec_type] and acl_spec_type[acl,spec_type] and pV2_tynd_FRF.l[joe07,spec_type,acl,t])
    pHV2_hoved_NRE$(tx0[t] and tF[t] and qC5_hoved_NRE.l[joe07,spec_type,acl,t] and pHV2_hoved_NRE.l[joe07,spec_type,acl,t])
    pV2_tynd_NRE$(tx0[t] and tF[t] and qC5_tynd_NRE.l[joe07,spec_type,acl,t] and pV2_tynd_NRE.l[joe07,spec_type,acl,t])
    pHV2_hoved_AFF$(tx0[t] and tF[t] and d1qF5_aff[skmodel,joe07,spec_type,acl,t] and pHV2_hoved_AFF.l[skmodel,joe07,spec_type,acl,t])
    pV2_tynd_AFF$(tx0[t] and tF[t] and d1qF5_aff[skmodel,joe07,spec_type,acl,t] and pV2_tynd_AFF.l[skmodel,joe07,spec_type,acl,t])

    pHV2_hoved_AFF$(tx0[t] and tF[t] and (d1qF5_aff[skmodel,joe07,spec_type,acl,t+1] and not d1qF5_aff[skmodel,joe07,spec_type,acl,t])  and pHV2_hoved_AFF.l[skmodel,joe07,spec_type,acl,t])
    pV2_tynd_AFF$(tx0[t] and tF[t] and (d1qF5_aff[skmodel,joe07,spec_type,acl,t+1] and not d1qF5_aff[skmodel,joe07,spec_type,acl,t]) and pV2_tynd_AFF.l[skmodel,joe07,spec_type,acl,t])


    pWoodproduct_markup$(tx0[t] and tF[t])
    markup$(tx0[t] and tF[t] and d1vY_CET[out,s,t] and sameas[out,'Firewood and woodchips'] and sameas[s,'02000']) 
    pY_CET_outother_02000_usewood$(tF[t])

    qY_CET_outother_02000_usewood_smooth$(tF[t])
    qY_CET_outother_02000_usewood$(tF[t])
    qY_CET_outother_02000_usewood_AFF$(tF[t])
    qY_CET_outother_02000_usewood_AFF_smooth$(tF[t])
    
    qPJ_energyXmill_smooth$(tF[t])
    qC5_Energy_AFF_xMill_smooth$(tF[t])

    pFirewoodWoodchips$(tx0[t] and tF[t])
    qD_usewood_CGE$(tx0[t])


    qI_s_afforestation$(tx0[t] and tF[t] and sum(skmodel, sum(joe07, sum(spec_type, d1qF5_aff[skmodel,joe07,spec_type,'acl5',t]))))

    pHugstomk_usew[t]$(tx0[t] and tF[t]) ""
    pHugstomk_firew[t]$(tx0[t] and tF[t]) ""
    
    pY_CET_usewoodtot$(tx0[t] and tF[t])

    sUseWood_AFF$(tx0[t] and tF[t] and qC5_Use_AFF.l[t])
    sFireWood_AFF$(tx0[t] and tF[t] and qC5_Energy_AFF.l[t])

    pTotalOperatingSurplus_AFF$(tF[t] and sum(skmodel,sum(joe07,sum(spec_type,sum(acl, d1qF5_AFF[skmodel,joe07,spec_type,acl,t])))))
  ;

  $GROUP G_lulucf_links_exo
    pWoodproduct_markup$(t0[t] or tF0[t])
    j_pHV2_hoved_FRF[joe07,spec_type,acl,t]$(tx0[t] and tF[t] and spec_type_xp[spec_type] and acl_spec_type[acl,spec_type] and pHV2_hoved_FRF.l[joe07,spec_type,acl,t])
    j_pV2_tynd_FRF[joe07,spec_type,acl,t]$(tx0[t] and tF[t] and spec_type_xp[spec_type] and acl_spec_type[acl,spec_type] and pV2_tynd_FRF.l[joe07,spec_type,acl,t])
    j_pHV2_hoved_NRE[joe07,spec_type,acl,t]$(tx0[t] and tF[t] and qC5_hoved_NRE.l[joe07,spec_type,acl,t] and pHV2_hoved_NRE.l[joe07,spec_type,acl,t])
    j_pV2_tynd_NRE[joe07,spec_type,acl,t]$(tx0[t] and tF[t] and qC5_tynd_NRE.l[joe07,spec_type,acl,t] and pV2_tynd_NRE.l[joe07,spec_type,acl,t])
    j_pHV2_hoved_AFF[skmodel,joe07,spec_type,acl,t]$(tx0[t] and tF[t] and d1qF5_aff[skmodel,joe07,spec_type,acl,t] and pHV2_hoved_AFF.l[skmodel,joe07,spec_type,acl,t])
    j_pV2_tynd_AFF[skmodel,joe07,spec_type,acl,t]$(tx0[t] and tF[t] and d1qF5_aff[skmodel,joe07,spec_type,acl,t] and pV2_tynd_AFF.l[skmodel,joe07,spec_type,acl,t])
    j_qY_CET_outother_02000_usewood_CGE[t]
    pY_CET_outother_02000_usewood$(tF0[t])

    qY_CET_outother_02000_usewood$(tF0[t])
    qY_CET_outother_02000_usewood$(t.val<=t0.val or t.val <=tF0.val)
    qY_CET_outother_02000_usewood$(t.val=2019)

    qY_CET_outother_02000_usewood_AFF$(tF0[t])
    qY_CET_outother_02000_usewood_AFF$(t.val<=t0.val or t.val <=tF0.val)
    qY_CET_outother_02000_usewood_AFF$(t.val=2019)

    qY_CET_outother_02000_usewood_smooth$(tF0[t])
    qY_CET_outother_02000_usewood_AFF_smooth$(tF0[t])

    qPJ_energyXmill$(tF0[t])
    qPJ_energyXmill$(t.val=2019)
    qPJ_energyXmill_smooth$(tF0[t])

    qC5_Energy_AFF_xMill$(tF0[t])
    qC5_Energy_AFF_xMill$(t.val=2019)
    qC5_Energy_AFF_xMill_smooth$(tF0[t])
    j_PJ_energyXmill_smooth[t]

  
    pFirewoodWoodchips$(tF[t])
    qPJ_energyXmill$(t.val <=t0.val)

    sUseWood_AFF
    sFireWood_AFF

    pHugstomk_usew
    pHugstomk_firew

    pY_CET_usewoodtot

    #From other modules 
    pY_CET$(tx0[t] and d1vY_CET[out,s,t] and sameas[out,'out_other'] and sameas[s,'02000'])  
    qRxE_y$(tx0[t] and tF[t] and d1rXE_y[r,s,t] and sameas[r,'16000'] and sameas[s,'02000'])
    qRxE_y$(tx0[t] and tF[t] and d1rXE_y[r,s,t] and sameas[r,'13150'] and sameas[s,'02000'])
    qRxE_y$(tx0[t] and tF[t] and d1rXE_y[r,s,t] and sameas[r,'41430'] and sameas[s,'02000'])


    pY0$((tx0[t] or t0[t]) and sameas[s,'02000'])
    pY_CET_usewoodtot_baseline

    pKELBM$(tF[t] and sameas[s,'02000'])
    qKELBM$(tF[t] and sameas[s,'02000'])
    pK$(tF[t] and sameas[sp,'02000'])
    qK$((tF[t] or tF0[t]) and sameas[s,'02000'])
    vY$(tF[t] and sameas[s_,'02000'])
    pY_CET$(tF[t] and sameas[s,'02000'])
    pI_afforestation_external


  ;


  $PGROUP PGROUP_LULUCF_NonFlat_Dummies
    d1qF ""
    d1qF5_LYS ""
    d1qF5_NRE ""
    d1qF5_aff ""
    d1qF5_FRF_NST ""
    d1qC5_FRF_reducNST ""
    d1qC5_FRF_reduc_hugst_NST ""
    d1pSurvival ""
    d1qEmmF[joe07,spec_type,acl,t] ""

    d1uSoilStock12 ""
    d1uBiomass12 ""

    d1qLU12[land12,t] ""
    d1qEmmLU12xF[land12xF,t] ""
    d1LU_agg[land5xF,t] ""
    d1LULUCF5[land5,t] ""
    d1qLUC5[land5_s,land5_r,t] ""
    d1qLUC12[land12_s,land12_r,t] ""
    d1qEmmLUC12[land12,t] ""
    d1qEmmtable4ii[land5,t] ""
    d1uEmmInstantOxiLUCinF[land12_s,land12_r] "" 
    d1uLUConv12xF[land12xF,land12xF_a] ""
    d1uSoilStock12[tt,t,land12] ""
    d1uBiomass12[tt,t,land12] ""
    ;

  $GROUP G_no_forecast_lulucf
    qLUC12
    qLUC12_baseline
    qLUC8
    uLU12_LUC12
    jLUC12
    qLU8 
    qLU12


    uBiomass12
    uSoilStock12
    uLU12xF

    qEmmHedgerows
    qEmmPeatland
    qEmmtable4ii
    qEmmTable4iii_settlement
    qEmmLU5xF
    qEmmLUC
    qEmmLULUCF5
    jEmmLULUCF
    qEmmLULUCF
    qEmmForestsoil


    jF5_FRF
    qF5_aff, jF5_AFF
    qF5_AFF_denom
    qF5_FRF
    qF5_FRF_fromAFF
    qF5_NRE 
    qF5_LYS
    qEmmFstock_FRF
    qEmmFStock_NRE
    qEmmFStock_LYS
    qEmmFstock_AFF
    qEmmFstock
    jEmmFstock_FRF
    jEmmFstock_AFF

    qC5_tynd_FRF
    qC5_tynd_NRE
    qC5_tynd_LYS
    qC5_tynd_AFF

    qC5_hoved_FRF
    qC5_hoved_NRE
    #  qC5_hoved_LYS
    qC5_hoved_AFF

    qC5_Energy_AFF
    qC5_Use_AFF
    qV2_Energy_AFF_xMill_FullDim
    qV2
    qC5_ENergy_AFF_xMill
    qC5_Energy_AFF_xMill_smooth
    qC5_Energy_FRF_fromAFF_xMill
    qC5_Energy_AFF_xMill_full

    adjloss_C5_FRF
    adjloss_C5_AFF
    adjloss_C5_NRE

    sEnduse
    
    qF5_NRE_deforestation

    qC5_usestock_FRF

    qC5_FRF_reducNST  
    qC5_FRF_reduc_hugst_NST

    qC5_hoved_FRF
    qF5_FRF_NST

    qEmmHWP
    jEmmHWP

    #Economics
    pHV2_hoved_AFF
    pHV2_hoved_AFF_data
    pV2_tynd_AFF
    pV2_tynd_AFF_data
    pHV2_hoved_NRE 
    pV2_tynd_NRE
    j_pHV2_hoved_NRE[joe07,spec_type,acl,t]
    j_pV2_tynd_NRE[joe07,spec_type,acl,t]
    j_pHV2_hoved_AFF[skmodel,joe07,spec_type,acl,t]
    j_pV2_tynd_AFF[skmodel,joe07,spec_type,acl,t]

    qPJ_energyXmill
    qY_CET_outother_02000_usewood
    qY_CET_outother_02000_usewood_smooth
    pY_CET_outother_02000_usewood
    qPJ_energyXmill
    qPJ_energyXmill_smooth

    j_PJ_energyXmill_smooth
    vV3
  ;

  $GROUP G_lulucf_endo 
    G_luluc_endo   
    G_f_endo  
    G_lulucf_links_endo
  ;

  $GROUP G_lulucf_exo 
    G_luluc_exo
    G_f_exo 
    G_lulucf_links_exo
  ;

$ENDIF


# ====================================================================================================================
# Equations
# ====================================================================================================================

$IF %stage% == "equations":

  $BLOCK B_lulucf
  
  #===============================================================================================================================================================================#      
  # AREA-MATRIX
  #===============================================================================================================================================================================#      

  # ACCOUNTING: land use and land use changes
  E_qLU12_qLU5[land5,t]$(tLULUC[t])..
    #9 land-categories are summed to 5. The difference is that crop and forest-land are categorized in 3 different levels of carbon content (<6, 6-12, 12<)
    qLU5[land5,t] =E= sum(land12$(land52land12[land5,land12] and d1qLU12[land12,t]), qLU12[land12,t]);

  #Transition on 5 type-resolution. The dimension of qLUC5 is [sender x receiver x time].  
  E_qLUC12_qLUC5[land5_s,land5_r,t]$(tLULUC[t] and d1qLUC5[land5_s,land5_r,t])..
    #Transition matrix for land-types (eg. crop-land that stays cropland, or crop-land to forest, etc.)
    qLUC5[land5_s,land5_r,t] =E= sum((land12_s,land12_r)$(not sameas(land12_s,land12_r) and land52land12[land5_s,land12_s] and land52land12[land5_r,land12_r] and d1qLUC12[land12_s,land12_r,t]), qLUC12[land12_s,land12_r,t] + jLUC12[land12_s,land12_r,t]);

  #  Transition on 9 type-resolution. The dimension of qLUC12 is [sender x receiver x time].
  E_qLU12_qLUC12[land12_r,t]$(tLULUC[t] and d1qLU12[land12_r,t])..
    qLU12[land12_r,t] =E= qLU12[land12_r,t-1]
      + sum(land12_s$(d1qLUC12[land12_s,land12_r,t] and not sameas(land12_s,land12_r)), qLUC12[land12_s,land12_r,t]) #Type land12 converted to land129 
      - sum(land12_s$(d1qLUC12[land12_r,land12_s,t] and not sameas(land12_r,land12_s)), qLUC12[land12_r,land12_s,t]) #Subtraction of land129 converted to other land
      + uLU12_LUC12[land12_r,t]; #Calibration parameter to account for difference in data-years


  #===============================================================================================================================================================================#      
  # LAND-USE EMISSIONS (LU)
  #===============================================================================================================================================================================#      

  E_qEmmLU[t]$(tLULUC[t]).. 
    #Land-use emissions are the emissions from all land-types, excluding forests
    qEmmLU[t] =E= sum(land5xF$(d1LU_agg[land5xF,t]), qEmmLU5xF[land5xF,t]);

  E_qEmmLU5xF[land5xF,t]$(tLULUC[t] and d1LU_agg[land5xF,t]).. 
     qEmmLU5xF[land5xF,t] =E= sum(land12xF$(land5xF2land12xF[land5xF,land12xF] and d1qEmmLU12xF[land12xF,t]), qEmmLU12xF[land12xF,t]);

  E_qEmmLU12xF[land12xF,t]$(tLULUC[t] and d1qEmmLU12xF[land12xF,t]).. 
    #Emissions are given by an emission-coeffucient uLU12xF times land-type. 
    qEmmLU12xF[land12xF,t] =E= uLU12xF[land12xF,t]*qLU12[land12xF, t]$(d1qLU12[land12xF,t]) 
                       #On top of that are emissions from previously converted organic CL and GL -> Wetland. We sum over all periods since bf_start. 
                       + sum((tt,land12xf_a)$(tt.val <= t.val and tt.val>=%bf_start% and d1uLUConv12xF[land12xf_a,land12xF]), uLUConv12xF[land12xf_a,land12xF]*qLUC12[land12xf_a,land12xF,tt]$(d1qLUC12[land12xf_a,land12xF,tt]))
                       + qEmmPyrolyse_tot[t]$(tx0[t] and sum(PyrolyseTech, d1PyrolysePot[PyrolyseTech,t]) and sameas[land12xF,'crop_u6'])
                       ;
                       
  #===============================================================================================================================================================================#      
  # LAND-USE-CHANGE EMISSIONS (LUC)
  #===============================================================================================================================================================================#      
  

  E_qEmmLUC12[land12_r,t]$(tLULUC[t]).. 
      #The land use-change emissions are composed of three elements currently
       qEmmLUC12[land12_r,t] =E= 
       qEmmLUC12_BiomassStock[land12_r,t] #The change in biomass stock. Apart from the case of cropland transformed to grassland this is an instantaneous effect
     + qEmmLUC12_OxiLuc[land12_r,t]       #For deforestation there is a N2O-emission associated with the decomposition of organic matter
     + qEmmLUC12_SoilStock[land12_r,t]    #The soil organic smatter gradually changes from one equilibrium to a new over 30-years (100-years for forest)
    ;


  E_qEmmLUC12_BiomassStock[land12_r,t]$(tLULUC[t])..
      qEmmLUC12_BiomassStock[land12_r,t] =E=                
        #Non-forest
         44/12 * uDM2C[land12_r] * sum(land12_s$(d1qLUC12[land12_s,land12_r,t] and not (sameas[land12_r,'forest'] and land12_crop[land12_s])), qLUC12[land12_s,land12_r,t] * (qBiomassStock9[land12_s]-qBiomassStock9[land12_r]))  #Instantaneous effect in change from type land12 -> land129. qBiomassStock9 biomass per area of type land12
        
        #Forest
          #For conversion of cropland to forest there is an initial loss of the biomass in crops (first line below). Secondly unmanaged grass grows (line 2) and slowly decays over 25 years as the forest grows
          +44/12 * uDM2C[land12_r] * sum(land12_s$(d1qLUC12[land12_s,land12_r,t] and (sameas[land12_r,'forest'] and land12_crop[land12_s])),  qLUC12[land12_s,land12_r,t]  * (qBiomassStock9['crop_u6'] - qBiomassStock9['grass_u6'])) #For forests a 25-year transition period is used     
      
          +44/12 * uDM2C[land12_r] * sum((tt,land12_s)$(tt.val <= t.val and tt.val>=%bf_start% and d1qLUC12[land12_s,land12_r,tt] and sameas[land12_r,'forest'] and land12_crop[land12_s]), 
                                                     qLUC12[land12_s,land12_r,tt] * uBiomass12[tt,t,land12_r]  * (qBiomassStock9['grass_u6'] - qBiomassStock9['forest'])) #For forests a 25-year transition period is used 



    #This term should be replaced by numbers in excel sheets from IGN containing the actual deforestation emissions
     + sum(land12_s, # (qLUC12[land12_s,land12_r,t] * qEmmFstock_FRF_tot[t]/sum((joe07,spec_type,acl)$(acl_spec_type[acl,spec_type]), qF5_FRF[joe07,spec_type,acl,t]))$(t.val >= tFStart.val and d1qLUC12[land12_s,land12_r,t] and sameas[land12_s,'forest'])
     +  (qLUC12[land12_s,land12_r,t] * qEmmFstock[t]/qLU12['forest',t])$(t.val <tFstart.val and d1qLUC12[land12_s,land12_r,t] and sameas[land12_s,'forest']));

  E_qEmmLUC12_OxiLuc[land12_r,t]$(tLULUC[t])..
      qEmmLUC12_OxiLuc[land12_r,t] =E= sum(land12_s$(d1qLUC12[land12_s,land12_r,t] and d1uEmmInstantOxiLUCinF[land12_s,land12_r]), qLUC12[land12_s,land12_r,t]*(uEmmInstantOxiLUCinF[land12_s,land12_r]));

  E_qEmmLUC12_Soilstock[land12_r,t]$(tLULUC[t])..
      qEmmLUC12_SoilStock[land12_r,t] =E=    
         #Non-forest
         sum((tt,land12_s)$(tt.val<=t.val and d1qLUC12[land12_s,land12_r,tt] and d1noLUC12inbase[land12_s,land12_r] and not sameas[land12_r,'forest']), (qLUC12[land12_s,land12_r,tt] - qLUC12_baseline[land12_s,land12_r,tt])*(qSoilStock9[land12_s]-qSoilStock9[land12_r])*uSoilStock12[tt,t,land12_r]) #The gradual effects of time in changed soil composition. For non-forests the process is 30-years and forests 100-years (difference due to convention-difference amongs researchers)
       + sum((tt,land12_s)$(tt.val<=t.val and d1qLUC12[land12_s,land12_r,tt] and not d1noLUC12inbase[land12_s,land12_r] and not sameas[land12_r,'forest']), qLUC12[land12_s,land12_r,tt] *(qSoilStock9[land12_s]-qSoilStock9[land12_r])*uSoilStock12[tt,t,land12_r])
      
        #Forest 
       + sum((tt,land12_crop)$(tt.val<=t.val and d1qLUC12[land12_crop,land12_r,tt] and not d1noLUC12inbase[land12_crop,land12_r] and sameas[land12_r,'forest']), qLUC12[land12_crop,land12_r,tt] *(qSoilStock9[land12_crop] - qSoilStock9[land12_r]) * uSoilStock12[tt,t,land12_r]); #For forests only conversions from agricultural lands apply, cf. sources in 'exogenous_values'       
       


  E_qEmmLUC5[land5,t]$(tLULUC[t]).. 
      qEmmLUC5[land5,t] =E=  sum(land12$(land52land12[land5,land12]), qEmmLUC12[land12,t]); 
     
  E_qEmmLUC[t]$(tLULUC[t]).. 
      qEmmLUC[t] =E= sum(land5, qEmmLUC5[land5,t]);

  # Table 4II emissions
  #This is just a reporting variable at this point to remind one about what is actually in table 4ii
    E_qEmmTable4ii_wetland[t]$(tLULUC[t])..
      qEmmTable4ii_wetland[t] =E= 
         sum(emm$(not sameas[emm,'CO2ubio']), qEmmPeatland[emm,t]*GWP.l[emm]) 
      +  sum(land12xF$(sameas[land12xF,'Wetland']),
         sum((tt,land12xf_a)$(tt.val <= t.val and tt.val>=%bf_start% and d1uLUConv12xF[land12xf_a,land12xF]), uLUConv12xF[land12xf_a,land12xF]*qLUC12[land12xf_a,land12xF,tt]$(d1qLUC12[land12xf_a,land12xF,tt])));


  #===============================================================================================================================================================================#      
  # EMISSION-AGGREGATES
  #===============================================================================================================================================================================#      
  
    E_LULUCF5xF[land5xF,t]$(tLULUC[t])..
      qEmmLULUCF5[land5xF,t] =E=  qEmmLUC5[land5xF,t]                        
                                + qEmmLU5xF[land5xF,t]$(d1LU_agg[land5xF,t]) 
                                + qEmmtable4ii[land5xF,t]$(d1qEmmtable4ii[land5xF,t]) 
                                + sum(emm,qEmmPeatland[emm,t]*GWP[emm])$(sameas[land5xF,'wetland']) #Add exogenous peatland emissions
                                + sum((land12xf,land8)$(land82land12(land8,land12xF) and land52land8(land5xF,land8)), qEmmHedgeRows[land12xf,t]) #Add exogenous emissions/uptake from hedgerows, fruits and berries
                                + jEmmLULUCF[land5xF,t];


    E_LULUCF5F[t]$(tF[t])..
      qEmmLULUCF5['forest',t] =E=  qEmmLUC5['forest',t] 
                                 + qEmmF[t] 
                                 + qEmmtable4ii['forest',t]$(d1qEmmtable4ii['forest',t]) 
                                 + qEmmTable4iii_settlement[t] 
                                 + qEmmForestsoil[t]
                                 + jEmmLULUCF['forest',t]
                                ;

    E_qEmmLULUCF[t]$(tLULUC[t]).. 
      qEmmLULUCF[t] =E= sum(land5, qEmmLULUCF5[land5,t]) + qEmmHWP[t]; 
      
  
  #===============================================================================================================================================================================#      
  # FORESTS
  #===============================================================================================================================================================================#      
  
    #-------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
    # FOREST REMAINING FOREST 
    #-------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
   
    #AREALER
      #Equation for new forest! All dead forest is assumed to be replanted/newly-grown. Note that the equation is conditional on acl_init! Which is new-planted/new-grown forest.
      E_qF5_FRF_regenerated[joe07, spec_type, acl,t]$(tF[t] and acl_init[acl])..              
          #New forest is then equal to what didn't survive from all other age-classes (acl_a)     
          qF5_FRF[joe07,spec_type,acl,t] =E= sum(acl_a$(acl_xinit[acl_a,spec_type]),    qF5_FRF[joe07, spec_type, acl_a-1,t-5]*(1-pSurvival[joe07, spec_type, acl_a-1])) #Note that this also sums the survivors of acl0
                                           + sum(acl_a$(acl_terminal[acl_a,spec_type]), qF5_FRF[joe07, spec_type, acl_a,t-5] *(1-pSurvival[joe07,spec_type,acl_a]))     #Survivors of terminal age
                                           #The area that doesn't survive is the variable 'Harea' in Tqble 11-11. Note that the numbers in table 11-11 needs to be multiplied by five to arrive at 5-year increments
                                           + sum((acl_a,skmodel)$(d1qF5_AFF[skmodel,joe07,spec_type,acl_a-1,t-5]), (1-pSurvival_AFF[skmodel,joe07,spec_type,acl_a-1]) * qF5_AFF[skmodel,joe07,spec_type,acl_a-1,t-5])
                                           + jF5_FRF[joe07,spec_type,acl,t];
                                          #When the IGN afforestation area is moved it seems not to enter qF5_FRF in 'acl5'. Though it appears to be necessary to include it here to compute correct carbon-levels

      E_qF5_FRF_regenerated_accounts[joe07,spec_type,t]$(tF[t])..
          qF5_FRF_regenerated[joe07,spec_type,t] =E= sum(acl_a$(acl_xinit[acl_a,spec_type]),    qF5_FRF[joe07, spec_type, acl_a-1,t-5]*(1-pSurvival[joe07, spec_type, acl_a-1])) #Note that this also sums the survivors of acl0
                                                   + sum(acl_a$(acl_terminal[acl_a,spec_type]), qF5_FRF[joe07, spec_type, acl_a,t-5] *(1-pSurvival[joe07,spec_type,acl_a]))      #Survivors of terminal age
                                                   + sum((acl_a,skmodel)$(d1qF5_AFF[skmodel,joe07,spec_type,acl_a-1,t-5]), (1-pSurvival_AFF[skmodel,joe07,spec_type,acl_a-1]) * qF5_AFF[skmodel,joe07,spec_type,acl_a-1,t-5])
                                                   ;


      ###############FROM AFF: START --->
        #WE ONLY FOLLOW FIRST GENERATION IN THESE EQUATIONS FOR "fromAFF"
        E_qF5_FRF_fromAFF_acl5[joe07,spec_type,acl,t]$(tF[t] and sum(skmodel,d1qF5_AFF[skmodel,joe07,spec_type,acl,t]) and acl_init[acl])..
          qF5_FRF_fromAFF[joe07,spec_type,acl,t] =E=  sum((acl_a,skmodel)$(d1qF5_AFF[skmodel,joe07,spec_type,acl_a-1,t-5] and sum(ite,firstgen(ite,acl_a-1) and ite2t(ite,t-5))),
                                                                     (1-pSurvival_AFF[skmodel,joe07,spec_type,acl_a-1]) * qF5_AFF[skmodel,joe07,spec_type,acl_a-1,t-5]);


        E_qF5_FRF_fromAFF[joe07,spec_type,acl,t]$(tF[t] and sum(skmodel,d1qF5_AFF[skmodel,joe07,spec_type,acl,t]) and acl_xinit[acl,spec_type]).. 
          qF5_FRF_fromAFF[joe07,spec_type,acl,t] =E= pSurvival[joe07,spec_type,acl-1] * qF5_FRF_fromAFF[joe07,spec_type,acl-1,t-5];
                                  

        E_qC5_Energy_FRF_fromAFF_xMill[joe07,spec_type,acl,t]$(tF[t] and sum(skmodel,d1qF5_AFF[skmodel,joe07,spec_type,acl,t]))..
           qC5_Energy_FRF_fromAFF_xMill[joe07,spec_type,acl,t] =E= qF5_FRF_fromAFF[joe07,spec_type,acl,t] * Tynding_coefs[joe07,spec_type,acl] * sTynd_FRF['ite1',joe07,spec_type,acl,'tynd_fuel']
                                                                 +(qF5_FRF_fromAFF[joe07, spec_type, acl-1,t-5]*(1-pSurvival[joe07, spec_type, acl-1]) * content_coeffs_data[joe07,spec_type,acl,'CA_ha'] * adjloss_C5_FRF[t] *sHTynd_FRF['ite1',joe07,spec_type,acl,'tynd_fuel']/5)$(sum(skmodel,d1qF5_AFF[skmodel,joe07,spec_type,acl-1,t-5] and pSurvival_AFF.l[skmodel,joe07,spec_type,acl-2]<>1));



        E_qHV2_hoved_FRF_fromAFF[joe07,spec_type,acl,t]$(tF[t] and sum(skmodel,d1qF5_AFF[skmodel,joe07,spec_type,acl,t]) and sHTynd_FRF.l['ite1',joe07,spec_type,acl,'tynd_use'])..
          qHV2_hoved_FRF_fromAFF[joe07,spec_type,acl,t] =E= qHV2_hoved_FRF[joe07,spec_type,acl,t] * qF5_FRF_fromAFF[joe07,spec_type,acl,t]/qF5_FRF[joe07,spec_type,acl,t];

        E_qV2_tynd_FRF_fromAFF[joe07,spec_type,acl,t]$(tF[t] and sum(skmodel,d1qF5_AFF[skmodel,joe07,spec_type,acl,t]) and sTynd_FRF.l['ite1',joe07,spec_type,acl,'tynd_use'])..
          qV2_tynd_FRF_fromAFF[joe07,spec_type,acl,t] =E= qV2_tynd_FRF[joe07,spec_type,acl,t] * qF5_FRF_fromAFF[joe07,spec_type,acl,t]/qF5_FRF[joe07,spec_type,acl,t];

      #############FROM AFF: END <---

      #Equation for all other age-classes (the not new-planted/newly-grown forest). Note the conditional acl_xinit_term which states all age-classes except from 1 (and the "terminal age").
      E_qF5_FRF[joe07,spec_type,acl,t]$(tF[t] and acl_xinit_term[acl,spec_type])..               
          qF5_FRF[joe07,spec_type,acl,t] =E= (qF5_FRF[joe07, spec_type, acl-1,t-5])*pSurvival[joe07,spec_type,acl-1]
                                          + jF5_FRF[joe07,spec_type,acl,t]; 


      #Equation for "terminal"-stage trees. After a certain age (200 years as this is written) the trees can, for all practical purposes, be lumped in to the same category. In particular because they do not absorb any more CO2 at this point.
      E_qF5_FRF_terminal[joe07, spec_type, acl,t]$(tF[t] and acl_terminal[acl,spec_type])..                 
          qF5_FRF[joe07,spec_type,acl,t] =E= qF5_FRF[joe07,spec_type,acl-1,t-5]*pSurvival[joe07,spec_type,acl-1] + qF5_FRF[joe07, spec_type, acl,t-5] *pSurvival[joe07,spec_type,acl]
                                           + jF5_FRF[joe07,spec_type,acl,t]; 


      #NATURSTYRELSENS AREALER -
      E_qF5_FRF_NST[joe07,spec_type,acl,t]$(tF[t] and d1qF5_FRF_NST[joe07,spec_type,acl,t])..
        qF5_FRF_NST[joe07,spec_type,acl,t] =E= qF5_FRF_NST[joe07,spec_type,acl-1,t-5] * pSurvival[joe07,spec_type,acl-1];
        #AKB: Should in principle make a full model for NST area, but since reduced thinning is only on second iteration we can get away with the above


      #TOTALT AREAL FRF         
      E_qF5_FRF_tot[t]$(tF[t])..
        qF5_FRF_tot[t] =E= sum((joe07,spec_type,acl)$(acl_spec_type[acl,spec_type]), qF5_FRF[joe07,spec_type,acl,t]);


    #KULSTOFLAGRE
      #Kulstoflager i stående FRF-skov
      E_qC5_FRF[joe07,spec_type,acl,t]$(tF[t])..
        qC5_FRF[joe07,spec_type,acl,t] =E= (qF5_FRF[joe07,spec_type,acl,t]*content_coefs[joe07, spec_type, acl] + qC5_FRF_reducNST[joe07,spec_type,acl,t]$(d1qC5_FRF_reducNST[joe07,spec_type,acl,t]));


      #Kulstoflager i tynding. Bemærk frdraget på 30 pct. reduceret hugst på Naturstyrelsens arealer imellem 2026-2030
      E_qC5_tynd_FRF[joe07,spec_type,acl,t]$(tF[t] and acl_spec_type[acl,spec_type])..
        qC5_tynd_FRF[joe07,spec_type,acl,t] =E=  qF5_FRF[joe07,spec_type,acl,t] * Tynding_coefs[joe07,spec_type,acl] 
                                                    - 0.3 * Tynding_coefs[joe07,spec_type,acl] * qF5_FRF_NST[joe07,spec_type,acl,t]$(ite2t('ite2',t) and d1qF5_FRF_NST[joe07,spec_type,acl,t])
                                                    + jC5_flow_tynd_FRF[joe07,spec_type,acl,t];
                                                    #The negative term corresponds to 'Sum af kulstof i levende biomasse over jord i hugstreduktion som følge af reduceret hugst i 2025-2031' from table 11.10. The variable "CA2NST"

      #Kulstoflager i hovedskovning.
      E_qC5_hoved_FRF[joe07,spec_type,acl,t]$(tF[t] and acl_spec_type[acl,spec_type])..
        qC5_hoved_FRF[joe07,spec_type,acl,t] =E= qF5_FRF[joe07, spec_type, acl-1,t-5]*(1-pSurvival[joe07, spec_type, acl-1]) * content_coeffs_data[joe07,spec_type,acl,'CA_ha']
                                                       +jC5_flow_hoved_FRF[joe07,spec_type,acl,t] ;  #Above-ground mass not transferred to next iteration is hovedskovning. It's a bit odd that it is measured not as a weighted average of acl and acl-1 (with weights 0.5/0.5), but whatevs..
         

      #Kulstoflager i stående FRF-skov målt i ktCO2e
      E_qEmmFstock_FRF[joe07,spec_type,acl,t]$(tF[t])..
        qEmmFstock_FRF[joe07,spec_type,acl,t] =E= qC5_FRF[joe07,spec_type,acl,t]*44/12 + jEmmFstock_FRF[joe07,spec_type,acl,t]; 

    #Decomposition of qC5_usestock_FRF
    E_qC5_usestock_FRF_depreciation[enduse_wood,spec_type,t]$(tF[t] and spec_type_xp[spec_type])..
      qC5_usestock_FRF_depreciation[enduse_wood,spec_type,t] =E= qC5_usestock_FRF[enduse_wood,spec_type,t-5] * (1 - depreciation_factor_usestock[enduse_wood]**5);

    E_qC5_usestock_FRF_HTynd[enduse_wood,spec_type,t]$(tF[t] and spec_type_xp[spec_type])..
      qC5_usestock_FRF_HTynd[enduse_wood,spec_type,t] =E= 
          sUtilization[enduse_wood,spec_type] * sEnduse[enduse_wood] * sHCA2HV2[enduse_wood,spec_type] *
             sum((joe07,acl)$(acl_spec_type[acl,spec_type]), sHTyndCorr_FRF[joe07,spec_type,acl]  * sHTynd_FRF['ite1',joe07,spec_type,acl,'tynd_use'] *    qC5_hoved_FRF[joe07,spec_type,acl,t]) * depreciation_factor_usestock_inflow[enduse_wood]**5;
  
    E_qC5_usestock_FRF_Tynd[enduse_wood,spec_type,t]$(tF[t] and spec_type_xp[spec_type])..
      qC5_usestock_FRF_Tynd[enduse_wood,spec_type,t] =E= sUtilization[enduse_wood,spec_type] * sEnduse[enduse_wood] * sum((joe07,acl)$(acl_spec_type[acl,spec_type]), sTynd_FRF['ite1',joe07,spec_type,acl,'tynd_use']  * 5* qC5_tynd_FRF[joe07,spec_type,acl,t]) * depreciation_factor_usestock_inflow[enduse_wood]**5;


    #Total carbon in harvest
    E_qC5_usestock_FRF_flow[t]$(tF[t])..
      qC5_usestock_FRF_flow[t] =E= sum((joe07,spec_type_xp,acl)$(acl_spec_type[acl,spec_type_xp]), 5*qC5_tynd_FRF[joe07,spec_type_xp,acl,t] + qC5_hoved_FRF[joe07,spec_type_xp,acl,t]);

      #Total kulstoflager i FRF-skov målt i ktCO2e
      E_qEmmFstock_FRF_tot[t]$(tF[t])..
        qEmmFstock_FRF_tot[t] =E= sum((joe07,spec_type,acl), qEmmFstock_FRF[joe07,spec_type,acl,t]);



      E_qHV2_hoved_FRF[joe07,spec_type,acl,t]$(tF[t] and spec_type_xp[spec_type])..
          qHV2_hoved_FRF[joe07,spec_type,acl,t] =E= sHTyndCorr_FRF[joe07,spec_type,acl]  * sHTynd_FRF['ite1',joe07,spec_type,acl,'tynd_use'] * qC5_hoved_FRF[joe07,spec_type,acl,t]/5;

      E_qV2_tynd_FRF[joe07,spec_type,acl,t]$(tF[t] and spec_type_xp[spec_type])..
          qV2_tynd_FRF[joe07,spec_type,acl,t]   =E= 1/sCA2V2[spec_type] * sTynd_FRF['ite1',joe07,spec_type,acl,'tynd_use']  *qC5_tynd_FRF[joe07,spec_type,acl,t];


      #HWP-kulstoflager fra FRF 
      E_qC5_usestock_FRF[enduse_wood,spec_type,t]$(tF[t] and spec_type_xp[spec_type])..
        #Stock er det den var for fem år siden. Plus der er vokset til over de sidste fem år
        qC5_usestock_FRF[enduse_wood,spec_type,t] =E=   qC5_usestock_FRF[enduse_wood,spec_type,t-5] * depreciation_factor_usestock[enduse_wood]**5
                                                                                                                                                    #Hovedskovningen ganges ikke med 5, da det lader til at 
             #  + sUtilization[enduse_wood,spec_type] * sEnduse[enduse_wood] * sum((joe07,acl)$(acl_spec_type[acl,spec_type]), sHTynd_FRF['ite1',joe07,spec_type,acl,'tynd_use'] *    qC5_hoved_FRF[joe07,spec_type,acl,t]) * depreciation_factor_usestock[enduse_wood]**2.5
             #  + sUtilization[enduse_wood,spec_type] * sEnduse[enduse_wood] * sum((joe07,acl)$(acl_spec_type[acl,spec_type]), sTynd_FRF['ite1',joe07,spec_type,acl,'tynd_use']  * 5* qC5_tynd_FRF[joe07,spec_type,acl,t]) * depreciation_factor_usestock[enduse_wood]**2.5;

            #Erstatter med metode baseret på afrundede tal som åbenbart (i vanlig stil) er det der køres med  
             + sUtilization[enduse_wood,spec_type] * sEnduse[enduse_wood] * sHCA2HV2[enduse_wood,spec_type] * sum((joe07,acl)$(acl_spec_type[acl,spec_type]), sHTyndCorr_FRF[joe07,spec_type,acl]  * sHTynd_FRF['ite1',joe07,spec_type,acl,'tynd_use'] *    qC5_hoved_FRF[joe07,spec_type,acl,t]+5*0.000000000000436557$(t.val>=2026 and t.val<=2030 and sameas[spec_type,'B'])) * depreciation_factor_usestock_inflow[enduse_wood]**5
             + sUtilization[enduse_wood,spec_type] * sEnduse[enduse_wood] * sHCA2HV2[enduse_wood,spec_type] * sum((joe07,acl)$(acl_spec_type[acl,spec_type]), 1/sCA2V2[spec_type]* sTynd_FRF['ite1',joe07,spec_type,acl,'tynd_use']  * 5* qC5_tynd_FRF[joe07,spec_type,acl,t]) * depreciation_factor_usestock_inflow[enduse_wood]**5;


      E_qC5_usestock_FRF_tot[t]$(tF[t] or tFinit[t])..
        qC5_usestock_FRF_tot[t] =E= sum((enduse_wood,spec_type_xp),qC5_usestock_FRF[enduse_wood,spec_type_xp,t]);


      #Carbon in annuals harvest 
        E_qC5_GrossHarvest_FRF[t]$(tF[t])..
          #Annual gross harvest of carbon 
          qC5_GrossHarvest_FRF[t] =E=  + sum((joe07,spec_type,acl)$(acl_spec_type[acl,spec_type]), qC5_tynd_FRF[joe07,spec_type,acl,t]) 
                                      + sum((joe07,spec_type,acl)$(acl_spec_type[acl,spec_type]), qC5_hoved_FRF[joe07,spec_type,acl,t])/5;



        E_qC5_Use_FRF[t]$(tF[t])..
          qC5_Use_FRF[t] =E= 
                 sum((enduse_wood,spec_type)$(spec_type_xp[spec_type]), sUtilization[enduse_wood,spec_type] *  sEnduse[enduse_wood] * sHCA2HV2[enduse_wood,spec_type] * sum((joe07,acl)$(acl_spec_type[acl,spec_type]), sHTyndCorr_FRF[joe07,spec_type,acl]  * sHTynd_FRF['ite1',joe07,spec_type,acl,'tynd_use'] *    qC5_hoved_FRF[joe07,spec_type,acl,t]+5*0.000000000000436557$(t.val>=2026 and t.val<=2030 and sameas[spec_type,'B'])))/5
                +sum((enduse_wood,spec_type)$(spec_type_xp[spec_type]), sUtilization[enduse_wood,spec_type] *  sEnduse[enduse_wood] * sHCA2HV2[enduse_wood,spec_type] * sum((joe07,acl)$(acl_spec_type[acl,spec_type]), 1/sCA2V2[spec_type]* sTynd_FRF['ite1',joe07,spec_type,acl,'tynd_use']  * 5* qC5_tynd_FRF[joe07,spec_type,acl,t]))/5;

      

        E_qC5_Energy_FRF_xMill[t]$(tF[t])..
                 qC5_Energy_FRF_xMill[t] =E=  sum((joe07,spec_type,acl)$(acl_spec_type[acl,spec_type]),   qC5_tynd_FRF[joe07,spec_type,acl,t]*sTynd_FRF['ite1',joe07,spec_type,acl,'tynd_fuel'])
                                            + sum((joe07,spec_type,acl)$(acl_spec_type[acl,spec_type]), adjloss_C5_FRF[t] *  qC5_hoved_FRF[joe07,spec_type,acl,t]*sHTynd_FRF['ite1',joe07,spec_type,acl,'tynd_fuel'])/5;

        E_qC5_Energy_FRF_Mill[t]$(tF[t])..
                 qC5_Energy_FRF_Mill[t] =E=   sum((enduse_wood,spec_type)$(spec_type_xp[spec_type]),(1-sUtilization[enduse_wood,spec_type]) *  sEnduse[enduse_wood] * sHCA2HV2[enduse_wood,spec_type] * sum((joe07,acl)$(acl_spec_type[acl,spec_type]), sHTyndCorr_FRF[joe07,spec_type,acl]  * sHTynd_FRF['ite1',joe07,spec_type,acl,'tynd_use'] *    qC5_hoved_FRF[joe07,spec_type,acl,t]+5*0.000000000000436557$(t.val>=2026 and t.val<=2030 and sameas[spec_type,'B'])))/5
                                            + sum((enduse_wood,spec_type)$(spec_type_xp[spec_type]),(1-sUtilization[enduse_wood,spec_type]) *  sEnduse[enduse_wood] * sHCA2HV2[enduse_wood,spec_type] * sum((joe07,acl)$(acl_spec_type[acl,spec_type]), 1/sCA2V2[spec_type]* sTynd_FRF['ite1',joe07,spec_type,acl,'tynd_use']  * 5* qC5_tynd_FRF[joe07,spec_type,acl,t]))/5;

 
        E_qC5_Energy_FRF[t]$(tF[t])..
                   #Annual gross transfer of carbon stock to energy
                   qC5_Energy_FRF[t] =E= qC5_Energy_FRF_xMill[t] + qC5_Energy_FRF_Mill[t];

        E_qC5_Loss_FRF[t]$(tF[t])..
          qC5_Loss_FRF[t] =E= sum((joe07,spec_type,acl)$(acl_spec_type[acl,spec_type]),   qC5_tynd_FRF[joe07,spec_type,acl,t]*sTynd_FRF['ite1',joe07,spec_type,acl,'tynd_loss'])
                            + sum((joe07,spec_type,acl)$(acl_spec_type[acl,spec_type]), adjloss_C5_FRF[t] * qC5_hoved_FRF[joe07,spec_type,acl,t]*sHTynd_FRF['ite1',joe07,spec_type,acl,'tynd_loss'])/5;

      

        E_adjloss_C5_FRF[t]$(tF[t])..
            qC5_Loss_FRF[t] =E= qC5_GrossHarvest_FRF[t] - qC5_Use_FRF[t] - qC5_Energy_FRF[t];


        #ECONOMY

        #Vi følger IFRO's forlæg, hvor der er regnet kubikmeter priser
        E_vHV2_hoved_FRF[joe07,spec_type,acl,t]$(tF[t] and spec_type_xp[spec_type]).. vHV2_hoved_FRF[joe07,spec_type,acl,t] =E= pHV2_hoved_FRF[joe07,spec_type,acl,t] * qHV2_hoved_FRF[joe07,spec_type,acl,t];
        E_vV2_tynd_FRF[joe07,spec_type,acl,t]$(tF[t] and spec_type_xp[spec_type])..  vV2_tynd_FRF[joe07,spec_type,acl,t]  =E= pV2_tynd_FRF[joe07,spec_type,acl,t]  * qV2_tynd_FRF[joe07,spec_type,acl,t];


    #-------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
    # NATURE RESERVES (NRE) 
    #-------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

      #AREALER 
        E_qF5_NRE[joe07,spec_type,acl,t]$(tF[t] and acl_xinit_term_NRE[acl,spec_type] and d1qF5_NRE[joe07,spec_type,acl,t])..
          qF5_NRE[joe07,spec_type,acl,t] =E= qF5_NRE[joe07,spec_type,acl-1,t-5] - qF5_NRE_deforestation[joe07,spec_type,acl,t];

        E_qF5_NRE_terminal[joe07,spec_type,acl,t]$(tF[t] and acl_terminal_NRE[acl,spec_type] and d1qF5_NRE[joe07,spec_type,acl,t])..
          qF5_NRE[joe07,spec_type,acl,t] =E= qF5_NRE[joe07,spec_type,acl,t-5] + qF5_NRE[joe07,spec_type,acl-1,t-5] - qF5_NRE_deforestation[joe07,spec_type,acl,t];      

        E_qF5_NRE_tot[t]$(tF[t])..
          qF5_NRE_tot[t] =E= sum((joe07,spec_type,acl)$(d1qF5_NRE[joe07,spec_type,acl,t]), qF5_NRE[joe07,spec_type,acl,t]);


        #NRE deforestation er altid konverteret 1:1 til lysåbne områder på den måde det er kodet op. Det er sådan det foregår i fremskrivningen til KF22. Det er desuden nåleskov, der bliver fældet og løvskov, der vokser op (løvskov, der er naturlig bevoksning i DK)
        E_qF5_LYS[joe07,spec_type,acl,t]$(tF[t] and acl_xinit_NRE[acl,spec_type] and d1qF5_LYS[joe07,spec_type,acl,t])..
          qF5_LYS[joe07,spec_type,acl,t] =E= qF5_LYS[joe07,spec_type,acl-1,t-5];

        E_qF5_LYS_new[joe07,spec_type,acl,t]$(tF[t] and acl_init[acl] and d1qF5_LYS[joe07,spec_type,acl,t])..
          qF5_LYS[joe07,spec_type,acl,t] =E= sum((acl_a,spec_type_a)$(NRE_spec_type_2_lyst[spec_type,spec_type_a]), qF5_NRE_deforestation[joe07,spec_type_a,acl_a,t]); #Deforestation in Natural reserves is converted to 'lysåbne områder' with sparse growth let on its own.
     

        E_qF5_LYS_tot[t]$(tF[t])..
          qF5_LYS_tot[t] =E= sum((joe07,spec_type,acl)$(d1qF5_LYS[joe07,spec_type,acl,t]), qF5_LYS[joe07,spec_type,acl,t]);


      #KULSTOFLAGRE
        E_qEmmFstock_NRE[joe07,spec_type,acl,t]$(tF[t] and d1qF5_NRE[joe07,spec_type,acl,t])..
          qEmmFstock_NRE[joe07,spec_type,acl,t] =E= qEmmFstock_NRE.l[joe07,spec_type,acl,t];

        E_qEmmFstock_NRE_tot[t]$(tF[t])..
          qEmmFstock_NRE_tot[t] =E= sum((joe07,spec_type,acl)$(d1qF5_NRE[joe07,spec_type,acl,t]),  qEmmFstock_NRE[joe07,spec_type,acl,t]);      

        E_qEmmFstock_LYS[joe07,spec_type,acl,t]$(tF[t] and d1qF5_LYS[joe07,spec_type,acl,t])..
          qEmmFstock_LYS[joe07,spec_type,acl,t] =E= qEmmFstock_LYS.l[joe07,spec_type,acl,t];

        E_qEmmFstock_LYS_tot[t]$(tF[t])..
          qEmmFstock_LYS_tot[t] =E= sum((joe07,spec_type,acl)$(d1qF5_LYS[joe07,spec_type,acl,t]),  qEmmFstock_LYS[joe07,spec_type,acl,t]);    


        E_qC5_hoved_NRE[joe07,spec_type,acl,t]$(tF[t] and d1qF5_NRE[joe07,spec_type,acl,t])..
          qC5_hoved_NRE[joe07,spec_type,acl,t] =E= qC5_hoved_NRE.l[joe07,spec_type,acl,t];

        E_qC5_tynd_NRE[joe07,spec_type,acl,t]$(tF[t] and d1qF5_NRE[joe07,spec_type,acl,t])..
          qC5_tynd_NRE[joe07,spec_type,acl,t]  =E=  qC5_tynd_NRE.l[joe07,spec_type,acl,t] ; 




        E_qHV2_hoved_NRE[joe07,spec_type,acl,t]$(tF[t] and qC5_hoved_NRE.l[joe07,spec_type,acl,t] and spec_type_xp[spec_type])..
          qHV2_hoved_NRE[joe07,spec_type,acl,t] =E= sum(ite$ite2t(ite,t), sHTyndCorr_NRE[ite,joe07,spec_type,acl] * sHTynd_NRE[ite,joe07,spec_type,acl,'tynd_use']) * qC5_hoved_NRE[joe07,spec_type,acl,t]/5;

       E_qV2_tynd_NRE[joe07,spec_type,acl,t]$(tF[t] and qC5_tynd_NRE.l[joe07,spec_type,acl,t] and spec_type_xp[spec_type])..
          qV2_tynd_NRE[joe07,spec_type,acl,t] =E= sum(ite$ite2t(ite,t), 1/sCA2V2[spec_type]* sTynd_NRE[ite,joe07,spec_type,acl,'tynd_use'])  * qC5_tynd_NRE[joe07,spec_type,acl,t];


        #HWP-kulstoflager fra NRE og lysåbne områder
        E_qC5_usestock_NRE[enduse_wood,spec_type,t]$(tF[t] and spec_type_xp[spec_type])..
        #Stock er det den var for fem år siden. Plus der er vokset til over de sidste fem år
          qC5_usestock_NRE[enduse_wood,spec_type,t] =E=   qC5_usestock_NRE[enduse_wood,spec_type,t-5]* depreciation_factor_usestock[enduse_wood]**5
              #Erstatter med metode baseret på afrundede tal som åbenbart (i vanlig stil) er det der køres med   
               + sUtilization[enduse_wood,spec_type] * sEnduse[enduse_wood] * sHCA2HV2[enduse_wood,spec_type] * sum((joe07,acl,ite)$(acl_spec_type[acl,spec_type] and qC5_hoved_NRE.l[joe07,spec_type,acl,t] and ite2t[ite,t]), sHTyndCorr_NRE[ite,joe07,spec_type,acl] * sHTynd_NRE[ite,joe07,spec_type,acl,'tynd_use'] *    qC5_hoved_NRE[joe07,spec_type,acl,t]) * depreciation_factor_usestock_inflow[enduse_wood]**5
               + sUtilization[enduse_wood,spec_type] * sEnduse[enduse_wood] * sHCA2HV2[enduse_wood,spec_type] * sum((joe07,acl,ite)$(acl_spec_type[acl,spec_type] and qC5_tynd_NRE.l[joe07,spec_type,acl,t] and ite2t[ite,t]), 1/sCA2V2[spec_type]*sTynd_NRE[ite,joe07,spec_type,acl,'tynd_use']  * 5* qC5_tynd_NRE[joe07,spec_type,acl,t]) * depreciation_factor_usestock_inflow[enduse_wood]**5;


        E_qC5_usestock_NRE_tot[t]$(tF[t] or tFinit[t])..
          qC5_usestock_NRE_tot[t] =E= sum((enduse_wood,spec_type_xp), qC5_usestock_NRE[enduse_wood,spec_type_xp,t]);

      #Carbon in annuals harvest 
        E_qC5_GrossHarvest_NRE[t]$(tF[t])..
          #Annual gross harvest of carbon 
          qC5_GrossHarvest_NRE[t] =E=   sum((joe07,spec_type,acl)$(d1qF5_NRE[joe07,spec_type,acl,t]), qC5_tynd_NRE[joe07,spec_type,acl,t]) 
                                      + sum((joe07,spec_type,acl)$(d1qF5_NRE[joe07,spec_type,acl,t]), qC5_hoved_NRE[joe07,spec_type,acl,t])/5;



        E_qC5_Use_NRE[t]$(tF[t])..
          qC5_Use_NRE[t] =E= 
                 sum((enduse_wood,spec_type)$(spec_type_xp[spec_type]), sUtilization[enduse_wood,spec_type] * sEnduse[enduse_wood] * sHCA2HV2[enduse_wood,spec_type] * sum((joe07,acl,ite)$(acl_spec_type[acl,spec_type] and qC5_hoved_NRE.l[joe07,spec_type,acl,t] and ite2t[ite,t]), sHTyndCorr_NRE[ite,joe07,spec_type,acl] * sHTynd_NRE[ite,joe07,spec_type,acl,'tynd_use'] *    qC5_hoved_NRE[joe07,spec_type,acl,t]))/5
                +sum((enduse_wood,spec_type)$(spec_type_xp[spec_type]), sUtilization[enduse_wood,spec_type] * sEnduse[enduse_wood] * sHCA2HV2[enduse_wood,spec_type] * sum((joe07,acl,ite)$(acl_spec_type[acl,spec_type] and qC5_tynd_NRE.l[joe07,spec_type,acl,t] and ite2t[ite,t]), 1/sCA2V2[spec_type]*sTynd_NRE[ite,joe07,spec_type,acl,'tynd_use']  * 5* qC5_tynd_NRE[joe07,spec_type,acl,t]))/5;

      
        E_qC5_Energy_NRE_xMill[t]$(tF[t])..
                  qC5_Energy_NRE_xMill[t] =E= sum((joe07,spec_type,acl,ite)$(d1qF5_NRE[joe07,spec_type,acl,t] and ite2t[ite,t]), sTynd_NRE[ite,joe07,spec_type,acl,'tynd_fuel']  * qC5_tynd_NRE[joe07,spec_type,acl,t]) 
                                            + sum((joe07,spec_type,acl,ite)$(d1qF5_NRE[joe07,spec_type,acl,t] and ite2t[ite,t]), adjloss_C5_NRE[t] * sHTynd_NRE[ite,joe07,spec_type,acl,'tynd_fuel'] * qC5_hoved_NRE[joe07,spec_type,acl,t])/5;
                                       
        E_qC5_Energy_NRE_Mill[t]$(tF[t])..
                  qC5_Energy_NRE_Mill[t] =E=  sum((enduse_wood,spec_type)$(spec_type_xp[spec_type]), (1-sUtilization[enduse_wood,spec_type]) * sEnduse[enduse_wood] * sHCA2HV2[enduse_wood,spec_type] * sum((joe07,acl,ite)$(acl_spec_type[acl,spec_type] and qC5_hoved_NRE.l[joe07,spec_type,acl,t] and ite2t[ite,t]), sHTyndCorr_NRE[ite,joe07,spec_type,acl] * sHTynd_NRE[ite,joe07,spec_type,acl,'tynd_use'] *    qC5_hoved_NRE[joe07,spec_type,acl,t]))/5
                                            + sum((enduse_wood,spec_type)$(spec_type_xp[spec_type]), (1-sUtilization[enduse_wood,spec_type]) * sEnduse[enduse_wood] * sHCA2HV2[enduse_wood,spec_type] * sum((joe07,acl,ite)$(acl_spec_type[acl,spec_type] and qC5_tynd_NRE.l[joe07,spec_type,acl,t] and ite2t[ite,t]), 1/sCA2V2[spec_type]*sTynd_NRE[ite,joe07,spec_type,acl,'tynd_use']  * 5* qC5_tynd_NRE[joe07,spec_type,acl,t]))/5;

        E_qC5_Energy_NRE[t]$(tF[t])..
                   #Annual gross transfer of carbon stock to energy
                   qC5_Energy_NRE[t] =E= qC5_Energy_NRE_xMill[t] + qC5_Energy_NRE_Mill[t];

        E_qC5_Loss_NRE[t]$(tF[t] and sum((joe07,spec_type,acl), d1qF5_NRE[joe07,spec_type,acl,t] and sum(ite$ite2t[ite,t],sHTynd_NRE.l[ite,joe07,spec_type,acl,'tynd_loss'])))..
          qC5_Loss_NRE[t] =E=  sum((joe07,spec_type,acl,ite)$(d1qF5_NRE[joe07,spec_type,acl,t] and ite2t[ite,t]), sTynd_NRE[ite,joe07,spec_type,acl,'tynd_loss']  * qC5_tynd_NRE[joe07,spec_type,acl,t]) 
                             + sum((joe07,spec_type,acl,ite)$(d1qF5_NRE[joe07,spec_type,acl,t] and ite2t[ite,t]), adjloss_C5_NRE[t] * sHTynd_NRE[ite,joe07,spec_type,acl,'tynd_loss'] * qC5_hoved_NRE[joe07,spec_type,acl,t])/5;
                                   


        E_adjloss_C5_NRE[t]$(tF[t])..
            qC5_Loss_NRE[t] =E= qC5_GrossHarvest_NRE[t] - qC5_Use_NRE[t] - qC5_Energy_NRE[t];


        #ECONOMY

          #Vi følger IFRO's forlæg, hvor der er regnet kubikmeter priser
          E_vHV2_hoved_NRE[joe07,spec_type,acl,t]$(tF[t] and qC5_hoved_NRE.l[joe07,spec_type,acl,t]).. vHV2_hoved_NRE[joe07,spec_type,acl,t] =E= pHV2_hoved_NRE[joe07,spec_type,acl,t] * qHV2_hoved_NRE[joe07,spec_type,acl,t];
          E_vV2_tynd_NRE[joe07,spec_type,acl,t]$(tF[t] and qC5_tynd_NRE.l[joe07,spec_type,acl,t])..  vV2_tynd_NRE[joe07,spec_type,acl,t]  =E= pV2_tynd_NRE[joe07,spec_type,acl,t]  * qV2_tynd_NRE[joe07,spec_type,acl,t];




    #-------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
    # AFFORESTATION 
    #-------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

    #AREALER
      E_qF5_aff[skmodel,joe07,spec_type,acl,t]$(tF[t] and acl_xinit[acl,spec_type] and d1qF5_aff[skmodel,joe07,spec_type,acl,t])..
        qF5_aff[skmodel,joe07,spec_type,acl,t] =E= qF5_aff[skmodel,joe07,spec_type,acl-1,t-5]* pSurvival_AFF[skmodel,joe07,spec_type,acl-1]
                                                  +jF5_AFF[skmodel,joe07,spec_type,acl,t]; #Afforestation does not "die" as in the main model. After a full generation it is transferred to main model. However it doesn't matter for the scope of this model as the full generation for both B and C are way past 2099.


      E_qF5_aff_denom[skmodel,joe07,spec_type,acl,t]$(tF[t] and d1qF5_aff[skmodel,joe07,spec_type,acl,t])..
        qF5_aff_denom[skmodel,joe07,spec_type,acl,t] =E= qF5_aff_denom[skmodel,joe07,spec_type,acl-1,t-5]$(acl_xinit[acl,spec_type])
                                                       + qF5_aff[skmodel,joe07,spec_type,acl,t]$(acl_init[acl]);
                                                       #  + qF5_FRF_fromAFF[skmodel,joe07,spec_type,acl,t]$();

      E_qF5_AFF_tot[t]$(tF[t])..
        qF5_AFF_tot[t] =E= sum((skmodel,joe07,spec_type,acl)$(d1qF5_aff[skmodel,joe07,spec_type,acl,t]), qF5_AFF[skmodel,joe07,spec_type,acl,t]);

    #KULSTOFLAGRE 
    #Målt i ktC
    E_qC5_AFF[skmodel,joe07,spec_type,acl,t]$(tF[t] and d1qF5_AFF[skmodel,joe07,spec_type,acl,t])..
      qC5_AFF[skmodel,joe07,spec_type,acl,t] =E= qF5_aff[skmodel,joe07,spec_type,acl,t] * carbon_content_aff[skmodel,joe07,spec_type,acl];

    #Målt i ktCO2e
    E_qEmmFstock_AFF[skmodel,joe07,spec_type,acl,t]$(tF[t] and d1qF5_aff[skmodel,joe07,spec_type,acl,t])..
      qEmmFstock_AFF[skmodel,joe07,spec_type,acl,t] =E= qC5_AFF[skmodel,joe07,spec_type,acl,t] *44/12 + jEmmFstock_AFF[skmodel,joe07,spec_type,acl,t]; 
      #qF5_aff[skmodel,joe07,spec_type,acl,t] * carbon_content_aff[skmodel,joe07,spec_type,acl]*44/12;

    E_qEmmFstock_AFF_tot[t]$(tF[t])..
      qEmmFstock_AFF_tot[t] =E= sum((skmodel,joe07,spec_type,acl)$(d1qF5_aff[skmodel,joe07,spec_type,acl,t]), qEmmFstock_AFF[skmodel,joe07,spec_type,acl,t]);


    #Kulstoflager i tynding 
    E_qC5_tynd_AFF[skmodel,joe07,spec_type,acl,t]$(tF[t] and d1qF5_aff[skmodel,joe07,spec_type,acl,t])..
      qC5_tynd_AFF[skmodel,joe07,spec_type,acl,t] =E= qF5_aff[skmodel,joe07,spec_type,acl,t] * Tynding_coefs_aff[skmodel,joe07,spec_type,acl]
                                                     +jC5_flow_tynd_AFF[skmodel,joe07,spec_type,acl,t];


    #Kulstoflager i hovedskovning
    E_qC5_hoved_AFF[skmodel,joe07,spec_type,acl,t]$(tF[t] and d1qF5_aff[skmodel,joe07,spec_type,acl,t])..
      qC5_hoved_AFF[skmodel,joe07,spec_type,acl,t] =E= qF5_AFF[skmodel,joe07,spec_type,acl-1,t-5] * (1-pSurvival_AFF[skmodel,joe07,spec_type,acl-1]) * AFF_coeffs_data[skmodel,joe07,spec_type,acl,'CA_ha']
                                                      +jC5_flow_hoved_AFF[skmodel,joe07,spec_type,acl,t];

    E_qHV2_hoved_AFF[skmodel,joe07,spec_type,acl,t]$(tF[t] and d1qF5_aff[skmodel,joe07,spec_type,acl,t] and spec_type_xp[spec_type])..
      qHV2_hoved_AFF[skmodel,joe07,spec_type,acl,t] =E=  sHTyndCorr_AFF[skmodel,joe07,spec_type,acl] * sHTynd_AFF[skmodel,joe07,spec_type,acl,'tynd_use'] * qC5_hoved_AFF[skmodel,joe07,spec_type,acl,t]/5;


     E_qV2_tynd_AFF[skmodel,joe07,spec_type,acl,t]$(tF[t] and d1qF5_aff[skmodel,joe07,spec_type,acl,t])..
      qV2_tynd_AFF[skmodel,joe07,spec_type,acl,t] =E= 1/sCA2V2[spec_type] * sTynd_AFF[skmodel,joe07,spec_type,acl,'tynd_use'] * qC5_tynd_AFF[skmodel,joe07,spec_type,acl,t];


    E_qV2_tynd_AFF_firstgen[skmodel,joe07,spec_type,acl,t]$(tF[t] and d1qF5_AFF[skmodel,joe07,spec_type,acl,t] and sum(ite,firstgen(ite,acl) and ite2t(ite,t))).. 
      qV2_tynd_AFF_firstgen[skmodel,joe07,spec_type,acl,t] =E= qV2_tynd_AFF[skmodel,joe07,spec_type,acl,t];

    E_qHV2_hoved_AFF_firstgen[skmodel,joe07,spec_type,acl,t]$(tF[t] and d1qF5_AFF[skmodel,joe07,spec_type,acl,t] and sum(ite,firstgen(ite,acl) and ite2t(ite,t))).. 
      qHV2_hoved_AFF_firstgen[skmodel,joe07,spec_type,acl,t] =E= qHV2_hoved_AFF[skmodel,joe07,spec_type,acl,t];

    #HWP-kulstoflager fra AFF 
    E_qC5_usestock_AFF[enduse_wood,spec_type,t]$(tF[t] and spec_type_xp[spec_type])..
      #Stock er det den var for fem år siden. Plus der er vokset til over de sidste fem år
      qC5_usestock_AFF[enduse_wood,spec_type,t] =E=   qC5_usestock_AFF[enduse_wood,spec_type,t-5] * depreciation_factor_usestock[enduse_wood]**5
                                                                                                                                                  #Hovedskovningen ganges ikke med 5, da det lader til at 
           #  + sUtilization[enduse_wood,spec_type] * sEnduse[enduse_wood] * sum((joe07,acl,skmodel)$(acl_spec_type[acl,spec_type] and d1qF5_aff[skmodel,joe07,spec_type,acl,t]), sHTynd_AFF[skmodel,joe07,spec_type,acl,'tynd_use'] *    qC5_hoved_AFF[skmodel,joe07,spec_type,acl,t]) * depreciation_factor_usestock[enduse_wood]**2.5
           #  + sUtilization[enduse_wood,spec_type] * sEnduse[enduse_wood] * sum((joe07,acl,skmodel)$(acl_spec_type[acl,spec_type] and d1qF5_aff[skmodel,joe07,spec_type,acl,t]), sTynd_AFF[skmodel,joe07,spec_type,acl,'tynd_use']  * 5* qC5_tynd_AFF[skmodel,joe07,spec_type,acl,t]) * depreciation_factor_usestock[enduse_wood]**2.5;
          #Ovenstående erstattes med metode baseret på afrundede tal, som i vanlig stil, er det der køres med fra officiel hold
          + sUtilization[enduse_wood,spec_type] * sEnduse[enduse_wood] * sHCA2HV2[enduse_wood,spec_type] * sum((joe07,acl,skmodel)$(d1qF5_aff[skmodel,joe07,spec_type,acl,t]), sHTyndCorr_AFF[skmodel,joe07,spec_type,acl] * sHTynd_AFF[skmodel,joe07,spec_type,acl,'tynd_use'] *    qC5_hoved_AFF[skmodel,joe07,spec_type,acl,t]) * depreciation_factor_usestock_inflow[enduse_wood]**5
          + sUtilization[enduse_wood,spec_type] * sEnduse[enduse_wood] * sHCA2HV2[enduse_wood,spec_type] * sum((joe07,acl,skmodel)$(d1qF5_aff[skmodel,joe07,spec_type,acl,t]), 1/sCA2V2[spec_type]*sTynd_AFF[skmodel,joe07,spec_type,acl,'tynd_use']  * 5* qC5_tynd_AFF[skmodel,joe07,spec_type,acl,t]) * depreciation_factor_usestock_inflow[enduse_wood]**5;



    E_qC5_usestock_AFF_tot[t]$(tF[t])..
      qC5_usestock_AFF_tot[t] =E= sum((enduse_wood,spec_type_xp),qC5_usestock_AFF[enduse_wood,spec_type_xp,t]);

    #Total carbon in harvest
    E_qC5_usestock_AFF_flow[t]$(tF[t])..
      qC5_usestock_AFF_flow[t] =E= sum((skmodel,joe07,spec_type_xp,acl)$(acl_spec_type[acl,spec_type_xp] and d1qF5_aff[skmodel,joe07,spec_type_xp,acl,t]), 5*qC5_tynd_AFF[skmodel,joe07,spec_type_xp,acl,t] + qC5_hoved_AFF[skmodel,joe07,spec_type_xp,acl,t]);

      #Carbon in annuals harvest 
        E_qC5_GrossHarvest_AFF[t]$(tF[t])..
          #Annual gross harvest of carbon 
          qC5_GrossHarvest_AFF[t] =E=   sum((skmodel,joe07,spec_type,acl)$(d1qF5_aff[skmodel,joe07,spec_type,acl,t]), qC5_tynd_AFF[skmodel,joe07,spec_type,acl,t]) 
                                      + sum((skmodel,joe07,spec_type,acl)$(d1qF5_aff[skmodel,joe07,spec_type,acl,t]), qC5_hoved_AFF[skmodel,joe07,spec_type,acl,t])/5;



        E_qC5_Use_AFF[t]$(tF[t])..
          qC5_Use_AFF[t] =E= 
                 sum((enduse_wood,spec_type)$(spec_type_xp[spec_type]), sUtilization[enduse_wood,spec_type] * sEnduse[enduse_wood] * sHCA2HV2[enduse_wood,spec_type] * sum((joe07,acl,skmodel)$(d1qF5_aff[skmodel,joe07,spec_type,acl,t]), sHTyndCorr_AFF[skmodel,joe07,spec_type,acl] * sHTynd_AFF[skmodel,joe07,spec_type,acl,'tynd_use'] *    qC5_hoved_AFF[skmodel,joe07,spec_type,acl,t]))/5
                +sum((enduse_wood,spec_type)$(spec_type_xp[spec_type]), sUtilization[enduse_wood,spec_type] * sEnduse[enduse_wood] * sHCA2HV2[enduse_wood,spec_type] * sum((joe07,acl,skmodel)$(d1qF5_aff[skmodel,joe07,spec_type,acl,t]), 1/sCA2V2[spec_type]*sTynd_AFF[skmodel,joe07,spec_type,acl,'tynd_use']  * 5* qC5_tynd_AFF[skmodel,joe07,spec_type,acl,t]))/5;

      

        #For afforestation we need to make the distinction between soil-quality. Islands vs. Jutland      
        E_qC5_Energy_AFF_xMill_full[skmodel,joe07,spec_type,acl,t]$(tF[t] and d1qF5_AFF[skmodel,joe07,spec_type,acl,t]).. 

                                                    qC5_Energy_AFF_xMill_full[skmodel,joe07,spec_type,acl,t] =E= 
                                                                                         sTynd_AFF[skmodel,joe07,spec_type,acl,'tynd_fuel']   * qC5_tynd_AFF[skmodel,joe07,spec_type,acl,t]
                                                                                      +  (adjloss_C5_AFF[t] * sHTynd_AFF[skmodel,joe07,spec_type,acl,'tynd_fuel'] * qC5_hoved_AFF[skmodel,joe07,spec_type,acl,t])/5;



        E_qC5_Energy_AFF_xMill[t]$(tF[t])..
                      qC5_Energy_AFF_xMill[t] =E= sum((skmodel,joe07,spec_type,acl)$(d1qF5_AFF[skmodel,joe07,spec_type,acl,t]), qC5_Energy_AFF_xMill_full[skmodel,joe07,spec_type,acl,t]);

        #HOVEDSKOVNINGSBIDRAGT SKAL NOK TJEKKES EFTER HER. HOVEDSKOVNING KORRIGERES OFR GAVNTRÆ, MEN DER MANGLER TILSVARENDE KORREKTIONSFAKTOR SOM FOR TYNDING....BRUGER DERFOR TYNDING I MANGEL AF BEDRE
        E_qV2_Energy_AFF_xMill[t]$(tF[t])..
            qV2_Energy_Aff_xMill[t] =E=   sum((skmodel,joe07,spec_type,acl)$(d1qF5_AFF[skmodel,joe07,spec_type,acl,t]), qV2_Energy_AFF_xMill_FullDim[skmodel,joe07,spec_type,acl,t]);
                                              

        E_qV2_Energy_AFF_xMill_FullDim[skmodel,joe07,spec_type,acl,t]$(tF[t] and d1qF5_AFF[skmodel,joe07,spec_type,acl,t])..
          qV2_Energy_AFF_xMill_FullDim[skmodel,joe07,spec_type,acl,t] =E= 1/sCA2V2[spec_type] *  sTynd_AFF[skmodel,joe07,spec_type,acl,'tynd_fuel']   * qC5_tynd_AFF[skmodel,joe07,spec_type,acl,t]
                                                                      +  1/sCA2V2[spec_type] * (adjloss_C5_AFF[t] * sHTynd_AFF[skmodel,joe07,spec_type,acl,'tynd_fuel'] * qC5_hoved_AFF[skmodel,joe07,spec_type,acl,t])/5;


        E_qC5_Energy_AFF_Mill[t]$(tF[t])..
                                            #Contribution from waste in saw-mills (assuming full utilization of waste as energy-wood)
                    qC5_Energy_AFF_Mill[t] =E=  sum((enduse_wood,spec_type)$(spec_type_xp[spec_type]), (1-sUtilization[enduse_wood,spec_type]) * sEnduse[enduse_wood] * sHCA2HV2[enduse_wood,spec_type] * sum((joe07,acl,skmodel)$(d1qF5_aff[skmodel,joe07,spec_type,acl,t]), sHTyndCorr_AFF[skmodel,joe07,spec_type,acl] * sHTynd_AFF[skmodel,joe07,spec_type,acl,'tynd_use'] *    qC5_hoved_AFF[skmodel,joe07,spec_type,acl,t]))/5
                                              + sum((enduse_wood,spec_type)$(spec_type_xp[spec_type]), (1-sUtilization[enduse_wood,spec_type]) * sEnduse[enduse_wood] * sHCA2HV2[enduse_wood,spec_type] * sum((joe07,acl,skmodel)$(d1qF5_aff[skmodel,joe07,spec_type,acl,t]), 1/sCA2V2[spec_type]*sTynd_AFF[skmodel,joe07,spec_type,acl,'tynd_use']  * 5* qC5_tynd_AFF[skmodel,joe07,spec_type,acl,t]))/5;


        E_qC5_Energy_AFF[t]$(tF[t])..
                   #Annual gross transfer of carbon stock to energy
                   qC5_Energy_AFF[t] =E= qC5_Energy_AFF_xMill[t] + qC5_Energy_AFF_Mill[t];

                                        
        E_qC5_Loss_AFF[t]$(tF[t] and sum((skmodel,joe07,spec_type,acl), d1qF5_aff[skmodel,joe07,spec_type,acl,t] and sHTynd_AFF.l[skmodel,joe07,spec_type,acl,'tynd_loss']))..
            qC5_loss_AFF[t] =E= 
                                  sum((skmodel,joe07,spec_type,acl)$(d1qF5_aff[skmodel,joe07,spec_type,acl,t]), sTynd_AFF[skmodel,joe07,spec_type,acl,'tynd_loss']   * qC5_tynd_AFF[skmodel,joe07,spec_type,acl,t]) 
                                 +sum((skmodel,joe07,spec_type,acl)$(d1qF5_aff[skmodel,joe07,spec_type,acl,t]), adjloss_C5_AFF[t] * sHTynd_AFF[skmodel,joe07,spec_type,acl,'tynd_loss'] * qC5_hoved_AFF[skmodel,joe07,spec_type,acl,t])/5;


        #Bestemmer adjlossc5_aff
        E_adjloss_C5_AFF[t]$(tF[t])..
            qC5_Loss_AFF[t] =E= qC5_GrossHarvest_AFF[t] - qC5_Use_AFF[t] - qC5_Energy_AFF[t];


        #Economics
          E_vHV2_hoved_AFF[skmodel,joe07,spec_type,acl,t]$(tF[t] and d1qF5_aff[skmodel,joe07,spec_type,acl,t]).. 
            vHV2_hoved_AFF[skmodel,joe07,spec_type,acl,t] =E= pHV2_hoved_AFF[skmodel,joe07,spec_type,acl,t] * qHV2_hoved_AFF[skmodel,joe07,spec_type,acl,t];
          E_vV2_tynd_AFF[skmodel,joe07,spec_type,acl,t]$(tF[t] and d1qF5_aff[skmodel,joe07,spec_type,acl,t])..  
            vV2_tynd_AFF[skmodel,joe07,spec_type,acl,t]  =E= pV2_tynd_AFF[skmodel,joe07,spec_type,acl,t]  * qV2_tynd_AFF[skmodel,joe07,spec_type,acl,t];



    #-------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
    # FOREST AGGREGATES 
    #-------------------------------------------------------------------------------------------------------------------------------------------------------------------------#



    #Total forest area
      E_qF5_tot[t]$(tF[t])..
        qF5_tot[t] =E= qF5_FRF_tot[t] + qF5_NRE_tot[t] + qF5_LYS_tot[t] + qF5_AFF_tot[t];

    #The stock of CO2-absorbed in trees
      E_qEmmFStock[t]$(tF[t])..
          qEmmFStock[t] =E= qEmmFstock_FRF_tot[t] + qEmmFstock_NRE_tot[t] + qEmmFstock_LYS_tot[t] + qEmmFstock_AFF_tot[t];


    #Forest-emissions
      E_qEmmF[t]$(tF[t])..
          qEmmF[t] =E= -(qEmmFStock[t] - qEmmFStock[t-5])/5 + 32.23; #32.23 is closer to excel-sheet values #33 ; #33 ktCO2e per year from deforestation, cf. p. 34 KF22skov_drivhusgasregnskab_rapport.pdf


    #Total stock of carbon in HWP
      E_qC5_usestock_tot[t]$(tF[t] or tFinit[t])..
        qC5_usestock_tot[t] =E= qC5_usestock_FRF_tot[t] + qC5_usestock_AFF_tot[t]$(tF[t])+ qC5_usestock_NRE_tot[t]$(tF[t]); 


    #Total inflow of carbon to HWP-stock by end-use
      E_qC5_usestock_inflow[enduse_wood,t]$(tF[t])..
        #Net inflow. The in-period depreciation are counted here as well
        qC5_usestock_inflow[enduse_wood,t] =E= 

                 #Inflow from FRF
                 sum(spec_type$(spec_type_xp[spec_type]),    sUtilization[enduse_wood,spec_type] * sEnduse[enduse_wood] * sHCA2HV2[enduse_wood,spec_type] * sum((joe07,acl)$(acl_spec_type[acl,spec_type]), sHTyndCorr_FRF[joe07,spec_type,acl]  * sHTynd_FRF['ite1',joe07,spec_type,acl,'tynd_use'] *    qC5_hoved_FRF[joe07,spec_type,acl,t]+5*0.000000000000436557$(t.val>=2026 and t.val<=2030 and sameas[spec_type,'B'])) * depreciation_factor_usestock_inflow[enduse_wood]**5
                                +  sUtilization[enduse_wood,spec_type] * sEnduse[enduse_wood] * sHCA2HV2[enduse_wood,spec_type] * sum((joe07,acl)$(acl_spec_type[acl,spec_type]), 1/sCA2V2[spec_type]* sTynd_FRF['ite1',joe07,spec_type,acl,'tynd_use']  * 5* qC5_tynd_FRF[joe07,spec_type,acl,t]) * depreciation_factor_usestock_inflow[enduse_wood]**5
                                   )
                 +
                 #Inflow from Afforestation
                 sum(spec_type$(spec_type_xp[spec_type]),
                                   sUtilization[enduse_wood,spec_type] * sEnduse[enduse_wood] * sHCA2HV2[enduse_wood,spec_type] * sum((joe07,acl,skmodel)$(d1qF5_aff[skmodel,joe07,spec_type,acl,t]), sHTyndCorr_AFF[skmodel,joe07,spec_type,acl] * sHTynd_AFF[skmodel,joe07,spec_type,acl,'tynd_use'] *    qC5_hoved_AFF[skmodel,joe07,spec_type,acl,t]) * depreciation_factor_usestock_inflow[enduse_wood]**5
                                 + sUtilization[enduse_wood,spec_type] * sEnduse[enduse_wood] * sHCA2HV2[enduse_wood,spec_type] * sum((joe07,acl,skmodel)$(d1qF5_aff[skmodel,joe07,spec_type,acl,t]), 1/sCA2V2[spec_type]*sTynd_AFF[skmodel,joe07,spec_type,acl,'tynd_use']  * 5* qC5_tynd_AFF[skmodel,joe07,spec_type,acl,t]) * depreciation_factor_usestock_inflow[enduse_wood]**5
                                )
                 +
                 #Inflow from NRE
                 sum(spec_type$(spec_type_xp[spec_type]),
                                  + sUtilization[enduse_wood,spec_type] * sEnduse[enduse_wood] * sHCA2HV2[enduse_wood,spec_type] * sum((joe07,acl,ite)$(acl_spec_type[acl,spec_type] and qC5_hoved_NRE.l[joe07,spec_type,acl,t] and ite2t[ite,t]), sHTyndCorr_NRE[ite,joe07,spec_type,acl] * sHTynd_NRE[ite,joe07,spec_type,acl,'tynd_use'] *    qC5_hoved_NRE[joe07,spec_type,acl,t]) * depreciation_factor_usestock_inflow[enduse_wood]**5
                                  + sUtilization[enduse_wood,spec_type] * sEnduse[enduse_wood] * sHCA2HV2[enduse_wood,spec_type] * sum((joe07,acl,ite)$(acl_spec_type[acl,spec_type] and qC5_tynd_NRE.l[joe07,spec_type,acl,t] and ite2t[ite,t]), 1/sCA2V2[spec_type]*sTynd_NRE[ite,joe07,spec_type,acl,'tynd_use']  * 5* qC5_tynd_NRE[joe07,spec_type,acl,t]) * depreciation_factor_usestock_inflow[enduse_wood]**5
                                  );
    #Total outflot from HWP stock by end-use
        E_qC5_usestock_outflow[enduse_wood,t]$(tF[t])..
          #Outflow, excl. in-same-period outflow
          qC5_usestock_outflow[enduse_wood,t] =E= sum(spec_type$(spec_type_xp[spec_type]), qC5_usestock_FRF[enduse_wood,spec_type,t-5] * (1-depreciation_factor_usestock[enduse_wood]**5) 
                                                                                          +qC5_usestock_NRE[enduse_wood,spec_type,t-5] * (1-depreciation_factor_usestock[enduse_wood]**5)
                                                                                          +qC5_usestock_AFF[enduse_wood,spec_type,t-5] * (1-depreciation_factor_usestock[enduse_wood]**5)
                                                                                          );
                                                               

    #HWP-emissions are the stock-change 
      E_qEmmHWP[t]$(tF[t])..
        qEmmHWP[t] =E= -44/12*(qC5_usestock_tot[t] - qC5_usestock_tot[t-5])/5 + jEmmHWP[t];

    #Harvest accounts
      E_qC5_harvest[t]$(tF[t]).. qC5_harvest[t] =E= qC5_GrossHarvest_FRF[t] + qC5_GrossHarvest_NRE[t] + qC5_GrossHarvest_AFF[t];

      E_qC5_Use[t]$(tF[t]).. qC5_use[t] =E= qC5_use_FRF[t] + qC5_use_NRE[t] + qC5_Use_AFF[t];

      E_qC5_Energy[t]$(tF[t]).. qC5_Energy[t] =E= qC5_Energy_FRF[t] + qC5_energy_NRE[t] + qC5_energy_AFF[t];
   
      E_qC5_Loss[t]$(tF[t]).. qC5_Loss[t] =E= qC5_Loss_FRF[t] + qC5_Loss_NRE[t] + qC5_Loss_AFF[t];


    #Economic aggregates


      E_vHV2_hoved_FRF_tot[t]$(tF[t])..  vHV2_hoved_FRF_tot[t] =E= sum((joe07,spec_type,acl)$(spec_type_xp[spec_type]), vHV2_hoved_FRF[joe07,spec_type,acl,t]);
      E_vV2_tynd_FRF_tot[t]$(tF[t])..  vV2_tynd_FRF_tot[t]     =E= sum((joe07,spec_type,acl)$(spec_type_xp[spec_type]), vV2_tynd_FRF[joe07,spec_type,acl,t]);

      E_vV2_FRF[t]$(tF[t]).. vV2_FRF[t] =E= vHV2_hoved_FRF_tot[t] + vV2_tynd_FRF_tot[t];


      E_vHV2_hoved_NRE_tot[t]$(tF[t])..  vHV2_hoved_NRE_tot[t] =E= sum((joe07,spec_type,acl)$(qC5_hoved_NRE.l[joe07,spec_type,acl,t]), vHV2_hoved_NRE[joe07,spec_type,acl,t]);
      E_vV2_tynd_NRE_tot[t]$(tF[t])..  vV2_tynd_NRE_tot[t]     =E= sum((joe07,spec_type,acl)$(qC5_tynd_NRE.l[joe07,spec_type,acl,t]), vV2_tynd_NRE[joe07,spec_type,acl,t]);

      E_vV2_NRE[t]$(tF[t]).. vV2_NRE[t] =E= vHV2_hoved_NRE_tot[t] + vV2_tynd_NRE_tot[t];


      E_vHV2_hoved_AFF_tot[t]$(tF[t])..  vHV2_hoved_AFF_tot[t] =E= sum((skmodel,joe07,spec_type,acl)$(d1qF5_aff[skmodel,joe07,spec_type,acl,t]), vHV2_hoved_AFF[skmodel,joe07,spec_type,acl,t]);
      E_vV2_tynd_AFF_tot[t]$(tF[t])..  vV2_tynd_AFF_tot[t]     =E= sum((skmodel,joe07,spec_type,acl)$(d1qF5_aff[skmodel,joe07,spec_type,acl,t]), vV2_tynd_AFF[skmodel,joe07,spec_type,acl,t]);

      E_vV2_AFF[t]$(tF[t]).. vV2_AFF[t] =E= vHV2_hoved_AFF_tot[t] + vV2_tynd_AFF_tot[t];


      E_vV2[t]$(tF[t]).. vV2[t] =E= vV2_FRF[t] + vV2_NRE[t] + vV2_AFF[t];


      #Total output of energy output using a very simple conversion (44/12 = ktCO2e. 103.4 = TJ/tCO2e = PJ/ktCO2e)
      E_qPJ_energyXmill[t]$(tF[t])..  qPJ_energyXmill[t] =E= (qC5_Energy_FRF_xMill[t] + qC5_Energy_NRE_xMill[t] + qC5_Energy_AFF_xMill[t]) * 44/12 /103.4;

      E_qV2[t]$(tF[t]).. qV2[t] =E= sum(spec_type_xp, qV2_spectype[spec_type_xp,t]);

      E_qV2_spectype[spec_type,t]$(tF[t] and spec_type_xp[spec_type])..
                        qV2_spectype[spec_type,t] =E= 
                                    sum((joe07,acl)$(spec_type_xp[spec_type]), qHV2_hoved_FRF[joe07,spec_type,acl,t])                                  + sum((joe07,acl)$(spec_type_xp[spec_type]), qV2_tynd_FRF[joe07,spec_type,acl,t])
                                  + sum((joe07,acl)$(qC5_hoved_NRE.l[joe07,spec_type,acl,t]), qHV2_hoved_NRE[joe07,spec_type,acl,t])                   + sum((joe07,acl)$(qC5_tynd_NRE.l[joe07,spec_type,acl,t]), qV2_tynd_NRE[joe07,spec_type,acl,t])
                                  + sum((skmodel,joe07,acl)$(d1qF5_aff[skmodel,joe07,spec_type,acl,t]), qHV2_hoved_AFF[skmodel,joe07,spec_type,acl,t]) + sum((skmodel,joe07,acl)$(d1qF5_aff[skmodel,joe07,spec_type,acl,t]), qV2_tynd_AFF[skmodel,joe07,spec_type,acl,t])
                                  ;

      E_vV2_spectype[spec_type,t]$(tF[t] and spec_type_xp[spec_type])..
                        vV2_spectype[spec_type,t] =E= 
                                     sum((joe07,acl)$(spec_type_xp[spec_type]), pHV2_hoved_FRF[joe07,spec_type,acl,t] * qHV2_hoved_FRF[joe07,spec_type,acl,t])                                  + sum((joe07,acl)$(spec_type_xp[spec_type]), pV2_tynd_FRF[joe07,spec_type,acl,t] * qV2_tynd_FRF[joe07,spec_type,acl,t])
                                  + sum((joe07,acl)$(qC5_hoved_NRE.l[joe07,spec_type,acl,t]), pHV2_hoved_NRE[joe07,spec_type,acl,t] * qHV2_hoved_NRE[joe07,spec_type,acl,t])                   + sum((joe07,acl)$(qC5_tynd_NRE.l[joe07,spec_type,acl,t]), pV2_tynd_NRE[joe07,spec_type,acl,t] * qV2_tynd_NRE[joe07,spec_type,acl,t])
                                  + sum((skmodel,joe07,acl)$(d1qF5_aff[skmodel,joe07,spec_type,acl,t]), pHV2_hoved_AFF[skmodel,joe07,spec_type,acl,t] * qHV2_hoved_AFF[skmodel,joe07,spec_type,acl,t]) + sum((skmodel,joe07,acl)$(d1qF5_aff[skmodel,joe07,spec_type,acl,t]), pV2_tynd_AFF[skmodel,joe07,spec_type,acl,t] * qV2_tynd_AFF[skmodel,joe07,spec_type,acl,t])
                                  ;

      #Stående lager (ex. juletræer) omregnet til kilo kubikmeter
      E_vV3[t]$(tF[t])..  vV3[t] =E=  sum((joe07,spec_type,acl)$(spec_type_xp[spec_type]), pHV2_hoved_FRF[joe07,spec_type,acl,t] * content_coefs_V3_FRF[joe07,spec_type,acl] * sHTynd_FRF['ite1',joe07,spec_type,acl,'tynd_use'] *qF5_FRF[joe07,spec_type,acl,t])
                                    + sum((joe07,spec_type,acl)$(spec_type_xp[spec_type]), pFirewoodWoodchips[t] * sHTynd_FRF['ite1',joe07,spec_type,acl,'tynd_fuel'] * adjloss_C5_FRF[t] * qC5_FRF[joe07,spec_type,acl,t]) * 44/12 /103.4
                                    + sum((joe07,spec_type,acl)$(spec_type_xp[spec_type] and qF5_NRE.l[joe07,spec_type,acl,t]), pHV2_hoved_FRF[joe07,spec_type,acl,t] * content_coefs_V3_NRE[joe07,spec_type,acl] * sum(ite$(ite2t(ite,t)), sHTynd_NRE[ite,joe07,spec_type,acl,'tynd_use']) * qF5_NRE[joe07,spec_type,acl,t])
                                    + sum((joe07,spec_type,acl)$(spec_type_xp[spec_type] and qF5_NRE.l[joe07,spec_type,acl,t]), pFirewoodWoodchips[t] * adjloss_C5_NRE[t] * sum(ite$(ite2t(ite,t)), sHTynd_NRE[ite,joe07,spec_type,acl,'tynd_fuel']) * qC5_FRF[joe07,spec_type,acl,t])* 44/12 /103.4
                                    + sum((skmodel,joe07,spec_type,acl)$(d1qF5_AFF[skmodel,joe07,spec_type,acl,t]), pHV2_hoved_AFF[skmodel,joe07,spec_type,acl,t] * content_coefs_V3_AFF[skmodel,joe07,spec_type,acl] * sHTynd_AFF[skmodel,joe07,spec_type,acl,'tynd_use'] * qF5_AFF[skmodel,joe07,spec_type,acl,t])
                                    + sum((skmodel,joe07,spec_type,acl)$(d1qF5_AFF[skmodel,joe07,spec_type,acl,t]), pFirewoodWoodchips[t] * adjloss_C5_AFF[t] * sHTynd_AFF[skmodel,joe07,spec_type,acl,'tynd_fuel'] * qF5_AFF[skmodel,joe07,spec_type,acl,t])* 44/12 /103.4;
     
  
$ENDBLOCK

$BLOCK B_lulucf_links 
  

  E_qY_CET_outother_02000_usewood[t]$(tF[t])..
    qY_CET_outother_02000_usewood[t]  =E=  (sum((joe07,spec_type,acl)$(spec_type_xp[spec_type]),                           pHV2_hoved_FRF[joe07,spec_type,acl,t-1] * qHV2_hoved_FRF[joe07,spec_type,acl,t])
                                     +     sum((joe07,spec_type,acl)$(spec_type_xp[spec_type]),                           pV2_tynd_FRF[joe07,spec_type,acl,t-1] * qV2_tynd_FRF[joe07,spec_type,acl,t])  
                                     +     sum((joe07,spec_type,acl)$(qC5_hoved_NRE.l[joe07,spec_type,acl,t]),            pHV2_hoved_NRE[joe07,spec_type,acl,t-1]*qHV2_hoved_NRE[joe07,spec_type,acl,t])
                                     +     sum((joe07,spec_type,acl)$(qC5_tynd_NRE.l[joe07,spec_type,acl,t]),             pV2_tynd_NRE[joe07,spec_type,acl,t-1]*qV2_tynd_NRE[joe07,spec_type,acl,t])
                                     +     sum((skmodel,joe07,spec_type,acl)$(d1qF5_aff[skmodel,joe07,spec_type,acl,t]),  pHV2_hoved_AFF[skmodel,joe07,spec_type,acl,t-1]*qHV2_hoved_AFF[skmodel,joe07,spec_type,acl,t])
                                     +     sum((skmodel,joe07,spec_type,acl)$(d1qF5_aff[skmodel,joe07,spec_type,acl,t]),  pV2_tynd_AFF[skmodel,joe07,spec_type,acl,t-1]*qV2_tynd_AFF[skmodel,joe07,spec_type,acl,t]))
                                           /pY_CET_outother_02000_usewood[t-1]
                                   ; 
  E_pY_CET_outother_02000_usewood[t]$(tF[t])..
    pY_CET_outother_02000_usewood[t] =E=  (sum((joe07,spec_type,acl)$(spec_type_xp[spec_type]),                           pHV2_hoved_FRF[joe07,spec_type,acl,t] * qHV2_hoved_FRF[joe07,spec_type,acl,t])
                                   +     sum((joe07,spec_type,acl)$(spec_type_xp[spec_type]),                           pV2_tynd_FRF[joe07,spec_type,acl,t] * qV2_tynd_FRF[joe07,spec_type,acl,t])  
                                   +     sum((joe07,spec_type,acl)$(qC5_hoved_NRE.l[joe07,spec_type,acl,t]),            pHV2_hoved_NRE[joe07,spec_type,acl,t]*qHV2_hoved_NRE[joe07,spec_type,acl,t])
                                   +     sum((joe07,spec_type,acl)$(qC5_tynd_NRE.l[joe07,spec_type,acl,t]),             pV2_tynd_NRE[joe07,spec_type,acl,t]*qV2_tynd_NRE[joe07,spec_type,acl,t])
                                   +     sum((skmodel,joe07,spec_type,acl)$(d1qF5_aff[skmodel,joe07,spec_type,acl,t]),  pHV2_hoved_AFF[skmodel,joe07,spec_type,acl,t]*qHV2_hoved_AFF[skmodel,joe07,spec_type,acl,t])
                                   +     sum((skmodel,joe07,spec_type,acl)$(d1qF5_aff[skmodel,joe07,spec_type,acl,t]),  pV2_tynd_AFF[skmodel,joe07,spec_type,acl,t]*qV2_tynd_AFF[skmodel,joe07,spec_type,acl,t]))
                                           /qY_CET_outother_02000_usewood[t];
   #Udskiller skovrejsning
   E_qY_CET_outother_02000_usewood_AFF[t]$(tF[t])..     qY_CET_outother_02000_usewood_AFF[t] =E=  
                                                        (sum((skmodel,joe07,spec_type,acl)$(d1qF5_aff[skmodel,joe07,spec_type,acl,t]),  pHV2_hoved_AFF[skmodel,joe07,spec_type,acl,t-1]*qHV2_hoved_AFF[skmodel,joe07,spec_type,acl,t])
                                                  +     sum((skmodel,joe07,spec_type,acl)$(d1qF5_aff[skmodel,joe07,spec_type,acl,t]),  pV2_tynd_AFF[skmodel,joe07,spec_type,acl,t-1]*qV2_tynd_AFF[skmodel,joe07,spec_type,acl,t]))/pY_CET_outother_02000_usewood[t-1];

  
   #Smoother nøglevariable til kobling med CGE
    E_qY_CET_outother_02000_usewood_smooth[t]$(tF[t] and not (tFend[t] or t.val=2098))..
      qY_CET_outother_02000_usewood_smooth[t] =E= 0.2 *  qY_CET_outother_02000_usewood[t-2] +  0.2 * qY_CET_outother_02000_usewood[t-1] + 0.2 * qY_CET_outother_02000_usewood[t] + 0.2 *  qY_CET_outother_02000_usewood[t+1] + 0.2 * qY_CET_outother_02000_usewood[t+2];

    E_qY_CET_outother_02000_usewood_smooth_tFEnd[t]$(tFend[t] or t.val = 2098)..
      qY_CET_outother_02000_usewood_smooth[t] =E= qY_CET_outother_02000_usewood_smooth[t-1];

    E_qY_CET_outother_02000_usewood_AFF_smooth[t]$(tF[t] and not (tFend[t] or t.val=2098))..
      qY_CET_outother_02000_usewood_AFF_smooth[t] =E= 0.2 *  qY_CET_outother_02000_usewood_AFF[t-2] +  0.2 * qY_CET_outother_02000_usewood_AFF[t-1] + 0.2 * qY_CET_outother_02000_usewood_AFF[t] + 0.2 *  qY_CET_outother_02000_usewood_AFF[t+1] + 0.2 * qY_CET_outother_02000_usewood_AFF[t+2];

    E_qY_CET_outother_02000_usewood_AFF_smooth_tFEnd[t]$(tFend[t] or t.val = 2098)..
      qY_CET_outother_02000_usewood_AFF_smooth[t] =E= qY_CET_outother_02000_usewood_AFF_smooth[t-1];


    E_qPJ_energyXmill_smooth[t]$(tF[t] and not (tFend[t] or t.val=2098))..
      qPJ_energyXmill_smooth[t] =E= 0.2 * qPJ_energyXmill[t-2] + 0.2 * qPJ_energyXmill[t-1] + 0.2 * qPJ_energyXmill[t] +  0.2 * qPJ_energyXmill[t+1] + 0.2 * qPJ_energyXmill[t+2];

    E_qPJ_energyXmill_smooth_tFEnd[t]$(tFend[t] or t.val = 2098)..
      qPJ_energyXmill_smooth[t] =E= qPJ_energyXmill_smooth[t-1];

    E_qC5_Energy_AFF_xMill_smooth[t]$(tF[t] and not (tFend[t] or t.val=2098))..
      qC5_Energy_AFF_xMill_smooth[t] =E= 0.2 * qC5_Energy_AFF_xMill[t-2]*44/12/103.4 + 0.2 * qC5_Energy_AFF_xMill[t-1]*44/12/103.4 + 0.2 * qC5_Energy_AFF_xMill[t]*44/12/103.4 +  0.2 * qC5_Energy_AFF_xMill[t+1]*44/12/103.4 + 0.2 * qC5_Energy_AFF_xMill[t+2]*44/12/103.4;

    E_qC5_Energy_AFF_xMill_smooth_tFEnd[t]$(tFend[t] or t.val = 2098)..
      qC5_Energy_AFF_xMill_smooth[t] =E= qC5_Energy_AFF_xMill_smooth[t-1];



  E_qD_usewood_CGE[t]$(tx0[t]).. qD_usewood_CGE[t] =E= qRxE_y['16000','02000',t] + qRxE_y['13150','02000',t] + qRxE_y['41430','02000',t] + qX_y['xOth','02000',t] ;

  E_restrict[t]$(tx0[t] and tF[t]).. qY_CET_outother_02000_usewood_smooth[t] =E= qD_usewood_CGE[t] + j_qY_CET_outother_02000_usewood_CGE[t];


  E_restrict_energy[t]$(tx0[t] and tF[t]).. qPJ_energyXmill_smooth[t]*(1$(ite1skov) +growth_factor[t]$(not ite1skov)) =E= qY_CET['firewood and woodchips','02000',t] + j_PJ_energyXmill_smooth[t];


  E_pHV2_hoved_FRF[joe07,spec_type,acl,t]$(tx0[t] and tF[t] and spec_type_xp[spec_type] and acl_spec_type[acl,spec_type] and pHV2_hoved_FRF.l[joe07,spec_type,acl,t]).. 
    pHV2_hoved_FRF[joe07,spec_type,acl,t]/pHV2_hoved_FRF[joe07,spec_type,acl,t-1] =E= pY_CET_usewoodtot[t]/pY_CET_usewoodtot[t-1] + j_pHV2_hoved_FRF[joe07,spec_type,acl,t];

  E_pV2_tynd_FRF[joe07,spec_type,acl,t]$(tx0[t] and tF[t] and spec_type_xp[spec_type] and acl_spec_type[acl,spec_type] and pV2_tynd_FRF.l[joe07,spec_type,acl,t]).. 
    pV2_tynd_FRF[joe07,spec_type,acl,t]/pV2_tynd_FRF[joe07,spec_type,acl,t-1] =E= pY_CET_usewoodtot[t]/pY_CET_usewoodtot[t-1] + j_pV2_tynd_FRF[joe07,spec_type,acl,t];


  E_pHV2_hoved_NRE[joe07,spec_type,acl,t]$(tx0[t] and tF[t] and qC5_hoved_NRE.l[joe07,spec_type,acl,t] and pHV2_hoved_NRE.l[joe07,spec_type,acl,t]).. 
    pHV2_hoved_NRE[joe07,spec_type,acl,t]/pHV2_hoved_NRE[joe07,spec_type,acl,t-1] =E= pY_CET_usewoodtot[t]/pY_CET_usewoodtot[t-1] + j_pHV2_hoved_NRE[joe07,spec_type,acl,t];


  E_pV2_tynd_NRE[joe07,spec_type,acl,t]$(tx0[t] and tF[t] and qC5_tynd_NRE.l[joe07,spec_type,acl,t] and pV2_tynd_NRE.l[joe07,spec_type,acl,t]).. 
    pV2_tynd_NRE[joe07,spec_type,acl,t]/pV2_tynd_NRE[joe07,spec_type,acl,t-1] =E= pY_CET_usewoodtot[t]/pY_CET_usewoodtot[t-1] + j_pV2_tynd_NRE[joe07,spec_type,acl,t];


  E_pHV2_hoved_AFF[skmodel,joe07,spec_type,acl,t]$(tx0[t] and tF[t] and d1qF5_aff[skmodel,joe07,spec_type,acl,t] and pHV2_hoved_AFF.l[skmodel,joe07,spec_type,acl,t]).. 
    pHV2_hoved_AFF[skmodel,joe07,spec_type,acl,t] =E= pHV2_hoved_AFF_data[skmodel,joe07,spec_type,acl,t] * pY_CET_usewoodtot[t]/pY_CET_usewoodtot_baseline[tFstart] + j_pHV2_hoved_AFF[skmodel,joe07,spec_type,acl,t];


  E_pHV2_hoved_AFF_lagged[skmodel,joe07,spec_type,acl,t]$(tx0[t] and tF[t] and (d1qF5_aff[skmodel,joe07,spec_type,acl,t+1] and not d1qF5_aff[skmodel,joe07,spec_type,acl,t]) and pHV2_hoved_AFF.l[skmodel,joe07,spec_type,acl,t]).. 
      pHV2_hoved_AFF[skmodel,joe07,spec_type,acl,t] * pY_CET_usewoodtot[t+1]/pY_CET_usewoodtot[t] =E= pHV2_hoved_AFF[skmodel,joe07,spec_type,acl,t+1];

 E_pV2_tynd_AFF[skmodel,joe07,spec_type,acl,t]$(tx0[t] and tF[t] and d1qF5_aff[skmodel,joe07,spec_type,acl,t] and pV2_tynd_AFF.l[skmodel,joe07,spec_type,acl,t]).. 
     pV2_tynd_AFF[skmodel,joe07,spec_type,acl,t] =E= pV2_tynd_AFF_data[skmodel,joe07,spec_type,acl,t] * pY_CET_usewoodtot[t]/pY_CET_usewoodtot_baseline[tFstart] + j_pV2_tynd_AFF[skmodel,joe07,spec_type,acl,t];
 

  E_pV2_tynd_AFF_lagged[skmodel,joe07,spec_type,acl,t]$(tx0[t] and tF[t] and (d1qF5_aff[skmodel,joe07,spec_type,acl,t+1] and not d1qF5_aff[skmodel,joe07,spec_type,acl,t]) and pV2_tynd_AFF.l[skmodel,joe07,spec_type,acl,t]).. 
    pV2_tynd_AFF[skmodel,joe07,spec_type,acl,t] * pY_CET_usewoodtot[t+1]/pY_CET_usewoodtot[t] =E= pV2_tynd_AFF[skmodel,joe07,spec_type,acl,t+1];
  

  E_pFirewoodWoodchips[t]$(tx0[t] and tF[t] and d1vY_CET['firewood and woodchips','02000',t])..
    pFirewoodWoodchips[t] =E= pY_CET['Firewood and woodchips','02000',t];  

  #  #Vedmassen værdisættes ud fra hovedskovningspriser
  #  E_qI_s_invt_02000[t]$(tx0[t] and tF[t])..
  #    pI_s['invt','02000',t] * qI_s['invt','02000',t] =E= vV3[t] - vV3[t-1]; #skovinvt

  #Det koster 63 tkr. per ha for lavbonitets skovrejsning og 65 tkr per ha for højbonitets skovrejsning
  E_qI_s_afforestation[t]$(tx0[t] and tF[t] and sum((skmodel,joe07,spec_type), d1qF5_aff[skmodel,joe07,spec_type,'acl5',t]))..
                                                                                                                                                                             #Der divideres med 5 fordi det totale skovmodellen opererer på totalt rejst areal over fem-års periode 
     pY_CET['out_other','02000',t] * qI_s_afforestation[t] =E= pI_afforestation_external['Jutland']/10**9 * sum((skmodel,spec_type)$(d1qF5_aff[skmodel,'jutland',spec_type,'acl5',t]), qF5_AFF[skmodel,'Jutland',spec_type,'acl5',t]/5)*1000
                                                            + pI_afforestation_external['islands']/10**9 * sum((skmodel,spec_type)$(d1qF5_aff[skmodel,'Islands',spec_type,'acl5',t]), qF5_AFF[skmodel,'Islands',spec_type,'acl5',t]/5)*1000;


  E_pY_CET_usewood_tot[t]$(tx0[t] and tF[t])..
    pY_CET_usewoodtot[t] =E= pY_CET['out_other','02000',t]+pWoodproduct_markup[t];


  #SKOVNINGSOMKOSTNINGER
    #Hugstpriser 
    E_pHugstomk_usew[t]$(tx0[t] and tF[t])..    pHugstomk_usew[t] =E= pHugstomk_usew[t-1]*pY0['02000',t]/pY0['02000',t-1]; 
    E_pHugstomk_firew[t]$(tx0[t] and tF[t])..  pHugstomk_firew[t] =E= pHugstomk_firew[t-1]*pY0['02000',t]/pY0['02000',t-1];



    #We now build up costs up bottom-up - we use a price of 100 kroner per cubic meter of use-wood harvested
      E_vTotalCost_targetfromIfro_hugst[t]$(tF[t])..
        vTotalCost_targetfromIfro_hugst[t] =E= sum((skmodel,joe07,spec_type,acl)$(d1qF5_AFF[skmodel,joe07,spec_type,acl,t]),  pHugstomk_usew[t] * qHV2_hoved_AFF[skmodel,joe07,spec_type,acl,t]) 
                                              +sum((skmodel,joe07,spec_type,acl)$(d1qF5_AFF[skmodel,joe07,spec_type,acl,t]),  pHugstomk_usew[t] * qV2_tynd_AFF[skmodel,joe07,spec_type,acl,t]); 

      #Den her bestemmer sUseWood_AFF
      E_vTotalCost_parity_hugst[t]$(tx0[t] and tF[t] and qC5_Use_AFF.l[t])..
              vTotalCost_targetfromIfro_hugst[t] =E= vTotalCost_hugst_sum[t];

      #Bottom-up cost of harvesting firewood
      E_vTotalCost_targetfromIfro_firew[t]$(tF[t])..
              vTotalCost_targetfromIfro_firew[t] =E=  sum((skmodel,joe07,spec_type,acl)$(d1qF5_AFF[skmodel,joe07,spec_type,acl,t]),  pHugstomk_firew[t] * qV2_Energy_AFF_xMill_FullDim[skmodel,joe07,spec_type,acl,t]); 


      #Den her bestemmer sFireWood_AFF
      E_vTotalCost_parity_firew[t]$(tx0[t] and tF[t] and qC5_Energy_AFF.l[t])..
        vTotalCost_targetfromIfro_firew[t] =E= vTotalCost_firew_sum[t];


      #Den her ligning beregner den totale omkostning af at hugge gavntræ i CGE_modellen 
      E_vTotalCost_hugst[skmodel,joe07,spec_type,acl,t]$(tF[t] and d1qF5_AFF[skmodel,joe07,spec_type,acl,t])..
            vTotalCost_hugst[skmodel,joe07,spec_type,acl,t]  =E= 
                                                            ((pHV2_hoved_AFF[skmodel,joe07,spec_type,acl,t-1] * qHV2_hoved_AFF[skmodel,joe07,spec_type,acl,t]/pY_CET_outother_02000_usewood[t-1] 
                                                             +pV2_tynd_AFF[skmodel,joe07,spec_type,acl,t-1]* qV2_tynd_AFF[skmodel,joe07,spec_type,acl,t]/pY_CET_outother_02000_usewood[t-1])
                                                            #Gang det med CGE-prisen og så får man total revenue 
                                                            * (pY_CET['out_other','02000',t])/
                                                              (vY['02000',t]) 
                                     *(1-sUseWood_AFF[t]) * (pKELBM['02000',t]*qKELBM['02000',t] - sum(k, pK[k,'02000',t]*qK[k,'02000',t-1]/fq)))
                                                             
                                                             ;

      #Total cost of harvesting afforestation use-wood, measured in the CGE-units
      E_vTotalCost_hugst_sum[t]$(tF[t]).. vTotalCost_hugst_sum[t] =E= sum((skmodel,joe07,spec_type,acl)$(d1qF5_AFF[skmodel,joe07,spec_type,acl,t]), vTotalCost_hugst[skmodel,joe07,spec_type,acl,t]);



      E_vTotalCost_firew[skmodel,joe07,spec_type,acl,t]$(tF[t] and d1qF5_aff[skmodel,joe07,spec_type,acl,t])..  
          vTotalCost_firew[skmodel,joe07,spec_type,acl,t]  =E= 
                                                            (qC5_Energy_AFF_xMill_full[skmodel,joe07,spec_type,acl,t] *44/12/103.4) * pY_CET['firewood and woodchips','02000',t]/
                                                            (vY['02000',t])
                                    *(1-sFireWood_AFF[t]) * (pKELBM['02000',t]*qKELBM['02000',t] - sum(k, pK[k,'02000',t]*qK[k,'02000',t-1]/fq))                                                          
                                                           ; 

      #Total cost of harvesting afforestation energy-wood measured in CGE-units
      E_vTotalCost_firew_sum[t]$(tF[t]).. vTotalCost_firew_sum[t] =E=  sum((skmodel,joe07,spec_type,acl)$(d1qF5_AFF[skmodel,joe07,spec_type,acl,t]), vTotalCost_firew[skmodel,joe07,spec_type,acl,t]);



      #Total cost of harvesting in CGE-units - this could be changed to a reporting equation 
      E_vTotalCost[skmodel,joe07,spec_type,acl,t]$(tF[t] and d1qF5_aff[skmodel,joe07,spec_type,acl,t]).. 
        vTotalCost[skmodel,joe07,spec_type,acl,t] =E= vTotalCost_hugst[skmodel,joe07,spec_type,acl,t] + vTotalCost_firew[skmodel,joe07,spec_type,acl,t];

      E_pTotalOperatingSurplus_AFF[t]$(tF[t] and sum((skmodel,joe07,spec_type,acl), d1qF5_AFF[skmodel,joe07,spec_type,acl,t])).. 
        pTotalOperatingSurplus_AFF[t] * sum((skmodel,joe07,spec_type,acl)$(d1qF5_AFF[skmodel,joe07,spec_type,acl,t]), qF5_AFF_denom[skmodel,joe07,spec_type,acl,t])
                                   =E= sum((skmodel,joe07,spec_type,acl)$(d1qF5_AFF[skmodel,joe07,spec_type,acl,t]),  vHV2_hoved_AFF[skmodel,joe07,spec_type,acl,t])
                                      +sum((skmodel,joe07,spec_type,acl)$(d1qF5_AFF[skmodel,joe07,spec_type,acl,t]),  vV2_tynd_AFF[skmodel,joe07,spec_type,acl,t])
                                      +sum((skmodel,joe07,spec_type,acl)$(d1qF5_AFF[skmodel,joe07,spec_type,acl,t]), qC5_Energy_AFF_xMill_full[skmodel,joe07,spec_type,acl,t] *44/12/103.4) * pY_CET['firewood and woodchips','02000',t]
                                      +sum((joe07,spec_type,acl)$(sum(skmodel,d1qF5_AFF[skmodel,joe07,spec_type,acl,t]) and sHTynd_FRF.l['ite1',joe07,spec_type,acl,'tynd_use']), pHV2_hoved_FRF[joe07,spec_type,acl,t] *  qHV2_hoved_FRF_fromAFF[joe07,spec_type,acl,t])                                                                     
                                      +sum((joe07,spec_type,acl)$(sum(skmodel,d1qF5_AFF[skmodel,joe07,spec_type,acl,t]) and sTynd_FRF.l['ite1',joe07,spec_type,acl,'tynd_use']), pV2_tynd_FRF[joe07,spec_type,acl,t] * qV2_tynd_FRF_fromAFF[joe07,spec_type,acl,t])
                                      -vTotalCost_hugst_sum[t]
                                      -vTotalCost_firew_sum[t]
                                      ;

$ENDBLOCK


 
$MODEL M_LULUCF B_lulucf, B_lulucf_links;

$ENDIF


# ======================================================================================================================
# Exogenous variables
# ======================================================================================================================
$IF %stage% == "exogenous_values":

#The data part is separated into a part for LULUC and a part for F. We start with LULUC 

#1) READ DATA 

  #Land-use (LU) and land-use-change (LUC) 

    #We stray from usual principles and do a computation on the arealmatrice 
      #Plugging areamatrix from before 1990 (KF23 matrix) into 
      Arealmatrice[t,land8_s,land8_r]$(t.val<1990) = arealmatrice_KF23[t,land8_s,land8_r];

      #Plugging sea into area-matrix before 1991
      Arealmatrice[t,'sea','sea']$(t.val<1991) = Arealmatrice['1991','sea','sea']; 

      #To kha 
      Arealmatrice[t,land8_s,land8_r] = Arealmatrice[t,land8_s,land8_r]/1000;

      #Extending beyond 2050 
      Arealmatrice[t,land8_s,land8_r]$(t.val>2050) = Arealmatrice['2050',land8_s,land8_r];

 
    qLU8.l[land8_r,t]$(t.val<1990)                           = sum(land8_s$(sameas[land8_r,land8_s]), arealmatrice[t,land8_s,land8_r]);
    qLU8.l[land8_r,t]$(t.val>=1990)                          = sum(land8_s, arealmatrice[t,land8_s,land8_r]);
    #Using "sea" as residual to keep total area constant (the total area in raw data changes a little over time for unknown reasons)
    qLU8.l['SEA',t] = sum(land8_s, qLu8.l[land8_s,'2050']) - sum(land8_r$(not sameas[land8_r,'sea']), qLU8.l[land8_r,t]); #We keep 2050 areas as reference

    qLUC8.l[land8_s,land8_r,t]$(t.val<1990 and not sameas[land8_s,land8_r]) = arealmatrice[t,land8_s,land8_r];


    qLU5.l[land5,t] = sum(land8$(land52land8[land5,land8]), qLu8.l[land8,t]);

    organic_soils[land12xF,t]$(t.val>2050) = organic_soils[land12xF,'2050'];
    organic_soils[land12xF,t]$(t.val<1990) = organic_soils[land12xF,'1990'];
      

  #Emissions 
    qEmmLUC5.l[land5,t]      = LULUCF_data["LUC_ktco2",land5,t];
    qEmmPeatland.l['CH4',t]  = peatland_nonCO2[t,'CH4']; qEmmPeatland.l['N2O',t] = peatland_nonCO2[t,'N2O']; qEmmPeatland.l['CO2ubio',t] = peatland_CO2[t];  

    qEmmHedgeRows.l[land12,t]                = kulstofpulje_levendebiomasse[t,land12]; 
    qEmmHedgeRows.l[land12,t]$(t.val > 2050) = qEmmHedgeRows.l[land12,'2050'];
    qEmmForestsoil.l[t]                      = forest_carbonsoil_total[t];
    qEmmForestsoil.l[t]$(t.val > 2050)       = qEmmForestsoil.l['2050'];

    qEmmTable4iii_settlement.l[t]              = Table4III_bebyggelse[t];
    qEmmTable4iii_settlement.l[t]$(t.val>2050) = qEmmTable4iii_settlement.l['2050'];

     
    qEmmLULUCF5.l[land5,t]    = LULUCF_data["tot_ktco2",land5,t];
    qEmmLU12xF.l['crop_u6',t] = LULUCF_data["lu_ktCO2",'crop_u6',t];
    qEmmLU12xF.l['grass_u6',t]= LULUCF_data["lu_ktCO2",'grass_u6',t];

   #Check if we can't compute the all of table 4ii now
      qEmmHWP.l[t]                                     = LULUCF_data["tot_ktco2","hwp",t];
      qEmmF_soil.l[t]                                  = 123 + 17 + 28; # Comes from DNFAP p. 48 - SKAL DEN HER OPDATERES MED MINERAL JORD + KULSTOFRIG JORD i TABEL 2 I KF21_LULUCF.XLSX
      uEmmInstantOxiLUCinF.l["forest","crop_u6"]       = 5.1*(44/28)*GWP.l['N2O']*(10**3)/(10**6); # cf DNEI2020 p. 474 - convert kg N2O-N  per hectare to kilotons CO2e per 1000 hectares. Atomic weight of N is 14 and it binds an oxygen molecule of weight 16. 
      uEmmInstantOxiLUCinF.l["forest","crop_6_12"]     = uEmmInstantOxiLUCinF.l["forest","crop_u6"];
      uEmmInstantOxiLUCinF.l["forest","crop_o12"]      = uEmmInstantOxiLUCinF.l["forest","crop_u6"];

      uEmmInstantOxiLUCinF.l['forest','water'] = 5.1*(44/28)*GWP.l['N2O']*(10**3)/(10**6);


#2) EXOGENOUS VALUES

  #LAND-USE-CHANGE RELATED PARAMETERS AND EMISSIONS-COEFFICIENTS
  parameter adjustmentxF /30/;        # 30-year adjustment period for non-forest
  parameter adjustmentF /100/;        # 100-year adjustment period for forest
  parameter adjustmentFbiomass /25/;  # 25-year adjustment for biomass in forests, cf. excel-sheet from Vivian IGN 

  # Soil stocks: Use "broken-stick approach" (i.e. assume steady state in 1990) - no changes before 1990 (since there are no recorded land use changes before 1990). AKB: Double check this. 
  uSoilStock12.l[tt,t,land12xF]  = 1/adjustmentxF;
  uSoilStock12.l[tt,t,"forest"]  = 1/adjustmentF;

  # No adjustment process for wetlands/water
    uSoilStock12.l[tt,t,land12xF]$(sameas(land12xF,"wetland")) = 0;
    uSoilStock12.l[tt,t,land12xF]$(sameas(land12xF,"water"))   = 0;
    
  # Set adjustment period to 30 years back in time for non-forest
    uSoilStock12.l[tt,t,land12xF]$(not (tt.val<=t.val and tt.val>(t.val-30))) = 0;
  # Set adjustment period to 100 years for forest
    uSoilStock12.l[tt,t,'forest']$(not (tt.val<=t.val and tt.val>(t.val-100))) = 0;

  #When land is converted to to forest the biomass on the forest floor is assumed to change over a 25-year period 
    uBiomass12.l[tt,t,"forest"]    = 1/adjustmentFbiomass;
    uBiomass12.l[tt,t,"forest"]$(not (tt.val <=t.val and tt.val>(t.val-25))) = 0;

  #When SOC > 12 % crop and grassland is converted to wetlands a standard emission factor of 288 kg methane per ha annually is applied 
    uLUConv12xF.l["crop_o12","wetland"]    = 288*GWP.l['CH4']*(10**3)/(10**6); # cf. "PROJECTION OF GREENHOUSE GASES 2019-2040" table 8.2 - convert kg CH4 per hectare to kilotons CO2e per 1000 hectares
    uLUConv12xF.l["grass_o12","wetland"]   = 288*GWP.l['CH4']*(10**3)/(10**6); # cf. "PROJECTION OF GREENHOUSE GASES 2019-2040" table 8.2 - convert kg CH4 per hectare to kilotons CO2e per 1000 
    #According to Signe Borgen from ENS the eemission applies also to medium SOC-soils. cf. mail on the 23/8/2022
    uLUConv12xF.l["crop_6_12","wetland"]   = 0.5*288*GWP.l['CH4']*(10**3)/(10**6); # cf. "PROJECTION OF GREENHOUSE GASES 2019-2040" table 8.2 - convert kg CH4 per hectare to kilotons CO2e per 1000 
    uLUConv12xF.l["grass_6_12","wetland"]  = 0.5*288*GWP.l['CH4']*(10**3)/(10**6); # cf. "PROJECTION OF GREENHOUSE GASES 2019-2040" table 8.2 - convert kg CH4 per hectare to kilotons CO2e per 1000 

  
  #Carbon content per dry-matter. NIR can't make up its mind wrt. if it's 0.5 or 0.47. Imputing from the official tables suggest that DCE has stuck with 0.5 in spite of writing 0.47
    uDM2C.l[land12_r] = 0.5;

  #SOIL STOCK CARBON CONTENT
  #The input data is taken from table 6.10 in 2021 DNEI. It is the sum of living above ground, and below ground biomass. If you compare to the values in table 6.10 you'll find that the values have been converted from kg dry matter per ha. to kg. C per ha. The conversion factor is 0.47 g C per g drymatter. And is also taken from that section of DNEI
  qSoilStock9.l[land12xF]          = LULUCF_data["c_stock_default",land12xF,'2015']*44/12/(10**6)*(10**3); # from kg C per ha to 1.000 tons CO2 per 1000 ha
  qSoilStock9.l["forest"]           = qSoilStock9.l["grass_u6"];
  qSoilStock9.l['Christmas trees'] = 120.8 * 44/12;

  #BIOMASS STOCK FOR LAND-USES, DRY-MATTER CONTENT                                
  qBiomassStock9.l[land12_grass]      = (2200 + 6160)/1000;  #t DM per ha, table 6.10 in NIR21, p. 476
  qBiomassStock9.l[land12_crop]       = (9577 + 2298)/1000;  #t DM per ha, table 6.10 in NIR21, p. 476
  qBiomassStock9.l['wetland']         = (3600 + 10080)/1000; #t DM per ha, table 6.10 in NIR21. In the NIR paragraph on Wetlands it claims that 3600 + 1200 are used for gains, but that is not consistent with reported numbers which matches table 6.10
  qBiomassStock9.l['water']           = 0; #No gains for fully covered water 
  qBiomassStock9.l['Forest']          = 0; #Is computed in forest module and not by standard values
  qBiomassStock9.l['Christmas trees'] = (21277 + 4255)/1000; #t DM per ha, table 6.10 in NIR21, p. 476

#3) COMPUTATIONS 
  
  #Land-use (LU) and land-use-change (LUC) 

    #qLUC5 
      qLUC5.l[land5_s,land5_r,t]$(not sameas[land5_s,land5_r]) = sum((land8_s,land8_r)$(land52land8(land5_s,land8_s) and land52land8(land5_r,land8_r)) , qLUC8.l[land8_s,land8_r,t]);

    #qLU12
      qLU12.l[land12,t]   = sum(land8$land82land12[land8,land12], qLU8.l[land8,t]/sum(land12_a$land82land12[land8,land12_a], 1));

    #For organic crop and grassland we replace by bottom-up numbers. We still want to hit the overall numbers for the two types and mineral soils are computed as the residual
      qLU12.l[land12_OC_GL_CL,t] =  organic_soils[land12_OC_GL_CL,t];
      qLU12.l['crop_u6',t]  = qLU5.l['crop',t]   - qLU12.l['crop_6_12',t]  - qLU12.l['crop_o12',t];
      qLU12.l['grass_u6',t] = qLU5.l['grass',t]  - qLU12.l['grass_6_12',t] - qLU12.l['grass_o12',t];

       #We do not know the transition matrix on this level and therefore compute a best guess. Possibly parts of it can be calibrated historically based on emissions on the 12 level
      #The LUC12 matrix is calibrated in the static-calibration
      # qLUC12.l[land12_s,land12_r,t]$(qLU12.l[land12_r,t]) 
      #   = sum((land8_s,land8_r)$(land82land12[land8_s,land12_s] and land82land12[land8_r,land12_r]), qLUC8.l[land8_s,land8_r,t]) * 
      #       qLU12.l[land12_s,t]/sum(land8_s$(land82land12[land8_s,land12_s]), qLU8.l[land8_s,t]) * qLU12.l[land12_r,t]/sum(land8_r$(land82land12[land8_r,land12_r]), qLU8.l[land8_r,t]);

      qLUC12_baseline.l[land12_s,land12_r,t] = qLUC12.l[land12_s,land12_r,t];   
      #For conversions of grassland to cropland, and vice versa most of the historic transitions are not permanent, but temporary transitions. 
      d1noLUC12inbase[land12_s,land12_r]        = no;
      d1noLUC12inbase[land12_crop,land12_grass] = yes;
      d1noLUC12inbase[land12_grass,land12_crop] = yes;
           
 
    #Emissions 
        qEmmLULUCF.l[t] = sum(land5,qEmmLULUCF5.l[land5,t]) + qEmmHWP.l[t];

    #Experiments
        qEmmLUC12.l[land12_r,t] = 44/12 * uDM2C.l[land12_r] * sum(land12_s$(not sameas[land12_r,'forest']), qLUC12.l(land12_s,land12_r,t)*(qBiomassStock9.l[land12_s]-qBiomassStock9.l[land12_r])) 
                      + 44/12 * uDM2C.l[land12_r] * sum(tt$(tt.val<=t.val), sum(land12_s$(d1qLUC12[land12_s,land12_r,tt] and sameas[land12_r,'forest']),   qLUC12.l[land12_s,land12_r,tt] * uBiomass12.l[tt,t,land12_r] * (qBiomassStock9.l[land12_s]-qBiomassStock9.l[land12_r])))
                      + sum(tt$(tt.val<=t.val), sum(land12_s$(d1qLUC12[land12_s,land12_r,tt]), qLUC12.l(land12_s,land12_r,tt)*(qSoilStock9.l[land12_s]-qSoilStock9.l[land12_r])*uSoilStock12.l[tt,t,land12_r]));

    loop(t,
    qEmmTable4ii_wetland.l[t] = 
         sum(emm$(not sameas[emm,'CO2ubio']), qEmmPeatland.l[emm,t]*GWP.l[emm]) 
      +  sum(land12xF$(sameas[land12xF,'Wetland']),
             sum((tt,land12xf_a)$(tt.val<t.val and tt.val>=%bf_start% and d1uLUConv12xF[land12xf_a,land12xF]), uLUConv12xF.l[land12xf_a,land12xF]*qLUC12.l[land12xf_a,land12xF,tt]$(d1qLUC12[land12xf_a,land12xF,tt])))
        );


#4) INITIAL VALUES 

   #Grass-and cropland emissions on organic soils. The N2O emissions, cf. 'LULUCF_sammenligning.xlsx' are not part of the BU-emissions as they are accounted for in the agriculture (Table 3.D i in CRF i believe the N2O emissions are stored - AKB)
      uLU12xF.l['crop_o12',t]                       = 1;
      uLU12xF.l['crop_6_12',t]                      = 1;
      uLU12xF.l['crop_u6',t]                        = 1;
      uLU12xF.l['grass_o12',t]                      = 1;
      uLU12xF.l['grass_6_12',t]                     = 1;
      uLU12xF.l['grass_u6',t]                       = 1;

#5) DUMMIES 

    d1LU_agg[land5xF,t] = yes; #Consider removing
    d1qLUC12[land12_s,land12_r,t] = yes$(qLUC12.l[land12_s,land12_r,t]);
    d1qLUC5[land5_s,land5_r,t] = yes$(qLUC5.l[land5_s,land5_r,t] and not sameas(land5_s,land5_r));
    d1LULUCF5[land5,t] = yes$(qEmmLULUCF5.l[land5,t]);
    d1uLUConv12xF[land12xf_a,land12xF] = yes$(uLUConv12xF.l[land12xf_a,land12xF]);
    d1qLU12[land12,t]   = yes$(qLU12.l[land12,t]);

    d1qEmmLU12xF[land12xF,t] = yes$(uLU12xF.l[land12xF,t] or sum(land12xf_a,uLUConv12xF.l[land12xf_a,land12xF]));
    d1qEmmtable4ii[land5,t]$(tx0[t]) = yes$(qEmmtable4ii.l[land5,t]);
    d1qEmmtable4ii[land5,t] = yes$(qEmmtable4ii.l[land5,t]);
    d1uEmmInstantOxiLUCinF[land12_s,land12_r] = yes$(uEmmInstantOxiLUCinF.l[land12_s,land12_r]);

# ======================================================================================================================
# Forest model
# ======================================================================================================================

  #1) READ DATA 

    #DATA PÅ FOREST-REMAINING-FOREST
      qF5_FRF.l[joe07,spec_type,acl,t]$(t.val >=1990)               = FRF_area_data[joe07,spec_type,acl]/1000; #Measure area in kHa
      #We also fill in areas for all iterations, though since final age-classes are collapsed in reporting, i.e. in table 11.11. we only fill out where data is present
      qF5_FRF.l[joe07,spec_type,acl,t]$(t.val >= 1990 and sum(ite$(ite2t(ite,t)), Tabel_11_11[ite,joe07,'FRF',spec_type,acl,'0','area']))
                                                                    = sum(ite$(ite2t(ite,t)), Tabel_11_11[ite,joe07,'FRF',spec_type,acl,'0','area'])/1000;


      qEmmFstock_FRF.l[joe07,spec_type,acl,t]$(t.val > 1990)        = sum(ite$(ite2t(ite,t)), Tabel_11_11[ite,joe07,'FRF',spec_type,acl,'0','CA3']
                                                                                             +Tabel_11_11[ite,joe07,'FRF',spec_type,acl,'0','CB3']
                                                                                             +Tabel_11_11[ite,joe07,'FRF',spec_type,acl,'0','CDW']
                                                                                             +Tabel_11_11[ite,joe07,'FRF',spec_type,acl,'0','CL'])*44/12; #Conversion to CO2e would usually be done in equations.


        #Forest-remaining-forest på Naturstyrelsens arealer 
        qF5_FRF_NST.l[joe07,'B',acl,t] =  Tabel_11_6[joe07,acl,'LE','NST0']$ite2t('ite0',t)/1000;
        qF5_FRF_NST.l[joe07,'C',acl,t] =  (Tabel_11_6[joe07,acl,'NE','NST0']+Tabel_11_6[joe07,acl,'NX','NST0'])$ite2t('ite0',t)/1000;

      #Carbon contents
      content_coefs.l[joe07, spec_type, acl] = sum(content_type, content_coeffs_data[joe07,spec_type,acl,content_type]) ; # measured in tons per hectare -> or in kilotons per 1000 hectares which is the unit that fit with the model

      #Cubic meters of wood per hectare forest
      content_coefs_V3_FRF.l[joe07,spec_type,acl]$(sum(ite, Tabel_11_11[ite,joe07,'FRF',spec_type,acl,'0','AREA'])) = sum(ite, Tabel_11_11[ite,joe07,'FRF',spec_type,acl,'0','V3'])/sum(ite, Tabel_11_11[ite,joe07,'FRF',spec_type,acl,'0','AREA']);
      content_coefs_V3_NRE.l[joe07,spec_type,acl]$(sum(ite, Tabel_11_11[ite,joe07,'NRE',spec_type,acl,'0','AREA'])) = sum(ite, Tabel_11_11[ite,joe07,'NRE',spec_type,acl,'0','V3'])/sum(ite, Tabel_11_11[ite,joe07,'NRE',spec_type,acl,'0','AREA']);
      content_coefs_V3_AFF.l[skmodel,joe07,spec_type,acl]$(sum(ite, Tabel_11_11[ite,joe07,'AFF',spec_type,acl,skmodel,'AREA'])) = sum(ite, Tabel_11_11[ite,joe07,'AFF',spec_type,acl,skmodel,'V3'])/sum(ite, Tabel_11_11[ite,joe07,'AFF',spec_type,acl,skmodel,'AREA']);

      #Carbon content in 'hovedskovning' and 'tynding'
      qC5_FRF.l[joe07,spec_type,acl,t]                        = sum(ite$(ite2t(ite,t)), Tabel_11_11[ite,joe07,'FRF',spec_type,acl,'0','CA3']+Tabel_11_11[ite,joe07,'FRF',spec_type,acl,'0','CB3'] + Tabel_11_11[ite,joe07,'FRF',spec_type,acl,'0','CDW'] + Tabel_11_11[ite,joe07,'FRF',spec_type,acl,'0','CL']);
      qC5_hoved_FRF.l[joe07,spec_type,acl,t]                  = sum(ite$(ite2t(ite,t)), Tabel_11_11[ite,joe07,'FRF',spec_type,acl,'0','HCA2'])*5; #Ganger med 5 for at få 5-årig
      qC5_tynd_FRF.l[joe07,spec_type,acl,t]                   = sum(ite$(ite2t(ite,t)), Tabel_11_11[ite,joe07,'FRF',spec_type,acl,'0','CA2']);

          #Carbon content in 'hovedskovning' and 'tynding' for Naturstyrelsens areas
          qC5_FRF_reducNST.l[joe07,spec_type,acl,t]         =  sum(ite$ite2t(ite,t), Tabel_11_10[ite,'FRF',spec_type,joe07,acl,'CA3NST'])/1000; #Measured in ktC
          qC5_FRF_reduc_hugst_NST.l[joe07,spec_type,acl,t]  = -sum(ite$ite2t(ite,t), Tabel_11_10[ite,'FRF',spec_type,joe07,acl,'CA2NST'])/1000; #Measured in ktC. Input data is negative, but we'd like to keep the negative sign in the equation

      #Survival probabilities 
      pSurvival.l[joe07, spec_type, acl]  = pSurvival_data[joe07,spec_type,acl]; 

   
      #Harvest goes to either use-wood, energy-wood or it is lost. The split between these are imputed from the background tables from IGN/KF22.
        #Distribution of thinning from broadleaves
          sTynd_FRF.l[ite,joe07,'B',acl,'tynd_use']$(Tabel_11_11[ite,joe07,'FRF','B',acl,'0','Tynd_usewL'] + Tabel_11_11[ite,joe07,'FRF','B',acl,'0','Tynd_fuelL'] + Tabel_11_11[ite,joe07,'FRF','B',acl,'0','Tynd_lossL']) 
            = Tabel_11_11[ite,joe07,'FRF','B',acl,'0','Tynd_usewL']/(Tabel_11_11[ite,joe07,'FRF','B',acl,'0','Tynd_usewL'] + Tabel_11_11[ite,joe07,'FRF','B',acl,'0','Tynd_fuelL'] + Tabel_11_11[ite,joe07,'FRF','B',acl,'0','Tynd_lossL']); 
          sTynd_FRF.l[ite,joe07,'B',acl,'tynd_fuel']$(Tabel_11_11[ite,joe07,'FRF','B',acl,'0','Tynd_usewL'] + Tabel_11_11[ite,joe07,'FRF','B',acl,'0','Tynd_fuelL'] + Tabel_11_11[ite,joe07,'FRF','B',acl,'0','Tynd_lossL']) 
            = Tabel_11_11[ite,joe07,'FRF','B',acl,'0','Tynd_fuelL']/(Tabel_11_11[ite,joe07,'FRF','B',acl,'0','Tynd_usewL'] + Tabel_11_11[ite,joe07,'FRF','B',acl,'0','Tynd_fuelL'] + Tabel_11_11[ite,joe07,'FRF','B',acl,'0','Tynd_lossL']);
          sTynd_FRF.l[ite,joe07,'B',acl,'tynd_loss']$(Tabel_11_11[ite,joe07,'FRF','B',acl,'0','Tynd_usewL'] + Tabel_11_11[ite,joe07,'FRF','B',acl,'0','Tynd_fuelL'] + Tabel_11_11[ite,joe07,'FRF','B',acl,'0','Tynd_lossL']) 
            = Tabel_11_11[ite,joe07,'FRF','B',acl,'0','Tynd_lossL']/(Tabel_11_11[ite,joe07,'FRF','B',acl,'0','Tynd_usewL'] + Tabel_11_11[ite,joe07,'FRF','B',acl,'0','Tynd_fuelL'] + Tabel_11_11[ite,joe07,'FRF','B',acl,'0','Tynd_lossL']);

        #Distribution of thinning from main-logging  
          sTynd_FRF.l[ite,joe07,'C',acl,'tynd_use']$((Tabel_11_11[ite,joe07,'FRF','C',acl,'0','Tynd_usewN'] + Tabel_11_11[ite,joe07,'FRF','C',acl,'0','Tynd_fuelN'] + Tabel_11_11[ite,joe07,'FRF','C',acl,'0','Tynd_lossN']))
            = Tabel_11_11[ite,joe07,'FRF','C',acl,'0','Tynd_usewN']/(Tabel_11_11[ite,joe07,'FRF','C',acl,'0','Tynd_usewN'] + Tabel_11_11[ite,joe07,'FRF','C',acl,'0','Tynd_fuelN'] + Tabel_11_11[ite,joe07,'FRF','C',acl,'0','Tynd_lossN']); 
          sTynd_FRF.l[ite,joe07,'C',acl,'tynd_fuel']$(Tabel_11_11[ite,joe07,'FRF','C',acl,'0','Tynd_usewN'] + Tabel_11_11[ite,joe07,'FRF','C',acl,'0','Tynd_fuelN'] + Tabel_11_11[ite,joe07,'FRF','C',acl,'0','Tynd_lossN']) 
            = Tabel_11_11[ite,joe07,'FRF','C',acl,'0','Tynd_fuelN']/(Tabel_11_11[ite,joe07,'FRF','C',acl,'0','Tynd_usewN'] + Tabel_11_11[ite,joe07,'FRF','C',acl,'0','Tynd_fuelN'] + Tabel_11_11[ite,joe07,'FRF','C',acl,'0','Tynd_lossN']);
          sTynd_FRF.l[ite,joe07,'C',acl,'tynd_loss']$(Tabel_11_11[ite,joe07,'FRF','C',acl,'0','Tynd_usewN'] + Tabel_11_11[ite,joe07,'FRF','C',acl,'0','Tynd_fuelN'] + Tabel_11_11[ite,joe07,'FRF','C',acl,'0','Tynd_lossN'])  
            = Tabel_11_11[ite,joe07,'FRF','C',acl,'0','Tynd_lossN']/(Tabel_11_11[ite,joe07,'FRF','C',acl,'0','Tynd_usewN'] + Tabel_11_11[ite,joe07,'FRF','C',acl,'0','Tynd_fuelN'] + Tabel_11_11[ite,joe07,'FRF','C',acl,'0','Tynd_lossN']);
          
        #Distribution of main-logging for broadleaves  
          sHTynd_FRF.l[ite,joe07,'B',acl,'tynd_use']$(Tabel_11_11[ite,joe07,'FRF','B',acl,'0','HTynd_usewL'] + Tabel_11_11[ite,joe07,'FRF','B',acl,'0 ','HTynd_fuelL'] + Tabel_11_11[ite,joe07,'FRF','B',acl,'0','HTynd_lossL']) 
            = Tabel_11_11[ite,joe07,'FRF','B',acl,'0','HTynd_usewL']/(Tabel_11_11[ite,joe07,'FRF','B',acl,'0','HTynd_usewL'] + Tabel_11_11[ite,joe07,'FRF','B',acl,'0 ','HTynd_fuelL'] + Tabel_11_11[ite,joe07,'FRF','B',acl,'0','HTynd_lossL']); 
          sHTynd_FRF.l[ite,joe07,'B',acl,'tynd_fuel']$(Tabel_11_11[ite,joe07,'FRF','B',acl,'0','HTynd_usewL'] + Tabel_11_11[ite,joe07,'FRF','B',acl,'0 ','HTynd_fuelL'] + Tabel_11_11[ite,joe07,'FRF','B',acl,'0','HTynd_lossL']) 
            = Tabel_11_11[ite,joe07,'FRF','B',acl,'0 ','HTynd_fuelL']/(Tabel_11_11[ite,joe07,'FRF','B',acl,'0','HTynd_usewL'] + Tabel_11_11[ite,joe07,'FRF','B',acl,'0 ','HTynd_fuelL'] + Tabel_11_11[ite,joe07,'FRF','B',acl,'0','HTynd_lossL']);
          sHTynd_FRF.l[ite,joe07,'B',acl,'tynd_loss']$(Tabel_11_11[ite,joe07,'FRF','B',acl,'0','HTynd_usewL'] + Tabel_11_11[ite,joe07,'FRF','B',acl,'0 ','HTynd_fuelL'] + Tabel_11_11[ite,joe07,'FRF','B',acl,'0','HTynd_lossL']) 
            = Tabel_11_11[ite,joe07,'FRF','B',acl,'0','HTynd_lossL']/(Tabel_11_11[ite,joe07,'FRF','B',acl,'0','HTynd_usewL'] + Tabel_11_11[ite,joe07,'FRF','B',acl,'0 ','HTynd_fuelL'] + Tabel_11_11[ite,joe07,'FRF','B',acl,'0','HTynd_lossL']);
      
        #Distribution of main-logging for conifers
          sHTynd_FRF.l[ite,joe07,'C',acl,'tynd_use']$((Tabel_11_11[ite,joe07,'FRF','C',acl,'0','HTynd_usewN'] + Tabel_11_11[ite,joe07,'FRF','C',acl,'0','HTynd_fuelN'] + Tabel_11_11[ite,joe07,'FRF','C',acl,'0','HTynd_lossN']))
            = Tabel_11_11[ite,joe07,'FRF','C',acl,'0','HTynd_usewN']/(Tabel_11_11[ite,joe07,'FRF','C',acl,'0','HTynd_usewN'] + Tabel_11_11[ite,joe07,'FRF','C',acl,'0','HTynd_fuelN'] + Tabel_11_11[ite,joe07,'FRF','C',acl,'0','HTynd_lossN']); 
          sHTynd_FRF.l[ite,joe07,'C',acl,'tynd_fuel']$(Tabel_11_11[ite,joe07,'FRF','C',acl,'0','HTynd_usewN'] + Tabel_11_11[ite,joe07,'FRF','C',acl,'0','HTynd_fuelN'] + Tabel_11_11[ite,joe07,'FRF','C',acl,'0','HTynd_lossN']) 
            = Tabel_11_11[ite,joe07,'FRF','C',acl,'0','HTynd_fuelN']/(Tabel_11_11[ite,joe07,'FRF','C',acl,'0','HTynd_usewN'] + Tabel_11_11[ite,joe07,'FRF','C',acl,'0','HTynd_fuelN'] + Tabel_11_11[ite,joe07,'FRF','C',acl,'0','HTynd_lossN']);
          sHTynd_FRF.l[ite,joe07,'C',acl,'tynd_loss']$(Tabel_11_11[ite,joe07,'FRF','C',acl,'0','HTynd_usewN'] + Tabel_11_11[ite,joe07,'FRF','C',acl,'0','HTynd_fuelN'] + Tabel_11_11[ite,joe07,'FRF','C',acl,'0','HTynd_lossN'])  
            = Tabel_11_11[ite,joe07,'FRF','C',acl,'0','HTynd_lossN']/(Tabel_11_11[ite,joe07,'FRF','C',acl,'0','HTynd_usewN'] + Tabel_11_11[ite,joe07,'FRF','C',acl,'0','HTynd_fuelN'] + Tabel_11_11[ite,joe07,'FRF','C',acl,'0','HTynd_lossN']);

      #CORRECTION-FACTOR (same across iterations)
      sHTyndCorr_FRF.l[joe07,spec_type,acl]$(sum(ite,Tabel_11_11[ite,joe07,'FRF',spec_type,acl,'0','HCA2'])) 
        = sum(ite,Tabel_11_11[ite,joe07,'FRF',spec_type,acl,'0','HV2'])/sum(ite,Tabel_11_11[ite,joe07,'FRF',spec_type,acl,'0','HCA2'])/1000;

      #Tynding går til enten brugstræ, brændsel, eller tab. Andelene tages fra output tabeller fra KF22.
        #Distribution of thinning for broadleaved afforestation
          sTynd_AFF.l[skmodel,joe07,'B',acl,'tynd_use']$(sum(ite,Tabel_11_11[ite,joe07,'AFF','B',acl,skmodel,'Tynd_usewL'] + Tabel_11_11[ite,joe07,'AFF','B',acl,skmodel,'Tynd_fuelL'] + Tabel_11_11[ite,joe07,'AFF','B',acl,skmodel,'Tynd_lossL'])) 
            = sum(ite,Tabel_11_11[ite,joe07,'AFF','B',acl,skmodel,'Tynd_usewL'])/sum(ite,Tabel_11_11[ite,joe07,'AFF','B',acl,skmodel,'Tynd_usewL'] + Tabel_11_11[ite,joe07,'AFF','B',acl,skmodel,'Tynd_fuelL'] + Tabel_11_11[ite,joe07,'AFF','B',acl,skmodel,'Tynd_lossL']); 
          sTynd_AFF.l[skmodel,joe07,'B',acl,'tynd_fuel']$(sum(ite,Tabel_11_11[ite,joe07,'AFF','B',acl,skmodel,'Tynd_usewL'] + Tabel_11_11[ite,joe07,'AFF','B',acl,skmodel,'Tynd_fuelL'] + Tabel_11_11[ite,joe07,'AFF','B',acl,skmodel,'Tynd_lossL'])) 
            = sum(ite,Tabel_11_11[ite,joe07,'AFF','B',acl,skmodel,'Tynd_fuelL'])/sum(ite,Tabel_11_11[ite,joe07,'AFF','B',acl,skmodel,'Tynd_usewL'] + Tabel_11_11[ite,joe07,'AFF','B',acl,skmodel,'Tynd_fuelL'] + Tabel_11_11[ite,joe07,'AFF','B',acl,skmodel,'Tynd_lossL']);
          sTynd_AFF.l[skmodel,joe07,'B',acl,'tynd_loss']$(sum(ite,Tabel_11_11[ite,joe07,'AFF','B',acl,skmodel,'Tynd_usewL'] + Tabel_11_11[ite,joe07,'AFF','B',acl,skmodel,'Tynd_fuelL'] + Tabel_11_11[ite,joe07,'AFF','B',acl,skmodel,'Tynd_lossL'])) 
            = sum(ite,Tabel_11_11[ite,joe07,'AFF','B',acl,skmodel,'Tynd_lossL'])/sum(ite,Tabel_11_11[ite,joe07,'AFF','B',acl,skmodel,'Tynd_usewL'] + Tabel_11_11[ite,joe07,'AFF','B',acl,skmodel,'Tynd_fuelL'] + Tabel_11_11[ite,joe07,'AFF','B',acl,skmodel,'Tynd_lossL']);

        #Distribution of thinning for conifer afforestation
          sTynd_AFF.l[skmodel,joe07,'C',acl,'tynd_use']$(sum(ite,Tabel_11_11[ite,joe07,'AFF','C',acl,skmodel,'Tynd_usewN'] + Tabel_11_11[ite,joe07,'AFF','C',acl,skmodel,'Tynd_fuelN'] + Tabel_11_11[ite,joe07,'AFF','C',acl,skmodel,'Tynd_lossN']))
            = sum(ite,Tabel_11_11[ite,joe07,'AFF','C',acl,skmodel,'Tynd_usewN'])/sum(ite,Tabel_11_11[ite,joe07,'AFF','C',acl,skmodel,'Tynd_usewN'] + Tabel_11_11[ite,joe07,'AFF','C',acl,skmodel,'Tynd_fuelN'] + Tabel_11_11[ite,joe07,'AFF','C',acl,skmodel,'Tynd_lossN']); 
          sTynd_AFF.l[skmodel,joe07,'C',acl,'tynd_fuel']$(sum(ite,Tabel_11_11[ite,joe07,'AFF','C',acl,skmodel,'Tynd_usewN'] + Tabel_11_11[ite,joe07,'AFF','C',acl,skmodel,'Tynd_fuelN'] + Tabel_11_11[ite,joe07,'AFF','C',acl,skmodel,'Tynd_lossN'])) 
            = sum(ite,Tabel_11_11[ite,joe07,'AFF','C',acl,skmodel,'Tynd_fuelN'])/sum(ite,Tabel_11_11[ite,joe07,'AFF','C',acl,skmodel,'Tynd_usewN'] + Tabel_11_11[ite,joe07,'AFF','C',acl,skmodel,'Tynd_fuelN'] + Tabel_11_11[ite,joe07,'AFF','C',acl,skmodel,'Tynd_lossN']);
          sTynd_AFF.l[skmodel,joe07,'C',acl,'tynd_loss']$(sum(ite,Tabel_11_11[ite,joe07,'AFF','C',acl,skmodel,'Tynd_usewN'] + Tabel_11_11[ite,joe07,'AFF','C',acl,skmodel,'Tynd_fuelN'] + Tabel_11_11[ite,joe07,'AFF','C',acl,skmodel,'Tynd_lossN']))  
            = sum(ite,Tabel_11_11[ite,joe07,'AFF','C',acl,skmodel,'Tynd_lossN'])/sum(ite,Tabel_11_11[ite,joe07,'AFF','C',acl,skmodel,'Tynd_usewN'] + Tabel_11_11[ite,joe07,'AFF','C',acl,skmodel,'Tynd_fuelN'] + Tabel_11_11[ite,joe07,'AFF','C',acl,skmodel,'Tynd_lossN']);
          
        #Distribution of main-logging for afforestation from broadleaves 
          sHTynd_AFF.l[skmodel,joe07,'B',acl,'tynd_use']$(sum(ite,Tabel_11_11[ite,joe07,'AFF','B',acl,skmodel,'HTynd_usewL'] + Tabel_11_11[ite,joe07,'AFF','B',acl,skmodel,'HTynd_fuelL'] + Tabel_11_11[ite,joe07,'AFF','B',acl,skmodel,'HTynd_lossL']))
            = sum(ite,Tabel_11_11[ite,joe07,'AFF','B',acl,skmodel,'HTynd_usewL'])/sum(ite,Tabel_11_11[ite,joe07,'AFF','B',acl,skmodel,'HTynd_usewL'] + Tabel_11_11[ite,joe07,'AFF','B',acl,skmodel,'HTynd_fuelL'] + Tabel_11_11[ite,joe07,'AFF','B',acl,skmodel,'HTynd_lossL']); 
          sHTynd_AFF.l[skmodel,joe07,'B',acl,'tynd_fuel']$(sum(ite,Tabel_11_11[ite,joe07,'AFF','B',acl,skmodel,'HTynd_usewL'] + Tabel_11_11[ite,joe07,'AFF','B',acl,skmodel,'HTynd_fuelL'] + Tabel_11_11[ite,joe07,'AFF','B',acl,skmodel,'HTynd_lossL'])) 
            = sum(ite,Tabel_11_11[ite,joe07,'AFF','B',acl,skmodel,'HTynd_fuelL'])/sum(ite,Tabel_11_11[ite,joe07,'AFF','B',acl,skmodel,'HTynd_usewL'] + Tabel_11_11[ite,joe07,'AFF','B',acl,skmodel,'HTynd_fuelL'] + Tabel_11_11[ite,joe07,'AFF','B',acl,skmodel,'HTynd_lossL']);
          sHTynd_AFF.l[skmodel,joe07,'B',acl,'tynd_loss']$(sum(ite,Tabel_11_11[ite,joe07,'AFF','B',acl,skmodel,'HTynd_usewL'] + Tabel_11_11[ite,joe07,'AFF','B',acl,skmodel,'HTynd_fuelL'] + Tabel_11_11[ite,joe07,'AFF','B',acl,skmodel,'HTynd_lossL'])) 
            = sum(ite,Tabel_11_11[ite,joe07,'AFF','B',acl,skmodel,'HTynd_lossL'])/sum(ite,Tabel_11_11[ite,joe07,'AFF','B',acl,skmodel,'HTynd_usewL'] + Tabel_11_11[ite,joe07,'AFF','B',acl,skmodel,'HTynd_fuelL'] + Tabel_11_11[ite,joe07,'AFF','B',acl,skmodel,'HTynd_lossL']);
      
       #Distribution of main-logging for afforestation from conifers   
          sHTynd_AFF.l[skmodel,joe07,'C',acl,'tynd_use']$(sum(ite,Tabel_11_11[ite,joe07,'AFF','C',acl,skmodel,'HTynd_usewN'] + Tabel_11_11[ite,joe07,'AFF','C',acl,skmodel,'HTynd_fuelN'] + Tabel_11_11[ite,joe07,'AFF','C',acl,skmodel,'HTynd_lossN']))
            = sum(ite,Tabel_11_11[ite,joe07,'AFF','C',acl,skmodel,'HTynd_usewN'])/sum(ite,Tabel_11_11[ite,joe07,'AFF','C',acl,skmodel,'HTynd_usewN'] + Tabel_11_11[ite,joe07,'AFF','C',acl,skmodel,'HTynd_fuelN'] + Tabel_11_11[ite,joe07,'AFF','C',acl,skmodel,'HTynd_lossN']); 
          sHTynd_AFF.l[skmodel,joe07,'C',acl,'tynd_fuel']$(sum(ite,Tabel_11_11[ite,joe07,'AFF','C',acl,skmodel,'HTynd_usewN'] + Tabel_11_11[ite,joe07,'AFF','C',acl,skmodel,'HTynd_fuelN'] + Tabel_11_11[ite,joe07,'AFF','C',acl,skmodel,'HTynd_lossN'])) 
            = sum(ite,Tabel_11_11[ite,joe07,'AFF','C',acl,skmodel,'HTynd_fuelN'])/sum(ite,Tabel_11_11[ite,joe07,'AFF','C',acl,skmodel,'HTynd_usewN'] + Tabel_11_11[ite,joe07,'AFF','C',acl,skmodel,'HTynd_fuelN'] + Tabel_11_11[ite,joe07,'AFF','C',acl,skmodel,'HTynd_lossN']);
          sHTynd_AFF.l[skmodel,joe07,'C',acl,'tynd_loss']$(sum(ite,Tabel_11_11[ite,joe07,'AFF','C',acl,skmodel,'HTynd_usewN'] + Tabel_11_11[ite,joe07,'AFF','C',acl,skmodel,'HTynd_fuelN'] + Tabel_11_11[ite,joe07,'AFF','C',acl,skmodel,'HTynd_lossN']))  
            = sum(ite,Tabel_11_11[ite,joe07,'AFF','C',acl,skmodel,'HTynd_lossN'])/sum(ite,Tabel_11_11[ite,joe07,'AFF','C',acl,skmodel,'HTynd_usewN'] + Tabel_11_11[ite,joe07,'AFF','C',acl,skmodel,'HTynd_fuelN'] + Tabel_11_11[ite,joe07,'AFF','C',acl,skmodel,'HTynd_lossN']);

        #Correction-factor
        sHTyndCorr_AFF.l[skmodel,joe07,spec_type,acl]$(sum(ite,Tabel_11_11[ite,joe07,'AFF',spec_type,acl,skmodel,'HCA2']))
           = sum(ite, Tabel_11_11[ite,joe07,'AFF',spec_type,acl,skmodel,'HV2'])/sum(ite,Tabel_11_11[ite,joe07,'AFF',spec_type,acl,skmodel,'HCA2'])/1000;


          sTynd_NRE.l[ite,joe07,'B',acl,'tynd_use']$(Tabel_11_11[ite,joe07,'NRE','B',acl,'0','Tynd_usewL'] + Tabel_11_11[ite,joe07,'NRE','B',acl,'0','Tynd_fuelL'] + Tabel_11_11[ite,joe07,'NRE','B',acl,'0','Tynd_lossL']) 
            = Tabel_11_11[ite,joe07,'NRE','B',acl,'0','Tynd_usewL']/(Tabel_11_11[ite,joe07,'NRE','B',acl,'0','Tynd_usewL'] + Tabel_11_11[ite,joe07,'NRE','B',acl,'0','Tynd_fuelL'] + Tabel_11_11[ite,joe07,'NRE','B',acl,'0','Tynd_lossL']); 
          sTynd_NRE.l[ite,joe07,'B',acl,'tynd_fuel']$(Tabel_11_11[ite,joe07,'NRE','B',acl,'0','Tynd_usewL'] + Tabel_11_11[ite,joe07,'NRE','B',acl,'0','Tynd_fuelL'] + Tabel_11_11[ite,joe07,'NRE','B',acl,'0','Tynd_lossL']) 
            = Tabel_11_11[ite,joe07,'NRE','B',acl,'0','Tynd_fuelL']/(Tabel_11_11[ite,joe07,'NRE','B',acl,'0','Tynd_usewL'] + Tabel_11_11[ite,joe07,'NRE','B',acl,'0','Tynd_fuelL'] + Tabel_11_11[ite,joe07,'NRE','B',acl,'0','Tynd_lossL']);
          sTynd_NRE.l[ite,joe07,'B',acl,'tynd_loss']$(Tabel_11_11[ite,joe07,'NRE','B',acl,'0','Tynd_usewL'] + Tabel_11_11[ite,joe07,'NRE','B',acl,'0','Tynd_fuelL'] + Tabel_11_11[ite,joe07,'NRE','B',acl,'0','Tynd_lossL']) 
            = Tabel_11_11[ite,joe07,'NRE','B',acl,'0','Tynd_lossL']/(Tabel_11_11[ite,joe07,'NRE','B',acl,'0','Tynd_usewL'] + Tabel_11_11[ite,joe07,'NRE','B',acl,'0','Tynd_fuelL'] + Tabel_11_11[ite,joe07,'NRE','B',acl,'0','Tynd_lossL']);

          sTynd_NRE.l[ite,joe07,'C',acl,'tynd_use']$(Tabel_11_11[ite,joe07,'NRE','C',acl,'0','Tynd_usewN'] + Tabel_11_11[ite,joe07,'NRE','C',acl,'0','Tynd_fuelN'] + Tabel_11_11[ite,joe07,'NRE','C',acl,'0','Tynd_lossN'])
            = Tabel_11_11[ite,joe07,'NRE','C',acl,'0','Tynd_usewN']/(Tabel_11_11[ite,joe07,'NRE','C',acl,'0','Tynd_usewN'] + Tabel_11_11[ite,joe07,'NRE','C',acl,'0','Tynd_fuelN'] + Tabel_11_11[ite,joe07,'NRE','C',acl,'0','Tynd_lossN']); 
          sTynd_NRE.l[ite,joe07,'C',acl,'tynd_fuel']$(Tabel_11_11[ite,joe07,'NRE','C',acl,'0','Tynd_usewN'] + Tabel_11_11[ite,joe07,'NRE','C',acl,'0','Tynd_fuelN'] + Tabel_11_11[ite,joe07,'NRE','C',acl,'0','Tynd_lossN']) 
            = Tabel_11_11[ite,joe07,'NRE','C',acl,'0','Tynd_fuelN']/(Tabel_11_11[ite,joe07,'NRE','C',acl,'0','Tynd_usewN'] + Tabel_11_11[ite,joe07,'NRE','C',acl,'0','Tynd_fuelN'] + Tabel_11_11[ite,joe07,'NRE','C',acl,'0','Tynd_lossN']);
          sTynd_NRE.l[ite,joe07,'C',acl,'tynd_loss']$(Tabel_11_11[ite,joe07,'NRE','C',acl,'0','Tynd_usewN'] + Tabel_11_11[ite,joe07,'NRE','C',acl,'0','Tynd_fuelN'] + Tabel_11_11[ite,joe07,'NRE','C',acl,'0','Tynd_lossN'])  
            = Tabel_11_11[ite,joe07,'NRE','C',acl,'0','Tynd_lossN']/(Tabel_11_11[ite,joe07,'NRE','C',acl,'0','Tynd_usewN'] + Tabel_11_11[ite,joe07,'NRE','C',acl,'0','Tynd_fuelN'] + Tabel_11_11[ite,joe07,'NRE','C',acl,'0','Tynd_lossN']);
          
          sHTynd_NRE.l[ite,joe07,'B',acl,'tynd_use']$(Tabel_11_11[ite,joe07,'NRE','B',acl,'0','HTynd_usewL'] + Tabel_11_11[ite,joe07,'NRE','B',acl,'0','HTynd_fuelL'] + Tabel_11_11[ite,joe07,'NRE','B',acl,'0','HTynd_lossL'])
            = Tabel_11_11[ite,joe07,'NRE','B',acl,'0','HTynd_usewL']/(Tabel_11_11[ite,joe07,'NRE','B',acl,'0','HTynd_usewL'] + Tabel_11_11[ite,joe07,'NRE','B',acl,'0','HTynd_fuelL'] + Tabel_11_11[ite,joe07,'NRE','B',acl,'0','HTynd_lossL']); 
          sHTynd_NRE.l[ite,joe07,'B',acl,'tynd_fuel']$(Tabel_11_11[ite,joe07,'NRE','B',acl,'0','HTynd_usewL'] + Tabel_11_11[ite,joe07,'NRE','B',acl,'0','HTynd_fuelL'] + Tabel_11_11[ite,joe07,'NRE','B',acl,'0','HTynd_lossL']) 
            = Tabel_11_11[ite,joe07,'NRE','B',acl,'0','HTynd_fuelL']/(Tabel_11_11[ite,joe07,'NRE','B',acl,'0','HTynd_usewL'] + Tabel_11_11[ite,joe07,'NRE','B',acl,'0','HTynd_fuelL'] + Tabel_11_11[ite,joe07,'NRE','B',acl,'0','HTynd_lossL']);
          sHTynd_NRE.l[ite,joe07,'B',acl,'tynd_loss']$(Tabel_11_11[ite,joe07,'NRE','B',acl,'0','HTynd_usewL'] + Tabel_11_11[ite,joe07,'NRE','B',acl,'0','HTynd_fuelL'] + Tabel_11_11[ite,joe07,'NRE','B',acl,'0','HTynd_lossL']) 
            = Tabel_11_11[ite,joe07,'NRE','B',acl,'0','HTynd_lossL']/(Tabel_11_11[ite,joe07,'NRE','B',acl,'0','HTynd_usewL'] + Tabel_11_11[ite,joe07,'NRE','B',acl,'0','HTynd_fuelL'] + Tabel_11_11[ite,joe07,'NRE','B',acl,'0','HTynd_lossL']);
      
          sHTynd_NRE.l[ite,joe07,'C',acl,'tynd_use']$(Tabel_11_11[ite,joe07,'NRE','C',acl,'0','HTynd_usewN'] + Tabel_11_11[ite,joe07,'NRE','C',acl,'0','HTynd_fuelN'] + Tabel_11_11[ite,joe07,'NRE','C',acl,'0','HTynd_lossN'])
            = Tabel_11_11[ite,joe07,'NRE','C',acl,'0','HTynd_usewN']/(Tabel_11_11[ite,joe07,'NRE','C',acl,'0','HTynd_usewN'] + Tabel_11_11[ite,joe07,'NRE','C',acl,'0','HTynd_fuelN'] + Tabel_11_11[ite,joe07,'NRE','C',acl,'0','HTynd_lossN']); 
          sHTynd_NRE.l[ite,joe07,'C',acl,'tynd_fuel']$(Tabel_11_11[ite,joe07,'NRE','C',acl,'0','HTynd_usewN'] + Tabel_11_11[ite,joe07,'NRE','C',acl,'0','HTynd_fuelN'] + Tabel_11_11[ite,joe07,'NRE','C',acl,'0','HTynd_lossN']) 
            = Tabel_11_11[ite,joe07,'NRE','C',acl,'0','HTynd_fuelN']/(Tabel_11_11[ite,joe07,'NRE','C',acl,'0','HTynd_usewN'] + Tabel_11_11[ite,joe07,'NRE','C',acl,'0','HTynd_fuelN'] + Tabel_11_11[ite,joe07,'NRE','C',acl,'0','HTynd_lossN']);
          sHTynd_NRE.l[ite,joe07,'C',acl,'tynd_loss']$(Tabel_11_11[ite,joe07,'NRE','C',acl,'0','HTynd_usewN'] + Tabel_11_11[ite,joe07,'NRE','C',acl,'0','HTynd_fuelN'] + Tabel_11_11[ite,joe07,'NRE','C',acl,'0','HTynd_lossN'])  
            = Tabel_11_11[ite,joe07,'NRE','C',acl,'0','HTynd_lossN']/(Tabel_11_11[ite,joe07,'NRE','C',acl,'0','HTynd_usewN'] + Tabel_11_11[ite,joe07,'NRE','C',acl,'0','HTynd_fuelN'] + Tabel_11_11[ite,joe07,'NRE','C',acl,'0','HTynd_lossN']);

          sHTyndCorr_NRE.l[ite,joe07,spec_type,acl]$(Tabel_11_11[ite,joe07,'NRE',spec_type,acl,'0','HCA2'])
            = Tabel_11_11[ite,joe07,'NRE',spec_type,acl,'0','HV2']/Tabel_11_11[ite,joe07,'NRE',spec_type,acl,'0','HCA2']/1000;


      #NATURRESERVATER + LYSÅBNE OMRÅDER 
        qF5_NRE.l[joe07,spec_type,acl,t]$(t.val > 1990)               = sum(ite$(ite2t(ite,t)), Tabel_11_11[ite,joe07,'NRE',spec_type,acl,'0','area'])/1000;
        qF5_NRE_deforestation.l[joe07,spec_type,acl,t]$(t.val > 1990) = sum(ite$(ite2t(ite,t)), Tabel_11_11[ite,joe07,'NRE',spec_type,acl,'0','harea'])*5/1000; #"Hovedskovning" is measured per year in Tabel_11_11. To convert to five-year increments we multiply by 5.
        qEmmFstock_NRE.l[joe07,spec_type,acl,t]$(t.val > 1990)        = sum(ite$(ite2t(ite,t)), Tabel_11_11[ite,joe07,'NRE',spec_type,acl,'0','CA3']
                                                                                               +Tabel_11_11[ite,joe07,'NRE',spec_type,acl,'0','CB3']
                                                                                               +Tabel_11_11[ite,joe07,'NRE',spec_type,acl,'0','CDW']
                                                                                               +Tabel_11_11[ite,joe07,'NRE',spec_type,acl,'0','CL'])*44/12; #Conversion to CO2e would usually be done in equations.

        #Carbon-flow from thinning in natural-reserves and LYS are added exogenously
        qC5_hoved_NRE.l[joe07,spec_type,acl,t]                        = sum(ite$ite2t(ite,t),  Tabel_11_11[ite,joe07,'NRE',spec_type,acl,'0','HCA2'])*5;
        qC5_tynd_NRE.l[joe07,spec_type,acl,t]                         = sum(ite$ite2t(ite,t),  Tabel_11_11[ite,joe07,'NRE',spec_type,acl,'0','CA2']);


        qF5_LYS.l[joe07,spec_type,acl,t]$(t.val > 1990)               = sum(ite$(ite2t(ite,t)), sum(skmodel, Tabel_11_11[ite,joe07,'LYS',spec_type,acl,skmodel,'area']))/1000;
        qEmmFstock_LYS.l[joe07,spec_type,acl,t]$(t.val > 1990)        = sum(ite$(ite2t(ite,t)), sum(skmodel, Tabel_11_11[ite,joe07,'LYS',spec_type,acl,skmodel,'CA3']
                                                                                                            +Tabel_11_11[ite,joe07,'LYS',spec_type,acl,skmodel,'CB3']
                                                                                                            +Tabel_11_11[ite,joe07,'LYS',spec_type,acl,skmodel,'CDW']
                                                                                                            +Tabel_11_11[ite,joe07,'LYS',spec_type,acl,skmodel,'CL']))*44/12; #Conversion to CO2e would usually be done in equations.

      #AFFORESTATION 

        #Afforestation area
        qF5_aff.l[skmodel,joe07,spec_type,'acl5',t]    = 5*AFF_area_data[t,joe07,spec_type,skmodel]/1000; #Based on table 5.1 and 5.2 in "KF22skov_drivhusregnskab_rapport.pdf" input-data is yearly average and not a total for the 5-year period. Hence we multiply input data by 5
        qF5_aff.l[skmodel,joe07,spec_type,acl,t]       = sum(ite$ite2t(ite,t), Tabel_11_11[ite,joe07,'AFF',spec_type,acl,skmodel,'AREA'])/1000;

        qF5_AFF_baseline.l[skmodel,joe07,spec_type,acl,t] = qF5_AFF.l[skmodel,joe07,spec_type,acl,t];

        #Kulstofindhold
        carbon_content_aff.l[skmodel,joe07,spec_type,acl] =  sum(content_type,AFF_coeffs_data[skmodel,joe07,spec_type,acl,content_type]);

        qC5_AFF.l[skmodel,joe07,spec_type,acl,t]       = sum(ite$(ite2t(ite,t)), Tabel_11_11[ite,joe07,'AFF',spec_type,acl,skmodel,'CA3'] + Tabel_11_11[ite,joe07,'AFF',spec_type,acl,skmodel,'CB3'] + Tabel_11_11[ite,joe07,'AFF',spec_type,acl,skmodel,'CDW']  + Tabel_11_11[ite,joe07,'AFF',spec_type,acl,skmodel,'CL']); 
        qEmmFstock_AFF.l[skmodel,joe07,spec_type,acl,t]= 44/12*qC5_AFF.l[skmodel,joe07,spec_type,acl,t];
        qC5_hoved_AFF.l[skmodel,joe07,spec_type,acl,t] = sum(ite$(ite2t(ite,t)), Tabel_11_11[ite,joe07,'AFF',spec_type,acl,skmodel,'HCA2'])*5; #Ganger med 5 for at få 5-årig
        qC5_tynd_aff.l[skmodel,joe07,spec_type,acl,t]  = sum(ite$(ite2t(ite,t)), Tabel_11_11[ite,joe07,'AFF',spec_type,acl,skmodel,'CA2']); 

        #Dødssandsynlighed: I korrespondance m. IGN fik vi at vide, at al skov fra afforestation levede indtil "terminalalder", hvorefter det blev fældet og overgik til lavest age-class i FRF. Det er ikke helt rigtigt lader det
        #Tilsyneladende starter hovedskovning tidligere end terminalalder. Hovedskovningen kan udledes af output tabellerne.
        pSurvival_AFF.l[skmodel,joe07,spec_type,acl-1]$(sum(ite,Tabel_11_11[ite-1,joe07,'AFF',spec_type,acl-1,skmodel,'AREA']))
           =  sum(ite,Tabel_11_11[ite,joe07,'AFF',spec_type,acl,skmodel,'AREA'])/sum(ite,Tabel_11_11[ite-1,joe07,'AFF',spec_type,acl-1,skmodel,'AREA']);


      #HWP 
        Tynding_coefs.l[joe07,spec_type,acl]             = NFI_HWP_coeff_data[joe07,spec_type,acl];
        Tynding_coefs_aff.l[skmodel,joe07,spec_type,acl] = AFF_HWP_coeff_data[skmodel,joe07,spec_type,acl];


        #Sætter start-stocken af HWP. Aflæses fra figur 7.5 i KF22skov_drivhusgasregnskab_rapport.pdf til 23.5 mio.tCO2e. Disse fordeles jævnt ud fra fordelingen af B og C. Det er formentlig en del af fejlkilden til at vi ikke kan ramme HWP
                                                                                        #Fordelingen på savskåret/træplader tages fra ark tilsendt af Stefan Krüger fra ENS.
        qC5_usestock_FRF.l['savskaaret',spec_type_xp,t]$(t.val > 1990 and t.val <=2020) = 3892451/1000 * sum((joe07,acl), qF5_FRF.l[joe07,spec_type_xp,acl,t])/sum((joe07_a,acl_a,spec_type_xp_a), qF5_FRF.l[joe07_a,spec_type_xp_a,acl_a,t]);
        qC5_usestock_FRF.l['traeplader',spec_type_xp,t]$(t.val > 1990 and t.val <=2020) = 2511738/1000 *  sum((joe07,acl), qF5_FRF.l[joe07,spec_type_xp,acl,t])/sum((joe07_a,acl_a,spec_type_xp_a), qF5_FRF.l[joe07_a,spec_type_xp_a,acl_a,t]);

        qC5_usestock_AFF.l['savskaaret',spec_type_xp,t]$(t.val > 1990 and t.val <=2020) = 0;
        qC5_usestock_AFF.l['traeplader',spec_type_xp,t]$(t.val > 1990 and t.val <=2020) = 0;



      #AGGREGATES 

        #  Values eye-balled from this one: https://static-curis.ku.dk/portal/files/283138747/Rapport_Skovstatistik_2020_web.pdf%20
        qEmmFStock.l[t]$(t.val >=1990 and t.val <=1999) = 30*1000*44/12; 
        qEmmFStock.l[t]$(t.val > 1999 and t.val <=2004) = 39*1000*44/12;
        qEmmFStock.l['2005']                            = 39*1000*44/12;
        qEmmFstock.l['2006']                            = 40*1000*44/12;
        qEmmFstock.l['2007']                            = 40*1000*44/12;
        qEmmFstock.l['2008']                            = 40*1000*44/12;
        qEmmFstock.l['2009']                            = 40*1000*44/12;
        qEmmFstock.l['2010']                            = 40*1000*44/12;
        qEmmFstock.l['2011']                            = 42*1000*44/12;
        qEmmFstock.l['2012']                            = 44*1000*44/12;
        qEmmFstock.l['2013']                            = 46*1000*44/12;
        qEmmFstock.l['2014']                            = 48*1000*44/12;


        qEmmFstock.l['2015'] = 49.4761861212    * 1000*44/12; #Aflæst i fanen Carbon 1960-1990-2050 i FP_MAIN_carbon_samling_20220301_KF22_50005402_skema.xlsx, se evt. i dataamppen 
        qEmmFstock.l['2016'] = 49.845238429129  * 1000*44/12;
        qEmmFstock.l['2017'] = 50.406185498500  * 1000*44/12;
        qEmmFstock.l['2018'] = 51.929830759328  * 1000*44/12;
        qEmmFstock.l['2019'] = 52.286874323329  * 1000*44/12;
        qEmmFstock.l['2020'] = 52.2655552360625 * 1000*44/12;
        qEmmFstock.l[t]$(t.val >=2020) = sum((joe07,forvalt,spec_type,acl,skmodel), (Tabel_11_11['ite0',joe07,forvalt,spec_type,acl,skmodel,'CA3'] 
                                                                           + Tabel_11_11['ite0',joe07,forvalt,spec_type,acl,skmodel,'CB3'] 
                                                                           + Tabel_11_11['ite0',joe07,forvalt,spec_type,acl,skmodel,'CDW'] 
                                                                           + Tabel_11_11['ite0',joe07,forvalt,spec_type,acl,skmodel,'CL'])) *44/12; 
      #ECONOMICS 

      #Harvest prices are "net-on-root" (netto-på-rod)
       $import read_hugstpriser.gms


       pHugstomk_usew.l[t]$(t.val >= tEnd.val)  = 100/10**6*inf_growth_factor['2021'];
       pHugstomk_firew.l[t]$(t.val >= tEnd.val) = 150/10**6*inf_growth_factor['2021'];

       pI_afforestation_external.l['Jutland'] = 63000*inf_growth_factor['2022'];
       pI_afforestation_external.l['Islands'] = 65000*inf_growth_factor['2022'];

          
  #2) EXOGENOUS VALUES 

      #HWP 
        sUtilization.l['savskaaret','C'] = 0.44; #Fraction of wood that goes into HWP-stock. 1-sUtilization is assumed to be wood waste and ending up being burned
        sUtilization.l['savskaaret','B'] = 0.47; 
        sUtilization.l['traeplader','C'] = 0.74;
        sUtilization.l['traeplader','B'] = 0.74;


        #Fordelingen på savkskåret/træplader tages fra ark tilsendt af Niclas Scott IGN. Det er 2020-fordelingen, denne trækkes også fladt af IGN i fremskrivningen
        sEnduse.l['savskaaret'] = 0.573704; sEnduse.l['savskaaret'] = 0.58; #Der afrundes til højre og venstre
        sEnduse.l['traeplader'] = 0.426296; sEnduse.l['traeplader'] = 0.42;

        sHCA2HV2.l['savskaaret','C'] = 0.235;
        sHCA2HV2.l['savskaaret','B'] = 0.286;
        sHCA2HV2.l['traeplader','C'] = 0.269;
        sHCA2HV2.l['traeplader','B'] = 0.269;

        sCA2V2.l['B'] = 0.27;
        sCA2V2.l['C'] = 0.19;


        #  depreciation_factor_usestock.l['savskaaret'] = exp(log(1/2)/35); #Half-life of 35 years on savskaaret wood
        #  depreciation_factor_usestock.l['traeplader'] = exp(log(1/2)/25);
        #  depreciation_factor_usestock.l['savskaaret'] = exp(log(1/2)/35); #Half-life of 35 years on savskaaret wood
        #  depreciation_factor_usestock.l['traeplader'] = exp(log(1/2)/25);

        #IGN bruger afrundede tal
        depreciation_factor_usestock.l['savskaaret'] = 0.98; #Half-life of 35 years on savskaaret wood
        depreciation_factor_usestock.l['traeplader'] = 0.973;
     
        depreciation_factor_usestock_inflow.l['savskaaret'] = 0.99; #Half-life of 35 years on savskaaret wood
        depreciation_factor_usestock_inflow.l['traeplader'] = 0.986;
      

  #3) COMPUTATIONS 
    #FOREST-REMAINING-FOREST

      #Naturstyrelsens arealer 
        LOOP(t,
         LOOP(acl, 
           qF5_FRF_NST.l[joe07,spec_type,acl,t]$(qF5_FRF_NST.l[joe07,spec_type,acl-1,t-5]) = qF5_FRF_NST.l[joe07,spec_type,acl-1,t-5];
           );
         );


      #Der er kun kulstofindhold frem til ACL=200 for Broadleaves i output-data. Broadleaves har dog terminalaldersklasse på 250, så vi udfylder de manglende år med nedenstående loop.
        LOOP(acl, 
          content_coefs.l[joe07, spec_type, acl]$(content_coefs.l[joe07, spec_type, acl] = 0 and content_coefs.l[joe07, spec_type, acl-1] and acl_spec_type[acl,spec_type]) = content_coefs.l[joe07, spec_type, acl-1]; 
          content_coeffs_data[joe07,spec_type,acl,content_type]$(content_coeffs_data[joe07,spec_type,acl,content_type] = 0 and content_coeffs_data[joe07,spec_type,acl-1,content_type] and acl_spec_type[acl,spec_type]) = content_coeffs_data[joe07,spec_type,acl-1 ,content_type];
        );

      #Der er kun tyndingskoefficienter frem til ACL=200 for Broadleaves i output-data. Broadleaves har dog terminalaldersklasse på 250, så vi udfylder de manglende år med nedenstående loop.
      LOOP(acl, 
      #
      sTynd_FRF.l[ite,joe07, spec_type, acl,tynd]$(sTynd_FRF.l[ite,joe07, spec_type, acl,tynd] = 0 and sTynd_FRF.l[ite,joe07, spec_type, acl-1,tynd] and acl_spec_type[acl,spec_type])
       = sTynd_FRF.l[ite,joe07, spec_type, acl-1,tynd];

      sHTynd_FRF.l[ite,joe07, spec_type, acl,tynd]$(sHTynd_FRF.l[ite,joe07, spec_type, acl,tynd] = 0 and sHTynd_FRF.l[ite,joe07, spec_type, acl-1,tynd] and acl_spec_type[acl,spec_type])
       = sHTynd_FRF.l[ite,joe07, spec_type, acl-1,tynd];

      sTynd_AFF.l[skmodel,joe07, spec_type, acl,tynd]$(sTynd_AFF.l[skmodel,joe07, spec_type, acl,tynd] = 0 and sTynd_AFF.l[skmodel,joe07, spec_type, acl-1,tynd] and acl_spec_type[acl,spec_type])
       = sTynd_AFF.l[skmodel,joe07, spec_type, acl-1,tynd];

      sHTynd_AFF.l[skmodel,joe07, spec_type, acl,tynd]$(sHTynd_AFF.l[skmodel,joe07, spec_type, acl,tynd] = 0 and sHTynd_AFF.l[skmodel,joe07, spec_type, acl-1,tynd] and acl_spec_type[acl,spec_type])
       = sHTynd_AFF.l[skmodel,joe07, spec_type, acl-1,tynd];
 
      sTynd_NRE.l[ite,joe07, spec_type, acl,tynd]$(sTynd_NRE.l[ite,joe07, spec_type, acl,tynd] = 0 and sTynd_NRE.l[ite,joe07, spec_type, acl-1,tynd] and acl_spec_type[acl,spec_type])
       = sTynd_NRE.l[ite,joe07, spec_type, acl-1,tynd];

      sHTynd_NRE.l[ite,joe07, spec_type, acl,tynd]$(sHTynd_NRE.l[ite,joe07, spec_type, acl,tynd] = 0 and sHTynd_NRE.l[ite,joe07, spec_type, acl-1,tynd] and acl_spec_type[acl,spec_type])
       = sHTynd_NRE.l[ite,joe07, spec_type, acl-1,tynd];

      sTynd_NRE.l[ite,joe07, spec_type, acl,tynd]$(sTynd_NRE.l[ite,joe07, spec_type, acl,tynd] = 0 and sTynd_NRE.l[ite,joe07, spec_type, acl-1,tynd] and acl_spec_type[acl,spec_type])
       = sTynd_NRE.l[ite,joe07, spec_type, acl-1,tynd];

      sHTynd_NRE.l[ite,joe07, spec_type, acl,tynd]$(sHTynd_NRE.l[ite,joe07, spec_type, acl,tynd] = 0 and sHTynd_NRE.l[ite,joe07, spec_type, acl-1,tynd] and acl_spec_type[acl,spec_type])
       = sHTynd_NRE.l[ite,joe07, spec_type, acl-1,tynd];

       #På samme vis er er problemet der for korrektionsfaktorerne 


      sHTyndCorr_FRF.l[joe07, spec_type, acl]$(sHTyndCorr_FRF.l[joe07, spec_type, acl] = 0 and sHTyndCorr_FRF.l[joe07, spec_type, acl-1] and acl_spec_type[acl,spec_type])
       = sHTyndCorr_FRF.l[joe07, spec_type, acl-1];

      sHTyndCorr_AFF.l[skmodel,joe07, spec_type, acl]$(sHTyndCorr_AFF.l[skmodel,joe07, spec_type, acl] = 0 and sHTyndCorr_AFF.l[skmodel,joe07, spec_type, acl-1] and acl_spec_type[acl,spec_type])
       = sHTyndCorr_AFF.l[skmodel,joe07, spec_type, acl-1];

      sHTyndCorr_NRE.l[ite,joe07, spec_type, acl]$(sHTyndCorr_NRE.l[ite,joe07, spec_type, acl] = 0 and sHTyndCorr_NRE.l[ite,joe07, spec_type, acl-1] and acl_spec_type[acl,spec_type])
       = sHTyndCorr_NRE.l[ite,joe07, spec_type, acl-1];
      );


    #AFFORESTATION


    #HWP
      LOOP((acl,spec_type)$(acl_spec_type[acl,spec_type]), Tynding_coefs.l[joe07,spec_type,acl]$(Tynding_coefs.l[joe07,spec_type,acl]=0) = Tynding_coefs.l[joe07,spec_type,acl-1]); 
  

  #4) INITIAL VALUES 
  pFirewoodWoodchips.l[tx0] = 1;

  #5) DUMMIES



  d1qF5_aff[skmodel,joe07,spec_type,acl,t]          = yes$(qF5_aff.l[skmodel,joe07,spec_type,acl,t]);
    #Apart from baseline afforestation we would like to open for endogenous afforestation.

      #First we initiate age-classes for all forestperiods (tF)
      d1qF5_aff['11','Islands','C','acl5',tF] = yes;
      d1qF5_aff['18','Islands','B','acl5',tF] = yes;
      d1qF5_aff['12','Jutland','C','acl5',tF] = yes;
      d1qF5_aff['18','Jutland','B','acl5',tF] = yes;

      #Next we loop over forest-periods to fill in other age-classes
      LOOP(t$(tF[t]),   
        d1qF5_aff['11','Islands','C',acl,t]$(d1qF5_aff['11','Islands','C',acl-1,t-5]) = d1qF5_aff['11','Islands','C',acl-1,t-5];
        d1qF5_aff['18','Islands','B',acl,t]$(d1qF5_aff['18','Islands','B',acl-1,t-5]) = d1qF5_aff['18','Islands','B',acl-1,t-5];
        d1qF5_aff['12','Jutland','C',acl,t]$(d1qF5_aff['12','Jutland','C',acl-1,t-5]) = d1qF5_aff['12','Jutland','C',acl-1,t-5];
        d1qF5_aff['18','Jutland','B',acl,t]$(d1qF5_aff['18','Jutland','B',acl-1,t-5]) = d1qF5_aff['18','Jutland','B',acl-1,t-5];
      );  
      
    d1qF5_NRE[joe07,spec_type,acl,t]                  = yes$(qF5_NRE.l[joe07,spec_type,acl,t]);  
    d1qF5_LYS[joe07,spec_type,acl,t]                  = yes$(qF5_LYS.l[joe07,spec_type,acl,t]);
    d1qF5_FRF_NST[joe07,spec_type,acl,t]              = yes$(qF5_FRF_NST.l[joe07,spec_type,acl,t]);
    d1qC5_FRF_reducNST[joe07,spec_type,acl,t]         = yes$(qC5_FRF_reducNST.l[joe07,spec_type,acl,t]);
    d1qC5_FRF_reduc_hugst_NST[joe07,spec_type,acl,t]  = yes$(qC5_FRF_reduc_hugst_NST.l[joe07,spec_type,acl,t]);
  
   pHV2_hoved_FRF.l[joe07,spec_type,acl,t]$(sum(ite,ite2t(ite,t)))                                                                            = pData_Forest[acl,spec_type,joe07] + pHugstomk_usew.l[t];  
   pV2_tynd_FRF.l[joe07,spec_type,acl,t]$(sum(ite,ite2t(ite,t)))                                                                              = pData_Forest[acl,spec_type,joe07] + pHugstomk_usew.l[t];
   pHV2_hoved_NRE.l[joe07,spec_type,acl,t]$(d1qF5_NRE[joe07,spec_type,acl,t])                                                                 = pData_Forest[acl,spec_type,joe07] + pHugstomk_usew.l[t];
   pV2_tynd_NRE.l[joe07,spec_type,acl,t]$(d1qF5_NRE[joe07,spec_type,acl,t])                                                                   = pData_Forest[acl,spec_type,joe07] + pHugstomk_usew.l[t];
   pHV2_hoved_AFF.l[skmodel,joe07,spec_type,acl,t]$(d1qF5_AFF[skmodel,joe07,spec_type,acl,t] or d1qF5_AFF[skmodel,joe07,spec_type,acl,t+1])   = pData_Forest[acl,spec_type,joe07] + pHugstomk_usew.l[t]; #We add t+1 so that the relative forecast p/p-1 does not yield zero
   pV2_tynd_AFF.l[skmodel,joe07,spec_type,acl,t]$(d1qF5_AFF[skmodel,joe07,spec_type,acl,t] or d1qF5_AFF[skmodel,joe07,spec_type,acl,t+1])     = pData_Forest[acl,spec_type,joe07] + pHugstomk_usew.l[t]; #We add t+1 so that the relative forecast p/p-1 does not yield zero


   #Der tyndes poppel efter hhv. 20 og 25 år
   pV2_tynd_AFF.l['12','Jutland','C','acl25',t]$(pV2_tynd_AFF.l['12','Jutland','C','acl25',t]) = (37.9 + pHugstomk_usew.l[t])/10**6;
   pV2_tynd_AFF.l['11','Islands','C','acl20',t]$(pV2_tynd_AFF.l['11','Islands','C','acl20',t]) = (37.9 + pHugstomk_usew.l[t])/10**6;

   pHV2_hoved_AFF_data.l[skmodel,joe07,spec_type,acl,t] = pHV2_hoved_AFF.l[skmodel,joe07,spec_type,acl,t];
   pV2_tynd_AFF_data.l[skmodel,joe07,spec_type,acl,t]   = pV2_tynd_AFF.l[skmodel,joe07,spec_type,acl,t];


#6) VARIABLES COVERED BY DATA - these variables are included in the data-check, i.e. the calibrated model should not move these variables

  $GROUP G_lulucf_data
    qLU12$(t.val >= 1990 and t.val <= 2050)
    qLU8$(t.val >= 1990 and t.val <= 2050)
    qLUC8$(t.val >= 1990 and t.val <= 2050)
    qEmmLULUCF5$(t.val >= 1990 and t.val <= 2050)
    qEmmHWP$(t.val >= 1990 and t.val <= 2050)
    qEmmF_soil$(t.val >= 1990 and t.val <= 2050)
    qEmmtable4ii$(t.val >=1990 and t.val <=2050)
    qEmmPeatland$(t.val >=1990 and t.val <=2050)
  ;

  PARAMETER EmmBiomasse_CO2perha[t];                                                                                       
  EmmBiomasse_CO2perha[t]$(t.val>=2021)                #Det antages at 1 kha skov plantes i 2021! ( i know - jeg kunne bare lade være med at gange med 1)
                        = 44/12 * uDM2C.l['forest'] * 1 * (qBiomassStock9.l['crop_u6'] - qBiomassStock9.l['grass_u6'])$(t.val =2021) 
                        #
                         +44/12 * uDM2C.l['forest'] *  sum(tt$(tt.val <= t.val and tt.val>=2021), 1$(tt.val=2021) * uBiomass12.l[tt,t,'Forest'] * (qBiomassStock9.l['grass_u6'] - qBiomassStock9.l['forest'])); 
  


  PARAMETER EmmBiomasse_CO2perha[t];                                                                                       
  EmmBiomasse_CO2perha[t]$(t.val>=2021)                #Det antages at 1 kha skov plantes i 2021! ( i know - jeg kunne bare lade være med at gange med 1)
                        = 44/12 * uDM2C.l['forest'] * 1 * (qBiomassStock9.l['crop_u6'] - qBiomassStock9.l['grass_u6'])$(t.val =2021) 
                        #
                         +44/12 * uDM2C.l['forest'] *  sum(tt$(tt.val <= t.val and tt.val>=2021), 1$(tt.val=2021) * uBiomass12.l[tt,t,'Forest'] * (qBiomassStock9.l['grass_u6'] - qBiomassStock9.l['forest']));


  PARAMETER emmsoilstock_CO2perhaperaar;
  emmsoilstock_CO2perhaperaar
                      = (qSoilstock9.l['forest']-qSoilstock9.l['crop_u6'])*1/100;


  # ======================================================================================================================
  # Links to the CGE-model
  # ======================================================================================================================


    # 1) Initial values
      qY_CET_outother_02000_usewood.l[tF] = 1;
      pY_CET_outother_02000_usewood.l[tF] = 1; pY_CET_outother_02000_usewood.l[tF0] = 1; 
      pY_CET_usewoodtot.l[tx0] =1;
      pY_CET_usewoodtot_baseline.l[tx0] = 1;

$ENDIF

  
# ======================================================================================================================
# Static calibration
# ======================================================================================================================
$IF %stage% == "static_calibration":

  $GROUP G_lulucf_static_calibration
    G_lulucf_endo
    -qLU12$(tLULUC[t] and d1qLU12[land12,t]), uLU12_LUC12$(tLULUC[t] and d1qLU12[land12_r,t]) # Hack to ensure consistency even though LUC-matrix is not consistent

    -qEmmLU12xF[land12xF,t]$(tLULUC[t] and d1qEmmLU12xF[land12xF,t] and land12_GL_CL_min[land12xF] and t.val <=2050), uLU12xF$(tLULUC[t] and d1qEmmLU12xF[land12xF,t] and land12_GL_CL_min[land12xF])
  
    jEmmLULUCF$(tLULUC[t] and t.val <= 2050), -qEmmLULUCF5$(tLULUC[t] and t.val <= 2050)  # Calibrate to hit total LULUC emissions by land category
    jEmmLULUCF$(tF[t] and sameas[land5,'forest'] and t.val<=2050), -qEmmLULUCF5$(tF[t] and sameas[land5,'forest'] and t.val <=2050)  # Calibrate to hit total LULUC emissions by land category

    
    jEmmFstock_FRF , -qEmmfStock_FRF
    #  jEmmFstock_FRF$(acl_spec_type_report[acl,spec_type]),          -qEmmFstock_FRF$(acl_spec_type_report[acl,spec_type])
    jEmmFstock_AFF$(d1qF5_aff[skmodel,joe07,spec_type,acl,t]),     -qEmmFstock_AFF$(d1qF5_aff[skmodel,joe07,spec_type,acl,t])
    jC5_flow_tynd_FRF$(acl_spec_type_report[acl,spec_type]),       -qC5_tynd_FRF$(acl_spec_type_report[acl,spec_type])
    jC5_flow_hoved_FRF$(acl_spec_type_report[acl,spec_type]),      -qC5_hoved_FRF$(acl_spec_type_report[acl,spec_type])
    jF5_FRF$(acl_spec_type_report[acl,spec_type]),                 -qF5_FRF$(acl_spec_type_report[acl,spec_type]) 
    jF5_AFF$(acl_spec_type_report[acl,spec_type]),                 -qF5_AFF$(acl_spec_type_report[acl,spec_type])
    jC5_flow_hoved_AFF$(d1qF5_aff[skmodel,joe07,spec_type,acl,t]), -qC5_hoved_AFF$(d1qF5_aff[skmodel,joe07,spec_type,acl,t])
    jC5_flow_tynd_AFF$(d1qF5_aff[skmodel,joe07,spec_type,acl,t]),  -qC5_tynd_aff$(d1qF5_aff[skmodel,joe07,spec_type,acl,t])
    jEmmHWP$(t.val>=2021 and t.val <=2050),                        -qEmmHWP$(t.val>=2021 and t.val <=2050)

    #  LINKS
    -pHV2_hoved_FRF$(spec_type_xp[spec_type]),   j_pHV2_hoved_FRF$(spec_type_xp[spec_type])
    -pV2_tynd_FRF$(spec_type_xp[spec_type]),   j_pV2_tynd_FRF$(spec_type_xp[spec_type])
    -pHV2_hoved_NRE$(qC5_hoved_NRE.l[joe07,spec_type,acl,t]),   j_pHV2_hoved_NRE$(qC5_hoved_NRE.l[joe07,spec_type,acl,t])
    -pV2_tynd_NRE$(qC5_tynd_NRE.l[joe07,spec_type,acl,t]),  j_pV2_tynd_NRE$(qC5_tynd_NRE.l[joe07,spec_type,acl,t])
    -pHV2_hoved_AFF$(d1qF5_aff[skmodel,joe07,spec_type,acl,t]), j_pHV2_hoved_AFF$(d1qF5_aff[skmodel,joe07,spec_type,acl,t])
    -pV2_tynd_AFF$(d1qF5_aff[skmodel,joe07,spec_type,acl,t]), j_pV2_tynd_AFF$(d1qF5_aff[skmodel,joe07,spec_type,acl,t])

    j_qY_CET_outother_02000_usewood_CGE

    qY_CET_outother_02000_usewood$(tF0[t])
    qY_CET_outother_02000_usewood$(t.val=2019)
    qY_CET_outother_02000_usewood_smooth$(tF0[t])

    qY_CET_outother_02000_usewood_AFF$(tF0[t])
    qY_CET_outother_02000_usewood_AFF$(t.val=2019)
    qY_CET_outother_02000_usewood_AFF_smooth$(tF0[t])

    qPJ_energyXmill$(tF0[t])
    qPJ_energyXmill$(t.val=2019)
    qPJ_energyXmill_smooth$(tF0[t])


    qPJ_energyXmill$(tF0[t])
    qPJ_energyXmill$(t.val=2019)
    qPJ_energyXmill_smooth$(tF0[t])


    -pFirewoodWoodchips$(tF[t])
    -pTotalOperatingSurplus_AFF

  ;

  $GROUP G_lulucf_static_calibration_exo
    G_lulucf_exo
    #ikke-skov
    qLU12$(tLULUC[t] and d1qLU12[land12,t]), -uLU12_LUC12$(tLULUC[t] and d1qLU12[land12_r,t])

    qEmmLU12xF[land12xF,t]$(tLULUC[t] and d1qEmmLU12xF[land12xF,t] and land12_GL_CL_min[land12xF] and t.val<=2050), -uLU12xF$(tLULUC[t] and d1qEmmLU12xF[land12xF,t] and land12_GL_CL_min[land12xF])
   
    -jEmmLULUCF$(tLULUC[t] and t.val <= 2050), qEmmLULUCF5$(tLULUC[t] and t.val <= 2050)  # Calibrate to hit total LULUC emissions by land category
    -jEmmLULUCF$(tF[t] and sameas[land5,'forest'] and t.val<=2050), qEmmLULUCF5$(tF[t] and sameas[land5,'forest'] and t.val <=2050)  # Calibrate to hit total LULUC emissions by land category


    #skov
    -jEmmFstock_FRF , qEmmfStock_FRF
    #  -jEmmFstock_FRF$(acl_spec_type_report[acl,spec_type]),      qEmmFstock_FRF$(acl_spec_type_report[acl,spec_type])
    -jEmmFstock_AFF$(d1qF5_aff[skmodel,joe07,spec_type,acl,t]), qEmmFstock_AFF$(d1qF5_aff[skmodel,joe07,spec_type,acl,t])
    -jC5_flow_tynd_FRF$(acl_spec_type_report[acl,spec_type]),   qC5_tynd_FRF$(acl_spec_type_report[acl,spec_type])
    -jC5_flow_hoved_FRF$(acl_spec_type_report[acl,spec_type]),  qC5_hoved_FRF$(acl_spec_type_report[acl,spec_type])
    -jF5_FRF$(acl_spec_type_report[acl,spec_type]),             qF5_FRF$(acl_spec_type_report[acl,spec_type])
    -jF5_AFF$(acl_spec_type_report[acl,spec_type]),             qF5_AFF$(acl_spec_type_report[acl,spec_type])
    -jC5_flow_hoved_AFF$(d1qF5_aff[skmodel,joe07,spec_type,acl,t]), qC5_hoved_AFF$(d1qF5_aff[skmodel,joe07,spec_type,acl,t])
    -jC5_flow_tynd_AFF$(d1qF5_aff[skmodel,joe07,spec_type,acl,t]), qC5_tynd_aff$(d1qF5_aff[skmodel,joe07,spec_type,acl,t])
    -jEmmHWP$(t.val>=2021 and t.val <=2050), qEmmHWP$(t.val>=2021 and t.val <=2050)

    #LINKS
    pHV2_hoved_FRF$(spec_type_xp[spec_type]),   -j_pHV2_hoved_FRF$(spec_type_xp[spec_type])
    pV2_tynd_FRF$(spec_type_xp[spec_type]),   -j_pV2_tynd_FRF$(spec_type_xp[spec_type])
    pHV2_hoved_NRE$(qC5_hoved_NRE.l[joe07,spec_type,acl,t]),   -j_pHV2_hoved_NRE$(qC5_hoved_NRE.l[joe07,spec_type,acl,t])
    pV2_tynd_NRE$(qC5_tynd_NRE.l[joe07,spec_type,acl,t]),  -j_pV2_tynd_NRE$(qC5_tynd_NRE.l[joe07,spec_type,acl,t])
    pHV2_hoved_AFF$(d1qF5_aff[skmodel,joe07,spec_type,acl,t]), -j_pHV2_hoved_AFF$(d1qF5_aff[skmodel,joe07,spec_type,acl,t])
    pV2_tynd_AFF$(d1qF5_aff[skmodel,joe07,spec_type,acl,t]), -j_pV2_tynd_AFF$(d1qF5_aff[skmodel,joe07,spec_type,acl,t])

    -j_qY_CET_outother_02000_usewood_CGE
    -qY_CET_outother_02000_usewood$(tF0[t])
    -qY_CET_outother_02000_usewood$(t.val=2019)
    -qY_CET_outother_02000_usewood_smooth$(tF0[t])


    -qY_CET_outother_02000_usewood_AFF$(tF0[t])
    -qY_CET_outother_02000_usewood_AFF$(t.val=2019)
    -qY_CET_outother_02000_usewood_AFF_smooth$(tF0[t])

    -qPJ_energyXmill$(tF0[t])
    -qPJ_energyXmill$(t.val=2019)
    -qPJ_energyXmill_smooth$(tF0[t])
    
    pFirewoodWoodchips$(tF[t])
    pTotalOperatingSurplus_AFF

  ;

  $BLOCK B_lulucf_static_calibration
    E_uLU12xF[land12xF,t]$(tLULUC[t] and d1qEmmlu12xF[land12xF,t] and land12_GL_CL_min[land12xF] and t.val > 2050)..
      uLU12xF[land12xF,t] =E= uLU12xF[land12xF,'2050'];
  $ENDBLOCK

  $BLOCK B_lulucf_links_static_calibration 
        E_qY_CET_outother_02000_usewood_tF0[t]$(tF0[t]).. qY_CET_outother_02000_usewood[t] =E= qY_CET_outother_02000_usewood[t+1];
        E_qY_CET_outother_02000_usewood_tF0_[t]$(t.val=2019).. qY_CET_outother_02000_usewood[t] =E= qY_CET_outother_02000_usewood[t+1];
        E_qY_CET_outother_02000_usewood_smooth_tF0[t]$(tF0[t]).. qY_CET_outother_02000_usewood_smooth[t] =E= qY_CET_outother_02000_usewood_smooth[t+1];
        
        E_qY_CET_outother_02000_usewood_AFF_tF0[t]$(tF0[t]).. qY_CET_outother_02000_usewood_AFF[t] =E= qY_CET_outother_02000_usewood_AFF[t+1];
        E_qY_CET_outother_02000_usewood_AFF_tF0_[t]$(t.val=2019).. qY_CET_outother_02000_usewood_AFF[t] =E= qY_CET_outother_02000_usewood_AFF[t+1];
        E_qY_CET_outother_02000_usewood_AFF_smooth_tF0[t]$(tF0[t]).. qY_CET_outother_02000_usewood_AFF_smooth[t] =E= qY_CET_outother_02000_usewood_AFF_smooth[t+1];

        E_qPJ_energyXmill_tF0[t]$(tF0[t])..  qPJ_energyXmill[t] =E= qPJ_energyXmill[t+1];
        E_qPJ_energyXmill_tF0_[t]$(t.val=2019)..  qPJ_energyXmill[t] =E= qPJ_energyXmill[t+1];
        E_qPJ_energyXmill_smooth_tF0[t]$(tF0[t])..  qPJ_energyXmill_smooth[t] =E= qPJ_energyXmill_smooth[t+1];

  $ENDBLOCK

  $MODEL M_lulucf_static_calibration
    B_lulucf
    B_lulucf_static_calibration
    B_lulucf_links
    -E_vTotalCost_targetfromIfro_hugst #These equations take input from the static-calibration and hence are hence first added in the dynamic calibration
    -E_vTotalCost_parity_hugst         #These equations take input from the static-calibration and hence are hence first added in the dynamic calibration
    -E_vTotalCost_targetfromIfro_firew #These equations take input from the static-calibration and hence are hence first added in the dynamic calibration
    -E_vTotalCost_parity_firew         #These equations take input from the static-calibration and hence are hence first added in the dynamic calibration
    -E_vTotalCost_hugst                #These equations take input from the static-calibration and hence are hence first added in the dynamic calibration
    -E_vTotalCost_hugst_sum            #These equations take input from the static-calibration and hence are hence first added in the dynamic calibration
    -E_vTotalCost_firew                #These equations take input from the static-calibration and hence are hence first added in the dynamic calibration
    -E_vTotalCost_firew_sum            #These equations take input from the static-calibration and hence are hence first added in the dynamic calibration
    -E_vTotalCost                      #These equations take input from the static-calibration and hence are hence first added in the dynamic calibration
    -E_pTotalOperatingSurplus_AFF      #These equations take input from the static-calibration and hence are hence first added in the dynamic calibration
    B_lulucf_links_static_calibration 
    -E_restrict, -E_restrict_energy
  ;

    d1qEmmLU12xF[land12xF,t] = yes$(uLU12xF.l[land12xF,t] or sum(land12xf_a,uLUConv12xF.l[land12xf_a,land12xF]));

$ENDIF






# ======================================================================================================================
# Dynamic calibration
# ======================================================================================================================
$IF %stage% == "dynamic_calibration":
  

  #NOTE THAT THESE ARE ADDED TO ENDO-GROUP FURTHER DOWN
  $GROUP G_lulucf_calib 
    vTotLoggingCost[t] ""
    pAverageLoggingCostPerPJ[t] ""
    pAverageLoggingCostPerKM3[t] ""
    adj_target_vV2_2021_C ""
    adj_target_vV2_2021_B ""
    adj_pV2_AFF_islands_Table2[aclTable2,t] ""
    adj_pV2_AFF_jutland_Table2[aclTable2,t] ""
 
    Table2_Model[joe07,aclTable2] ""
    adj_wood_xport ""


    vTotalCost_firstgen[skmodel,joe07,spec_type,acl,t] ""
    vTotalCost_hugst_firstgen[skmodel,joe07,spec_type,acl,t] ""
    vTotalCost_firew_firstgen[skmodel,joe07,spec_type,acl,t] ""
    vTotalRevenue_firstgen[skmodel,joe07,spec_type,acl,t] ""
    vTotalRevenue_firew_firstgen[skmodel,joe07,spec_type,acl,t] ""
    vTotalRevenue_hugst_firstgen[skmodel,joe07,spec_type,acl,t] ""
 
    vTotalCost_hugst_fromAFF_firstgen[joe07,spec_type,acl,t] ""
    vTotalRevenue_fromAFF_firstgen[joe07,spec_type,acl,t] ""
    vTotalRevenue_firew_fromAFF_firstgen[joe07,spec_type,acl,t] ""
    vTotalRevenue_hugst_fromAFF_firstgen[joe07,spec_type,acl,t] ""


    vDBII_firstgen[skmodel,joe07,spec_type,acl,t] ""
    vDBII_fromAFF_firstgen[joe07,spec_type,acl,t] ""
    vPresentvalue_firstgen[joe07] ""
    vDBII_firstgen_table2[joe07,aclTable2] ""
    vDBII_firstgen_fromAFF_table2[joe07,aclTable2] ""

    adj2Table2_GSRmaj2023[aclTable2,joe07] ""
    adj_vPresentValueTable2[joe07] ""
  ;
  

  PARAMETER vPresentValueTable2[joe07];
  vPresentValueTable2['Jutland'] = -39800/10**6*inf_growth_factor['2022']; #All prices in 2022-prices, cf. mail from KEFM 12/1/2024
  vPresentValueTable2['Islands'] = -31900/10**6*inf_growth_factor['2022']; # 

  parameter d1Poppeliskovrejstynd[skmodel,joe07,spec_type,acl];
  d1Poppeliskovrejstynd['12','Jutland','C','acl25'] = yes;
  d1Poppeliskovrejstynd['11','Islands','C','acl20'] = yes;

  vV3.l[t]$(tx0[t] and not tF[t]) = vV3.l[tFstart];


  d1HugstTable2[joe07,aclTable2] = yes$(sum((skmodel,spec_type,acl,t), aclTable2_2_acl(aclTable2,acl) and d1qF5_AFF[skmodel,joe07,spec_type,acl,t] and (sHTynd_AFF.l[skmodel,joe07,spec_type,acl,'tynd_use'] or sTynd_AFF.l[skmodel,joe07,spec_type,acl,'tynd_use'])));


  $BLOCK B_lulucf_calib 
    #-----------------------------------------------------------------------------------------------------------------------------------#
    #KALIBRERER TIL 2021-PRODUKTIONSVÆRDIER
    #Se 2021-værdier i ark fra DST rekvireret per mail 15/8/2023
      #Bruges til at kalibrere hugstpriserne for nåletræer. Dog ikke skovrejsning. Skovrejsningspriserne kalibreres til at ramme GSR-forventninger
      E_target_vV2_2021_C.. 0.668125856*inf_growth_factor['2021'] =E=   sum((joe07,acl), vHV2_hoved_FRF[joe07,'C',acl,'2021']                                 + vV2_tynd_FRF[joe07,'C',acl,'2021'])
                                            + sum((joe07,acl),         vHV2_hoved_NRE[joe07,'C',acl,'2021']$(qC5_hoved_NRE.l[joe07,'C',acl,'2021'])           + vV2_tynd_NRE[joe07,'C',acl,'2021']$(qC5_tynd_NRE.l[joe07,'C',acl,'2021']))       
                                            + sum((skmodel,joe07,acl), vHV2_hoved_AFF[skmodel,joe07,'C',acl,'2021']$(d1qF5_AFF[skmodel,joe07,'C',acl,'2021']) + vV2_tynd_AFF[skmodel,joe07,'C',acl,'2021']$(d1qF5_AFF[skmodel,joe07,'C',acl,'2021']));                                     
                          
      #Bruges til at kalibrere hugstpriserne for løvtræer. Dog ikke skovrejsning. Skovrejsningspriserne kalibreres til at ramme GSR-forventninger
      E_target_vV2_2021_B.. 0.313324345*inf_growth_factor['2021'] =E=  sum((joe07,acl), vHV2_hoved_FRF[joe07,'B',acl,'2021']       + vV2_tynd_FRF[joe07,'B',acl,'2021'])
                                           + sum((joe07,acl),         vHV2_hoved_NRE[joe07,'B',acl,'2021']$(qC5_hoved_NRE.l[joe07,'B',acl,'2021'])           + vV2_tynd_NRE[joe07,'B',acl,'2021']$(qC5_tynd_NRE.l[joe07,'B',acl,'2021']))       
                                           + sum((skmodel,joe07,acl), vHV2_hoved_AFF[skmodel,joe07,'B',acl,'2021']$(d1qF5_AFF[skmodel,joe07,'B',acl,'2021']) + vV2_tynd_AFF[skmodel,joe07,'B',acl,'2021']$(d1qF5_AFF[skmodel,joe07,'B',acl,'2021']));   


      E_pHV2_hoved_FRF_2020[joe07,spec_type,acl,t]$(ite2t('ite0',t))..pHV2_hoved_FRF[joe07,spec_type,acl,t] =E= pHV2_hoved_FRF.l[joe07,spec_type,acl,t] * (adj_target_vV2_2021_C$(sameas[spec_type,'C']) + adj_target_vV2_2021_B$(sameas[spec_type,'B']));
      E_pV2_tynd_FRF_2020[joe07,spec_type,acl,t]$(ite2t('ite0',t))..  pV2_tynd_FRF[joe07,spec_type,acl,t]   =E= pV2_tynd_FRF.l[joe07,spec_type,acl,t]   * (adj_target_vV2_2021_C$(sameas[spec_type,'C']) + adj_target_vV2_2021_B$(sameas[spec_type,'B']));


      #Guider CGE-modellens efterspørgsel efter træprodukter på plads i 2021, så det svarer til skovemodellens. Det gøres igennem tilpasning af eksporten
      E_calib_export_target..  qD_usewood_CGE[tFStart] =E= qD_usewood_CGE[tF0] + adj_wood_xport;  #Bestemmmer adj_wood_xport
      E_calib_export[t]$(tx1[t] and not tF[t])..   qD_usewood_CGE[t] =E= qD_usewood_CGE[t-1] + adj_wood_xport; #Bestemmer sX_y i 2020
      E_sX_y_tFt[t]$(tF[t]).. sX_y['xOth','02000',t] =E= sX_y['xOth','02000',tF0];

      # E_vV3_tF0.. vV3[tF0] =E= vV3[tFstart]; #skovinvt. Vi ved ikke, hvad skovlagrene var til at starte med

    #-----------------------------------------------------------------------------------------------------------------------------------#
    #BEREGNER AFKAST OG OMKOSTNINGER FRA SKOVREJSNING, TOP DOWN. 
    #Det er vigtigt det er top-down, fordi det er indtægter og omkostninger på CGE-modellens præmisser - og det er vigtigt igen fordi det i sidste ende er CGE-modellens variable, der definerer velfærd
    #-----------------------------------------------------------------------------------------------------------------------------------#
      #(A) AFF-variable
      E_vTotalRevenue_hugst_firstgen[skmodel,joe07,spec_type,acl,t]$(tF[t] and d1qF5_AFF[skmodel,joe07,spec_type,acl,t] and sum(ite,firstgen(ite,acl) and ite2t(ite,t))).. 
        vTotalRevenue_hugst_firstgen[skmodel,joe07,spec_type,acl,t] =E=
                                                       (pHV2_hoved_AFF[skmodel,joe07,spec_type,acl,t-1] * qHV2_hoved_AFF[skmodel,joe07,spec_type,acl,t]/pY_CET_outother_02000_usewood[t-1] #/qY_CET_outother_02000_usewood[t]
                                                           +pV2_tynd_AFF[skmodel,joe07,spec_type,acl,t-1]* qV2_tynd_AFF[skmodel,joe07,spec_type,acl,t]/pY_CET_outother_02000_usewood[t-1])
                                                        #  Gang det med CGE-prisen og så får man total revenue 
                                                         *(pY_CET['out_other','02000',t] + pWoodproduct_markup[t])
                                                          /qF5_AFF_denom[skmodel,joe07,spec_type,acl,t] ;


      E_vTotalRevenue_firew_firstgen[skmodel,joe07,spec_type,acl,t]$(tF[t] and d1qF5_AFF[skmodel,joe07,spec_type,acl,t] and sum(ite,firstgen(ite,acl) and ite2t(ite,t))).. 
        vTotalRevenue_firew_firstgen[skmodel,joe07,spec_type,acl,t] =E=
                                                           qC5_Energy_AFF_xMill_full[skmodel,joe07,spec_type,acl,t] *44/12/103.4 * pY_CET['firewood and woodchips','02000',t]
                                                          /qF5_AFF_denom[skmodel,joe07,spec_type,acl,t];

      E_vTotalRevenue_firstgen[skmodel,joe07,spec_type,acl,t]$(tF[t] and d1qF5_AFF[skmodel,joe07,spec_type,acl,t] and sum(ite,firstgen(ite,acl) and ite2t(ite,t))).. 
        vTotalRevenue_firstgen[skmodel,joe07,spec_type,acl,t] =E= vTotalRevenue_hugst_firstgen[skmodel,joe07,spec_type,acl,t] + vTotalRevenue_firew_firstgen[skmodel,joe07,spec_type,acl,t];


         #Total cost in first generation
             E_vTotalCost_hugst_firstgen[skmodel,joe07,spec_type,acl,t]$(tF[t] and d1qF5_AFF[skmodel,joe07,spec_type,acl,t] and sum(ite,firstgen(ite,acl) and ite2t(ite,t))).. 
              vTotalCost_hugst_firstgen[skmodel,joe07,spec_type,acl,t] =E=  #vTotalCost_hugst[skmodel,joe07,spec_type,acl,t];
                                                              ((pHV2_hoved_AFF[skmodel,joe07,spec_type,acl,t-1] * qHV2_hoved_AFF[skmodel,joe07,spec_type,acl,t]/pY_CET_outother_02000_usewood[t-1] #/qY_CET_outother_02000_usewood[t]
                                                               +pV2_tynd_AFF[skmodel,joe07,spec_type,acl,t-1]* qV2_tynd_AFF[skmodel,joe07,spec_type,acl,t]/pY_CET_outother_02000_usewood[t-1])
                                                              #Gang det med CGE-prisen og så får man total revenue 
                                                              * (pY_CET['out_other','02000',t])/
                                                                (vY['02000',t]) 
                                        *(1-sUseWood_AFF[t]) * (pKELBM['02000',t]*qKELBM['02000',t] - sum(k, pK[k,'02000',t]*qK[k,'02000',t-1]/fq)))
                                                               /qF5_AFF_denom[skmodel,joe07,spec_type,acl,t]
                                                               ;
            E_vTotalCost_firew_firstgen[skmodel,joe07,spec_type,acl,t]$(tF[t] and d1qF5_aff[skmodel,joe07,spec_type,acl,t] and sum(ite,firstgen(ite,acl) and ite2t(ite,t))).. 
              vTotalCost_firew_firstgen[skmodel,joe07,spec_type,acl,t] =E=  #vTotalCost_firew[skmodel,joe07,spec_type,acl,t];
                                                                (qC5_Energy_AFF_xMill_full[skmodel,joe07,spec_type,acl,t] *44/12/103.4) * pY_CET['firewood and woodchips','02000',t]/
                                                                (vY['02000',t])
                                        *(1-sFireWood_AFF[t]) * (pKELBM['02000',t]*qKELBM['02000',t] - sum(k, pK[k,'02000',t]*qK[k,'02000',t-1]/fq))
                                                               /qF5_AFF_denom[skmodel,joe07,spec_type,acl,t]
                                                               ;

            E_vTotalCost_firstgen[skmodel,joe07,spec_type,acl,t]$(tF[t] and d1qF5_aff[skmodel,joe07,spec_type,acl,t] and sum(ite,firstgen(ite,acl) and ite2t(ite,t))).. 
              vTotalCost_firstgen[skmodel,joe07,spec_type,acl,t] =E= vTotalCost_hugst_firstgen[skmodel,joe07,spec_type,acl,t] + vTotalCost_firew_firstgen[skmodel,joe07,spec_type,acl,t];


   
                                               

        #(B) AFF-, der er overgået til FRF kategorien. Der brydes lidt med god kodepraksis ved at betinge på en variabel, der bliver lavet i den statiske kalibrering (qF5_FRF_fromAFF)
         E_vTotalRevenue_hugst_fromaff_firstgen[joe07,spec_type,acl,t]$(tF[t] and sum(skmodel,d1qF5_AFF[skmodel,joe07,spec_type,acl,t]) and qF5_FRF_fromAFF.l[joe07,spec_type,acl,t])..
          vTotalRevenue_hugst_fromaff_firstgen[joe07,spec_type,acl,t] =E= (( (pHV2_hoved_FRF[joe07,spec_type,acl,t-1] * qHV2_hoved_FRF_fromAFF[joe07,spec_type,acl,t])$(sHTynd_FRF.l['ite1',joe07,spec_type,acl,'tynd_use'])/pY_CET_outother_02000_usewood[t-1]
                                                                                +(pV2_tynd_FRF[joe07,spec_type,acl,t-1] * qV2_tynd_FRF_fromAFF[joe07,spec_type,acl,t])$(sTynd_FRF.l['ite1',joe07,spec_type,acl,'tynd_use'])/pY_CET_outother_02000_usewood[t-1])
                                                                                *(pY_CET['out_other','02000',t] + pWoodproduct_markup[t]))/qF5_FRF_fromAFF[joe07,spec_type,acl,t];


        E_vTotalRevenue_firew_fromaff_firstgen[joe07,spec_type,acl,t]$(tF[t] and sum(skmodel,d1qF5_AFF[skmodel,joe07,spec_type,acl,t]) and qF5_FRF_fromAFF.l[joe07,spec_type,acl,t]).. # and sum(ite,firstgen(ite,acl) and ite2t(ite,t))).. 
          vTotalRevenue_firew_fromaff_firstgen[joe07,spec_type,acl,t]  =E=
                                                             qC5_Energy_FRF_fromAFF_xMill[joe07,spec_type,acl,t] *44/12/103.4 * pY_CET['firewood and woodchips','02000',t]/qF5_FRF_fromAFF[joe07,spec_type,acl,t]
                                                            ;

        E_vTotalRevenue_fromAFF_firstgen[joe07,spec_type,acl,t]$(tF[t] and sum(skmodel,d1qF5_AFF[skmodel,joe07,spec_type,acl,t]) and qF5_FRF_fromAFF.l[joe07,spec_type,acl,t])..  #and sum(ite,firstgen(ite,acl) and ite2t(ite,t))).. 
          vTotalRevenue_fromAFF_firstgen[joe07,spec_type,acl,t] =E= vTotalRevenue_hugst_fromaff_firstgen[joe07,spec_type,acl,t] + vTotalRevenue_firew_fromaff_firstgen[joe07,spec_type,acl,t];



        E_vTotalCost_hugst_fromaff_firstgen[joe07,spec_type,acl,t]$(tF[t] and sum(skmodel,d1qF5_AFF[skmodel,joe07,spec_type,acl,t]) and qF5_FRF_fromAFF.l[joe07,spec_type,acl,t]).. # and sum(ite,firstgen(ite,acl) and ite2t(ite,t))).. 
          vTotalCost_hugst_fromaff_firstgen[joe07,spec_type,acl,t] =E= 
                                                            (((pHV2_hoved_FRF[joe07,spec_type,acl,t-1] * qHV2_hoved_FRF_fromAFF[joe07,spec_type,acl,t])$(sHTynd_FRF.l['ite1',joe07,spec_type,acl,'tynd_use'])/pY_CET_outother_02000_usewood[t-1] #/qY_CET_outother_02000_usewood[t]
                                                             +(pV2_tynd_FRF[joe07,spec_type,acl,t-1] * qV2_tynd_FRF_fromAFF[joe07,spec_type,acl,t])$(sTynd_FRF.l['ite1',joe07,spec_type,acl,'tynd_use'])/pY_CET_outother_02000_usewood[t-1])
                                                            #Gang det med CGE-prisen og så får man total revenue 
                                                            * (pY_CET['out_other','02000',t]) 
                                                            + (qC5_Energy_FRF_fromAFF_xMill[joe07,spec_type,acl,t] *44/12/103.4) * pY_CET['firewood and woodchips','02000',t])/
                                                             (vY['02000',t])*
                                                             (pKELBM['02000',t]*qKELBM['02000',t] - sum(k, pK[k,'02000',t]*qK[k,'02000',t-1]/fq))/qF5_FRF_fromAFF[joe07,spec_type,acl,t]
                                                             
                                                             ;                                 


      #-----------------------------------------------------------------------------------------------------------------------------------#
      # OPSAMLER AFKAST I DÆKNINGSBIDRAG
      #-----------------------------------------------------------------------------------------------------------------------------------#
  
      E_vDBII_firstgen[skmodel,joe07,spec_type,acl,t]$(tF[t] and d1qF5_AFF[skmodel,joe07,spec_type,acl,t] and sum(ite,firstgen(ite,acl) and ite2t(ite,t))).. 
        vDBII_firstgen[skmodel,joe07,spec_type,acl,t] =E= vTotalRevenue_firstgen[skmodel,joe07,spec_type,acl,t] - vTotalCost_firstgen[skmodel,joe07,spec_type,acl,t];
      
      E_vDBII_fromAFF_firstgen[joe07,spec_type,acl,t]$(tF[t] and sum(skmodel,d1qF5_AFF[skmodel,joe07,spec_type,acl,t]) and qF5_FRF_fromAFF.l[joe07,spec_type,acl,t]).. # and sum(ite,firstgen(ite,acl) and ite2t(ite,t))).. 
        vDBII_fromAFF_firstgen[joe07,spec_type,acl,t] =E= vTotalRevenue_fromAFF_firstgen[joe07,spec_type,acl,t] - vTotalCost_hugst_fromaff_firstgen[joe07,spec_type,acl,t];

      E_vDBII_firstgen_table2[joe07,aclTable2].. 
        vDBII_firstgen_table2[joe07,aclTable2] 
              =E= 
                sum((skmodel,spec_type,acl,t)$(sum(ite,firstgen(ite,acl) and ite2t(ite,t)) and tF[t] and d1qF5_aff[skmodel,joe07,spec_type,acl,t] and aclTable2_2_acl(aclTable2,acl)), 
                          vDBII_firstgen[skmodel,joe07,spec_type,acl,t])
                 /sum((t,acl), 1$(sum(ite,firstgen(ite,acl) and ite2t(ite,t)) and tF[t] and aclTable2_2_acl(aclTable2,acl)));
            # =E= sum((t,acl), 1$(sum(ite,firstgen(ite,acl) and ite2t(ite,t)) and tF[t] and aclTable2_2_acl(aclTable2,acl)));

      E_vDBII_firstgen_fromAFF_table2[joe07,aclTable2]$(sameas[aclTable2,'40_100'])..
        vDBII_firstgen_fromAFF_table2[joe07,aclTable2] =E= sum((spec_type,acl,t)$(qF5_FRF_fromAFF.l[joe07,spec_type,acl,t]), 
                                                               vDBII_fromAFF_firstgen[joe07,spec_type,acl,t])
                                                              /sum((t,acl), 1$(sum(spec_type,qF5_FRF_fromAFF.l[joe07,spec_type,acl,t])));


      E_vPresentvalue_firstgen[joe07].. 
       
        vPresentvalue_firstgen[joe07] =E= sum((skmodel,spec_type,acl,t)$(sum(ite,firstgen(ite,acl) and ite2t(ite,t)) and tx0[t] and tF[t] and d1qF5_aff[skmodel,joe07,spec_type,acl,t]), vDBII_firstgen[skmodel,joe07,spec_type,acl,t]/(1+0.0272)**(t.val-2019))
                                          -(pI_afforestation_external[joe07]/10**6)$(sameas[joe07,'islands']) #65000 kroner per ha = 65000/10**9 mia. kroner per ha. = 65000/10**9 * 1000  mia. kroner per kha
                                          -(pI_afforestation_external[joe07]/10**6)$(sameas[joe07,'jutland']);

      #-----------------------------------------------------------------------------------------------------------------------------------#
      # TILPASNINGSLIGNINGER, HVIS VI SKAL RAMME NUTIDSVÆRDI I TABEL2
      #-----------------------------------------------------------------------------------------------------------------------------------# 
        E_jHV2_hoved_AFF[skmodel,joe07,spec_type,acl,t]$(tx0[t] and tF[t] and d1qF5_aff[skmodel,joe07,spec_type,acl,t] and pHV2_hoved_AFF.l[skmodel,joe07,spec_type,acl,t]).. 
          j_pHV2_hoved_AFF[skmodel,joe07,spec_type,acl,t] =E= adj_vPresentValueTable2[joe07];

        E_jV2_tynd_AFF[skmodel,joe07,spec_type,acl,t]$(tx0[t] and tF[t] and d1qF5_aff[skmodel,joe07,spec_type,acl,t] and pV2_tynd_AFF.l[skmodel,joe07,spec_type,acl,t] and not d1Poppeliskovrejstynd[skmodel,joe07,spec_type,acl])..
          j_pV2_tynd_AFF[skmodel,joe07,spec_type,acl,t]   =E= adj_vPresentValueTable2[joe07];
        


        E_adj_vPresentValueTable2[joe07].. 
          vPresentValueTable2[joe07] =E= vPresentvalue_firstgen[joe07];
   
        E_pY_CET_usewood_tot_baseline[t]$(tx0[t])..
          pY_CET_usewoodtot_baseline[t] =E= pY_CET['out_other','02000',t] + pWoodproduct_markup[t];

  $ENDBLOCK

  $GROUP G_lulucf_calib
    G_lulucf_endo
    G_lulucf_links_endo
    G_lulucf_calib

    sX_y$(tx1[t] and sameas[x,'xOth'] and sameas[s,'02000']) # and not tF[t]

    j_qY_CET_outother_02000_usewood_CGE$(tx0[t] and tF[t]), -pWoodproduct_markup$(tx0[t] and tF[t])
    j_PJ_energyXmill_smooth$(tx0[t] and tF[t]), -markup$(tx0[t] and tF[t] and d1vY_CET[out,s,t] and sameas[out,'firewood and woodchips'] and sameas[s,'02000'])
    qY_CET$(tx0[t] and tF[t] and d1vY_CET[out,s,t] and sameas[out,'firewood and woodchips'] and sameas[s,'02000']), -markup$(tx0[t] and tF[t] and d1vY_CET[out,s,t] and sameas[out,'firewood and woodchips'] and sameas[s,'02000']) 

    #Rammaer 2021-produktionsværdi
    pHV2_hoved_FRF$(sum(ite,ite2t(ite,t) and sameas[ite,'ite0']))
    pV2_tynd_FRF$(sum(ite,ite2t(ite,t) and sameas[ite,'ite0']))

    vV3$(tF0[t]) #E_vV3_tF0 #skovinvt

      j_pHV2_hoved_AFF$(tx0[t] and tF[t]  and d1qF5_aff[skmodel,joe07,spec_type,acl,t] and pHV2_hoved_AFF.l[skmodel,joe07,spec_type,acl,t]) # and aclTable2_2_acl('40_100',acl) and sameas[joe07,'jutland']) # and sum(ite,firstgen(ite,acl) and ite2t(ite,t)))
      j_pV2_tynd_AFF$(tx0[t] and tF[t] and d1qF5_aff[skmodel,joe07,spec_type,acl,t] and pV2_tynd_AFF.l[skmodel,joe07,spec_type,acl,t] and not d1Poppeliskovrejstynd[skmodel,joe07,spec_type,acl]) # and aclTable2_2_acl('40_100',acl) and sameas[joe07,'jutland']) #and sum(ite,firstgen(ite,acl) and ite2t(ite,t)))

    pY_CET_usewoodtot_baseline$(tx0[t])


    #B_lulucf_links_static_calibration
    qY_CET_outother_02000_usewood$(tF0[t])
    qY_CET_outother_02000_usewood$(t.val=2019)
    qY_CET_outother_02000_usewood_smooth$(tF0[t])

    qY_CET_outother_02000_usewood_AFF$(tF0[t])
    qY_CET_outother_02000_usewood_AFF$(t.val=2019)
    qY_CET_outother_02000_usewood_AFF_smooth$(tF0[t])

    qPJ_energyXmill$(tF0[t])
    qPJ_energyXmill$(t.val=2019)
    qPJ_energyXmill_smooth$(tF0[t])

  ;

  $GROUP G_lulucf_calib_exo
    G_lulucf_exo
    G_lulucf_links_exo

    -j_qY_CET_outother_02000_usewood_CGE$(tx0[t] and tF[t]), pWoodproduct_markup$(tx0[t] and tF[t])
    -j_PJ_energyXmill_smooth$(tx0[t] and tF[t]), markup$(tx0[t] and tF[t] and d1vY_CET[out,s,t] and sameas[out,'firewood and woodchips'] and sameas[s,'02000'])
    markup$(tx0[t] and tF[t] and d1vY_CET[out,s,t] and sameas[out,'firewood and woodchips'] and sameas[s,'02000'])
    qV2$(tx0[t] and not tF[t])

    -pHV2_hoved_FRF$(sum(ite,ite2t(ite,t) and sameas[ite,'ite0']))
    -pV2_tynd_FRF$(sum(ite,ite2t(ite,t) and sameas[ite,'ite0']))

    pY0$(sameas[s,'02000'])

    #B_lulucf_links_static_calibration
    -qY_CET_outother_02000_usewood$(tF0[t])
    -qY_CET_outother_02000_usewood$(t.val=2019)
    -qY_CET_outother_02000_usewood_smooth$(tF0[t])
    -qY_CET_outother_02000_usewood_AFF$(tF0[t])
    -qY_CET_outother_02000_usewood_AFF$(t.val=2019)
    -qY_CET_outother_02000_usewood_AFF_smooth$(tF0[t])


    -qPJ_energyXmill$(tF0[t])
    -qPJ_energyXmill$(t.val=2019)
    -qPJ_energyXmill_smooth$(tF0[t])

    #B_lulucf_calib
    pKELBM$(tx0[t] and sameas[s,'02000'])
    qKELBM$(tx0[t] and sameas[s,'02000'])
    vY$(tx0[t] and sameas[s_,'02000'])
    pK$(tx0[t] and sameas[sp,'02000']), qK$(tx0[t] and sameas[s,'02000'])

    pY_CET$(tx0[t] and sameas[s,'02000'] and sameas[out,'out_other'])
    pY_CET$(tx0[t] and sameas[s,'02000'] and sameas[out,'Firewood and woodchips'])
  ;

  $MODEL M_lulucf_calib
    B_lulucf
    B_lulucf_links
    B_lulucf_calib
    B_lulucf_links_static_calibration
  ;

  #Value of J-term - we abstain from calibrating and just compute it
  j_PJ_energyXmill_smooth.l[t] = qPJ_energyXmill_smooth.l['2021'] - qY_CET.l['Firewood and woodchips','02000','2019'];

  j_pHV2_hoved_NRE.l[joe07,spec_type,acl,tForecast] = 0;
  j_pV2_tynd_NRE.l[joe07,spec_type,acl,tForecast] = 0;
  j_pHV2_hoved_AFF.l[skmodel,joe07,spec_type,acl,tForecast] = 0;
  j_pV2_tynd_AFF.l[skmodel,joe07,spec_type,acl,tForecast] = 0;

  jEmmLULUCF.l[land5,t]$(t.val>2050) = jEmmLULUCF.l[land5,'2050'];
  


  $MODEL M_lulucf_calib_premodel 
    M_lulucf_calib
    #We subtract equations that link to the rest of the model
    -E_restrict
    -E_restrict_energy
    -E_qD_usewood_CGE
    -E_sX_y_tFt
    -E_calib_export_target
    -E_calib_export
  ;

  $GROUP G_lulucf_calib_premodel_exo 
    G_lulucf_calib_exo
    pWoodproduct_markup  
  ;

  $GROUP G_lulucf_calib_premodel_endo 
    G_lulucf_calib
    -pWoodproduct_markup
  ;

  $FIX G_lulucf_calib_premodel_exo;
  $UNFIX G_lulucf_calib_premodel_endo;
  @SOLVE(M_lulucf_calib_premodel);
  # execute_unload 'output\pre.gdx';

$ENDIF
