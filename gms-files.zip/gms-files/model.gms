# ======================================================================================================================
# Model definition
# ======================================================================================================================
# In this file we define the sets, variables, and equations that comprise the model.
# The variables and equations are organized in groups of variable and blocks of equation.
# We combine the module-specific groups into bigger groups.
# Finally, we combine the blocks of equations to get the basic model.

# ----------------------------------------------------------------------------------------------------------------------
# Set time periods
# ----------------------------------------------------------------------------------------------------------------------

  set_time_periods(%cal_start%, %cal_end%);

# ======================================================================================================================
# Variables
# ======================================================================================================================
# ----------------------------------------------------------------------------------------------------------------------
# Variable definitions
# ----------------------------------------------------------------------------------------------------------------------
@import_from_modules("variables")

# ----------------------------------------------------------------------------------------------------------------------
# Group compilation
# ----------------------------------------------------------------------------------------------------------------------
@import_from_modules("groupcompilation")


# Endogenous variables
# We combine the endo groups from each module into a group of all endogenous variables.
$GROUP G_Endo
        G_exports_endo
        G_energy_markets_endo
        G_labor_market_endo
        G_production_private_endo
        G_production_public_endo
        G_consumers_endo
        G_government_endo
        G_taxes_bottom_endo
        G_taxes_total_endo
        G_taxes_energy_endo
        G_aggregates_endo
        G_IO_endo
        G_emissions_endo
        G_abatement_endo
        G_waste_endo
        G_production_plant_endo 
        G_production_ani_endo
        G_production_agr_endo
        G_GE_LINKS_ANI
        G_GE_LINKS_PLANT
        G_GE_ENDOGENIZE_PLANT
        G_GE_ENDOGENIZE_ANI
        G_GE_LINKS_EMMI_PLANT
        G_GE_LINKS_EMMI_ANI
        G_LULUCF_endo
        G_leakage_shock_endo
        G_udvaskning_endo
        G_pyrolyse_endo
        -qY_CET$(sameas[s,'03000'] and d1vY_CET[out,s,t]), markup$(sameas[s,'03000'] and d1vY_CET[out,s,t])

;

$GROUP G_exo 
  G_IO_exo 
  G_energy_markets_exo
  G_labor_market_exo
  G_Government_exo 
  G_production_private_exo
  G_production_public_exo
  G_taxes_bottom_exo
  G_taxes_total_exo
  G_taxes_energy_exo
  G_exports_exo
  G_consumers_exo
  G_aggregates_exo
  G_emissions_exo
  G_abatement_exo
  G_waste_exo
  G_production_agr_exo 
  G_production_plant_exo 
  G_production_ani_exo 
  G_LULUCF_exo
  G_leakage_shock_exo
  G_udvaskning_exo
  G_Pyrolyse_exo
  qY_CET$(sameas[s,'03000'] and d1vY_CET[out,s,t]), -markup$(sameas[s,'03000'] and d1vY_CET[out,s,t])
;

# To make growth and inflation adjustment easier, we create groups for all prices, quantities, and values respectively.
$GROUP G_prices  # Variables that should be adjusted for inflation
       G_exports_prices
       G_energy_markets_prices
       G_production_private_prices
       G_production_public_prices
       G_consumers_prices
#       G_government_prices
       G_aggregates_prices
       G_IO_prices
       G_abatement_prices
       G_agr_prices
       G_ani_prices
       G_plant_prices
;

$GROUP G_quantities  # Variables that should be adjusted for general productivity growth
       G_exports_quantities
       G_energy_markets_quantities
       G_production_private_quantities
       G_production_public_quantities
       G_consumers_quantities
       G_government_quantities
       G_aggregates_quantities
       G_IO_quantities
       G_abatement_quantities
       G_agr_quantities
       G_ani_quantities
       G_plant_quantities
;

$GROUP G_values  # Variables that should both be adjusted for inflation and general productivity growth
       G_labor_market_values
       G_energy_markets_values
       G_production_private_values
       G_production_public_values
       G_government_values
       G_taxes_values
       G_aggregates_values
       G_IO_values
;

$GROUP G_baseline # Variables that we want to be reported as baseline values
       G_baseline_agr
       G_baseline_ani
       G_baseline_plant
       G_baseline_production
;

$GROUP G_baseline_newvars 
       $LOOP G_baseline:
              {name}_baseline{sets} ""
       $ENDLOOP 
;

# ======================================================================================================================
# Equations
# ======================================================================================================================

# Equations are defined in each module and organized in "blocks". They are imported here.
@import_from_modules("equations")


# ----------------------------------------------------------------------------------------------------------------------
# Main model
# ----------------------------------------------------------------------------------------------------------------------
# We define the model as the combination of equation blocks from each imported module
$MODEL M_base
       M_taxes_bottom
       M_taxes_total
       M_taxes_energy
       M_energy_markets
       B_exports
       M_production_private
       M_production_public
       M_labor_market
       M_consumers
       M_government
       M_IO
       M_aggregates
       M_emissions
       M_abatement
       M_production_agr_plant
       M_production_agr_ani
       M_production_agr
       M_waste
       M_LULUCF
       B_leakage
       B_udvaskning
       M_pyrolyse
;

# ======================================================================================================================
# Set exogenous parameters
# ======================================================================================================================
# Set dummies to indicate years where we have full data.
# They are used to control which years microdata should be calibrated to match aggregates.

# Run exogenous_values part of each module
@import_from_modules("read_data")

@import_from_modules("exogenous_values")

# Run update_dummies part of each module
$import update_dummies.gms

# Adjust for growth and inflation
@inf_growth_adjust()

#Retter jord og jordpris (som ellers er blevet vækst- og inflationskorrigeret)
	qPlant.l[plant_sectors,'land',t] = qPlant.l[plant_sectors,'land',t]/growth_factor[t];
	pLand.l[t]                       = pLand.l[t]/inf_factor[t]*inf_growth_factor[t];
	pPlant.l[plant_sectors,'land',t] = pPlant.l[plant_sectors,'land',t]/inf_factor[t]*inf_growth_factor[t];
	
# ======================================================================================================================
# Save data
# ======================================================================================================================

# Variables covered by data (or an exogenous forecast) that should not be changed by the calibration.
parameter d1jqI_s[s];
d1jqI_s[s] = no;

$GROUP G_data
    G_exports_data
    G_energy_markets_data
    G_labor_market_data
    G_production_private_data
    G_production_public_data
    G_consumers_data
    G_government_data
    G_taxes_data
    G_aggregates_data
    G_IO_data    
    G_agr_data
    G_ani_data
    G_plant_data
    G_emissions_data
    -pREa
    -qAni
    -pAni
    -qPlant
    -pPlant
    -qEmmProdxE$(sameas[s,'01031'] or sameas[s,'01032'] or sameas[s,'01051'] or sameas[s,'01052'] or sameas[s,'01061'] or sameas[s,'01062']) # Trækker data tjek ud for animalske non-energy emissioner
    -qK$(t1[t] and d1jqI_s[s])
    -qRxE_pgroup
    -pRxE_pgroup
    -vRxE_pgroup

;

$GROUP G_data G_data$(tData[t]);

#Add LULUCF-data which has a larger time-base 

$GROUP G_data 
  G_data 
  G_lulucf_data
  -qEmmHWP
  G_udvaskning_data
  G_waste_data$(tWaste_dst[t]) 
;


@save(G_data);  # Save snapshot of all data, to check that all data is intact after calibration.

execute_unload 'Output/model.gdx';
