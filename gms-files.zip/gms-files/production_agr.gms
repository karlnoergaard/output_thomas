# ======================================================================================================================
#		 AGRICULTURAL MODULE
# ======================================================================================================================
# A brief overview:
#
# 1) In the first stage (%stage%=="variables") variables are created in GAMS 
#
# 2) In the second stage (%stage%=="GroupCompilation") variables are bunched together in $GROUPS. This allows us to perform the same action over collections of variable, most prominently defining which variables are exogenous and which are endogenous.
#
# 3) In the third stage (%stage%=="equations") blocks of equations are defined. Together the blocks add up to the GreenREFORM agricultural module (for the LULUCF-module see lulucf.gms). 
#
# 4) In the fourth stage (%stage%=="exogenous_values") data is loaded into the module variables. A bit of residual data-treament is also carried out in this stage.
#
# 5) In the fifth stage (%stage%=="static_calibration") additional equations are added for the so-called static calibration. In this step the model is "inverted" in data-years. That is, endogenous variables are exogenized and calibration-parameters are endogenized.
#
# 6) In the sixth stage (%stage%=="dynamic_calibration") additional equations are added for the so-called dynanic calibration. In this step a partial version of the agricultural module is also compiled. This stage otherwise collects variables and equations and projects 
#    and would calibrate a "raw" projection of the agricultural module from last data year to 2099. The module is however calibrated to many external sources. Most importantly a calibration of production, prices, and emissions. This is collected in the file integration_agr.gms
# ======================================================================================================================


# ======================================================================================================================
# Variable definition
# ======================================================================================================================

$IF %stage% == "variables":

	#-------------------------------------------------------------------------------------------------------------------
	# Variables for the CES-production function: Prices, quantities, values, CES-shares, etc...
	#-------------------------------------------------------------------------------------------------------------------

	$GROUP G_agr_prices
		pD_manure[t] 													            "Market clearing price for manure (Bio. kroner per mio. tonnes of N-equivalent. Prices is inflation- and growth-adjusted)"
		pD_litter[t] 													            "Market clearing for litter (Price index of equilibrium price of litter, inflation adjusted)" 	
		pRxE_nm[Agri_sectorss,agri_sectors,Agri_,t]                      			"Non-market inputs in production function (Price index of non-market inputs, inflation adjusted)"
		pNH3[t]                                                          			"Social cost of ammonia-emissions. Only costs related to Danish residents are included (bio kr. per kiloton NH3-emitted, inflation adjusted)"
	;

	$GROUP G_agr_quantities 
		qD_manure[t] 										                        "Total demand for manure, megaton N-equivalent (Samlet efterspørgsel efter husdyrgødning, målt i mtN tilført til mark)"
		qD_litter[t] 													            "Total demand for litter, bio.kr. growth-adjusted (Samlet efterspørgsel efter halmstrøelse, målt i mia. kr. 2019-priser, vækstkorrigerede)"
		qRxE_nm[Agri_sectorss,Agri_sectors,Agri_,t]                       			"Non-market inputs in  production function, bio. kr. growth-adjusted"
	;

	$GROUP G_agr_report			
		vGrossValAdd_agr_nm[agri_sectors,t]$(tx0[t])                      			"Gross value added in agricultural sectors, when including non-market production and consumption, bio. kr. inflation and growth-adjusted (Bruttoværditilvækst i produktionsgrene, inkl. ikke-markedsmæssige transaktioner, mia. kr. vækst-og inf. korr)"
		vY_agr_market[agri_sectors,t]$(tx0[t])                            			"Value of market production in agricultural sectors, bio. kr. inflation and growth-adjusted (Værdi af markedsmæssig produktion i landbrugets produktionsgrene, mia. kr. vækst-og inf. korr.)"
		vInput_agr_market[agri_sectors,t]$(tx0[t])                        			"Value market inputs in agricultural production, bio. kr. inflation and growth-adjusted (Værdi af markedsmæssige input i produktionen i landbrugets produktionsgrene, mia. kr. vækst-og inf. korr.)"
		vInput_01080_market[t]$(tx0[t])                                   			"Value of inputs for agrictultural constractor, bio. kr. inflation and growth-adjusted (Værdi af inputs i maskinstationsbranchen, mia. kr. vækst-og i inf. korr.)"
		vY_agr_nm[agri_sectors,t]$(tx0[t])                                			"Value of non-market production, bio. kr. inflation- and growth-adjusted (Værdi af ikke-marekdsmæssig produktion i landbrugets produktionsgrene, mia. kr. vækst-og inf. korr.)"
		vInput_agr_nm[agri_sectors,t]$(tx0[t])                            			"Value of non-market inputs in production, bio. kr. inflation- and growth-adjusted (Værdi af ikke-markedsmæssige input i landbrugets produktionsgrene, mia. kr. vækst-og inf. korr.) "
		vY_agr[agri_sectors,t]$(tx0[t])                                   			"Value of production, both market and non-market (vY_agr_market + vy_agr_nonmarket), bio. kr. inflation and growth-adjusted (Værdi af samlet produktion (markeds- og ikke-markedsmæssig), i landbrugets produktionsgrene)"
		vInput_agr[agri_sectors,t]$(tx0[t])                               			"Value of inputs, both market and non-market, in agricultural productoin, bio. kr. inflation and growth-adjusted (Værdi af input i landbrugets produktionsgrene, både markeds- og ikke-markedsmæssig, mia. kr. vækst-og inf. korr.)"
		qEmmIntensity[agri_sectors,t,emm_eq]$(tx0[t] and sum(emmtype, d1EmmAgrxE[emmtype,Agri_sectors,t,emm_eq]) and sameas[emm_eq,'CO2e']) 	"Non-energy related agricultural emissions per value of production (both market, and non-market), ktCO2e per bio. kr. output"
		vBVT_01080_cpntns[BVTagr_cpntns,t]$(tx0[t])                       			"Decomposition of production value for agricultural contractor, inflation and growth-adjusted (Dekomponering af BVT i maskinstation, mia. kr. vækst- og inf. korr.)"
		vEmmNH3[t]$(tx0[t])                                               			"Social cost of ammonia emissions to Danish residents, bio. kr. inflation and growth-adjusted (Skadesomkostning fra ammoniakudledninger på danske indbyggere, mia. kr. vækst- og inf. korr.)"                        
    pK_alt[k,sp,t]   ""
    pTobinsQ_alt[k,sp,t]  ""
	;

	#-------------------------------------------------------------------------------------------------------------------
	# Agricultural non-energy related emissions
	#-------------------------------------------------------------------------------------------------------------------

$ENDIF 

# ======================================================================================================================
# Compiling groups of endogenous and exogenous values
# ======================================================================================================================

$IF %stage% == "groupcompilation":

  	$GROUP G_agr_qK
  		qAni$(Ani_pK[Ani_])
  		qPlant$(Plant_pK[Plant_]) 
	;

 	$GROUP G_agr_non_flat_initial_values
	    vtCAP_tot
  	;

	$GROUP G_production_agr_endo 
    #Ani
    pAni$(tx0[t] and sameas[ani_,'litter'])

		pD_manure, qD_manure

		# Non market
		pRxE_nm$(d1RxE_nm[Agri_sectorss,Agri_sectors,Agri_,t])
		
		#Plants
    qPlant_CET$((Plant_out_top_nm[Plant_out]) and d1Plant_CET0[Plant_sectors,plant_out,t]) #kommer senere
    pPlant$(tx0[t] and nonNRnestsPlant[Plant_])
	;

		$GROUP G_production_agr_endo G_production_agr_endo$(tx0[t]);


	$GROUP G_production_agr_exo
		vCO2_plant$(sameas[plant_,'Manure'])
		sPlant_AGG												                
		ePlant_AGG 																		                
		vtLand$(tx0[t])
		vTech_subsidy_plant[Techplant,EmmType,plant_sectors,t]$(tx0[t] and sum(emm, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]))					

		# Plant 
		pPlant_CET$(plant_out_top_nm[Plant_out])
		qPlant$(nonNRnestsPlant[Plant_])
    	    	
		#Ani
		qNManureOtherAnimals

		# Non-market 
		qRxE_nm$(sameas[Agri_,'CoarseFeed'])
		pRxE_nm$(sameas[Agri_,'CoarseFeed'] and not d1RxE_nm[Agri_sectorss,Agri_sectors,Agri_,t])
    ;

    $GROUP G_agr_report_endo
    	G_agr_report$(tx0[t])
    	qEmmAgrxE$(tx0[t] and d1EmmAgrxE[emmtype_,Agri_sectors,t,emm_eq] and sameas[emmtype_,'emmtype_sum'])
			;

    $GROUP G_agr_report_exo 
    	pNH3
    	pTotalOperatingSurplus_AFF
    	rBonds 
    	tCorp 
    	sDebt2j
			thetaProd$(agri_sectors[sp] and prdL[prd])
    	tqRE$(d1pREown[purpose,energy19,r,t])
			qEmmAgrxE$(tx0[t] and d1EmmAgrxE[emmtype_,Agri_sectors,t,emm_eq])
			vY_agr$(tx0[t])	
			vREa$(d1pREa[purpose,energy19a,s,t] and sameas[s,'01080'])
			vtEAFG_RE$(d1EAFG_RE[purpose,energy19,r,t] and sameas[r,'01080'])
			vtEAFG_REmarg[purpose,energy19,r,t]$(d1EAFG_RE[purpose,energy19,r,t] and sameas[r,'01080'])	
			vtCO2_RE$(d1CO2_RE[purpose,energy19,r,t] and sameas[r,'01080'])
			vtCO2_REmarg[purpose,energy19,r,t]$(d1CO2_RE[purpose,energy19,r,t] and sameas[r,'01080'])	
			vtCO2_ETS_marg$(tx0[t])	
			pRxE$(tx0[t])
			qRxE$(tx0[t])

			vtL$(sameas[s_,'01080']	)
			vtFirmsWeight$(sameas[s_,'01080'])
			vtCO2_ETS$(tx0[t])
			vtLand$(sameas[s_,'01080'])
			z$(tx0[t]) 
			thetaProd$(tx0[t] and sameas[prd,'L']) 
			pL$(tx0[t]) 
			qL$(tx0[t])
			pY_CET$(tx0[t] and sameas[s,'01080'] and sameas[out,'out_other'])
			pY0_CET$(tx0[t] and sameas[s,'01080'] and sameas[out,'out_other'])
			qY_CETgross[out,s,t]$(tx0[t] and sameas[s,'01080'] and sameas[out,'out_other'])		
			pK$(tx0[t] and sameas[sp,'01080'])
			qK$((tx0[t] or t0[t]) and sameas[s,'01080'])	
			pNH3	
			qEmmAgrxE$(d1EmmAgrxE[emmtype_,agri_sectors,t,emm_eq] and sameas[emmtype_,'NH3'] and tx0[t]) 
			qEmmAgrAnimalsOther[emmtype,t,emm_eq]$(d1EmmAgrAniOther[emmtype,t,emm_eq] and sameas[emmtype,'NH3'] and tx0[t])	
			vInput_agr_market$(tx0[t])
			vInput_agr_nm$(tx0[t])
		;

  
	  $GROUP G_baseline_agr
    	qEmmAgrxE
    ;

$ENDIF

# ======================================================================================================================
# Equations
# ======================================================================================================================

$IF %stage% == "equations":

$BLOCK B_production_agr

  # ---------------------------------------------------------------------------------------------------------------------
  # Non-market clearing
  # ---------------------------------------------------------------------------------------------------------------------

	# Non-market "market clearing": Coarse feed
	E_pRxE_nm_coarsefeed[Ani_sectors,Plant_sectors,t]$(tx0[t] and d1RxE_nm[Ani_sectors,Plant_sectors,'CoarseFeed',t]).. 
		pRxE_nm[Ani_sectors,Plant_sectors,'CoarseFeed',t] =E= pPlant_CET[Plant_sectors,'CoarseFeed',t];

	E_qPlant_CET_coarsefeed[plant_sectors,t]$(tx0[t] and d1Plant_CET0[plant_sectors,'CoarseFeed',t])..  	
		qPlant_CET[plant_sectors,'CoarseFeed',t] =E= sum(ani_sectors$(d1RxE_nm[ani_sectors,plant_sectors,'CoarseFeed',t]), qRxE_nm[ani_sectors,plant_sectors,'CoarseFeed',t]);

	# This is just a summary variable at this stage.
 	E_qD_manure[t]$(tx0[t])..
 		qD_manure[t] =E= sum(plant_sectors$(d1Plant[plant_sectors,'Manure',t]), qPlant[plant_sectors,'manure',t]);


	# Market clearing of manure 
	E_pD_manure[t]$(tx0[t])..
		sum(plant_sectors$(d1plant[plant_sectors,'manure',t]), qPlant[plant_sectors,'manure',t]) 
			=E= sum((ani_sectors,animals)$(sum(emm,d1EmmAgrAni['ManureManagement',ani_sectors,Animals,t,emm])), qNManure[ani_sectors,animals,t]) + qNManureOtherAnimals[t];

	
	E_pPlant_manure[plant_sectors,t]$(tx0[t] and d1plant[plant_sectors,'manure',t])..
		pPlant[plant_sectors,'manure',t] =E= pD_manure[t]*(qD_manure[t] - qNManureOtherAnimals[t])/qD_manure[t] # Scaling of manure price, because crop producers also receive manure from "OtherAnimals"
										   + vCO2_plant[plant_sectors,'manure',t]$(d1EmmAgrxE['manure',plant_sectors,t,'CO2e'])/qPlant[plant_sectors,'manure',t]
										   + sum((Techplant,Emmtype)$(emmtype2plant_[emmtype,'manure'] and sum(emm, d1Thetaplant[Techplant,plant_sectors,emmtype,t,emm])), 
                                      						vEOPCostplant_TechTot[Techplant,Emmtype,plant_sectors,t]/qPlant[plant_sectors,'manure',t])
										   - sum((Techplant,Emmtype)$(emmtype2plant_[emmtype,'manure'] and sum(emm, d1Thetaplant[Techplant,plant_sectors,emmtype,t,emm])),
										   														vTech_subsidy_plant[Techplant,EmmType,plant_sectors,t]/qPlant[plant_sectors,'manure',t]);  


	# The distributor distributes the total litter demand on suppliers 
	E_qPlant_AGG[plant_sectors,t]$(tx0[t] and d1Plant_CET0[Plant_sectors,'Litter',t])..	
		qPlant_CET[plant_sectors,'litter',t] * sum(plant_sectorss$(d1Plant_CET0[plant_sectorss,'litter',t]), sPlant_AGG[plant_sectorss,t] * pPlant_CET[plant_sectorss,'litter',t]**(-ePlant_AGG))
			=E= sPlant_AGG[plant_sectors,t] * pPlant_CET[plant_sectors,'litter',t]**(-ePlant_AGG) * qD_litter[t];

	# The average price is computed. 
	E_pD_litter[t]$(tx0[t])..
		pD_litter[t] * qD_litter[t] =E= sum(plant_sectors$(d1Plant_CET0[plant_sectors,'litter',t]), pPlant_CET[plant_sectors,'litter',t] * qPlant_CET[plant_sectors,'litter',t]);


	#Market clearing of litter
	E_qD_litter[t]$(tx0[t])..
		qD_litter[t] =E= sum(ani_sectors$(d1Ani[ani_sectors,'litter',t]), qAni[ani_sectors,'litter',t]);

	# On the demand side the average price is paid
	E_pAni_litter[ani_sectors,t]$(tx0[t] and d1ani[ani_sectors,'litter',t])..
		pAni[ani_sectors,'litter',t] =E= pD_litter[t];
																					   		+ vtHectareSubsidy_nonprod[plant_sectors,t]
$ENDBLOCK

# ---------------------------------------------------------------------------------------------------------------------
# Variables for reporting
# ---------------------------------------------------------------------------------------------------------------------

$BLOCK B_report_agr

# Emissioner summeret over emmtype
	E_qEmmAgrxESumEmmtype[agri_sectors,t,emm_eq]$(tx0[t] and sum(emmtype_, d1EmmAgrxE[emmtype_,Agri_sectors,t,emm_eq]))..
		qEmmAgrxE['emmtype_sum',agri_sectors,t,emm_eq] =E= sum(emmtype$(d1EmmAgrxE[emmtype,Agri_sectors,t,emm_eq]), qEmmAgrxE[emmtype,agri_sectors,t,emm_eq]);

	E_EmmIntensity_agr[agri_sectors,t]$(tx0[t] and sum(emmtype, d1EmmAgrxE[emmtype,Agri_sectors,t,'CO2e']))..
		qEmmIntensity[agri_sectors,t,'CO2e'] * vY_agr[agri_sectors,t] =E= qEmmAgrxE['emmtype_sum',agri_sectors,t,'CO2e'];

# BVT i landbrug inkl. non-market 
	E_BVT_plant[agri_sectors,t]$(tx0[t])..
		vGrossValAdd_agr_nm[agri_sectors,t] =E= vY_agr_market[agri_sectors,t]
											  + vY_agr_nm[agri_sectors,t]
											  - (  vInput_agr_market[agri_sectors,t] 
											  + vInput_agr_nm[agri_sectors,t]);

	E_vInput_01080_market[t]$(tx0[t])..
		vInput_01080_market[t] =E= pRxE['01080',t]*qRxE['01080',t]
								 + sum((energy19,purpose)$(d1pREa[purpose,energy19,'01080',t]), vREa[purpose,energy19,'01080',t])
								 + sum((purpose,energy19a), d1tREmarg['01080']*
                                        (+vtEAFG_RE[purpose,energy19a,'01080',t]$(d1EAFG_RE[purpose,energy19a,'01080',t])
                                        - vtEAFG_REmarg[purpose,energy19a,'01080',t]$(d1EAFG_RE[purpose,energy19a,'01080',t])
                                        + vtCO2_RE[purpose,energy19a,'01080',t]$(d1CO2_RE[purpose,energy19a,'01080',t])
                                        - vtCO2_REmarg[purpose,energy19a,'01080',t]$(d1CO2_RE[purpose,energy19a,'01080',t])
                                        - vtCO2_ETS_marg[energy19a,'01080',t]$(d1EmmProdE['01080',t,'CO2e',purpose,energy19a] and d1CO2_ETS['01080',t] and sameas[purpose,'in_ETS'])));;

	# Non-market
	E_vY_agr[agri_sectors,t]$(tx0[t])..
		vY_agr[agri_sectors,t] 		=E= vY_agr_market[agri_sectors,t] + vY_agr_nm[agri_sectors,t];

	E_vInput_agr[agri_sectors,t]$(tx0[t])..
		vInput_agr[agri_sectors,t] 	=E= vInput_agr_market[agri_sectors,t] + vInput_agr_nm[agri_sectors,t];

	E_vBVT_01080_cpntns_subsidies[t]$(tx0[t])..
		vBVT_01080_cpntns['netProdSubsidies',t] =E= vtNetproductionRest['01080',t]
												  + vtL['01080',t] 					# Taxes/Subsidies on labour
												  + vtLand['01080',t]				# Taxes/Subsidies on land/buildings
												  + vtFirmsWeight['01080',t]		# Vægtafgifter
												  + vtCO2_ETS['01080',t];			# ETS quota

	E_vBVT_01080_cpntns_wage[t]$(tx0[t])..
		vBVT_01080_cpntns['Wage',t] =E= pL['01080',t]*Z[t]*thetaProd['L','01080',t]*qL['01080',t]
										- vtL['01080',t];

	E_vBVT_01080_cpntns_markup[t]$(tx0[t])..
		vBVT_01080_cpntns['Profit',t] 		   =E= sum(out$d1vY_CET[out,'01080',t], pY_CET[out,'01080',t] *qY_CETgross[out,'01080',t])
												  - sum(out$d1vY_CET[out,'01080',t], pY0_CET[out,'01080',t]*qY_CETgross[out,'01080',t]);

	E_vBVT_01080_cpntns_machine[t]$(tx0[t])..
		vBVT_01080_cpntns['MachineCapital',t]  =E= pK['im','01080',t] * qK['im','01080',t-1]/fq	
												  - vtFirmsWeight['01080',t];

	E_vBVT_01080_cpntns_building[t]$(tx0[t])..
		vBVT_01080_cpntns['BuildingCapital',t] =E= pK['ib','01080',t] * qK['ib','01080',t-1]/fq
												   - vtLand['01080',t];

# Aggregate shadow value of NH3 emissions 
	E_vEmmNH3[t]$(tx0[t] and sum((emmtype,agri_sectors), d1EmmAgrxE[emmtype,agri_sectors,t,"NH3"]) and sum(emmtype, d1EmmAgrAniOther[emmtype,t,"NH3"])).. 
		vEmmNH3[t] =E= pNH3[t] * (sum((emmtype,agri_sectors)$(d1EmmAgrxE[emmtype,agri_sectors,t,"NH3"]), qEmmAgrXe[emmtype,agri_sectors,t,"NH3"]) 
							   + sum(emmtype$(d1EmmAgrAniOther[emmtype,t,"NH3"]), qEmmAgrAnimalsOther[emmtype, t, "NH3"]));    

$ENDBLOCK

$MODEL M_production_agr
	B_production_agr
;
	
$ENDIF

# ======================================================================================================================
# Exogenous variables and data assignment
# ======================================================================================================================

$IF %stage% == "read_data":

#1) READ DATA 
	
	# From CGE-model

		# CAP 2023-2027 ind. Satser tages fra: https://lbst.dk/tilskud-selvbetjening/tilskudsguide
		vtCAP.l[agri_sectors,t] = IO_vtCAP[agri_sectors,t];
		vtCAP.l[agri_sectors,t] = vtCAP.l[agri_sectors,t] * inf_growth_factor[t];	

	# Non-market with real data (£: Kan vi fjerne den her? Der indlæses manuelt herunder - men måske skal den her være der for manure)
		qRxE_nm.l[Agri_sectors,Agri_sectorss,Agri_,t] = sum(modtager_pgren$(pgren2s(modtager_pgren,Agri_sectors)), 
												        sum(afsender_pgren$(pgren2s(afsender_pgren,Agri_sectorss)),
												        sum(regnskabspost$(regnskabspost2Agri(regnskabspost,Agri_)), NM_IO[modtager_pgren,afsender_pgren,regnskabspost,t]))); 


		#£ Tjek om den her ikke kan fjernes nu?
		qRxE_nm.l[Agri_sectors,Agri_sectorss,Agri_,'2019'] = qRxE_nm.l[Agri_sectors,Agri_sectorss,Agri_,'2018'];


		# Litter (from Statistics Denmark, Table 2)
		qRxE_nm.l['01031','01011','litter','2019']     = 0.3816*10**9;
		qRxE_nm.l['01032','01012','litter','2019']     = 0.044276*10**9;

		qRxE_nm.l['01051','01011','litter','2019']     = 0.112036*10**9;
		qRxE_nm.l['01052','01012','litter','2019']     = 0.000863*10**9;

		$IF1 %smaagrisesplit%:
		qRxE_nm.l['01051','01011','litter','2019']     = sYS_svin['01051'] * (0.112036*10**9+ 0.000863*10**9);
		qRxE_nm.l['01052','01012','litter','2019']     = sYS_svin['01052'] * (0.112036*10**9+ 0.000863*10**9);
		$ENDIF1 

		qRxE_nm.l['01061','01011','litter','2019']     = 0.00677344*10**9;
		qRxE_nm.l['01062','01012','litter','2019']     = 0.0000851*10**9;

		# Coarse Feed (From Statistics Denmark and own data-treatment, cf  data/ikkemarkedsligIO/2019.xls 
		qRxE_nm.l['01031','01011','CoarseFeed','2018'] = 5.2*10**9  + 0.214*10**9;
		qRxE_nm.l['01032','01012','CoarseFeed','2018'] = 1.05*10**9 + 0.043*10**9; 
		
		qRxE_nm.l['01051','01011','CoarseFeed','2018'] = 2.79*10**9; 
		qRxE_nm.l['01052','01012','CoarseFeed','2018'] = 0.04*10**9; 

		$IF1 %smaagrisesplit%:
		qRxE_nm.l['01051','01011','CoarseFeed','2018'] = sYS_svin['01051'] * (2.79*10**9 + 0.04*10**9); 
		qRxE_nm.l['01052','01012','CoarseFeed','2018'] = sYS_svin['01052'] * (2.79*10**9 + 0.04*10**9); 
		$ENDIF1

		qRxE_nm.l['01061','01011','CoarseFeed','2018'] = 0.17*IO_vY['01061','2018']/(IO_vY['01061','2018'] + IO_vY['01062','2018'])*10**9;
		qRxE_nm.l['01062','01011','CoarseFeed','2018'] = 0.17*IO_vY['01062','2018']/(IO_vY['01061','2018'] + IO_vY['01062','2018'])*10**9;	


		#LBFI1 in 'data/iodata/landbrugsoverskud_main.xlsx'  
		qRxE_nm.l['01031','01011','CoarseFeed','2019'] =  3.321*10**9; #
		qRxE_nm.l['01032','01012','CoarseFeed','2019'] =  0.830*10**9 - 0.1*10**9; 
		
		qRxE_nm.l['01051','01011','CoarseFeed','2019'] = 1.768*10**9;
		qRxE_nm.l['01052','01012','CoarseFeed','2019'] = 0.032*10**9 -0.04*10**9; 
 
		$IF1 %smaagrisesplit%:
		qRxE_nm.l['01051','01011','CoarseFeed','2019']  = sYS_svin['01051'] * (1.768*10**9 + 0.032*10**9 -0.04*10**9);
		qRxE_nm.l['01052','01011','CoarseFeed','2019']  = sYS_svin['01052'] * (1.768*10**9 + 0.032*10**9 -0.04*10**9);
		$ENDIF1

		qRxE_nm.l['01061','01011','CoarseFeed','2019'] = 0.1804*IO_vY['01061','2019']/(IO_vY['01061','2019'] + IO_vY['01062','2019'])*10**9 + 0.2*IO_vY['01061','2019']/(IO_vY['01061','2019'] + IO_vY['01062','2019'])*10**9; 
		qRxE_nm.l['01062','01011','CoarseFeed','2019'] = 0.1804*IO_vY['01062','2019']/(IO_vY['01061','2019'] + IO_vY['01062','2019'])*10**9 + 0.2*IO_vY['01062','2019']/(IO_vY['01061','2019'] + IO_vY['01062','2019'])*10**9 + 0.01*10**9;  	

		qD_litter.l[t] 								   = sum((agri_sectors,agri_sectorss), qRxE_nm.l[agri_sectors,agri_sectorss,'litter',t]);

	# Social cost of ammonia on Danish residents
		pNH3.l[t] = 0.042/inf_factor['2022'] * 0.22; # 48 kroner per kg i 2022-prices, with a 22 pct. impact on Danish residents, cf. mail from MIM d. 8/11/2023


$ENDIF

$IF %stage% == "exogenous_values":


#3) COMPUTATIONS (residual data treatment that could be considered moved to actual data-reading in Python etc.)

	# EMISSIONS 
		#Compute CO2e
		qEmmAgrxE.l[emmtype,Agri_sectors,t,'CO2e']              = sum(emm, qEmmAgrxE.l[emmtype,Agri_sectors,t,emm]*GWP.l[emm]);

#4) INITIAL VALUES 

	# Non-market 
		pD_litter.l[t] 	= 1;

#5) DUMMIES 

	# Non-market IO
	d1RxE_nm[agri_sectorss,agri_sectors,agri_,t]		   	= yes$(qRxE_nm.l[agri_sectorss,agri_sectors,agri_,t]);

	# Emissions
	d1EmmAgrxE[emmtype,Agri_sectors,t,emm_eq] 			   	= yes$(qEmmAgrxE.l[emmtype,Agri_sectors,t,emm_eq]);
	d1EmmAgrxE[emmtype,Agri_sectors,t,emm_eq]$(t.val > 2050 and ani_sectors[agri_sectors]) = yes$(qEmmAgrxE.l[emmtype,Agri_sectors,'2050',emm_eq]); # Set dummy after 2035 for animal sectors
	d1EmmAgrxE[emmtype,Agri_sectors,t,emm_eq]$(t.val > 2019 and plant_sectors[agri_sectors]) = yes$(qEmmAgrxE.l[emmtype,Agri_sectors,'2019',emm_eq]); # Set dummy after 2018 for plant sectors
	d1EmmAgrxE['emmtype_sum',Agri_sectors,t,emm_eq]			= yes$(sum(emmtype, d1EmmAgrxE[emmtype,Agri_sectors,t,emm_eq]));

	d1EmmProdxE_overlap[agri_sectors,t,emm] 			   	= yes$(d1EmmProdxE[agri_sectors,t,emm] and sum(emmtype,d1EmmAgrxE[emmtype,agri_sectors,t,emm]));
	d1EmmProdxE_overlap[s,t,emm]$(not agri_sectors_s[s])   	= no;

	# Lavbundsudtag
	d1OptionsUdtag_xGrid[HaUdtag,lavbundsmodel] = no;
	d1OptionsUdtag_xGrid['35000','1'] 			= yes;

# ---------------------------------------------------------------------------------------------------------------------
# Add to data (includes list in data check)
# ---------------------------------------------------------------------------------------------------------------------

	$GROUP G_agr_data 
		qEmmAgrxE$(not Ani_sectors[Agri_sectors])
		qRxE_nm
		pRxE_nm
	;	


$ENDIF

# ======================================================================================================================
# Static calibration
# ======================================================================================================================

$IF %stage% == "static_calibration":

	$BLOCK B_production_agr_static_calibration

		# Calibration of litter distributors portfolio shares 
		E_sPlant_AGG[plant_sectors,t]$(tx0[t] and d1Plant_CET0[Plant_sectors,'Litter',t])..	
			sPlant_AGG[plant_sectors,t] =E= qPlant_CET[plant_sectors,'litter',t]/qD_litter[t] * pPlant_CET[plant_sectors,'litter',t]**ePlant_AGG;

	$ENDBLOCK

	#Addition to capital model
	$BLOCK B_production_agr_static_calibration_capital 
            #For plant-sectors allocation takes into account also value of land
            E_vFin2CAP_iM_static_calibration_capital[plant_sectors,t]$(tx0[t] and sum(ns69, ns692s(ns69,plant_sectors))).. 
                pFin_k['iM',plant_sectors,t] * qFin_k['iM',plant_sectors,t]/sum(kk, pFin_k[kk,plant_sectors,t] * qFin_k[kk,plant_sectors,t]) 
                    =E=  pI_s['iM',plant_sectors,t] * qK['iM',plant_sectors,t-1]/fq/(sum(kk,pI_s[kk,plant_sectors,t] * qK[kk,plant_sectors,t-1]/fq) 
                                                                                             + pLand[t]*qPlant[plant_sectors,'Land',t-1]
                                                                                             + sum(landallocation, pLand_nonproductive[landallocation,plant_sectors,t]*qLand_nonproductive[landallocation,plant_sectors,t-1]));


            E_vFin2CAP_iB_static_calibration_capital[plant_sectors,t]$(tx0[t] and sum(ns69, ns692s(ns69,plant_sectors))).. 
                pFin_k['iB',plant_sectors,t] * qFin_k['iB',plant_sectors,t]/sum(kk, pFin_k[kk,plant_sectors,t] * qFin_k[kk,plant_sectors,t]) 
                    =E=   (pI_s['iB',plant_sectors,t] * qK['iB',plant_sectors,t-1]/fq + pLand[t]*qPlant[plant_sectors,'Land',t-1]  + sum(landallocation, pLand_nonproductive[landallocation,plant_sectors,t]*qLand_nonproductive[landallocation,plant_sectors,t-1])
                                                         )
                                                    /(sum(kk,pI_s[kk,plant_sectors,t] * qK[kk,plant_sectors,t-1]/fq) 
                                                     + pLand[t]*qPlant[plant_sectors,'Land',t-1]
                                                     + sum(landallocation, pLand_nonproductive[landallocation,plant_sectors,t]*qLand_nonproductive[landallocation,plant_sectors,t-1]));

            E_vFin2CAP_iT_static_calibration_capital[plant_sectors,t]$(tx0[t] and sum(ns69, ns692s(ns69,plant_sectors))).. 
                pFin_k['iT',plant_sectors,t] * qFin_k['iT',plant_sectors,t]/sum(kk, pFin_k[kk,plant_sectors,t] * qFin_k[kk,plant_sectors,t]) 
                    =E=  pI_s['iT',plant_sectors,t] * qK['iT',plant_sectors,t-1]/fq/(sum(kk,pI_s[kk,plant_sectors,t] * qK[kk,plant_sectors,t-1]/fq) 
                                                                                             + pLand[t]*qPlant[plant_sectors,'Land',t-1]
                                                                                             + sum(landallocation, pLand_nonproductive[landallocation,plant_sectors,t]*qLand_nonproductive[landallocation,plant_sectors,t-1]));
                                      
	$ENDBLOCK

		$MODEL M_production_static_calibration_capital_incl_agrcapital
			M_production_private_static_calibration_capital
			B_production_agr_static_calibration_capital

			#Andet agr
			# E_pK_plant_t0
			E_pPlant_uc_t0
			E_pAni_uc_t0
			E_pTobinsQ_ani_t0
			E_pTobinsQ_plant_t0
			E_pTobinsQ_plant
			E_pTobinsQ_ani
			E_pTobinsQ_ani_terminal
			E_pTobinsQ_plant_terminal
		;

		$GROUP G_production_static_calibration_capital_incl_agrcapital_exo
			G_production_private_static_calibration_capital_exo
			tCorp$(tx0[t] or t0[t]) 
			rFirms$(tx0[t] or t0[t]) 
			rDepr$(tx0[t] or t0[t])
			tK_plant$(tx0[t] or t0[t])
			pI_s$(tx0[t] or t0[t]) 
			rBonds$(tx0[t] or t0[t]) 
			sDebt2k$(tx0[t] or t0[t]) 
			pI_s$(tx0[t] or t0[t]) 
			pPlant_CET$(tx0[t] or t0[t]) 
			EKtax$(tx0[t] or t0[t])
			dKInstCost2dK$(tx0[t] or t0[t]) 
			dKInstCost2dI$(tx0[t] or t0[t])
			jpK_plant$(tx0[t] or t0[t])
			pLand$(tx0[t] or t0[t])
			qK$(t0[t])
			qPlant$(sameas[plant_,'land'] and t0[t])
			pFin_k$(t1[t] and plant_sectors_s[r])
      qRxE_nm$(d1RxE_nm[agri_sectorss,agri_sectors,agri_,t])
      qPlant$(d1Plant[plant_sectors,plant_,t] and sameas[plant_,'manure'])
      pD_manure$(tx0[t] or t0[t]) 
      qNManure$(tData[t])
      pLand_nonproductive$(tx0[t])
      qLand_nonproductive$(t0[t])
      pLand$(tx0[t])
      qPlant$(sameas[plant_,'land'] and t0[t])	
			pYani$(tx0[t] or t0[t]) 
			jpK_ani$(tx0[t] or t0[t])
			pAni$(tx0[t] and sameas[ani_,'grossprod'])
			pPlant$(tx0[t] and sameas[plant_,'grossprod'])
		;

	$MODEL M_agr_static_calibration_partial 
		B_production_agr
		-E_pD_manure                    # -E_pD_manure. When we fix both LHS and RHS of pD_manure the manure can no longer be determined endogenously
		B_production_agr_static_calibration
		-E_qPlant_AGG              # E_sPlant_AGG
	;

	$GROUP G_agr_static_calibration_partial 
		G_production_agr_endo

		# User-cost is not determined in the calibration
		-pD_manure #-E_pD_manure. When we fix both LHS and RHS of pD_manure the manure can no longer be determined endogenously
	
		# All bottom layers are inverted - quantity for share-parameter
		-qRxE_nm, sRxE_nm

		# The litter-distributor 
		sPlant_AGG, -qPlant_CET$(sameas[plant_out,'litter']) # E_sPlant_AGG	
	;

	$GROUP G_agr_static_calibration_partial_exo
		G_production_agr_exo

		pD_manure
		
		# All bottom layers are inverted - quantity for share-parameter
		qRxE_nm$(sameas[Agri_,'Manure']), -sRxE_nm

		# The litter-distributor 
		-sPlant_AGG, qPlant_CET$(sameas[plant_out,'litter']) # E_sPlant_AGG

		qAni$(d1Ani[ani_sectors,ani_,t] and sameas[ani_,'litter'])
	;

	#  # Comment in to solve partial static-calibration
	#  set_time_periods(%cal_start%, %cal_end%);
	#  set_data_periods(%cal_start%, %cal_end%);

	#  $FIX G_agr_static_calibration_partial_exo;
	#  $UNFIX G_agr_static_calibration_partial;
	#  #  execute_unload 'output\pre_static_calibration.gdx';
	#  @SOLVE(M_agr_static_calibration_partial);


	$GROUP G_production_agr_static_calibration
		G_agr_static_calibration_partial
	;

	$GROUP G_production_agr_static_calibration_exo
		G_agr_static_calibration_partial_exo
	;

	$MODEL M_production_agr_static_calibration
		M_agr_static_calibration_partial
	;

	#  # Comment in to solve static-calibration
	#  set_time_periods(%cal_start%, %cal_end%);
	#  set_data_periods(%cal_start%, %cal_end%);

	#  $FIX G_production_agr_static_calibration_exo;
	#  $UNFIX G_production_agr_static_calibration;
	#  execute_unload 'output\pre_static_calibration.gdx';
	#  @SOLVE(M_production_agr_static_calibration);
	#  $exit

$ENDIF

# ======================================================================================================================
# Dynamic calibration
# ======================================================================================================================

$IF %stage% == "dynamic_calibration":

	$GROUP G_agr_calib_partial 
		G_production_agr_endo
	;


	$GROUP G_agr_calib_partial_exo
		G_production_agr_exo
	;


	# Run a forecast on the partial equilibrium
	$MODEL M_agr_calib_partial 
		B_production_agr
	;


	$GROUP G_agr_calib_partial_exo
		G_agr_calib_partial_exo
	;

	$GROUP G_agr_calib_partial
		G_agr_calib_partial
	;

#  	  COMMENT IN TO RUN PARTIAL MODEL

#  	 Note: Dynamic calibration of the partial model should perhaps include an actual equation for fKInstCost

#  	set_time_periods(%cal_start%, %terminal_year%);
#  	@set_dummies('2019',tx1);  # Use dummies from last data year in following periods
	
#  	fKInstCost.l[k,agri_sectors,tx1] = fq;
#  	rBonds.l[agri_sectors,t] = rBonds.l[agri_sectors,'2019'];
	

#  	$FIX G_agr_calib_partial_exo;
#  	$UNFIX G_agr_calib_partial;
#  	execute_unload 'output\pre.gdx';
#  	@SOLVE(M_agr_calib_partial);
#  	execute_unload 'output\agr_partial.gdx';
#  	@assert_no_difference(G_data,%tolerance_data%);
#  	$exit


	$MODEL M_production_agr_calib 
		B_production_agr
	;

	$GROUP G_production_agr_calib 
		G_production_agr_endo
	;

	$GROUP G_production_agr_calib_exo 
		G_production_agr_exo 
		;

$ENDIF