# ======================================================================================================================
#		 AGRICULTURAL MODULE
# ======================================================================================================================
# A brief overview:
#
# 1) In the first stage (%stage%=="variables") variables are created in GAMS 
#
# 2) In the second stage (%stage%=="GroupCompilation") variables are bunched together in $GROUPS. This allows us to perform the same action over collections of variable, most prominently defining which variables are exogenous and which are endogenous.
#
# 3) In the third stage (%stage%=="equations") blocks of equations are defined. Together the blocks add up to the GreenREFORM agricultural module (for the LULUCF-module see lulucf.gms). 
#
# 4) In the fourth stage (%stage%=="exogenous_values") data is loaded into the module variables. A bit of residual data-treament is also carried out in this stage.
#
# 5) In the fifth stage (%stage%=="static_calibration") additional equations are added for the so-called static calibration. In this step the model is "inverted" in data-years. That is, endogenous variables are exogenized and calibration-parameters are endogenized.
#
# 6) In the sixth stage (%stage%=="dynamic_calibration") additional equations are added for the so-called dynanic calibration. In this step a partial version of the agricultural module is also compiled. This stage otherwise collects variables and equations and projects 
#    and would calibrate a "raw" projection of the agricultural module from last data year to 2099. The module is however calibrated to many external sources. Most importantly a calibration of production, prices, and emissions. This is collected in the file integration_agr.gms
# ======================================================================================================================


# ======================================================================================================================
# Variable definition
# ======================================================================================================================

$IF %stage% == "variables":

	# Parametre til landbrugsabatement
	$PGROUP PG_ani_abatement_parms
	  	switch_forward_looking_ani ""
	  	switch_sluggish_ani ""
	  	rhoEOPani[TechAni] ""
	  	sigmaEOPAni[TechAni] ""
	  	uEOPanibeta ""
			aflob[TechAni,ani_sectors,Emmtype,animals,t] "Afløb af puljer. AKB: Har umiddelbart kun indvirkning på indtræning, men ikke hvor meget de faktiske puljer bruges?"
     ;

	#-------------------------------------------------------------------------------------------------------------------
	# Variables for the CES-production function: Prices, quantities, values, CES-shares, etc...
	#-------------------------------------------------------------------------------------------------------------------

	$GROUP G_ani_prices
		pYAni[Ani_sectors,t]     										            "Average output price on animal sector output, inflation adjusted"
		pAni_CET0[Ani_sectors,Ani_out,t]						                    "Prices of ani sector CET outputs (own prices), inflation adjusted"
		pAni_CET[Ani_sectors,Ani_out_top,t]					                    	"Prices of ani sector CET outputs (market prices), inflation adjusted"
		pAni_CET_baseline[Ani_sectors,Ani_out_top,t]					                    	"Prices of ani sector CET outputs (market prices), inflation adjusted"
		pAni[Ani_sectors,Ani_,t]										            "Prices of ani sector production function, inflation adjusted (Producentprisindeks for animalsk produktion)"
		pAni_uc[ani_sectors,Ani_pk,t]                            ""
		pTobinsQ_ani[ani_sectors,ani_pK,t] 					                    	"Tobins-Q in user-cost of capital for animal-sectors, inflation adjusted"

		pD_manure[t] 													            "Market clearing price for manure (Bio. kroner per mio. tonnes of N-equivalent. Prices is inflation- and growth-adjusted)"
		pRxE_nm[Agri_sectorss,agri_sectors,Agri_,t]                      			"Non-market inputs in production function (Price index of non-market inputs, inflation adjusted)"

		#IO
		pRxE_ym_ani[Ani_sectors,s,t]								                "Prices of non-energy, market-inputs, buyers prices received in animal sectors, inflation adjusted"	
	
		pBotdedPerAnimal[emmtype,ani_sectors,animals,t,emm_eq]         "CO2e-tax bottom per deduction per animal"
	;

	$GROUP G_ani_quantities 
		qAni_CET[Ani_sectors,Ani_out,t]								              				  "Quantities out output in animal sectors production-functio. Bio. kr. growth-adjusted"
		qAni_CET_baseline[Ani_sectors,Ani_out,t]								              				  "Quantities out output in animal sectors production-functio. Bio. kr. growth-adjusted"
		qAni[Ani_sectors,Ani_,t]									            						    "Quantities of input in the animal sectors production-function. Bio. kr. growth-adjusted, the exception being manure, which is  measured in mio. tonnes of N-equivalent."
		qAni_capital[ani_sectors,ani_pK,t] 																		"Quantity of capital in ani sector production function, bio. kr. growth-adjusted (Kapital i animalsk produktion, mio. kr. vækst- og inf. korr.)"
		qRxE_ym_Ani[Ani_sectors,s,t]                                  				"IO level quantities of ani sector production function (bio. kr. growth-adjusted)"
		qNManure[ani_sectors,animals,t]                                   			"Quantity of manure (in mio. tonnes of  Nitrogen-equivalent)"

		qRxE_nm[Agri_sectorss,Agri_sectors,Agri_,t]                       			"Non-market inputs in  production function, bio. kr. growth-adjusted"
	;

	$GROUP G_agr_values_ani			
		vtCAP_top[s,t]$(agri_sectors_s[s])                                                     			"CAP-subsidies that enter the top of the production-function, bio. kr. inflation and growth-adjusted (Værdi af EU-landbrugsstøtte, der trækkes fra de samlede omkostninger, mia. kr. vækst- og inf. korr.)"
		vCO2_ani[EmmType,ani_sectors,Animals,t]  	                        		"Tax-revenue from CO2-tax levied on non-energy emissions in animal sectors, bio. kr. inflation- and growth-adjusted (CO2e-afgfit på animalske udledninger)"
		vtCAP[s,t]$(ani_sectors_s[s])                                                        			"Total CAP-subsidies by sector, bio. kr. inflation- and growth-adjusted (Total EU-landbrugsstøtte tildelt branche s)"
	;

	$GROUP G_agr_report_ani			
		vDBII_ani[ani_sectors,t]                                          			"Operating Surplus II for animal sectors, bio. kr. inflation and growth-adjusted (Dækningsbidrag II for animalske producenter, mia. kr. vækst- og inf. korr.)"
		pAni_mekanisk[ani_sectors,t]                                      			"Mechanical change, i.e. before behaviour, in animal prices due to a CO2e-tax on non-energy animal emissions (Mekanisk priseffekt af en CO2e-afgift på animalske produkter, i.e. effekt før adfærd)"
		vAni[ani_sectors,ani_,t]$(tx0[t])                                 			"Value of production inputs in animal production, bio. kr. inflation and growth-adjusted (Værdi af input i animalsk produktion, mia. kr. vækst- og inf. korr.)"
		EmmPerAnimal[ani_sectors,t]$(tx0[t] and sum(animals, d1Ani[ani_sectors,animals,t])) 													"Emissions per animal, where animals are summed across animal types (eg. Dairy cows and other cattle)"
    pAni_pK_alt[ani_sectors,ani_pK,t] ""
    pTobinsQ_ani_alt[ani_sectors,ani_pK,t]  ""
		vY_agr_market[agri_sectors,t]$(tx0[t])                            			"Value of market production in agricultural sectors, bio. kr. inflation and growth-adjusted (Værdi af markedsmæssig produktion i landbrugets produktionsgrene, mia. kr. vækst-og inf. korr.)"
		vInput_agr_market[agri_sectors,t]$(tx0[t])                        			"Value market inputs in agricultural production, bio. kr. inflation and growth-adjusted (Værdi af markedsmæssige input i produktionen i landbrugets produktionsgrene, mia. kr. vækst-og inf. korr.)"
		vY_agr_nm[agri_sectors,t]$(tx0[t])                                			"Value of non-market production, bio. kr. inflation- and growth-adjusted (Værdi af ikke-marekdsmæssig produktion i landbrugets produktionsgrene, mia. kr. vækst-og inf. korr.)"
		vInput_agr_nm[agri_sectors,t]$(tx0[t])                            			"Value of non-market inputs in production, bio. kr. inflation- and growth-adjusted (Værdi af ikke-markedsmæssige input i landbrugets produktionsgrene, mia. kr. vækst-og inf. korr.) "
		vBVT_agr_cpntns[agri_sectors,BVTagr_cpntns,t]$(tx0[t])            			"De composition of production value in agriculture, bio. kr. inflation- and growth-adjusted (Dekomponering af BVT i landbrugets produktionsgrene, mia. kr. vækst-og inf. korr.)" 
		qAni_dis[husdyrtype,ani_sectors,animals,t]$(tx0[t] and qAni_dis.l[husdyrtype,ani_sectors,animals,t]) ""
		uAni_dis_tot[husdyrtype,animals,t]$(tx0[t] and qAni_dis_tot.l[husdyrtype,animals,t]) ""
		qAni_dis_tot[husdyrtype,animals,t]$(tx0[t] and qAni_dis_tot.l[husdyrtype,animals,t]) ""
		uAni_dis[husdyrtype,ani_sectors,animals,t]$(tx0[t] and qAni_dis.l[husdyrtype,ani_sectors,animals,t]) ""
		qAni_dis_rep[husdyrtype,ani_sectors_,animals,t]$(tx0[t] and KF_qAni_dis[husdyrtype,ani_sectors_,animals,t]) ""
	;

	$GROUP G_ani_taxes 
		tCO2_emm_ani[emmtype,Ani_sectors,Ani_,t] 	                        		"CO2-tax levied on non-energy emissions in animal sectors (Afgiftssats på ikke-energimæssige udledninger i de animalske produktionsgrene, målt i kroner per tCO2e, inf-korrigeret)"
	;

	$GROUP G_agr_other_ani
		# CES-shares
		uAni[Ani_sectors,Ani_,t]                                                                      	"CES shares of ani sector production function"
		sRxE_ym_ani[Ani_sectors,s,t]$(d1RxE_ym[Ani_sectors,s,t])					                    "CES shares of IO level of ani sector production function"
		sRxE_nm[Agri_sectorss,Agri_sectors,Agri_,t]$(d1RxE_nm[Agri_sectorss,Agri_sectors,Agri_,t] and ani_sectors[agri_sectorss] and ani_[agri_])    	"CES shares of non-market inputs in production function"
		uAni_CET[Ani_sectors,Ani_out,t]$(not sameas(ani_out,'netprod'))					                "CET shares of Ani CET split"
		TFPAni[ani_sectors,t] 	  													                    "Total-factor productivity of animal production"

		# Other
		eAni[Ani_sectors,Ani_,t]    					                			                    "Production elasticities of ani sector production function (incl. IO)"
		eCET_ani[Ani_sectors,Ani_outNest]												                "CET elasticities animal"
		uManurePerAnimal[ani_sectors,animals,t]                                                       	"Amount of manure produced per animal"
		uManurePerAnimal_base[ani_sectors,animals,t]$(d1Ani[ani_sectors,animals,t])   "Amount of manure produced per animal, baseline for bottom deduction"
		Ani_markup[Ani_sectors,Ani_out_top,t]										                    "CET markups, animals"
		Ani_markup_calib[Ani_sectors,t]													                "CET markups, plants"
		uOtherEnergy_ani[purpose_xtint,ani_sectors,t]                      				                "CES share of other energy allocated on different purposes, excluding transport"
		jpK_ani[Ani_sectors,ani_pK,t] 												                    "J-term in user-cost of capital. Captures difference in forward-looking agents investment need vs. actual invest in last data-year"
		thetaA[Ani_sectors,Animals,t] 												                    "Animal enhancing technological growth (relative to fq baseline growth)"
		qNManureOtherAnimals[t]                                                                       	"Manure from other animals, not modelled by the animal production functions (goas, hoarses, etc.), measured in mio. t N-equivalent"
		jEmmAgrxE[agri_sectors,t,emm]$(ani_sectors[agri_sectors]) 												                    "J-term to capture residual between DST and Climate Outlook emissions in data"
		jqAni_CET[ani_sectors,ani_out_top,t]                                        ""
		jpAni_CET[ani_sectors,ani_out_top,t]                                        ""
		vBotdedPerAnimal[sp,t] ""
		sSizeBottomDed[emmtype,ani_sectors,animals,t,emm]$(d1EmmAgrAni[emmtype,ani_sectors,animals,t,emm]) "Size of bottom deduction on animals"
		jBotdedPeranimal[emmtype,ani_sectors,animals,t]$(sum(emm, d1EmmAgrAni[emmtype,ani_sectors,animals,t,emm])) ""
	;

	#-------------------------------------------------------------------------------------------------------------------
	# Abatement (EOP = End-of-pipe)
	#------------------------- ------------------------------------------------------------------------------------------

    $GROUP G_ani_EOP
		rEOPAni_gains[TechAni,ani_sectors,Emmtype,animals,t]					"Gains of adopting technology, DKK per tCO2e (scaled by reduction potential)"
		rEOPAni_costs[TechAni,ani_sectors,Emmtype,animals,t]					"Costs of adopting technology, DKK per tCO2e (scaled by reduction potential)"
		rEOPAni_input[TechAni,ani_sectors,Emmtype,animals,t]					"Input into the normal distribution to determine technology penetration"
		uEOPAnit[TechAni,ani_sectors,Emmtype,animals,t]							"Scale parameter in calculation of rEOPani_input"
		rEOPani[TechAni,ani_sectors,Emmtype,animals,t]$(tx0[t])					"Share of technology penetration (immediate)"
		j_rEOPAni[TechAni,ani_sectors,Emmtype,animals,t]						"J-term in determining rEOPani"
		rEOPani_preferred[TechAni,ani_sectors,Emmtype,animals,t]	    		"Share of technology penetration (preferred)"
		rEOPani_actual[TechAni,ani_sectors,Emmtype,animals,t]         			"Share of technology penetration (actual)"

		thetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]$(tx0[t])			"Reduction potential, pct. of baseline emissions"
		uEOPani[Emmtype,ani_sectors,ani_,t,emm]$(tx0[t])		 				"Factor for reducing emmisions factor"
		qGrossEmmAni[Emmtype,ani_sectors,animals,t,emm_eq]$(tx0[t])   			"Gross non-energy related emissions (excl. agriculture tech)"
		qEmmAniEOP[Emmtype,ani_sectors,animals,t,emm_eq]$(tx0[t])   			"Technology induced reduction of agricultural emissions"

		pEOPAni[TechAni,Emmtype,ani_sectors,animals,t]							"Price of agricultural technology, DKK per tCO2e, inflation adjusted"
		shareAniPrice_type[techani,techtype,t]                        			"Share parameter determining share of costs related to capital, energy and materials, respectively"
		shareAniPrice_group[techani,s,t]                              			"Share parameter determining share of costs to materials related to sector s (sender)"

		vEOPCostAni_IO[TechAni,Emmtype,ani_sectors,s,animals,t]					"Value of technology induced demand for materials from sector s, billion DKK, inflation and growth-adjusted"
		vRxEEOP_ani[ani_sectors,s,t]                                  			"Value of total technology induced demand for materials from sector s, billion DKK, inflation and growth-adjusted"
		qRxEEOP_ani[ani_sectors,s,t]                                  			"Quantity of total technology induced demand for materials from sector s, billion DKK, growth-adjusted"

		qI_EOPCostAni[i,TechAni,Emmtype,ani_sectors,animals,t]					"Quantity of technology induced investment demand, billion DKK, growth-adjusted"
		vI_EOPCostAni[i,TechAni,Emmtype,ani_sectors,animals,t]					"Value of technology induced investment demand, billion DKK, inflation and growth-adjusted"
	    qI_EOPCostAni_actual[i,TechAni,Emmtype,ani_sectors,animals,t]           ""

		vEOPCostAni_TechTot[TechAni,Emmtype,ani_sectors,animals,t]				"Techonology specific total cost of agricultural technology, billion DKK, inflation and growth-adjusted"
		vEOPcost_ani_tot[ani_sectors,t]											"Total cost of agricultural technology, billion DKK, inflation and growth-adjusted"

		vTech_subsidy_ani[TechAni,EmmType,Ani_sectors,Animals,t]				"Total subsidy payments to firms implementing abatement technology, animal sectors"
		tech_subsidy_ani[TechAni,Emmtype,Ani_sectors,Ani_,t]					"Subsidy for abatement technologies in animal sectors"
	;

	#-------------------------------------------------------------------------------------------------------------------
	# Agricultural non-energy related emissions
	#-------------------------------------------------------------------------------------------------------------------

	$GROUP G_ani_emmissions_q 
		qEmmAgrAni[emmtype,Ani_sectors,Ani_,t,emm_eq]$(d1EmmAgrAni[emmtype,Ani_sectors,Ani_,t,emm_eq]) 	"Non-energy related dis-aggregated animal emissions, measured in kilotonnes"
		qEmmAgrAni_baseline[emmtype,Ani_sectors,Ani_,t,emm_eq]$(d1EmmAgrAni[emmtype,Ani_sectors,Ani_,t,emm_eq]) 	"Non-energy related dis-aggregated animal emissions, measured in kilotonnes"
		qEmmAgrAnimalsOther[emmtype,t,emm_eq]$(d1EmmAgrAniOther[emmtype,t,emm_eq])                       	"Non-energy related animal emissions from animals not encompassed by production functions, measured in kilotonnes"
 	   	qEmmAgrxE[emmtype_,Agri_sectors,t,emm_eq]                                                        	"Non-energy related agricultural emissions, measured in kilotonnes"
   ;

    $GROUP G_ani_emissions_u
    	uEmmAgrAni[emmtype,Ani_sectors,Ani_,t,emm_eq]$(d1EmmAgrAni[emmtype,Ani_sectors,Ani_,t,emm_eq]) 	"Emission-factor on non-energy related disaggregated animal emissions, measured in kilotonnes per emitting unit"
    	uEmmAgrAni_base[emmtype,Ani_sectors,Ani_,t,emm_eq]$(d1EmmAgrAni[emmtype,Ani_sectors,Ani_,t,emm_eq]) 	"Emission-factor on non-energy related disaggregated animal emissions, measured in kilotonnes per emitting unit, baseline for bottom deduction"

    ;


$ENDIF 

# ======================================================================================================================
# Compiling groups of endogenous and exogenous values
# ======================================================================================================================

$IF %stage% == "groupcompilation":

 	$GROUP G_ani_non_flat_initial_values
  		# qAni$(Ani_pK[Ani_])
			qAni_capital
	    qAni$(Animals[Ani_])
	    uEmmAgrAni 
	    qEmmAgrAni
	    qEmmAgrxE$(Ani_sectors[Agri_sectors])
	    qEmmAgrAnimalsOther 
	    qNManureOtherAnimals
			tCO2_emm_ani
			pBotdedPerAnimal
			sSizeBottomDed
			qAni_dis 
			uAni_dis 
			uAni_dis_tot
			qAni_dis_tot
  	;

	$PGROUP PGROUP_production_ani_NonFlat_Dummies
			d1EmmAgrAni
	  	d1Ani$(Animals[Ani_] or sameas[Ani_,'AnimalsAgg'])
			d1BotDedAni
  	;

	$GROUP G_ani_EOP_endo
		uEOPani[Emmtype,ani_sectors,animals,t,emm]$(tx0[t])						
		qGrossEmmAni[Emmtype,ani_sectors,animals,t,emm_eq]$(tx0[t])       
 	 	qEmmAniEOP[Emmtype,ani_sectors,animals,t,emm_eq]$(tx0[t] and sum(TechAni, sum(emm,d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]))) 
 	 	vEOPCostAni_IO[TechAni,Emmtype,ani_sectors,s,animals,t]$(tx0[t] and sum(emm, d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]))								
 	 	vEOPcost_ani_tot[ani_sectors,t]$(tx0[t] and sum(TechAni, sum(Emmtype, sum(animals, sum(emm, d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm])))))													
 	 	rEOPani_preferred[TechAni,ani_sectors,Emmtype,animals,t]$(tx0[t] and sum(emm, d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]))	                              
 	 	rEOPani_actual[TechAni,ani_sectors,Emmtype,animals,t]$(tx0[t] and sum(emm, d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]))	  	                                     
		vRxEEOP_ani[ani_sectors,s,t]$(tx0[t] and sum(TechAni, sum(Emmtype, sum(animals, sum(emm,d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm])))))
		qRxEEOP_ani[ani_sectors,s,t]$(tx0[t] and sum(TechAni, sum(Emmtype, sum(animals, sum(emm,d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm])))))
		rEOPAni_gains[TechAni,ani_sectors,Emmtype,animals,t]$(tx0[t] and sum(emm, d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]))	  
		rEOPAni_costs[TechAni,ani_sectors,Emmtype,animals,t]$(tx0[t] and sum(emm, d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]))	  
		rEOPAni_input[TechAni,ani_sectors,Emmtype,animals,t]$(tx0[t] and sum(emm, d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]))	  
		vEOPCostAni_TechTot[TechAni,Emmtype,ani_sectors,animals,t]$(tx0[t] and sum(emm, d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]))
		rEOPani[TechAni,ani_sectors,Emmtype,animals,t]$(tx0[t] and sum(emm, d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]))	  	
		qI_EOPCostAni[i,TechAni,Emmtype,ani_sectors,animals,t]$(tx0[t] and sameas(i,'iM') and sum(emm, d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]))
		vI_EOPCostAni[i,TechAni,Emmtype,ani_sectors,animals,t]$(tx0[t] and sameas(i,'iM') and sum(emm, d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]))
		qI_EOPCostAni_actual[i,TechAni,Emmtype,ani_sectors,animals,t]$(tx0[t] and sameas(i,'iM') and sum(emm, d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]))
		vTech_subsidy_ani$(tx0[t] and d1TechSubsidyAni[techani,Emmtype,ani_sectors,animals,t])
	;

	$GROUP G_ani_EOP_exo
		thetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]$(tx0[t] and d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm])								
		pEOPAni[TechAni,Emmtype,ani_sectors,animals,t]$(tx0[t] and sum(emm, d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]))		
		rEOPani_preferred[TechAni,ani_sectors,Emmtype,animals,t]$(t0[t] and sum(emm, d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]))	          
		rEOPani_actual[TechAni,ani_sectors,Emmtype,animals,t]$(t0[t] and sum(emm, d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]))                    
 		shareAniPrice_type[techani,techtype,t]
		shareAniPrice_group[techani,s,t]
		uEOPAnit[TechAni,ani_sectors,Emmtype,animals,t]$(tx0[t] and sum(emm, d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]))  							
		j_rEOPAni[TechAni,ani_sectors,Emmtype,animals,t]$(tx0[t] and sum(emm, d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm])) 							
		vTech_subsidy_ani[TechAni,EmmType,Ani_sectors,Animals,t]$(tx0[t] and sum(emm, d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]))				
		tech_subsidy_ani[TechAni,Emmtype,Ani_sectors,Ani_,t]$(tx0[t] and sum(emm, d1ThetaAni[TechAni,ani_sectors,Emmtype,ani_,t,emm]))				
	;

	$GROUP G_GE_LINKS_ANI	# Group of links that link this (partial) model with GreenREFORM as a whole in general equilibrium
		qANI_CET$(ani_out_top[ani_out]) 				
		pAni$(Ani_bottom[Ani_] and not Animals(Ani_))
		pRxE_ym_ani$(d1RxE_ym[ani_sectors,s,t])
	;

	$GROUP G_GE_LINKS_EMMI_ANI 
	    uEmmProdxE$(d1EmmProdxE_overlap[s,t,emm] and ani_sectors_s[s])	# Adapt CGE-emissioncoefficients to hit emissions from agricultural module
	;

	$GROUP G_GE_LINKS_ANI G_GE_LINKS_ANI$(tx0[t]);


	$GROUP G_GE_ENDOGENIZE_ANI	# Group that lets agriculture sectors of production.gms be "constantly recalibrated" to hit submodel inputs and outputs 
  		sRxE_ym$(Ani_sectors_s[r] and d1rXe_ym[r,s,t])
	    uProd$(ani_sectors_sp[sp] and d1prod[prd,sp,t] and prdCapital[prd] and t.val > t1.val)			#In first period, t1, capital stock is determined by capital accumulation in last data year. After that it can be determined by the agricultural module
 	    uProd$(ani_sectors_sp[sp] and d1prod[prd,sp,t] and prdFin[prd]) # and sameas[k,'iM']
 	    uProd$(Ani_sectors_sp[sp] and d1prod[prd,sp,t] and prdL[prd])
 	    uEP$(Ani_sectors_sp[sp] and d1EP[purpose,sp,t])
 	    markup$(Ani_sectors_s[s] and d1vY_CET[out,s,t]) 
	;

	$GROUP G_GE_ENDOGENIZE_ANI G_GE_ENDOGENIZE_ANI$(tx0[t]);


	$GROUP G_CO2ani_exo 
		qEmmAgrAni$(sameas[emm_eq,'CO2e'] and d1EmmAgrAni[emmtype,ani_sectors,ani_,t,emm_eq]) ""
	;

	$GROUP G_CO2ani_endo 
		vCO2_ani$(tx0[t] and d1Ani[Ani_sectors,Animals,t] and d1EmmAgrAni[emmtype,ani_sectors,Animals,t,'CO2e'] and reguleringsgrundlag_ani[emmtype])
		vBotdedPerAnimal$(tx0[t] and ani_sectors_sp[sp]) ""
	;

	$GROUP G_production_ani_endo 
	    pAni_CET0 
	    pAni_CET  
	    pYANI     
	    qAni_CET$(Ani_outNest[ani_out])       
	    pAni$(tx0[t] and (sameas[Ani_,'netprod'] or AniNest[Ani_]  or IOnestsAni[Ani_] or nonNRnestsAni[Ani_]  or ani_pK[Ani_] or animals[Ani_]) and not sameas[ani_,'litter'])
	    pAni_uc$(tx0[t] and d1Ani[ani_sectors,ani_pK,t])
			pTobinsQ_ani
	    qAni
	    qRxE_ym_ani$(d1RxE_ym[Ani_sectors,s,t])

	    qNManure$(sum(emm,d1EmmAgrAni['ManureManagement',ani_sectors,Animals,t,emm])) #link til plant

			pBotdedPerAnimal[emmtype,ani_sectors,animals,t,emm]$(tx0[t] and d1EmmAgrAni[emmtype,ani_sectors,animals,t,emm] and d1BotDedAni[emmtype,ani_sectors,animals,t,emm])
			pBotdedPerAnimal[emmtype,ani_sectors,animals,t,'CO2e']$(tx0[t] and sum(emm, d1EmmAgrAni[emmtype,ani_sectors,animals,t,emm]) and sum(emm, d1BotDedAni[emmtype,ani_sectors,animals,t,emm]))

	    # Non-market
			qRxE_nm$(d1RxE_nm[Agri_sectorss,Agri_sectors,Agri_,t])

			# Emissions
 			qEmmAgrxE$(d1EmmAgrxE[emmtype_,Agri_sectors,t,emm_eq] and emmtype[emmtype_] and (sameas(emmtype_,'EntericFermentation') or sameas(emmtype_,'ManureManagement') or sameas(emmtype_,'GrazingAnimals') or sameas(emmtype_,'N2Oindirect'))) 
	    qEmmAgrAni$(d1EmmAgrAni[emmtype,Ani_sectors,Ani_,t,emm_eq])
	    G_ani_EOP_endo

	    vtCAP_top$(ani_sectors_s(s))

			G_CO2ani_endo

	; 

	$GROUP G_production_ani_endo G_production_ani_endo$(tx0[t]), -pAni_uc$(t1[t] and sameas[ani_pK,'TransportCapital']); #We subtract the user-cost of transport capital in the first period. This is because Transport-capital is Leontief with Machines in first period. With capital being fixed in first period, both user-cost of tranport and machien capital cannot simultaneously be endogenous


	$GROUP G_production_ani_exo
		G_agr_values_ani,-vCO2_ani 
		G_agr_other_ani
		G_ani_taxes 
		G_ani_EOP_exo

		# Ani
		qAni_CET$(not Ani_outNest[ani_out])
		pAni$(not (sameas[Ani_,'netprod'] or AniNest[Ani_] or IOnestsAni[Ani_] or nonNRnestsAni[Ani_] or ani_pK[Ani_] or animals[ani_]))

		qRxE_ym_ani$(not d1RxE_ym[Ani_sectors,s,t])
		pRxE_ym_ani$(d1RxE_ym[ani_sectors,s,t])

		pAni_uc$(tDataEnd[t])

		pBotdedPerAnimal$(d1EmmAgrAni[emmtype,ani_sectors,animals,t,emm_eq])
 
		#Non market prøv at fjerne
		qRxE_nm$(not d1RxE_nm[Agri_sectorss,Agri_sectors,Agri_,t] and ani_sectors[agri_sectorss] and ani_[agri_])
		pRxE_nm$(ani_sectors[agri_sectorss] and ani_[agri_])

		# External
		EKtax$(ani_sectors_sp[sp])	
		rDepr$(ani_sectors_s[s])
		pI_s$(ani_sectors_s[s])
		tK$(ani_sectors_s[s])
		rBonds$(ani_sectors_s[s])
		sDebt2k$(ani_sectors_s[s])
	    tCorp
		rFirms$(ani_sectors_sp[sp])
		vtNetProductionRest$(ani_sectors_s_[s_])
		qKInstCost$(ani_sectors_s[s])
		vtCAP$(ani_sectors_s[s])

		uEmmAgrAni$(d1EmmAgrAni[emmtype,Ani_sectors,Ani_,t,emm_eq])
		uEmmAgrAni_base$(d1EmmAgrAni[emmtype,Ani_sectors,Ani_,t,emm_eq])
		qEmmAgrAnimalsOther$(d1EmmAgrAniOther[emmtype,t,emm_eq])	# Emissions from animals not related to production are exogenous

		vtBotDed$(ani_sectors_s[s])
		pREa$(d1pREa[purpose,energy19a,s,t] and ani_sectors_s[s])
		qREa$(d1pREa[purpose,energy19a,s,t] and ani_sectors_s[s])

		pRE_base$(d1pRE_base[purpose,energy19,r,t] and ani_sectors_s[r]) 
		pRE_base_marg$(d1pRE_base[purpose,energy19,r,t] and ani_sectors_s[r])
		qREgj$(d1PRE_base[purpose,energy19,r,t] and ani_sectors_s[r])

		pAni$(tx0[t] and (sameas[ani_,'manure'] or sameas[ani_,'litter'])) #determined in prod.agr
		pAni$(t1[t] and sameas[ani_,'TransportCapital'])	
		pAni_uc$(t1[t] and sameas[ani_pK,'TransportCapital'])

		#Link 
		jqI_s$(tx0[t] and ani_sectors_s[s])
    	fKInstCost$(tx0[t] and ani_sectors_s[s])

		jpAni_CET$(tx0[t])
		jqAni_CET$(tx0[t])
	;


    $GROUP G_ani_report_endo
    	G_agr_report_ani$(tx0[t])
			-uAni_dis$(tx0[t] and qAni_dis.l[husdyrtype,ani_sectors,animals,t] and qAni.l[ani_sectors,animals,t])
			-uAni_dis_tot 
    ;



	$GROUP G_ani_report_exo  
  	pD_manure$(tx0[t])
  	uManurePerAnimal$(tx0[t] and d1Ani[ani_sectors,animals,t]) # Amount of manure produced per animal, used in calculating the value of manure
  	qAni$(tx0[t] and d1Ani[ani_sectors,ani_,t]), qAni$(tx0[t] and sameas[ani_,'AnimalsAgg']) # Quantity of animal production, used in calculating the value of animal production
  	pAni$(tx0[t] and d1Ani[ani_sectors,ani_,t]), pAni$(tx0[t] and sameas[ani_,'AnimalsAgg']) 
		vAni$(tx0[t] and d1Ani[ani_sectors,ani_,t]) # Value of animal production, used in calculating the value of animal production
  	vtEAFG_RE$(tx0[t] and d1EAFG_RE[purpose,energy19,r,t]) # Energy taxes on animal production
  	vCO2_ani$(tx0[t] and d1EmmAgrAni[emmtype,ani_sectors,animals,t,'CO2e']) # CO2e tax on non-energy related emissions in animal production
  	vEOPCostAni_TechTot$(tx0[t] and sum(emm,d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm])) # Total cost of abatement technology in animal production
		vTech_subsidy_ani$(tx0[t] and d1TechSubsidyAni[techani,Emmtype,ani_sectors,animals,t])
  	tCO2_emm_ani[emmtype,Ani_sectors,Ani_,t]$(tx0[t] and d1EmmAgrAni[emmtype,Ani_sectors,Ani_,t,'CO2e']) # CO2 tax on non-energy related emissions in animal production 
  	qEmmAgrAni_baseline[emmtype,ani_sectors,Animals,t,'co2e']$(tx0[t] and d1EmmAgrAni[emmtype,ani_sectors,Animals,t,'co2e']) # Baseline emissions in animal production
  	pAni_CET_baseline[ani_sectors,'out_other',t]$(tx0[t]) # Baseline CET price for animal production
  	qAni_CET_baseline[ani_sectors,'out_other',t]$(tx0[t]) # Baseline CET quantity for animal production
  	qEmmAgrxE$(tx0[t] and d1EmmAgrxE[emmtype_,agri_sectors,t,emm_eq]) # Total non-energy related emissions in animal production
  	pRE_base$(tx0[t] and d1pRE_base[purpose,energy19,r,t]) # Average energy prices in animal production
  	pRE_base_marg$(tx0[t] and d1PRE_base[purpose,energy19,r,t]) # Average energy prices in animal production
		qREgj$(tx0[t] and d1PRE_base[purpose,energy19,r,t]) # Quantity of energy used in animal production
  	pREa$(tx0[t] and (d1pREa[purpose,energy19a,s,t] or d1pREown[purpose,energy19a,s,t])) # Average energy prices in animal production
  	qREa$(tx0[t] and (d1pREa[purpose,energy19a,s,t] or d1pREown[purpose,energy19a,s,t])) # Quantity of energy used in animal production
  	vtEAFG_REmarg[purpose,energy19a,r,t]$(tx0[t] and d1EAFG_RE[purpose,energy19a,r,t]) # Marginal energy taxes in animal production
		vtEAFG_RE[purpose,energy19a,r,t]$(tx0[t] and d1EAFG_RE[purpose,energy19a,r,t]) # Energy taxes on animal production
  	vtCO2_RE[purpose,energy19a,r,t]$(tx0[t] and d1CO2_RE[purpose,energy19a,r,t]) # CO2 tax on energy in animal production
  	vtCO2_REmarg[purpose,energy19,r,t]$(tx0[t] and d1CO2_RE[purpose,energy19,r,t]) # Marginal CO2 tax on energy in animal production
  	vtCO2_ETS_marg$(tx0[t]) 
  	tqRE[purpose,energy19,r,t]$(tx0[t] and (d1pRE_base[purpose,energy19,r,t] or d1pREown[purpose,energy19,r,t])) # Tax on energy in animal production
  	vtNetProductionRest$(tx0[t])
  	vtCAP_top$(tx0[t])
  	vtLand$(tx0[t])
  	vtFirmsWeight$(tx0[t]) 
  	vtCO2_ETS$(tx0[t])
  	vtL$(tx0[t])
  	pAni_CET$(tx0[t])
  	pAni_CET0$(tx0[t])
  	qAni_CET$(tx0[t])
		uAni_dis$(tx0[t] and qAni_dis.l[husdyrtype,ani_sectors,animals,t] and qAni.l[ani_sectors,animals,t])
		uAni_dis_tot 
		qX_y['xOth','01051',t]
  	;
  
  

    $GROUP G_baseline_ani
    	pAni_CET
    	qAni_CET
    	qEmmAgrAni
    ;

$ENDIF

# ======================================================================================================================
# Equations
# ======================================================================================================================

$IF %stage% == "equations":

$BLOCK B_production_agr_ani

  # ---------------------------------------------------------------------------------------------------------------------
  # Animal production structure
  # ---------------------------------------------------------------------------------------------------------------------

	# CET split budget constraint 
	E_pAni_CET_nest[Ani_sectors,Ani_outNest,t]$(tx0[t])..  	
		pAni_CET0[Ani_sectors,Ani_outNest,t]*qAni_CET[Ani_sectors,Ani_outNest,t] =E= sum(Ani_out$Ani_prod2out[Ani_outNest,Ani_out], pAni_CET0[Ani_sectors,Ani_out,t]*qAni_CET[Ani_sectors,Ani_out,t]); 

	# CET split Ani production
	E_pAni_CET0[Ani_sectors,Ani_out,Ani_outNest,t]$(tx0[t] and Ani_prod2out[Ani_outNest,Ani_out])..      
		qAni_CET[Ani_sectors,Ani_out,t] =E= uAni_CET[Ani_sectors,Ani_out,t] * 
			(pAni_CET0[Ani_sectors,Ani_out,t]/pAni_CET0[Ani_sectors,Ani_outNest,t])**eCET_Ani[Ani_sectors,Ani_outNest] *
			qAni_CET[Ani_sectors,Ani_outNest,t]; 

	# CET markups
	E_pAni_CET[Ani_sectors,Ani_out_top,t]$(tx0[t])..  
		pAni_CET[Ani_sectors,Ani_out_top,t] =E= (1+ani_markup[Ani_sectors,Ani_out_top,t])*pAni_CET0[Ani_sectors,Ani_out_top,t];

	# Computes the "average" output price
	E_pYANI[Ani_sectors,t]$(tx0[t])..        pYAni[ani_sectors,t]*qAni[Ani_sectors,'netprod',t] =E= sum(Ani_out_top, pAni_CET[Ani_sectors,Ani_out_top,t] *qAni_CET[Ani_sectors,Ani_out_top,t]);

	# CET links - quantities and prices 
	E_qAni_CET_[Ani_sectors,t]$(tx0[t]).. 
		qAni[Ani_sectors,'netprod',t] =E=    qAni_CET[Ani_sectors,'netprod',t]; 
	
	E_pAni_CET_[Ani_sectors,t]$(tx0[t]).. 
		pAni[Ani_sectors,'netprod',t] =E= 	 pAni_CET0[Ani_sectors,'netprod',t];

	E_pAni_netprod[Ani_sectors,t]$(tx0[t]).. pAni[Ani_sectors,'netprod',t] =E= pAni[Ani_sectors,'grossprod',t] 
																			+ vtBotDed[Ani_sectors,t]*d1tREmarg[Ani_sectors]/qAni[Ani_sectors,'netprod',t]
																			# Account for marginal vs. average energy prices
																			+ sum((purpose,energy19)$(d1pRE_base[purpose,energy19,Ani_sectors,t]),(pRE_base[purpose,energy19,Ani_sectors,t]-pRE_base_marg[purpose,energy19,ani_sectors,t])*qREgj[purpose,energy19,Ani_sectors,t])
   																			+ sum((purpose,energy19)$(d1pREa[purpose,energy19,Ani_sectors,t] and eNotInEnergyNest[purpose,energy19,Ani_sectors,t]), pREa[purpose,energy19,Ani_sectors,t]*qREa[purpose,energy19,Ani_sectors,t])/qAni[Ani_sectors,'netprod',t]
																			+ vtNetProductionRest[ani_sectors,t]/qAni[Ani_sectors,'netprod',t]
																			+ vtCAP[ani_sectors,t]/qAni[Ani_sectors,'netprod',t]
																			#  - sum((purpose,energy19)$(d1tRE[purpose,energy19,ani_sectors,t]), vtCalibENS[purpose,energy19,ani_sectors,t])/qAni[ani_sectors,'netprod',t]
																			;
	
	E_qAni_netprod[Ani_sectors,t]$(tx0[t]).. qAni[Ani_sectors,'netprod',t] =E= qAni[Ani_sectors,'grossprod',t] - sum(k, qKInstCost[k,ani_sectors,t]);

	# Budget Constraint - Animal aggregates
	E_pAni_nests[Ani_sectors,AniNest,t]$(tx0[t] and d1Ani[Ani_sectors,AniNest,t])..
		pAni[Ani_sectors,AniNest,t] * qAni[Ani_sectors,AniNest,t] 	=E= sum(Ani_$(AniNest2inputs_[AniNest,Ani_] and d1Ani[Ani_sectors,Ani_,t]), pAni[Ani_sectors,Ani_,t]*qAni[Ani_sectors,Ani_,t]); 
	
	# FOC - Animal Production inputs
	E_qAni_top[Ani_sectors,Ani_,Aninest,t]$(tx0[t] and AniNest2inputs_[AniNest,Ani_] and d1Ani[Ani_sectors,Ani_,t] and not sameas(Ani_,'AnimalsAgg') and not Leontief_aniNest[aniNest] and not Animals[ani_] and sameas[AniNest,'grossprod'])..# and not sameas(AniNest,'AnimalsAgg') ).. 
  		TFPani[ani_sectors,t] * qAni[Ani_sectors,Ani_,t] =E= uAni[Ani_sectors,Ani_,t] * (pAni[Ani_sectors,Ani_,t] / pAni[Ani_sectors,AniNest,t])**(-eAni[Ani_sectors,AniNest,t])*qAni[Ani_sectors,AniNest,t];


	E_qAni_nottop[Ani_sectors,Ani_,Aninest,t]$(tx0[t] and AniNest2inputs_[AniNest,Ani_] and d1Ani[Ani_sectors,Ani_,t] and not sameas(Ani_,'AnimalsAgg') and not Leontief_aniNest[aniNest] and not Animals[ani_] and not sameas[AniNest,'grossprod'])..# and not sameas(AniNest,'AnimalsAgg') ).. 
  		qAni[Ani_sectors,Ani_,t] =E= uAni[Ani_sectors,Ani_,t] * (pAni[Ani_sectors,Ani_,t] / pAni[Ani_sectors,AniNest,t])**(-eAni[Ani_sectors,AniNest,t])*qAni[Ani_sectors,AniNest,t];

	# Animal aggregates is explicitly modelled as Leontief
	E_qAnimalsAgg[Ani_sectors,t]$(tx0[t] and d1Ani[ani_sectors,'AnimalsAgg',t])..
  		qAni[Ani_sectors,'AnimalsAgg',t] =E= uAni[Ani_sectors,'AnimalsAgg',t] * qAni[ani_sectors,'BAML',t];

  #Capital and financial services for capital are modelled as Leontief
  E_qAni_nottop_LeontiefCap_ani[ani_sectors,ani_,AniNest,t]$(tx0[t] and AniNest2inputs_[AniNest,Ani_] and d1Ani[ani_sectors,ani_,t] and Leontief_aniNest[aniNest] and not sameas[Ani_,'TransportCapital'])..
  	qAni[ani_sectors,ani_,t] =E= uAni[ani_sectors,ani_,t] * qAni[ani_sectors,AniNest,t];
  	#  qAni[ani_sectors,ani_,t] =E= uAni[ani_sectors,ani_,t] * (pAni[ani_sectors,ani_,t]/pAni[ani_sectors,aninest,t])**(-0.01) * qAni[ani_sectors,AniNest,t];

  E_qAni_nottop_LeontiefCap_ani_TC[ani_sectors,ani_,AniNest,t]$(tx1[t] and AniNest2inputs_[AniNest,Ani_] and d1Ani[ani_sectors,ani_,t] and Leontief_aniNest[aniNest]  and sameas[Ani_,'TransportCapital'])..
  	#  qAni[ani_sectors,ani_,t] =E= uAni[ani_sectors,ani_,t] * qAni[ani_sectors,AniNest,t];
  	qAni[ani_sectors,ani_,t] =E= uAni[ani_sectors,ani_,t] * qAni[ani_sectors,AniNest,t];

	E_pAni_animals[ani_sectors,animals,t]$(tx0[t] and d1Ani[ani_sectors,animals,t]).. 
		pAni[ani_sectors,animals,t]		=E= (- pD_manure[t] * uManurePerAnimal[ani_sectors,animals,t])$(sum(emm,d1EmmAgrAni['ManureManagement',ani_sectors,Animals,t,emm])) #Manure price should only be added when there is manure production 
											+ sum(emmtype$(d1EmmAgrAni[emmtype,ani_sectors,animals,t,'CO2e']), vCO2_ani[EmmType,Ani_sectors,Animals,t])/qAni[ani_sectors,animals,t]
											- sum(emmtype$(d1EmmAgrAni[emmtype,ani_sectors,animals,t,'CO2e']), pBotdedPerAnimal[emmtype,ani_sectors,animals,t,'CO2e'])
											- sum((TechAni,emmtype)$(sum(emm,d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm])), vTech_subsidy_ani[TechAni,EmmType,Ani_sectors,Animals,t])/qAni[ani_sectors,animals,t]
											+ sum((TechAni,emmtype)$(sum(emm,d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm])), vEOPCostAni_TechTot[TechAni,Emmtype,ani_sectors,animals,t])/qAni[ani_sectors,animals,t]
											;
		
	# Animal types is explicitly modelled as Leontief AND are not growth-adjusted
	E_qAnimals[Ani_sectors,Animals,t]$(tx0[t] and d1Ani[Ani_sectors,Animals,t])..
  		thetaA[Ani_sectors,Animals,t] * qAni[Ani_sectors,Animals,t] =E= uAni[Ani_sectors,Animals,t] * qAni[ani_sectors,'AnimalsAgg',t];

	# We condition on d1EmmAgr instead of d1Ani because not all animals are producing manure in the model
	E_qNManure[ani_sectors,animals,t]$(tx0[t] and sum(emm,d1EmmAgrAni['ManureManagement',ani_sectors,Animals,t,emm])).. 
		
		qNManure[ani_sectors,animals,t] =E=  uManurePerAnimal[ani_sectors,animals,t] * qAni[ani_sectors,animals,t];

	# Budget constraint - Animal IO inputs
	E_pAni_ym[Ani_sectors,Ani_,t]$(tx0[t] and IOnestsAni[Ani_] and d1Ani[Ani_sectors,Ani_,t])..
		pAni[Ani_sectors,Ani_,t]*qAni[Ani_sectors,Ani_,t] =E= sum(s$(input2ani[s,Ani_] and d1RxE_ym[Ani_sectors,s,t]), qRxE_ym_ani[Ani_sectors,s,t]*pRxE_ym_ani[Ani_sectors,s,t]);
	
	# FOC - Animal IO inputs
	E_qRxE_ym_ani[Ani_sectors,Ani_,s,t]$(tx0[t] and input2ani[s,Ani_] and d1RxE_ym[Ani_sectors,s,t]).. 
		qRxE_ym_ani[Ani_sectors,s,t] =E= sRxE_ym_ani[Ani_sectors,s,t] * (pRxE_ym_ani[Ani_sectors,s,t] / pAni[Ani_sectors,Ani_,t])**(-eAni[Ani_sectors,Ani_,t]) * qAni[Ani_sectors,Ani_,t];

	# Budget constraint - Animal non-market inputs 
	E_pAni_nm[Ani_sectors,Ani_,t]$(tx0[t] and nonNRnestsAni[Ani_] and d1Ani[Ani_sectors,Ani_,t] and not sameas[ani_,'manure'] and not sameas[ani_,'litter'])..
    	pAni[Ani_sectors,Ani_,t] * qAni[Ani_sectors,Ani_,t] =E= sum(agri_sectors$(d1RxE_nm[Ani_sectors,agri_sectors,Ani_,t]), pRxE_nm[Ani_sectors,agri_sectors,Ani_,t] * qRxE_nm[Ani_sectors,agri_sectors,Ani_,t]);

    # FOC - Non-market inputs
    E_qRxE_nm_ani[Ani_sectors,agri_sectors,Ani_,t]$(tx0[t] and d1RxE_nm[Ani_sectors,agri_sectors,Ani_,t] and not sameas[ani_,'manure'] and not sameas[ani_,'litter']).. 
	    qRxE_nm[Ani_sectors,agri_sectors,Ani_,t] =E= sRxE_nm[ani_sectors,agri_sectors,Ani_,t] * (pRxE_nm[ani_sectors,agri_sectors,Ani_,t]/pAni[Ani_sectors,Ani_,t])**(-eAni[Ani_sectors,Ani_,t]) * qAni[Ani_sectors,Ani_,t];

	# User-cost (same as main model with the difference that non-market input/outs are accounted for)
	# Definition of user cost
  	E_pAni_uc[ani_sectors,ani_pK,k,t]$(tx0E[t] and d1K[k,ani_sectors,t] and agri2k[ani_pK,k] and d1ani[ani_sectors,ani_pK,t])..
		pAni_uc[ani_sectors,ani_pK,t+1]*fp*(1-tCorp[t+1]) =E= 
  			# Tobin's q today and tomorrow
  			pTobinsQ_ani[ani_sectors,ani_pK,t] * (1+rFirms[ani_sectors,t+1]) - (1-rDepr[k,ani_sectors,t+1]) * pTobinsQ_ani[ani_sectors,ani_pK,t+1]*fp
  			# Production tax on capital
        	+ (1-tCorp[t+1]) * tK[k,ani_sectors,t+1] * pI_s[k,ani_sectors,t+1]*fp
        	# Tax shield
        	- ((rFirms[ani_sectors,t+1] - rBonds[ani_sectors,'2025'] * (1-tCorp[t+1])) * sDebt2k[k,ani_sectors,t] * pI_s[k,ani_sectors,t])$(t.val<2025)
        	- ((rFirms[ani_sectors,t+1] - rBonds[ani_sectors,t+1] * (1-tCorp[t+1])) * sDebt2k[k,ani_sectors,t] * pI_s[k,ani_sectors,t])$(t.val>=2025)
        	# Discounted value of change in future installation costs from change in investments today

        	+ (1-tCorp[t+1]) * pAni[Ani_sectors,'grossprod',t+1] *fp * dKinstCost2dK[k,ani_sectors,t]

        	#Added term to correct for difference between forward looking   
  			+ jpK_ani[ani_sectors,ani_pK,t+1]
  		; 

    E_pTobinsQ_ani[ani_sectors,ani_pK,k,t]$(tx0E[t] and d1K[k,ani_sectors,t] and agri2k[ani_pK,k] and d1ani[ani_sectors,ani_pK,t])..
    	pTobinsQ_ani[ani_sectors,ani_pK,t] =E= pI_s[k,ani_sectors,t] - pI_s[k,ani_sectors,t]*EKtax[k,ani_sectors,t]
    		+ pAni[Ani_sectors,'grossprod',t]  * (1-tCorp[t]) * dKInstCost2dI[k,ani_sectors,t]
    		+ 1/(1+rFirms[ani_sectors,t+1]) * pAni[Ani_sectors,'grossprod',t+1] * fp * (1-tCorp[t+1]) * dKInstCostLead2dI[k,ani_sectors,t] * qK[k,ani_sectors,t];


    E_pTobinsQ_ani_terminal[ani_sectors,ani_pK,k,t]$(tEnd[t] and d1K[k,ani_sectors,t] and agri2k[ani_pK,k] and d1ani[ani_sectors,ani_pK,t])..
    	pTobinsQ_ani[ani_sectors,ani_pK,t] =E= pI_s[k,ani_sectors,t] - pI_s[k,ani_sectors,t]*EKtax[k,ani_sectors,t]
    		+ pAni[Ani_sectors,'grossprod',t] * (1-tCorp[t]) * dKInstCost2dI[k,ani_sectors,t];


		#Scaling uc and capital for entering in production function
		E_pAni_pK[ani_sectors,ani_pK,t]$(tx0[t] and d1ani[ani_sectors,ani_pK,t])..
			pAni[ani_sectors,ani_pK,t] =E= pAni_uc[ani_sectors,ani_pK,t]/pAni_uc[ani_sectors,ani_pK,tDataEnd]; 

		E_qAni_qK[ani_sectors,ani_pK,t]$(tx0[t] and d1ani[ani_sectors,ani_pK,t])..
			qAni[ani_sectors,ani_pK,t] =E= qAni_capital[ani_sectors,ani_pK,t]*pAni_uc[ani_sectors,ani_pK,tDataEnd];

   # ---------------------------------------------------------------------------------------------------------------------
   # CAP-BUDGET
   # ---------------------------------------------------------------------------------------------------------------------

	# CAP subsidies that enter the top of the production function: all CAP-subsidies for animal sectors
	E_vtCAP_top_ani[ani_sectors,t]$(tx0[t]).. 			  vtCAP_top[ani_sectors,t] =E= vtCAP[ani_sectors,t];

$ENDBLOCK

# ---------------------------------------------------------------------------------------------------------------------
# Non-energy emissions from livestock 
# ---------------------------------------------------------------------------------------------------------------------

$BLOCK B_emissions_agr_ani 
	# Emissions AFTER end-of-pipe-abatement
	E_qEmmProdxE_agr_ani[ani_sectors,t,emm]$(tx0[t] and d1EmmProdxE_overlap[ani_sectors,t,emm]).. 
				qEmmProdxE[ani_sectors,t,emm]	=E= qEmmAgrxE['EntericFermentation',ani_sectors,t,emm]$(d1EmmAgrxE['EntericFermentation',ani_sectors,t,emm])	
												  + qEmmAgrxE['ManureManagement',ani_sectors,t,emm]$(d1EmmAgrxE['ManureManagement',ani_sectors,t,emm])
												  + qEmmAgrxE['GrazingAnimals',ani_sectors,t,emm]$(d1EmmAgrxE['GrazingAnimals',ani_sectors,t,emm])
												  + qEmmAgrxE['N2Oindirect',ani_sectors,t,emm]$(d1EmmAgrxE['N2Oindirect',ani_sectors,t,emm])
												  + jEmmAgrxE[ani_sectors,t,emm];

	# These are emissions BEFORE end-of-pipe-abatement

	# Animal related emissions
		# Enteric fermentation
		E_qEmmEntericFermentationAnimals[ani_sectors,Ani_,t,emm]$(tx0[t] and Animals[ani_] and d1EmmAgrAni['EntericFermentation',ani_sectors,ani_,t,emm])..  
			qEmmAgrAni['EntericFermentation',ani_sectors,Ani_,t,emm] =E= uEmmAgrAni['EntericFermentation',ani_sectors,Ani_,t,emm] * qAni[ani_sectors,Ani_,t] * uEOPani['EntericFermentation',ani_sectors,ani_,t,emm];
		E_qEmmEntericFermentationAnimals_CO2e[ani_sectors,Ani_,t]$(tx0[t] and d1EmmAgrAni['EntericFermentation',ani_sectors,Ani_,t,'co2e'])..
			qEmmAgrAni['EntericFermentation',ani_sectors,Ani_,t,'co2e'] =E= sum(emm$(d1EmmAgrAni['EntericFermentation',ani_sectors,Ani_,t,emm]), qEmmAgrAni['EntericFermentation',ani_sectors,Ani_,t,emm]*GWP[emm]);
		E_qEmmEntericFermentation[ani_sectors,t,emm_eq]$(tx0[t] and sum(Ani_, d1EmmAgrAni['EntericFermentation',ani_sectors,Ani_,t,emm_eq]))..  
			qEmmAgrxE['EntericFermentation',ani_sectors,t,emm_eq] =E= sum(Ani_$(d1EmmAgrAni['EntericFermentation',ani_sectors,Ani_,t,emm_eq]), qEmmAgrAni['EntericFermentation',ani_sectors,Ani_,t,emm_eq]);

		# Manure management
		E_qEmmManureManagementAnimals[ani_sectors,animals,t,emm]$(tx0[t] and d1EmmAgrAni['ManureManagement',ani_sectors,Animals,t,emm]).. 
			qEmmAgrAni['ManureManagement',ani_sectors,Animals,t,emm] =E= uEmmAgrAni['ManureManagement',ani_sectors,Animals,t,emm] * qNManure[ani_sectors,animals,t] * uEOPani['ManureManagement',ani_sectors,animals,t,emm];

		E_qEmmManureManagementAnimals_CO2e[ani_sectors,Animals,t]$(tx0[t] and d1EmmAgrAni['ManureManagement',ani_sectors,Animals,t,'co2e'])..
			qEmmAgrAni['ManureManagement',ani_sectors,Animals,t,'co2e'] =E= sum(emm$(d1EmmAgrAni['ManureManagement',ani_sectors,Animals,t,emm]), qEmmAgrAni['ManureManagement',ani_sectors,Animals,t,emm]*GWP[emm]);

		E_qEmmManureManagement[ani_sectors,t,emm_eq]$(tx0[t] and sum(Animals,d1EmmAgrAni['ManureManagement',ani_sectors,Animals,t,emm_eq]))..  
			qEmmAgrxE['ManureManagement',ani_sectors,t,emm_eq] =E= sum(Animals$(d1EmmAgrAni['ManureManagement',ani_sectors,Animals,t,emm_eq]), qEmmAgrAni['ManureManagement',ani_sectors,Animals,t,emm_eq]);

		# Grazing animals
		E_qEmmGrazinAnimalsAni[ani_sectors,ani_,t,emm]$(tx0[t] and Animals[ani_] and d1EmmAgrAni['GrazingAnimals',ani_sectors,ani_,t,emm])..  
			qEmmAgrAni['GrazingAnimals',ani_sectors,ani_,t,emm] =E= uEmmAgrAni['GrazingAnimals',ani_sectors,ani_,t,emm] * qAni[ani_sectors,ani_,t] * uEOPani['GrazingAnimals',ani_sectors,ani_,t,emm];
		E_qEmmGrazinAnimals_CO2e[ani_sectors,Ani_,t]$(tx0[t] and d1EmmAgrAni['GrazingAnimals',ani_sectors,Ani_,t,'CO2e'])..
			qEmmAgrAni['GrazingAnimals',ani_sectors,Ani_,t,'CO2e'] =E= sum(emm$(d1EmmAgrAni['GrazingAnimals',ani_sectors,Ani_,t,emm]), qEmmAgrAni['GrazingAnimals',ani_sectors,Ani_,t,emm]*GWP[emm]);

		E_qEmmGrazingAnimals[ani_sectors,t,emm_eq]$(tx0[t] and sum(Animals, d1EmmAgrAni['GrazingAnimals',ani_sectors,Animals,t,emm_eq]))..  
			qEmmAgrxE['GrazingAnimals',ani_sectors,t,emm_eq] =E= sum(Animals$(d1EmmAgrAni['GrazingAnimals',ani_sectors,Animals,t,emm_eq]), qEmmAgrAni['GrazingAnimals',ani_sectors,Animals,t,emm_eq]);

		# Indirect N2O-emissions
		E_qEmmN2OindirectAni[ani_sectors,Ani_,t,emm]$(tx0[t] and d1EmmAgrAni['N2Oindirect',ani_sectors,Ani_,t,emm])..  
			qEmmAgrAni['N2Oindirect',ani_sectors,Ani_,t,emm] =E= uEmmAgrAni['N2Oindirect',ani_sectors,Ani_,t,emm] * qAni[ani_sectors,Ani_,t];
		E_qEmmN2Oindirect_CO2e[ani_sectors,Ani_,t]$(tx0[t] and d1EmmAgrAni['N2Oindirect',ani_sectors,Ani_,t,'CO2e'])..
			qEmmAgrAni['N2Oindirect',ani_sectors,Ani_,t,'CO2e'] =E= sum(emm$(d1EmmAgrAni['N2Oindirect',ani_sectors,Ani_,t,emm]), qEmmAgrAni['N2Oindirect',ani_sectors,Ani_,t,emm]*GWP[emm]);

		E_qEmmN2Oindirect[ani_sectors,t,emm_eq]$(tx0[t] and sum(Ani_, d1EmmAgrAni['N2Oindirect',ani_sectors,Ani_,t,emm_eq]))..  
			qEmmAgrxE['N2Oindirect',ani_sectors,t,emm_eq] =E= sum(Ani_$(d1EmmAgrAni['N2Oindirect',ani_sectors,Ani_,t,emm_eq]), qEmmAgrAni['N2Oindirect',ani_sectors,Ani_,t,emm_eq]);

$ENDBLOCK 


# ---------------------------------------------------------------------------------------------------------------------
# Tax on non-energy related emissions 
# ---------------------------------------------------------------------------------------------------------------------

$BLOCK B_CO2taxOnAni
		E_vCO2_emm_ani[Emmtype,Ani_sectors,Animals,t]$(tx0[t] and d1EmmAgrAni[emmtype,ani_sectors,Animals,t,'CO2e'] and reguleringsgrundlag_ani[emmtype])..
			vCO2_ani[EmmType,Ani_sectors,Animals,t] =E= tCO2_emm_ani[emmtype,Ani_sectors,Animals,t] * (1-afgiftsfritagede[t,animals,ani_sectors]) * (qEmmAgrAni[emmtype,ani_sectors,Animals,t,'co2e']*growth_factor[t]) / 10**6;

$ENDBLOCK


# ---------------------------------------------------------------------------------------------------------------------
# Bottom-deduction on animals 
# ---------------------------------------------------------------------------------------------------------------------
$BLOCK B_botdedperanimal
    E_pBotdedPerAnimal[emmtype,ani_sectors,animals,t,emm]$(tx0[t] and d1EmmAgrAni[emmtype,ani_sectors,animals,t,emm] and d1BotDedAni[emmtype,ani_sectors,animals,t,emm])..
        pBotdedPerAnimal[emmtype,ani_sectors,animals,t,emm] 
        =E= (tCO2_emm_ani[emmtype,Ani_sectors,animals,t]/10**6 * growth_factor[t] * GWP[emm] 
            * uEmmAgrAni_base[emmtype,ani_sectors,animals,'2024',emm] * (1$(not sameas[emmtype,'ManureManagement'])+uManurePerAnimal_base[ani_sectors,animals,'2024']$(sameas[emmtype,'ManureManagement'])))
            * sSizeBottomDed[emmtype,ani_sectors,animals,t,emm];

    E_pBotdedPerAnimal_CO2e[emmtype,ani_sectors,animals,t]$(tx0[t] and sum(emm, GWP.l[emm]*d1EmmAgrAni[emmtype,ani_sectors,animals,t,emm]))..
        pBotdedPerAnimal[emmtype,ani_sectors,animals,t,'CO2e'] =E= sum(emm$(d1EmmAgrAni[emmtype,ani_sectors,animals,t,emm] and d1BotDedAni[emmtype,ani_sectors,animals,t,emm]), 
                                                                             pBotdedPerAnimal[emmtype,ani_sectors,animals,t,emm])*jBotdedPeranimal[emmtype,ani_sectors,animals,t];
    E_vBotdedPerAnimal[ani_sectors,t]$(tx0[t])..
            vBotdedPerAnimal[ani_sectors,t] =E= sum((emmtype,animals)$(sum(emm, d1EmmAgrAni[emmtype,ani_sectors,animals,t,emm] and d1BotDedAni[emmtype,ani_sectors,animals,t,emm])),
                                                        pBotdedPerAnimal[emmtype,ani_sectors,animals,t,'CO2e'] * qAni[ani_sectors,animals,t]);

$ENDBLOCK

# ---------------------------------------------------------------------------------------------------------------------
# GE Links to rest of model 
# ---------------------------------------------------------------------------------------------------------------------

$BLOCK B_LINK_ani
	# Animal production

		#Demand for market outputs
		E_qAni_CET_LINK[Ani_sectors,Ani_out_top,t]$(tx0[t])..  							   qAni_CET[Ani_sectors,ani_out_top,t] =E= sum(out$out2ani_out(out,Ani_out_top), qY_CET[out,Ani_sectors,t]) + jqAni_CET[Ani_sectors,ani_out_top,t];

		#Agricultural module sends back output price through adjustment of mark-up in CGE-model
		E_pY_CET_ani_LINK[out,ani_sectors,t]$(tx0[t] and d1vY_CET[out,ani_sectors,t])..    pY_CET[out,ani_sectors,t] =E= sum(Ani_out_top$(out2ani_out(out,ani_out_top)), pAni_CET[Ani_sectors,Ani_out_top,t] + jpAni_CET[ani_sectors,ani_out_top,t]) ;      

		E_qRxE_ym_LINK_ani[Ani_sectors,s,t]$(tx0[t] and d1RxE_ym[Ani_sectors,s,t]).. 	
														qRxE_ym_ani[Ani_sectors,s,t]			=E= qRxE_ym[Ani_sectors,s,t]; #sRxE_ym 
		E_pRxE_ym_LINK_ani[Ani_sectors,s,t]$(tx0[t] and d1RxE_ym[Ani_sectors,s,t]).. 	
														pRxE_ym_ani[Ani_sectors,s,t]			=E= pRxE_ym[Ani_sectors,s,t];  

		#Financial services
		E_qFin_iM_LINK_ani[Ani_sectors,t]$(tx0[t])..  	qAni[Ani_sectors,'FinancialServiceM',t]  =E= qFin_k['iM',Ani_sectors,t];
		E_pFin_iM_LINK_ani[Ani_sectors,t]$(tx0[t])..  	pAni[Ani_sectors,'FinancialServiceM',t]  =E= pFin_k['iM',Ani_sectors,t];

    	E_qFin_iB_LINK_ani[Ani_sectors,t]$(tx0[t])..  	qAni[Ani_sectors,'FinancialServiceB',t]  =E= qFin_k['iB',Ani_sectors,t];
		E_pFin_iB_LINK_ani[Ani_sectors,t]$(tx0[t])..  	pAni[Ani_sectors,'FinancialServiceB',t]  =E= pFin_k['iB',Ani_sectors,t];

    	E_qFin_iT_LINK_ani[Ani_sectors,t]$(tx0[t])..  	qAni[Ani_sectors,'FinancialServiceT',t]  =E= qFin_k['iT',Ani_sectors,t];
		E_pFin_iT_LINK_ani[Ani_sectors,t]$(tx0[t])..  	pAni[Ani_sectors,'FinancialServiceT',t]  =E= pFin_k['iT',Ani_sectors,t];
	 
		#Capital demand						
		E_qK_ib_LINK_ani[Ani_sectors,t]$(tx0[t])..  	qAni_capital[Ani_sectors,'Buildings',t] 	    	=E= qK['ib',Ani_sectors,t-1]/fq; #uK 
		E_qK_im_LINK_ani[Ani_sectors,t]$(tx0[t])..  	qAni_capital[Ani_sectors,'MachinesPrivate',t]   =E= qK['im',Ani_sectors,t-1]/fq;  #uK
		E_qK_it_LINK_ani[Ani_sectors,t]$(tx0[t])..  	qAni_capital[Ani_sectors,'TransportCapital',t]  =E= qK['it',Ani_sectors,t-1]/fq;

	
		#Labor-demand																							        
		E_qL_LINK_ani[Ani_sectors,t]$(tx0[t])..			qAni[Ani_sectors,'Labor',t] =E= qL[Ani_sectors,t]*thetaProd['L',Ani_sectors,t];  #uL
		E_pL_LINK_ani[Ani_sectors,t]$(tx0[t])..			pAni[Ani_sectors,'Labor',t] =E= (1+tL[Ani_sectors,t])*w[t]; 

		#Fuel demand and fuel prices
		E_qRE_fuel_ani[Ani_sectors,t]$(tx0[t] and d1Ani[ani_sectors,'fuel',t] and d1EP['intern_trans',ani_sectors,t])..        qAni[Ani_sectors,'Fuel',t] =E= qEP['intern_trans',ani_sectors,t];
		E_pRE_fuel_ani[Ani_sectors,t]$(tx0[t] and d1Ani[ani_sectors,'fuel',t] and d1EP['intern_trans',ani_sectors,t])..        pAni[Ani_sectors,'Fuel',t] =E= pEP['intern_trans',ani_sectors,t];

		#Demand for other energi and price of other energi
		E_qRE_otherenergy_ani[ani_sectors,purpose_xtint,t]$(tx0[t] and d1EP[purpose_xtint,ani_sectors,t])..
		    qEP[purpose_xtint,ani_sectors,t] =E= uOtherEnergy_ani[purpose_xtint,ani_sectors,t] * (pEP[purpose_xtint,ani_sectors,t]/pAni[ani_sectors,'OtherEnergy',t]) **(-eAni[Ani_sectors,'OtherEnergy',t]) * qAni[ani_sectors,'OtherEnergy',t];
		
		E_pRE_otherenergy_ani[ani_sectors,t]$(tx0[t])..
			pAni[Ani_sectors,'OtherEnergy',t]*qAni[Ani_sectors,'OtherEnergy',t] =E= sum(purpose_xtint$(d1EP[purpose_xtint,ani_sectors,t]), pEP[purpose_xtint,ani_sectors,t] * qEP[purpose_xtint,ani_sectors,t]); 

$ENDBLOCK

# ---------------------------------------------------------------------------------------------------------------------
# End of Pipe Abatement technologies
# ---------------------------------------------------------------------------------------------------------------------

$BLOCK B_abatement_ani

  E_rEOPAni_gains[TechAni,ani_sectors,Emmtype,animals,t]$(tx0[t] and sum(emm, d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm])).. 
  	rEOPAni_gains[TechAni,ani_sectors,Emmtype,animals,t] =E= sum(emm$(d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]), thetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm] * (tCO2_emm_ani[emmtype,Ani_sectors,Animals,t]+tech_subsidy_ani[TechAni,emmtype,Ani_sectors,Animals,t]));

  # Unit cost of implementing CCS technology (OBS.: vigtigt, at en teknologi kun virker på én branche - ellers summer man flere investeringspriser her)
  E_rEOPAni_costs[TechAni,ani_sectors,Emmtype,animals,t]$(tx0[t] and sum(emm, d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm])).. 
  	rEOPAni_costs[TechAni,ani_sectors,Emmtype,animals,t] =E= sum(emm$(d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]), thetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm] * pEOPAni[TechAni,Emmtype,ani_sectors,animals,t]);

  # Input for calculating instantaneous adoption rate (assuming normally distributed costs)
  E_rEOPAni_input[TechAni,ani_sectors,Emmtype,animals,t]$(tx0[t] and sum(emm, d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm])).. 
  	rEOPAni_input[TechAni,ani_sectors,Emmtype,animals,t] =E= (sum(emm$(d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]), (rEOPAni_gains[TechAni,ani_sectors,Emmtype,animals,t] - rEOPAni_costs[TechAni,ani_sectors,Emmtype,animals,t])/thetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]) - uEOPAnit[TechAni,ani_sectors,Emmtype,animals,t])/ sigmaEOPAni[techAni];

  # Instantanous technology adoption rate (without forward-looking or sluggsihness)
  E_rEOPAni[TechAni,ani_sectors,Emmtype,animals,t]$(tx0[t] and sum(emm, d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm])).. 
  	rEOPAni[TechAni,ani_sectors,Emmtype,animals,t] =E= (errorf(rEOPAni_input[TechAni,ani_sectors,Emmtype,animals,t]) + j_rEOPAni[TechAni,ani_sectors,Emmtype,animals,t])*aflob[TechAni,ani_sectors,Emmtype,animals,t];

		#Fra trepartsfil
    #  rEOPAni[TechAni,ani_sectors,Emmtype,animals,t] =E= (errorf(rEOPAni_input[TechAni,ani_sectors,Emmtype,animals,t]) + j_rEOPAni[TechAni,ani_sectors,Emmtype,animals,t])*aflob[TechAni,ani_sectors,Emmtype,animals,t];

  # Technology adoption with forward-looking mechanism (if switch_forward_looking = 1)
  E_rEOPani_preferred[TechAni,ani_sectors,Emmtype,animals,t]$(tx0[t] and not tend[t] and sum(emm, d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]))..
  	rEOPani_preferred[TechAni,ani_sectors,Emmtype,animals,t] =E= (1-switch_forward_looking_ani)*rEOPani[TechAni,ani_sectors,Emmtype,animals,t] + switch_forward_looking_ani*( (1-uEOPanibeta)*rEOPani[TechAni,ani_sectors,Emmtype,animals,t]+(uEOPanibeta)*rEOPani_preferred[TechAni,ani_sectors,Emmtype,animals,t+1]);

  # Terminal condition for forward-looking mechanism
  E_rEOPani_preferred_terminal_condition[TechAni,ani_sectors,Emmtype,animals,t]$(tend[t] and sum(emm, d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]))..
  	rEOPani_preferred[TechAni,ani_sectors,Emmtype,animals,tend] =E= rEOPani[TechAni,ani_sectors,Emmtype,animals,tend];

  # Actual technology adoption (with sluggishness, if switch_sluggish = 1)
  E_rEOPani_actual[TechAni,ani_sectors,Emmtype,animals,t]$(tx0[t] and sum(emm, d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]))..
    rEOPani_actual[TechAni,ani_sectors,Emmtype,animals,t] =E= (1-switch_sluggish_ani)*rEOPani_preferred[TechAni,ani_sectors,Emmtype,animals,t]  
      														+ switch_sluggish_ani*( exp(-sqr(rEOPani_preferred[TechAni,ani_sectors,Emmtype,animals,t] - rEOPani_actual[TechAni,ani_sectors,Emmtype,animals,t-1])/rhoEOPani[TechAni])
      														* (rEOPani_preferred[TechAni,ani_sectors,Emmtype,animals,t]) 
      														+ (1-exp(-sqr(rEOPani_preferred[TechAni,ani_sectors,Emmtype,animals,t] - rEOPani_actual[TechAni,ani_sectors,Emmtype,animals,t-1])/rhoEOPani[TechAni])) * rEOPani_actual[TechAni,ani_sectors,Emmtype,animals,t-1]);

  E_uEOPani[Emmtype,ani_sectors,animals,t,emm]$(tx0[t])..
  	uEOPani[Emmtype,ani_sectors,animals,t,emm] =E= 1-sum(TechAni$(d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]), rEOPani_actual[TechAni,ani_sectors,Emmtype,animals,t] * thetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]);

  E_qGrossEmmAni[Emmtype,ani_sectors,animals,t,emm]$(tx0[t] and sum(TechAni,d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]))..
    qGrossEmmAni[Emmtype,ani_sectors,animals,t,emm] =E= qEmmAgrAni[Emmtype,ani_sectors,animals,t,emm]/uEOPani[Emmtype,ani_sectors,animals,t,emm];

  E_qGrossEmmAni_CO2e[Emmtype,ani_sectors,animals,t]$(tx0[t] and sum((TechAni,emm),d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]))..
    qGrossEmmAni[Emmtype,ani_sectors,animals,t,'co2e'] =E= sum(emm$(sum(TechAni,d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm])), qGrossEmmAni[Emmtype,ani_sectors,animals,t,emm]*GWP[emm]);

  E_qEmmAniEOP[Emmtype,ani_sectors,animals,t,emm]$(tx0[t] and sum(TechAni, d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]))..
 	qEmmAniEOP[Emmtype,ani_sectors,animals,t,emm] =E= qEmmAgrAni[Emmtype,ani_sectors,animals,t,emm] - qGrossEmmAni[Emmtype,ani_sectors,animals,t,emm];

  E_qEmmAniEOP_CO2e[Emmtype,ani_sectors,animals,t]$(tx0[t] and sum((TechAni,emm),d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]))..
 	qEmmAniEOP[Emmtype,ani_sectors,animals,t,'CO2e'] =E= qEmmAgrAni[Emmtype,ani_sectors,animals,t,'CO2e'] - qGrossEmmAni[Emmtype,ani_sectors,animals,t,'CO2e'];

## IO DEMAND FROM TECHNOLOGY
	E_vEOPCostAni_IO[TechAni,Emmtype,ani_sectors,s,animals,t]$(tx0[t] and sum(emm, d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]))..
    	vEOPCostAni_IO[TechAni,Emmtype,ani_sectors,s,animals,t] =E= sum(emm$d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm], qGrossEmmAni[Emmtype,ani_sectors,animals,t,'CO2e'] * growth_factor[t] * rEOPani_actual[TechAni,ani_sectors,Emmtype,animals,t] * thetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]
        																													* pEOPAni[TechAni,Emmtype,ani_sectors,animals,t]*10**(3)*10**(-9)*shareAniPrice_group[techani,s,t]*shareAniPrice_type[techani,'IO',t]);

			#Fra trepartsfil - igen udgangspunkt i theta2026 og for bovaer (tech1)
      # vEOPCostAni_IO[TechAni,Emmtype,ani_sectors,s,animals,t] =E= sum(emm$d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm], qGrossEmmAni[Emmtype,ani_sectors,animals,t,'CO2e'] * growth_factor[t] * rEOPani_actual[TechAni,ani_sectors,Emmtype,animals,t] * thetaAni[TechAni,ani_sectors,Emmtype,animals,'2026',emm]
                                                                  # * pEOPAni[TechAni,Emmtype,ani_sectors,animals,t]*10**(3)*10**(-9)*shareAniPrice_group[techani,s,t]*shareAniPrice_type[techani,'IO',t]);

			#Fra trepartsfil - alle andre end Bovaer (tech1)
      # vEOPCostAni_IO[TechAni,Emmtype,ani_sectors,s,animals,t] =E= sum(emm$d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm], qGrossEmmAni[Emmtype,ani_sectors,animals,t,'CO2e'] * growth_factor[t] * rEOPani_actual[TechAni,ani_sectors,Emmtype,animals,t] * thetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]
      #                                                             * pEOPAni_dist[TechAni,Emmtype,ani_sectors,animals,t]*10**(3)*10**(-9)*shareAniPrice_group[techani,s,t]*shareAniPrice_type[techani,'IO',t]); 

  	E_vRxEEOP_ani[ani_sectors,s,t]$(tx0[t] and sum((TechAni,Emmtype,animals,emm),d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]))..
    	vRxEEOP_ani[ani_sectors,s,t] =E= sum((TechAni,emmtype,Animals)$(sum(emm, d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm])), vEOPCostAni_IO[TechAni,Emmtype,ani_sectors,s,animals,t]);

  	E_qRxEEOP_ani[ani_sectors,s,t]$(tx0[t] and sum((TechAni,Emmtype,animals,emm),d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]) and sum((Emmtype,animals),d1vEOPCostAni[Emmtype,ani_sectors,s,animals,t]))..
    	qRxEEOP_ani[ani_sectors,s,t] =E= vRxEEOP_ani[ani_sectors,s,t]/pRxE_y[ani_sectors,s,t];

## CAPITAL DEMAND FROM TECHNOLOGY
 	E_qI_EOPCostAni[TechAni,Emmtype,ani_sectors,animals,t]$(tx0[t] and sum(emm, d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]))..
    	qI_EOPCostAni['iM',TechAni,Emmtype,ani_sectors,animals,t] =E= sum(emm$d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm], qGrossEmmAni[Emmtype,ani_sectors,animals,t,'CO2e'] * growth_factor[t] * rEOPani_actual[TechAni,ani_sectors,Emmtype,animals,t] * thetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm] # Reduction from each technology
  																															* pEOPAni[TechAni,Emmtype,ani_sectors,animals,t]*10**(3)*10**(-9)*shareAniPrice_type[techani,'capital',t]); # Capital cost of reduction

			#Fra Trepartsfil - forskel er 2026 i thetaani - kun på bovaer
      # qI_EOPCostAni['iM',TechAni,Emmtype,ani_sectors,animals,t] =E= sum(emm$d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm], qGrossEmmAni[Emmtype,ani_sectors,animals,t,'CO2e'] * growth_factor[t] * rEOPani_actual[TechAni,ani_sectors,Emmtype,animals,t] * thetaAni[TechAni,ani_sectors,Emmtype,animals,'2026',emm] # Reduction from each technology
      #                                                           * pEOPAni[TechAni,Emmtype,ani_sectors,animals,t]*10**(3)*10**(-9)*shareAniPrice_type[techani,'capital',t]); # Capital cost of reduction

		  #Fra trepartsfil - alt andet end Bovaer (tech1). Det er standard
      # qI_EOPCostAni['iM',TechAni,Emmtype,ani_sectors,animals,t] =E= sum(emm$d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm], qGrossEmmAni[Emmtype,ani_sectors,animals,t,'CO2e'] * growth_factor[t] * rEOPani_actual[TechAni,ani_sectors,Emmtype,animals,t] * thetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm] # Reduction from each technology
      #                                                           * pEOPAni_dist[TechAni,Emmtype,ani_sectors,animals,t]*10**(3)*10**(-9)*shareAniPrice_type[techani,'capital',t]); # Capital cost of reduction

  	# Value of additonal investment demand (levelized)
  	E_vI_EOPCostAni[TechAni,Emmtype,ani_sectors,animals,t]$(tx0[t] and sum(emm, d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]))..
    	vI_EOPCostAni['iM',TechAni,Emmtype,ani_sectors,animals,t] =E= qI_EOPCostAni['iM',TechAni,Emmtype,ani_sectors,animals,t]*pI_s['iM',ani_sectors,t];

    # Spread necessary investments evenly over T_CCS periods preceeding year of capital demand (if front-loading is activated):
    E_qI_EOPCostAni_actual[TechAni,Emmtype,ani_sectors,animals,t]$(tx0[t] and sum(emm, d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]))..
        qI_EOPCostAni_actual['iM',TechAni,Emmtype,ani_sectors,animals,t] =E= qI_EOPCostAni['iM',TechAni,Emmtype,ani_sectors,animals,t];

## SUBSIDIES FOR TECHNOLOGY 
    E_vTech_subsidy_ani[TechAni,Emmtype,ani_sectors,animals,t]$(tx0[t] and d1TechSubsidyani[Techani,Emmtype,ani_sectors,animals,t] and sum(emm,d1Thetaani[TechAni,ani_sectors,Emmtype,animals,t,emm]))..
      vTech_subsidy_ani[TechAni,Emmtype,ani_sectors,animals,t] =E= -tech_subsidy_ani[TechAni,Emmtype,ani_sectors,animals,t] * qEmmaniEOP[Emmtype,ani_sectors,animals,t,'CO2e'] / 10**6;



## TOTAL COST OF TECHNOLOGY (FOR CALCUALTION OF ENDOGENOUS ADOPTION)

  	E_vEOPCostAni_TechTot[TechAni,Emmtype,ani_sectors,animals,t]$(tx0[t] and sum(emm, d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]))..
  		vEOPCostAni_TechTot[TechAni,Emmtype,ani_sectors,animals,t] =E= sum(s$(sum(emm, d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm])), 
  																																			vEOPCostAni_IO[TechAni,Emmtype,ani_sectors,s,animals,t])
  																																		  + vI_EOPCostAni['iM',TechAni,Emmtype,ani_sectors,animals,t]
  																																	;

  	E_vEOPcost_ani_tot[ani_sectors,t]$(tx0[t] and sum((TechAni,Emmtype,animals,emm),d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]))..
    	vEOPcost_ani_tot[ani_sectors,t] =E= sum((TechAni,emmtype,s,Animals)$(sum(emm, d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm])), vEOPCostAni_IO[TechAni,Emmtype,ani_sectors,s,animals,t])
    																+ sum((TechAni,Emmtype,animals)$(sum(emm, d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm])), vI_EOPCostAni['iM',TechAni,Emmtype,ani_sectors,animals,t]);

$ENDBLOCK

# ---------------------------------------------------------------------------------------------------------------------
# Variables for reporting
# ---------------------------------------------------------------------------------------------------------------------

$BLOCK B_report_agr_ani

# Dækningsbidrag II for Ani_sectors
    E_DBII_ani[Ani_sectors,t]$(tx0[t])..
		vDBII_ani[ani_sectors,t] =E= qAni_CET[ani_sectors,'out_other',t]*pAni_CET[ani_sectors,'out_other',t] # Produktionsværdien af market og non-market goods
								   + sum(animals$(sum(emm,d1EmmAgrAni['ManureManagement',ani_sectors,Animals,t,emm]) and d1Ani[ani_sectors,Animals,t]), pD_manure[t] * uManurePerAnimal[ani_sectors,animals,t]*qAni[ani_sectors,animals,t]) # Værdi af husdyrgødning 
								 								- sum(Ani_$(sameas[Ani_,'Other'] and d1Ani[ani_sectors,Ani_,t]), pAni[Ani_sectors,Ani_,t]*qAni[Ani_sectors,Ani_,t]) # Materialeinputs
								 								- sum(Ani_$((sameas[Ani_,'CompoundFeed'] or sameas[Ani_,'CoarseFeed'] or sameas[Ani_,'Litter']) and d1Ani[ani_sectors,Ani_,t]), pAni[Ani_sectors,Ani_,t]*qAni[Ani_sectors,Ani_,t]) # Foder og strøelse
								 								- (sum(Ani_$((sameas[Ani_,'Fuel'] or sameas[Ani_,'OtherEnergy']) and d1Ani[ani_sectors,Ani_,t]), pAni[Ani_sectors,Ani_,t]*qAni[Ani_sectors,Ani_,t]) # Energiforbrug inkl. energiafgifter
								 								- sum((purpose,energy19), vtEAFG_RE[purpose,energy19,Ani_sectors,t]$d1EAFG_RE[purpose,energy19,Ani_sectors,t])) # Energiafgifter
								 								- sum(Ani_$(sameas[Ani_,'MachinesRent'] and d1Ani[ani_sectors,Ani_,t]), pAni[Ani_sectors,Ani_,t]*qAni[Ani_sectors,Ani_,t]) # Maskinstation
								 								- sum(Ani_$(sameas[Ani_,'Labor'] and d1Ani[ani_sectors,Ani_,t]), pAni[Ani_sectors,Ani_,t]*qAni[Ani_sectors,Ani_,t]) # Arbejdskraft
								 								- sum((emmtype,animals)$(d1EmmAgrAni[emmtype,ani_sectors,Animals,t,'CO2e'] and not sameas[emmtype,'N2Oindirect'] and not sameas(emmtype,"grazinganimals")), vCO2_ani[Emmtype,ani_sectors,animals,t]) # Værdien af CO2e-afgifter
								 								- sum((TechAni,Emmtype,Animals)$(sum(emm, d1ThetaAni[TechAni,Ani_sectors,Emmtype,Animals,t,emm])), vEOPCostAni_TechTot[TechAni,Emmtype,ani_sectors,Animals,t])
								 								+ sum((TechAni,Emmtype,Animals)$(sum(emm, d1ThetaAni[TechAni,Ani_sectors,Emmtype,Animals,t,emm])), vTech_subsidy_ani[TechAni,Emmtype,ani_sectors,Animals,t])
								 ;


# Mekanisk prisstigning sfa. CO2e-afgift på landbrugets ikke-energirelaterede udledninger
	E_pAni_mekanisk[ani_sectors,t]$(tx0[t])..
		pAni_mekanisk[ani_sectors,t] 		=E= sum((Animals,emmtype)$(d1EmmAgrAni[emmtype,ani_sectors,Animals,t,'CO2e']), tCO2_emm_ani[emmtype,Ani_sectors,Animals,t] * (qEmmAgrAni_baseline[emmtype,ani_sectors,Animals,t,'co2e']*growth_factor[t]) / 10**6)
												/ (pAni_CET_baseline[ani_sectors,'out_other',t]*qAni_CET_baseline[ani_sectors,'out_other',t]) ;

# Emissioner summeret over emmtype
	E_EmmPerAnimal[ani_sectors,t]$(tx0[t] and d1EmmAgrxE['emmtype_sum',ani_sectors,t,'CO2e'])..
		EmmPerAnimal[ani_sectors,t] =E= qEmmAgrxE['emmtype_sum',ani_sectors,t,'CO2e']/sum(animals$d1Ani[ani_sectors,animals,t], qAni[ani_sectors,animals,t]);

# BVT i landbrug inkl. non-market 
	E_vY_agr_market_ani[ani_sectors,t]$(tx0[t])..
		vY_agr_market[ani_sectors,t] 	=E= qAni_CET[ani_sectors,'out_other',t]*pAni_CET[ani_sectors,'out_other',t];

	E_vAni[ani_sectors,ani_,t]$(tx0[t] and d1Ani[ani_sectors,ani_,t])..
		vAni[ani_sectors,ani_,t] 		=E= pAni[ani_sectors,ani_,t] * qAni[ani_sectors,ani_,t];

	E_vInput_agr_market_ani[ani_sectors,t]$(tx0[t])..
		vInput_agr_market[ani_sectors,t] =E= vAni[ani_sectors,'other',t]$(d1Ani[ani_sectors,'other',t])
										   + vAni[ani_sectors,'fuel',t]$(d1Ani[ani_sectors,'fuel',t])
										   + vAni[ani_sectors,'MachinesRent',t]$(d1Ani[ani_sectors,'MachinesRent',t])
										   + vAni[ani_sectors,'OtherEnergy',t]$(d1Ani[ani_sectors,'OtherEnergy',t])
										   # Account for marginal vs. average energy prices
										   + sum((purpose,energy19)$(d1pRE_base[purpose,energy19,ani_sectors,t]),(pRE_base[purpose,energy19,ani_sectors,t]-pRE_base_marg[purpose,energy19,ani_sectors,t])*qREgj[purpose,energy19,ani_sectors,t])			
										   + sum((purpose,energy19)$(d1pREown[purpose,energy19,ani_sectors,t]), - qREa[purpose,energy19,Ani_sectors,t]*pREa[purpose,energy19,Ani_sectors,t]
										   																		+ (tqRE[purpose,energy19,ani_sectors,t]*qREa[purpose,energy19,ani_sectors,t])) # fratræk værdien af egen produktion af energihalm
										   + vAni[ani_sectors,'CompoundFeed',t]$(d1Ani[ani_sectors,'CompoundFeed',t])
										   # Deduct marginal taxes and add average
										   + sum((purpose,energy19a), d1tREmarg[ani_sectors]*
                                                (+vtEAFG_RE[purpose,energy19a,ani_sectors,t]$d1EAFG_RE[purpose,energy19a,ani_sectors,t] 
                                                 -vtEAFG_REmarg[purpose,energy19a,ani_sectors,t]$d1EAFG_RE[purpose,energy19a,ani_sectors,t]
                                                 +vtCO2_RE[purpose,energy19a,ani_sectors,t]$d1CO2_RE[purpose,energy19a,ani_sectors,t]
                                                 -vtCO2_REmarg[purpose,energy19a,ani_sectors,t]$d1CO2_RE[purpose,energy19a,ani_sectors,t]
                                                 -vtCO2_ETS_marg[energy19a,ani_sectors,t]$(d1EmmProdE[ani_sectors,t,'CO2e',purpose,energy19a] and d1CO2_ETS[ani_sectors,t] and sameas[purpose,'in_ETS'])));

	# Non-market
	E_vY_agr_nm_ani[ani_sectors,t]$(tx0[t])..
		vY_agr_nm[ani_sectors,t] =E= -qAni[ani_sectors,'AnimalsAgg',t]*pAni[ani_sectors,'AnimalsAgg',t];			½

	E_vInput_agr_nm_ani[ani_sectors,t]$(tx0[t])..
		vInput_agr_nm[ani_sectors,t] =E= vAni[ani_sectors,'Litter',t]$(d1Ani[ani_sectors,'Litter',t])
									     + vAni[ani_sectors,'CoarseFeed',t]$(d1Ani[ani_sectors,'CoarseFeed',t])
									     + sum((purpose,energy19)$(d1pREown[purpose,energy19,ani_sectors,t]), qREa[purpose,energy19,ani_sectors,t]*pREa[purpose,energy19,ani_sectors,t]
										   																   - (tqRE[purpose,energy19,ani_sectors,t]*qREa[purpose,energy19,ani_sectors,t]));									   ;

	E_vBVT_agr_cpntns_subsidies[ani_sectors,t]$(tx0[t])..
		vBVT_agr_cpntns[ani_sectors,'netProdSubsidies',t] =E= vtNetproductionRest[ani_sectors,t]
															 + vtCAP_top[ani_sectors,t]				# CAP-subsidies from the EU that enter the top of the production function
															 + vtL[ani_sectors,t] 					# Taxes/Subsidies on labour
															 + vtLand[ani_sectors,t]				# Taxes/Subsidies on land/buildings
															 + vtFirmsWeight[ani_sectors,t]			# Vægtafgifter
															 + vtCO2_ETS[ani_sectors,t];			# ETS quotas

	E_vBVT_agr_cpntns_wage_ani[ani_sectors,t]$(tx0[t] and d1Ani[ani_sectors,'Labor',t])..
		vBVT_agr_cpntns[ani_sectors,'Wage',t]	=E= qAni[ani_sectors,'Labor',t]*pAni[ani_sectors,'Labor',t]
													- vtL[ani_sectors,t];

	E_vBVT_agr_cpntns_markup_ani[ani_sectors,t]$(tx0[t])..
		vBVT_agr_cpntns[ani_sectors,'Profit',t] 	=E= sum(Ani_out_top, pAni_CET[Ani_sectors,Ani_out_top,t]*qAni_CET[Ani_sectors,Ani_out_top,t] 
																   - pAni_CET0[Ani_sectors,Ani_out_top,t]*qAni_CET[Ani_sectors,Ani_out_top,t]);

	E_vBVT_agr_cpntns_machine_ani[ani_sectors,t]$(tx0[t])..
		vBVT_agr_cpntns[ani_sectors,'MachineCapital',t] 	=E= qAni[ani_sectors,'MachinesPrivate',t]*pAni[ani_sectors,'MachinesPrivate',t]
																- vtFirmsWeight[ani_sectors,t];

	E_vBVT_agr_cpntns_building_ani[ani_sectors,t]$(tx0[t])..
		vBVT_agr_cpntns[ani_sectors,'BuildingCapital',t] 	=E= qAni[ani_sectors,'Buildings',t]*pAni[ani_sectors,'Buildings',t]
														     	- vtLand[ani_sectors,t];

	#Disaggregerede husdyr. Det bliver lidt møjsommeligt, fordi det er lavet over ani_sectors_
	E_qAni_dis[husdyrtype,ani_sectors,animals,t]$(tx0[t] and qAni_dis.l[husdyrtype,ani_sectors,animals,t]).. 
		qAni_dis[husdyrtype,ani_sectors,animals,t] =E= uAni_dis[husdyrtype,ani_sectors,animals,t] * qAni[ani_sectors,animals,t];

	E_qAni_dis_tot_a[husdyrtype,animals,t]$(tx0[t] and qAni_dis_tot.l[husdyrtype,animals,t] and sum(ani_sectors, qAni_dis.l[husdyrtype,ani_sectors,animals,t]))..
		qAni_dis_tot[husdyrtype,animals,t] =E= sum(ani_sectors$qAni_dis.l[husdyrtype,ani_sectors,animals,t], qAni_dis[husdyrtype,ani_sectors,animals,t]);

	E_qAni_dis_tot_b[husdyrtype,animals,t]$(tx0[t] and qAni_dis_tot.l[husdyrtype,animals,t] and not sum(ani_sectors, qAni_dis.l[husdyrtype,ani_sectors,animals,t]) and not sameas[husdyrtype,'Eksport af smaagrise'])..
		qAni_dis_tot[husdyrtype,animals,t] =E= uAni_dis_tot[husdyrtype,animals,t] * sum(ani_sectors$d1Ani[ani_sectors,animals,t], qAni[ani_sectors,animals,t]);

	E_qAni_dis_tot_smaagrise[t]$(tx0[t])..
		qAni_dis_tot['Eksport af smaagrise','Piglets',t] =E= uAni_dis_tot['Eksport af smaagrise','Piglets',t] * qX_y['xOth','01051',t]/qAni_CET['01051','out_other',t] * qAni_dis_tot['Producerede smaagrise','Piglets',t];

	E_qAni_dis_rep[husdyrtype,ani_sectors_,animals,t]$(tx0[t] and KF_qAni_dis[husdyrtype,ani_sectors_,animals,t] and sum(ani_sectors, anisectors2anisectors_(ani_sectors,ani_sectors_)))..
		qAni_dis_rep[husdyrtype,ani_sectors_,animals,t] =E= sum(ani_sectors$(anisectors2anisectors_(ani_sectors,ani_sectors_) and qAni_dis.l[husdyrtype,ani_sectors,animals,t]), qAni_dis[husdyrtype,ani_sectors,animals,t]);

	E_qAni_dis_rep_tot[husdyrtype,animals,t]$(tx0[t] and KF_qAni_dis[husdyrtype,'tot',animals,t])..
		qAni_dis_rep[husdyrtype,'tot',animals,t] =E= qAni_dis_tot[husdyrtype,animals,t];

$ENDBLOCK

$MODEL M_production_agr_ani
	B_production_agr_ani
	B_LINK_ani
	B_emissions_agr_ani
	B_abatement_ani
	B_CO2taxOnAni
	B_botdedperanimal
;
	
$ENDIF


# ======================================================================================================================
# Exogenous variables and data assignment
# ======================================================================================================================

$IF %stage% == "read_data":

#1) READ DATA 
	
	# From CGE-model
		# ANI 
		pAni_CET.l[Ani_sectors,ani_out_top,t]			 = sum(out$out2ani_out(out,Ani_out_top), IO_pY_CET[out,ani_sectors,t]);
		qAni_CET.l[Ani_sectors,ani_out_top,t]			 = sum(out$out2ani_out(out,Ani_out_top), IO_qY_CET[out,ani_sectors,t]);
		qAni_CET.l[Ani_sectors,'netprod',t]  			 = IO_qY[ani_sectors,t];
		pYANI.l[ani_sectors,t]                           = IO_pY[ani_sectors,t];
		qAni.l[Ani_sectors,'grossprod',t] 				 = IO_qY[Ani_sectors,t]; 

		pAni.l[Ani_sectors,'Labor',t] 					 = IO_pL[Ani_sectors,t];			
		qAni.l[Ani_sectors,'Labor',t] 					 = IO_qL[Ani_sectors,t];

		pAni.l[Ani_sectors,'Fuel',tData]                 = 1;
		pAni.l[Ani_sectors,'FinancialServiceM',t]        = IO_pFin_k['iM',Ani_sectors,t];
		pAni.l[Ani_sectors,'FinancialServiceB',t]        = IO_pFin_k['iB',Ani_sectors,t];
		pAni.l[Ani_sectors,'FinancialServiceT',t]        = IO_pFin_k['iT',Ani_sectors,t];

		#AKB
		qAni.l[Ani_sectors,'other',t] 				   	 = IO_qRxE[Ani_sectors,t];
		qAni.l[Ani_sectors,'FinancialServiceM',t]        = IO_qFin_k['iM',Ani_sectors,t];
		qAni.l[Ani_sectors,'FinancialServiceB',t]        = IO_qFin_k['iB',Ani_sectors,t];
		qAni.l[Ani_sectors,'FinancialServiceT',t]        = IO_qFin_k['iT',Ani_sectors,t];

		qRxE_ym_ani.l[Ani_sectors,s,t]					 = IO_qRxE_ym[Ani_sectors,s,t];
		pRxE_ym_ani.l[Ani_sectors,s,t]					 = IO_pRxE_ym[Ani_sectors,s,t];

		# ANI 
		qAni.l[Ani_sectors,'Fuel',t] 		= sum((energy19), EN_vnRE['intern_trans',energy19,Ani_sectors,t] 
													+ EN_vCO2_RE['intern_trans',energy19,Ani_sectors,t] 
													+ EN_vSO2_RE['intern_trans',energy19,Ani_sectors,t] 
													+ EN_vPSO_RE['intern_trans',energy19,Ani_sectors,t]
													+ EN_vNOx_RE['intern_trans',energy19,Ani_sectors,t]
													+ EN_vEAFG_RE['intern_trans',energy19,Ani_sectors,t] 
													+ EN_vMOMS_RE['intern_trans',energy19,Ani_sectors,t]);

		tCO2_ETS.l[t]  = KF25_pETS[t]; 
		qAni.l[Ani_sectors,'OtherEnergy',t] = sum((energy19,purpose_xtint), EN_vnRE[purpose_xtint,energy19,Ani_sectors,t] 
														    		   + EN_vCO2_RE[purpose_xtint,energy19,Ani_sectors,t] 
														    		   + EN_vSO2_RE[purpose_xtint,energy19,Ani_sectors,t] 
														    		   + EN_vPSO_RE[purpose_xtint,energy19,Ani_sectors,t]
														    		   + EN_vNOx_RE[purpose_xtint,energy19,Ani_sectors,t]
														    		   + EN_vEAFG_RE[purpose_xtint,energy19,Ani_sectors,t] 
														    		   + EN_vMOMS_RE[purpose_xtint,energy19,Ani_sectors,t]
														    		   + tCO2_ETS.l[t]/10**6*EM_RE['CO2ubio',purpose_xtint,energy19,Ani_sectors,t]$(sameas[purpose_xtint,'in_ETS']));

	#CO2-tax on non-energy related emissions
	reguleringsgrundlag_ani[emmtype] = no;
	reguleringsgrundlag_ani['EntericFermentation'] = yes;
	reguleringsgrundlag_ani['ManureManagement']    = yes;

	tCO2_emm_ani.l[emmtype,Ani_sectors,Animals,'2030']$(reguleringsgrundlag_ani[emmtype]) = 340.6*KF25_deflator['2025']; #/(fp**(2025-2019));
	tCO2_emm_ani.l[emmtype,Ani_sectors,Animals,'2031']$(reguleringsgrundlag_ani[emmtype]) = 440.6*KF25_deflator['2025']; #/(fp**(2025-2019));
	tCO2_emm_ani.l[emmtype,Ani_sectors,Animals,'2032']$(reguleringsgrundlag_ani[emmtype]) = 540.6*KF25_deflator['2025']; #/(fp**(2025-2019));
	tCO2_emm_ani.l[emmtype,Ani_sectors,Animals,'2033']$(reguleringsgrundlag_ani[emmtype]) = 640.6*KF25_deflator['2025']; #/(fp**(2025-2019));
	tCO2_emm_ani.l[emmtype,Ani_sectors,Animals,'2034']$(reguleringsgrundlag_ani[emmtype]) = 740.6*KF25_deflator['2025']; #/(fp**(2025-2019));
	tCO2_emm_ani.l[emmtype,Ani_sectors,Animals,'2035']$(reguleringsgrundlag_ani[emmtype]) = 851.6*KF25_deflator['2025']; #/(fp**(2025-2019));
	tCO2_emm_ani.l[emmtype,Ani_sectors,Animals,t]$(reguleringsgrundlag_ani[emmtype] and t.val>2035) =tCO2_emm_ani.l[emmtype,Ani_sectors,Animals,'2035'];

	#Bottom deduction on CO2-tax
	pBotdedPerAnimal.l[emmtype,ani_sectors,animals,t,emm_eq] = pBotdedPerAnimal_data[emmtype,ani_sectors,animals,t,emm_eq];

	#Reading disaggregated animals for reporting
	qAni_dis.l[husdyrtype,ani_sectors,animals,t] = sum(ani_sectors_$anisectors2anisectors_(ani_sectors,ani_sectors_), KF_qAni_dis[husdyrtype,ani_sectors_,animals,t]);
	qAni_dis_tot.l[husdyrtype,animals,t] = KF_qAni_dis[husdyrtype,'tot',animals,t];
$ENDIF

$IF %stage% == "exogenous_values":

#1) READ DATA 

	qAni_capital.l[Ani_sectors,'MachinesPrivate',t] 	   = qK.l['im',Ani_sectors,t-1]; 
	qAni_capital.l[Ani_sectors,'Buildings',t] 			  	 = qK.l['ib',Ani_sectors,t-1];
	qAni_capital.l[Ani_sectors,'TransportCapital',t] 		 = qK.l['it',Ani_sectors,t-1]; 		

	qAni.l[Ani_sectors,'MachinesPrivate',t] 	   = qK.l['im',Ani_sectors,t-1]; 
	qAni.l[Ani_sectors,'Buildings',t] 			  	 = qK.l['ib',Ani_sectors,t-1];
	qAni.l[Ani_sectors,'TransportCapital',t] 		 = qK.l['it',Ani_sectors,t-1]; 		
 
	pAni_uc.l[Ani_sectors,'MachinesPrivate',t] 		 = pK.l['im',Ani_sectors,t];
	pAni_uc.l[Ani_sectors,'Buildings',t] 			   	 = pK.l['ib',Ani_sectors,t] ;	
	pAni_uc.l[Ani_sectors,'TransportCapital',t] 		 = pK.l['it',Ani_sectors,t];

	pAni.l[Ani_sectors,'MachinesPrivate',t] 		 = pK.l['im',Ani_sectors,t];
	pAni.l[Ani_sectors,'Buildings',t] 			   	 = pK.l['ib',Ani_sectors,t] ;	
	pAni.l[Ani_sectors,'TransportCapital',t] 		 = pK.l['it',Ani_sectors,t];



#2) EXOGENOUS VALUES 
	
	# Production Elasticities:
		# ANI 
		eAni.fx[Ani_sectors,'grossprod',t]			= 0; 	# 
		eAni.fx[Ani_sectors,'KELBani',t]	 	    = 0.04; # 
		eAni.fx[Ani_sectors,'KELani',t]		  		= 0.48; # 
		eAni.fx[Ani_sectors,'Machines',t]	  		= 0.58; #
		eAni.fx[Ani_sectors,'PF',t]			      	= 0.1;  # Substitution between machines and fuel. 
		eAni.fx[Ani_sectors,'PFF',t]    		  	= 0;	# Substitution between private machines and financial service for machine capital (Leontief) 
		eAni.fx[Ani_sectors,'BELHA',t]      		= 0;
		eAni.fx[Ani_sectors,'BE',t]			      	= 0.1; 	# eBE and eBAML are set to zero because buildings, manure, litter and the energy used on buildings come in fixed proportions. 
		eAni.fx[Ani_sectors,'BF',t]         		= 0;  # Substitution between buildings capital and financial service for buildings capital (Leontief) 
		eAni.fx[Ani_sectors,'BAML',t]       		= 0; 	#
		eAni.fx[Ani_sectors,'AnimalsAgg',t] 		= 0; 	#
		eAni.fx[Ani_sectors,'AnimalFood',t] 		= 0.5; 	# 
		eAni.fx[Ani_sectors,'other',t]		 	  	= eRxE.l[Ani_sectors]; 

		eCET_ani.l[Ani_sectors,'netprod'] 			= 0;

	# Other production related exo-values 
		TFPAni.l[ani_sectors,t]$(tData[t])     		= 1;

		thetaA.l[Ani_sectors,Animals,tData] 		= 1;

#3) COMPUTATIONS (residual data treatment that could be considered moved to actual data-reading in Python etc.)

	# Inf- and growth-adjustment of production prices and quantities
		KF_qAni[ani_sectors,t]     = KF_qAni[ani_sectors,t] * growth_factor[t];
		KF_pAni[ani_sectors,t]     = KF_pAni[ani_sectors,t] * inf_factor[t];

	# NON-MARKET
		qRxE_nm.l[agri_sectors,agri_sectorss,'manure',t]     = qRxE_nm.l[agri_sectors,agri_sectorss,'manure',t]*20/3*5.29499/5.80652; # £AKB(3): Sætter manureværdi til x20 
		qRxE_nm.l[Ani_sectors,Ani_sectors,'Manure',t] 		 = sum(agri_sectors, qRxE_nm.l[Agri_sectors,Ani_sectors,'manure',t]); 
		qRxE_nm.l[Agri_sectors,Agri_sectorss,'manure',t]     = qRxE_nm.l[Agri_sectors,agri_sectorss,'manure',t]/10**9;
		qRxE_nm.l[Agri_sectors,Agri_sectorss,'litter',t]     = qRxE_nm.l[Agri_sectors,Agri_sectorss,'litter',t]/10**9; 
		qRxE_nm.l[Agri_sectors,Agri_sectorss,'coarsefeed',t] = qRxE_nm.l[Agri_sectors,Agri_sectorss,'coarsefeed',t]/10**9; 

		# Litter 
		qAni.l[ani_sectors,'litter',t] = sum(plant_sectors, qRxE_nm.l[ani_sectors,plant_sectors,'litter',t]);

	# ANI PRODUCTION 
		## DYR

		# Reading animals to model variables
		qAni.l[Ani_sectors,Animals,t] 			   = KF_animals[Ani_sectors,Animals,t];
		qAni.l[Ani_sectors,Animals,t]$(t.val>2050) = qAni.l[Ani_sectors,Animals,'2050'];

		qAni.l[Ani_sectors,'AnimalsAgg',t] = sum(Animals,qAni.l[Ani_sectors,Animals,t]);

		uAni_dis.l[husdyrtype,ani_sectors,animals,t]$(qAni.l[ani_sectors,animals,t]) 
			= qAni_dis.l[husdyrtype,ani_sectors,animals,t]/qAni.l[ani_sectors,animals,t];

		uAni_dis_tot.l[husdyrtype,animals,t]$(sum(ani_sectors, qAni.l[ani_sectors,animals,t]))
			= qAni_dis_tot.l[husdyrtype,animals,t]/sum(ani_sectors, qAni.l[ani_sectors,animals,t]);

		uAni_dis.l[husdyrtype,ani_sectors,animals,t]$(t.val>2050) = uAni_dis.l[husdyrtype,ani_sectors,animals,'2050'];
		uAni_dis_tot.l[husdyrtype,animals,t]$(t.val>2050) = uAni_dis_tot.l[husdyrtype,animals,'2050'];

		#Hack for missing animals in DCE
		qAni_dis.l['ammekoeer','01032','CowsDairy',t] = qAni_dis.l['ammekoeer','01032','CowsOther',t]; 
		uAni_dis.l['ammekoeer','01032','CowsDairy',t] = uAni_dis.l['ammekoeer','01032','CowsOther',t]; 
		qAni_dis.l['ammekoeer','01032','CowsOther',t] = 0;
		qAni_dis.l['ungkvaeg i alt','01032','CowsDairy',t] = qAni_dis.l['ungkvaeg i alt','01032','CowsOther',t]; 
		uAni_dis.l['ungkvaeg i alt','01032','CowsDairy',t] = uAni_dis.l['ungkvaeg i alt','01032','CowsOther',t]; 
		qAni_dis.l['ungkvaeg i alt','01032','CowsOther',t] = 0;


		## MANURE QUANTITIES
		# Omregner til mio. t 
		KF_NabDyrViaLager[Ani_sectors,Animals,t] = KF_NabDyrViaLager[Ani_sectors,Animals,t]/10**6; 
		KF_NabDyrViaLager_OtherAnimals[t]        = KF_NabDyrViaLager_OtherAnimals[t]/10**6;

		# Moving manure from poultry to 'OtherAnimals'
		KF_NabDyrViaLager_OtherAnimals[t]        		 = KF_NabDyrViaLager_OtherAnimals[t] + KF_NabDyrViaLager['01061','Poultry',t]; KF_NabDyrViaLager['01061','Poultry',t] = 0;
		KF_NabDyrViaLager_OtherAnimals[t]$(t.val > 2050) = KF_NabDyrViaLager_OtherAnimals['2050'];



		# For pigs the manure production follow number of animals as there is a weird jump in manure from organic pigs between 2023 and 2024 in data (could be handled differently)
		# parameter totNabdyrsvin2019[animals];
		# totNabdyrsvin2019[animals]  = KF_NabDyrViaLager['01051',animals,'2019'] + KF_NabDyrViaLager['01052',animals,'2019'];
		# KF_NabDyrViaLager['01052',animals,t]$(KF_animals['01051',Animals,t] + KF_animals['01052',Animals,t]) = KF_animals['01052',Animals,t]/(KF_animals['01051',Animals,t] + KF_animals['01052',Animals,t]) * totNabdyrsvin2019[animals];
		# KF_NabDyrViaLager['01051',animals,t] = totNabdyrsvin2019[animals] - KF_NabDyrViaLager['01052',animals,t];

		# Read manure production to model variables
		qNManureOtherAnimals.l[t]         = KF_NabDyrViaLager_OtherAnimals[t];
		qNManure.l[ani_sectors,animals,t] = KF_NabDyrViaLager[Ani_sectors,Animals,t];

		# Manure production factor
		uManurePerAnimal.l[ani_sectors,animals,t]$(qAni.l[Ani_sectors,Animals,t]) = qNManure.l[ani_sectors,animals,t]/qAni.l[Ani_sectors,Animals,t];

		## EMISSIONS

		# For now we are keeping poultry out of  manure market (since they don't really matter in terms of size anyway. Their small size makes the model hard to solve)
		# To keep track of all emissions still, we re-assign manure management emissions from poultry to enteric fermentation
		qEmmAgrAni.l[emmtype,aniXpoultry,Animals,t,emm] 				= qAni.l[aniXpoultry,Animals,t] * KF_uEmmAgrAnimals[emmtype,Animals,aniXpoultry,t,emm];
		qEmmAgrAni.l['EntericFermentation',aniPoultry,Animals,t,emm] 	= qAni.l[aniPoultry,Animals,t] * KF_uEmmAgrAnimals['EntericFermentation',Animals,aniPoultry,t,emm] + qAni.l[aniPoultry,Animals,t] * KF_uEmmAgrAnimals['ManureManagement',Animals,aniPoultry,t,emm];

		qEmmAgrAni.l['GrazingAnimals','01031',Animals,t,emm]$((KF_animals['01031',Animals,t1] + KF_animals['01032',Animals,t1]) and KF_landemissions['GrazingAnimals',emm,t]) 
															            = 1/10*KF_animals['01031',Animals,t1]/sum(Animals_a, 1/10*KF_animals['01031',Animals_a,t1] + KF_animals['01032',Animals_a,t1]) * KF_landemissions['GrazingAnimals',emm,t]*1000/GWP.l[emm];
		qEmmAgrAni.l['GrazingAnimals','01032',Animals,t,emm]$((KF_animals['01031',Animals,t1] + KF_animals['01032',Animals,t1]) and KF_landemissions['GrazingAnimals',emm,t]) 
															            = KF_animals['01032',Animals,t1]/sum(Animals_a, 1/10*KF_animals['01031',Animals_a,t1] + KF_animals['01032',Animals_a,t1]) * KF_landemissions['GrazingAnimals',emm,t]*1000/GWP.l[emm];

		# ENS has given the formula for converting NH3 and NOx to indirect N2O-emissions
		qEmmAgrAni.l['N2Oindirect',ani_sectors,Animals,t,'N2O'] = (KF_IndN2O_NH3[ani_sectors,animals,t]+KF_IndN2O_NOx[Ani_sectors,animals,t])*0.01*(44/28)/1000;

		# The distribution of indirect N2O-emissions for CowsDairy follow the distribution of animals from before 2022
		qEmmAgrAni.l['N2Oindirect','01032','CowsDairy',t,'N2O']$(t.val<2022 and (KF_animals['01031','CowsDairy',t] + KF_animals['01032','CowsDairy',t])) = KF_animals['01032','CowsDairy',t]/(KF_animals['01031','CowsDairy',t]  + KF_animals['01032','CowsDairy',t]) * sum(ani_sectors$(sameas[ani_sectors,'01031'] or sameas[ani_sectors,'01032']), KF_IndN2O_NH3[ani_sectors,'CowsDairy',t]+KF_IndN2O_NOx[Ani_sectors,'CowsDairy',t])*0.01*(44/28)/1000;
		qEmmAgrAni.l['N2Oindirect','01031','CowsDairy',t,'N2O']$(t.val<2022 and (KF_animals['01031','CowsDairy',t] + KF_animals['01032','CowsDairy',t])) = sum(ani_sectors$(sameas[ani_sectors,'01031'] or sameas[ani_sectors,'01032']), KF_IndN2O_NH3[ani_sectors,'CowsDairy',t]+KF_IndN2O_NOx[Ani_sectors,'CowsDairy',t])*0.01*(44/28)/1000 - qEmmAgrAni.l['N2Oindirect','01032','CowsDairy',t,'N2O'];

		# The distribution of indirect N2O-emissions follow the distribution of animals
		qEmmAgrAni.l['N2Oindirect','01032','CowsOther',t,'N2O']$(KF_animals['01031','CowsOther',t] + KF_animals['01032','CowsOther',t]) = KF_animals['01032','CowsOther',t]/(KF_animals['01031','CowsOther',t]  + KF_animals['01032','CowsOther',t]) * sum(ani_sectors$(sameas[ani_sectors,'01031'] or sameas[ani_sectors,'01032']), KF_IndN2O_NH3[ani_sectors,'CowsOther',t]+KF_IndN2O_NOx[Ani_sectors,'CowsOther',t])*0.01*(44/28)/1000;
		qEmmAgrAni.l['N2Oindirect','01031','CowsOther',t,'N2O']$(KF_animals['01031','CowsOther',t] + KF_animals['01032','CowsOther',t]) = sum(ani_sectors$(sameas[ani_sectors,'01031'] or sameas[ani_sectors,'01032']), KF_IndN2O_NH3[ani_sectors,'CowsOther',t]+KF_IndN2O_NOx[Ani_sectors,'CowsOther',t])*0.01*(44/28)/1000 - qEmmAgrAni.l['N2Oindirect','01032','CowsOther',t,'N2O'];

		# The distribution of indirect N2O-emissions follow the distrbution of animals
		qEmmAgrAni.l['N2Oindirect','01052',animals,t,'N2O']$(KF_animals['01051',Animals,t] + KF_animals['01052',Animals,t]) = KF_animals['01052',animals,t]/(KF_animals['01051',animals,t]  + KF_animals['01052',animals,t]) * sum(ani_sectors$(sameas[ani_sectors,'01051'] or sameas[ani_sectors,'01052']), KF_IndN2O_NH3[ani_sectors,animals,t]+KF_IndN2O_NOx[Ani_sectors,animals,t])*0.01*(44/28)/1000;
		qEmmAgrAni.l['N2Oindirect','01051',animals,t,'N2O']$(KF_animals['01051',Animals,t] + KF_animals['01052',Animals,t]) = sum(ani_sectors$(sameas[ani_sectors,'01051'] or sameas[ani_sectors,'01052']), KF_IndN2O_NH3[ani_sectors,animals,t]+KF_IndN2O_NOx[Ani_sectors,animals,t])*0.01*(44/28)/1000 - qEmmAgrAni.l['N2Oindirect','01052',animals,t,'N2O'];

		# The distribution of indirect N2O-emissions follow the distrbution of animals
		qEmmAgrAni.l['N2Oindirect','01062',animals,t,'N2O']$(KF_animals['01061',Animals,t] + KF_animals['01062',Animals,t]) = KF_animals['01062',animals,t]/(KF_animals['01061',animals,t]  + KF_animals['01062',animals,t]) * sum(ani_sectors$(sameas[ani_sectors,'01061'] or sameas[ani_sectors,'01062']), KF_IndN2O_NH3[ani_sectors,animals,t]+KF_IndN2O_NOx[Ani_sectors,animals,t])*0.01*(44/28)/1000;
		qEmmAgrAni.l['N2Oindirect','01061',animals,t,'N2O']$(KF_animals['01061',Animals,t] + KF_animals['01062',Animals,t]) = sum(ani_sectors$(sameas[ani_sectors,'01061'] or sameas[ani_sectors,'01062']), KF_IndN2O_NH3[ani_sectors,animals,t]+KF_IndN2O_NOx[Ani_sectors,animals,t])*0.01*(44/28)/1000 - qEmmAgrAni.l['N2Oindirect','01062',animals,t,'N2O'];

	# 	Emissions from other animals (not linked to production)
		qEmmAgrAnimalsOther.l[emmtype,t,emm] 				= KF_qEmmAgrAnimalsOther[emmtype,t,emm];
		qEmmAgrAnimalsOther.l['N2Oindirect',t,'N2O'] 		= (KF_IndN2O_NH3_OtherAnimals[t]+KF_IndN2O_NOx_OtherAnimals[t])*0.01*(44/28)/1000;
		#For Mink sættes udledningerne til 0 efter 2020 og lægges over i OtherAnimals
		qEmmAgrAnimalsOther.l[emmtype,t,emm]$(t.val>2020) 		 = qEmmAgrAnimalsOther.l[emmtype,t,emm] + qEmmAgrAni.l[emmtype,'01070','Mink',t,emm]; 
		qEmmAgrAni.l[emmtype,'01070',animals,t,'N2O']$(t.val>2020) = 0;

		#Other animals trækkes fladt efter 2050
		qEmmAgrAnimalsOther.l[emmtype,t,emm]$(t.val>2050) 	= qEmmAgrAnimalsOther.l[emmtype,'2050',emm];

		# Aggregates of animal emissions
		qEmmAgrxE.l['EntericFermentation',ani_sectors,t,emm] 	= sum(Animals, qEmmAgrAni.l['EntericFermentation',ani_sectors,Animals,t,emm]);
		qEmmAgrxE.l['ManureManagement',ani_sectors,t,emm] 		= sum(Animals, qEmmAgrAni.l['ManureManagement',ani_sectors,Animals,t,emm]);
		qEmmAgrxE.l['GrazingAnimals',ani_sectors,t,emm]       = sum(Animals, qEmmAgrAni.l['GrazingAnimals',ani_sectors,animals,t,emm]);
		qEmmAgrxE.l['N2Oindirect',ani_sectors,t,emm]         	= sum(Animals, qEmmAgrAni.l['N2Oindirect',ani_sectors,animals,t,emm]);

		#CO2e 
		qEmmAgrAni.l[emmtype,ani_sectors,Animals,t,'CO2e'] 		= sum(emm, qEmmAgrAni.l[emmtype,ani_sectors,Animals,t,emm]*GWP.l[emm]);
		qEmmAgrAnimalsOther.l[emmtype,t,'CO2e'] 		          = sum(emm, qEmmAgrAnimalsOther.l[emmtype,t,emm]*GWP.l[emm]);

		# Emissions factors
		uEmmAgrAni.l['EntericFermentation',Ani_sectors,Animals,t,emm]$(qAni.l[Ani_sectors,Animals,t])  = qEmmAgrAni.l['EntericFermentation',Ani_sectors,Animals,t,emm] / qAni.l[Ani_sectors,Animals,t];
		uEmmAgrAni.l['GrazingAnimals',Ani_sectors,Animals,t,emm]$(qAni.l[Ani_sectors,Animals,t])       = qEmmAgrAni.l['GrazingAnimals',Ani_sectors,Animals,t,emm] / qAni.l[Ani_sectors,Animals,t];
		uEmmAgrAni.l['N2Oindirect',Ani_sectors,Animals,t,emm]$(qAni.l[Ani_sectors,Animals,t]) 		   = qEmmAgrAni.l['N2Oindirect',Ani_sectors,Animals,t,emm] / qAni.l[Ani_sectors,Animals,t];
		uEmmAgrAni.l['ManureManagement',Ani_sectors,Animals,t,emm]$(qNMANURE.l[ani_sectors,animals,t]) = qEmmAgrAni.l['ManureManagement',Ani_sectors,Animals,t,emm] / qNMANURE.l[ani_sectors,animals,t];

		uEmmAgrAni.l[emmtype,Ani_sectors,Animals,t,emm]$(t.val > 2050) 	= uEmmAgrAni.l[emmtype,Ani_sectors,Animals,'2050',emm]; # Set constant emissions factor after 2050		

		uEmmAgrxE.l['EntericFermentation',ani_sectors,t,emm]    = qEmmAgrxE.l['EntericFermentation',ani_sectors,t,emm];
		uEmmAgrxE.l['ManureManagement',aniXpoultry,t,emm]       = qEmmAgrxE.l['ManureManagement',aniXpoultry,t,emm];    
		uEmmAgrxE.l['GrazingAnimals',aniXpoultry,t,emm]         = qEmmAgrxE.l['GrazingAnimals',aniXpoultry,t,emm];    


#4) INITIAL VALUES 

	# Non-market 
		pRxE_nm.l[Agri_sectors,Agri_sectorss,Agri_,t]$(qRxE_nm.l[Agri_sectors,Agri_sectorss,Agri_,t]) = 1; 


	# ANI 
		pAni_CET0.l[Ani_sectors,ani_out,tData]  = 1;
		qAni_CET.l[Ani_sectors,Ani_outNest,t] =sum(Ani_out_top$(Ani_prod2out(Ani_outNest,Ani_out_top)), qAni_CET.l[Ani_sectors,Ani_out_top,t]);

		# Prices of inputs
		pAni.l[Ani_sectors,'OtherEnergy',tData] = 1;

		# Aggregates prices
		pAni.l[Ani_sectors,'grossprod',tData]	= 1; # Set aggregates prices to one
		pAni.l[Ani_sectors,'netprod',tData]    	= 1;
		pAni.l[Ani_sectors,AniAggregates,tData]$(not sameas(AniAggregates,'AnimalsAgg')) = 1; # Set aggregates prices to one
		pAni.l[Ani_sectors,IOnestsAni,tData]	= 1; # Set bottom-level prices to one when they are constructed from IO inputs

		pAni.l[Ani_sectors,'BAML',tData]   	   = 1;
		pAni.l[ani_sectors,'litter',tData]     = 1; 
		pAni.l['01031',Animals,tData] 		   = 0;
		pAni.l['01032',Animals,tData] 		   = 0;
		pAni.l['01051',Animals,tData] 		   = 0;
		pAni.l['01052',Animals,tData] 		   = 0;
		pAni.l['01061',Animals,tData] 		   = 0;
		pAni.l['01062',Animals,tData] 		   = 0;
		pAni.l['01070',Animals,tData] 		   = 0;
		pAni.l[Ani_sectors,'AnimalsAgg',tData] = 0;

		# Creating initial values for CES-nests
		qAni.l[Ani_sectors,Ani_,t]$(ionestsani[Ani_] and tData[t])    = sum(s$(input2ani[s,Ani_]), qRxE_ym_ani.l[Ani_sectors,s,t]*pRxE_ym_ani.l[Ani_sectors,s,t])/pAni.l[Ani_sectors,Ani_,t];
		qAni.l[Ani_sectors,Ani_,t]$(nonNRnestsAni[Ani_] and tData[t]) = sum(Agri_sectors, pRxE_nm.l[Ani_sectors,Agri_sectors,Ani_,t]*qRxE_nm.l[Ani_sectors,Agri_sectors,Ani_,t]/pAni.l[Ani_sectors,Ani_,t]);
		qAni.l[Ani_sectors,AniNest,t]$(not sameas(AniNest,'AnimalsAgg') and tData[t]) = sum(Ani_$(AniNest2inputs_[AniNest,Ani_]), pAni.l[Ani_sectors,Ani_,t]*qAni.l[Ani_sectors,Ani_,t])/pAni.l[Ani_sectors,AniNest,t]; 
		qAni.l[Ani_sectors,AniNest,t]$(not sameas(AniNest,'AnimalsAgg') and tData[t]) = sum(Ani_$(AniNest2inputs_[AniNest,Ani_]), pAni.l[Ani_sectors,Ani_,t]*qAni.l[Ani_sectors,Ani_,t])/pAni.l[Ani_sectors,AniNest,t]; 
		qAni.l[Ani_sectors,AniNest,t]$(not sameas(AniNest,'AnimalsAgg') and tData[t]) = sum(Ani_$(AniNest2inputs_[AniNest,Ani_]), pAni.l[Ani_sectors,Ani_,t]*qAni.l[Ani_sectors,Ani_,t])/pAni.l[Ani_sectors,AniNest,t]; 
		qAni.l[Ani_sectors,AniNest,t]$(not sameas(AniNest,'AnimalsAgg') and tData[t]) = sum(Ani_$(AniNest2inputs_[AniNest,Ani_]), pAni.l[Ani_sectors,Ani_,t]*qAni.l[Ani_sectors,Ani_,t])/pAni.l[Ani_sectors,AniNest,t]; 
		qAni.l[Ani_sectors,AniNest,t]$(not sameas(AniNest,'AnimalsAgg') and tData[t]) = sum(Ani_$(AniNest2inputs_[AniNest,Ani_]), pAni.l[Ani_sectors,Ani_,t]*qAni.l[Ani_sectors,Ani_,t])/pAni.l[Ani_sectors,AniNest,t]; 
		qAni.l[Ani_sectors,'netprod',t]   = qY.l[ani_sectors,t];
		qAni.l['01070','BAML','2017']     = qAni.l['01070','BAML','2018']; 

		uAni.l[Ani_sectors,Ani_,t]        = qAni.l[Ani_sectors,Ani_,t];
		uAni_CET.l[Ani_sectors,ani_out,t] = qAni_CET.l[Ani_sectors,ani_out,t];
		uOtherEnergy_ani.l[purpose_xtint,ani_sectors,t] = qEP.l[purpose_xtint,ani_sectors,t];
		sRxE_ym_ani.l[Ani_sectors,s,t]    = qRxE_ym_ani.l[Ani_sectors,s,t];

	# New abatement	
		# These switches control whether abatement forward looking and/or sluggish. Should be set to 0 (not forward-looking or sluggish) or 1
		switch_forward_looking_ani 	= 1; 		# Perhaps this should be controlled individually for ID and EOPtech...
		switch_sluggish_ani 		= 1; 		# Perhaps this should be controlled individually for ID and EOPtech...
		uEOPanibeta 				= 0.5;      # This parameter controls the degree of forward-lookingness for EOPtech technologies
		rhoEOPani[TechAni] 			= 0.8;      # This parameter controls the degree of sluggishness for EOPtech technologies
		sigmaEOPAni[TechAni] 		= 0.1; 


#5) DUMMIES 
	# Dummy for the full nesting structure
	d1Ani[ani_sectors,Ani_,t]								= yes$(qAni.l[Ani_sectors,Ani_,t]);

	# Abatement
	d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm] 	= yes$(thetaAni.l[TechAni,ani_sectors,Emmtype,animals,t,emm]);
	d1vEOPCostAni[Emmtype,ani_sectors,s,animals,t] 			= yes$(sum((TechAni,emm), d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]) and sum(techAni, shareAniPrice_type.l[TechAni,'IO',t] and shareAniPrice_group.l[techAni,s,t]));

	# Emissions
	d1EmmAgrAni[emmtype,Ani_sectors,Ani_,t,emm_eq] 		= yes$(qEmmAgrAni.l[emmtype,Ani_sectors,Ani_,t,emm_eq]);
	d1EmmAgrAni[emmtype,Ani_sectors,Ani_,t,emm_eq]$(t.val > 2050) = yes$(qEmmAgrAni.l[emmtype,Ani_sectors,Ani_,'2050',emm_eq]); # Set dummy after 2050 
	d1EmmAgrAniOther[emmtype,t,emm_eq]			       		= yes$(qEmmAgrAnimalsOther.l[emmtype,t,emm_eq]);

	#Bottom deductions
	d1BotDedAni['EntericFermentation',ani_sectors,animals,t,emm]$(GWP.l[emm] and tCO2_emm_ani.l['EntericFermentation',ani_sectors,animals,t]) = 1; #One need to update these to have bottom-deductions for other combinations
	d1BotDedAni['ManureManagement',ani_sectors,animals,t,emm]$(GWP.l[emm] and tCO2_emm_ani.l['ManureManagement',ani_sectors,animals,t])    = 1;
	d1BotDedAni[emmtype,ani_sectors,animals,t,'CO2e'] = yes$(sum(emm,d1BotDedAni[emmtype,ani_sectors,animals,t,emm] and GWP.l[emm]));

	sSizeBottomDed.l[emmtype,ani_sectors,animals,t,emm]$(d1EmmAgrAni[emmtype,ani_sectors,animals,t,emm]) = 0.60;
	pBotdedPerAnimal.l[emmtype,ani_sectors,animals,t,emm_eq]$(not d1EmmAgrAni[emmtype,ani_sectors,animals,t,emm_eq]) = 0;

	uEOPani.l[Emmtype,ani_sectors,animals,t,emm]$(d1EmmAgrAni[emmtype,Ani_sectors,animals,t,emm]) = 1;


# ---------------------------------------------------------------------------------------------------------------------
# Add to data (includes list in data check)
# ---------------------------------------------------------------------------------------------------------------------

	$GROUP G_ani_data 
		qAni$(Ani_bottom[ani_] or ani_pk[ani_])
		pAni$(Ani_bottom[ani_] or ani_pk[ani_])
		qAni_CET$(ani_out_top[ani_out])
		pAni_CET
		qEmmAgrAni
		uEmmAgrAni
		qNManure
	;	


$ENDIF

# ======================================================================================================================
# Static calibration
# ======================================================================================================================

$IF %stage% == "static_calibration":

	$BLOCK B_production_ani_static_calibration

		# Assume identical markups of CET outputs in calibration
		E_markup_calib_ani[Ani_sectors,Ani_out_top,t]$(tx0[t])..
			Ani_markup[Ani_sectors,Ani_out_top,t]	=E=	Ani_markup_calib[Ani_sectors,t];

	    $LOOP00 E_pAni_uc:
	    	{name}_t0{sets}$(t0[t] and d1K[k,ani_sectors,t] and agri2k[ani_pK,k] and d1ani[ani_sectors,ani_pK,t])..
	    		{LHS} =E= {RHS};

	   	$ENDLOOP00

	   	E_pTobinsQ_ani_t0[ani_sectors,ani_pK,t]$(t0[t] and d1Ani[ani_sectors,ani_pK,t])..
	   		pTobinsQ_ani[ani_sectors,ani_pK,t]  =E= pTobinsQ_ani[ani_sectors,ani_pK,t+1];	   	

	  E_qAni_nottop_LeontiefCap_ani_TC_static_calib[ani_sectors,ani_,AniNest,t]$(t1[t] and AniNest2inputs_[AniNest,Ani_] and d1Ani[ani_sectors,ani_,t] and Leontief_aniNest[aniNest] and sameas[Ani_,'TransportCapital'])..
  		#  qAni[ani_sectors,ani_,t] =E= uAni[ani_sectors,ani_,t] * qAni[ani_sectors,AniNest,t];
	  	qAni[ani_sectors,ani_,t] =E= uAni[ani_sectors,ani_,t] * qAni[ani_sectors,AniNest,t];

		E_uEmmAgrAni_base[emmtype,Ani_sectors,animals,t,emm]$(tx0[t] and d1EmmAgrAni[emmtype,ani_sectors,animals,t,emm])..
			uEmmAgrAni_base[emmtype,ani_sectors,animals,t,emm] =E= uEmmAgrAni[emmtype,ani_sectors,animals,t,emm]/(1-sum(TechAni$(d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm] and not TechAni_eff[TechAni]), rEOPani_actual[TechAni,ani_sectors,Emmtype,animals,t] * thetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]));

		E_uManurePerAnimal_base[ani_sectors,animals,t]$(tx0[t] and sum(emm_eq, d1EmmAgrAni['ManureManagement',ani_sectors,animals,t,emm_eq]))..
			uManurePerAnimal_base[ani_sectors,animals,t] =E= uManurePerAnimal[ani_sectors,animals,t];
		

	$ENDBLOCK

	$MODEL M_ani_static_calibration_partial
		B_production_agr_ani
		B_production_ani_static_calibration
		B_emissions_agr_ani,-E_qEmmProdxE_agr_ani
		B_abatement_ani
		B_CO2taxOnAni
		B_botdedperanimal
	;

	$GROUP G_ani_static_calibration_partial
		G_production_ani_endo
		-qNManure, uManurePerAnimal
		-qRxE_nm, sRxE_nm
		-qRxE_ym_ani$(d1RxE_ym[ani_sectors,s,t]), sRxE_ym_ani$(d1RxE_ym[ani_sectors,s,t])                        
		-qAni$(d1Ani[ani_sectors,ani_,t] and Ani_bottom[ani_]), uAni$(d1Ani[ani_sectors,ani_,t] and Ani_bottom[ani_]) 
		-qAni$(d1Ani[ani_sectors,ani_,t] and sameas[ani_,'litter']), uAni$(d1Ani[ani_sectors,ani_,t] and sameas[ani_,'litter'])
		# -qAni$(d1Ani[ani_sectors,ani_,t] and ani_pK[ani_]), uAni$(d1Ani[ani_sectors,ani_,t] and ani_pK[ani_])
		-qAni_capital$(d1Ani[ani_sectors,ani_pK,t]), uAni$(d1Ani[ani_sectors,ani_,t] and ani_pK[ani_])

		# Intermediate CES-goods are determined by fixing prices at 1. For animals, which are Leontief no price fixing is need
		-qAni$(d1Ani[ani_sectors,ani_,t] and sameas[ani_,'AnimalsAgg']), uAni$(d1Ani[ani_sectors,ani_,t] and sameas[ani_,'AnimalsAgg'])
		uAni$(d1Ani[ani_sectors,ani_,t] and nonNRnestsAni[Ani_] and not sameas[ani_,'litter']), -pAni$(d1Ani[ani_sectors,ani_,t] and nonNRnestsAni[Ani_] and not sameas[ani_,'litter'])
		uAni$(d1Ani[ani_sectors,ani_,t] and ionestsani[Ani_]), -pAni$(d1Ani[ani_sectors,ani_,t] and ionestsani[ani_])
		uAni$(d1Ani[ani_sectors,ani_,t] and AniNest[ani_] and not sameas[Ani_,'grossprod'] and not sameas[Ani_,'AnimalsAgg']),-pAni$(d1Ani[ani_sectors,ani_,t] and AniNest[ani_] and not sameas[Ani_,'grossprod'] and not sameas[Ani_,'AnimalsAgg'])

		-pAni_CET, uAni_CET 
		-qAni_CET$(Ani_outNest[Ani_out]) # Alternatively determine via chain-index
		Ani_markup       # E_mAni_CET
		Ani_markup_calib # E_markup_calib_ani #TJEK

		-qEmmAgrAni$(d1EmmAgrAni[emmtype,Ani_sectors,Ani_,t,emm_eq]), uEmmAgrAni$(d1EmmAgrAni[emmtype,Ani_sectors,Ani_,t,emm_eq])

		#Bottom deduction 
		# -pBotdedPerAnimal[emmtype,ani_sectors,animals,t,'CO2e']$(tx0[t] and sum(emm,d1EmmAgrAni[emmtype,ani_sectors,animals,t,emm]) and sum(emm, d1BotDedAni[emmtype,ani_sectors,animals,t,emm])), jBotdedPeranimal
		uEmmAgrAni_base[emmtype,Ani_sectors,Ani_,t,emm]$(tx0[t] and d1EmmAgrAni[emmtype,ani_sectors,ani_,t,emm] and animals[ani_])
		uManurePerAnimal_base[ani_sectors,animals,t]$(tx0[t] and sum(emm_eq, d1EmmAgrAni['ManureManagement',ani_sectors,animals,t,emm_eq]))
	;

	$GROUP G_ani_static_calibration_partial_exo
		G_production_ani_exo

		dKInstCost2dK$(ani_sectors_sp[sp])

		pAni$(Ani_pk[Ani_])
		pD_manure

		# All bottom layers are inverted - quantity for share-parameter
		qNManure, -uManurePerAnimal 
		qRxE_nm$(ani_sectors[agri_sectorss] and ani_[agri_]), -sRxE_nm
		qRxE_ym_ani$(d1RxE_ym[ani_sectors,s,t]), -sRxE_ym_ani$(d1RxE_ym[ani_sectors,s,t])

		qAni$(d1Ani[ani_sectors,ani_,t] and Ani_bottom[ani_]), -uAni$(d1Ani[ani_sectors,ani_,t] and Ani_bottom[ani_])
		qAni$(d1Ani[ani_sectors,ani_,t] and sameas[ani_,'litter']), -uAni$(d1Ani[ani_sectors,ani_,t] and sameas[ani_,'litter'])
		qAni$(d1Ani[ani_sectors,ani_,t] and sameas[ani_,'AnimalsAgg']), -uAni$(d1Ani[ani_sectors,ani_,t] and sameas[ani_,'AnimalsAgg'])
		# qAni$(d1Ani[ani_sectors,ani_,t] and ani_pK[ani_]), -uAni$(d1Ani[ani_sectors,ani_,t] and ani_pK[ani_])
		qAni_capital$(d1Ani[ani_sectors,ani_pK,t]), -uAni$(d1Ani[ani_sectors,ani_,t] and ani_pK[ani_])


		# Intermediate CES-goods are determined by fixing prices at 1. For animals, which are Leontief no price fixing is need
		-uAni$(d1Ani[ani_sectors,ani_,t] and nonNRnestsAni[Ani_] and not sameas[ani_,'litter']), pAni$(d1Ani[ani_sectors,ani_,t] and nonNRnestsAni[Ani_] and not sameas[ani_,'litter'])
		-uAni$(d1Ani[ani_sectors,ani_,t] and ionestsani[Ani_]), pAni$(d1Ani[ani_sectors,ani_,t] and ionestsani[ani_])
		-uAni$(d1Ani[ani_sectors,ani_,t] and AniNest[ani_] and not sameas[Ani_,'grossprod'] and not sameas[Ani_,'AnimalsAgg']), pAni$(d1Ani[ani_sectors,ani_,t] and AniNest[ani_] and not sameas[Ani_,'grossprod'] and not sameas[Ani_,'AnimalsAgg'])

		pYani$(t0[t]), dKInstCost2dI$(ani_sectors_sp[sp]), dKInstCostLead2dI$(ani_sectors_sp[sp]) # E_pTobinsQ_ani
		pAni_CET, -uAni_CET 
		qAni_CET$(Ani_outNest[Ani_out]) # Nests are fixed or could alternatively be determined by a chain-index. Actual output is exogenous for the farmer an taken as given from the rest of the economy 
		-Ani_markup       # E_markup_calib_ani
		-Ani_markup_calib # E_mAni_CET

		# LINK
		pK$(d1K[k,sp,t] and Ani_sectors_sp[sp])

		qEmmAgrAni$(d1EmmAgrAni[emmtype,Ani_sectors,Ani_,t,emm_eq]), -uEmmAgrAni$(d1EmmAgrAni[emmtype,Ani_sectors,Ani_,t,emm_eq])
		;

	$GROUP G_production_ani_static_calibration
		G_ani_static_calibration_partial
		pAni_uc$(t1[t] and sameas[ani_pK,'TransportCapital']) #Because machines and transport capital are Leontief in same nest, they cannot both be shadow price for the nest. However, in static calibration we need to attach a value (through price) to one of them. We choose transportcapital

		G_GE_LINKS_ANI

	    # Quantities, instead of being exogenized, are fed in directly from the CGE-model via the links
		pAni_CET               # To ensure complete correspondance between modules the prices are fed in from the CGE-model. Alternatively the link could have been made the other direction
		# qAni$((Ani_bottom[Ani_] or ani_pK[Ani_]) and not sameas[Ani_,'OtherEnergy'] and not Animals(Ani_)), uOtherEnergy_ani
		qAni$(Ani_bottom[Ani_] and not sameas[Ani_,'OtherEnergy'] and not Animals(Ani_)), uOtherEnergy_ani
		qAni_capital$(d1Ani[ani_sectors,ani_pK,t])
		qRxE_ym_ani$(d1RxE_ym[ani_sectors,s,t])    

		jEmmAgrxE$(ani_sectors[agri_sectors])

		# #Bottom deduction 		
		# pBotdedPerAnimal[emmtype,ani_sectors,animals,t,'CO2e']$(tx0[t] and sum(emm,d1EmmAgrAni[emmtype,ani_sectors,animals,t,emm]) and sum(emm, d1BotDedAni[emmtype,ani_sectors,animals,t,emm])), -jBotdedPeranimal

	;

	$GROUP G_production_ani_static_calibration_exo
		G_ani_static_calibration_partial_exo

		# Exogenous from link-equations 
		#  qY_CETgross$(agri_sectors_s[s])
		qY_CET$(Ani_sectors_s[s])
		pY_CET$(d1vY_CET[out,s,t] and Ani_sectors_s[s])
		qRxE_ym$(d1RxE_ym[r,s,t] and Ani_sectors_r_[r])
		pRxE_ym$(d1RxE_ym[r,s,t] and Ani_sectors_r_[r])
		qK$(d1K[k,s,t] and Ani_sectors_s[s])
		qFin_k$(Ani_sectors_s[r])
		pFin_k$(Ani_sectors_r_[r])
		qL$(Ani_sectors_s_[s_])
		thetaProd$(ani_sectors_sp[sp] and prdL[prd])
		tL$(Ani_sectors_s[s])
		w 
		qEP$(Ani_sectors_s[s])
		pEP$(Ani_sectors_s[s])
	;

	$MODEL M_production_ani_static_calibration
		M_ani_static_calibration_partial
		B_LINK_ani
		E_qEmmProdxE_agr_ani   #We add this to calibrate J-term (difference between DST emissions and Climate Outlook)
	;

$ENDIF

# ======================================================================================================================
# Dynamic calibration
# ======================================================================================================================

$IF %stage% == "dynamic_calibration":

	$GROUP G_ani_calib_partial 
		G_production_ani_endo
		# -qAni$((Ani_pK[Ani_] and tData[t]) or (Ani_pK[Ani_] and t2[t]))			  # Capital is fixed in data years
		-qAni_capital$(tData[t] or t2[t])			  # Capital is fixed in data years
		jpK_ani$(not sameas[ani_pK,'TransportCapital'])
		uAni$(t2[t] and sameas[ani_,'TransportCapital'])     #For some reason mink move a bit in t2 without this condition.
		qI_s$(ani_sectors_s[s] and tx0[t])
		qK$((t0[t] or tx0[t]) and ani_sectors_s[s])
		qFin_k$((t0[t] or tx0[t]) and ani_sectors_s[r]) #and sameas[k,'iM']
		qKInstCost$(tx0[t] and ani_sectors_s[s])
		dKInstCost2dK$(tx0[t] and ani_sectors_sp[sp])
		dKInstCost2dI$(tx0[t] and ani_sectors_sp[sp])
		dKInstCostLead2dI$(tx0E[t] and ani_sectors_sp[sp])
	;


	$GROUP G_ani_calib_partial_exo
		G_production_ani_exo
		# qAni$((Ani_pK[Ani_] and tData[t]) or (Ani_pK[Ani_] and t2[t]))
		qAni_capital$(tData[t] or t2[t])
		-jpK_ani$(not sameas[ani_pK,'TransportCapital'])
		-qI_s$(ani_sectors_s[s] and tx0[t])
		-qK$((t0[t] or tx0[t]) and ani_sectors_s[s])
		-qFin_k$((t0[t] or tx0[t]) and ani_sectors_s[r]) # and sameas[k,'iM']
		-qKInstCost$(tx0[t] and ani_sectors_s[s])
	;

	$BLOCK B_ani_calib 
		
		E_jpK_ani[ani_sectors,ani_pK,k,t]$(d1K[k,ani_sectors,t] and agri2k[ani_pK,k] and tx1[t] and t.val > t2.val and not sameas[ani_pK,'TransportCapital'])..
			jpK_ani[ani_sectors,ani_pK,t] =E= 0; #jpK_ani[ani_sectors,ani_pK,t-1]$(not sameas[ani_sectors,'01070']) + jpK_ani[ani_sectors,ani_pK,t-1]$(sameas[ani_sectors,'01070']);

		# Capital accumulation and installation cost. We copy the CGE-version of equations
	    $LOOP00 E_qI_s:
	    	{name}_ani{sets}$({subsets} and ani_sectors_sp[sp]).. {LHS} =E= {RHS};
	    $ENDLOOP00

	    $LOOP00 E_qI_s_END:
	    	{name}_ani{sets}$({subsets} and ani_sectors_sp[sp]).. {LHS} =E= {RHS};
	    $ENDLOOP00

	    $LOOP00 E_qKInstCost:
	    	{name}_ani{sets}$({subsets} and ani_sectors_sp[sp]).. {LHS} =E= {RHS};
	    $ENDLOOP00


	    $LOOP00 E_dqKInstCost2dqK:
	    	{name}_ani{sets}$({subsets} and ani_sectors_sp[sp]).. {LHS} =E= {RHS};
	    $ENDLOOP00


	    $LOOP00 E_dqKInstCost2dqI_s:
	    	{name}_ani{sets}$({subsets} and ani_sectors_sp[sp]).. {LHS} =E= {RHS};
	    $ENDLOOP00

	    $LOOP00 E_dqKInstCostLead2dqI_s:
	    	{name}_ani{sets}$({subsets} and ani_sectors_sp[sp]).. {LHS} =E= {RHS};
	    $ENDLOOP00

	$ENDBLOCK 

	# Run a forecast on the partial equilibrium
	$MODEL M_ani_calib_partial 
		B_production_agr_ani
		B_emissions_agr_ani,-E_qEmmProdxE_agr_ani	
		B_abatement_ani
		B_ani_calib 
		B_CO2taxOnAni
		B_botdedperanimal
		E_uEmmAgrAni_base
		E_uManurePerAnimal_base

		#AKB
		E_qK_im_link_ani
		E_qFin_iM_LINK_ani
		
		E_qK_ib_LINK_ani
		E_qFin_iB_LINK_ani

		E_qK_it_LINK_ani
		E_qFin_iT_LINK_ani
	;

	$GROUP G_ani_calib_partial_exo
		G_ani_calib_partial_exo
		uEOPani
		GWP
		uEmmAgrxE$(ani_sectors[agri_sectors])
		#Bottom deduction 
		# pBotdedPerAnimal[emmtype,ani_sectors,animals,t,'CO2e']$(tx0[t] and sum(emm,d1EmmAgrAni[emmtype,ani_sectors,animals,t,emm]) and sum(emm, d1BotDedAni[emmtype,ani_sectors,animals,t,emm])), -jBotdedPeranimal

		
	;

	$GROUP G_ani_calib_partial
		G_ani_calib_partial
		#Bottom deduction 
		# -pBotdedPerAnimal[emmtype,ani_sectors,animals,t,'CO2e']$(tx0[t] and sum(emm,d1EmmAgrAni[emmtype,ani_sectors,animals,t,emm]) and sum(emm, d1BotDedAni[emmtype,ani_sectors,animals,t,emm])), jBotdedPeranimal
		uEmmAgrAni_base[emmtype,Ani_sectors,Ani_,t,emm]$(tx0[t] and d1EmmAgrAni[emmtype,ani_sectors,ani_,t,emm] and animals[ani_])
		uManurePerAnimal_base[ani_sectors,animals,t]$(tx0[t] and sum(emm,d1EmmAgrAni[emmtype,ani_sectors,animals,t,emm])))

	;

#  	  COMMENT IN TO RUN PARTIAL MODEL

#  	 Note: Dynamic calibration of the partial model should perhaps include an actual equation for fKInstCost

 	# set_time_periods(%cal_start%, %terminal_year%);
 	# @set_dummies('2019',tx1);  # Use dummies from last data year in following periods
	
 	# fKInstCost.l[k,agri_sectors,tx1] = fq;
 	# rBonds.l[agri_sectors,t] = rBonds.l[agri_sectors,'2019'];
	

 	# $FIX G_ani_calib_partial_exo;
 	# $UNFIX G_ani_calib_partial;
#  	execute_unload 'output\pre.gdx';
 	# @SOLVE(M_ani_calib_partial);
#  	execute_unload 'output\ani_partial.gdx';
#  	@assert_no_difference(G_data,%tolerance_data%);
#  	$exit

	$MODEL M_production_ani_calib 
		B_production_agr_ani
		B_abatement_ani
		B_ani_calib,-E_qI_s_ani, -E_qI_s_end_ani,-E_qKInstCost_ani,-E_dqKInstCost2dqK_ani,-E_dqKInstCost2dqI_s_ani,-E_dqKInstCostLead2dqI_s_ani
		B_LINK_ani
		B_emissions_agr_ani
		B_CO2taxOnAni
		B_botdedperanimal
		E_uEmmAgrAni_base
		E_uManurePerAnimal_base

	;

	$GROUP G_production_ani_calib 
		G_production_ani_endo
		jpK_ani$(not sameas[ani_pK,'TransportCapital'])
		G_GE_LINKS_ANI
		G_GE_ENDOGENIZE_ANI,-uProd$(ani_sectors_sp[sp] and prdCapital[prd] and (tData[t] or t2[t])) # Exogenous parameters in CGE-model that are endogenized to fit the CGE-sectors to the agricultural module.	
		G_GE_LINKS_EMMI_ANI
		uAni$(t2[t] and sameas[ani_,'TransportCapital']) #For some reason mink move a bit in t2 without this condition.
		#Bottom deduction 
		# -pBotdedPerAnimal[emmtype,ani_sectors,animals,t,'CO2e']$(tx0[t] and sum(emm,d1EmmAgrAni[emmtype,ani_sectors,animals,t,emm]) and sum(emm, d1BotDedAni[emmtype,ani_sectors,animals,t,emm])), jBotdedPeranimal
		uEmmAgrAni_base[emmtype,Ani_sectors,Ani_,t,emm]$(tx0[t] and d1EmmAgrAni[emmtype,ani_sectors,ani_,t,emm] and animals[ani_])
		uManurePerAnimal_base[ani_sectors,animals,t]$(tx0[t] and sum(emm_eq, d1EmmAgrAni['ManureManagement',ani_sectors,animals,t,emm_eq]))

	;


	$GROUP G_production_ani_calib_exo 
		G_production_ani_exo 
		-jpK_ani$(not sameas[ani_pK,'TransportCapital']) 	
		uProd$(ani_sectors_sp[sp] and prdCapital[prd] and (tData[t] or t2[t]))
		G_CO2ani_exo
		# pBotdedPerAnimal[emmtype,ani_sectors,animals,t,'CO2e']$(tx0[t] and sum(emm,d1EmmAgrAni[emmtype,ani_sectors,animals,t,emm]) and sum(emm, d1BotDedAni[emmtype,ani_sectors,animals,t,emm])), -jBotdedPeranimal

		;

	jEmmAgrxE.l[ani_sectors,tForecast,emm] = 0; 		# The difference between DST and ENS i set to zero after data year
	qAni_capital.l[ani_sectors,ani_pK,t]$(t.val>t2.val) = qAni_capital.l[ani_sectors,ani_pK,t2];

$ENDIF



