# ======================================================================================================================
#		 AGRICULTURAL MODULE
# ======================================================================================================================
# A brief overview:
#
# 1) In the first stage (%stage%=="variables") variables are created in GAMS 
#
# 2) In the second stage (%stage%=="GroupCompilation") variables are bunched together in $GROUPS. This allows us to perform the same action over collections of variable, most prominently defining which variables are exogenous and which are endogenous.
#
# 3) In the third stage (%stage%=="equations") blocks of equations are defined. Together the blocks add up to the GreenREFORM agricultural module (for the LULUCF-module see lulucf.gms). 
#
# 4) In the fourth stage (%stage%=="exogenous_values") data is loaded into the module variables. A bit of residual data-treament is also carried out in this stage.
#
# 5) In the fifth stage (%stage%=="static_calibration") additional equations are added for the so-called static calibration. In this step the model is "inverted" in data-years. That is, endogenous variables are exogenized and calibration-parameters are endogenized.
#
# 6) In the sixth stage (%stage%=="dynamic_calibration") additional equations are added for the so-called dynanic calibration. In this step a partial version of the agricultural module is also compiled. This stage otherwise collects variables and equations and projects 
#    and would calibrate a "raw" projection of the agricultural module from last data year to 2099. The module is however calibrated to many external sources. Most importantly a calibration of production, prices, and emissions. This is collected in the file integration_agr.gms
# ======================================================================================================================


#  # ======================================================================================================================
#  # Variable definition
#  # ======================================================================================================================

$IF %stage% == "variables":
	
	# Parametre til landbrugsabatement
	$PGROUP PG_plant_abatement_parms
	  	switch_forward_looking_plant ""
	  	switch_sluggish_plant ""
	  	rhoEOPplant[Techplant] ""
	  	sigmaEOPplant[Techplant] ""
	  	uEOPplantbeta ""
	;

	#-------------------------------------------------------------------------------------------------------------------
	# Variables for the CES-production function: Prices, quantities, values, CES-shares, etc...
	#-------------------------------------------------------------------------------------------------------------------

	$GROUP G_plant_prices 
		pPlant_CET[Plant_sectors,Plant_out,t]                           			"Prices of plant sectors CET outputs (market prices), inflation-adjusted (Producentprisindex for afgrødeproduktion)"
		pPlant_CET_baseline[Plant_sectors,Plant_out,t]                           			"Prices of plant sectors CET outputs (market prices), inflation-adjusted (Producentprisindex for afgrødeproduktion)"
		pPlant_CET0[Plant_sectors,Plant_out,t]                          			"Prices of plant sectors CET outputs (own prices), inflation-adjusted"
		pPlant[Plant_sectors,Plant_,t]									            "Prices plant ani sector production function, inflation adjusted "
		pPlant_uc[plant_sectors,plant_pK,t] 							            "User-cost of capital in plant sectors, inflation adjusted (Brugeromkostning på kapital i afgrødeproduktion, vækst- og inf. korrigeret)"
		pPlant_base[plant_sectors,chemNPK,t] 							            "Prices for chem and NPK (basis-priser), inflation adjusted"
		pLand[t]													  	            "Market-clearing price of land (Price of land bio. kr. per mio. hectares = thousand kr. per hectare. Price is inflation- and growth-adjusted)"
		pLand_nonproductive[landallocation,plant_sectors,t]             			"Price of land allocated to alternative use. Originially non-productive use, but now the definition encompasses land-use such as forest, solar and windpower which are productive, inflation and growth-adjusted"
		pReturnPerHa_alt_landallocation[landallocation,plant_sectors,t] 			"Return on land allocated otherwise than crop production, inflation and growth-adjusted (Afkast på jord allokeret til andet en ekstensiv landbrug, målt i tusinde kroner per hektar, vækst- og inf. korrigeret)"
		pLandvalueFromUnobserved[idxUnobservable,plant_sectors,t]         			"Flow of unobservable value to land-price due to unobservables in data, inflation and growth-adjusted (Flow af ikke-observerbar værdi til jordværdi fx. herligheds- og optionsværdi. Målt i tusinde kroner per ha. vækst- og inf. korr)"

		#For user-cost 
		pTobinsQ_plant[plant_sectors,plant_pK,t] 						            "Tobins-Q in user-cost of capital for plants"
		pTobinsQ_plantxInst[plant_sectors,plant_pK,t]				            	"Tobins Q excluding installation costs (to calculate DBII) £: Overvej at fjern"
		pPlantxInst[plant_sectors,plant_pK,t]							            "User cost excluding installation costs (to calculate DBII)"
		pTobinsQ_land[plant_sectors,t]												"Tobins-Q in user-costs of capital for land"
	
		#IO
		pRxE_ym_plant[Plant_sectors,s,t]							 	            "Prices of non-energy, market-inputs, buyers prices received in plant sectors, inflation-adjusted"
	;

	$GROUP G_plant_quantities 
		qPlant_CET_gross[Plant_sectors,Plant_out,t]                       			"Gross-production from plant sectors (i.e. including production for own-consumption of straw). In general bio. kr. growth-adjusted, exception for straw, which are scaled PJ."        
		qPlant_CET[Plant_sectors,Plant_out,t]                             			"Net production from plant sectors (In general bio. kr. growth-adjusted, exception for straw, which are scaled PJ)"
		qPlant_CET_baseline[Plant_sectors,Plant_out,t]                             			"Net production from plant sectors (In general bio. kr. growth-adjusted, exception for straw, which are scaled PJ)"
		qPlant[Plant_sectors,Plant_,t]			                              		"Quantities of input in plant sectors production-function (In general bio. kroner growth-adjusted, but mio. hectares for land and mio. tonnes of N-equivalent for manure and NPK)"
		qPlant_capital[plant_sectors,plant_pK,t] 							            "Capital in plant sectors, bio. kr. growth-adjusted (Kapital i afgrødeproduktion, mio. kr. vækst- og inf. korr.)"
		qRxE_ym_Plant[Plant_sectors,s,t]                            	    		"IO level quantities of plant sector production function (bio. kr. growth-adjusted)"
		qKInstcost_land[plant_sectors,t] 								           	"Installation cost incurred from changing hectares of land in production-function (bio. kr. growth-adjusted)"
	;

	$GROUP G_agr_values_plant			
		vtCAP[s,t]$(agri_sectors_s[s])                                                        			"Total CAP-subsidies by sector, bio. kr. inflation- and growth-adjusted (Total EU-landbrugsstøtte tildelt branche s)"
		vtCAP_top[s,t]$(agri_sectors_s[s])                                                    			"CAP-subsidies that enter the top of the production-function, bio. kr. inflation and growth-adjusted (Værdi af EU-landbrugsstøtte, der trækkes fra de samlede omkostninger, mia. kr. vækst- og inf. korr.)"
		vtCAP_tot[t]                                                      			"Total CAP-subsidies, bio. kr. inflation- and growth-adjusted (Total EU-landbrugsstøtte tildelt til den samlede landbrugssektor)"  
		vtCAP_uc[plant_sectors,t]                                          			"CAP-subsidies that enter user-cost of the production-function, bio. kr. inflation and growth-adjusted (Værdi af EU-landbrugsstøtte, der indgår i brugeromkostningen på jord i omdrift, mia. kr. vækst- og inf. korr.)"
		vtCAP_lumpsum[plant_sectors,t]                                     			"CAP-subsidies transferred lump-sum to farmers (Værdi af EU-landbrugsstøtte, der betragtes som uafhængigt af produktionen, mia. kr. vækst- og inf. korr.)"
		vCO2_plant[plant_sectors,plant_,t]			                          		"Tax-revenue from CO2-tax levied on non-energy emissions in plant sectors, bio. kr. inflation- and growth-adjusted (CO2e-afgift på planterelaterede udledninger)"
		vDBII[plant_sectors,t]					                                  	"Operating surplus II measure, bio. kr. inflation- and growth-adjusted (Dækningsbidrag II, mia. kr. vækst- og inf. korrigerede)"
		vtProduktionsStoetteCAP[plant_sectors,t]                          			"Total production-related subsidies under the CAP, bio. kr. inflation and growth-adjusted (Produktionsrelateret landbrugsstøtte fra EU)"                                     
		vtHectareSubsidy_prod[plant_sectors,t]                             			"Total hectare-subsidies granted to land in extensive crop production, bio. kr. inflation and growth-adjusted (Grundbetaling til jord i omdrift, målt i mia. kroner vækst- og inf. korr.)"
		vtHectareSubsidy_nonprod[plant_sectors,t]                          			"Total hectare-subsidies granted to land in non-extensive use, bio. kr. inflation and growth-adjusted (Grundbetaling til jord uden for omdrift, målt i mia. kroner vækst - og inf. korr.)"
		vtAndenArealStoette[plant_sectors,t]                              			"Total per hectare CAP-subsidies, excluding grundbetaling, bio. kr. inflation and growth-adjusted (Værdi af anden arealstøtte, målt i mia. kr., vækst- og inf. korr.)"
		vtSubOrganic[plant_sectors,t]                                     			"Total per hectare subsidies to hectares in extensive organic crop production, bio. kr. inflation and growth-adjusted (Værdi af økologiestøtte, mia. kr. vækst- og inf.korr.)"
		vtCAP_other[plant_sectors,t]                                      			"Residual category for CAP-subsidies to the ones above in G_agr_value, bio. kr. inflation and growth-adjusted (Værdi af anden EU-landbrugsstøtte, mia. kr. vækst- og inf. korr.)"
		vtPerHectareBottomDeduction[sp,t]$(plant_sectors_sp[sp])                                     		"In shocks, a her hectare bottom-deduction in CO2e-tax can be applied, bio. kr. inflation and growth-adjusted (Værdi af eventuelt bundfradrag for CO2e-afgift givet per hektar, mia. kr. vækst- og inf. korr.)"
		adj_vtCAP_other[t]                                                			"Adjustment parameter, that expands and shrinks vtCAP_other to keep the total CAP-constraint"
	;

	$GROUP G_agr_report_plant			
		vCO2_plantAgg[t]							                             	"Aggregate tax-revenue from plant sectors (non-energy emissions), bio. kr. inflation and growth-adjusted (Samlet skatteprovenu fra CO2e-afgift på ikke-energimæssige udledninger hos afgrødeproducenter), "
		vDBIIperHectare[t]							                                "Dækningsbidrag II per hectare, thousand kroner per hectare, inflation and growth-adjusted (Dækningsbidrag II for afgrødeproducenter, tusinde kroner per hektar, vækst-og inf. korr.)"
		ProdValue[t]                                                      			"Total crop and horticulture production, including non-market crops, bio. kr. inflation and growth-adjusted (Værdi af afgrøde- og gartneriproduktion, mia. kr. vækst- og inf. korr.)"
		vProdInput[t]                                                     			"Value of non-energy, market inputs in crop and horticulture production, bio. kr. inflation and growth-adjusted (Værdi af energiinput i afgrøde- og gartneriproduktion, mia. kr. vækst- og inf. korr.)"
		EnergyExTax[t]                                                    			"Value of fuel use in plant production, ex. energy-taxes, bio. kr. inflation and growth-adjusted (Værdi af brændselsforbrug, eksl. energiafgifter, mia. kr., vækst-og inf.korr.)"
		vManure[t]                                                        			"Value of manure in plant production, bio. kr. inflation and growth-adjusted (Værdi af husdyrgødning i afgrødeproduktion, mia. kr. vækst-og inf.korr.)"
		vNPK[t]                                                           			"Value of NPK-fertilizer in plant production, bio. kr. inflation and growth-adjusted (Værdi af NPK-gødning i afgrødeproduktion, mia. kr. vækst-og inf. korr.)"
		pPlant_mekanisk[plant_sectors,t]                                  			"Mechanical change, i.e. before behaviour, in plant prices due to a CO2e-tax on non-energy plant-emissions (Mekanisk priseffekt af en CO2e-afgift på afgrødepriser, i.e. effekt før adfærd)"
		vPlant[plant_sectors,plant_,t]$(tx0[t])                           			"Value of production inputs in plant production, bio. kr. inflation- and growth-adjusted (Værdi af input i afgrodeproduktion, mia. kr. vækst- og inf. korr.)"
		EmmPerManure[plant_sectors,t]$(tx0[t])                            			"Fertilizer (NPK, manure and other) related emissions per input of N applied to field, ktCO2e per mio. ton N-equivalent"
		EmmPerLand[plant_sectors,t]$(tx0[t])                              			"Land-related emissions (ktCO2e) per mio. hectare land in extensive-use"
		pLand_avg[t]                                                      			"Average price of land across all possible land allocations, thousand kroner per hectare, inflation and growth-adjusted (Gennemsnitlig jordpris på tværs af arealanvendelser, målt i tusinde kroner per hektar, vækst-og inf. korr.)"
		pPlant_pK_alt[plant_sectors,plant_pK,t]  ""
		pTobinsQ_plant_alt[plant_sectors,plant_pK,t]  ""
		pLand_nonproductive_report[landallocation,plant_sectors,t]             			"Price of land allocated to alternative use. Originially non-productive use, but now the definition encompasses land-use such as forest, solar and windpower which are productive, inflation and growth-adjusted"
		vY_agr_market[agri_sectors,t]$(tx0[t])                            			"Value of market production in agricultural sectors, bio. kr. inflation and growth-adjusted (Værdi af markedsmæssig produktion i landbrugets produktionsgrene, mia. kr. vækst-og inf. korr.)"
		vInput_agr_market[agri_sectors,t]$(tx0[t])                        			"Value market inputs in agricultural production, bio. kr. inflation and growth-adjusted (Værdi af markedsmæssige input i produktionen i landbrugets produktionsgrene, mia. kr. vækst-og inf. korr.)"
		vY_agr_nm[agri_sectors,t]$(tx0[t])                                			"Value of non-market production, bio. kr. inflation- and growth-adjusted (Værdi af ikke-marekdsmæssig produktion i landbrugets produktionsgrene, mia. kr. vækst-og inf. korr.)"
		vInput_agr_nm[agri_sectors,t]$(tx0[t])                            			"Value of non-market inputs in production, bio. kr. inflation- and growth-adjusted (Værdi af ikke-markedsmæssige input i landbrugets produktionsgrene, mia. kr. vækst-og inf. korr.) "
		vBVT_agr_cpntns[agri_sectors,BVTagr_cpntns,t]$(tx0[t])            			"De composition of production value in agriculture, bio. kr. inflation- and growth-adjusted (Dekomponering af BVT i landbrugets produktionsgrene, mia. kr. vækst-og inf. korr.)" 
	;

	$GROUP G_plant_taxes_and_subsidies
		tCO2_emm_plant[plant_sectors,plant_,t]		                        		"CO2-tax levied on non-energy emissions in plant sectors (Afgiftssats på ikke-energimæssige udledninger i de afgrødeproduktionsgrene, målt i kroner per tCO2e, inf-korrigeret)"
		tLand[plant_sectors,t] 												        "Effective per mille tax rate on land (Grundskyldspromille på landbrugsjord)"
		tLand_Photovoltaics[plant_sectors,t]                        			    "Effective per mille tax rate on areas allocated for photovoltaic panels (Grundskyldspromille på jord allokeret til solceller)"
		tPerHectareBottomDeduction[t]                                               "Per hectare bottom deduction on CO2e-tax that can be applied in shocks"             
		tHectareSubsidy[t]                                                          "Base subsidy per hectare, thousand kroners per hectare, inflation and growth-adjusted (Grundbetaling, tusind kroner per hektar)"
		tSubOrganic[plant_sectors,t]                                                "Per hectare subsidy to organic crop production, thousand kroners per hectare, inflation and growth-adjusted (Økologi-støtte, tusind kroner per hektar)"
		tSubOtherPerHectareSchemes[landallocation,plant_sectors,t]                  "Other per hectare based subsidies under the CAP, thousand kroners per hectare, inflation and growth-adjusted "
		tK_plant[k,plant_sectors,t]                                                 "Tax on non-land capital in plant production"                     
		tAfforestationPerHa[plant_sectors,t]                                        "Afforestation subsidy, given as a one-time payment per hectar converted"
	;

	$GROUP G_agr_other_plant
		# CES-shares
		uPlant[Plant_sectors,Plant_,t]$(not (sameas(plant_,'grossprod') or sameas[plant_,'netprod'])) 	"CES shares of plant sector production function"
		sRxE_ym_plant[plant_sectors,s,t]$(d1RxE_ym[Plant_sectors,s,t])				                  			  "CES shares of IO level of plant sector production function"
		uPlant_CET[Plant_sectors,Plant_out,t]                                                         	"CET shares of plant-CET split"
		TFPPlant[plant_sectors,t] 													                 												   "Total-factor productivity of plant production"
		# Other
		ePlant[Plant_sectors,Plant_,t]                                  				                "Production elasticities of ani sector production function (incl. IO)"
		eCET_Plant[Plant_sectors,Plant_out]$(Plant_outNest[Plant_out]) 			                     	"CET elasticities plant"
		qLand[t]$(t0[t])															                   	"Total amount of land available for extensive farming, mio. hectares"
		qLand_nonproductive[landallocation,plant_sectors,t]                                           	"Total amount of land allocated to other purposes than extensive farming, mio. hectares"
		Plant_markup[Plant_sectors,plant_out,t]                         				                "CET markups plants"
		Plant_markup_calib[Plant_sectors,t]                             				                "CET markups plants"
		uOtherEnergy_plant[purpose_xtint,plant_sectors,t]                  				                "CES share of other energy allocated on different purposes, excluding transport"
		jpK_plant[plant_sectors,plant_pK,t] 								                            "J-term in user-cost of capital. Captures difference in forward-looking agents investment need vs. actual invest in last data-year"
		jpPlant[plant_sectors,chemNPK,t] 											                    "J-term in user-cost of capital. Captures difference in forward-looking agents investment need vs. actual invest in last data-year"
		sPlant_AGG[plant_sectors,t] 													                "Distributors portfolio share of litter to plant_sector"
		ePlant_AGG 																		                "Distributors elasticity of demand between supplying plant sectors of litter"
		uKinstcost_land[plant_sectors,t] 											                    "Scale parameter of installation costs on change in land allocated to extensive farming"
		jpK_land[plant_sectors,t]      									                                "J-term in user-cost of land-capital. Captures difference in forward-looking agents investment need vs. actual invest in last data-year"
		dInstcostlandT[plant_sectors,t]  										                       	"Derivative of current installaiton cost wrt. land"
		dInstcostlandTp1[plant_sectors,t] 											                    "Derivative of future installation cost wrt. land"
		thetaJ[plant_sectors,t] 													                    "Land enhancing technological growth (relative to fq baseline growth)"
		rFirmsLand[plant_sectors,t]                                                                   	"Required rate of return on land in plant production"
		sDebt2j[plant_sectors,t] 													                    "Share of land investments financed with debt"
		jvtLand[plant_sectors,t]                                                                      	"J-term to capture difference in tax-revenue from land tax in data"
		jEmmAgrxE[agri_sectors,t,emm]$(plant_sectors[agri_sectors]) 												                    "J-term to capture residual between DST and Climate Outlook emissions in data"
		vtLand$(tx0[t])
		jqPlant_CET[plant_sectors,plant_out,t]$(d1Plant_CET0[plant_sectors,plant_out,t]) ""
		;


	#-------------------------------------------------------------------------------------------------------------------
	# Abatement (EOP = End-of-pipe)
	#------------------------- ------------------------------------------------------------------------------------------

	$GROUP G_plant_EOP
		rEOPplant_gains[Techplant,plant_sectors,Emmtype,t] 						"Gains of adopting technology, DKK per tCO2e (scaled by reduction potential)"
		rEOPplant_costs[Techplant,plant_sectors,Emmtype,t] 						"Costs of adopting technology, DKK per tCO2e (scaled by reduction potential)"
		rEOPplant_input[Techplant,plant_sectors,Emmtype,t] 						"Input into the normal distribution to determine technology penetration"
		uEOPplantt[Techplant,plant_sectors,Emmtype,t] 							"Scale parameter in calculation of rEOPplant_input"
		rEOPplant[Techplant,plant_sectors,Emmtype,t]$(tx0[t])					"Share of technology penetration (immediate)"
		j_rEOPplant[Techplant,plant_sectors,Emmtype,t] 							"J-term in determining rEOPplant"
		rEOPplant_preferred[Techplant,plant_sectors,Emmtype,t]	    			"Share of technology penetration (preferred)"
		rEOPplant_actual[Techplant,plant_sectors,Emmtype,t]         			"Share of technology penetration (actual)"

		thetaplant[Techplant,plant_sectors,Emmtype,t,emm]$(tx0[t])				"Reduction potential, pct. of baseline emissions"
		uEOPplant[Emmtype,plant_sectors,t,emm]$(tx0[t])		 					"Factor for reducing emmisions factor"
		qGrossEmmplant[Emmtype,plant_sectors,t,emm_eq]$(tx0[t])     			"Gross non-energy related emissions (excl. agriculture tech)"
		qEmmplantEOP[Emmtype,plant_sectors,t,emm_eq]$(tx0[t]) 					"Technology induced reduction of agricultural emissions"

		pEOPplant[Techplant,Emmtype,plant_sectors,t]							"Price of agricultural technology, DKK per tCO2e, inflation adjusted"
		shareplantPrice_type[techplant,techtype,t] 								"Share parameter determining share of costs related to capital, energy and materials, respectively"
		shareplantPrice_group[techplant,s,t] 									"Share parameter determining share of costs to materials related to sector s (sender)"

		vEOPCostplant_IO[Techplant,Emmtype,plant_sectors,s,t]					"Value of technology induced demand for materials from sector s, billion DKK, inflation and growth-adjusted"
		vRxEEOP_plant[plant_sectors,s,t] 										"Value of total technology induced demand for materials from sector s, billion DKK, inflation and growth-adjusted"
		qRxEEOP_plant[plant_sectors,s,t] 										"Quantity of total technology induced demand for materials from sector s, billion DKK, growth-adjusted"

		qI_EOPCostplant[i,Techplant,Emmtype,plant_sectors,t] 					"Quantity of technology induced investment demand, billion DKK, growth-adjusted"
		vI_EOPCostplant[i,Techplant,Emmtype,plant_sectors,t] 					"Value of technology induced investment demand, billion DKK, inflation and growth-adjusted"
		qI_EOPCostplant_actual[i,Techplant,Emmtype,plant_sectors,t]             ""

		vEOPcost_plant_tot[plant_sectors,t]										"Techonology specific total cost of agricultural technology, billion DKK, inflation and growth-adjusted"
		vEOPCostplant_TechTot[Techplant,Emmtype,plant_sectors,t] 				"Total cost of agricultural technology, billion DKK, inflation and growth-adjusted"

		vTech_subsidy_plant[Techplant,EmmType,plant_sectors,t]					"Total subsidy payments to firms implementing abatement technology, plant sectors"
		tech_subsidy_plant[Techplant,Emmtype,plant_sectors,t]					"Subsidy for abatement technologies in plant sectors"
	;

	#-------------------------------------------------------------------------------------------------------------------
	# Agricultural non-energy related emissions
	#-------------------------------------------------------------------------------------------------------------------

	$GROUP G_plant_emmissions_q 
	   	qEmmAgrxE[emmtype_,Agri_sectors,t,emm_eq]                                                        	"Non-energy related agricultural emissions, measured in kilotonnes"
    ;

    $GROUP G_agr_emissions_u
      	uEmmAgrxE[emmtype,Agri_sectors,t,emm_eq]$(d1EmmAgrxE[emmtype,Agri_sectors,t,emm_eq])             	"Emission-factor on non-energy related agricultural emissions, measured in kilotonnes per emitting unit"
    ;

$ENDIF

# ======================================================================================================================
# Compiling groups of endogenous and exogenous values
# ======================================================================================================================

$IF %stage% == "groupcompilation":

 	$GROUP G_plant_non_flat_initial_values
  		# qPlant$(Plant_pK[Plant_]) 
			qPlant_capital
	    qLand
	    qLand_nonproductive
	    pLand
	    qPlant$(sameas[plant_,'land'])
	    jvtLand
	    tHectareSubsidy
	    tSubOtherPerHectareSchemes
	    tSubOrganic
			tAfforestationPerHa
			tCO2_emm_plant
  	;

	$PGROUP PGROUP_production_plant_NonFlat_Dummies
	  	d1EmmAgrxE
  	;


	$GROUP G_plant_EOP_endo
		uEOPplant[Emmtype,plant_sectors,t,emm]$(tx0[t])						
		qGrossEmmplant[Emmtype,plant_sectors,t,emm_eq]$(tx0[t]) 
  		qEmmplantEOP[Emmtype,plant_sectors,t,emm_eq]$(tx0[t] and sum(Techplant, sum(emm,d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]))) 	
  		vEOPCostplant_IO[Techplant,Emmtype,plant_sectors,s,t]$(tx0[t] and sum(emm, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]))							
  		vEOPcost_plant_tot[plant_sectors,t]$(tx0[t] and sum(Techplant, sum(Emmtype, sum(emm, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]))))												
  		rEOPplant_preferred[Techplant,plant_sectors,Emmtype,t]$(tx0[t] and sum(emm, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]))	                                     
  		rEOPplant_actual[Techplant,plant_sectors,Emmtype,t]$(tx0[t] and sum(emm, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]))	  	                                  
   		vRxEEOP_plant[plant_sectors,s,t]$(tx0[t] and sum(Techplant, sum(Emmtype, sum(emm,d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]))))
		qRxEEOP_plant[plant_sectors,s,t]$(tx0[t] and sum(Techplant, sum(Emmtype, sum(emm,d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]))))
		rEOPplant_gains[Techplant,plant_sectors,Emmtype,t]$(tx0[t] and sum(emm, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]))	  
		rEOPplant_costs[Techplant,plant_sectors,Emmtype,t]$(tx0[t] and sum(emm, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]))	  
		rEOPplant_input[Techplant,plant_sectors,Emmtype,t]$(tx0[t] and sum(emm, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]))	  
		vEOPCostplant_TechTot[Techplant,Emmtype,plant_sectors,t]$(tx0[t] and sum(emm, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]))
		rEOPplant[Techplant,plant_sectors,Emmtype,t]$(tx0[t] and sum(emm, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]))	  			
		qI_EOPCostplant[i,Techplant,Emmtype,plant_sectors,t]$(tx0[t] and sameas(i,'iM') and sum(emm, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]))
		vI_EOPCostplant[i,Techplant,Emmtype,plant_sectors,t]$(tx0[t] and sameas(i,'iM') and sum(emm, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]))
		qI_EOPCostplant_actual[i,Techplant,Emmtype,plant_sectors,t]$(tx0[t] and sameas(i,'iM') and sum(emm, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]))
	;

	$GROUP G_plant_EOP_exo
		thetaplant[Techplant,plant_sectors,Emmtype,t,emm]$(tx0[t] and d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm])								
		pEOPplant[Techplant,Emmtype,plant_sectors,t]$(tx0[t] and sum(emm, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]))									
		rEOPplant_preferred[Techplant,plant_sectors,Emmtype,t]$(t0[t] and sum(emm, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]))	                 
		rEOPplant_actual[Techplant,plant_sectors,Emmtype,t]$(t0[t] and sum(emm, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]))                           
 		shareplantPrice_type[techplant,techtype,t]
		shareplantPrice_group[techplant,s,t]
		uEOPplantt[Techplant,plant_sectors,Emmtype,t]$(tx0[t] and sum(emm, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]))
		j_rEOPplant[Techplant,plant_sectors,Emmtype,t]$(tx0[t] and sum(emm, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]))
		vTech_subsidy_plant[Techplant,EmmType,plant_sectors,t]$(tx0[t] and sum(emm, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]))					
		tech_subsidy_plant[Techplant,Emmtype,plant_sectors,t]		
	;

	$GROUP G_GE_LINKS_PLANT	# Group of links that link this (partial) model with GreenREFORM as a whole in general equilibrium
		qPlant_CET$(Plant_out_top_m[Plant_out] and d1Plant_CET0[Plant_sectors,plant_out,t]) 
		pRxE_ym_plant$(d1RxE_ym[plant_sectors,s,t])
	  	pPlant$(plant_bottom[Plant_]) # LINK 
	  	pPlant$(ChemNPK[Plant_]) # LINK 
	  	pPlant_base$(sum(s,input2plant[s,plant_sectors,chemNPK] and d1RxE_ym[plant_sectors,s,t]) and d1Plant[plant_sectors,chemNPK,t])
	  	pPlantxInst
	;

	$GROUP G_GE_LINKS_EMMI_PLANT 
	    uEmmProdxE$(d1EmmProdxE_overlap[s,t,emm] and plant_sectors_s[s])	# Adapt CGE-emissioncoefficients to hit emissions from agricultural module
	;

	$GROUP G_GE_LINKS_PLANT G_GE_LINKS_PLANT$(tx0[t]);


	$GROUP G_GE_ENDOGENIZE_PLANT	# Group that lets agriculture sectors of production.gms be "constantly recalibrated" to hit submodel inputs and outputs 
  		sRxE_ym$(plant_sectors_s[r] and d1rXe_ym[r,s,t])
	    uProd$(plant_sectors_sp[sp] and d1prod[prd,sp,t] and prdCapital[prd] and t.val > t1.val)			#In first period, t1, capital stock is determined by capital accumulation in last data year. After that it can be determined by the agricultural module
 	    uProd$(plant_sectors_sp[sp] and d1prod[prd,sp,t] and prdFin[prd]) # and sameas[k,'iM']
 	    uProd$(Plant_sectors_sp[sp] and d1prod[prd,sp,t] and prdL[prd])
 	    uEP$(plant_sectors_sp[sp] and d1EP[purpose,sp,t])
 	    markup$(plant_sectors_s[s] and d1vY_CET[out,s,t]) 
 	    tK$(plant_sectors_s[s] and sameas[k,'iB'])			
 	    vFirmDebtFromOtherModules$(plant_sectors_sp[sp])	# Adding debt from crop production to debt variables in CGE-model.
	;

	$GROUP G_GE_ENDOGENIZE_PLANT G_GE_ENDOGENIZE_PLANT$(tx0[t]);

	$GROUP G_CO2plant_endo 
		    vCO2_plant$(tx0[t] and sum(emmtype, d1EmmAgrxE[emmtype,plant_sectors,t,'CO2e'] and emmtype2plant_(emmtype,plant_) and reguleringsgrundlag[emmtype])) # and not d1exclude[plant_]) 
	;

	$GROUP G_production_plant_endo
    	pPlant_CET0$(d1Plant_CET0[Plant_sectors,plant_out,t]) #E_pPlant_CET0
    	qPlant_CET$((Plant_outNest[Plant_out]) and d1Plant_CET0[Plant_sectors,plant_out,t]) #E_pPlant_CET_nest
    	pPlant_CET$((plant_out_top[Plant_out] or sameas[plant_out,'netprod']) and d1Plant_CET0[Plant_sectors,plant_out,t]) #E_pPlant_CET SIKKER
			pPlant$(tx0[t] and (sameas[Plant_,'netprod'] or PlantNest[Plant_] or IOnestsPlant[Plant_] or sameas[Plant_,'land'] or plant_pK[Plant_]))
			pPlant_uc$(tx0[t] and d1Plant[plant_sectors,plant_pK,t])
    	pTobinsQ_plant #E_pTobinsQ_plant E_pTobinsQ_plant_terminal
    	qPlant
    	qRxE_ym_plant$(d1RxE_ym[Plant_sectors,s,t]) # E_qRxE_ym_plant
    	pLand #E_pLand_End E_pLand
    	pLand_nonproductive #E_pLand_nonproductive E_pLand_nonproductive_end

		vtCAP$(plant_sectors_s[s])
		vtHectareSubsidy_prod
		vtHectareSubsidy_nonprod
		vtAndenArealStoette
		vtSubOrganic
		vtProduktionsStoetteCAP
		vtCAP_other
		vtCAP_top$(plant_sectors_s(s))
		vtCAP_uc
		vtCAP_lumpsum
    	vtPerHectareBottomDeduction$(tx0[t]) #E_vtPerHectareBottomDeduction
		adj_vtCAP_other

	    # Operating surplus II
    	vDBII #E_DBII

	    # Installation cost
     	qKInstcost_land #E_qPlant_instcostland
      	dInstcostlandT #E_qPland_dInstcostlandT
      	dInstcostlandTp1 #E_qPland_dInstcostlandTp1

		# Emissions
 		qEmmAgrxE$(d1EmmAgrxE[emmtype_,Agri_sectors,t,emm_eq]  and emmtype[emmtype_] and not (sameas(emmtype_,'EntericFermentation') or sameas(emmtype_,'ManureManagement') or sameas(emmtype_,'GrazingAnimals') or sameas(emmtype_,'N2Oindirect'))), 
		G_plant_EOP_endo
		#CO2e-tax
		G_CO2plant_endo
	;

	# $GROUP G_production_plant_endo G_production_plant_endo$(tx0[t]), -pPlant$(t1[t] and sameas[plant_,'TransportCapital']);
	$GROUP G_production_plant_endo G_production_plant_endo$(tx0[t]), -pPlant_uc$(t1[t] and sameas[plant_pK,'TransportCapital']);

	$GROUP G_production_plant_exo
		G_agr_values_plant 
		G_agr_other_plant
		G_plant_taxes_and_subsidies
		G_plant_EOP_exo

		# Plant 
		pPlant_CET0$(not d1Plant_CET0[Plant_sectors,plant_out,t]) 
		qPlant_CET$(not ((Plant_out_top_nm[Plant_out] or Plant_outNest[Plant_out]) and d1Plant_CET0[Plant_sectors,plant_out,t])) # Top or nests incl. netprod
		pPlant_CET$(not (plant_out_top[Plant_out] and d1Plant_CET0[Plant_sectors,plant_out,t]))
		pPlant$(not (sameas[Plant_,'netprod'] or PlantNest[Plant_] or IOnestsPlant[Plant_] or sameas[Plant_,'land'] or plant_pK[Plant_]))
		pPlant_base$(t0[t] and sum(s,input2plant[s,plant_sectors,chemNPK] and d1RxE_ym[plant_sectors,s,t]) and d1Plant[plant_sectors,chemNPK,t])
		qRxE_ym_plant$(not d1RxE_ym[Plant_sectors,s,t]) #E_qRxE_ym_plant
		pRxE_ym_plant$(d1RxE_ym[plant_sectors,s,t] and t0[t])
		
		qPlant$(t0[t] and d1Plant[plant_sectors,plant_,t] and sameas[plant_,'land'])
		qLand  # Total quantity of available land
		pPlant_uc$(tDataEnd[t]) #Used as scaling factor - and exogenous when we move starting year from last data-year
		pPlant_uc$(t1[t] and sameas[plant_pK,'TransportCapital']) #Shadow-price argument, cf. production_agr_ani.gms

		# Non-productive land is exogenous     
		pLand$(t0[t]) 
		pLand_nonproductive$(t0[t])
		pLandvalueFromUnobserved$(tx0[t])
		pReturnPerHa_alt_landallocation                                                                                                           

		# External
		EKtax$(plant_sectors_sp[sp])
		rDepr$(plant_sectors_s[s])
		pI_s$(plant_sectors_s[s])
		rBonds$(plant_sectors_s[s]) 
		sDebt2k$(plant_sectors_s[s])
		tCorp 
		rFirms$(plant_sectors_sp[sp])
		vtNetProductionRest$(plant_sectors_s_[s_])
		qKInstCost$(plant_sectors_s[s])
		thetaProd$(plant_sectors_sp[sp] and prdL[prd])

		pPlant$(chemNPK[plant_] and t0[t])

		uEmmAgrxE$(d1EmmAgrxE[emmtype,Agri_sectors,t,emm_eq] and not (sameas(emmtype,'EntericFermentation') or sameas(emmtype,'ManureManagement') or sameas(emmtype,'GrazingAnimals') or sameas(emmtype,'N2Oindirect')))
		sLeachOf2TotalN
		qLU12$(tx0[t] and land12_OC_CL[land12])

		vtBotDed$(plant_sectors_s[s])
		pREa$(d1pREa[purpose,energy19a,s,t] and plant_sectors_s[s])
		qREa$(d1pREa[purpose,energy19a,s,t] and plant_sectors_s[s])
    	
		pRE_base$(d1pRE_base[purpose,energy19,r,t] and plant_sectors_s[r]) 
		pRE_base_marg$(d1pRE_base[purpose,energy19,r,t] and plant_sectors_s[r]) 
		qREgj$(d1PRE_base[purpose,energy19,r,t] and plant_sectors_s[r])

		pPlant$(t1[t] and sameas[plant_,'TransportCapital'])
		qPlant_CET$((Plant_out_top_nm[Plant_out]) and d1Plant_CET0[Plant_sectors,plant_out,t]) #Determined in prod_agr
 
		vtEAFG_RE$(d1EAFG_RE[purpose,energy19,r,t] and plant_sectors_s[r])

		#Link 
		pRxE_ym_plant$(tx0[t] and d1RxE_ym[plant_sectors,s,t])
		jqI_s$(tx0[t] and plant_sectors_s[s])
  		  fKInstCost$(tx0[t] and plant_sectors_s[s])
	;

    $GROUP G_plant_report_endo
    	G_agr_report_plant$(tx0[t])
			pLand_nonproductive_report$(tx0[t] and (sameas[landallocation,'skov'] or sameas[landallocation,'solceller'] or sameas[landallocation,'VaadLagtLavbund'] or sameas[landallocation,'landvind']) and not sameas[plant_sectors,'01020'])    
    ;

    $GROUP G_plant_report_exo 
    	# E_pLand_avg
    	qLand, pLand, pLand_nonproductive_report, qLand_Nonproductive
    	pReturnPerHa_alt_landallocation
    	pLandvalueFromUnobserved
    	tLand_Photovoltaics
    	tLand 
    	rFirmsLand
    	pLostFutureWoodprod[plant_sectors,t] ""
	 		qPlant$(tx0[t] and d1Plant[plant_sectors,plant_,t]) # Quantity of animal production, used in calculating the value of animal production
  		pPlant$(tx0[t] and d1Plant[plant_sectors,plant_,t]) 
			vPlant$(tx0[t] and d1Plant[plant_sectors,plant_,t]) # Value of animal production, used in calculating the value of animal production
  		vtEAFG_RE$(tx0[t] and d1EAFG_RE[purpose,energy19,r,t]) # Energy taxes on animal production
  		vCO2_plant$(tx0[t]) # CO2e tax on non-energy related emissions in plant production
  		vEOPCostPlant_TechTot$(tx0[t] and sum(emm,d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm])) # Total cost of abatement technology in plant production
			vTech_subsidy_plant$(tx0[t] and sum(emm,d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]))
  		tCO2_emm_plant$(tx0[t]) # CO2 tax on non-energy related emissions in plant production
  		pPlant_CET_baseline[plant_sectors,'out_other',t]$(tx0[t]) # Baseline CET price for plant production
  		qPlant_CET_baseline[ani_sectors,'out_other',t]$(tx0[t]) # Baseline CET quantity for animal production
  		qEmmAgrxE$(tx0[t] and d1EmmAgrxE[emmtype_,agri_sectors,t,emm_eq]) # Total non-energy related emissions in animal production
  		pRE_base$(tx0[t] and d1pRE_base[purpose,energy19,r,t]) # Average energy prices in animal production
  		pRE_base_marg$(tx0[t] and d1PRE_base[purpose,energy19,r,t]) # Average energy prices in animal production
			qREgj$(tx0[t] and d1PRE_base[purpose,energy19,r,t]) # Quantity of energy used in animal production
  		pREa$(tx0[t] and (d1pREa[purpose,energy19a,s,t] or d1pREown[purpose,energy19a,s,t])) # Average energy prices in animal production
  		qREa$(tx0[t] and (d1pREa[purpose,energy19a,s,t] or d1pREown[purpose,energy19a,s,t])) # Quantity of energy used in animal production
  		vtEAFG_REmarg[purpose,energy19a,r,t]$(tx0[t] and d1EAFG_RE[purpose,energy19a,r,t]) # Marginal energy taxes in animal production
			vtEAFG_RE[purpose,energy19a,r,t]$(tx0[t] and d1EAFG_RE[purpose,energy19a,r,t]) # Energy taxes on animal production
  		vtCO2_RE[purpose,energy19a,r,t]$(tx0[t] and d1CO2_RE[purpose,energy19a,r,t]) # CO2 tax on energy in animal production
  		vtCO2_REmarg[purpose,energy19,r,t]$(tx0[t] and d1CO2_RE[purpose,energy19,r,t]) # Marginal CO2 tax on energy in animal production
  		vtCO2_ETS_marg$(tx0[t]) 
  		tqRE[purpose,energy19,r,t]$(tx0[t] and (d1pRE_base[purpose,energy19,r,t] or d1pREown[purpose,energy19,r,t])) # Tax on energy in animal production
  		vtNetProductionRest$(tx0[t])
  		vtCAP_top$(tx0[t])
  		vtLand$(tx0[t])
  		vtFirmsWeight$(tx0[t]) 
  		vtCO2_ETS$(tx0[t])
  		vtL$(tx0[t])
  		pPlant_CET$(tx0[t])
  		pPlant_CET0$(tx0[t])
  		qPlant_CET$(tx0[t])
			vDBII$(tx0[t])
			qLand$(tx0[t] or t0[t])
			qY_CETgross$(tx0[t] and plant_sectors_s[s])
			pY_CET$(tx0[t] and plant_sectors_s[s])
			qLand_Nonproductive$(tx0[t])
			pLand_nonproductive$(tx0[t])
			qY_CET$(tx0[t] and plant_sectors_s[s] and d1vY_CET[out,s,t]), qY_CETgross$(tx0[t] and plant_sectors_s[s] and d1vY_CET[out,s,t]), pY_CET$(tx0[t] and plant_sectors_s[s] and d1vY_CET[out,s,t])
    ;

    $GROUP G_baseline_plant
    	pPlant_CET
    	qPlant_CET
    ;

$ENDIF


# ======================================================================================================================
# Equations
# ======================================================================================================================

$IF %stage% == "equations":

$BLOCK B_production_agr_plant

  # ---------------------------------------------------------------------------------------------------------------------
  # Plant production structure
  # ---------------------------------------------------------------------------------------------------------------------
	
  	E_pPlant_CET0[Plant_sectors,Plant_out,Plant_outt,t]$(tx0[t] and Plant2Out[Plant_out,Plant_outt] and d1Plant_CET0[Plant_sectors,Plant_outt,t]).. 
  		qPlant_CET[Plant_sectors,Plant_outt,t] =E= uPlant_CET[Plant_sectors,Plant_outt,t] * 
	  		#  (pPlant_CET0[Plant_sectors,Plant_outt,t]/(1-tCorp[t]$(d1Plant_CET0[Plant_sectors,plant_outt,t] and plant_out_top_nm[plant_outt]))/pPlant_CET0[Plant_sectors,Plant_out,t])**eCET_Plant[Plant_sectors,Plant_out] *
  		(pPlant_CET0[Plant_sectors,Plant_outt,t]/pPlant_CET0[Plant_sectors,Plant_out,t])**eCET_Plant[Plant_sectors,Plant_out] * qPlant_CET[Plant_sectors,Plant_out,t]; 

  	# CET split budget constraint 
  	E_pPlant_CET_nest[Plant_sectors,Plant_out,t]$(tx0[t] and plant_outNest(plant_out)).. 
  		pPlant_CET0[Plant_sectors,Plant_out,t]*qPlant_CET[Plant_sectors,Plant_out,t] =E= sum(Plant_outt$(Plant2Out[Plant_out,Plant_outt] and d1Plant_CET0[Plant_sectors,Plant_outt,t]), 
  			#  pPlant_CET0[Plant_sectors,Plant_outt,t]/(1-tCorp[t]$(d1Plant_CET0[Plant_sectors,plant_outt,t] and plant_out_top_nm[plant_outt]))*qPlant_CET[Plant_sectors,Plant_outt,t]);  # The rather lenghty dollar-condition takes into account that corporate taxes are not paid on non-market output
  			pPlant_CET0[Plant_sectors,Plant_outt,t]*qPlant_CET[Plant_sectors,Plant_outt,t]);  # The rather lenghty dollar-condition takes into account that corporate taxes are not paid on non-market output

  	E_pPlant_CET[Plant_sectors,plant_out_top,t]$(tx0[t] and d1Plant_CET0[Plant_sectors,Plant_out_top,t])..
  		pPlant_CET[Plant_sectors,plant_out_top,t] =E= (1+plant_markup[Plant_sectors,plant_out_top,t]) * pPlant_CET0[Plant_sectors,plant_out_top,t];

	# Computer "average" output price
	E_pPlant_CET_netprod[Plant_sectors,t]$(tx0[t] and d1Plant_CET0[Plant_sectors,'netprod',t]).. 
		pPlant_CET[Plant_sectors,'netprod',t]*qPlant_CET[Plant_sectors,'netprod',t] =E= sum(Plant_out_top, pPlant_CET[Plant_sectors,Plant_out_top,t] *qPlant_CET[Plant_sectors,Plant_out_top,t]);


  	# CET links - quantities and prices 
  	E_qPlant_CET_[Plant_sectors,t]$(tx0[t]).. 
  		qPlant[Plant_sectors,'netprod',t] =E= qPlant_CET[Plant_sectors,'netprod',t]; 
  	E_pPlant_CET_[Plant_sectors,t]$(tx0[t]).. 
  		pPlant[Plant_sectors,'netprod',t] =E= pPlant_CET0[Plant_sectors,'netprod',t];

	E_pPlant_netprod[Plant_sectors,t]$(tx0[t]).. pPlant[Plant_sectors,'netprod',t]*qPlant[Plant_sectors,'netprod',t] 
											 =E= pPlant[Plant_sectors,'grossprod',t]*qPlant[Plant_sectors,'netprod',t] 
											   + vtBotDed[Plant_sectors,t]*d1tREmarg[Plant_sectors]
											   # Account for marginal vs. average energy prices
											   + sum((purpose,energy19)$(d1pRE_base[purpose,energy19,plant_sectors,t]),(pRE_base[purpose,energy19,plant_sectors,t]-pRE_base_marg[purpose,energy19,plant_sectors,t])*qREgj[purpose,energy19,plant_sectors,t])			
											   + sum((purpose,energy19)$(d1pREa[purpose,energy19,Plant_sectors,t] and eNotInEnergyNest[purpose,energy19,Plant_sectors,t]), pREa[purpose,energy19,Plant_sectors,t]*qREa[purpose,energy19,Plant_sectors,t])
											   + vCO2_plant[plant_sectors,'Netprod',t]
											   + vtNetproductionRest[plant_sectors,t]
											   + vtCAP_top[plant_sectors,t]
											   + sum((Techplant,Emmtype)$(emmtype2plant_[emmtype,'netprod'] and sum(emm, d1Thetaplant[Techplant,plant_sectors,emmtype,t,emm])), vEOPCostplant_TechTot[Techplant,emmtype,plant_sectors,t])
										       - sum((Techplant,emmtype)$(emmtype2plant_[emmtype,'netprod'] and sum(emm,d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm])), vTech_subsidy_plant[Techplant,EmmType,plant_sectors,t])
											   #  - sum((purpose,energy19)$(d1tRE[purpose,energy19,plant_sectors,t]), vtCalibENS[purpose,energy19,plant_sectors,t])
											   ;

	E_qPlant_netprod[Plant_sectors,t]$(tx0[t]).. qPlant[Plant_sectors,'netprod',t] =E= qPlant[Plant_sectors,'grossprod',t] - sum(k, qKInstCost[k,Plant_sectors,t]) - qKInstcost_land[plant_sectors,t];

	# Installation costs on land. We assume symmetric quadratic installation costs 
	E_qPlant_instcostland[plant_sectors,t]$(tx0[t] and d1plant[plant_sectors,'land',t])..
		qKInstcost_land[plant_sectors,t] 		=E= uKinstcost_land[plant_sectors,t]/2 * thetaJ[plant_sectors,t] * qPlant[plant_sectors,'land',t-1] * sqr(( qPlant[plant_sectors,'land',t] - qPlant[plant_sectors,'land',t-1])/qPlant[plant_sectors,'land',t-1]);
	# Derivatives of installation-cost, used in user-cost 
	E_qPland_dInstcostlandT[plant_sectors,t]$(tx0[t] and d1plant[plant_sectors,'land',t])..
		dInstcostlandT[plant_sectors,t] 		=E= uKinstcost_land[plant_sectors,t] * thetaJ[plant_sectors,t] * (qPlant[plant_sectors,'land',t] - qPlant[plant_sectors,'land',t-1])/qPlant[plant_sectors,'land',t-1];

	E_qPland_dInstcostlandTp1[plant_sectors,t]$(tx0E[t] and d1plant[plant_sectors,'land',t])..
		dInstcostlandTp1[plant_sectors,t+1]*fq 	=E= -uKinstcost_land[plant_sectors,t]/2 * thetaJ[plant_sectors,t+1]*fq * sqr((qPlant[plant_sectors,'land',t+1] - qPlant[plant_sectors,'land',t])/ qPlant[plant_sectors,'land',t])
		 									       -uKinstcost_land[plant_sectors,t]   * thetaJ[plant_sectors,t+1]*fq * (qPlant[plant_sectors,'land',t+1]- qPlant[plant_sectors,'land',t])/qPlant[plant_sectors,'land',t];

	# Budget Constraint - Plant aggregates 
    E_pPlant_nests[Plant_sectors,PlantNest,t]$(tx0[t] and d1Plant[Plant_sectors,PlantNest,t])..
        pPlant[Plant_sectors,PlantNest,t]*qPlant[Plant_sectors,PlantNest,t] =E= (sum(Plant_$(PlantNest2inputs_[PlantNest,Plant_] and d1Plant[plant_sectors,plant_,t]), pPlant[Plant_sectors,Plant_,t]*qPlant[Plant_sectors,Plant_,t]))$(not sameas[PlantNest,'LandChem']) #We have to make an exception for the land-nest where land is ultimo dated
                                                                            	+ ((pPlant[plant_sectors,'land',t]*qPlant[plant_sectors,'land',t-1])$(d1plant[Plant_sectors,'land',t-1]) + sum(plant_$(PlantNest2inputs_[PlantNest,Plant_] and not sameas[plant_,'Land'] and d1Plant[plant_sectors,plant_,t]), pPlant[plant_sectors,plant_,t]*qPlant[plant_sectors,plant_,t]))$(sameas[PlantNest,'LandChem']) #The exception for land, with land being ultimo-dated
                                                                            	+ vCO2_plant[plant_sectors,PlantNest,t]$emmtypeinNest[PlantNest]
                                                                            	+ sum((Techplant,Emmtype)$(emmtype2plant_(emmtype,plantnest) and sum(emm, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm])), vEOPCostplant_TechTot[Techplant,Emmtype,plant_sectors,t]$emmtypeinNest[PlantNest])
                                                                            	- sum((Techplant,Emmtype)$(emmtype2plant_(emmtype,plantnest) and sum(emm, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm])), vTech_subsidy_plant[Techplant,EmmType,plant_sectors,t])$emmtypeinNest[PlantNest] ;  

	#  FOC - Plant Production inputs
	E_qPlant_top[Plant_sectors,Plant_,Plantnest,t]$(tx0[t] and PlantNest2inputs_[PlantNest,Plant_] and d1Plant[plant_sectors,plant_,t] and sameas[plantNest,'grossprod']).. 
		TFPPlant[plant_sectors,t] *qPlant[Plant_sectors,Plant_,t] =E= uPlant[Plant_sectors,Plant_,t] * (pPlant[Plant_sectors,Plant_,t] / pPlant[Plant_sectors,PlantNest,t])**(-ePlant[Plant_sectors,PlantNest,t])*qPlant[Plant_sectors,PlantNest,t];


	E_qPlant_nottop[Plant_sectors,Plant_,Plantnest,t]$(tx0[t] and PlantNest2inputs_[PlantNest,Plant_] and d1Plant[plant_sectors,plant_,t] and not Leontief_PlantNest[plantNest] and not sameas[plant_,'land'] and not sameas[plantNest,'grossprod']).. 
		qPlant[Plant_sectors,Plant_,t] =E= uPlant[Plant_sectors,Plant_,t] * (pPlant[Plant_sectors,Plant_,t] / pPlant[Plant_sectors,PlantNest,t])**(-ePlant[Plant_sectors,PlantNest,t])*qPlant[Plant_sectors,PlantNest,t];


	E_qPlant_nottop_Leontief_plantnest[plant_sectors,plant_,plantnest,t]$(tx0[t] and PlantNest2inputs_[PlantNest,Plant_] and d1Plant[plant_sectors,plant_,t] and Leontief_PlantNest[plantNest] and not sameas[plant_,'land'] and not sameas[plant_,'TransportCapital'])..
		#  qPlant[plant_sectors,plant_,t] =E= uPlant[plant_sectors,plant_,t] * (pPlant[plant_sectors,plant_,t]/pPlant[plant_sectors,plantNest,t])**(-0.5) * qPlant[PLant_sectors,plantnest,t];
		qPlant[plant_sectors,plant_,t] =E= uPlant[plant_sectors,plant_,t] * qPlant[PLant_sectors,plantnest,t];


	#Equation only works on tx1. This is due to us having a Leontief-nest with two capital goods. In the first period, without non-zero elasticity of substitution, user-cost can't be determined as the shadow price of capital for both simultaneously. 
	#To fix this the equation only runs on tx1 for transport capital, and user-cost on transport capital is fixed in first period. This means that user-cost on Private Machines become the total shadow price of both machines and transport capital in first period.
	#Finally, An equation is added in the static calibration to calibrate uPlant[plant_sectors,'TransportCapital'].
	E_qPlant_nottop_Leontief_plantnest_TC[plant_sectors,plant_,plantnest,t]$(tx1[t] and PlantNest2inputs_[PlantNest,Plant_] and d1Plant[plant_sectors,plant_,t] and Leontief_PlantNest[plantNest] and not sameas[plant_,'land'] and sameas[plant_,'TransportCapital'])..
		#  qPlant[plant_sectors,plant_,t] =E= uPlant[plant_sectors,plant_,t] * (pPlant[plant_sectors,plant_,t]/pPlant[plant_sectors,plantNest,t])**(-0.5) * qPlant[PLant_sectors,plantnest,t];
		qPlant[plant_sectors,plant_,t] =E= uPlant[plant_sectors,plant_,t] * qPlant[PLant_sectors,plantnest,t];


	#We model land as ultimo-dated
	E_qPlant_land[Plant_sectors,Plantnest,t]$(tx0[t] and PlantNest2inputs_[PlantNest,'land'] and d1Plant[plant_sectors,'land',t])..
		thetaJ[plant_sectors,t] * qPlant[Plant_sectors,'Land',t-1] =E= uPlant[Plant_sectors,'land',t] * qPlant[Plant_sectors,PlantNest,t];


	# This is not a terminal-condition but merely fills in land in the terminal period. 
	E_qPlant_land_End[Plant_sectors,Plantnest,t]$(tEnd[t] and PlantNest2inputs_[PlantNest,'land'] and d1Plant[plant_sectors,'land',t])..
	 	qPlant[Plant_sectors,'land',t] =E= qPlant[plant_sectors,'Land',t-1];

	# Budget constraint - Plant IO inputs
	E_pPlant_ym[Plant_sectors,Plant_,t]$(tx0[t] and IOnestsPlant[Plant_] and d1Plant[plant_sectors,plant_,t])..
		pPlant[Plant_sectors,Plant_,t]*qPlant[Plant_sectors,Plant_,t] =E= sum(s$(input2plant[s,Plant_sectors,Plant_] and d1RxE_ym[Plant_sectors,s,t]), pRxE_ym_plant[Plant_sectors,s,t]*qRxE_ym_plant[Plant_sectors,s,t]);
	
	#  FOC - Plant IO inputs
	E_qRxE_ym_plant[Plant_sectors,Plant_,s,t]$(tx0[t] and input2plant[s,Plant_sectors,Plant_] and d1RxE_ym[Plant_sectors,s,t] and not chemNPK[Plant_]).. 
		qRxE_ym_plant[Plant_sectors,s,t] =E= sRxE_ym_plant[Plant_sectors,s,t] * (pRxE_ym_plant[Plant_sectors,s,t] / pPlant[Plant_sectors,Plant_,t])**(-ePlant[Plant_sectors,Plant_,t]) * qPlant[Plant_sectors,Plant_,t];

	#qRxE_ym_plant is computed as a weighted average of chemicals and NPK 
	E_qRxE_ym_plant_chemNPK[Plant_sectors,s,t]$(tx0[t] and sum(chemNPK,d1Plant[plant_sectors,chemNPK,t]) and sum(chemNPK,input2plant[s,plant_sectors,chemNPK]) and d1RxE_ym[Plant_sectors,s,t])..
		qRxE_ym_plant[plant_sectors,s,t] =E= pPLant[plant_sectors,'NPK',t]/pRxE_ym_plant[plant_sectors,s,t] * qPlant[plant_sectors,'NPK',t] + pPlant[plant_sectors,'Chemicals',t]/pRxE_ym_plant[Plant_sectors,s,t]*qPlant[plant_sectors,'Chemicals',t]; 

	# Definition of user cost
  	# E_pK_plant[plant_sectors,plant_pK,k,t]$(tx0E[t] and d1K[k,plant_sectors,t] and agri2k[plant_pK,k] and d1plant[plant_sectors,plant_pK,t])..
		# pPlant[plant_sectors,plant_pK,t+1]*fp*(1-tCorp[t+1]) =E= 
  	E_pPlant_uc[plant_sectors,plant_pK,k,t]$(tx0E[t] and d1K[k,plant_sectors,t] and agri2k[plant_pK,k] and d1plant[plant_sectors,plant_pK,t])..
		pPlant_uc[plant_sectors,plant_pK,t+1]*fp*(1-tCorp[t+1]) =E= 

  			# Tobin's q today and tomorrow
  			pTobinsQ_plant[plant_sectors,plant_pK,t] * (1+rFirms[plant_sectors,t+1]) - (1-rDepr[k,plant_sectors,t+1]) * pTobinsQ_plant[plant_sectors,plant_pK,t+1]*fp
  			# Production tax on capital
        	+ (1-tCorp[t+1]) * tK_plant[k,plant_sectors,t+1] * pI_s[k,plant_sectors,t+1]*fp
        	# Tax shield
        	- ((rFirms[plant_sectors,t+1] - rBonds[plant_sectors,'2025'] * (1-tCorp[t+1])) * sDebt2k[k,plant_sectors,t] * pI_s[k,plant_sectors,t])$(t.val<2025)
        	- ((rFirms[plant_sectors,t+1] - rBonds[plant_sectors,t+1] * (1-tCorp[t+1])) * sDebt2k[k,plant_sectors,t] * pI_s[k,plant_sectors,t])$(t.val>=2025)

        	# Discounted value of change in future installation costs from change in investments today
        	+ (1-tCorp[t+1]) * pPlant[plant_sectors,'grossprod',t+1]*fp * dKinstCost2dK[k,plant_sectors,t]
        	# Added term to correct for difference between forward looking   
  			+ jpK_plant[plant_sectors,plant_pK,t+1];
  		 

    E_pTobinsQ_plant[plant_sectors,plant_pK,k,t]$(tx0E[t] and d1K[k,plant_sectors,t] and agri2k[plant_pK,k] and d1plant[plant_sectors,plant_pK,t])..
    	pTobinsQ_plant[plant_sectors,plant_pK,t] =E= pI_s[k,plant_sectors,t] - pI_s[k,plant_sectors,t]*EKtax[k,plant_sectors,t]
    		+ pPlant[plant_sectors,'grossprod',t] * (1-tCorp[t]) * dKInstCost2dI[k,plant_sectors,t]
    		+ 1/(1+rFirms[plant_sectors,t+1]) * pPlant[plant_sectors,'grossprod',t+1] * fp * (1-tCorp[t+1]) * dKInstCostLead2dI[k,plant_sectors,t] * qK[k,plant_sectors,t];

    E_pTobinsQ_plant_terminal[plant_sectors,plant_pK,k,t]$(tEnd[t] and d1K[k,plant_sectors,t] and agri2k[plant_pK,k] and d1plant[plant_sectors,plant_pK,t])..
    	pTobinsQ_plant[plant_sectors,plant_pK,t] =E= pI_s[k,plant_sectors,t] - pI_s[k,plant_sectors,t]*EKtax[k,plant_sectors,t]
    		+ pPlant[plant_sectors,'grossprod',t] * (1-tCorp[t]) * dKInstCost2dI[k,plant_sectors,t];

		#Scaling uc and capital for entering in production function
		E_pPlant_pK[plant_sectors,plant_pK,t]$(tx0[t] and d1plant[plant_sectors,plant_pK,t])..
			pplant[plant_sectors,plant_pK,t] =E= pplant_uc[plant_sectors,plant_pK,t]/pplant_uc[plant_sectors,plant_pK,tDataEnd]; 

		E_qPlant_qK[plant_sectors,plant_pK,t]$(tx0[t] and d1plant[plant_sectors,plant_pK,t])..
			qplant[plant_sectors,plant_pK,t] =E= qplant_capital[plant_sectors,plant_pK,t]*pplant_uc[plant_sectors,plant_pK,tDataEnd];


    E_pPlant_land[plant_sectors,t]$(tx0E[t] and d1Plant[plant_sectors,'land',t])..
     	pPlant[plant_sectors,'land',t+1]*fv*(1-tCorp[t+1]) =E= (1+rFirmsLand[plant_sectors,t]) * (1-tCorp[t]) * pPlant[plant_sectors,'grossprod',t] * dInstcostlandT[plant_sectors,t]
     		+ (1-tCorp[t+1])* pPlant[plant_sectors,'grossprod',t+1] * fp * dInstcostlandTp1[plant_sectors,t+1] *fq 
     		+ (1+rFirmsLand[plant_sectors,t]) *pLand[t] - pLand[t+1]*fv
			- ((rFirmsLand[plant_sectors,'2025'] - rBonds[plant_sectors,'2025']*(1-tCorp[t+1])) * sDebt2j[plant_sectors,t] * pLand[t])$(t.val<2025)
			- ((rFirmsLand[plant_sectors,t+1] - rBonds[plant_sectors,t+1]*(1-tCorp[t+1])) * sDebt2j[plant_sectors,t] * pLand[t])$(t.val>=2025)
     		- (1-tCorp[t+1]) * tHectareSubsidy[t+1] *fv
     		+ (1-tCorp[t+1]) * tLand[plant_sectors,t+1] * pLand[t]
     		- (1-tCorp[t+1]) * sum(idxUnobservable,  pLandvalueFromUnobserved[idxUnobservable, plant_sectors,t+1]) 
     		- (1-tCorp[t+1]) * tPerHectareBottomDeduction[t+1] *fv

    	# A CO2-tax per unit of land is levied on farmers 
     		+ (vCO2_plant[plant_sectors,'land',t+1]*fv/qPlant[plant_sectors,'land',t])$(d1EmmAgrxE['Mineralization',plant_sectors,t,'CO2e'] or d1EmmAgrxE['Other',plant_sectors,t,'CO2e'] or d1EmmAgrxE['CropResidues',plant_sectors,t,'CO2e']) 
     		+ sum((Techplant,Emmtype)$(emmtype2plant_[emmtype,'land'] and sum(emm, d1Thetaplant[Techplant,plant_sectors,emmtype,t,emm])), vEOPCostplant_TechTot[Techplant,Emmtype,plant_sectors,t+1]*fv/qPlant[plant_sectors,'land',t])$(d1EmmAgrxE['Mineralization',plant_sectors,t,'CO2e'] or d1EmmAgrxE['Other',plant_sectors,t,'CO2e'])
     		- sum((Techplant,Emmtype)$(emmtype2plant_[emmtype,'land'] and sum(emm, d1Thetaplant[Techplant,plant_sectors,emmtype,t,emm])), vTech_subsidy_plant[Techplant,EmmType,plant_sectors,t+1]*fv/qPlant[plant_sectors,'land',t])$(d1EmmAgrxE['Mineralization',plant_sectors,t,'CO2e'] or d1EmmAgrxE['Other',plant_sectors,t,'CO2e'])
     		+ jpK_land[plant_sectors,t+1]
    	;


  # Terminal condition (Land price)
	E_pLand_End[t]$(tEnd[t])..   pLand[t] =E= pLand[t-1];

	# Land market - total amount of land is fixed (implicitly defines common land price)
	E_pLand[t]$(tx0E[t])..
		qLand[t] =E= sum(plant_sectors,qPlant[plant_sectors,'Land',t]);
	
	#In shocks to the model, a bottom-deduction in a CO2e-tax on non-energy emissions from crop production, can be introduced and given per hectare land.
    E_vtPerHectareBottomDeduction[plant_sectors,t]$(tx0[t])..
      	vtPerHectareBottomDeduction[plant_sectors,t] =E= tPerHectareBottomDeduction[t] * (qplant[plant_sectors,'land',t-1] + sum(LandAllocation, qLand_Nonproductive[landallocation,plant_sectors,t-1]));

    # We use the user cost equation to determine the price on non-productive land
    E_pLand_nonproductive[LandAllocation,Plant_sectors,t]$(tx0E[t])..
    	(1-tCorp[t+1]) * (tHectareSubsidy[t+1] 
    		           + tSubOtherPerHectareSchemes[landallocation,plant_sectors,t+1] 
    		           + tPerHectareBottomDeduction[t+1]$(landallocation_m_bundfradrag[LandAllocation]) 
    		           + sum(idxUnobservable$(LandAllocation2idxUnobservable(LandAllocation,idxUnobservable)), pLandvalueFromUnobserved[idxUnobservable,plant_sectors,t+1])) =E= 
		(1+rFirmsLand[plant_sectors,t+1]) * pLand_nonproductive[LandAllocation,Plant_sectors,t] - pLand_nonproductive[LandAllocation,Plant_sectors,t+1]*fv
					   - (rFirmsLand[plant_sectors,t] - rBonds[plant_sectors,t+1]*(1-tCorp[t+1])) * sDebt2j[plant_sectors,t] * pLand_nonproductive[LandAllocation,Plant_sectors,t]
					   + (1-tCorp[t+1]) * tLand[plant_sectors,t+1] * pLand_nonproductive[LandAllocation,Plant_sectors,t];

    E_pLand_nonproducive_End[LandAllocation,Plant_sectors,t]$(tEnd[t])..
    	pLand_nonproductive[LandAllocation,Plant_sectors,t] =E= pLand_nonproductive[LandAllocation,Plant_sectors,t-1];

    # Operating surplus II for Plant_sectors
    E_DBII[plant_sectors,t]$(tx0[t])..
		vDBII[plant_sectors,t] =E= sum(Plant_out$(sameas[plant_out,'netprod'] and d1Plant_CET0[plant_sectors,plant_out,t]), qPlant_CET[plant_sectors,plant_out,t]*pPlant_CET[plant_sectors,plant_out,t]) # Produktionsværdien af market og non-market goods
								 - sum(Plant_$(sameas[Plant_,'Other'] and d1Plant[plant_sectors,Plant_,t]), pPlant[Plant_sectors,Plant_,t]*qPlant[Plant_sectors,Plant_,t]) # Materialeinputs
								 - sum(Plant_$((sameas[Plant_,'Chemicals'] or sameas[Plant_,'NPK'] or sameas[Plant_,'Manure']) and d1Plant[plant_sectors,Plant_,t]), pPlant[Plant_sectors,Plant_,t]*qPlant[Plant_sectors,Plant_,t]) # Gødning og kemikalier
								 - sum(Plant_$((sameas[Plant_,'Fuel'] or sameas[Plant_,'OtherEnergy']) and d1Plant[plant_sectors,Plant_,t]), pPlant[Plant_sectors,Plant_,t]*qPlant[Plant_sectors,Plant_,t]) # Energy
								 + sum((purpose,energy19), vtEAFG_RE[purpose,energy19,Plant_sectors,t]$d1EAFG_RE[purpose,energy19,Plant_sectors,t]) # Energiafgifter
								 - sum(Plant_$(sameas[Plant_,'MachinesRent'] and d1Plant[plant_sectors,Plant_,t]), pPlant[Plant_sectors,Plant_,t]*qPlant[Plant_sectors,Plant_,t]) # Maskinstation
								 - sum(Plant_$(sameas[Plant_,'Labor'] and d1Plant[plant_sectors,Plant_,t]), pPlant[Plant_sectors,Plant_,t]*qPlant[Plant_sectors,Plant_,t]) # Arbejdskraft
								 - sum(plant_$((sameas[Plant_,'Land'] or sameas[Plant_,'Netprod'] or sameas[Plant_,'Fertilizer']) and d1Plant[PLant_sectors,plant_,t]), vCO2_plant[plant_sectors,plant_,t]) 								 
								 - sum((Techplant,Emmtype)$((emmtype2plant_[emmtype,'Land'] or emmtype2plant_[emmtype,'Netprod'] or emmtype2plant_[emmtype,'Fertilizer']) and sum(emm, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm])), vEOPCostplant_TechTot[Techplant,Emmtype,plant_sectors,t])
								 + sum((Techplant,Emmtype)$((emmtype2plant_[emmtype,'Land'] or emmtype2plant_[emmtype,'Netprod'] or emmtype2plant_[emmtype,'Fertilizer']) and sum(emm, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm])), vTech_subsidy_plant[Techplant,EmmType,plant_sectors,t])
								 ;

	# Definition of user cost without installation costs
  	E_pK_plantxInst[plant_sectors,plant_pK,k,t]$(tx0E[t] and d1K[k,plant_sectors,t] and agri2k[plant_pK,k] and d1plant[plant_sectors,plant_pK,t])..
		pPlantxInst[plant_sectors,plant_pK,t+1]*fp*(1-tCorp[t+1]) =E= pPlant_uc[plant_sectors,plant_pK,t+1] * fp * (1-tCorp[t+1])
		# Minus installation costs from user cost equation
		- (1-tCorp[t+1]) * pPlant_CET[plant_sectors,'netprod',t+1] * fp * dKinstCost2dK[k,plant_sectors,t]
  		# Minus installation costs from Tobins Q
  		+ (pTobinsQ_plantxInst[plant_sectors,plant_pK,t]   - pTobinsQ_plant[plant_sectors,plant_pK,t])   * (1+rFirms[plant_sectors,t+1])
  		- (pTobinsQ_plantxInst[plant_sectors,plant_pK,t+1] - pTobinsQ_plant[plant_sectors,plant_pK,t+1]) * (1-rDepr[k,plant_sectors,t+1])*fp; 

    E_pTobinsQ_plantxInst[plant_sectors,plant_pK,k,t]$(tx0E[t] and d1K[k,plant_sectors,t] and agri2k[plant_pK,k] and d1plant[plant_sectors,plant_pK,t])..
    	pTobinsQ_plantxInst[plant_sectors,plant_pK,t] =E= pI_s[k,plant_sectors,t] - pI_s[k,plant_sectors,t] * EKtax[k,plant_sectors,t];

    E_pTobinsQ_plant_terminalxInst[plant_sectors,plant_pK,k,t]$(tEnd[t] and d1K[k,plant_sectors,t] and agri2k[plant_pK,k] and d1plant[plant_sectors,plant_pK,t])..
    	pTobinsQ_plantxInst[plant_sectors,plant_pK,t] =E= pI_s[k,plant_sectors,t] - pI_s[k,plant_sectors,t] * EKtax[k,plant_sectors,t];

   # ---------------------------------------------------------------------------------------------------------------------
   # CAP-BUDGET
   # ---------------------------------------------------------------------------------------------------------------------

	E_vtCAP[plant_sectors,t]$(tx0[t])..	vtCAP[plant_sectors,t] =E= vtHectareSubsidy_prod[plant_sectors,t]
						   										 + vtHectareSubsidy_nonprod[plant_sectors,t]
						   										 + vtAndenArealStoette[plant_sectors,t]
		  				   										 + vtSubOrganic[plant_sectors,t]
		  				   										 + vtProduktionsStoetteCAP[plant_sectors,t]
		  				   										 + vtCAP_other[plant_sectors,t];

	# Aggregate CAP budget (exogenous) controls vtCAP_other through adj_vtCAP_other (endogenous)
	E_vtCAP_tot[t]$(tx0[t]).. 							  vtCAP_tot[t] =E= sum(agri_sectors, vtCAP[agri_sectors,t]);

	E_vtHectareSubsidy_prod[plant_sectors,t]$(tx0[t]).. 	  vtHectareSubsidy_prod[plant_sectors,t] =E= - tHectareSubsidy[t] * qPlant[plant_sectors,'Land',t-1];


	E_vtHectareSubsidy_nonprod[plant_sectors,t]$(tx0[t]).. vtHectareSubsidy_nonprod[plant_sectors,t] =E=	- sum(landallocation, tHectareSubsidy[t] * qLand_nonproductive[landallocation,plant_sectors,t-1]);

	E_vtAndenArealStoette[plant_sectors,t]$(tx0[t]).. 	  vtAndenArealStoette[plant_sectors,t] =E= - sum(landallocation, tSubOtherPerHectareSchemes[landallocation,plant_sectors,t] * qLand_nonproductive[landallocation,plant_sectors,t-1]);

	E_vtSubOrganic[plant_sectors,t]$(tx0[t]).. 			  vtSubOrganic[plant_sectors,t] =E= - tSubOrganic[plant_sectors,t] * qPlant[plant_sectors,'Land',t-1];

	# Assuming that subsidies for starch potatoes goes to conventional crop produciton only (it's a very small subsidy, otherwise we would split it with more care)
	E_vtProduktionsStoetteCAP[plant_sectors,t]$(tx0[t]).. vtProduktionsStoetteCAP[plant_sectors,t] =E= -capbudget2023_2027['stivelseskart',t]$(sameas[plant_sectors,'01011'])*inf_growth_factor[t]
																									 + 0$(not sameas[plant_sectors,'01011']);

	E_vtCAP_other[plant_sectors,t]$(tx0[t]).. 			  vtCAP_other[plant_sectors,t] =E= vtCAP_other.l[plant_sectors,'2019']*adj_vtCAP_other[t];

	# CAP subsidies that enter the top of the production function e.g. without user cost on land and lump-sum transfers
	E_vtCAP_top_plant[plant_sectors,t]$(tx0[t]).. 		  vtCAP_top[plant_sectors,t] =E= vtProduktionsStoetteCAP[plant_sectors,t]
								   											   + vtSubOrganic[plant_sectors,t];
	# CAP subsidies that enter user cost on land
	E_vtCAP_uc_plant[plant_sectors,t]$(tx0[t]).. 		  vtCAP_uc[plant_sectors,t] =E= vtHectareSubsidy_prod[plant_sectors,t];	

	# CAP subsidies that enter user cost on land
	E_vtCAP_lumpsum_plant[plant_sectors,t]$(tx0[t]).. 	  vtCAP_lumpsum[plant_sectors,t] =E= vtCAP_other[plant_sectors,t]


$ENDBLOCK

# ---------------------------------------------------------------------------------------------------------------------
# Non-energy emissions from plant production 
# ---------------------------------------------------------------------------------------------------------------------

$BLOCK B_emissions_agr_plant 
	# Emissions AFTER end-of-pipe-abatement
	E_qEmmProdxE_agr_plant[plant_sectors,t,emm]$(tx0[t] and d1EmmProdxE_overlap[plant_sectors,t,emm]).. 
				qEmmProdxE[plant_sectors,t,emm] =E=  qEmmAgrxE['N2OFromLeaching',plant_sectors,t,emm]$(d1EmmAgrxE['N2OFromLeaching',plant_sectors,t,emm])
												   + qEmmAgrxE['InorganicFertilizer',plant_sectors,t,emm]$(d1EmmAgrxE['InorganicFertilizer',plant_sectors,t,emm])
												   + qEmmAgrxE['Manure',plant_sectors,t,emm]$(d1EmmAgrxE['Manure',plant_sectors,t,emm])
												   + qEmmAgrxE['Mineralization',plant_sectors,t,emm]$(d1EmmAgrxE['Mineralization',plant_sectors,t,emm])
												   + qEmmAgrxE['OrganicSoilsInProduction',plant_sectors,t,emm]$(d1EmmAgrxE['OrganicSoilsInProduction',plant_sectors,t,emm])
												   + qEmmAgrxE['CropResidues',plant_sectors,t,emm]$(d1EmmAgrxE['CropResidues',plant_sectors,t,emm])												   
												   + qEmmAgrxE['Other',plant_sectors,t,emm]$(d1EmmAgrxE['Other',plant_sectors,t,emm])												   
												   + jEmmAgrxE[plant_sectors,t,emm]; #
	
	# These are emissions BEFORE end-of-pipe-abatement

	# Plant related emissions
		# Inorganic fertilizer
		E_qEmmInorganicFertilizer[plant_sectors,t,emm]$(tx0[t] and d1EmmAgrxE['InorganicFertilizer',plant_sectors,t,emm]).. 
			qEmmAgrxE['InorganicFertilizer',plant_sectors,t,emm] =E= uEmmAgrxE['InorganicFertilizer',plant_sectors,t,emm] * qPlant[plant_sectors,'NPK',t]*uEOPplant['InorganicFertilizer',plant_sectors,t,emm];
		E_qEmmInorganicFertilizer_CO2e[plant_sectors,t]$(tx0[t] and d1EmmAgrxE['InorganicFertilizer',plant_sectors,t,'co2e'])..
			qEmmAgrxE['InorganicFertilizer',plant_sectors,t,'co2e'] =E= sum(emm$(d1EmmAgrxE['InorganicFertilizer',plant_sectors,t,emm]), qEmmAgrxE['InorganicFertilizer',plant_sectors,t,emm]*GWP[emm]);

		# Manure
		E_qEmmManure[plant_sectors,t,emm]$(tx0[t] and d1EmmAgrxE['Manure',plant_sectors,t,emm])..   
			qEmmAgrxE['Manure',plant_sectors,t,emm] =E= uEmmAgrxE['Manure',plant_sectors,t,emm] * qPlant[plant_sectors,'Manure',t]*uEOPplant['Manure',plant_sectors,t,emm];
		E_qEmmManure_CO2e[plant_sectors,t]$(tx0[t] and d1EmmAgrxE['Manure',plant_sectors,t,'co2e'])..
			qEmmAgrxE['Manure',plant_sectors,t,'co2e'] =E= sum(emm$(d1EmmAgrxE['Manure',plant_sectors,t,emm]), qEmmAgrxE['Manure',plant_sectors,t,emm]*GWP[emm]);

		# N2OFromLeaching 
		E_qEmmN2OFromLeaching[plant_sectors,t,emm]$(tx0[t] and d1EmmAgrxE['N2OFromLeaching',plant_sectors,t,emm])..   
			qEmmAgrxE['N2OFromLeaching',plant_sectors,t,emm] =E= uEmmAgrxE['N2OFromLeaching',plant_sectors,t,emm] * sLeachOf2TotalN 
	  												   * ((qPlant[plant_sectors,'NPK',t]$(d1Plant[plant_sectors,'NPK',t])+qPlant[plant_sectors,'manure',t]$(d1Plant[plant_sectors,'Manure',t]))*10**6)*uEOPplant['N2OFromLeaching',plant_sectors,t,emm];		
		E_qEmmN2OFromLeaching_CO2e[plant_sectors,t]$(tx0[t] and d1EmmAgrxE['N2OFromLeaching',plant_sectors,t,'co2e'])..
			qEmmAgrxE['N2OFromLeaching',plant_sectors,t,'co2e'] =E= sum(emm$(d1EmmAgrxE['N2OFromLeaching',plant_sectors,t,emm]), qEmmAgrxE['N2OFromLeaching',plant_sectors,t,emm]*GWP[emm]);

		# Other 
		E_qEmmOther[plant_sectors,t,emm]$(tx0[t] and d1EmmAgrxE['Other',plant_sectors,t,emm])..	
			qEmmAgrxE['Other',plant_sectors,t,emm] =E= uEmmAgrxE['Other',plant_sectors,t,emm] * qPlant[plant_sectors,'land',t-1]*uEOPplant['Other',plant_sectors,t,emm];
		E_qEmmOther_CO2e[plant_sectors,t]$(tx0[t] and d1EmmAgrxE['Other',plant_sectors,t,'co2e'])..
			qEmmAgrxE['Other',plant_sectors,t,'co2e'] =E= sum(emm$(d1EmmAgrxE['Other',plant_sectors,t,emm]), qEmmAgrxE['Other',plant_sectors,t,emm]*GWP[emm]);

		# Mineralization
		E_qEmmMineralization[plant_sectors,t,emm]$(tx0[t] and d1EmmAgrxE['Mineralization',plant_sectors,t,emm])..	
			qEmmAgrxE['Mineralization',plant_sectors,t,emm] =E= uEmmAgrxE['Mineralization',plant_sectors,t,emm] * (qPlant[plant_sectors,'land',t-1] + qLand_nonproductive['Brak',plant_sectors,t-1])*uEOPplant['Mineralization',plant_sectors,t,emm];

		E_qEmmMineralization_CO2e[plant_sectors,t]$(tx0[t] and d1EmmAgrxE['Mineralization',plant_sectors,t,'co2e'])..
			qEmmAgrxE['Mineralization',plant_sectors,t,'co2e'] =E= sum(emm$(d1EmmAgrxE['Mineralization',plant_sectors,t,emm]), qEmmAgrxE['Mineralization',plant_sectors,t,emm]*GWP[emm]);

		# Crop residues - this could be refined. Maybe crop residue emissions from coarse feed is lower than other output or vice versa?
		E_qEmmCropResidues[plant_sectors,t,emm]$(tx0[t] and d1EmmAgrxE['CropResidues',plant_sectors,t,emm])..	
			qEmmAgrxE['CropResidues',plant_sectors,t,emm] =E= uEmmAgrxE['CropResidues',plant_sectors,t,emm] * (qPlant[plant_sectors,'land',t-1] + qLand_nonproductive['Brak',plant_sectors,t-1])*uEOPplant['CropResidues',plant_sectors,t,emm];

		E_qEmmCropResidues_CO2e[plant_sectors,t]$(tx0[t] and d1EmmAgrxE['CropResidues',plant_sectors,t,'co2e'])..
			qEmmAgrxE['CropResidues',plant_sectors,t,'co2e'] =E= sum(emm$(d1EmmAgrxE['CropResidues',plant_sectors,t,emm]), qEmmAgrxE['CropResidues',plant_sectors,t,emm]*GWP[emm]);

		# OrganicSoilsInProduction 
		E_qEmmOrganicSoilsInProduction[plant_sectors,t,emm]$(tx0[t] and d1EmmAgrxE['OrganicSoilsInProduction',plant_sectors,t,emm])..	
			qEmmAgrxE['OrganicSoilsInProduction',plant_sectors,t,emm] =E= uEmmAgrxE['OrganicSoilsInProduction',plant_sectors,t,emm] * sum(land12_OC_CL,qLU12[land12_OC_CL,t]);
		
		
		E_qEmmOrganicSoilsInProduction_CO2e[plant_sectors,t]$(tx0[t] and d1EmmAgrxE['OrganicSoilsInProduction',plant_sectors,t,'co2e'])..
			qEmmAgrxE['OrganicSoilsInProduction',plant_sectors,t,'co2e'] =E= sum(emm$(d1EmmAgrxE['OrganicSoilsInProduction',plant_sectors,t,emm]), qEmmAgrxE['OrganicSoilsInProduction',plant_sectors,t,emm]*GWP[emm]);
$ENDBLOCK


# ---------------------------------------------------------------------------------------------------------------------
# CO2e-tax on non-energy emissions 
# ---------------------------------------------------------------------------------------------------------------------

$BLOCK B_CO2taxOnPlant                                                                        
    E_vCO2_emm_plant[Plant_sectors,plant_,t]$(tx0[t] and sum(emmtype$(emmtype2plant_[emmtype,plant_] and reguleringsgrundlag[emmtype]), d1EmmAgrxE[emmtype,plant_sectors,t,'CO2e'])).. #and not d1exclude[plant_])..
      vCO2_Plant[plant_sectors,plant_,t] =E= tCO2_emm_plant[Plant_sectors,plant_,t] * (sum(emmtype$(emmtype2plant_[emmtype,plant_] and d1EmmAgrxE[emmtype,plant_sectors,t,'CO2e'] and reguleringsgrundlag[emmtype]),  qEmmAgrxE[emmtype,Plant_sectors,t,'co2e']*growth_factor[t])) / 10**6;
$ENDBLOCK

# ---------------------------------------------------------------------------------------------------------------------
# Links to CGE-model 
# ---------------------------------------------------------------------------------------------------------------------

$BLOCK B_LINK_plant
	# Plant production 

		#Grundskyld is on land in agricultural module, but tied to buildings in the CGE-model. The tax-rate in the CGE-model takes the slack
		E_tK_plant_ib[plant_sectors,t]$(tx0[t])..      vtLand[plant_sectors,t] =E=  tLand[plant_sectors,t] * pLand[t-1]/fv * qPlant[plant_sectors,'land',t-1]
																				 +  tLand[plant_sectors,t] * sum(landallocation, pLand_nonproductive[landallocation,plant_sectors,t-1]/fv * qLand_nonproductive[landallocation,plant_sectors,t-1]) + jvtLand[plant_sectors,t];

		#Demand for market goods taken from CGE-model
		E_qPlant_CET_LINK[Plant_sectors,plant_out_top_m,t]$(tx0[t] and d1Plant_CET0[Plant_sectors,plant_out_top_m,t] and not sameas[plant_out_top_m,'EnergyStraw'])..
		   qPlant_CET[Plant_sectors,plant_out_top_m,t] =E= sum(out$out2plant_out(out,plant_out_top_m), qY_CETgross[out,plant_sectors,t]) + jqPlant_CET[plant_sectors,plant_out_top_m,t];

		E_qPlant_CET_LINK_straw[Plant_sectors,plant_out_top_m,t]$(tx0[t] and d1Plant_CET0[Plant_sectors,plant_out_top_m,t] and sameas[plant_out_top_m,'EnergyStraw'])..
		   qPlant_CET[Plant_sectors,plant_out_top_m,t] =E= sum(out$out2plant_out(out,plant_out_top_m), qY_CETgross[out,plant_sectors,t]*0.05) + jqPlant_CET[plant_sectors,plant_out_top_m,t];


		#Output prices determined through adjustment of mark-up in CGE-model		
		E_pY_CET_plant_LINK[out,plant_sectors,t]$(tx0[t] and d1vY_CET[out,plant_sectors,t] and not sameas[out,'straw for energy purposes'])..  pY_CET[out,plant_sectors,t] =E= sum(plant_out_top_m$(out2plant_out(out,plant_out_top_m) and d1Plant_CET0[Plant_sectors,plant_out_top_m,t]), pPlant_CET[plant_sectors,Plant_out_top_m,t]); #markup i CGE-model tager forskellen

		E_pY_CET_plant_LINK_straw[out,plant_sectors,t]$(tx0[t] and d1vY_CET[out,plant_sectors,t] and sameas[out,'straw for energy purposes'])..  
			pY_CET[out,plant_sectors,t] =E= sum(plant_out_top_m$(out2plant_out(out,plant_out_top_m) and d1Plant_CET0[Plant_sectors,plant_out_top_m,t]), 0.05*pPlant_CET[plant_sectors,Plant_out_top_m,t]); 


		E_qRxE_ym_LINK_Plant[Plant_sectors,s,t]$(tx0[t] and d1RxE_ym[Plant_sectors,s,t]).. 	
														qRxE_ym_Plant[Plant_sectors,s,t]	=E= qRxE_ym[Plant_sectors,s,t];  #sRxE_ym
		E_pRxE_ym_LINK_Plant[Plant_sectors,s,t]$(tx0[t] and d1RxE_ym[Plant_sectors,s,t]).. 	
														pRxE_ym_Plant[Plant_sectors,s,t]	=E= pRxE_ym[Plant_sectors,s,t]; 

		# The price for chemicals and NPK is calibrated to a different unit (DKK/kg N?) in historical years. The price change follows the change in prices from the IO-system.
		E_pRxE_ym_LINK_plant_chemNPK[plant_sectors,chemNPK,t]$(tx0[t] and sum(s$input2plant[s,plant_sectors,chemNPK],d1RxE_ym[plant_sectors,s,t]) and d1Plant[plant_sectors,chemNPK,t])..
	   		pPlant_base[plant_sectors,chemNPK,t] =E= sum(s$(input2plant[s,plant_sectors,chemNPK] and d1Plant[plant_sectors,chemNPK,t]), pRxE_ym_plant[plant_sectors,s,t]/pRxE_ym_plant[plant_sectors,s,t-1]) * pPlant_base[plant_sectors,chemNPK,t-1] + jpPlant[plant_sectors,chemNPK,t]; 

	    # CO2-tax is added to the base price of NPK
	    E_pRxE_ym_LINK_plant_chem[plant_sectors,chemNPK,t]$(tx0[t] and sum(s$input2plant[s,plant_sectors,chemNPK],d1RxE_ym[plant_sectors,s,t]) and d1Plant[plant_sectors,chemNPK,t])..
	        pPlant[plant_sectors,chemNPK,t] =E= pPlant_base[plant_sectors,chemNPK,t] + (vCO2_plant[plant_sectors,chemNPK,t]/qPlant[plant_sectors,chemNPK,t])$(sameas[chemNPK,'NPK'] and d1EmmAgrxE['InorganicFertilizer',plant_sectors,t,'CO2e'])
	        									+ sum((Techplant)$(sameas[chemNPK,'NPK'] and sum(emm, d1Thetaplant[Techplant,plant_sectors,'InorganicFertilizer',t,emm])), vEOPCostplant_TechTot[Techplant,'InorganicFertilizer',plant_sectors,t]/qPlant[plant_sectors,chemNPK,t])
	        									- sum((Techplant)$(sameas[chemNPK,'NPK'] and sum(emm, d1Thetaplant[Techplant,plant_sectors,'InorganicFertilizer',t,emm])), vTech_subsidy_plant[Techplant,'InorganicFertilizer',plant_sectors,t]/qPlant[plant_sectors,chemNPK,t]);
													
	  #Capital demand
		# E_qK_ib_LINK_Plant[Plant_sectors,t]$(tx0[t])..  qPlant[Plant_sectors,'Buildings',t] =E= qK['ib',Plant_sectors,t-1]/fq;  #uK
		# E_qK_im_LINK_Plant[Plant_sectors,t]$(tx0[t])..  qPlant[Plant_sectors,'MachinesPrivate',t]  =E= qK['im',Plant_sectors,t-1]/fq; #uK
		# E_qK_it_LINK_Plant[Plant_sectors,t]$(tx0[t])..  qPlant[Plant_sectors,'TransportCapital',t]  =E= qK['it',Plant_sectors,t-1]/fq; #uK

		E_qK_ib_LINK_Plant[Plant_sectors,t]$(tx0[t])..  qPlant_capital[Plant_sectors,'Buildings',t] =E= qK['ib',Plant_sectors,t-1]/fq;  #uK
		E_qK_im_LINK_Plant[Plant_sectors,t]$(tx0[t])..  qPlant_capital[Plant_sectors,'MachinesPrivate',t]  =E= qK['im',Plant_sectors,t-1]/fq; #uK
		E_qK_it_LINK_Plant[Plant_sectors,t]$(tx0[t])..  qPlant_capital[Plant_sectors,'TransportCapital',t]  =E= qK['it',Plant_sectors,t-1]/fq; #uK


		#Financial services
		E_qFin_iM_LINK_Plant[Plant_sectors,t]$(tx0[t])..  	qPlant[Plant_sectors,'FinancialServiceM',t]  =E= qFin_k['iM',Plant_sectors,t];
		E_pFin_iM_LINK_Plant[Plant_sectors,t]$(tx0[t])..  	pPlant[Plant_sectors,'FinancialServiceM',t]  =E= pFin_k['iM',Plant_sectors,t];

  		E_qFin_iB_LINK_Plant[Plant_sectors,t]$(tx0[t])..  	qPlant[Plant_sectors,'FinancialServiceB',t] + qPlant[Plant_sectors,'FinancialServiceL',t]  =E= qFin_k['iB',Plant_sectors,t];
		E_pFin_iB_LINK_Plant[Plant_sectors,t]$(tx0[t])..  	pPlant[Plant_sectors,'FinancialServiceB',t]  =E= pFin_k['iB',Plant_sectors,t];

   		E_qFin_iT_LINK_Plant[Plant_sectors,t]$(tx0[t])..  	qPlant[Plant_sectors,'FinancialServiceT',t]  =E= qFin_k['iT',Plant_sectors,t];
		E_pFin_iT_LINK_Plant[Plant_sectors,t]$(tx0[t])..  	pPlant[Plant_sectors,'FinancialServiceT',t]  =E= pFin_k['iT',Plant_sectors,t];

		E_pFin_Land_LINK_Plant[Plant_sectors,t]$(tx0[t])..  	pPlant[Plant_sectors,'FinancialServiceL',t]  =E= pFin_k['iB',Plant_sectors,t];


		E_qL_LINK_Plant[Plant_sectors,t]$(tx0[t])..		qPlant[Plant_sectors,'Labor',t] =E= qL[Plant_sectors,t]*thetaProd['L',Plant_sectors,t]; #uL
		E_pL_LINK_Plant[Plant_sectors,t]$(tx0[t])..		pPlant[Plant_sectors,'Labor',t] =E= (1+tL[Plant_sectors,t])*w[t];


		E_qRE_otherenergy_plant[plant_sectors,purpose_xtint,t]$(tx0[t] and d1EP[purpose_xtint,plant_sectors,t])..
		    qEP[purpose_xtint,plant_sectors,t] =E= uOtherEnergy_plant[purpose_xtint,plant_sectors,t] * (pEP[purpose_xtint,plant_sectors,t]/pPlant[plant_sectors,'OtherEnergy',t]) **(-ePlant[plant_sectors,'OtherEnergy',t]) * qPlant[plant_sectors,'OtherEnergy',t];
		E_pRE_otherenergy_plant[plant_sectors,t]$(tx0[t])..
			pPlant[plant_sectors,'OtherEnergy',t]*qPlant[plant_sectors,'OtherEnergy',t] =E= sum(purpose_xtint$(d1EP[purpose_xtint,plant_sectors,t]), pEP[purpose_xtint,plant_sectors,t] * qEP[purpose_xtint,plant_sectors,t]); 


		E_qRE_fuel_plant[Plant_sectors,t]$(tx0[t] and d1Plant[plant_sectors,'fuel',t] and d1EP['intern_trans',plant_sectors,t])..            qPlant[Plant_sectors,'Fuel',t] =E= qEP['intern_trans',Plant_sectors,t];
		E_pRE_fuel_plant[Plant_sectors,t]$(tx0[t] and d1Plant[plant_sectors,'fuel',t] and d1EP['intern_trans',plant_sectors,t])..            pPlant[Plant_sectors,'Fuel',t] =E= pEP['intern_trans',Plant_sectors,t];

		# Link of debt on land 
		E_vFirmDebt_plant_sectors[plant_sectors,t]$(tx0[t]).. vFirmDebtFromOtherModules[plant_sectors,t] =E= sDebt2j[plant_sectors,t] * pLand[t] * qPlant[plant_sectors,'land',t]
																		 + sDebt2j[plant_sectors,t] * sum(LandAllocation, pLand_nonproductive[LandAllocation,plant_sectors,t] * qLand_nonproductive[LandAllocation,plant_sectors,t]);

$ENDBLOCK


$BLOCK B_abatement_plant

  E_rEOPplant_gains[Techplant,plant_sectors,Emmtype,t]$(tx0[t] and sum(emm, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm])).. 
  	rEOPplant_gains[Techplant,plant_sectors,Emmtype,t] =E= sum((emm,plant_)$(emmtype2plant_[emmtype,plant_] and d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]), thetaplant[Techplant,plant_sectors,Emmtype,t,emm] * (tCO2_emm_plant[plant_sectors,plant_,t]+tech_subsidy_plant[Techplant,Emmtype,plant_sectors,t]));

  # Unit cost of implementing CCS technology (OBS.: vigtigt, at en teknologi kun virker på én branche - ellers summer man flere investeringspriser her)
  E_rEOPplant_costs[Techplant,plant_sectors,Emmtype,t]$(tx0[t] and sum(emm, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm])).. 
  	rEOPplant_costs[Techplant,plant_sectors,Emmtype,t] =E= sum(emm$(d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]), thetaplant[Techplant,plant_sectors,Emmtype,t,emm] * pEOPplant[Techplant,Emmtype,plant_sectors,t]);

  # Input for calculating instantaneous adoption rate (assuming normally distributed costs)
  E_rEOPplant_input[Techplant,plant_sectors,Emmtype,t]$(tx0[t] and sum(emm, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm])).. 
  	rEOPplant_input[Techplant,plant_sectors,Emmtype,t] =E= (sum(emm$(d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]), (rEOPplant_gains[Techplant,plant_sectors,Emmtype,t] - rEOPplant_costs[Techplant,plant_sectors,Emmtype,t])/thetaplant[Techplant,plant_sectors,Emmtype,t,emm]) - uEOPplantt[Techplant,plant_sectors,Emmtype,t])/ sigmaEOPplant[techplant];

  # Instantanous technology adoption rate (without forward-looking or sluggsihness)
  E_rEOPplant[Techplant,plant_sectors,Emmtype,t]$(tx0[t] and sum(emm, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm])).. 
  	rEOPplant[Techplant,plant_sectors,Emmtype,t] =E= (errorf(rEOPplant_input[Techplant,plant_sectors,Emmtype,t]) + j_rEOPplant[Techplant,plant_sectors,Emmtype,t]);

  # Technology adoption with forward-looking mechanism (if switch_forward_looking = 1)
  E_rEOPplant_preferred[Techplant,plant_sectors,Emmtype,t]$(tx0[t] and not tend[t] and sum(emm, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]))..
  	rEOPplant_preferred[Techplant,plant_sectors,Emmtype,t] =E= (1-switch_forward_looking_plant)*rEOPplant[Techplant,plant_sectors,Emmtype,t] + switch_forward_looking_plant*( (1-uEOPplantbeta)*rEOPplant[Techplant,plant_sectors,Emmtype,t]+(uEOPplantbeta)*rEOPplant_preferred[Techplant,plant_sectors,Emmtype,t+1]);

  # Terminal condition for forward-looking mechanism
  E_rEOPplant_preferred_terminal_condition[Techplant,plant_sectors,Emmtype,t]$(tend[t] and sum(emm, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]))..
  	rEOPplant_preferred[Techplant,plant_sectors,Emmtype,tend] =E= rEOPplant[Techplant,plant_sectors,Emmtype,tend];

  # Actual technology adoption (with sluggishness, if switch_sluggish = 1)
  E_rEOPplant_actual[Techplant,plant_sectors,Emmtype,t]$(tx0[t] and sum(emm, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]))..
        rEOPplant_actual[Techplant,plant_sectors,Emmtype,t] =E=  
        (1-switch_sluggish_plant)*rEOPplant_preferred[Techplant,plant_sectors,Emmtype,t]  
      + switch_sluggish_plant*( exp(-sqr(rEOPplant_preferred[Techplant,plant_sectors,Emmtype,t] - rEOPplant_actual[Techplant,plant_sectors,Emmtype,t-1])/rhoEOPplant[Techplant])
      *	(rEOPplant_preferred[Techplant,plant_sectors,Emmtype,t]) 
      + (1-exp(-sqr(rEOPplant_preferred[Techplant,plant_sectors,Emmtype,t] - rEOPplant_actual[Techplant,plant_sectors,Emmtype,t-1])/rhoEOPplant[Techplant])) * rEOPplant_actual[Techplant,plant_sectors,Emmtype,t-1]);

  E_uEOPplant[Emmtype,plant_sectors,t,emm]$(tx0[t])..
  	uEOPplant[Emmtype,plant_sectors,t,emm] 			=E= 1-sum(Techplant$(d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]), rEOPplant_actual[Techplant,plant_sectors,Emmtype,t] * thetaplant[Techplant,plant_sectors,Emmtype,t,emm]);

  E_qGrossEmmplant[Emmtype,plant_sectors,t,emm]$(tx0[t] and sum(Techplant,d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]))..
    qGrossEmmplant[Emmtype,plant_sectors,t,emm] 	=E= qEmmAgrxE[Emmtype,plant_sectors,t,emm]/uEOPplant[Emmtype,plant_sectors,t,emm];

  E_qGrossEmmplant_CO2e[Emmtype,plant_sectors,t]$(tx0[t] and sum((Techplant,emm),d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]))..
    qGrossEmmplant[Emmtype,plant_sectors,t,'co2e'] 	=E= sum(emm$(sum(Techplant,d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm])), qGrossEmmplant[Emmtype,plant_sectors,t,emm]*GWP[emm]);

  E_qEmmplantEOP[Emmtype,plant_sectors,t,emm]$(tx0[t] and sum(Techplant, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]))..
 	qEmmplantEOP[Emmtype,plant_sectors,t,emm] 		=E= qEmmAgrxE[Emmtype,plant_sectors,t,emm] - qGrossEmmplant[Emmtype,plant_sectors,t,emm];

  E_qEmmplantEOP_CO2e[Emmtype,plant_sectors,t]$(tx0[t] and sum((Techplant,emm),d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]))..
 	qEmmplantEOP[Emmtype,plant_sectors,t,'CO2e'] 	=E= qEmmAgrxE[Emmtype,plant_sectors,t,'CO2e'] - qGrossEmmplant[Emmtype,plant_sectors,t,'CO2e'];

## IO DEMAND FROM TECHNOLOGY
	E_vEOPCostplant_IO[Techplant,Emmtype,plant_sectors,s,t]$(tx0[t] and sum(emm, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]))..
    	vEOPCostplant_IO[Techplant,Emmtype,plant_sectors,s,t] =E= sum(emm$d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm], qGrossEmmplant[Emmtype,plant_sectors,t,'CO2e'] * growth_factor[t] * rEOPplant_actual[Techplant,plant_sectors,Emmtype,t] * thetaplant[Techplant,plant_sectors,Emmtype,t,emm]
        																													* pEOPplant[Techplant,Emmtype,plant_sectors,t]*10**(3)*10**(-9)*shareplantPrice_group[techplant,s,t]*shareplantPrice_type[techplant,'IO',t]);

  	E_vRxEEOP_plant[plant_sectors,s,t]$(tx0[t] and sum((Techplant,Emmtype,emm),d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]))..
    	vRxEEOP_plant[plant_sectors,s,t] =E= sum((Techplant,emmtype)$(sum(emm, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm])), vEOPCostplant_IO[Techplant,Emmtype,plant_sectors,s,t]);

  	E_qRxEEOP_plant[plant_sectors,s,t]$(tx0[t] and sum((Techplant,Emmtype,emm),d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]) and sum((Emmtype),d1vEOPCostplant[Emmtype,plant_sectors,s,t]))..
    	qRxEEOP_plant[plant_sectors,s,t] =E= vRxEEOP_plant[plant_sectors,s,t]/pRxE_y[plant_sectors,s,t];

## CAPITAL DEMAND FROM TECHNOLOGY
 	E_qI_EOPCostplant[Techplant,Emmtype,plant_sectors,t]$(tx0[t] and sum(emm, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]))..
    	qI_EOPCostplant['iM',Techplant,Emmtype,plant_sectors,t] =E= sum(emm$d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm], qGrossEmmplant[Emmtype,plant_sectors,t,'CO2e'] * growth_factor[t] * rEOPplant_actual[Techplant,plant_sectors,Emmtype,t] * thetaplant[Techplant,plant_sectors,Emmtype,t,emm] # Reduction from each technology
  																															* pEOPplant[Techplant,Emmtype,plant_sectors,t]*10**(3)*10**(-9)*shareplantPrice_type[techplant,'capital',t]); # Capital cost of reduction

  # Value of additonal investment demand (levelized)
  	E_vI_EOPCostplant[Techplant,Emmtype,plant_sectors,t]$(tx0[t] and sum(emm, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]))..
    	vI_EOPCostplant['iM',Techplant,Emmtype,plant_sectors,t] =E= qI_EOPCostplant['iM',Techplant,Emmtype,plant_sectors,t]*pI_s['iM',plant_sectors,t];

  # Spread necessary investments evenly over T_CCS periods preceeding year of capital demand (if front-loading is activated):
    E_qI_EOPCostplant_actual[Techplant,Emmtype,plant_sectors,t]$(tx0[t] and sum(emm, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]))..
  	    qI_EOPCostplant_actual['iM',Techplant,Emmtype,plant_sectors,t] =E= qI_EOPCostplant['iM',Techplant,Emmtype,plant_sectors,t];


## TOTAL COST OF TECHNOLOGY (FOR CALCUALTION OF ENDOGENOUS ADOPTION)
  	E_vEOPCostplant_TechTot[Techplant,Emmtype,plant_sectors,t]$(tx0[t] and sum(emm, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]))..
  		vEOPCostplant_TechTot[Techplant,Emmtype,plant_sectors,t] =E= sum(s$(sum(emm, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm])), 
  																																		vEOPCostplant_IO[Techplant,Emmtype,plant_sectors,s,t])
  																																	  + vI_EOPCostplant['iM',Techplant,Emmtype,plant_sectors,t];
  																																	

  	E_vEOPcost_plant_tot[plant_sectors,t]$(tx0[t] and sum((Techplant,Emmtype,emm),d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]))..
    	vEOPcost_plant_tot[plant_sectors,t] =E= sum((Techplant,emmtype,s)$(sum(emm, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm])), vEOPCostplant_IO[Techplant,Emmtype,plant_sectors,s,t])
    																+ sum((Techplant,Emmtype)$(sum(emm, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm])), vI_EOPCostplant['iM',Techplant,Emmtype,plant_sectors,t]);

$ENDBLOCK

$BLOCK B_report_agr_plant
# Dekomponering af DBII
	E_ProdValue[t]$(tx0[t])..
		ProdValue[t] 		=E= sum((plant_sectors,Plant_out)$(sameas[plant_out,'netprod'] and d1Plant_CET0[plant_sectors,plant_out,t]), qPlant_CET[plant_sectors,plant_out,t]*pPlant_CET[plant_sectors,plant_out,t]); # Produktionsværdien af market og non-market goods

	E_vProdInput[t]$(tx0[t])..
		vProdInput[t] 		=E= sum((plant_sectors,Plant_)$(sameas[Plant_,'Other'] and d1Plant[plant_sectors,Plant_,t]), pPlant[Plant_sectors,Plant_,t]*qPlant[Plant_sectors,Plant_,t]) # Materialeinputs
					   		  + sum((plant_sectors,Plant_)$((sameas[Plant_,'Chemicals']) and d1Plant[plant_sectors,Plant_,t]), pPlant[Plant_sectors,Plant_,t]*qPlant[Plant_sectors,Plant_,t]) # Kemikalier
					   		  + sum((plant_sectors,Plant_)$(sameas[Plant_,'MachinesRent'] and d1Plant[plant_sectors,Plant_,t]), pPlant[Plant_sectors,Plant_,t]*qPlant[Plant_sectors,Plant_,t]) # Maskinstation
					   		  + sum((plant_sectors,Plant_)$(sameas[Plant_,'Labor'] and d1Plant[plant_sectors,Plant_,t]), pPlant[Plant_sectors,Plant_,t]*qPlant[Plant_sectors,Plant_,t]); # Arbejdskraft

	E_EnergyExTax[t]$(tx0[t])..
		EnergyExTax[t] 		=E= sum((plant_sectors,Plant_)$((sameas[Plant_,'Fuel'] or sameas[Plant_,'OtherEnergy']) and d1Plant[plant_sectors,Plant_,t]), pPlant[Plant_sectors,Plant_,t]*qPlant[Plant_sectors,Plant_,t]) # Energy
						 	  - sum((purpose,energy19,Plant_sectors), vtEAFG_RE[purpose,energy19,Plant_sectors,t]$d1EAFG_RE[purpose,energy19,Plant_sectors,t]); # Energiafgifter

	E_ManureValue[t]$(tx0[t])..
		vManure[t] 			=E= sum((plant_sectors,Plant_)$(sameas[Plant_,'Manure'] and d1Plant[plant_sectors,Plant_,t]), pPlant[Plant_sectors,Plant_,t]*qPlant[Plant_sectors,Plant_,t]); # Husdyrgødning

	E_NPKValue[t]$(tx0[t])..
		vNPK[t] 			=E= sum((plant_sectors,Plant_)$((sameas[Plant_,'NPK']) and d1Plant[plant_sectors,Plant_,t]), pPlant[Plant_sectors,Plant_,t]*qPlant[Plant_sectors,Plant_,t]); # Kunstgødning basispris

	E_vCO2_plantAgg[t]$(tx0[t])..
		vCO2_plantAgg[t] 	=E= sum((plant_sectors,Plant_), vCO2_plant[plant_sectors,plant_,t]);

	E_vDBIIperHectare[t]$(tx0[t])..
		vDBIIperHectare[t] 	=E= sum(plant_sectors, vDBII[plant_sectors,t])/qLand[t-1];

# Mekanisk prisstigning sfa. CO2e-afgift på landbrugets ikke-energirelaterede udledninger
	E_pPlant_mekanisk[plant_sectors,t]$(tx0[t] and pPlant_CET_baseline.l[plant_sectors,'netprod',t])..
		pPlant_mekanisk[plant_sectors,t] 	=E= sum((plant_,emmtype)$(emmtype2plant_[emmtype,plant_] and d1EmmAgrxE[emmtype,plant_sectors,t,'CO2e']), tCO2_emm_plant[Plant_sectors,plant_,t] * (qEmmAgrxE_baseline[emmtype,Plant_sectors,t,'co2e']*growth_factor[t]) / 10**6)
												/ (pPlant_CET_baseline[plant_sectors,'netprod',t]*qPlant_CET_baseline[plant_sectors,'netprod',t]) ;


# Emissioner summeret over emmtype
	E_EmmPerManure[plant_sectors,t]$(tx0[t] and (d1plant[plant_sectors,'manure',t] or d1plant[plant_sectors,'NPK',t]))..
		EmmPerManure[plant_sectors,t] =E= (qEmmAgrxE['InorganicFertilizer',plant_sectors,t,'CO2e']$(d1EmmAgrxE['InorganicFertilizer',plant_sectors,t,'CO2e'])
										 + qEmmAgrxE['Manure',plant_sectors,t,'CO2e']$(d1EmmAgrxE['Manure',plant_sectors,t,'CO2e'])
										 + qEmmAgrxE['N2OFromLeaching',plant_sectors,t,'CO2e']$(d1EmmAgrxE['N2OFromLeaching',plant_sectors,t,'CO2e'])) 
										 / (qPlant[plant_sectors,'NPK',t]$(d1plant[plant_sectors,'NPK',t]) + qPlant[plant_sectors,'manure',t]$(d1plant[plant_sectors,'manure',t]));

	E_EmmPerLand[plant_sectors,t]$(tx0[t])..
		EmmPerLand[plant_sectors,t] =E= (qEmmAgrxE['other',plant_sectors,t,'CO2e']$(d1EmmAgrxE['other',plant_sectors,t,'CO2e'])
									   + qEmmAgrxE['Mineralization',plant_sectors,t,'CO2e']$(d1EmmAgrxE['Mineralization',plant_sectors,t,'CO2e'])
									   + qEmmAgrxE['CropResidues',plant_sectors,t,'CO2e']$(d1EmmAgrxE['CropResidues',plant_sectors,t,'CO2e'])
									   + qEmmAgrxE['OrganicSoilsInProduction',plant_sectors,t,'CO2e']$(d1EmmAgrxE['OrganicSoilsInProduction',plant_sectors,t,'CO2e']))
										 / qPlant[plant_sectors,'Land',t-1]$(d1plant[plant_sectors,'Land',t-1]);

# BVT i landbrug inkl. non-market 
	E_vY_agr_market_plant[plant_sectors,t]$(tx0[t])..
		vY_agr_market[plant_sectors,t] =E= qPlant_CET[plant_sectors,'Grain',t]*pPlant_CET[plant_sectors,'Grain',t]
										 + qPlant_CET[plant_sectors,'EnergyStraw',t]*pPlant_CET[plant_sectors,'EnergyStraw',t]
										 - (qY_CETgross['Straw for energy purposes',plant_sectors,t]-qY_CET['Straw for energy purposes',plant_sectors,t])*pY_CET['Straw for energy purposes',plant_sectors,t];

	E_vPlant[plant_sectors,plant_,t]$(tx0[t] and d1plant[plant_sectors,plant_,t])..
		vPlant[plant_sectors,plant_,t] 	=E= pPlant[plant_sectors,plant_,t] * qPlant[plant_sectors,plant_,t];

	E_vInput_agr_market_plant[plant_sectors,t]$(tx0[t])..
		vInput_agr_market[plant_sectors,t] =E= vPlant[plant_sectors,'other',t]$(d1plant[plant_sectors,'other',t])
										 	 + vPlant[plant_sectors,'fuel',t]$(d1plant[plant_sectors,'fuel',t])
										 	 + vPlant[plant_sectors,'MachinesRent',t]$(d1plant[plant_sectors,'MachinesRent',t])
										 	 + vPlant[plant_sectors,'OtherEnergy',t]$(d1plant[plant_sectors,'OtherEnergy',t])
										     # Account for marginal vs. average energy prices
										     + sum((purpose,energy19)$(d1pRE_base[purpose,energy19,plant_sectors,t]),(pRE_base[purpose,energy19,plant_sectors,t]-pRE_base_marg[purpose,energy19,plant_sectors,t])*qREgj[purpose,energy19,plant_sectors,t])													 	 
										   	 + sum((purpose,energy19)$(d1pREown[purpose,energy19,plant_sectors,t]), - qREa[purpose,energy19,plant_sectors,t]*pREa[purpose,energy19,plant_sectors,t]
										   																		  + (tqRE[purpose,energy19,plant_sectors,t]*qREa[purpose,energy19,plant_sectors,t])) # fratræk værdien af egen produktion af energihalm
										 	 + vPlant[plant_sectors,'Chemicals',t]$(d1plant[plant_sectors,'Chemicals',t])
										 	 + vPlant[plant_sectors,'NPK',t]$(d1plant[plant_sectors,'NPK',t])
										 	 # Deduct marginal taxes and add average 
										 	 + sum((purpose,energy19a), d1tREmarg[plant_sectors]*
                                                (+vtEAFG_RE[purpose,energy19a,plant_sectors,t]$d1EAFG_RE[purpose,energy19a,plant_sectors,t] 
                                                 -vtEAFG_REmarg[purpose,energy19a,plant_sectors,t]$d1EAFG_RE[purpose,energy19a,plant_sectors,t]
                                                 +vtCO2_RE[purpose,energy19a,plant_sectors,t]$d1CO2_RE[purpose,energy19a,plant_sectors,t]
                                                 -vtCO2_REmarg[purpose,energy19a,plant_sectors,t]$d1CO2_RE[purpose,energy19a,plant_sectors,t]
                                                 -vtCO2_ETS_marg[energy19a,plant_sectors,t]$(d1EmmProdE[plant_sectors,t,'CO2e',purpose,energy19a] and d1CO2_ETS[plant_sectors,t] and sameas[purpose,'in_ETS'])));

	# Non-market
	E_vY_agr_nm_plant[plant_sectors,t]$(tx0[t])..
		vY_agr_nm[plant_sectors,t] =E= qPlant_CET[plant_sectors,'Litter',t]*pPlant_CET[plant_sectors,'Litter',t]
									 + qPlant_CET[plant_sectors,'CoarseFeed',t]*pPlant_CET[plant_sectors,'CoarseFeed',t]
									 + (qY_CETgross['Straw for energy purposes',plant_sectors,t]-qY_CET['Straw for energy purposes',plant_sectors,t])*pY_CET['Straw for energy purposes',plant_sectors,t];

	E_vInput_agr_nm_plant[plant_sectors,t]$(tx0[t])..
		vInput_agr_nm[plant_sectors,t] =E= vPlant[plant_sectors,'Manure',t]$(d1plant[plant_sectors,'Manure',t])
										 + sum((purpose,energy19)$(d1pREown[purpose,energy19,plant_sectors,t]), qREa[purpose,energy19,plant_sectors,t]*pREa[purpose,energy19,plant_sectors,t]
										   																	- (tqRE[purpose,energy19,plant_sectors,t]*qREa[purpose,energy19,plant_sectors,t]));
	
	E_vBVT_agr_cpntns_subsidies_plant[plant_sectors,t]$(tx0[t])..
		vBVT_agr_cpntns[plant_sectors,'netProdSubsidies',t] =E= vtNetproductionRest[plant_sectors,t]
															 + vtCAP_top[plant_sectors,t]			# CAP-subsidies from the EU that enter the top of the production function
															 - tHectareSubsidy[t] * qPlant[plant_sectors,'land',t-1] # Hektarstøtte (indgår i usercost på jord)
															 + vtL[plant_sectors,t] 				# Taxes/Subsidies on labour
															 + vtLand[plant_sectors,t]				# Taxes/Subsidies on land/buildings
															 + vtFirmsWeight[plant_sectors,t]		# Vægtafgifter
															 + vtCO2_ETS[plant_sectors,t];			# ETS quotas

	E_vBVT_agr_cpntns_wage_plant[plant_sectors,t]$(tx0[t] and d1Plant[plant_sectors,'labor',t])..
		vBVT_agr_cpntns[plant_sectors,'Wage',t] =E= qPlant[plant_sectors,'Labor',t]*pPlant[plant_sectors,'Labor',t]
												 	- vtL[plant_sectors,t];

	E_vBVT_agr_cpntns_markup_plant[plant_sectors,t]$(tx0[t])..
		vBVT_agr_cpntns[plant_sectors,'Profit',t]	=E= sum(Plant_out_top, pPlant_CET[Plant_sectors,Plant_out_top,t]*qPlant_CET[Plant_sectors,Plant_out_top,t] 
																   	- pPlant_CET0[Plant_sectors,Plant_out_top,t]*qPlant_CET[Plant_sectors,Plant_out_top,t]);

	E_vBVT_agr_cpntns_machine_plant[plant_sectors,t]$(tx0[t] and d1Plant[plant_sectors,'MachinesPrivate',t])..
		vBVT_agr_cpntns[plant_sectors,'MachineCapital',t] 	=E= qPlant[plant_sectors,'MachinesPrivate',t]*pPlant[plant_sectors,'MachinesPrivate',t]
															 	- vtFirmsWeight[plant_sectors,t];

	E_vBVT_agr_cpntns_building_plant[plant_sectors,t]$(tx0[t] and d1Plant[plant_sectors,'Buildings',t])..
		vBVT_agr_cpntns[plant_sectors,'BuildingCapital',t] 	=E= qPlant[plant_sectors,'Buildings',t]*pPlant[plant_sectors,'Buildings',t];

	E_vBVT_agr_cpntns_land_plant[plant_sectors,t]$(tx0[t] and d1Plant[plant_sectors,'land',t-1])..
		vBVT_agr_cpntns[plant_sectors,'Land',t] =E= qPlant[plant_sectors,'Land',t-1]*pPlant[plant_sectors,'Land',t]
												  - vtLand[plant_sectors,t] 
												  + tHectareSubsidy[t] * qPlant[plant_sectors,'land',t-1];

# Aggregate shadow value of NH3 emissions 
	E_pLand_avg[t]$(tx0[t])..  pLand_avg[t] * (qLand[t-1] + sum((landallocation,plant_sectors), qLand_Nonproductive[landallocation,plant_sectors,t-1]))
										 =E= pLand[t]*qLand[t-1] + sum((landallocation,plant_sectors), pLand_nonproductive[landallocation,plant_sectors,t] * qLand_Nonproductive[landallocation,plant_sectors,t-1]);


	E_pLand_nonproductive_report_skov[Landallocation,plant_sectors,t]$(tx0E[t] and not sameas[plant_sectors,'01020'] and sameas[landallocation,'skov'])..
    	(1-tCorp[t+1]) * (pReturnPerHa_alt_landallocation[landallocation,plant_sectors,t+1] + pLandvalueFromUnobserved['JagtHerlighed',plant_sectors,t+1] + pLostFutureWoodprod[plant_sectors,t+1]) =E=  #Omregner mia. kr. per kha til mia. kr. per mio. ha.
					(1+rFirmsLand[plant_sectors,t+1]) * pLand_nonproductive_report[LandAllocation,Plant_sectors,t] - pLand_nonproductive_report[LandAllocation,Plant_sectors,t+1]*fv
				-   (rFirmsLand[plant_sectors,t] - rBonds[plant_sectors,t+1]*(1-tCorp[t+1])) * sDebt2j[plant_sectors,t] * pLand_nonproductive_report[LandAllocation,Plant_sectors,t]
				+   (1-tCorp[t+1]) * tLand[plant_sectors,t+1] * pLand_nonproductive_report[LandAllocation,Plant_sectors,t]
				;

	E_pLand_nonproductive_report_solc[Landallocation,plant_sectors,t]$(tx0E[t] and not sameas[plant_sectors,'01020'] and sameas[landallocation,'solceller'])..
   		(1-tCorp[t+1]) * (pReturnPerHa_alt_landallocation[landallocation,plant_sectors,t+1]) =E= 
					(1+rFirmsLand[plant_sectors,t+1]) * pLand_nonproductive_report[LandAllocation,Plant_sectors,t] - pLand_nonproductive_report[LandAllocation,Plant_sectors,t+1]*fv
				-   (rFirmsLand[plant_sectors,t] - rBonds[plant_sectors,t+1]*(1-tCorp[t+1])) * sDebt2j[plant_sectors,t] * pLand_nonproductive_report[LandAllocation,Plant_sectors,t]
				+   (1-tCorp[t+1]) * tLand_Photovoltaics[plant_sectors,t] * pLand_nonproductive_report[LandAllocation,Plant_sectors,t]
				# Grundskyldspromille sat lig "Effektiv grundskyldspromillen i 2024 vægtet gns. (promille) i Tabel 1 fra SKM via mail fra KEFM d. 17.11.2023" 
				;

	E_pLand_nonproductive_report_landv[Landallocation,plant_sectors,t]$(tx0E[t] and not sameas[plant_sectors,'01020'] and sameas[landallocation,'landvind'])..
   		(1-tCorp[t+1]) * (pReturnPerHa_alt_landallocation[landallocation,plant_sectors,t+1]) =E= 
					(1+rFirmsLand[plant_sectors,t+1]) * pLand_nonproductive_report[LandAllocation,Plant_sectors,t] - pLand_nonproductive_report[LandAllocation,Plant_sectors,t+1]*fv
				-   (rFirmsLand[plant_sectors,t] - rBonds[plant_sectors,t+1]*(1-tCorp[t+1])) * sDebt2j[plant_sectors,t] * pLand_nonproductive_report[LandAllocation,Plant_sectors,t]
				+   (1-tCorp[t+1]) * tLand_Photovoltaics[plant_sectors,t] * pLand_nonproductive_report[LandAllocation,Plant_sectors,t]
				# Grundskyldspromille sat lig "Effektiv grundskyldspromillen i 2024 vÃ¦gtet gns. (promille) i Tabel 1 fra SKM via mail fra KEFM d. 17.11.2023" 
				;
				
	E_pLand_nonproductive_report_lavb[Landallocation,plant_sectors,t]$(tx0E[t] and not sameas[plant_sectors,'01020'] and sameas[landallocation,'VaadLagtLavbund'])..
   		(1-tCorp[t+1]) * (tHectareSubsidy[t+1] + pReturnPerHa_alt_landallocation[landallocation,plant_sectors,t+1]) =E= 
					(1+rFirmsLand[plant_sectors,t+1]) * pLand_nonproductive_report[LandAllocation,Plant_sectors,t] - pLand_nonproductive_report[LandAllocation,Plant_sectors,t+1]*fv
				-   (rFirmsLand[plant_sectors,t] - rBonds[plant_sectors,t+1]*(1-tCorp[t+1])) * sDebt2j[plant_sectors,t] * pLand_nonproductive_report[LandAllocation,Plant_sectors,t]
				+   (1-tCorp[t+1]) * tLand[plant_sectors,t+1] * pLand_nonproductive_report[LandAllocation,Plant_sectors,t]
				# Grundskyldspromille sat lig "Effektiv grundskyldspromillen i 2024 vægtet gns. (promille) i Tabel 1 fra SKM via mail fra KEFM d. 17.11.2023" 
				;

	E_pLand_nonproductive_skovsolc_tEnd[landallocation,plant_sectors,t]$(tEnd[t] and not sameas[plant_sectors,'01020'] and (sameas[landallocation,'skov'] or sameas[landallocation,'solceller'] or sameas[landallocation,'VaadLagtLavbund'] or sameas[landallocation,'LandVind']))..
		pLand_nonproductive_report[landallocation,plant_sectors,t] =E= pLand_nonproductive_report[landallocation,plant_sectors,t-1];


$ENDBLOCK

$MODEL M_production_agr_plant
	B_production_agr_plant
	B_emissions_agr_plant
	B_LINK_plant
	B_abatement_plant
	B_CO2taxOnPlant
;

$ENDIF

#   ======================================================================================================================
#   Exogenous variables and data assignment
#   ======================================================================================================================

$IF %stage% == "read_data":
#1) READ DATA 
	
	# From CGE-model
		# PLANT
		# CET prices and quantities: 
		pPlant_CET.l[plant_sectors,plant_out_top_m,t]    = sum(out$out2plant_out(out,plant_out_top_m), IO_pY_CET[out,plant_sectors,t]);
		qPlant_CET.l[plant_sectors,plant_out_top_m,t]    = sum(out$out2plant_out(out,plant_out_top_m), IO_qY_CET[out,plant_sectors,t]); #Should add own-production here

		qPlant_CET.l[plant_sectors,'EnergyStraw',t]$(qPlant_CET.l[plant_sectors,'EnergyStraw',t])  
													     = pPlant_CET.l[plant_sectors,'EnergyStraw',t] * qPlant_CET.l[plant_sectors,'EnergyStraw',t]; 
		pPlant_CET.l[plant_sectors,'EnergyStraw',t]      = 1;

		qPlant.l[Plant_sectors,'grossprod',t] 			 = IO_qY[Plant_sectors,t];
		pPlant.l[Plant_sectors,'grossprod',t] 			 = IO_pY[Plant_sectors,t];
		qPlant.l[Plant_sectors,'netprod',t]   			 = IO_qY[Plant_sectors,t];
		pPlant.l[plant_sectors,'netprod',t]   			 = IO_pY[Plant_sectors,t];

		pPlant.l[Plant_sectors,'Labor',t] 				 = IO_pL[Plant_sectors,t];			
		qPlant.l[Plant_sectors,'Labor',t] 			     = IO_qL[Plant_sectors,t];
		pPlant.l[Plant_sectors,'fuel',tData]             = 1;

		#AKB
		pPlant.l[Plant_sectors,'FinancialServiceM',t]    = IO_pFin_k['iM',plant_sectors,t];
		pPlant.l[plant_sectors,'FinancialServiceB',t]    = IO_pFin_k['iB',plant_sectors,t];
		pPlant.l[plant_sectors,'FinancialServiceL',t]    = IO_pFin_k['iB',plant_sectors,t];
		pPlant.l[plant_sectors,'FinancialServiceT',t]    = IO_pFin_k['iT',plant_sectors,t];

		qPlant.l[Plant_sectors,'other',t]                = IO_qRxE[plant_sectors,t];
		qPlant.l[Plant_sectors,'FinancialServiceM',t]    = IO_qFin_k['iM',Plant_sectors,t];
		qPlant.l[Plant_sectors,'FinancialServiceB',t]    = 0.1 * IO_qFin_k['iB',Plant_sectors,t]; #Fordeling beregnes i statisk kalibrering 
		qPlant.l[Plant_sectors,'FinancialServiceL',t]    = 0.9 * IO_qFin_k['iB',Plant_sectors,t]; #Fordeling beregnes i statisk kalibrering 
		qPlant.l[Plant_sectors,'FinancialServiceT',t]    = IO_qFin_k['iT',Plant_sectors,t]; 

		qRxE_ym_plant.l[Plant_sectors,s,t]				 = IO_qRxE_ym[Plant_sectors,s,t];
		pRxE_ym_plant.l[Plant_sectors,s,t]				 = IO_pRxE_ym[Plant_sectors,s,t];

	
	# From LPRIS37 Statistikbanken
		pLand.l['2018'] = 132.099;
		pLand.l['2019'] = 131.251;
		pLand.l['2020'] = 130.383;
		pLand.l['2021'] = 135.451;
		pLand.l['2022'] = 147.610; 
		pLand.l['2023'] = 159.603; 
		pLand.l['2024'] = 162.370; 

		pLand.l[t]$(t.val > 2024) = pLand.l['2024'];

		
	    # Adding the part of land value derived from unobserved variables (From Table 6 in "Kompensationkrav ved udtagning af landbrugsjord baseret på stated preference-metode"-IFRO and own assumptions. All values are converted to a flow of value using the models discount factor)

	      # Harmoniareal
	      pLandvalueFromUnobserved.l['HarmoniAreal',plant_sectors,tx0] = 0.65;
	      LOOP(t$(t.val > 2023 and t.val <=2035),
	        pLandvalueFromUnobserved.l['HarmoniAreal',plant_sectors,t] = pLandvalueFromUnobserved.l['HarmoniAreal',plant_sectors,t-1] - 0.45/(2035-2023); 
	        );

	      pLandvalueFromUnobserved.l['HarmoniAreal',plant_sectors,t]$(t.val > 2035) = pLandvalueFromUnobserved.l['HarmoniAreal',plant_sectors,'2035'];

	      # Value from leasing the lands for hunting and the intrinsic value of the land to the farmer
	      pLandvalueFromUnobserved.l['JagtHerlighed',plant_sectors,tx0] = (0.314120387591655 + 0.194457); 

	      #Option value of land, wrt. to its value for future infrastructure
	      pLandvalueFromUnobserved.l['OptionsVaerdiIfbmInfrastruktur',plant_sectors,tx0] = 0.145853948392634; #

	      #Residual value
	      pLandvalueFromUnobserved.l['Andet',plant_sectors,tx0]	 =  0.783923 - 0.338;

		# We load land-data here from KF23-agr data. However, in the "computations"-part of "exogenous_values" we correct these areas to only be productive areas, according to IFRO in "Endogen jordudtagning"
			qPlant.l[plant_sectors,'land',t-1] = KF_qPlant_landProductive[plant_sectors,t]/1000; # Divide by 1000 to arrive at mio. hectares
			qPlant.l[plant_sectors,'land',t]$(t.val > 2049) = qPlant.l[plant_sectors,'land','2049'];
			# Total agricultural area (productive)
			qLand.l[t-1] = sum(plant_sectors, qPlant.l[plant_sectors,'land',t-1]);

			# Non-productive land
			qLand_nonproductive.l[landallocation,plant_sectors,t-1] = KF_qLand_nonproductive[landallocation,plant_sectors,t]/1000; # Divide by 1000 to arrive at mio. hectares
			qLand_nonproductive.l[landallocation,plant_sectors,t]$(t.val > 2049) = qLand_nonproductive.l[landallocation,plant_sectors,'2049'];

		# The average effective landtax (grundskyld) is computed on the basis of the National accounts revenue and total land-value, based on producive land.
		tLand.l[plant_sectors,'2019'] = sum(plant_sectorss, IO_FakDutyB_xh[plant_sectorss,'2019'])/(pLand.l['2018']*qLand.l['2018']);

		# The effective land tax on 
		tLand_Photovoltaics.l[plant_sectors,t] = 0.0081; # Grundskyldspromille sat lig "Effektiv grundskyldspromillen i 2024 vægtet gns. (promille) i Tabel 1 fra SKM via mail fra KEFM d. 17.11.2023"



		# CAP 2023-2027 ind. Satser tages fra ark rekvireret fra Cecilie Nydam Munkholm MGTP, d. 18/6/2025
		tHectareSubsidy.l['2023'] = 1.899; tHectareSubsidy.l[t]$(t.val<2023) = tHectareSubsidy.l['2023'];
		tHectareSubsidy.l['2024'] = 1.911;
		tHectareSubsidy.l['2025'] = 1.818;
		tHectareSubsidy.l['2026'] = 1.574;
		tHectareSubsidy.l['2027'] = 1.875; tHectareSubsidy.l[t]$(t.val>2027) = tHectareSubsidy.l['2027'];

		tHectareSubsidy.l[t]           = tHectareSubsidy.l[t] * inf_growth_factor[t];

		tSubOrganic.l['01012','2023']  = 0.87; tSubOrganic.l['01012',t]$(t.val<2023) = tSubOrganic.l['01012','2023'];
		tSubOrganic.l['01012','2024'] = 1.200;
		tSubOrganic.l['01012','2025'] = 1.200;
		tSubOrganic.l['01012','2026'] = 1.350;
		tSubOrganic.l['01012','2027'] = 1.350;
		tSubOrganic.l['01012',t]$(t.val>2027) = tSubOrganic.l['01012','2027'];

		tSubOrganic.l['01012',t]      = tSubOrganic.l['01012',t] * inf_growth_factor[t];


		tSubOtherPerHectareSchemes.l['EkstensiveretLavbund',plant_sectors,t]      = 3.526; tSubOtherPerHectareSchemes.l['EkstensiveretLavbund',plant_sectors,t]$(t.val>2024) = 0; #Udgår efter 2024
		tSubOtherPerHectareSchemes.l['Biodiversitet',plant_sectors,t]             = 2.740; # 2740 kr. per ha.
		tSubOtherPerHectareSchemes.l['Biodiversitet',plant_sectors,t]$(t.val>=2026) = 1.352; # 2740 kr. per ha.
		tSubOtherPerHectareSchemes.l['MiljoeogKlimavenligtGraes',plant_sectors,t] = 1.500; # 1500 kr. per ha.
		tSubOtherPerHectareSchemes.l[landallocation,plant_sectors,t]              = inf_growth_factor[t] * tSubOtherPerHectareSchemes.l[landallocation,plant_sectors,t];

		#National funds for afforestation of 75 500 DKR per hectare
		tAfforestationPerHa.l[plant_sectors,t] = 75.5 *inf_growth_factor[t]; #

		# PLANT

		qPlant.l[Plant_sectors,'Fuel',t] 				= sum((energy19), EN_vnRE['intern_trans',energy19,Plant_sectors,t] 
														            	+ EN_vCO2_RE['intern_trans',energy19,Plant_sectors,t] 
														            	+ EN_vSO2_RE['intern_trans',energy19,Plant_sectors,t] 
														            	+ EN_vPSO_RE['intern_trans',energy19,Plant_sectors,t]
														            	+ EN_vNOx_RE['intern_trans',energy19,Plant_sectors,t]
														            	+ EN_vEAFG_RE['intern_trans',energy19,Plant_sectors,t] 
														            	+ EN_vMOMS_RE['intern_trans',energy19,Plant_sectors,t]);

		tCO2_ETS.l[t]  = KF25_pETS[t]; 
		qPlant.l[Plant_sectors,'OtherEnergy',t]     = sum((energy19,purpose_xtint), EN_vnRE[purpose_xtint,energy19,Plant_sectors,t] 
														            			   + EN_vCO2_RE[purpose_xtint,energy19,Plant_sectors,t] 
														            			   + EN_vSO2_RE[purpose_xtint,energy19,Plant_sectors,t] 
														            			   + EN_vPSO_RE[purpose_xtint,energy19,Plant_sectors,t]
														            			   + EN_vNOx_RE[purpose_xtint,energy19,Plant_sectors,t]
														            			   + EN_vEAFG_RE[purpose_xtint,energy19,Plant_sectors,t] 
														            			   + EN_vMOMS_RE[purpose_xtint,energy19,Plant_sectors,t]
														            			   + tCO2_ETS.l[t]/10**6*EM_RE['CO2ubio',purpose_xtint,energy19,Plant_sectors,t]$(sameas[purpose_xtint,'in_ETS']));


 
$ENDIF

$IF %stage% == "exogenous_values":

#1) READ DATA 
		pPlant.l[Plant_sectors,'MachinesPrivate',t] 	 = pK.l['im',Plant_sectors,t];
		pPlant.l[Plant_sectors,'Buildings',t] 			 = pK.l['ib',Plant_sectors,t] ;	
		pPlant.l[Plant_sectors,'TransportCapital',t] 	 = pK.l['it',Plant_sectors,t];

		pPlant_uc.l[Plant_sectors,'MachinesPrivate',t] 	 = pK.l['im',Plant_sectors,t];
		pPlant_uc.l[Plant_sectors,'Buildings',t] 			 = pK.l['ib',Plant_sectors,t] ;	
		pPlant_uc.l[Plant_sectors,'TransportCapital',t] 	 = pK.l['it',Plant_sectors,t];

		qPlant.l[Plant_sectors,'MachinesPrivate',t] 	 = qK.l['im',Plant_sectors,t-1];
		qPlant.l[Plant_sectors,'Buildings',t] 		     = qK.l['ib',Plant_sectors,t-1];
		qPlant.l[Plant_sectors,'TransportCapital',t] 	 = qK.l['it',Plant_sectors,t-1];

		qPlant_capital.l[Plant_sectors,'MachinesPrivate',t] 	 = qK.l['im',Plant_sectors,t-1];
		qPlant_capital.l[Plant_sectors,'Buildings',t] 		     = qK.l['ib',Plant_sectors,t-1];
		qPlant_capital.l[Plant_sectors,'TransportCapital',t] 	 = qK.l['it',Plant_sectors,t-1];

		#CO2e-taxes
		Reguleringsgrundlag[emmtype] = no;
		Reguleringsgrundlag['Other']                     = yes;

		PARAMETER tCO2_emm_plant_emmtype[emmtype,t];
		tCO2_emm_plant_emmtype['Other',t]$(t.val>=2028) = 851.6/(fp**(2025-2019));
		# tCO2_emm_plant_emmtype[emmtype,t]$KF25_deflator[t] = tCO2_emm_plant_emmtype[emmtype,t]/KF25_deflator[t]*inf_factor[t]; #Omregner til afgift i modellens løbende priser

		tCO2_emm_plant.l[Plant_sectors,plant_,t] = sum(emmtype$(emmtype2plant_[emmtype,plant_] and reguleringsgrundlag[emmtype]), tCO2_emm_plant_emmtype[emmtype,t]);

#2) EXOGENOUS VALUES 
	
	# Production Elasticities:
		# PLANT
		ePlant.fx[Plant_sectors,'grossprod',t]		= 0;    
		ePlant.fx[Plant_sectors,'KELBLAND',t]		  = 0.07; 
		ePlant.fx[Plant_sectors,'KELBveg',t]		  = 0.04;  
		ePlant.fx[Plant_sectors,'KELveg',t]			  = 0.48; 
		ePlant.fx[Plant_sectors,'LF',t]				    = 0.1;
		ePlant.fx[Plant_sectors,'LandChem',t]	  	= 0;
		ePlant.fx[Plant_sectors,'Fertilizer',t]		= 0.5; 
		ePlant.fx[Plant_sectors,'BE',t]          	= 0.1;
		ePlant.fx[Plant_sectors,'Machines',t]		  = 0.6;	
		ePlant.fx[Plant_sectors,'PF',t]         	= 0.1; 
		ePlant.fx[Plant_sectors,'other',t]		  	= eRxE.l[Plant_sectors]; 
		ePlant.fx[Plant_sectors,'OtherEnergy',t] 	= 0;
		ePlant.fx[plant_sectors,'PFF',t]            = 0;

		ePlant_AGG.l 								= 2.5;

		# CET elasticities:
		eCET_Plant.l[Plant_sectors,'netprod'] 		= 2;
		eCET_Plant.l[Plant_sectors,'crops']   		= 2.5;
		eCET_Plant.l[Plant_sectors,'Straw']   		= 5;

		# Required rate of return on investments
		rFirmsLand.l[plant_sectors,t]$(tData[t]) 	= 0.05;

	# Other production related exo-values 
		TFPPlant.l[plant_sectors,t]$(tData[t])		= 1;

		# PLANT
		sDebt2j.l[plant_sectors,tData] 				= 0.6;

		uKinstcost_land.l[plant_sectors,tData] 		= 1; 

		thetaJ.l[plant_sectors,tData] 				= 1;

#3) COMPUTATIONS (residual data treatment that could be considered moved to actual data-reading in Python etc.)

	# Inf- and growth-adjustment of production prices and quantities
		KF_pPlant[plant_sectors,t] = KF_pPlant[plant_sectors,t] * inf_factor[t];
		KF_qPlant[plant_sectors,t] = KF_qPlant[plant_sectors,t] * growth_factor[t];

		# Creates horticulture production and prices index as the same as for conventional plants
		KF_pPlant['01020',t] = KF_pPlant['01011',t];
		KF_qPlant['01020',t] = KF_qPlant['01011',t];

	#PLANT PRODUCTION

		# CET quantities:
		qPlant_CET.l[plant_sectors,'CoarseFeed',t]	= sum(agri_sectors, qRxE_nm.l[agri_sectors,plant_sectors,'CoarseFeed',t]);
		qPlant_CET.l[plant_sectors,'Litter',t]    	= sum(agri_sectors, qRxE_nm.l[agri_sectors,plant_sectors,'Litter',t]);


		## MANURE USE
		# Distribution between con/org based on exchange with Statistics Denmark 24/11/2022 based on manure-accounts at LBST
		qPlant.l['01011','Manure',t] = 0.866378     * (sum((ani_sectors,animals), qNManure.l[ani_sectors,animals,t]) + qNManureOtherAnimals.l[t]);  
		qPlant.l['01012','Manure',t] = (1-0.866378) * (sum((ani_sectors,animals), qNManure.l[ani_sectors,animals,t]) + qNManureOtherAnimals.l[t]);
		
		# Chemicals and fertilizer 
		qPlant.l['01011','NPK',t]       = (Napplied['InorganicFertilizer',t] + Napplied['SewageSludge',t] + Napplied['OtherOrganic',t]) * 0.984; 
		qPlant.l['01020','NPK',t]       = (Napplied['InorganicFertilizer',t] + Napplied['SewageSludge',t] + Napplied['OtherOrganic',t]) * (1-0.984); 

		# Manure aggregate and price
		qD_manure.l[t] 					= sum(plant_sectors, qPlant.l[plant_sectors,'manure',t]);
		pD_manure.l[t]$(qD_manure.l[t]) = sum((plant_sectors,ani_sectors), qRxE_nm.l[plant_sectors,ani_sectors,'manure',t])/qD_manure.l[t];

		## User-cost on land (just an intial value)
		pPlant.l['01011','land','2019'] = 1;
		pPlant.l['01012','land','2019'] = 1; 
		pPlant.l['01020','land','2019'] = 1;

		# We use shares from JORD1 to distribute deliveries from chemical sector to agriculture. £AKB: In JORD1 values are significantly higher than in IO - it should be investigated if this is all due to wholesale/retail mark-ups
			pPlant_base.l['01011','NPK',t]$(qPlant.l['01011','NPK',t]) 	= 0.57 * pRxE_ym.l['01011','20000',t] * qRxE_ym.l['01011','20000',t]/qPlant.l['01011','NPK',t];
			pPlant_base.l['01020','NPK',t]$(qPlant.l['01020','NPK',t]) 	= 0.53 * pRxE_ym.l['01020','20000',t] * qRxE_ym.l['01020','20000',t]/qPlant.l['01020','NPK',t];

		#  Chemicals use is computed as a residual after subtracting NPK-fertilizer from the total deliveries from the chemicals sectors.
			qPlant.l[plant_sectors,'chemicals',t]$(input2Plant('20000',Plant_sectors,'Chemicals')) 
				= pRxE_ym.l[plant_sectors,'20000',t] * qRxE_ym.l[plant_sectors,'20000',t] - pPlant_base.l[plant_sectors,'NPK',t] * qPlant.l[plant_sectors,'NPK',t];

		# Manure-price
			pPlant.l[plant_sectors,'manure',t] = pPlant_base.l['01011','NPK',t];


		# CAP SUBSIDIES
		vtCAP_tot.l[t]$(t.val <= 2019) = sum(agri_sectors, vtCAP.l[agri_sectors,t]);
		vtCAP_tot.l[t]$(t.val >= 2023 and t.val <= 2027) 	= -sum(kat, capbudget2023_2027[kat,t])*inf_growth_factor[t];                          # The total cap-budget for 2023-2027
		vtCAP_tot.l[t]$(t.val >= 2028) 						= vtCAP_tot.l['2027']*inf_growth_factor[t];                                           # After 2027 the CAP-budget is held constant in growth and inflation adjusted terms
		vtCAP_tot.l[t]$(t.val >= 2020 and t.val <= 2022) 	= vtCAP_tot.l['2019'] + (vtCAP_tot.l['2023'] - vtCAP_tot.l['2019'])/4 * (t.val-2019); # Linear interpolation between 2019 and 2023

		vtCAP.l[agri_sectors,t]$(t.val > 2019) 				= vtCAP_tot.l[t]*vtCAP.l[agri_sectors,'2019']/sum(agri_sectorss, vtCAP.l[agri_sectorss,'2019']);

		vtHectareSubsidy_prod.l[plant_sectors,t] 	= - tHectareSubsidy.l[t] * qPlant.l[plant_sectors,'Land',t-1];
		vtHectareSubsidy_nonprod.l[plant_sectors,t]	= - sum(landallocation, tHectareSubsidy.l[t] * qLand_nonproductive.l[landallocation,plant_sectors,t-1]);
		vtAndenArealStoette.l[plant_sectors,t]      = - sum(landallocation, tSubOtherPerHectareSchemes.l[landallocation,plant_sectors,t] * qLand_Nonproductive.l[landallocation,plant_sectors,t-1]);
		vtSubOrganic.l[plant_sectors,t] 			= - tSubOrganic.l[plant_sectors,t] * qPlant.l[plant_sectors,'Land',t-1];
		vtProduktionsStoetteCAP.l[plant_sectors,t] 	= - capbudget2023_2027['stivelseskart',t]$(sameas[plant_sectors,'01011'])
												 	  + 0$(not sameas[plant_sectors,'01011']);

		vtCAP_other.l[plant_sectors,t] 	 = vtCAP.l[plant_sectors,t] 
									   	 - vtHectareSubsidy_prod.l[plant_sectors,t]
						   			   	 - vtHectareSubsidy_nonprod.l[plant_sectors,t]
						   			   	 - vtAndenArealStoette.l[plant_sectors,t]
		  				   			   	 - vtSubOrganic.l[plant_sectors,t]
		  				   			   	 - vtProduktionsStoetteCAP.l[plant_sectors,t];
		adj_vtCAP_other.l[t] = 1;

		vtCAP_top.l[plant_sectors,t] 	 = vtProduktionsStoetteCAP.l[plant_sectors,t]
								   	 	 + vtSubOrganic.l[plant_sectors,t];
		vtCAP_top.l[ani_sectors,t] 	 	 = vtCAP.l[ani_sectors,t];
		vtCAP_uc.l[plant_sectors,t]	 	 = vtHectareSubsidy_prod.l[plant_sectors,t];
		vtCAP_lumpsum.l[plant_sectors,t] = vtCAP_other.l[plant_sectors,t]
										 + vtHectareSubsidy_nonprod.l[plant_sectors,t]
										 + vtAndenArealStoette.l[plant_sectors,t];

		# Plant emissions

			# Distribution between con/org based on exchange with Statistics Denmark 24/11/2022 based on manure-accounts at LBST #LBS vi bør indføre denne i databehandlingen
			qEmmAgrxE.l['InorganicFertilizer','01011',t,emm]$(KF_landemissions['InorganicFertilizer',emm,t] and GWP.l[emm]) 
				=  0.9868       * KF_landemissions['InorganicFertilizer',emm,t]*1000/GWP.l[emm]; # Multiply by 1000 for kt, and divide by GWP as data is in CO2e
			qEmmAgrxE.l['InorganicFertilizer','01020',t,emm]$(KF_landemissions['InorganicFertilizer',emm,t] and GWP.l[emm]) 
				=  (1-0.9868)   * KF_landemissions['InorganicFertilizer',emm,t]*1000/GWP.l[emm]; # Multiply by 1000 for kt, and divide by GWP as data is in CO2e

				# Same as above - but NH3
				qEmmAgrxE.l['InorganicFertilizer','01011',t,emm]$(KF_landemissions['InorganicFertilizer',emm,t] and sameas[emm,'NH3']) 
					=  0.9868       * KF_landemissions['InorganicFertilizer',emm,t]*1000; #Multiply by 1000 for kt, and divide by GWP as data is in CO2e
				qEmmAgrxE.l['InorganicFertilizer','01020',t,emm]$(KF_landemissions['InorganicFertilizer',emm,t] and sameas[emm,'NH3']) 
					=  (1-0.9868)   * KF_landemissions['InorganicFertilizer',emm,t]*1000; #Multiply by 1000 for kt, and divide by GWP as data is in CO2e

			qEmmAgrxE.l['Manure','01011',t,emm]$(KF_landemissions['Manure',emm,t] and GWP.l[emm])             
				=  0.866378     * KF_landemissions['Manure',emm,t]*1000/GWP.l[emm];
			qEmmAgrxE.l['Manure','01012',t,emm]$(KF_landemissions['Manure',emm,t] and GWP.l[emm])            
				=  (1-0.866378) * KF_landemissions['Manure',emm,t]*1000/GWP.l[emm];
				# Same as above - but NH3
				qEmmAgrxE.l['Manure','01011',t,emm]$(KF_landemissions['Manure',emm,t] and sameas[emm,'NH3'])             
					=  0.866378     * KF_landemissions['Manure',emm,t]*1000;
				qEmmAgrxE.l['Manure','01012',t,emm]$(KF_landemissions['Manure',emm,t] and sameas[emm,'NH3'])            
					=  (1-0.866378) * KF_landemissions['Manure',emm,t]*1000;


			qEmmAgrxE.l['N2OFromLeaching','01011',t,emm]$(KF_landemissions['N2OFromLeaching',emm,t])  
				= (qPlant.l['01011','NPK',t1] + qPlant.l['01011','Manure',t1])/(qPlant.l['01011','NPK',t1] + qPlant.l['01011','Manure',t1] +  qPlant.l['01012','Manure',t1]) * KF_landemissions['N2OFromLeaching',emm,t]*1000/GWP.l[emm];

			qEmmAgrxE.l['N2OFromLeaching','01012',t,emm]$(KF_landemissions['N2OFromLeaching',emm,t])  
				= (qPlant.l['01012','Manure',t1])/(qPlant.l['01011','NPK',t1] + qPlant.l['01011','Manure',t1] +  qPlant.l['01012','Manure',t1]) * KF_landemissions['N2OFromLeaching',emm,t]*1000/GWP.l[emm];

			qEmmAgrxE.l['Mineralization','01011',t,emm]$(KF_landemissions['Mineralization',emm,t])     
			    = qPlant.l['01011','land',t0]/(qPlant.l['01011','land',t0] + qPlant.l['01012','land',t0]) * KF_landemissions['Mineralization',emm,t]*1000/GWP.l[emm];
			qEmmAgrxE.l['Mineralization','01012',t,emm]$(KF_landemissions['Mineralization',emm,t])      
				= qPlant.l['01012','land',t0]/(qPlant.l['01011','land',t0] + qPlant.l['01012','land',t0]) * KF_landemissions['Mineralization',emm,t]*1000/GWP.l[emm];
	
			qEmmAgrxE.l['Other','01011',t,emm]$(KF_landemissions['Other',emm,t] and GWP.l[emm])               
				= qPlant.l['01011','land',t0]/(qPlant.l['01011','land',t0] + qPlant.l['01012','land',t0]) * KF_landemissions['Other',emm,t]*1000/GWP.l[emm];
			qEmmAgrxE.l['Other','01012',t,emm]$(KF_landemissions['Other',emm,t] and GWP.l[emm])               
				= qPlant.l['01012','land',t0]/(qPlant.l['01011','land',t0] + qPlant.l['01012','land',t0]) * KF_landemissions['Other',emm,t]*1000/GWP.l[emm];

				# Same as above - but NH3
				qEmmAgrxE.l['Other','01011',t,emm]$(KF_landemissions['Other',emm,t] and sameas[emm,'NH3'])               
					= qPlant.l['01011','land',t0]/(qPlant.l['01011','land',t0] + qPlant.l['01012','land',t0]) * KF_landemissions['Other',emm,t]*1000;
				qEmmAgrxE.l['Other','01012',t,emm]$(KF_landemissions['Other',emm,t] and sameas[emm,'NH3'])               
					= qPlant.l['01012','land',t0]/(qPlant.l['01011','land',t0] + qPlant.l['01012','land',t0]) * KF_landemissions['Other',emm,t]*1000;
		
			qEmmAgrxE.l['CropResidues','01011',t,emm]$(KF_landemissions['CropResidues',emm,t] and GWP.l[emm])        
				= qPlant.l['01011','land',t0]/(qPlant.l['01011','land',t0] + qPlant.l['01012','land',t0]) * KF_landemissions['CropResidues',emm,t]*1000/GWP.l[emm];
			qEmmAgrxE.l['CropResidues','01012',t,emm]$(KF_landemissions['CropResidues',emm,t] and GWP.l[emm])     
				= qPlant.l['01012','land',t0]/(qPlant.l['01011','land',t0] + qPlant.l['01012','land',t0]) * KF_landemissions['CropResidues',emm,t]*1000/GWP.l[emm];

				# Same as above - but NH3
				qEmmAgrxE.l['CropResidues','01011',t,emm]$(KF_landemissions['CropResidues',emm,t] and sameas[emm,'NH3'])               
					= qPlant.l['01011','land',t0]/(qPlant.l['01011','land',t0] + qPlant.l['01012','land',t0]) * KF_landemissions['CropResidues',emm,t]*1000;
				qEmmAgrxE.l['CropResidues','01012',t,emm]$(KF_landemissions['CropResidues',emm,t] and sameas[emm,'NH3'])               
					= qPlant.l['01012','land',t0]/(qPlant.l['01011','land',t0] + qPlant.l['01012','land',t0]) * KF_landemissions['CropResidues',emm,t]*1000;

			# For now these emissions are assigned to conventional plants
			qEmmAgrxE.l['OrganicSoilsInProduction','01011',t,emm]$(KF_landemissions['OrganicSoilsInProduction',emm,t]) 
				= KF_landemissions['OrganicSoilsInProduction',emm,t]*1000/GWP.l[emm];

			uEmmAgrxE.l['InorganicFertilizer',plant_sectors,t,emm]  = qEmmAgrxE.l['InorganicFertilizer',plant_sectors,t,emm];
			uEmmAgrxE.l['Manure',plant_sectors,t,emm]               = qEmmAgrxE.l['Manure',plant_sectors,t,emm]; 	

#4) INITIAL VALUES 
	# PLANT 
		pPlant_CET.l[plant_sectors,'CoarseFeed',tData]	= 1;
		pPlant_CET.l[plant_sectors,'Litter',tData]    	= 1;

		pPlant_CET0.l[Plant_sectors,plant_out,t] = pPlant_CET.l[Plant_sectors,plant_out,t];
		pPlant_CET0.l[Plant_sectors,plant_out,t]$(pPlant_CET0.l[Plant_sectors,plant_out,t] = 0) = 1;
	
		# CET-aggregate prices are normalized
		pPlant_CET.l[Plant_sectors,Plant_outNest,t] = 1;

		# Aggregates
		qPlant_CET.l[Plant_sectors,plant_outNest,t] = sum(plant_out$Plant2out(Plant_outNest,plant_out), pPlant_CET.l[plant_sectors,plant_out,t]*qPlant_CET.l[plant_sectors,plant_out,t]);
		qPlant_CET.l[Plant_sectors,plant_outNest,t] = sum(plant_out$Plant2out(Plant_outNest,plant_out), pPlant_CET.l[plant_sectors,plant_out,t]*qPlant_CET.l[plant_sectors,plant_out,t]);
		qPlant_CET.l[Plant_sectors,plant_outNest,t] = sum(plant_out$Plant2out(Plant_outNest,plant_out), pPlant_CET.l[plant_sectors,plant_out,t]*qPlant_CET.l[plant_sectors,plant_out,t]);

		pPlant.l[plant_sectors,'land',tForecast] = pPlant.l[plant_sectors,'land',tDataEnd]; 
		pPlant.l[Plant_sectors,'OtherEnergy',t]          = 1;

		# Aggregates prices
		pPlant.l[Plant_sectors,'netprod',tData]      	= 1;
		pPlant.l[Plant_sectors,'grossprod',tData]    	= 1;
		pPlant.l[Plant_sectors,PlantNest,tData]         = 1;
		pPlant.l[Plant_sectors,PlantAggregates,tData]	= 1; # Set aggregates prices to one
		pPlant.l[Plant_sectors,IOnestsPlant,tData]		= 1; # Set bottom-level prices to one when they are constructed from IO inputs
		pPlant.l[Plant_sectors,'other',tData] 		= 1;
		pPlant.l[Plant_sectors,'fertilizer',t] 	= 1;
		pPlant.l[Plant_sectors,'manure',tData]     	= 1;
		pPlant_base.l[plant_sectors,'chemicals',tData]$(input2Plant('20000',Plant_sectors,'Chemicals')) = 1;

		qPlant.l[Plant_sectors,'other',tData] 		= 1;
		qPlant.l[Plant_sectors,'fertilizer',tData] 	= 1;
		pPlant.l[plant_sectors,chemNPK,tData]		= 1;

		pPlant.l[Plant_sectors,Plant_,tData]$(pPlant.l[Plant_sectors,Plant_,tData] = 0) = 1;

		# Creating initial values for CES-nests
		qPlant.l[Plant_sectors,Plant_,tData]$ionestsplant[Plant_] = sum(s$(input2plant[s,Plant_sectors,Plant_]), qRxE_ym_plant.l[Plant_sectors,s,tData]*pRxE_ym_plant.l[Plant_sectors,s,tData])/pPlant.l[Plant_sectors,Plant_,tData];
		qPlant.l[Plant_sectors,PlantNest,tData] = sum(Plant_$(PlantNest2inputs_[PlantNest,Plant_]), pPlant.l[Plant_sectors,Plant_,tData]*qPlant.l[Plant_sectors,Plant_,tData])/pPlant.l[Plant_sectors,PlantNest,tData]; 
		qPlant.l[Plant_sectors,PlantNest,tData] = sum(Plant_$(PlantNest2inputs_[PlantNest,Plant_]), pPlant.l[Plant_sectors,Plant_,tData]*qPlant.l[Plant_sectors,Plant_,tData])/pPlant.l[Plant_sectors,PlantNest,tData]; 
		qPlant.l[Plant_sectors,PlantNest,tData] = sum(Plant_$(PlantNest2inputs_[PlantNest,Plant_]), pPlant.l[Plant_sectors,Plant_,tData]*qPlant.l[Plant_sectors,Plant_,tData])/pPlant.l[Plant_sectors,PlantNest,tData]; 
		qPlant.l[Plant_sectors,PlantNest,tData] = sum(Plant_$(PlantNest2inputs_[PlantNest,Plant_]), pPlant.l[Plant_sectors,Plant_,tData]*qPlant.l[Plant_sectors,Plant_,tData])/pPlant.l[Plant_sectors,PlantNest,tData]; 
		qPlant.l[Plant_sectors,PlantNest,tData] = sum(Plant_$(PlantNest2inputs_[PlantNest,Plant_]), pPlant.l[Plant_sectors,Plant_,tData]*qPlant.l[Plant_sectors,Plant_,tData])/pPlant.l[Plant_sectors,PlantNest,tData]; 
		qPlant.l[Plant_sectors,PlantNest,tData] = sum(Plant_$(PlantNest2inputs_[PlantNest,Plant_]), pPlant.l[Plant_sectors,Plant_,tData]*qPlant.l[Plant_sectors,Plant_,tData])/pPlant.l[Plant_sectors,PlantNest,tData]; 

		# Initial values
		uPlant.l[plant_sectors,plant_,t]        			= qPlant.l[plant_sectors,plant_,t];
		uPlant_CET.l[plant_sectors,plant_out,t] 			= qPlant_CET.l[plant_sectors,plant_out,t];
		uOtherEnergy_plant.l[purpose_xtint,Plant_sectors,t] 	= qEP.l[purpose_xtint,Plant_sectors,t];

		sRxE_nm.l[Agri_sectorss,agri_sectors,agri_,t] 	= qRxE_nm.l[Agri_sectorss,agri_sectors,agri_,t];
		sRxE_ym_plant.l[Plant_sectors,s,t]     			= qRxE_ym.l[Plant_sectors,s,t];

		sPlant_Agg.l[plant_sectors,t] = 1;

		pReturnPerHa_alt_landallocation.l['skov',plant_sectors,tDataEnd] 		= 1;
		pReturnPerHa_alt_landallocation.l['solceller',plant_sectors,tDataEnd]	= 1;
		pReturnPerHa_alt_landallocation.l['landvind',plant_sectors,tDataEnd] 	= 1;

	# New abatement	
		# These switches control whether abatement forward looking and/or sluggish. Should be set to 0 (not forward-looking or sluggish) or 1
		switch_forward_looking_plant 	= 0; 		# Perhaps this should be controlled individually for ID and EOPtech...
		switch_sluggish_plant 			= 0; 		# Perhaps this should be controlled individually for ID and EOPtech...
		uEOPplantbeta 					= 0.5;      # This parameter controls the degree of forward-lookingness for EOPtech technologies
		rhoEOPplant[Techplant] 			= 0.8;      # This parameter controls the degree of sluggishness for EOPtech technologies
		sigmaEOPplant[Techplant] 		= 0.1;  	# Default value for variance on technology costs

		uEOPplant.l[Emmtype,plant_sectors,t,emm] = 1;

#5) DUMMIES 
	# Plant outputs
	d1Plant_CET0[plant_sectors,plant_out,t] 			   	= yes$(qPlant_CET.l[plant_sectors,plant_out,t]);

	# Dummy for the full nesting structure
	d1Plant[Plant_sectors,Plant_,t] 					   	= yes$(qPlant.l[Plant_sectors,Plant_,t]);	

	# Abatement
	d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm] 	= yes$(thetaplant.l[Techplant,plant_sectors,Emmtype,t,emm]);
	d1vEOPCostplant[Emmtype,plant_sectors,s,t] 				= yes$(sum((Techplant,emm), d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]) and sum(techplant, shareplantPrice_type.l[Techplant,'IO',t] and shareplantPrice_group.l[techplant,s,t]));

# ---------------------------------------------------------------------------------------------------------------------
# Add to data (includes list in data check)
# ---------------------------------------------------------------------------------------------------------------------

	$GROUP G_plant_data 
		qPlant$(Plant_bottom[plant_] or plant_pk[plant_] or sameas[plant_,'manure'])
		pPlant$(plant_bottom[plant_] or plant_pk[plant_] or sameas[plant_,'manure'])
		qPlant_CEt$(plant_out_top[plant_out])
		pPlant_CET$(plant_out_top[plant_out])
		qLand
		pLand
	;	



$ENDIF


# ======================================================================================================================
# Static calibration
# ======================================================================================================================

$IF %stage% == "static_calibration":

	$BLOCK B_production_plant_static_calibration

		# Assume identical markups of CET outputs in calibration
		E_markup_calib_plant[Plant_sectors,Plant_out_top,t]$(tx0[t] and d1Plant_CET0[Plant_sectors,plant_out_top,t])..
			Plant_markup[Plant_sectors,Plant_out_top,t]	=E=	Plant_markup_calib[Plant_sectors,t];

		E_pPlant_01011[t]$(tx0[t])..
			Plant_markup_calib['01011',t] =E= 0;
			# pPlant['01011','land',t] =E= 1;

		E_pPlant_01012[t]$(tx0[t])..
			pPlant['01012','land',t] =E= pPlant['01011','land',t];

		E_pPlant_01020[t]$(tx0[t])..
			pPlant['01020','land',t] =E= pPlant['01011','land',t];

	    # $LOOP00 E_pK_plant:
	    # 	{name}_t0{sets}$(t0[t] and d1K[k,plant_sectors,t] and agri2k[plant_pK,k] and d1Plant[Plant_sectors,plant_pK,t])..
	    # 		{LHS} =E= {RHS};

	   	# $ENDLOOP00

	    $LOOP00 E_pPlant_uc:
	    	{name}_t0{sets}$(t0[t] and d1K[k,plant_sectors,t] and agri2k[plant_pK,k] and d1Plant[Plant_sectors,plant_pK,t])..
	    		{LHS} =E= {RHS};

	   	$ENDLOOP00


	   	E_pTobinsQ_plant_t0[plant_sectors,plant_pK,t]$(t0[t] and d1Plant[plant_sectors,plant_pK,t])..
	   		pTobinsQ_plant[plant_sectors,plant_pK,t]  =E= pTobinsQ_plant[plant_sectors,plant_pK,t+1];

	 	E_qPlantFinServicesB_plant[plant_sectors,t]$(tx0[t] and d1Plant[plant_sectors,'FinancialServiceB',t])..
	 		qPlant[plant_sectors,'FinancialServiceB',t] =E= qFin_k['iB',plant_sectors,t] * (pI_s['iB',plant_sectors,t] * qK['iB',plant_sectors,t-1]/fq)/((pI_s['iB',plant_sectors,t] * qK['iB',plant_sectors,t-1]/fq) + pLand[t]*qPlant[plant_sectors,'land',t-1]);

	 	E_qPlantFinServicesL_plant[plant_sectors,t]$(tx0[t] and d1Plant[plant_sectors,'FinancialServiceB',t])..
	 		qPlant[plant_sectors,'FinancialServiceL',t] =E= qFin_k['iB',plant_sectors,t] * (pLand[t]*qPlant[plant_sectors,'land',t-1])/((pI_s['iB',plant_sectors,t] * qK['iB',plant_sectors,t-1]/fq) + pLand[t]*qPlant[plant_sectors,'land',t-1]);

		E_qPlant_nottop_Leontief_plantnest_TC_static_calib[plant_sectors,plant_,plantnest,t]$(t1[t] and PlantNest2inputs_[PlantNest,Plant_] and d1Plant[plant_sectors,plant_,t] and Leontief_PlantNest[plantNest] and not sameas[plant_,'land'] and sameas[plant_,'TransportCapital'])..
			#  qPlant[plant_sectors,plant_,t] =E= uPlant[plant_sectors,plant_,t] * (pPlant[plant_sectors,plant_,t]/pPlant[plant_sectors,plantNest,t])**(-0.5) * qPlant[PLant_sectors,plantnest,t];
			qPlant[plant_sectors,plant_,t] =E= uPlant[plant_sectors,plant_,t] * qPlant[PLant_sectors,plantnest,t];

	$ENDBLOCK

	$BLOCK B_production_agr_static_calibration_LINK

			#UC ex inst (Overflødig i data år, når vi ikke har installationsomk.)
			E_pK_ib_LINK_PlantxInst_calib[Plant_sectors,t]$(tx0[t])..  	pPlantxInst[Plant_sectors,'Buildings',t] =E= pK['ib',Plant_sectors,t]; #jpK

			E_pK_im_LINK_PlantxInst_calib[Plant_sectors,t]$(tx0[t])..  	pPlantxInst[Plant_sectors,'MachinesPrivate',t]  =E= pK['im',Plant_sectors,t];

			E_pK_it_LINK_PlantxInst_calib[Plant_sectors,t]$(tx0[t])..  	pPlantxInst[Plant_sectors,'TransportCapital',t]  =E= pK['it',Plant_sectors,t];

			#Grundskyldspromille
			E_tLand_calib[plant_sectors,t]$(tx0[t])..      				tLand[plant_sectors,t] =E= sum(plant_sectorss, vtLand[plant_sectorss,t])
																		 					/( pLand[t-1]/fv * sum(plant_sectorss, qPlant[plant_sectorss,'land',t-1] + sum(landallocation,qLand_nonproductive[landallocation,plant_sectorss,t-1]))); 

	$ENDBLOCK 

	$MODEL M_plant_static_calibration_partial 
		B_production_agr_plant
		-E_pTobinsQ_plant_terminalxInst # No terminal-condition in static-calib
		-E_qPlant_land_End              # No terminal-condition in static-calib
		-E_pLand_End
		B_production_plant_static_calibration
		B_emissions_agr_plant ,-E_qEmmProdxE_agr_plant
		B_abatement_plant
		B_CO2taxOnPlant
	;


	$GROUP G_plant_static_calibration_partial
		G_production_plant_endo
		# User-cost is fixed in static calibration
		# -pPlant$(Plant_pK[Plant_])  
		# All bottom layers are inverted - quantity for share-parameter
		-qRxE_ym_plant$(d1RxE_ym[plant_sectors,s,t] and not input2Plant(s,Plant_sectors,'NPK') and not input2Plant(s,Plant_sectors,'Chemicals')), 
		sRxE_ym_plant$(d1RxE_ym[plant_sectors,s,t] and not input2Plant(s,Plant_sectors,'NPK') and not input2Plant(s,Plant_sectors,'Chemicals'))                        

		-qPlant$(d1Plant[plant_sectors,plant_,t] and sameas[plant_,'manure']), uPlant$(d1Plant[plant_sectors,plant_,t] and sameas[plant_,'manure'])
		-qPlant$(d1Plant[plant_sectors,plant_,t] and plant_bottom[plant_]),    uPlant$(d1Plant[plant_sectors,plant_,t] and plant_bottom[plant_])
		-qPlant$(d1Plant[Plant_sectors,plant_,t] and sameas[plant_,'land']),   uPlant$(d1Plant[plant_sectors,plant_,t] and sameas[plant_,'land'])
		# -qPlant$(d1Plant[Plant_sectors,plant_,t] and plant_pK[plant_]),        uPlant$(d1Plant[Plant_sectors,plant_,t] and plant_pk[Plant_])
		-qPlant_capital$(d1Plant[Plant_sectors,plant_pK,t]),        uPlant$(d1Plant[Plant_sectors,plant_,t] and plant_pk[Plant_])

		 #  Intermediate CES-goods are determined by fixing prices at 1. For animals, which are Leontief no price fixing is need
		-pPlant$(d1Plant[Plant_sectors,plant_,t] and IOnestsPlant[plant_]),    uPlant$(d1Plant[Plant_sectors,plant_,t] and IOnestsPlant[plant_])
		-pPlant$(d1Plant[plant_sectors,plant_,t] and PlantNest[plant_] and not sameas[Plant_,'grossprod']), uPlant$(d1Plant[plant_sectors,plant_,t] and PlantNest[plant_] and not sameas[Plant_,'grossprod'])

		#Financiel service opdeling byg/jord 
		qPlant$(d1Plant[plant_sectors,plant_,t] and (sameas[plant_,'FinancialServiceB'] or sameas[plant_,'FinancialServiceL']))

		# Prices
		-pPlant_CET$(Plant_out_top[Plant_out]), uPlant_CET
		-pPlant_CET0$(plant_outNest[plant_out])

		Plant_markup$(plant_out_top[plant_out]) 
		Plant_markup_calib # E_mPlant_CET

		-qEmmAgrxE$(d1EmmAgrxE[emmtype_,Agri_sectors,t,emm_eq] and not ( sameas(emmtype_,'EntericFermentation') or sameas(emmtype_,'ManureManagement') or sameas(emmtype_,'GrazingAnimals') or sameas(emmtype_,'N2Oindirect'))), 
		uEmmAgrxE$(d1EmmAgrxE[emmtype,Agri_sectors,t,emm_eq] and not (sameas(emmtype,'EntericFermentation') or sameas(emmtype,'ManureManagement') or sameas[emmtype,'GrazingAnimals'] or sameas(emmtype,'N2Oindirect')))
	;


	$GROUP G_plant_static_calibration_partial_exo
		G_production_plant_exo

		dKInstCost2dK$(plant_sectors_sp[sp])

		# User-cost is computed in exogenous values part 
		# pPlant$(Plant_pK[Plant_]) 
		#  pPlantxInst
		pPlant$(tx0[t] and sameas[plant_,'land'])

		# All bottom layers are inverted - quantity for share-parameter
		qRxE_ym_plant$(d1RxE_ym[plant_sectors,s,t] and not input2Plant(s,Plant_sectors,'NPK') and not input2Plant(s,Plant_sectors,'Chemicals')), -sRxE_ym_plant$(d1RxE_ym[plant_sectors,s,t] and not input2Plant(s,Plant_sectors,'NPK') and not input2Plant(s,Plant_sectors,'Chemicals'))                        
		
		qPlant$(d1Plant[plant_sectors,plant_,t] and sameas[plant_,'manure']), -uPlant$(d1Plant[plant_sectors,plant_,t] and sameas[plant_,'manure'])
		qPlant$(d1Plant[plant_sectors,plant_,t] and plant_bottom[plant_]),    -uPlant$(d1Plant[plant_sectors,plant_,t] and plant_bottom[plant_])
		qPlant$(d1Plant[Plant_sectors,plant_,t] and sameas[plant_,'land']),   -uPlant$(d1Plant[plant_sectors,plant_,t] and sameas[plant_,'land'])
		# qPlant$(d1Plant[Plant_sectors,plant_,t] and plant_pK[plant_]),        -uPLant$(d1Plant[Plant_sectors,plant_,t] and plant_pk[Plant_])
		qPlant_capital$(d1Plant[Plant_sectors,plant_pK,t]),        -uPLant$(d1Plant[Plant_sectors,plant_,t] and plant_pk[Plant_])
	
		# Intermediate CES-goods are determined by fixing prices at 1. For animals, which are Leontief no price fixing is need
		pPlant$(d1Plant[Plant_sectors,plant_,t] and IOnestsPlant[plant_]),    -uPlant$(d1Plant[Plant_sectors,plant_,t] and IOnestsPlant[plant_])
		pPlant$(d1Plant[plant_sectors,plant_,t] and PlantNest[plant_] and not sameas[Plant_,'grossprod']), -uPlant$(d1Plant[plant_sectors,plant_,t] and PlantNest[plant_] and not sameas[Plant_,'grossprod'])

		dKInstCost2dI$(plant_sectors_sp[sp])
		dKInstCostLead2dI$(plant_sectors_sp[sp])
		pPlant_CET$(Plant_out_top[Plant_out]), -uPlant_CET
		pPlant_CET0$(plant_outNest[plant_out])

		-Plant_markup$(plant_out_top[plant_out]) 
		-Plant_markup_calib # E_markup_calib_plant

		qPlant_CET$(sameas[plant_out,'litter']) 

		# LINK
		qPlant$(chemNPK[plant_]), pPlant$(chemNPK[plant_])
		pK$(plant_sectors_sp[sp]) 

 		qEmmAgrxE$(d1EmmAgrxE[emmtype_,Agri_sectors,t,emm_eq] and not (sameas(emmtype_,'EntericFermentation') or sameas(emmtype_,'ManureManagement') or sameas(emmtype_,'GrazingAnimals') or sameas(emmtype_,'N2Oindirect'))), 
 		-uEmmAgrxE$(d1EmmAgrxE[emmtype,Agri_sectors,t,emm_eq] and not (sameas(emmtype,'EntericFermentation') or sameas(emmtype,'ManureManagement') or sameas[emmtype,'GrazingAnimals'] or sameas(emmtype,'N2Oindirect')))
	;

	$GROUP G_production_plant_static_calibration
		G_plant_static_calibration_partial
		pPlant_uc$(t1[t] and sameas[plant_pK,'TransportCapital']) #Because machines and transport capital are Leontief in same nest, they cannot both be shadow price for the nest. However, in static calibration we need to attach a value (through price) to one of them. We choose transportcapital

		G_GE_LINKS_PLANT
		pPlant_CET$(plant_out_top_m[plant_out] and d1Plant_CET0[plant_sectors,plant_out,t])
		qRxE_ym_plant$(d1RxE_ym[plant_sectors,s,t]) 
		qPlant$(Plant_bottom[Plant_] and not sameas[Plant_,'OtherEnergy'] and not chemNPK[Plant_]), uOtherEnergy_plant 
		qPlant_capital$(d1plant[plant_sectors,plant_pK,t])

		-pPlant_base$(d1Plant[plant_sectors,chemNPK,t]), jpPlant
		-pLand # Land-price is not determined when land-market is fixed
		
		jEmmAgrxE
		jvtLand
		
		vFirmDebtFromOtherModules$(plant_sectors_sp[sp]) 
;

	$GROUP G_production_plant_static_calibration_exo
		G_plant_static_calibration_partial_exo
		-pPlant$(Plant_pK[Plant_] and tx0[t]) #B_production_agr_static_calibration_LINK
		pPlant_base$(d1Plant[plant_sectors,chemNPK,t]), -jpPlant
		pLand # Land-price is not determined when land-market is fixed

		# Exogenous from link-equations 
		qY_CETgross$(plant_sectors_s[s])
		pY_CET$(plant_sectors_s[s])
		qRxE_ym$(d1RxE_ym[r,s,t] and plant_sectors_s[r])
		pRxE_ym$(d1RxE_ym[r,s,t] and plant_sectors_s[r])
		qK$(plant_sectors_s[s])
		qFin_k$(plant_sectors_s[r])
		pFin_k$(plant_sectors_r_[r])
		qL$(plant_sectors_s_[s_])
		tL$(plant_sectors_s[s])
		w 
		qEP$(plant_sectors_s[s]) 
		pEP$(plant_sectors_s[s]) 

;		

	$MODEL M_production_plant_static_calibration
		M_plant_static_calibration_partial
		B_production_agr_static_calibration_LINK, -E_tLand_calib
		-E_qRxE_ym_plant_chemNPK
		B_LINK_plant, -E_qFin_iB_LINK_Plant
		E_qEmmProdxE_agr_plant #We add this to calibrate J-term (difference between DST emissions and Climate Outlook)
	;

$ENDIF

# ======================================================================================================================
# Dynamic calibration
# ======================================================================================================================

$IF %stage% == "dynamic_calibration":

	$GROUP G_plant_calib_partial
		G_production_plant_endo

		# -qPlant$((Plant_pK[Plant_] and tData[t]) or (Plant_pK[Plant_] and t2[t])) # Capital is fixed in data years
		-qPlant_capital$(tData[t] or t2[t]) # Capital is fixed in data years
		-qPlant$(tData[t] and d1Plant[plant_sectors,plant_,t] and sameas[plant_,'land'])	
		jpK_plant$(not sameas[plant_pK,'TransportCapital']) 
		uPlant$(t2[t] and sameas[plant_,'TransportCapital']) #For some reason mink move a bit in t2 without this condition.

		qI_s$(plant_sectors_s[s] and tx0[t])
		qK$((t0[t] or tx0[t]) and plant_sectors_s[s])
		qFin_k$((t0[t] or tx0[t]) and plant_sectors_s[r]) #and sameas[k,'iM']
		qKInstCost$(tx0[t] and plant_sectors_s[s])
		dKInstCost2dK$(tx0[t] and plant_sectors_sp[sp])
		dKInstCost2dI$(tx0[t] and plant_sectors_sp[sp])
		dKInstCostLead2dI$(tx0E[t] and plant_sectors_sp[sp])

		-pLand$(tData[t])
		qLand$(t1[t]) # Total quantity of land at tStart is made endogenous to accomodate that land is fixed in t-Start
		jpK_land
	;

	$GROUP G_plant_calib_partial_exo
		G_production_plant_exo
		# qPlant$((Plant_pK[Plant_] and tData[t]) or (Plant_pK[Plant_] and t2[t]))
		qPlant_capital$(tData[t] or t2[t]) # Capital is fixed in data years
		qPlant$(tData[t] and d1Plant[plant_sectors,plant_,t] and sameas[plant_,'land'])
		-jpK_plant$(not sameas[plant_pK,'TransportCapital']) 
		-jpK_land
		-qI_s$(plant_sectors_s[s] and tx0[t])
		-qK$((t0[t] or tx0[t]) and plant_sectors_s[s])
		-qFin_k$((t0[t] or tx0[t]) and plant_sectors_s[r]) # and sameas[k,'iM']

		-qKInstCost$(tx0[t] and plant_sectors_s[s])
		pLand$(tData[t])
		-qLand$(t1[t])
	;


	$BLOCK B_plant_calib 
		
		E_jpK_plant[plant_sectors,plant_pK,k,t]$(d1K[k,plant_sectors,t] and agri2k[plant_pK,k] and tx1[t] and t.val > t2.val and not sameas[plant_pK,'TransportCapital'])..
			jpK_plant[plant_sectors,plant_pK,t] =E= jpK_plant[plant_sectors,plant_pK,t-1];

		E_jpK_land[plant_sectors,t]$(t.val > t2.val and d1Plant[plant_sectors,'land',t]).. 
			jpK_land[plant_sectors,t] =E= jpK_land[plant_sectors,t-1];


		# Capital accumulation and installation cost. We copy the CGE-version of equations
	    $LOOP00 E_qI_s:
	    	{name}_plant{sets}$({subsets} and plant_sectors_sp[sp]).. {LHS} =E= {RHS};
	    $ENDLOOP00

	    $LOOP00 E_qI_s_END:
	    	{name}_plant{sets}$({subsets} and plant_sectors_sp[sp]).. {LHS} =E= {RHS};
	    $ENDLOOP00

	    $LOOP00 E_qKInstCost:
	    	{name}_plant{sets}$({subsets} and plant_sectors_sp[sp]).. {LHS} =E= {RHS};
	    $ENDLOOP00


	    $LOOP00 E_dqKInstCost2dqK:
	    	{name}_plant{sets}$({subsets} and plant_sectors_sp[sp]).. {LHS} =E= {RHS};
	    $ENDLOOP00


	    $LOOP00 E_dqKInstCost2dqI_s:
	    	{name}_plant{sets}$({subsets} and plant_sectors_sp[sp]).. {LHS} =E= {RHS};
	    $ENDLOOP00

	    $LOOP00 E_dqKInstCostLead2dqI_s:
	    	{name}_plant{sets}$({subsets} and plant_sectors_sp[sp]).. {LHS} =E= {RHS};
	    $ENDLOOP00

	$ENDBLOCK 

	# Run a forecast on the partial equilibrium
	$MODEL M_plant_calib_partial 
		B_production_agr_plant
		B_emissions_agr_plant, -E_qEmmProdxE_agr_plant
		B_abatement_plant 
		B_plant_calib 
		B_CO2taxOnPlant

		#AKB
		E_qK_im_LINK_Plant
		E_qFin_iM_LINK_plant

		E_qK_ib_LINK_Plant
		E_qFin_iB_LINK_plant

		E_qK_it_LINK_plant
		E_qFin_iT_LINK_plant

		-E_DBII
	;

	$GROUP G_plant_calib_partial_exo
		G_plant_calib_partial_exo
		uEOPplant
		GWP
		sLeachOf2TotalN
		uEmmAgrxE$(plant_sectors[agri_sectors])
	;

	$GROUP G_plant_calib_partial
		G_plant_calib_partial
	;

#  	  COMMENT IN TO RUN PARTIAL MODEL

#  	 Note: Dynamic calibration of the partial model should perhaps include an actual equation for fKInstCost

 	# set_time_periods(%cal_start%, %terminal_year%);
 	# @set_dummies('2019',tx1);  # Use dummies from last data year in following periods
	
 	# fKInstCost.l[k,plant_sectors,tx1] = fq;
 	# rBonds.l[plant_sectors,t] = rBonds.l[plant_sectors,'2019'];
	

 	# $FIX G_plant_calib_partial_exo;
 	# $UNFIX G_plant_calib_partial;
 	# execute_unload 'output\pre.gdx';
 	# @SOLVE(M_plant_calib_partial);
#  	execute_unload 'output\plant_partial.gdx';
#  	@assert_no_difference(G_data,%tolerance_data%);
#  	$exit

	$MODEL M_production_plant_calib 
		B_production_agr_plant
		B_abatement_plant
		B_plant_calib,-E_qI_s_plant, -E_qI_s_end_plant,-E_qKInstCost_plant,-E_dqKInstCost2dqK_plant,-E_dqKInstCost2dqI_s_plant,-E_dqKInstCostLead2dqI_s_plant
		B_LINK_plant
		B_emissions_agr_plant
		B_CO2taxOnPlant
	;

	$GROUP G_production_plant_calib 
		G_production_plant_endo
		-qPlant$(tData[t] and d1Plant[plant_sectors,plant_,t] and sameas[plant_,'land'])
		jpK_plant$(not sameas[plant_pK,'TransportCapital'])
		jpK_land
		-qPlant$(tData[t] and d1Plant[plant_sectors,plant_,t] and sameas[plant_,'land'])
		G_GE_LINKS_PLANT
		G_GE_ENDOGENIZE_PLANT,-uProd$(plant_sectors_sp[sp] and prdCapital[prd] and (tData[t] or t2[t])) # Exogenous parameters in CGE-model that are endogenized to fit the CGE-sectors to the agricultural module.	
		G_GE_LINKS_EMMI_PLANT
		-pLand$(tData[t]) # pLand$(t.val = 2018)
		qLand$(t1[t]) # qLand at t1 is made endogenous to accomodate that the plant-sectors individual landuse is fixed
		uPlant$(t2[t] and sameas[plant_,'TransportCapital']) #For some reason mink move a bit in t2 without this condition.
	;

	$GROUP G_production_plant_calib_exo 
		G_production_plant_exo 
		-jpK_plant$(not sameas[plant_pK,'TransportCapital'])
		-jpK_land
		qPlant$(tData[t] and d1Plant[plant_sectors,plant_,t] and sameas[plant_,'land'])
		uProd$(plant_sectors_sp[sp] and prdCapital[prd] and (tData[t] or t2[t]))
		pLand$(tData[t])
		-qLand$(t1[t])
		;

	jpPlant.fx[plant_sectors,chemNPK,tForecast] = 0; 	# The difference between model movements and data are set to zero in forecast years
	jEmmAgrxE.l[plant_sectors,tForecast,emm] = 0; 		# The difference between DST and ENS i set to zero after data year
	qPlant_capital.l[plant_sectors,plant_pK,t]$(t.val>t2.val) = qPlant_capital.l[plant_sectors,plant_pK,t2];

$ENDIF