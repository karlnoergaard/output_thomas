# ======================================================================================================================
# Production
# ======================================================================================================================
# Demand for production and factors

# ======================================================================================================================
# Variable definition
# ======================================================================================================================

$IF %stage% == "variables":


    $GROUP G_production_private_prices
        pY_CET[out,s,t]$(d1vY_CET[out,s,t])     "Producer prices of various outputs, i.e marginal cost + mark-up" 
        pY0_CET[out,s,t]$(d1vY_CET[out,s,t])    "Marginal unit-cost incl. residual of production taxes on various outputs"
        pY0[s,t]                                "Marginal unit-cost incl. residual of production taxes"
        pY[s_,t]$(not stot[s_])                 "Domestic price level of final goods."
        pKELBM[s,t]                             "CES price of qKELBM aggregate = marginal unit cost of firms by sector"
        pEP[purpose,s,t]$(d1EP[purpose,s,t])    "CES-price of qEP aggregate"
        pREa[purpose,energy19a,s,t]$(d1pREa[purpose,energy19a,s,t])  "CES-price of qREa (=RE in absence of input-displacing abatement"

        pK[k,sp,t]$(d1K[k,sp,t])                "User cost of capital"
        pTobinsQ[k,sp,t]$(d1K[k,sp,t])          "Shadow price of capital or Tobin's Q"
        pL[sp,t]                                "Wage rate per productive labor unit including taxes (CES prices, except the Paasche chain of total wage payments)"
        w[t]                                    "Wage"
        pY_ElNl[t]                              "Price on electricity produced in the Netherlands"
        pRE_NatGasNL[t]                         "Price of natural gas used in production of electricity in the Netherlands"
        pProd[prd,sp,t]                         "Prices in private production nests"
        pK_scaled[k,sp,t]$(d1k[k,sp,t])          "User cost of capital scaled with the price of capital in last data-year"
    ; 

    $GROUP G_production_private_quantities
        qY_CETgross[out,s,t]                    "Gross-output (i.e including energy-input for own-consumption"
        qY[s,t]                                 "Aggregate output"
        qKELBM[s,t]                             "CES-aggregate between KLB-aggregate and materials"
        qK[k,s,t]$(d1K[k,s,t])                  "Capital"
        qRxE[r_,t]                              "Material input in sector s (raw materials and intermediate goods and services)"
        qI_s[i_,s,t]$(d1I_s[i_,s,t])            "Investment input demanded by sector s"
        qKInstCost[k_,s,t]$(d1K[k_,s,t])        "Installation costs of capital by sector"     
        qE[s,t]                                 "CES-aggregate of energy-goods"
        qEP[purpose,s,t]$(d1EP[purpose,s,t])    "CES-aggregate of energy-goods for various purposes"
        qREa[purpose,energy19a,s,t]$(d1pREa[purpose,energy19a,s,t])   "Energy activity (peta-Joule) split on purpose and energy-type"
        qL[s_,t]                                "Labor"
        qY_ElNl[t]                              "Production of electricity in the Netherlands"
        qRE_NatGasNL[t]                         "Natural gas used in production of eletricity in the Netherlands"
        qFin_k[k,r,t]$(d1Fin_k[k,r,t])          "Material inputs from the financial sector of domestic origin"
        qProd[prd,sp,t]                         "Quantities in private production nests"
        qK_scaled[k,sp,t]$(d1K[k,sp,t])           "Capital scaled with the price of capital in last data-year"
    ;


    $GROUP G_production_private_values  
        vY[s_,t]$(not stot[s_])                 "Value of output, including mark-up"
        vFirmDebt[sp,t]                         "Value of firm-debt"
        vGrossValAdd[s_,t]                      "Aggregate nominal value of Gross Value Added in kr. bn (BVT)"
        vEBITDA[s_,t]                           "Earnings before interests, taxes, depreciation, and amortization"
        vEBT[s_,t]                              "Earnings before taxes - fortjeneste før beskatning"
        vtCorpMain[s_,t]                        "Revenue from corporate taxation exluding the extraction sector (Selskabsskat øvrige selskaber) <T_{s,t}^{Corp}>"
        vFCFE[s_,t]                             "Free Cash Flow to Equity of domestic firms "
        vEquity[s_,t]                           "Value of domestic shares"
        vKtax[k_,s_,t]                          "Posted (Bogført) value of total stock of capital distributed on industry (brancher)"
        vREa[purpose,energy19a,s,t]$(d1pREa[purpose,energy19a,s,t])  "Value of energy activity split on purposes and energy-type"
        vEP[purpose,s,t]$(d1EP[purpose,s,t])    "Value of energy input split on purpose"
        vDistributionProfits_e19[energy19,sp,t]$(d1vY_CET[energy19,sp,t])    "Any distribution profits accrued by the firm from the selling of energy-goods"
        vFirmDebtFromOtherModules[sp,t]         "Firm Debt from other Modules"
        vtCO2_LULUCF[t]                         "(Negative) tax on LULUCF-emissions in agritulture"
        vtCO2_organicinproduction[t]            "Tax revenue for emmisions on peatlands (lavbundsjorde) in production"
        vtCO2_organic_outofproduction[t]        "Tax revenue for emmisions on peatlands (lavbundsjorde) out of production"

    ;

    $GROUP G_production_private_other
        uY_CET[out,s,t]                         "Scale parameter for qY_CET in in the production function"
        uRE[purpose,energy19a,s,t]              ""
        uKInstCost[k,s,t]                       "Parameter for installation costs of capital"
        uEP[purpose,sp,t]                       "Scale parameter for energy-aggregates split on purpose"

        nEmployed_s[s,t]                        "Number of employed"
        fW[s,t]                                 ""
        fW0[s,t]                                ""

        
        eCET[s]                                 "Elasticity of transformation between qY_CET"
        eKELBM[sp]                              "Elasticity of substitution between qRxE and qKELB"
        eKELB[sp]                               "Elasticity of substitution between qK['ib',sp,t] and qKEL"
        eKEL[sp]                                "Elasticity of substitution between qL and qKE"
        eKETM[sp]                               ""
        eTKE[sp]                                ""
        eMKE[sp]                                ""
        eREP[s]                                 "Elasticity of substitution between the different energy-purposes "
        eRE[purpose,s]                          "Elasticity of substitution between the different energy-goods"
      
        tCorp[t]                               "Corporate tax rate <t_{s,t}^{Corp}> <t_{s,t}^{Corp}>"
        tCorpRes[t]                            "Correction in vtCorp to fit macro data"
        tK[k,s,t]$(d1K[k,s,t])                 "Tax rate on capital in production"

        EKtax[k,sp,t]$(d1K[k,sp,t])            "Shadow price of tax deductible value of capital"

        rFirms[sp,t]                           "Sector specific discount rate of firms (hurdle rate)."
        rInvestor[sp,t]                        "Investors required return/discount rate"
        rDepr[k,s,t]                           "Depreciation rate of capital"
        rTaxDep[k,t]                           "Tax depreciation rate (Skattemæssig afskrivningsrate)"
        rBonds[s,t]                            "Average bonds rate. (Obligationsrentegennemsnit: Almindelige og særlige realkreditobligationer)"
        rInterest[portfolio,t]                 "Interest and dividends on financial portfolio"
        sDebt2K[k,s,t]                         "Share of investments that are financed through debt"
        rIL[s,t]                               "Share of total production going to inventory-investments (lagerinvesteringer)"
        markup[out,s,t]$(d1vY_CET[out,s,t])    "Product specific mark-up"
        markup_cali[s,t]                       "Mark-up is calibrated by equating it across different outputs in data-years" 

        rDepr_static[k,s,t]                    "Smoothed depreciation rate for static calibration (Udglattet afskrivningsrate til statisk kalibrering)"
        gpI_s_static[k,s,t]                    "Smoothed inflation rate for investments for static calibration (Udglattet prisstigningsrate for investeringer til statisk kalibrering)"

      
        prod_a[t]                              "Labor productivity factor"
        jpK[k,sp,t]                            "Additive error-term. The wedge explains why the investment in last data-year does not match what the investment should have been giving the user-cost produced by the model"
        fKInstCost[k,s,t]                      "Growth factor in investments yielding zero installation costs (Vækstfaktor i investeringer som giver nul installationsomkostningerne)"
        j_pREa[purpose,energy19a,s,t]          "Correction term (= 0 when abatement module is not active)"
        prod_s[s,t]                            "Public productivity i public CES-price"

        jqI_s[k,s,t]                           ""

        uProd[prd,sp,t]$(not prdTop(prd))      "Scale parameter in private production nests"
        thetaProd[prd,sp,t]$(not prdTop(prd))  "Productivity of labor"
        TFP[prdNest,sp,t]                 "Total-factor productivity"
        eProd[prd,sp]                          "Elasticity of substitution between production nests"
        jpProd[prd,sp,t]                       "Additive error-term for production nest"

        z[t]                                  "Time dependent work-productivity (arbejdsproduktivitet)"
        vtNetProduction[s_,t]                 "Value of production taxes"
    ;


    $GROUP G_baseline_production
        prod_branche[s,t]$(tendo[t])           "Indutry productivity (Brancheproduktivitet)"
        korr[t]$(tendo[t])                     "Adjustment between GDP and raw production value growth (Korrektion ml. BNP og rå produktionsværditilvækst)"
        N_L[s,t]$(tendo[t])                    "Effective work productivity? (Noget effektiv arbejdsproduktivitet måske?)"
    ;


$GROUP G_production_report
    prod_branche[s,t]$(tendo[t])           "Indutry productivity (Brancheproduktivitet)"
    korr[t]$(tendo[t])                     "Adjustment between GDP and raw production value growth (Korrektion ml. BNP og rå produktionsværditilvækst)"
    N_L[s,t]$(tendo[t])                    "Effektiv work productivity? (Noget effektiv arbejdsproduktivitet måske?)"
;






$ENDIF 


$IF %stage% == "groupcompilation":

# ======================================================================================================================
# Compiling groups of endogenous and exogenous values
# ======================================================================================================================

$GROUP G_production_private_cet_endo 
    qY_CETgross$(sp[s])     #E_qY_CETgross_e19, E_qY_CETgross_oth, E_qY_CETgross_WholeAndRetailSaleMarginE
    pY0_CET$(d1vY_CET[out,s,t] and sp[s])     #E_pY_CET0
    qY   #E_qY
    pY_CET$(d1vY_CET[out,s,t] and sp[s])    #E_pY_CET
    vY$(s[s_] and not sameas(s_,'off'))    #E_vY
    pY$(s[s_] and not sameas(s_,'off'))     #E_pY
    qKELBM$(sp[s])    #E_qKELBM
    pKELBM$(sp[s])    #E_pKELBM
    pY0$(sp[s])    #E_pY0
    qREa$(tx0[t] and d1pREa[purpose,energy19a,s,t] and eNotInEnergyNest[purpose,energy19a,s,t]) #E_qRE
;

$GROUP G_production_private_cet_exo 
    #E_qY_CETgross_e19
    qY_CET$(tx0[t] and sp[s])
    qREgj$(tx0[t] and sp[r] and d1pREown[purpose,energy19,r,t]), 
    sFireWood_AFF[t]$(tx0[t]), qC5_Energy_AFF_xMill_smooth[t]$(tx0[t])     

    #E_qY_CETgross_oth
    sUseWood_AFF[t]$(tx0[t]), qY_CET_outother_02000_usewood_AFF_smooth[t]$(tx0[t])

    #E_pY_CET0
    uY_CET$(tx0[t] and d1vY_CET[out,s,t]) 
    eCET

    #E_pY_CET
    markup$(tx0[t] and d1vY_CET[out,s,t])

    #E_vY
    pY_ElNL$(tx0[t]), qY_ElNl$(tx0[t]), pWoodproduct_markup$(tx0[t]), pXE_bionatgas[t]$(tx0[t]), qXE_bionatgas[t]$(tx0[t])

    #E_pY0
    vtNetProductionRest$(tx0[t]), vtCAP_top$(agri_sectors_s[s] and tx0[t]), vtBotDed$(tx0[t]), vtCO2_ETSxE_marg$(tx0[t] and d1EmmProdxE[r,t,'CO2ubio'] and d1CO2_ETS[r,t]), vtVAT_RE$(tx0[t] and d1VAT_RE[purpose,energy19,r,t])
    pRE_base$(tx0[t] and d1pRE_base[purpose,energy19,r,t]), qREgj$(tx0[t] and sp[r] and d1pRE_base[purpose,energy19,r,t]), pRE_base_marg$(tx0[t]),

    #E_qRE
    uRE$(tx0[t] and d1pREa[purpose,energy19a,s,t] and sp[s] and eNotInEnergyNest[purpose,energy19a,s,t])
;

$GROUP G_production_private_ces_endo
    qProd$(d1Prod[prd,sp,t])    # E_qProd_map
    pProd$(d1Prod[prd,sp,t])    # E_pProd_map
    qFin_k$(d1Fin_k[k,r,t])   # E_qFin_map
    qRxE$(r[r_] and not sameas(r_,'off'))    # E_qRxE_map
;

$GROUP G_production_private_ces_exo
    # E_qProd_map_notUlt    E_qProd_map_Ult
    TFP$(d1Prod[prdNest,sp,t])
    thetaProd$(tx0[t] and d1Prod[prd,sp,t] and not prdTop(prd))
    uProd$(tx0[t] and d1Prod[prd,sp,t] and not prdTop(prd))
    eProd #

    # E_pK_map
    jpProd$(tx0[t] and d1Prod[prd,sp,t])
    pK_scaled$(d1K[k,sp,t])
 
    # E_pRxE_map
    pRxE$(tx0[t])

    # E_pFin_map
    pFin_k$(tx0[t])
;

$GROUP   G_production_private_energy_endo
    qEP$(sp[s] and d1EP[purpose,s,t])    #E_qEP_trans E_qEP
    pEP$(d1EP[purpose,s,t] and sp[s])    #E_pEP_trans E_pEP
    qREa$(tx0[t] and sp[s] and d1pREa[purpose,energy19a,s,t] and not eNotInEnergyNest[purpose,energy19a,s,t])    #E_qRE_trans E_qREa
    pREa$(d1pREa[purpose,energy19a,s,t] and sp[s])    # E_pREa
;

$GROUP   G_production_private_energy_exo
    #E_qRE_trans E_qREa
    uRE$(tx0[t] and sp[s] and d1pREa[purpose,energy19a,s,t] and not eNotInEnergyNest[purpose,energy19a,s,t])
    eRE$(sp[s])

    #E_qEP_trans E_qEP
    uEP$(tx0[t] and d1EP[purpose,sp,t])
    eREP

    # E_pREa
    pREgj$(tx0[t] and d1pREgj[purpose,energy19,r,t])
    j_pREa$(tx0[t] and sp[s] and d1pREa[purpose,energy19a,s,t])
;

$GROUP G_production_private_uc_endo
    pK$(d1K[k,sp,t])    # E_pK
    pTobinsQ$(d1K[k,sp,t])    # E_pTobinsQ E_pTobinsQ_tEnd
    EKtax$(d1K[k,sp,t]) # E_EKtax E_EKtax_tEnd
    qKInstCost$(d1K[k_,s,t] and sp[s])  # E_qKInstCost_kTot E_qKInstCost
    dKInstCost2dK[k,sp,t]$(d1K[k,sp,t])                 "qKInstCost differentieret ift. qK[t-1]" # E_dqKInstCost2dqK
    dKInstCost2dI[k,sp,t]$(d1K[k,sp,t])                 "qKInstCost differentieret ift. qI_s" # E_dqKInstCost2dqI_s
    dKInstCostLead2dI[k,sp,t]$(tx0E[t] and d1K[k,sp,t]) "qKInstCost[t+1] differentieret ift. qI_s" # E_dqKInstCostLead2dqI_s
    #  qK$(d1K[k,s,t] and sp[s])    # E_qK_scaled
    qProd$(d1prod[prd,sp,t] and prdBotUlt(prd) and t0[t])    # E_qK_scaled
    #  pK_scaled$(d1K[k,sp,t])

;

$GROUP G_production_private_uc_exo
    # E_pK
    tCorp
    rFirms
    rDepr$(tx0[t] and sp[s] and d1K[k,s,t])
    tK$(tx0[t] and sp[s] and d1K[k,s,t])
    pI_s$(sp[s] and d1K[i_,s,t])
    rBonds$(sp[s])
    sDebt2k$(tx0[t] and sp[s])
    jpK

    #E_pTobinsQ E_pTobinsQ_tEnd
    EKtax$(tx0[t] and d1K[k,sp,t])

    # E_EKtax E_EKtax_tEnd
    rTaxDep$(tx0[t])

    # E_qKInstCost_kTot E_qKInstCost E_dqKInstCost2dqI_s E_dqKInstCostLead2dqI_s
    uKInstCost$(tx0[t] and sp[s] and d1K[k,s,t])
    qI_s$(t0[t] and sp[s])
    fKInstCost$(tx0[t] and sp[s] and d1K[k,s,t])
    qK$(t0[t] and sp[s])

    pK$(tDataEnd[t]) #Scaling
;

$GROUP G_production_private_inv_endo
    #  qK_scaled$(tx0[t] and d1K[k,sp,t]) # E_qK_map
    qK$(d1K[k,s,t] and sp[s])    
    qI_s$(d1I_s[i_,s,t] and i[i_] and sp[s])     #E_qI_s
;

$GROUP G_production_private_inv_exo
    jqI_s$(sp[s] and d1K[k,s,t])#$(tx0[t] and sp[s] and d1K[k,s,t])

    # E_qI_s_inv
    pI_s$(t0[t] and sameas[i_,'invt'])
    rIL$(sp[s])#$(tx0[t] and sp[s])
    pY$(t0[t] and s[s_] and not sameas(s_,'off'))
;

$GROUP G_production_private_finance_endo
    vKtax    # E_vKtax_Im E_vKtax_Ib E_vKtax_It
    vFirmDebt  # E_vFirmDebt
    vREa$(d1pREa[purpose,energy19a,s,t] and sp[s])   # E_vREa
    vGrossValAdd$(not sameas(s_,'off'))    # E_vGrossValAdd E_vGrossValAdd_tot
    vEBITDA   # E_vEBITDA E_vEBITDA_tot
    vEBT    # E_vEBT
    vtCorpMain   # E_vtCorpMain
    vFCFE   # E_vFCFE
    vDistributionProfits_e19$(d1vY_CET[energy19,sp,t])     # E_vDistributionProfits_share
    vEquity    # E_vEquity E_vEquity_terminal
;

$GROUP G_production_private_finance_exo
    # E_vKtax_Im E_vKtax_Ib E_vKtax_It
    vKtax$(t0[t])
    vI_s$(tx0[t] and sp[s] and $d1I_s[i_,s,t])
    
    # E_vFirmDebt
    vFirmDebtFromOtherModules$(tx0[t])

    # E_vREa
    pREgj$(tx0[t] and sp[r] and d1pREa[purpose,energy19,r,t])
    tvREmarg$(tx0[t] and sp[r] and d1pREa[purpose,energy19,r,t])
    pREown$(tx0[t] and sp[r] and d1pREa[purpose,energy19,r,t])

    # E_vGrossValAdd E_vGrossValAdd_tot
    vRxE$(tx0[t]), vFin$(tx0[t] and sp[r])
    vtCO2_ProdxE$(tx0[t] and sp[s] and d1EmmProdxE[s,t,emm] and d1CO2_ProdxE[s,t,emm])
    vtEAFG_RE$(tx0[t] and sp[r] and d1EAFG_RE[purpose,energy19,r,t])
    vtEAFG_REmarg$(tx0[t] and sp[r] and d1EAFG_RE[purpose,energy19,r,t])
    vtCO2_RE$(tx0[t] and sp[r] and d1CO2_RE[purpose,energy19,r,t])
    vtCO2_REmarg$(tx0[t] and sp[r] and d1CO2_RE[purpose,energy19,r,t])
    vtCO2_ETS_marg$(tx0[t] and sp[r] and d1CO2_ETS[r,t])
    pRE_NatGasNL, qRE_NatGasNL
    vRxEEOP_ani$(tx0[t] and sum(Emmtype, sum(animals,d1vEOPCostAni[Emmtype,ani_sectors,s,animals,t])))
    vRxEEOP_plant$(tx0[t] and sum(Emmtype,d1vEOPCostplant[Emmtype,plant_sectors,s,t]))
    tCALIBENS$(tx0[t] and sp[r] and d1tRE[purpose,energy19,r,t])
    qREgj$(tx0[t] and sp[r] and d1tRE[purpose,energy19,r,t])
    vLE$(tx0[t] and d1vLE[purpose,energy19,t])
    vGrossValAdd$(tx0[t] and sameas(s_,'off'))

    # E_vEBITDA E_vEBITDA_tot
    vSubsidy_CCS_EmmxE$(tx0[t] and sp[s])
    vtLand$(tx0[t] and s[s_] and not sameas(s_,'off'))
    vtLPayRoll$(tx0[t] and s[s_] and not sameas(s_,'off'))
    vtFirmsWeight$(tx0[t] and s[s_] and not sameas(s_,'off'))
    vtLAM$(tx0[t] and s[s_] and not sameas(s_,'off'))
    vtCAP$(tx0[t] and agri_sectors_s[s])
    vtLSubsidy$(tx0[t] and s[s_] and not sameas(s_,'off'))
    vGovReceiveFirms$(tx0[t])
    vGov2Firms$(tx0[t])
    vGovRent$(tx0[t])
    vtCO2_LULUCF$(tx0[t])
    vKompOmk$(tx0[t])
    vtCO2_organicinproduction$(tx0[t])
    vtCO2_organic_outofproduction$(tx0[t])
    vtPerHectareBottomDeduction$(tx0[t] and plant_sectors_sp[sp])
    vCO2_ani$(tx0[t] and d1EmmAgrAni[emmtype,ani_sectors,Animals,t,'CO2e'])
    vCO2_plant$(tx0[t] and sum(emmtype, emmtype2plant_[emmtype,plant_] and d1EmmAgrxE[emmtype,plant_sectors,t,'CO2e']))
    vTech_subsidy_ani$(tx0[t] and sum(emm,d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]))
    vTech_subsidy_plant$(tx0[t] and sum(emm,d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]))
    vOtherDistributionProfits_EAV$(tx0[t])
    vOtherDistributionProfits_DAV$(tx0[t])
    vOtherDistributionProfits_CAV$(tx0[t])
    vBotdedPerAnimal
    tAfforestationPerHa$(tx0[t])  
    vSubProductionRest$(tx0[t])
    qLand_Nonproductive$(tx0[t] or t0[t])
    # pyrolyse
    vSubsidy_Pyrolyse[t]$(tx0[t] and sum(PyrolyseTech, d1PyrolysePot[PyrolyseTech,t]))  ""
    vBiomass_Pyrolyse[t]$(tx0[t] and sum(PyrolyseTech, d1PyrolysePot[PyrolyseTech,t])) ""
    qI_Pyrolyse_actual[PyrolyseTech,t]$(tx0[t] and sum(tt, d1PyrolysePot[PyrolyseTech,tt])) ""

    # E_vEBT
    vFirmDebt$(t0[t])

    # E_vtCorpMain
    tCorpRes$(tx0[t])

    # E_vFCFE
    qI_s_afforestation$(tx0[t])
    qI_s_afforestation_inst$(tx0[t])
    vI_EOPCostAni$(tx0[t] and sameas(i,'iM') and sum(emm,d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]))
    vI_EOPCostplant$(tx0[t] and sameas(i,'iM') and sum(emm,d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm]))
    jvtCorp$(tx0[t])

    # E_vDistributionProfits_share
    vDistributionProfits$(tx0[t])

    # E_vEquity E_vEquity_terminal
    rInvestor$(txE[t])

;

$GROUP G_production_private_labor_market_endo
    qL$(s[s_] and not sameas(s_,'off')) # E_qL_map
    pL  # E_pL
    nEmployed_s  # E_nL
    w  # E_nL_tot
    fW  #E_fW
;

$GROUP G_production_private_labor_market_exo
    # E_pL
    tL$(tx0[t] and sp[s])

    # E_nL
    qL$(tx0[t] and sameas(s_,'off'))
    prod_a$(tx0[t])
    Hours$(tx0[t])
    nEmployed_s$(tx0[t])
    nEmployed$(tx0[t])

    # E_fW
    fW0$(tx0[t])
;

    $GROUP G_production_private_endo
    G_production_private_cet_endo
       -pY_CET$(sameas[s,'0600a'] and d1vY_CET[out,s,t]), markup$(sameas[s,'0600a'] and d1vY_CET[out,s,t])
       -pY_CET$(sameas[s,'19000'] and d1vY_CET[out,s,t] and energy19[out] and not (sameas[out,'refinery gas'] or sameas[out,'semi-refined oil'])), markup$(sameas[s,'19000'] and d1vY_CET[out,s,t] and energy19[out] and not (sameas[out,'refinery gas'] or sameas[out,'semi-refined oil']))
       -pY_CET$(sameas[s,'51001'] and d1vY_CET[out,s,t]), markup$(sameas[s,'51001'] and d1vY_CET[out,s,t])
    G_production_private_ces_endo
    G_production_private_energy_endo
        -pREa$(sp[s])
        pREa$(tx0[t] and sp[s]and d1pREa[purpose,energy19a,s,t] and not (sum(techID, d1thetaID_k[techID,purpose,energy19a,s,t]) or sum(techCCS, sum(emm, d1thetaCCS[techCCS,purpose,energy19a,s,t,emm])) or sum(energy19,d1vREE_transport[purpose,energy19a,energy19,s,t])))
        j_pREa$(tx0[t] and sp[s] and d1pREa[purpose,energy19a,s,t] and (sum(techID, d1thetaID_k[techID,purpose,energy19a,s,t]) or sum(techCCS, sum(emm, d1thetaCCS[techCCS,purpose,energy19a,s,t,emm])) or sum(energy19,d1vREE_transport[purpose,energy19a,energy19,s,t])))
    G_production_private_uc_endo
       qProd$(d1Prod[prd,sp,t] and prdBotUlt(prd) and t0[t]) # E_qK_map
    G_production_private_inv_endo
    G_production_private_finance_endo
    G_production_private_labor_market_endo
    ;

    $GROUP G_production_non_flat_initial_values_from_MAKRO
        prod_s # Only public sector productivity is from MAKRO
        qI_s$(sameas(s,'OFF') and not sameas(i_,'invt'))
        uKinstcost$(sameas[s,'01051'] and sameas[k,'iB'])
        j_pKELBM_off_markup
    ;

    $GROUP G_production_private_endo G_production_private_endo$(tx0[t]), vEquity$(t0[t]);

    $GROUP G_production_private_exo  
	G_production_private_cet_exo
	    pY_CET$(sameas[s,'0600a'] and d1vY_CET[out,s,t]), -markup$(sameas[s,'0600a'] and d1vY_CET[out,s,t])
	    pY_CET$(sameas[s,'19000'] and d1vY_CET[out,s,t] and energy19[out] and not (sameas[out,'refinery gas'] or sameas[out,'semi-refined oil'])), -markup$(sameas[s,'19000'] and d1vY_CET[out,s,t] and energy19[out] and not (sameas[out,'refinery gas'] or sameas[out,'semi-refined oil']))
	    pY_CET$(sameas[s,'51001'] and d1vY_CET[out,s,t]), -markup$(sameas[s,'51001'] and d1vY_CET[out,s,t])
	G_production_private_ces_exo
	G_production_private_energy_exo
	    -j_pREa
	    pREa$(tx0[t] and d1pREa[purpose,energy19a,s,t] and (sum(techID, d1thetaID_k[techID,purpose,energy19a,s,t]) or sum(techCCS, sum(emm, d1thetaCCS[techCCS,purpose,energy19a,s,t,emm])) or sum(energy19,d1vREE_transport[purpose,energy19a,energy19,s,t])))
	    j_pREa$(tx0[t] and d1pREa[purpose,energy19a,s,t] and not (sum(techID, d1thetaID_k[techID,purpose,energy19a,s,t]) or sum(techCCS, sum(emm, d1thetaCCS[techCCS,purpose,energy19a,s,t,emm])) or sum(energy19,d1vREE_transport[purpose,energy19a,energy19,s,t])))
	G_production_private_uc_exo
	    -EKtax
	G_production_private_inv_exo
	G_production_private_finance_exo
	G_production_private_labor_market_exo
    vtNetProduction
;

    $GROUP G_production_private_data 
        pL[s,t] 
        #  pY[s_,t] 
        pRxE[r_,t]      
        pI_s[i_,s,t] 
        qI_s[i_,s,t] #, -qI_s$(sum(ns69, ns692s(ns69,s)))  
        qY[s_,t]       
        qK[k,s,t] #, -qK$(sum(ns69, ns692s(ns69,s)))     
        qL[s,t]       
        qRxE[r_,t]     
        vI_s[i_,s,t] #,-vI_s$(sum(ns69, ns692s(ns69,s))) 
        vRxE[r_,t]   
        #  vRE[r_,t]    
        vY[s_,t]    
        rBonds 
        rFirms      
        pY_CET
        pY  
        vGrossValAdd
        pY_ElNL
        qY_ElNl
        qRE_NatGasNL
        pRE_NatGasNL
    ;

    $GROUP G_production_report_exo 
    z
    thetaProd['L',sp,t]
    qL
    pY 
    qY 
    pRxE 
    qRxE 
    pE_CGE  
    qE  
    pGDP  
    vGDP  

;    

$GROUP G_production_report_exo 
    G_production_report_exo$(tEndo[t])
; 


$ENDIF

# ======================================================================================================================
# Equations
# ======================================================================================================================
$IF %stage% == "equations":

    $BLOCK B_production_private_cet

    # ------------------------------------------------------------------------------------------------------------------
    # CET-transformation of output
    # ------------------------------------------------------------------------------------------------------------------

    # For consumption of own-produced energy-good we introduce the following two equations.qY_CETgross is production incl. production for own-consumption
    E_qY_CETgross_e19[energy19,sp,t]$(tx0[t] and d1vY_CET[energy19,sp,t]).. qY_CETgross[energy19,sp,t] =E= qY_CET[energy19,sp,t] + sum((purpose,r)$(d1pREown[purpose,energy19,r,t] and mapownproduction(energy19,r,sp)), qREgj[purpose,energy19,r,t])
                                                                                                                             - (sFireWood_AFF[t] *qC5_Energy_AFF_xMill_smooth[t]*44/12/103.4)$(sameas[sp,'02000'] and sameas[energy19,'Firewood and woodchips']); 
                                                                                                                                                                                          

    E_qY_CETgross_oth[sp,t]$(tx0[t] and d1vY_CET['out_other',sp,t])..    qY_CETgross['out_other',sp,t] =E= qY_CET['out_other',sp,t] - (sUseWood_AFF[t] * qY_CET_outother_02000_usewood_AFF_smooth[t])$(sameas[sp,'02000']);

    E_qY_CETgross_WholeAndRetailSaleMarginE[sp,t]$(tx0[t] and d1vY_CET['WholeAndRetailSaleMarginE',sp,t])..
                                                                      qY_CETgross['WholeAndRetailSaleMarginE',sp,t] =E= qY_CET['WholeAndRetailSaleMarginE',sp,t];
   
    E_pY_CET0[out,sp,t]$(tx0[t] and d1vY_CET[out,sp,t]).. qY_CETgross[out,sp,t] =E= uY_CET[out,sp,t] * (pY0_CET[out,sp,t]/pY0[sp,t])**eCET[sp] *qY[sp,t];

    E_qY[sp,t]$(tx0[t])..    pY0[sp,t]*qY[sp,t] =E= sum(out$d1vY_CET[out,sp,t], pY0_CET[out,sp,t] * qY_CETgross[out,sp,t]); 


    E_pY_CET[out,sp,t]$(tx0[t] and d1vY_CET[out,sp,t]).. pY_CET[out,sp,t] =E= (1+markup[out,sp,t]) * pY0_CET[out,sp,t];        


    #"Average" output-price is computed (£AKB: Is marginally poluted by the crossing of qY being including production for own-consumption.)
    E_vY[sp,t]$(tx0[t])..               vY[sp,t]               =E= sum(out$d1vY_CET[out,sp,t], pY_CET[out,sp,t] * qY_CET[out,sp,t])$(not sameas[sp,'19000'])
                                                                +sum(out$d1vY_CET[out,sp,t], pY_CET[out,sp,t] * qY_CETgross[out,sp,t])$(sameas[sp,'19000']) #For refineries own-consumption of refinery-gas is recorded in National Accounts and hence should be included in computation of NA-value
                                                                +  (pY_ElNL[t]*qY_ElNl[t])$(sameas[sp,'35011'] and t.val <= 2019) #Revenue from Ørsteds joint venture (ended after 2019) 
                                                                +  (pWoodproduct_markup[t]*qD_usewood_CGE[t])$(sameas[sp,'02000']) #Revenue from woodproduct mark-up
                                                                +  (pXE_bionatgas[t] * qXE_bionatgas[t])$(sameas[sp,'35002']); 


   E_pY[sp,t]$(tx0[t])..               vY[sp,t] =E= pY[sp,t] * qY[sp,t];

                     

    # ------------------------------------------------------------------------------------------------------------------
    # Gross production from net production
    # ------------------------------------------------------------------------------------------------------------------
 
     E_qKELBM[sp,t]$(tx0[t])..  qKELBM[sp,t] =E= qY[sp,t] + sum(k$d1K[k,sp,t], qKInstCost[k,sp,t]);

     E_pKELBM[sp,t]$(tx0[t]).. pKELBM[sp,t] =E= pProd['KELBM',sp,t]; # Link to production nest 

     E_pY0[sp,t]$(tx0[t])..      pY0[sp,t] * qY[sp,t] =E= pKELBM[sp,t] * qY[sp,t] 
                                                     + vtNetProductionRest[sp,t]
                                                     + vtCAP_top[sp,t]$(agri_sectors_s[sp])
                                                    #Basic deduction (Bundfradrag) on energy, incl. basic deduction from free quotas (gratiskvoter) in ETS
                                                     + vtBotDed[sp,t]$(not sameas[sp,'51001']) #Vi lader ikke indenrigsluftfarten indprise deres bundfradrag i endelig pris
                                                     + vtCO2_ETSxE_marg[sp,t]$(d1EmmProdxE[sp,t,'CO2e'] and d1CO2_ETS[sp,t])
                                                     + sum((purpose,energy19)$(d1pREa[purpose,energy19,sp,t] and eNotInEnergyNest[purpose,energy19,sp,t]), pREa[purpose,energy19,sp,t]*qREa[purpose,energy19,sp,t])
                                                     + sum((purpose,energy19)$(d1VAT_RE[purpose,energy19,sp,t]), vtVAT_RE[purpose,energy19,sp,t]) #VAT is not paid on the margin. For now we add it add the top.
                                                     + (pRE_NatGasNL[t]*qRE_NatGasNL[t])$(sameas[sp,'35011'] and t.val <= 2019)
                                                     + sum(emm$(d1EmmProdxE[sp,t,emm] and d1CO2_ProdxE[sp,t,emm]), vtCO2_ProdxE[sp,t,emm])                         # CO2e-tax on non-energy related emissions
                                                     + sum(emm$(d1EmmProdxE[sp,t,emm] and sum(techCCS, d1thetaCCSxE[techCCS,sp,t,emm]) and sameas[emm,'CO2ubio']),   
                                                                                                               + qLEVC_CCS_EmmxE[sp,t,emm]*pI_s['iM',sp,t]        # LEVC on non-energy related CCS
                                                                                                               - vSubsidy_CCS_EmmxE[sp,t,emm])                  # Subsidy to non-energy related CCS
                                                     + sum((purpose,energy19)$(d1pRE_base[purpose,energy19,sp,t]),(pRE_base[purpose,energy19,sp,t]-pRE_base_marg[purpose,energy19,sp,t])*qREgj[purpose,energy19,sp,t])
                                                    #  - sum((purpose,energy19)$(d1tRE[purpose,energy19,s,t]), vtCalibENS[purpose,energy19,s,t])
                                                    ;    
    
    #£AKB: Kategorien opsamler ikke fuldstændig efterspørgslen, find ud af hvilke små celler, der mangler.
    #  E_qRE_natgas[t]$(tx0[t]).. qRE['process_special','Natural gas (Extraction)','35002',t] =E= uRE['process_special','Natural gas (Extraction)','35002',t] * qY_CETgross['Natural gas (Incl. city-gas)','35002',t];

    #The demand for natural gas from North-sea or imported is the total demand for gas minus biogas converted to biongas
    E_qRE_natgas[t]$(tx0[t] and d1pREa['process_special','Natural gas (Extraction)','35002',t] and eNotInEnergyNest['process_special','Natural gas (Extraction)','35002',t]).. 
        qREa['process_special','Natural gas (Extraction)','35002',t] =E= 
            uRE['process_special','Natural gas (Extraction)','35002',t] * (qY_CETgross['Natural gas incl. biongas','35002',t] - qREa['process_special','Biogas','35002',t]);

    E_qRE_biogas[t]$(tx0[t] and d1pREa['process_special','Biogas','35002',t] and eNotInEnergyNest['process_special','Biogas','35002',t]).. 
        qREa['process_special','Biogas','35002',t] =E= uRE['process_special','biogas','35002',t] * qREa.l['process_special','Biogas','35002',t];  #* qY_CETgross['Biongas','35002',t];

    E_qRE_el[t]$(tx0[t] and d1pREa['process_special','El from y and m','35012',t] and eNotInEnergyNest['process_special','El from y and m','35012',t])..  
         qREa['process_special','El from y and m','35012',t] =E= qY_CET['electricity','35012',t];

    E_qRE_DataCentre[t]$(tx0[t] and d1pREa['process_special','Electricity','71000',t] and eNotInEnergyNest['process_special','Electricity','71000',t]).. 
        qREa['process_special','Electricity','71000',t] =E= uRE['process_special','Electricity','71000',t] * qREa.l['process_special','Electricity','71000',t];

    E_qRE_CrudeOilToRefineries[t]$(tx0[t] and d1pREa['process_special','crude oil','19000',t] and eNotInEnergyNest['process_special','crude oil','19000',t]).. 
        qREa['process_special','crude oil','19000',t] =E= uRE['process_special','crude oil','19000',t] * qKELBM['19000',t];


    $ENDBLOCK 

    $BLOCK B_production_private_ces

   	# ------------------------------------------------------------------------------------------------------------------
    # Private production nesting tree
    # ------------------------------------------------------------------------------------------------------------------
 	# Private production is given by a nested CES function; the firm's behavior can be modeled by a demand system for each nest.
       
        # Top nest: CES-aggregate between KLB-aggregate and materials is determined through aggregate output
           E_qProd_map_KELBM[prd,sp,t]$(tx0[t] and d1Prod[prd,sp,t] and prdTop[prd]).. 
              qProd['KELBM',sp,t] =E= qKELBM[sp,t];

        # Budget constraint for production nests: Determines the hypothetical price of each production nest
            E_pProd_map[prdNest,sp,t]$(tx0[t] and d1Prod[prdNest,sp,t]).. 
               pProd[prdNest,sp,t] * qProd[prdNest,sp,t] =E= sum(prd$(d1Prod[prd,sp,t] and prdNest2Prd[prdNest,prd] and not prdBotUlt[prd]), pProd[prd,sp,t] * qProd[prd,sp,t])
               +  sum(prd$(d1Prod[prd,sp,t] and prdNest2Prd(prdNest,prd) and prdBotUlt[prd]),  pProd[prd,sp,t] * qProd[prd,sp,t-1]/fq);

        # First-order conditions: Within each production nest, input demand is derived in accordance with the hierarchical nesting structure   
           E_qProd_map_notUlt[prd,sp,prdNest,t]$(tx0[t] and d1Prod[prd,sp,t] and prdNest2Prd[prdNest,prd] and not prdTop(prd) and not (prdBotUlt(prd) or prdFin(prd))).. 
              TFP[prdNest,sp,t] * thetaProd[prd,sp,t] * qProd[prd,sp,t] =E= uProd[prd,sp,t]  * (pProd[prd,sp,t]/thetaProd[prd,sp,t] / pProd[prdNest,sp,t])**(-eProd(prdNest,sp)) * qProd[prdNest,sp,t]; 
        
        	# CES-functions are Leontief for capital and financial services    
            E_qProd_map_Ult[prd,sp,prdNest,t]$(tx0[t] and d1Prod[prd,sp,t-1] and prdNest2Prd[prdNest,prd] and prdBotUlt(prd)).. 
              qProd[prd,sp,t-1]/fq =E= uProd[prd,sp,t] * qProd[prdNest,sp,t]; # Capital demand is recorded at the end of the period.

            E_qProd_map_Fin[prd,sp,prdNest,t]$(tx0[t] and d1Prod[prd,sp,t] and prdNest2Prd[prdNest,prd] and prdFin(prd)).. 
              qProd[prd,sp,t] =E= uProd[prd,sp,t]* qProd[prdNest,sp,t]; 

        # Prices at the lowest level of the production nesting structure are determined exogenously, outside the scope of the nested CES function.
            #  #Capital
            #  E_pK_map[prd,k,sp,t]$(tx0E[t] and d1Prod[prd,sp,t+1] and mapprd2k(prd,k))..  
            #      pProd[prd,sp,t+1] =E= pK_scaled[k,sp,t+1] + jpProd[prd,sp,t+1];

    E_pK_scaled[prd,k,sp,t]$(tx0[t] and d1Prod[prd,sp,t] and mapprd2k(prd,k))..
      pProd[prd,sp,t] =E= pK[k,sp,t]/pK[k,sp,tDataEnd];   

            #Labour
            E_pL_map[sp,t]$(tx0[t] and d1Prod['L',sp,t]).. 
                pProd['L',sp,t] =E=pL[sp,t]; 

            #RxE
            E_pRxE_map[sp,t]$(tx0[t] and d1Prod['RxE',sp,t])..           
                pProd['RxE',sp,t] =E= pRxE[sp,t];

            #Financial services
            E_pFin_map[prd,k,sp,t]$(tx0[t] and d1Prod[prd,sp,t] and mapprd2fin(prd,k))..
                pProd[prd,sp,t] =E= pFin_k[k,sp,t];

            #Energy
            E_pEtrans[sp,t]$(tx0[t] and d1Prod['Etrans',sp,t])..
                pProd['Etrans',sp,t] * qProd['Etrans',sp,t] =E= sum(purpose$(d1EP[purpose,sp,t] and (sameas[purpose,'Transport'] or sameas[Purpose,'Intern_trans'])), pEP[purpose,sp,t]*qEP[purpose,sp,t]);

            E_pE_CGE[sp,t]$(tx0[t] and d1Prod['Eother',sp,t]).. 
                pProd['Eother',sp,t] * qProd['Eother',sp,t] =E= sum(purpose$(d1EP[purpose,sp,t] and not (sameas[purpose,"transport"] or sameas[purpose,'intern_trans'])), pEP[purpose,sp,t] * qEP[purpose,sp,t]); 

        # Link from nesting variables to production inputs
            E_qFin_k_map[prd,k,sp,t]$(tx0[t] and d1Prod[prd,sp,t] and mapprd2fin(prd,k))..
                qFin_k[k,sp,t] =E= qProd[prd,sp,t];

            E_qRxE_map[sp,t]$(tx0[t] and d1prod['RxE',sp,t])..
                qRxE[sp,t] =E= qProd['RxE',sp,t];


    $ENDBLOCK 

    $BLOCK B_production_private_energy
    # ------------------------------------------------------------------------------------------------------------------
    # Demand for energy
    # ------------------------------------------------------------------------------------------------------------------

    #Transport
    E_qEP_trans[purpose,sp,t]$(tx0[t] and d1EP[purpose,sp,t] and (sameas[purpose,'Transport'] or sameas[purpose,'intern_trans']))..
         qEP[purpose,sp,t] =E= uEP[purpose,sp,t] * qProd['Etrans',sp,t];

    E_pEP_trans[purpose,sp,t]$(tx0[t] and d1EP[purpose,sp,t] and (sameas[purpose,'Transport'] or sameas[purpose,'intern_trans'])).. 
      pEP[purpose,sp,t] * qEP[purpose,sp,t] =E= sum(energy19$(d1pREa[purpose,energy19,sp,t] and not eNotInEnergyNest[purpose,energy19,sp,t]), 
                                                                                              pREa[purpose, energy19,sp,t] * qREa[purpose,energy19,sp,t]); 

     E_qRE_trans[purpose,energy19a,sp,t]$(tx0[t] and (sameas[purpose,'Transport'] or sameas[purpose,'intern_trans']) and d1pREa[purpose,energy19a,sp,t] and not eNotInEnergyNest[purpose,energy19a,sp,t]).. 
      qREa[purpose,energy19a,sp,t] =E= uRE[purpose,energy19a,sp,t] * (pREa[purpose,energy19a,sp,t] / pEP[purpose,sp,t])**(-eRE[purpose,sp])*qEP[purpose,sp,t];

    #Non transport
    E_qEP[purpose,sp,t]$(tx0[t] and d1EP[purpose,sp,t] and not (sameas[purpose,"transport"] or sameas[purpose,'intern_trans']))..   
      qEP[purpose,sp,t] =E= uEP[purpose,sp,t] * (pEP[purpose,sp,t]/pProd['Eother',sp,t]) **(-eREP[sp]) * qProd['Eother',sp,t];

    E_pEP[purpose,sp,t]$(tx0[t] and d1EP[purpose,sp,t] and not (sameas[purpose,"transport"] or sameas[purpose,'intern_trans']) ).. 
      pEP[purpose,sp,t]*qEP[purpose,sp,t] =E= sum(energy19$(d1pREa[purpose,energy19,sp,t] and not eNotInEnergyNest[purpose,energy19,sp,t]), pREa[purpose,energy19,sp,t] * qREa[purpose,energy19,sp,t]);

    E_qREa[purpose,energy19a,sp,t]$(tx0[t] and d1pREa[purpose,energy19a,sp,t] and not eNotInEnergyNest[purpose,energy19a,sp,t] and not (sameas[purpose,"transport"] or sameas[purpose,'intern_trans'])).. 
      qREa[purpose,energy19a,sp,t] =E= uRE[purpose,energy19a,sp,t] * (pREa[purpose,energy19a,sp,t]/pEP[purpose,sp,t]) **(-eRE[purpose,sp]) * qEP[purpose,sp,t];


    E_pREa[purpose,energy19a,sp,t]$(tx0[t] and d1pREa[purpose,energy19a,sp,t]).. 
      pREa[purpose,energy19a,sp,t] =E= pREgj[purpose,energy19a,sp,t]$(d1pREgj[purpose,energy19a,sp,t]) 
                                    + j_pREa[purpose,energy19a,sp,t]$(sum(techID, d1thetaID_k[techID,purpose,energy19a,sp,t]) or sum((techCCS,emm), d1thetaCCS[techCCS,purpose,energy19a,sp,t,emm]) or sum(energy19,d1vREE_transport[purpose,energy19a,energy19,sp,t]));
    $ENDBLOCK

    $BLOCK B_production_private_uc

    # ------------------------------------------------------------------------------------------------------------------
    # Cost of capital
    # ------------------------------------------------------------------------------------------------------------------

    # Definition of user cost
    E_pK[k,sp,t]$(tx0E[t] and d1K[k,sp,t])..  
        pK[k,sp,t+1]*fp * (1-tCorp[t+1]) =E=
      # Tobin's q today and tomorrow
        pTobinsQ[k,sp,t] * (1+rFirms[sp,t+1]) - (1 - rDepr[k,sp,t+1]) * pTobinsQ[k,sp,t+1]*fp
      # Production tax on capital
      + (1-tCorp[t+1]) * tK[k,sp,t+1] * pI_s[k,sp,t+1]*fp
      # Tax shield on collateral value on capital
      #  - (rFirms[sp,t+1] - rBonds[t+1] * (1-tCorp[t+1])) * sDebt2k[k,sp,t] * pI_s[k,sp,t]
      - ((rFirms[sp,t+1] - rBonds[sp,'2025'] * (1-tCorp[t+1])) * sDebt2k[k,sp,t] * pI_s[k,sp,t])$(t.val<2025)
      - ((rFirms[sp,t+1] - rBonds[sp,t+1] * (1-tCorp[t+1])) * sDebt2k[k,sp,t] * pI_s[k,sp,t])$(t.val>=2025)
      
      # Discounted value of change in future installation costs from change in investments today
      #  + (1-tCorp[t+1]) * pY[sp,t+1] * fp * dKinstCost2dK[k,sp,t]
      + (1-tCorp[t+1]) * pKELBM[sp,t+1] * fp * dKinstCost2dK[k,sp,t]
      #Added term to correct for difference between forward looking   
      + jpK[k,sp,t+1];


     #TobinsQ kopieret (og tilpasset) fra MAKRO
      E_pTobinsQ[k,sp,t]$(tx0E[t] and d1K[k,sp,t]).. 
        pTobinsQ[k,sp,t] =E= pI_s[k,sp,t] - pI_s[k,sp,t]*EKtax[k,sp,t]
                        #  + pY[sp,t] * (1-tCorp[t]) * dKInstCost2dI[k,sp,t]
                        #  + 1/(1+rFirms[sp,t+1]) * pY[sp,t+1] * fp * (1-tCorp[t+1]) * dKInstCostLead2dI[k,sp,t] * qK[k,sp,t];
                        + pKELBM[sp,t] * (1-tCorp[t]) * dKInstCost2dI[k,sp,t]
                        + 1/(1+rFirms[sp,t+1]) * pKELBM[sp,t+1] * fp * (1-tCorp[t+1]) * dKInstCostLead2dI[k,sp,t] * qK[k,sp,t];


      #TobinsQ terminalbetingelse. Kopieret (og tilpasset) fra MAKRO
      E_pTobinsQ_tEnd[k,sp,t]$(tEnd[t] and d1K[k,sp,t])..        
         pTobinsQ[k,sp,t] =E= pI_s[k,sp,t] - pI_s[k,sp,t]*EKtax[k,sp,t]
                             + pKELBM[sp,t] * (1-tCorp[t]) * dKInstCost2dI[k,sp,t]; 
                             #  + pY[sp,t] * (1-tCorp[t]) * dKInstCost2dI[k,sp,t]; 
  #  

  # First order condition with respect to tax deductible capital ('Shadows price')
    E_EKtax[k,sp,t]$(tx0E[t] and d1K[k,sp,t])..
      EKtax[k,sp,t] =E= ((1-rTaxDep[k,t+1]) * EKtax[k,sp,t+1] + tCorp[t+1] * rTaxDep[k,t+1]) / (1+rFirms[sp,t+1]);

    E_EKtax_tEnd[k,sp,t]$(tEnd[t] and d1K[k,sp,t])..
      EKtax[k,sp,t] =E= tCorp[t] * rTaxDep[k,t] / (rFirms[sp,t] + rTaxDep[k,t]);


    # ------------------------------------------------------------------------------------------------------------------
    # Installation costs
    # ------------------------------------------------------------------------------------------------------------------
    
    # Aggregate lost production from installation costs
    E_qKInstCost_kTot[sp,t]$(tx0[t] and d1K['iTot',sp,t]).. qKInstCost['iTot',sp,t] =E= sum(k$d1K[k,sp,t], qKInstCost[k,sp,t]);


    E_qKInstCost[k,sp,t]$(tx0[t] and d1K[k,sp,t])..        
      qKInstCost[k,sp,t] =E= uKInstCost[k,sp,t]/2 * sqr(qI_s[k,sp,t] - qI_s[k,sp,t-1]/fq * fKInstCost[k,sp,t]) /(qK[k,sp,t-1]/fq); 

    E_dqKInstCost2dqK[k,sp,t]$(tx0[t] and d1K[k,sp,t])..
      dKInstCost2dK[k,sp,t] =E= - uKInstCost[k,sp,t]/2 * sqr((qI_s[k,sp,t+1]*fq - qI_s[k,sp,t] * fKInstCost[k,sp,t+1]) / qK[k,sp,t]);

    E_dqKInstCost2dqI_s[k,sp,t]$(tx0[t] and d1K[k,sp,t])..
      dKInstCost2dI[k,sp,t] =E= uKInstCost[k,sp,t] * (qI_s[k,sp,t] - qI_s[k,sp,t-1]/fq * fKInstCost[k,sp,t]) / (qK[k,sp,t-1]/fq);

    E_dqKInstCostLead2dqI_s[k,sp,t]$(tx0E[t] and d1K[k,sp,t])..
      dKInstCostLead2dI[k,sp,t] =E= - fKInstCost[k,sp,t+1] / qK[k,sp,t] * dKInstCost2dI[k,sp,t+1];

    #  #Scaling
    #  E_pK_scaled[k,sp,t]$(tx0[t] and d1k[k,sp,t])..
    #    pK_scaled[k,sp,t] =E= pK[k,sp,t]/pK[k,sp,tDataEnd];

    #  E_qK_scaled[prd,k,sp,t]$(tx0[t] and d1Prod[prd,sp,t] and mapprd2k(prd,k))..
    #    qProd[prd,sp,t-1] =E= qK[k,sp,t-1]*pK[k,sp,tDataEnd];
    
    #  E_qK_scaled_tEnd[prd,sp,t]$(tEnd[t] and d1Prod[prd,sp,t] and prdBotUlt(prd))..
    #    qProd[prd,sp,t] =E= qProd[prd,sp,t-1]; #Steady-state characterized by growth-corrected investment quantity being 'flat'

    $ENDBLOCK

    $BLOCK B_production_private_inv 
		#  #Quantities the other way
	 #     E_qK_map[prd,k,sp,t]$(tx0[t] and d1Prod[prd,sp,t] and mapprd2k(prd,k))..
	 #      qK[k,sp,t] =E= qProd[prd,sp,t];

    E_qK_scaled[prd,k,sp,t]$(tx0[t] and d1Prod[prd,sp,t] and mapprd2k(prd,k))..
      qProd[prd,sp,t-1] =E= qK[k,sp,t-1]*pK[k,sp,tDataEnd];
    
    E_qK_scaled_tEnd[prd,sp,t]$(tEnd[t] and d1Prod[prd,sp,t] and prdBotUlt(prd))..
      qProd[prd,sp,t] =E= qProd[prd,sp,t-1]; #Steady-state characterized by growth-corrected investment quantity being 'flat'

	  	# Capital accumulation
	    E_qI_s[k,sp,t]$(tx0[t] and d1K[k,sp,t]).. qI_s[k,sp,t] =E= qK[k,sp,t] - (1 - rDepr[k,sp,t]) * qK[k,sp,t-1]/fq + jqI_s[k,sp,t];

	 	#Terminal condition 
	    E_qI_s_END[k,sp,t]$(tEnd[t] and d1K[k,sp,t]).. qI_s[k,sp,t] =E= qI_s[k,sp,t-1]; #Steady-state characterized by growth-corrected investment quantity being 'flat'

	  # Inventory investments
	    # Inventories are forecast as fixed shares of production - corrected with lagged prices to balance future aggregated chain index
	    E_qI_s_inv[sp,t]$(tx0[t] and d1I_s['invt',sp,t])..      
	      qI_s['invt',sp,t] * pI_s['invt',sp,t-1] =E= rIL[sp,t] * pY[sp,t-1] * qY[sp,t];
    $ENDBLOCK

    # ------------------------------------------------------------------------------------------------------------------
    # From finance
    # ------------------------------------------------------------------------------------------------------------------

    $BLOCK B_production_private_finance

    # Tax book value of firm shares
    E_vKtax_Im[sp,t]$(tx0[t]).. vKtax['Im',sp,t] =E= (1-rTaxDep['Im',t]) * vKtax['Im',sp,t-1]/fv + ((@pos(vI_s['Im',sp,t])+vI_s['Im',sp,t])/2)$(d1I_s['Im',sp,t]);
    E_vKtax_Ib[sp,t]$(tx0[t]).. vKtax['Ib',sp,t] =E= (1-rTaxDep['Ib',t]) * vKtax['Ib',sp,t-1]/fv + ((@pos(vI_s['Ib',sp,t])+vI_s['Ib',sp,t])/2)$(d1I_s['Ib',sp,t]);
    E_vKtax_It[sp,t]$(tx0[t]).. vKtax['It',sp,t] =E= (1-rTaxDep['It',t]) * vKtax['It',sp,t-1]/fv + ((@pos(vI_s['It',sp,t])+vI_s['It',sp,t])/2)$(d1I_s['It',sp,t]);

    E_vFirmDebt[sp,t]$(tx0[t])..  vFirmDebt[sp,t] =E=  sum(k$d1I_s[k,sp,t], sDebt2K[k,sp,t]*pI_s[k,sp,t]*qK[k,sp,t]) + vFirmDebtFromOtherModules[sp,t];

    # Value of energyinput (excl. own-consumption) - consider moving to IO?

    E_vREa[purpose,energy19,sp,t]$(tx0[t] and d1pREa[purpose,energy19,sp,t]).. vREa[purpose,energy19,sp,t] =E= pREa[purpose,energy19,sp,t] * qREa[purpose,energy19,sp,t]  
                                                                                                          -(pREgj[purpose,energy19,sp,t] * qREgj[purpose,energy19,sp,t])$(d1pREown[purpose,energy19,sp,t]) #In the event that own-consumption is taxed it will enter GVA, we therefore substract and add only tax-component. 
                                                                                                          +(tvREmarg[purpose,energy19,sp,t] * pREown[purpose,energy19,sp,t] * qREgj[purpose,energy19,sp,t] )$(d1pREown[purpose,energy19,sp,t] and d1tRE[purpose,energy19,sp,t]);

    E_vGrossValAdd[sp,t]$(tx0[t]).. vGrossValAdd[sp,t] =E= vY[sp,t] - vRxE[sp,t] #Non-energy materials
                                                                 - vFin[sp,t] #Financial services
                                                                 - sum(emm$(d1EmmProdxE[sp,t,emm] and d1CO2_ProdxE[sp,t,emm]),  vtCO2_ProdxE[sp,t,emm]) # CO2e-tax on non-energy related emissions
                                                                 # The aggregated value of the energy commodity including capital costs for abatement and CCS
                                                                 - sum((purpose,energy19a), vREa[purpose,energy19a,sp,t]$(d1pREa[purpose,energy19a,sp,t]) 
                                                                 # Adjustment of taxes to reflect the average tax rate (gennemsnitsafgiftssatsen) (vRE reflects the marginal tax rate)
                                                                    + (+vtEAFG_RE[purpose,energy19a,sp,t]$(d1EAFG_RE[purpose,energy19a,sp,t]) 
                                                                       -vtEAFG_REmarg[purpose,energy19a,sp,t]$(d1EAFG_RE[purpose,energy19a,sp,t])
                                                                       +vtCO2_RE[purpose,energy19a,sp,t]$(d1CO2_RE[purpose,energy19a,sp,t])
                                                                       -vtCO2_REmarg[purpose,energy19a,sp,t]$(d1CO2_RE[purpose,energy19a,sp,t])
                                                                       -vtCO2_ETS_marg[energy19a,sp,t]$(d1tCO2_ETS_marg[purpose,energy19a,sp,t])
                                                                       -vtCO2_ETS2_marg[purpose,energy19a,sp,t]$(d1CO2_ETS2_marg[purpose,energy19a,sp,t])
                                                                       +vtVAT_RE[purpose,energy19a,sp,t]$(d1VAT_RE[purpose,energy19a,sp,t])) 
                                                                       #We only deduct marginal ETS payments, as ETS is not part of GVA in the National Accounts definition
                                                                    # Deduct capital costs for ID abatement and energy-related CCS (because they are included in vRE)
                                                                    - sum(techID$(d1thetaID_k[techID,purpose,energy19a,sp,t]), rID_actual[techID,purpose,energy19a,sp,t] * thetaID_KMean[techID,purpose,energy19a,sp,t]*sum(energy19$(d1thetaID[techID,purpose,energy19a,energy19,sp,t] and sameas(energy19,energy19a)),-thetaID[techID,purpose,energy19a,energy19,sp,t]) * pI_s['iM',sp,t])
                                                                    - pCCS_qRE[sp,energy19a,purpose,t]*qREa[purpose,energy19a,sp,t]$(d1pREa[purpose,energy19a,sp,t] and sum((techCCS,emm), d1thetaCCS[techCCS,purpose,energy19a,sp,t,emm]))                 
                                                                         )
                                                               #When deducting vREa (above) we subtract marginal prices. Here we add the marginal prices back, and subtract the average prices.
                                                                 + sum((purpose,energy19a)$(d1pRE_base[purpose,energy19a,sp,t]),(pRE_base_marg[purpose,energy19a,sp,t]-pRE_base[purpose,energy19a,sp,t])*qREgj[purpose,energy19a,sp,t])
                                                                 # Ørsted join-venture in the Netherlands. Ended in 2019
                                                                 - (pRE_NatGasNL[t]*qRE_NatGasNL[t])$(sameas[sp,'35011'] and t.val <= 2019)
                                                                 # Technology costs (Tekologiomkostninger)
                                                                 - sum((ani_sectors,ss)$(map_anisectors2s(Ani_sectors,sp) and sum((Emmtype,animals),d1vEOPCostAni[Emmtype,ani_sectors,sp,animals,t])), vRxEEOP_ani[ani_sectors,sp,t])
                                                                 - sum((plant_sectors,ss)$(map_plantsectors2s(plant_sectors,sp) and sum(Emmtype,d1vEOPCostplant[Emmtype,plant_sectors,sp,t])), vRxEEOP_plant[plant_sectors,sp,t])
                                                                 + sum((purpose,energy19)$(d1tRE[purpose,energy19,sp,t]), tCALIBENS[purpose,energy19,sp,t]*qREgj[purpose,energy19,sp,t]) #LBS: Her er jeg i tvivl
                                                                 - (sum((energy19,purpose)$(d1vLE[purpose,energy19,t] and not tDataEnd[t]), vLE[purpose,energy19,t])* vY[sp,t] /sum(TheBig7, vY[TheBig7,t]))$(TheBig7[sp])
                                                                 - (vBiomass_Pyrolyse[t])$(sum(PyrolyseTech, d1PyrolysePot[PyrolyseTech,t])) # pyrolyse
                                                                ;


    E_vGrossValAdd_tot[t]$(tx0[t]).. vGrossValAdd['tot',t] =E= sum(s, vGrossValAdd[s,t]);

    # Earnings before interests, corporate taxes, and depreciation. Payroll taxes are included in both vtNetYAfg and vL, and are added back.
    # Earnings before interests, corporate taxes, and depreciation. Payroll taxes are included in both vtNetYAfg and vL, and are added back.
    E_vEBITDA[sp,t]$(tx0[t]).. 
        vEBITDA[sp,t] =E= 
                      vY[sp,t] 
                    - vRxE[sp,t] 
                    - vFin[sp,t]
                    - sum((purpose,energy19)$(d1pREa[purpose,energy19,sp,t]), vREa[purpose,energy19,sp,t])  #vREa contains full ETS-payments on energy
                    - sum((purpose,energy19)$(d1VAT_RE[purpose,energy19,sp,t]), vtVAT_RE[purpose,energy19,sp,t]) #VAT, which is no longer in vREa
                    - w[t] * qL[sp,t] 
                    - vtBotDed[sp,t]
                    + sum((purpose,energy19)$(d1tRE[purpose,energy19,sp,t]), tCALIBENS[purpose,energy19,sp,t]*qREgj[purpose,energy19,sp,t]) #LBS: Her er jeg i tvivl
                    - vtCO2_ETSxE_marg[sp,t]$(d1EmmProdxE[sp,t,'CO2e'] and d1CO2_ETS[sp,t])
                    - pRE_NatGasNL[t]*qRE_NatGasNL[t]$(sameas[sp,'35011'] and t.val <= 2019)
                    - sum(emm$(d1EmmProdxE[sp,t,emm] and d1CO2_ProdxE[sp,t,emm]),  vtCO2_ProdxE[sp,t,emm]) # CO2e-tax on non-energy related emissions
                    # Correction for actual capital investments and not levelized
                    + sum((purpose,energy19a,emm)$(sum(energy19, d1qREE[purpose,energy19a,energy19,sp,t] and sum(techCCS, d1thetaCCS[techCCS,purpose,energy19,sp,t,emm])) and (sameas[emm,'CO2ubio'] or sameas[emm,'CO2bio'])), 
                                              qLEVC_CCS_EmmE_RE[purpose,energy19a,sp,t,emm]*pI_s['iM',sp,t]) # Levelized investments on energy CCS should be added, as it enters in vREa above
                    - qI_CCS_actual['iM',sp,t]*pI_s['iM',sp,t]$(sum((techCCS,purpose,energy19,tt,emm), d1thetaCCS[techCCS,purpose,energy19,sp,tt,emm]) or sum((techCCS,tt,emm), d1thetaCCSxE[techCCS,sp,tt,emm])) # Actual investments on both energy and non-energy CCS
                    - sum(emm$(d1EmmProdxE[sp,t,emm] and sum(techCCS, d1thetaCCSxE[techCCS,sp,t,emm]) and sameas[emm,'CO2ubio']), - vSubsidy_CCS_EmmxE[sp,t,emm])   # Subsidy for non-energy related CCS does not enter above         
                    # When deducting vREa (above) we subtract marginal prices. Here we add the marginal prices back, and subtract the average prices.
                    + sum((purpose,energy19)$(d1pRE_base[purpose,energy19,sp,t]),(pRE_base_marg[purpose,energy19,sp,t]-pRE_base[purpose,energy19,sp,t])*qREgj[purpose,energy19,sp,t])
                    # Production taxed and subsidies                                                                      
                    - (  vtLand[sp,t]
                       + vtLPayRoll[sp,t]
                       + vtFirmsWeight[sp,t]
                       + vtLAM[sp,t] 
                       + vtNetProductionRest[sp,t]
                       + vtCAP[sp,t]$(agri_sectors[sp]) #The CAP is measured with negative sign and thus contributes positively to the result
                       - vtLSubsidy[sp,t]
                       + (vGovReceiveFirms[t]-vGov2Firms[t])*qY[sp,t]/sum(ssp,qY[ssp,t])
                       + vGovRent[t]$(sameas[sp,'0600a']) 
                       - vtCO2_LULUCF[t]$(sameas[sp,'02000']) #We assume (at least starting out) that the forrest is planted on conventional land. 
                        # Instead, it is uncluded as fully CAP-funded - i.e., it falls under the vtCAP
                       - vKompOmk[t]$(sameas[sp,'01011']) #Compensation for lowland withdrawal (Kompensation for udtagning af lavbund). 
                       + (vtCO2_organicinproduction[t] + vtCO2_organic_outofproduction[t])$(sameas[sp,'01011'])
                       - vtPerHectareBottomDeduction[sp,t]$(plant_sectors_sp[sp])
                       )
                    + vSubProductionRest[t]*vY[sp,t]/sum(ssp, vY[ssp,t])
                    + sum(plant_sectors$map_plantsectors2s(plant_sectors,sp), tAfforestationPerHa[plant_sectors,t] * (qLand_Nonproductive['skov',plant_sectors,t]-qLand_Nonproductive['skov',plant_sectors,t-1]))
                    # Technology costs, including taxes
                    - sum((ani_sectors,emmtype,animals)$(map_anisectors2s(Ani_sectors,sp) and d1EmmAgrAni[emmtype,ani_sectors,Animals,t,'CO2e']), vCO2_ani[EmmType,Ani_sectors,Animals,t])
                    - sum((plant_sectors,plant_)$(map_plantsectors2s(Plant_sectors,sp) and sum(emmtype$(emmtype2plant_[emmtype,plant_] and reguleringsgrundlag[emmtype]), d1EmmAgrxE[emmtype,plant_sectors,t,'CO2e'])), vCO2_plant[Plant_sectors,plant_,t])
                    + sum((Techani,Ani_sectors,emmtype,animals)$(map_anisectors2s(Ani_sectors,sp) and sum(emm,d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm])), vTech_subsidy_ani[techani,EmmType,Ani_sectors,Animals,t])
                    + sum((Techplant,plant_sectors,emmtype)$(map_plantsectors2s(Plant_sectors,sp) and sum(emm,d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm])), vTech_subsidy_plant[Techplant,EmmType,plant_sectors,t])
                    - sum((ani_sectors,s)$(map_anisectors2s(Ani_sectors,s) and sum((Emmtype,animals),d1vEOPCostAni[Emmtype,ani_sectors,s,animals,t])), vRxEEOP_ani[ani_sectors,s,t])
                    - sum((plant_sectors,s)$(map_plantsectors2s(plant_sectors,s) and sum(Emmtype,d1vEOPCostplant[Emmtype,plant_sectors,s,t])), vRxEEOP_plant[plant_sectors,s,t])
                    - sum(ani_sectors$(map_anisectors2s(ani_sectors,sp)), sum((TechAni,Emmtype,Animals)$(sum(emm,d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm])), vI_EOPCostAni['iM',TechAni,Emmtype,ani_sectors,animals,t]))
                    - sum(plant_sectors$(map_plantsectors2s(plant_sectors,sp)), sum((TechPlant,Emmtype)$(sum(emm,d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm])), vI_EOPCostplant['iM',Techplant,Emmtype,plant_sectors,t]))
                   + vBotdedPerAnimal[sp,t]$(ani_sectors_sp[sp]) 
                    # Distributor's "Profit"
                    + sum(energy19, vDistributionProfits_e19[energy19,sp,t]$d1vY_CET[energy19,sp,t])
                    + vOtherDistributionProfits_EAV[t]$(sameas[sp,'46000'])
                    + vOtherDistributionProfits_DAV[t]$(sameas[sp,'47000'])
                    + vOtherDistributionProfits_CAV[t]$(sameas[sp,'45000'])
                    - (sum((energy19,purpose)$(d1vLE[purpose,energy19,t] and not tDataEnd[t]), vLE[purpose,energy19,t])* vY[sp,t] /sum(TheBig7, vY[TheBig7,t]))$(TheBig7[sp])
                    # Pyrolyse
                    + vSubsidy_Pyrolyse[t]$(sameas[sp,'01011'] and sum(PyrolyseTech, d1PyrolysePot[PyrolyseTech,t]))
                    - (vBiomass_Pyrolyse[t])$(sameas[sp,'01011'] and sum(PyrolyseTech, d1PyrolysePot[PyrolyseTech,t]))
                    - (sum(PyrolyseTech$(sum(tt, d1PyrolysePot[PyrolyseTech,tt])), qI_Pyrolyse_actual[PyrolyseTech,t])*pI_s['iM','01011',t])$(sameas[sp,'01011'])
                    ;

   
    E_vEBITDA_tot[t]$(tx0[t]).. vEBITDA['tot',t] =E= sum(sp, vEBITDA[sp,t]);

    # Earnings before taxes
    E_vEBT[sp,t]$(tx0[t]).. vEBT[sp,t] =E= vEBITDA[sp,t] - rBonds[sp,t] * vFirmDebt[sp,t-1]/fv - sum(k$d1K[k,sp,t-1], rTaxDep[k,t] * vKtax[k,sp,t-1]/fv);

    E_vtCorpMain[sp,t]$tx0[t]..  vtCorpMain[sp,t]  =E= (tCorp[t]+tCorpRes[t]) * vEBT[sp,t];  #* ((@cdfNorm(vEBT[sp,t],0,0.001))$(not agri_sectors[sp]) + 1$(agri_sectors[sp])); #Der betales kun selskabsskat af positive resultater. For landbruget kan der godt være negativ EBT i en enkelt produktionsgren. Det betyder at selskabsskatten bliver negativ (en overførsel fra staten). Det er ofte ok, da det er planteavlerne, der får negativt resultat som følge af at en stor del af deres output sælges ikke-markedsmæssigt.  

    # Free cash flow to equity
    E_vFCFE[sp,t]$(tx0[t]).. 
     vFCFE[sp,t] =E= vEBITDA[sp,t]        
                #Deduct investment costs
                 - sum(k$d1I_s[k,sp,t], vI_s[k,sp,t]) 
                 - (pY_CET['out_other','02000',t]*qI_s_afforestation[t])$(sameas[sp,'02000'])
                 - (pY_CET['out_other','02000',t]*qI_s_afforestation_inst[t])$(sameas[sp,'02000'])
                 # Deduct company taxes (selskabsskatter)  
                 - vtCorpMain[sp,t]    
                 #Deduct correction terms for corporate taxes
                 - jvtCorp[t]*(vEBT[sp,t]/sum(dsp$(not agri_sectors[dsp]), vEBT[dsp,t]))$(not agri_sectors[sp]) #Corporate tax residual. J-term is calibrated to ensure we hit corporate tax-revenues from external forecast               
                 # Deduct interest payments on debt and changes in debt
                 - (rBonds[sp,t] * vFirmDebt[sp,t-1]/fv - vFirmDebt[sp,t] + vFirmDebt[sp,t-1]/fv)
                 ;

    E_vDistributionProfits_share[energy19,sp,t]$(tx0[t] and d1vY_CET[energy19,sp,t]).. vDistributionProfits_e19[energy19,sp,t] =E= vDistributionProfits[energy19,t] * qY_CET[energy19,sp,t]/sum(dsp, qY_CET[energy19,dsp,t]);

     # Rate of return on domestic shares (dividends + capital gains)

    #  E_vEquity[sp,t]$(tx0[t]).. rFirms[sp,t] * vEquity[sp,t-1]/fv =E= vFCFE[sp,t] + vEquity[sp,t] - vEquity[sp,t-1]/fv;
    
    E_vEquity[sp,t]$(txE[t]).. rInvestor[sp,t] * vEquity[sp,t]/fv =E= vFCFE[sp,t+1] + vEquity[sp,t+1] - vEquity[sp,t]/fv;

    E_vEquity_terminal[sp,t]$(tend[t])..       vEquity[sp,t-1] =E= vEquity[sp,t];

    $ENDBLOCK

   # ------------------------------------------------------------------------------------------------------------------
   # Clearing of labor market
   # ------------------------------------------------------------------------------------------------------------------

    $BLOCK B_production_private_labor_market

    E_qL_map[sp,t]$(tx0[t] and d1Prod['L',sp,t])..
	    qL[sp,t] =E= qProd['l',sp,t];

    E_pL[sp,t]$tx0[t]..        pL[sp,t]                            =E= (1+tL[sp,t])*w[t];

    E_nL[s,t]$(tx0[t])..  qL[s,t] =E= prod_a[t] * Hours[t] * fW[s,t] * nEmployed_s[s,t]; # * prod_s[s,t]; 

    E_nL_tot[t]$(tx0[t]).. sum(s,nEmployed_s[s,t]) =E= nEmployed[t];

    E_fW[s,t]$(tx0[t]).. fW[s,t] =E= fW0[s,t] * sum(ss, nEmployed_s[ss,t])/sum(ss, fW0[ss,t]*nEmployed_s[ss,t]);

	$ENDBLOCK

     $BLOCK B_report_production

     E_N_L[sp,t] $(tendo[t])..
          N_L[sp,t] =E= Z[t]*thetaProd['L',sp,t]*qL[sp,t];

     E_N_L_off[t] $(tendo[t])..
          N_L['off',t] =E= Z[t]*qL['off',t];


        #Brancheproduktivitet
            E_prod_branche[s,t] $(tendo[t])..    
                prod_branche[s,t] =E= (pY[s,t]*qY[s,t] - pRxE[s,t]*qRxE[s,t] - pE_CGE[s,t]*qE[s,t]) / (pGDP[t]*N_L[s,t]);
                    
        #Korrektion mellem BNP og rå produktionsværditilvækst
            E_korr[t] $(tendo[t]).. 
                korr[t] =E= vGDP[t] / sum(s,pY[s,t]*qY[s,t] - pRxE[s,t]*qRxE[s,t] - pE_CGE[s,t]*qE[s,t]);
    
        $ENDBLOCK


	$MODEL M_production_private 
		B_production_private_cet
		B_production_private_ces
		B_production_private_energy
		B_production_private_uc
		B_production_private_inv
        B_production_private_finance
		B_production_private_labor_market
	;

$ENDIF


$IF %stage% == "exogenous_values":
# ======================================================================================================================
# Exogenous variables and data assignment
# ======================================================================================================================

#1) READ DATA 

	#From IO 
    pY.l[s_,t]        = IO_pY[s_,t];
    qY.l[s_,t]        = IO_qY[s_,t]; #qY0.l[s,t] = qY.l[s,t];
    vY.l[s_,t]        = IO_vY[s_,t]; 
    pY_CET.l[out,s,t] = IO_pY_CET[out,s,t]; 
    qY_CETgross.l[out,s,t] = IO_qY_CET[out,s,t];
    qY_CETgross.l[energy19,s,t] = qY_CETgross.l[energy19,s,t] + sum((purpose,r)$(d1pREown[purpose,energy19,r,t] and mapownproduction(energy19,r,s)), EN_qRE[purpose,energy19,r,t]);

    pRxE.l[r_,t]      = IO_pRxE[r_,t];
    qRxE.l[r_,t]      = IO_qRxE[r_,t];

    vRxE.l[r_,t]      = IO_vRxE[r_,t];

    pFin_k.l[k,r,t]   = IO_pFin_k[k,r,t];
    qFin_k.l[k,r,t]   = IO_qFin_k[k,r,t];

    pI_s.l[i_,s,t]    = IO_pI_s[i_,s,t];
    qI_s.l[i_,s,t]    = IO_qI_s[i_,s,t];
    vI_s.l[i_,s,t]    = IO_vI_s[i_,s,t];
    qK.l[k,s,t]       = IO_qK[k,s,t]; 

       #  execute_loaddc '..\data\IOdata\Kapital_og_investering\qK_beforeFinService.gdx' qK.l, qI_s.l, vI_s.l, jqI_s.l;

    #AKB: We comment out these corrections and load straight from a previous version, where capital has been distributed by the capital-dist model. Hence this model is commented out in static_calibration as well
    qK.l['im','01080',t]$(tData[t]) = qK.l['im','01080',t]   + 2*qK.l['im','01080',t];
    qK.l['im','01011',t]$(tData[t]) = qK.l['im','01011',t] - 1*qK.l['im','01080',t];


    set agr_core(agri_sectors)/01011,01012,01020,01031,01032,01051,01052,01061,01062,01070/; alias(agr_core,agr_core_a);


    #Extremely high mark-up in gardening
    capitaldistREGNPRO['iB','01020',t]$(tData[t]) = 0.125;
    capitaldistREGNPRO['iM','01020',t]$(tData[t]) = 0.04;
    
    capitaldistREGNPRO[k,agr_core,t]$(tData[t] and not sameas[k,'iT'])   = capitaldistREGNPRO[k,agr_core,t]/sum(agr_core_a, capitaldistREGNPRO[k,agr_core_a,t]);
    capitaldistREGNPRO['iT',agr_core,t]                                  = capitaldistREGNPRO['iM',agr_core,t];

        qK.l[k,agr_core,t]   = capitaldistREGNPRO[k,agr_core,t] * sum(agr_core_a, qK.l[k,agr_core_a,t]);
        qI_s.l[k,agr_core,t] = capitaldistREGNPRO[k,agr_core,t] * sum(agr_core_a, qI_s.l[k,agr_core_a,t]);


    #C/Y-ratio in organic-plants vs. conventional-plants is very low without this correction
    qK.l['iB','01020',t]    = qK.l['iB','01020',t] - qK.l['iB','01012',t];
    qI_s.l['iB','01020',t]  = qI_s.l['iB','01020',t] - qI_s.l['iB','01012',t];
     
    qK.l['iB','01012',t]    = 2*qK.l['iB','01012',t];
    qI_s.l['iB','01012',t]  = 2*qI_s.l['iB','01012',t];

    qK.l['ib','01070',t]$(qK.l['ib','01070',t]) = qK.l['ib','01070',t] + 5.2;
    #  qI_s.l['ib','01070',t]$(qI_s.l['ib','01070',t]) = qI_s.l['ib','01070',t] + 5;

    qK.l['ib','01011',t]$(qK.l['ib','01011',t]) = qK.l['ib','01011',t] -5.2;
    #  qI_s.l['ib','01011',t]$(qI_s.l['ib','01011',t]) = qI_s.l['ib','01011',t] -5;
 
    #Organic pig farming is just a really small industry
    qK.l['iB','01020',t]    = qK.l['iB','01020',t] - 2/3*qK.l['iB','01052',t];
    qI_s.l['iB','01020',t]  = qI_s.l['iB','01020',t] - 2/3*qI_s.l['iB','01052',t];
     
    qK.l['iB','01052',t]    = 5/3 * qK.l['iB','01052',t];
    qI_s.l['iB','01012',t]  = 5/3 * qI_s.l['iB','01052',t];

    qK.l[k,'01070',t]  = 0.6 * qK.l[k,'01070',t];


    qL.l[s,t]         = IO_qL[s,t];
    pL.l[sp,t]        = IO_pL[sp,t];
    w.l[t]            = IO_w[t];

    tK.l[k,s,t]       = IO_tK[k,s,t];

    vGrossValAdd.l[s,t] = IO_vY[s,t] - IO_vRE[s,t] - IO_vRxE[s,t]; #£ AKB: Well-known issue with IO not matching energy-statistics causing computed GrossValAdd and model GVA to differ
    vGrossValAdd.l['tot',t] = sum(s, vGrossValAdd.l[s,t]);


    nEmployed_s.l[s,t] = data_besk_out_s[s,t];
    
    #Corrects, nEmployed_s, so it  aligns with the numbers we gather from MAKRO and KP21
    nEmployed_s.l[s,t]$(sum(ss, nEmployed_s.l[ss,t])) = nEmployed_s.l[s,t]/sum(ss, nEmployed_s.l[ss,t]) * nEmployed.l[t]; 


    #Energy-use
    #Energy-activity is read in "energy_markets.gms"

    #Ørsted
    pY_ElNL.l[t]$TIL_qE_y_elNL.l[t] = (TIL_vE_y_elNL.l[t]/correction_factor_values)/(TIL_qE_y_elNL.l[t]/correction_factor_joule); pY_ElNL.l[t]$(not pY_ElNL.l[t]) = 1; #Ørsted  - initialize 1 to create chain indices
    qY_ElNl.l[t]$TIL_qE_y_elNL.l[t] = TIL_qE_y_elNL.l[t]/correction_factor_joule; #Ørsted

    pRE_NatGasNL.l[t]$ANV_qRE_NatgasNL.l[t] = (ANV_vnRE_NatgasNL.l[t]/correction_factor_values)/(ANV_qRE_NatgasNL.l[t]/correction_factor_joule); #Ørsted
    qRE_NatGasNL.l[t] = ANV_qRE_NatgasNL.l[t]/correction_factor_joule; #Ørsted


    #2) EXOGENOUS VALUES 

    eTKE.l[sp] = 0.1;  eTKE.l['51001']  = 0.1;
    eMKE.l[sp] = 0.1;  eMKE.l['51001']  = 0.1;
    eKETM.l[sp] = 0.1; eKETM.l['51001'] = 0.1; #Jet-fuel ligger i maskinnestet, men flyene ligger i maskinkapitalnestet. For at holde dem tæt til hinanden lægges det Leontief i produktionsfunktionen
    eCET.l[s]    = 5;

    # KELB_RxE
    eKELBM.L[sp] = 0.5;

    eKELBM.L[sLan_sp] = 0.00; # Maybe set to 0.1? 
    eKELBM.L[sFre_sp] = 1.30;
    eKELBM.L[FoodProcessingSectors] = 0.1; #Food is assumed to have limited abilty to switch from primary inputs
    eKELBM.L[stje_sp] = 0.66; 
    eKELBM.L[sbyg_sp] = 0.00; #Should be zero according to MAKRO
    eKELBM.L[sUdv_sp] = 0.51; 
    eKELBM.L[sEne_sp] = 0.24; 

    # The maritime transport and houseing sectors are assigned the same elasticity as services - MKH
    eKELBM.L[sSoe_sp] = 0.66; 
    eKELBM.L[sBol_sp] = 0.66; 
    

    # KEL_B
    eKELB.l[sp]  = 0.50;

    eKELB.l[sLan_sp] = 0.07;
    eKELB.l[sFre_sp] = 0.23; 
    eKELB.l[stje_sp] = 0.59;  
    eKELB.l[sbyg_sp] = 0.02;
    eKELB.l[sUdv_sp] = 0.02;
    eKELB.l[sEne_sp] = 0.10; # should be zero according to MAKRO

    # Samme som foroven 
    eKELB.l[sSoe_sp] = 0.59; 
    eKELB.l[sBol_sp] = 0.59; 
    


    # KE_L
    eKEL.L[sp]   = 0.6;

    eKEL.L[sLan_sp]   = 0.67;
    eKEL.L[sFre_sp]   = 0.51;
    eKEL.L[stje_sp]   = 1.17;
    eKEL.L[sbyg_sp]   = 0.26;
    eKEL.L[sUdv_sp]   = 0.29;
    eKEL.L[sEne_sp]   = 0.10; # should be zero according to MAKRO

    # Same as above
    eKEL.L[sSoe_sp]   = 1.17;
    eKEL.L[sBol_sp]   = 1.17;
    

    #  eKE.l['0600a'] = 0.1; #Nordsø
    eREP.l[s]    = 0.1;
    eRE.l[purpose,sp] = 0.1;

    eProd.l['KELBM',sp]  = eKELBM.l[sp];
    eProd.l['KELB',sp]   = eKELB.l[sp];
    eProd.l['KEL',sp]    = eKEL.l[sp];
    eProd.l['KETM',sp]   = eKETM.l[sp];
    eProd.l['TKE',sp]    = eTKE.l[sp];
    eProd.l['MKE',sp]    = eMKE.l[sp];
    eProd.l['EOther',sp] = eREP.l[sp]; 


    #2) EXOGENOUS VALUE
    uKInstCost.l[k,sp,t]        = 1;#  Kinstcost.l[k,'01052'] = 0; #£AKB
    uKinstcost.l[k,'68203',t]   = 4.5;
    uKinstCost.l[k,'OFF',t]     = 0; 
    uKinstCost.l[k,'02000',t]   = 0;
    uKinstcost.l['ib','01051',t] = 1;

    tCorpRes.l[tData]       = 0;
    prod_s.l[s,t] = 1;


    # Tax depreciation
    parameter rTaxDepr0[*,t];
    rTaxDepr0['Ix',tData] = 0.06;
    rTaxDepr0['iT',tData] = 0.25;
    rTaxDepr0['iM',tData] = 0.25; #https://www.retsinformation.dk/eli/lta/2021/242#P1
    rTaxDepr0['iB',tData] = 0.04;
    rTaxDep.l[k,t]    = rTaxDepr0[k,t];

    sDebt2K.l[k,s,t]  = 0.6; 


    vKtax.l[k,sp,t]$(tData1[t] and d1I_s[k,sp,t]) = vI_s.l[k,sp,t]/rTaxDep.l[k,t];  
    loop(t$tDataX1[t], 
      vKtax.l[k,sp,t]$(d1I_s[k,sp,t]) = vKtax.l[k,sp,t-1]*(1-rTaxDep.l[k,t]) + vI_s.l[k,sp,t];
    );

        #From External forecast 
    tCorp.l[t]                      = ExtFor_tCorp[t];
    rFirms.l[sp,t]                  = max(0.07, ExtFor_rInterest['RealKred',t] + 0.025);
    #  rFirms.l[agri_sectors,t]        = 0.04; rFirms.l['01080',t] = 0.04; #£zeroprofitagr
    rFirms.l[agri_sectors,t]        = 0.05; rFirms.l['01080',t] = 0.05; rFirms.l['01020',t] = 0.06;
    rFirms.l['02000',t]             = 0.05; #Applies the same discounting in forestry as in agriculture
    #  rFirms.l[FoodProcessingSectors,t] = 0.04;
    rFirms.l[FoodProcessingSectors,t] = 0.05;
    rFirms.l[off_ish,t]             = 0; #Public-like sectors operate without return requirements
    rFirms.l['68203',t]             = 0.035; #Housing sector with a half return requirement
    rFirms.l['35011',t]             = 0.04;  #Low return-requirement (afkastkrav) in the energy supply sector
    rFirms.l['35012',t]             = 0.04; #temporary return-requirement
    rFirms.l['38393',t]             = 0.04; 
    rFirms.l['35002',t]             = 0.04; 

    rInvestor.l[sp,t]               = 0.07;

    rInterest.l['bonds',t]          = ExtFor_rInterest['Obl',t];
    rInterest.l['ForeignEquity',t]  = ExtFor_rInterest['UdlAktier',t];
    rInterest.l['Equity',t]         = ExtFor_rInterest['IndlAktier',t];
    rInterest.l['Deposits',t]       = ExtFor_rInterest['Bank',t];
    rInterest.l['Mortgages',t]      = ExtFor_rInterest['RealKred',t];
    rInterest.l['Debt',t]           = ExtFor_rInterest['BankGaeld',t];
    rBonds.l[sp,t]                  = rInterest.l['bonds',t];
    
#      # We set the effective interest rate on debt
#      rBonds.l[agri_sectors,tData] = 0.016; LOOP(t$(t.val >2019), rBonds.l[agri_sectors,t] = rBonds.l[agri_sectors,t-1] + rBonds.l['71000',t] -rBonds.l['71000',t-1]); #Kilde: Korrespondance m. Nationalbanken 
    
#      # In the rest of the economy we apply the same debt interest rate as in agricultural sectors
#      rBonds.l[sp,t]$(not agri_sectors[sp]) = rBonds.l['01011',t];

    #Public productivity in the equation for pKELBM['OFF',t]
    loop(t$(t.val > 2019),
    prod_s.FX['OFF',t]$ExtFor_qProd_s['OFF',t-1] = prod_s.l['OFF',t-1] *ExtFor_qProd_s['OFF',t]/ExtFor_qProd_s['OFF',t-1];
    );


#3) COMPUTATIONS 

   #Hack af kapitalapparat
    loop(t$(tDataX1[t]), 
        qK.l[k,sOFF,t]    = (1-ExtFor_rAfskr[k,'OFF',t])*qK.l[k,sOFF,t-1] + qI_s.l[k,sOFF,t];
        qK.l[k,sTJE,t]    = (1-ExtFor_rAfskr[k,'TJE',t])*qK.l[k,sTJE,t-1] + qI_s.l[k,sTJE,t];
        qK.l[k,sFRE,t]    = (1-ExtFor_rAfskr[k,'FRE',t])*qK.l[k,sFRE,t-1] + qI_s.l[k,sFRE,t];
        #  qK.l[k,sLAN,t] = (1-ExtFor_rAfskr[k,'LAN',t])*qK.l[k,sLAN,t-1] + qI_s.l[k,sLAN,t];
        qK.l['Im',sLAN,t] = (1-0.095)*qK.l['im',sLAN,t-1]                          + qI_s.l['im',sLAN,t]; #£zeroprofitagr - REFORM discountrate
        qK.l['It',sLAN,t] = (1-0.095)*qK.l['it',sLAN,t-1]                          + qI_s.l['it',sLAN,t]; #£zeroprofitagr
        qK.l['Ib',sLAN,t] = (1-0.026)*qK.l['ib',sLAN,t-1]                          + qI_s.l['ib',sLAN,t]; #£zeroprofitagr

        
        qK.l[k,sbyg,t]    = (1-ExtFor_rAfskr[k,'BYG',t])*qK.l[k,sbyg,t-1]         + qI_s.l[k,sbyg,t];
        qK.l[k,sENE,t]    = (1-ExtFor_rAfskr[k,'ENE',t])*qK.l[k,sENE,t-1]         + qI_s.l[k,sENE,t];
        qK.l[k,sUDV,t]    = (1-ExtFor_rAfskr[k,'UDV',t])*qK.l[k,sUDV,t-1]         + qI_s.l[k,sUDV,t];
        qK.l[k,sSOE,t]    = (1-ExtFor_rAfskr[k,'SOE',t])*qK.l[k,sSOE,t-1]         + qI_s.l[k,sSOE,t];
        qK.l[k,'50001',t] = (1-ExtFor_rAfskr[k,'SOE',t])*qK.l[k,'50001',t-1]      + qI_s.l[k,'50001',t];
        qK.l['im',sBOL,t] = (1-0.15) * qK.l['im',sBol,t-1]                        + qI_s.l['im',sBol,t];
        qK.l['it',sBOL,t] = (1-0.15) * qK.l['it',sBol,t-1]                        + qI_s.l['it',sBol,t];

        qK.l['ib',sBOL,t] = (1-ExtFor_rAfskr['ib','BOL',t]) * qK.l['ib',sBol,t-1] + qI_s.l['ib',sBol,t];
        );




    #Public investments are set equal to values from MAKRO. Additionally, the public investments are exogenous/policy-determined
    LOOP(t$(tForecast[t]),     qI_s.l[k,'off',t]$(not sameas[k,'iT'])      = ExtFor_qI_s[k,'OFF',t]/ExtFor_qI_s[k,'OFF',t-1] * qI_s.l[k,'off',t-1];);
    LOOP(t$(tForecast[t]),                            qI_s.l['iT','off',t] = ExtFor_qI_s['iM','OFF',t]/ExtFor_qI_s['im','OFF',t-1] * qI_s.l['iT','off',t-1];);


    #USER-COST!!!

    #HACK 
    pI_s.l['ib','45000','2017'] = pI_s.l['ib','45000','2018']/fp; #Bygningsinvesteringsprisen i 2017 er bizart lav (0.02) netop her


    #Calculate smooth depriciation and investment-expectations
    rDepr_static.l[k,s,t]$(tData[t] and qK.l[k,s,t])  = max(0, (qI_s.l[k,s,t+1] - (qK.l[k,s,t+1] - qK.l[k,s,t])) / qK.l[k,s,t]);
    gpI_s_static.l[k,s,t]$(tData[t] and pI_s.l[k,s,t]) = pI_s.l[k,s,t] / pI_s.l[k,s,t-1] - 1;

    loop(t$tDataX1[t], 
    rDepr_static.l[k,s,t]$io_qK[k,s,t]     = 0.8 * rDepr_static.l[k,s,t-1] + 0.2 * max(0, (qI_s.l[k,s,t] - (qK.l[k,s,t] - qK.l[k,s,t-1])) / (qK.l[k,s,t-1]));
    #Fairly static expectations. Weighted average of 80% of the previous period's price change, 20% the actual
    gpI_s_static.l[k,s,t]$io_pI_s[k,s,t-1] = 0.8 * gpI_s_static.l[k,s,t-1] + 0.2 * (pI_s.l[k,s,t] / (pI_s.l[k,s,t-1]) - 1);
    );

    rDepr_static.l['iT',s,t] = rDepr_static.l['iM',s,t];


    #Recalculates capital taxation with hacked capital apparatus
    tK.l['ib',s,t]$((tData[t] and  pI_s.l['ib',s,t] * qK.l['ib',s,t] ) ne 0) 
                    = io_FakDutyB_xh(s,t) / (pI_s.l['ib',s,t] * qK.l['ib',s,t] );

    tK.l['it',s,t]$(tData[t] and ( io_pI_s['it',s,t] * io_qK['it',s,t] ) ne 0) 
        = io_FakDutyEkso_v(s,t) / (pI_s.l['it',s,t] * qK.l['it',s,t] );



    

      #===> Here it is pK
       pK.l[k,sp,t]$(tData[t]) = (pI_s.l[k,sp,t-1] * (
#        # Tobin's q today and tomorrow
        (1-tCorp.l[t] * rTaxDep.l[k,t] / (rFirms.l[sp,t] + rTaxDep.l[k,t])) 
        * ( rFirms.l[sp,t] + rDepr_static.l[k,sp,t] - (1 - rDepr_static.l[k,sp,t]) * gpI_s_static.l[k,sp,t])
#        #   Production tax on capital
        + (1-tCorp.l[t]) * (1+gpI_s_static.l[k,sp,t]) * tK.l[k,sp,t]
#        # Tax shield.l
        - tCorp.l[t] * rBonds.l[sp,t] * sDebt2K.l[k,sp,t-1]))/(1-tCorp.l[t]);     

  
    #Tax shield  
    EKtax.l[k,sp,t]$(tData[t]) = tCorp.l[t] * rTaxDep.l[k,t] / (rFirms.l[sp,t] + rTaxDep.l[k,t]);




#4) INITIAL VALUES 
    pY0_CET.l[out,s,t] = pY_CET.l[out,s,t];
    uY_CET.l[out,sp,t] = qY_CET.l[out,sp,t]; 

    pY0.l[s,tData] = 1;


    pEP.l[purpose,s,tData] = 1;



    vEBT.l[sp,tData] = 1; #Initial value


    qKInstCost.l[k,s,t]$qK.l[k,s,t-1] = uKInstCost.l[k,s,t]/2 * IO_qK[k,s,t-1] * sqr(IO_qI_s[k,s,t]/IO_qK[k,s,t-1]);

    qKELBM.l[s,t] = qY.l[s,t] + sum(k,qKInstCost.l[k,s,t]);




    pKELBM.l[s,tData] = 1;

    markup_cali.l[s,tData]$pKELBM.l[s,tData] = (pY.l[s,tData]/pKELBM.l[s,tData]) - 1;

    pTobinsQ.l[k,sp,t]$(tData[t])= 1;

    vFirmDebt.l[sp,t]$(tData[t]) =  1;

    vEBITDA.l[sp,t] = vY.l[sp,t] - w.l[t] * qL.l[sp,t] - sum((purpose,energy19), vREa.l[purpose,energy19,sp,t]) - vRxE.l[sp,t] - vtNetProduction.l[sp,t]; 

    vFCFE.l[sp,t] = vEBITDA.l[sp,t] * 0.5;
    vFCFE.l['tot',t] = sum(sp, vFCFE.l[sp,t]);

    vEquity.l[sp,t] = qKELBM.l[sp,t]; 

    fW.l[s,tData]  = 1; fW0.l[s,tData] = 1;
    prod_a.l[tData] = 1;

    N_L.l[s,tData] = 1;
    
    rDepr.l[k,sp,tData] = 0.05;

    uProd.l[prd,sp,tData]=qProd.l[prd,sp,tData];
    thetaProd.l[prd,sp,tData] = 1;
    TFP.l[prdNest,sp,t] = 1;

 #5) DUMMIES 


    #Investments and capital
    d1I_s[i_,s,t]    = yes$(abs(IO_qI_s[i_,s,t]) > min_cell_size);
    d1K['invt',s_,t] = no;
    d1K[k,s,t]       = yes$(qK.l[k,s,t] <> 0);
    d1K[k,'tot',t]   = yes$(sum(s, d1K[k,s,t]) <> 0);
    d1K['iTot',s_,t] = yes$(sum(k, d1K[k,s_,t]) <> 0);
    d1Fin_k[k,s,t]   = yes$(qFin_k.l[k,s,t]);

    #Control which energy-use is not in energy nest
    eNotInEnergyNest[purpose,energy19,s,t] = no;
    eNotInEnergyNest['process_special','natural gas (Extraction)','35002',tData] = yes; 
    eNotInEnergyNest['process_special','El from y and m','35012',tData] = yes; 
    eNotInEnergyNest['process_special','biogas','35002',tData] = yes; 
    eNotInEnergyNest['process_special','Electricity','71000',tData] = yes; 
    eNotInEnergyNest['process_special','Crude oil','19000',tData] = yes;


$ENDIF

# ======================================================================================================================
# Static calibration
# ======================================================================================================================
$IF %stage% == "static_calibration":

PARAMETER d1pK_t0[s];
d1pK_t0[s] = yes;
d1pK_t0[s]$(agri_sectors_s[s]) = no;

    $GROUP G_production_private_static_calibration 
        G_production_private_endo
                markup$(sp[s] and d1vY_CET[out,s,t] and not ((sameas[out,'refinery gas'] or sameas[out,'semi-refined oil']) and sameas[s,'19000'])) # E_markup #No mark-up on refinery gas as it is own-consumption. Furthermore. Semi-refined oil is not in ENS-data. A neutral calibration approach is setting the mark-up to zero and letting the model decide.
                markup_cali$(sp[s] and sum(out,d1vY_CET[out,s,t])), - pY_CET$(d1vY_CET[out,s,t]) # E_pY_CET


                rDepr[k,s,t]$(d1K[k,s,t] and tx0[t]),  #E_rDepr_sp     #Important that is is rDepr$(tx0[t]) because rDepr[t0] is included in Government.gms     
                -qI_s[i_,s,t]$(k_[i_] and not sameas(i_,'iTot')), jqI_s #E_qI_s        
                rIL[s,t], -qI_s[i_,s,t]$(sameas(i_,'invt')) # E_qI_s_inv


                #Energy not in nesting
                 -qREa$(tx0[t] and d1pREa[purpose,energy19a,s,t] and eNotInEnergyNest[purpose,energy19a,s,t] and sameas[purpose,'process_special'] and sameas[energy19a,'Natural gas (Extraction)'] and sameas[s,'35002']) # E_qRE_natgas
                  uRE$(tx0[t] and d1pREa[purpose,energy19a,s,t] and eNotInEnergyNest[purpose,energy19a,s,t] and sameas[purpose,'process_special'] and sameas[energy19a,'Natural gas (Extraction)'] and sameas[s,'35002']) # E_qRE_natgas
                -qREa$(tx0[t] and d1pREa[purpose,energy19a,s,t] and eNotInEnergyNest[purpose,energy19a,s,t] and sameas[purpose,'process_special'] and sameas[energy19a,'Biogas'] and sameas[s,'35002']) # E_qRE_biogas
                  uRE$(tx0[t] and d1pREa[purpose,energy19a,s,t] and eNotInEnergyNest[purpose,energy19a,s,t] and sameas[purpose,'process_special'] and sameas[energy19a,'Biogas'] and sameas[s,'35002']) # E_qRE_biogas
                -qREa$(tx0[t] and d1pREa[purpose,energy19a,s,t] and eNotInEnergyNest[purpose,energy19a,s,t] and sameas[purpose,'process_special'] and sameas[energy19a,'Electricity'] and sameas[s,'71000']) # E_qRE_DataCentre
                  uRE$(tx0[t] and d1pREa[purpose,energy19a,s,t] and eNotInEnergyNest[purpose,energy19a,s,t] and sameas[purpose,'process_special'] and sameas[energy19a,'Electricity'] and sameas[s,'71000']) # E_qRE_DataCentre
                -qREa$(tx0[t] and d1pREa[purpose,energy19a,s,t] and eNotInEnergyNest[purpose,energy19a,s,t] and sameas[purpose,'process_special'] and sameas[energy19a,'crude oil'] and sameas[s,'19000']) # E_qRE_CrudeOilToRefineries
                  uRE$(tx0[t] and d1pREa[purpose,energy19a,s,t] and eNotInEnergyNest[purpose,energy19a,s,t] and sameas[purpose,'process_special'] and sameas[energy19a,'crude oil'] and sameas[s,'19000']) # E_qRE_CrudeOilToRefineries
                -qREa$((sameas[purpose,'Transport'] or sameas[purpose,'intern_trans']) and d1pREa[purpose,energy19a,s,t] and not eNotInEnergyNest[purpose,energy19a,s,t] and not sameas[s,"off"]) # E_qRE_trans
                  uRE$((sameas[purpose,'Transport'] or sameas[purpose,'intern_trans']) and d1pREa[purpose,energy19a,s,t] and not eNotInEnergyNest[purpose,energy19a,s,t] and not sameas[s,"off"]) # E_qRE_trans
                -qREa$(tx0[t] and d1pREa[purpose,energy19a,s,t] and not eNotInEnergyNest[purpose,energy19a,s,t] and not (sameas[purpose,"transport"] or sameas[purpose,'intern_trans']) and not sameas[s,"off"]) # E_qREa
                  uRE$(tx0[t] and d1pREa[purpose,energy19a,s,t] and not eNotInEnergyNest[purpose,energy19a,s,t] and not (sameas[purpose,"transport"] or sameas[purpose,'intern_trans']) and not sameas[s,"off"]) # E_qREa
                -qREa$(tx0[t] and d1pREa[purpose,energy19a,s,t] and eNotInEnergyNest[purpose,energy19a,s,t] and bunkering[energy19a]) # E_qRE_bunkering
                  uRE$(tx0[t] and d1pREa[purpose,energy19a,s,t] and eNotInEnergyNest[purpose,energy19a,s,t] and bunkering[energy19a]) # E_qRE_bunkering

                #Nesting tree
                uProd$(tx0[t] and d1Prod[prd,sp,t] and not prdTop(prd))
                -qProd$(tx0[t] and d1Prod[prd,sp,t] and prdBot[prd] and not prdBotUlt(prd) and not prdfin(prd))
                -qK$(tx0[t] and d1K[k,s,t])
                -qFin_k$(d1Fin_k[k,r,t]) 
                -pProd$(tx0[t] and d1Prod[prd,sp,t] and (prdNest(prd)) and not prdTop(prd))
                
                #E_pProd_Nest
                pProd$(t0[t] and d1Prod[prd,sp,t] and prdNest(prd) and not prdTop(prd)), -pProd$(tBasis[t] and d1Prod[prd,sp,t] and prdNest(prd) and not prdTop(prd))
                -pProd$(t0[t] and d1Prod[prd,sp,t] and prdTop(prd))

                #Energy
                pProd$(t0[t] and d1Prod[prd,sp,t] and (sameas(prd,'Eother') or sameas(prd,'Etrans')))
                -pProd$(tBasis[t] and d1Prod[prd,sp,t] and (sameas(prd,'Eother') or sameas(prd,'Etrans')))
                uEP 
                pEP, -pEP$(tBasis[t])

                -pK, pK$(tx0[t]) # E_pK_static_calib
                pTobinsQ$(t0[t]) #E_pTobinsQ_t0
                fKInstCost$(sp[s]) # E_fKInstCost_static_calibration_sp
            
                -nEmployed_s, fW0 # E_fW0
                prod_a,-w # E_nL
                
                #AKB
                uY_CET$(d1vY_CET[out,s,t]), -pY_CET$(d1vY_CET[out,s,t])
                -qY #We do not create chain indexes for qY0/pY0, but instead use chain indexes from the data
                
                tK # E_tK
                -dKInstCost2dK  # E_dqKInstCost2dqK
     ;

    $GROUP G_production_private_static_calibration_exo 
            G_production_private_exo
            
                    -markup$(sp[s] and d1vY_CET[out,s,t] and not ((sameas[out,'refinery gas'] or sameas[out,'semi-refined oil']) and sameas[s,'19000'])) # E_markup
                    -markup_cali$(sp[s] and sum(out,d1vY_CET[out,s,t])), pY_CET$(d1vY_CET[out,s,t]) # E_pY_CET
                   
                   -rDepr[k,s,t]$(d1K[k,s,t] and tx0[t]), rDepr_static$(tx0[t]) #E_rDepr_sp
                    qI_s[i_,s,t],  jqI_s   # E_qI_s       
                    qI_s[i_,s,t]$(sameas(i_,'invt')), -rIL[s,t]  # E_qI_s_inv

                    qREa$(tx0[t] and d1pREa[purpose,energy19a,s,t] and eNotInEnergyNest[purpose,energy19a,s,t] and sameas[purpose,'process_special'] and sameas[energy19a,'Natural gas (Extraction)'] and sameas[s,'35002']) # E_qRE_natgas
                    -uRE$(tx0[t] and d1pREa[purpose,energy19a,s,t] and eNotInEnergyNest[purpose,energy19a,s,t] and sameas[purpose,'process_special'] and sameas[energy19a,'Natural gas (Extraction)'] and sameas[s,'35002']) # E_qRE_natgas
                    qREa$(tx0[t] and d1pREa[purpose,energy19a,s,t] and eNotInEnergyNest[purpose,energy19a,s,t] and sameas[purpose,'process_special'] and sameas[energy19a,'Biogas'] and sameas[s,'35002']) # E_qRE_biogas
                    -uRE$(tx0[t] and d1pREa[purpose,energy19a,s,t] and eNotInEnergyNest[purpose,energy19a,s,t] and sameas[purpose,'process_special'] and sameas[energy19a,'Biogas'] and sameas[s,'35002']) # E_qRE_biogas
                    qREa$(tx0[t] and d1pREa[purpose,energy19a,s,t] and eNotInEnergyNest[purpose,energy19a,s,t] and sameas[purpose,'process_special'] and sameas[energy19a,'Electricity'] and sameas[s,'71000']) # E_qRE_DataCentre
                    -uRE$(tx0[t] and d1pREa[purpose,energy19a,s,t] and eNotInEnergyNest[purpose,energy19a,s,t] and sameas[purpose,'process_special'] and sameas[energy19a,'Electricity'] and sameas[s,'71000']) # E_qRE_DataCentre
                    qREa$(tx0[t] and d1pREa[purpose,energy19a,s,t] and eNotInEnergyNest[purpose,energy19a,s,t] and sameas[purpose,'process_special'] and sameas[energy19a,'crude oil'] and sameas[s,'19000']) # E_qRE_CrudeOilToRefineries
                    -uRE$(tx0[t] and d1pREa[purpose,energy19a,s,t] and eNotInEnergyNest[purpose,energy19a,s,t] and sameas[purpose,'process_special'] and sameas[energy19a,'crude oil'] and sameas[s,'19000']) # E_qRE_CrudeOilToRefineries
                    qREa$((sameas[purpose,'Transport'] or sameas[purpose,'intern_trans']) and d1pREa[purpose,energy19a,s,t] and not eNotInEnergyNest[purpose,energy19a,s,t] and not sameas[s,"off"]) # E_qRE_trans
                    -uRE$((sameas[purpose,'Transport'] or sameas[purpose,'intern_trans']) and d1pREa[purpose,energy19a,s,t] and not eNotInEnergyNest[purpose,energy19a,s,t] and not sameas[s,"off"]) # E_qRE_trans
                    qREa$(tx0[t] and d1pREa[purpose,energy19a,s,t] and not eNotInEnergyNest[purpose,energy19a,s,t] and not (sameas[purpose,"transport"] or sameas[purpose,'intern_trans']) and not sameas[s,"off"]) # E_qREa
                    -uRE$(tx0[t] and d1pREa[purpose,energy19a,s,t] and not eNotInEnergyNest[purpose,energy19a,s,t] and not (sameas[purpose,"transport"] or sameas[purpose,'intern_trans']) and not sameas[s,"off"]) # E_qREa
                    qREa$(tx0[t] and d1pREa[purpose,energy19a,s,t] and eNotInEnergyNest[purpose,energy19a,s,t] and bunkering[energy19a]) # E_qRE_bunkering
                    -uRE$(tx0[t] and d1pREa[purpose,energy19a,s,t] and eNotInEnergyNest[purpose,energy19a,s,t] and bunkering[energy19a]) # E_qRE_bunkering

                    #Nesting tree
                    -uProd$(tx0[t] and d1Prod[prd,sp,t] and not prdTop(prd))
                    qProd$(tx0[t] and d1Prod[prd,sp,t] and prdBot[prd] and not prdBotUlt(prd) and not prdfin(prd))
                    qK$(tx0[t] and d1K[k,s,t])
                    qFin_k$(d1Fin_k[k,r,t])
                    qProd$(tx0[t] and d1Prod[prd,sp,t] and prdBot[prd]) 

                    # E_pProd_Nest
                    -pProd$(t0[t] and d1Prod[prd,sp,t] and prdNest(prd) and not prdTop(prd)), pProd$(tBasis[t] and d1Prod[prd,sp,t] and prdNest(prd) and not prdTop(prd))
                    pProd$(t0[t] and d1Prod[prd,sp,t] and prdTop(prd)) 
                    
                    #Energy
                    -pProd$(t0[t] and d1Prod[prd,sp,t] and (sameas(prd,'Eother') or sameas(prd,'Etrans')))
                    pProd$(tBasis[t] and d1Prod[prd,sp,t] and (sameas(prd,'Eother') or sameas(prd,'Etrans')))

                    -uEP, pREa$(t0[t] and d1pREa[purpose,energy19a,s,t+1] and not eNotInEnergyNest[purpose,energy19a,s,t+1]) # E_pProd_Nest_prdPurpose
                    pEP$(tBasis[t]),-pEP$(t0[t])

                    # E_pK_static_calib
                    pK, -pK$(tx0[t]) 
                    sDebt2K$(t0[t])
                    pI_s$(t0[t])
                    gpI_s_static$(tx0[t])

                   -fKInstCost$(sp[s]) # E_fKInstCost_static_calibration

                    nEmployed_s, -fW0 # E_fW0
                    w, -prod_a # E_nL
                    
                    -uY_CET$(d1vY_CET[out,s,t]), pY_CET$(d1vY_CET[out,s,t])
                    qY

                    # E_tK
                    -tK 
                    qK$(tx0[t] and d1K[k,s,t] and sameas(s,'off'))

                    dKInstCost2dK # E_dqKInstCost2dqK
      ;

	  $GROUP gg placehold[k,sp,t] "";

	  $BLOCK B_production_private_static_calibration

	   #We take qY from NR. Alternatively, one could calibrate to, for example, a chain index using the below
	   E_markup_sp[out,sp,t]$(tx0[t] and d1vY_CET[out,sp,t] and not ((sameas[out,'refinery gas'] or sameas[out,'semi-refined oil']) and sameas[sp,'19000']))..  
	       markup[out,sp,t] =E= markup_cali[sp,t];


       E_pProd_Nest[prdNest,sp,t]$(tx0[t] and d1Prod[prdNest,sp,t] and not prdTop[prdNest]).. 
           pProd[prdNest,sp,t-1] * qProd[prdNest,sp,t] =E= sum(prd$(d1Prod[prd,sp,t] and prdNest2Prd[prdNest,prd] and not prdBotUlt[prd]), pProd[prd,sp,t-1] * qProd[prd,sp,t])
           +  sum(prd$(d1Prod[prd,sp,t] and prdNest2Prd(prdNest,prd) and prdBotUlt[prd]),  pProd[prd,sp,t-1] * qProd[prd,sp,t-1]/fq);

       E_sEtrans[sp,t]$(tx0[t] and d1Prod['Etrans',sp,t]).. pProd['Etrans',sp,t-1] * qProd['Etrans',sp,t] =E= sum(purpose$(d1EP[purpose,sp,t] and (sameas[purpose,'Transport'] or sameas[purpose,'intern_trans'])), pEP[purpose,sp,t-1]*qEP[purpose,sp,t]);
    
       E_sE_notoff[sp,t]$(tx0[t] and d1Prod['EOther',sp,t]).. pProd['Eother',sp,t-1] * qProd['Eother',sp,t] =E= sum(purpose$(d1EP[purpose,sp,t] and not (sameas[purpose,'Transport'] or sameas[purpose,'intern_trans'])), pEP[purpose,sp,t-1] * qEP[purpose,sp,t]);
    
       E_sEP_notoff[purpose,sp,t]$(tx0[t] and d1EP[purpose,sp,t]).. pEP[purpose,sp,t-1] * qEP[purpose,sp,t] =E= sum(energy19$(d1pREa[purpose,energy19,sp,t] and not eNotInEnergyNest[purpose,energy19,sp,t]), pREa[purpose,energy19,sp,t-1] * qREa[purpose,energy19,sp,t]);


	   #The above is replaced by 
	   E_fKInstCost_static_calibration_sp[k,sp,t]$(tx0[t] and d1K[k,sp,t] and d1I_s[k,sp,t-1])..
	     0 =E= qI_s[k,sp,t] - qI_s[k,sp,t-1]/fq * fKInstCost[k,sp,t];
	   
	   #In case of zero investments in the previous year, fK cannot be identified. It is then set to the previous year's value. In the current version, there are two sectors with zero investments, 53000,ib,2012 and 78000,ib,2012
	   E_fKInstCost_static_calibration_ifzero_sp[k,sp,t]$(tx0[t] and d1K[k,sp,t] and not d1I_s[k,sp,t-1])..
	    fKInstCost[k,sp,t] =E=  fKInstCost[k,sp,t-1];

	    E_fW0[t]$(tx0[t])..
	      sum(s, fW0[s,t] * nEmployed_s[s,t]) =E= sum(s, nEmployed_s[s,t]);

	    #AKB: It's not quite kosher to have data parameters in equations
	    E_tK_ib[s,t]$(tx0[t] and d1K['ib',s,t])..
	          tK['ib',s,t] =E= io_FakDutyB_xh(s,t)*inf_growth_factor[t]   / (pI_s['ib',s,t] * qK['ib',s,t]);
	                    
	    E_tK_im[s,t]$(tx0[t] and d1K['im',s,t])..
	        tK['im',s,t]   =E= 0 * inf_growth_factor[t] / (pI_s['im',s,t] * qK['im',s,t]);

	    E_tK_it[s,t]$(tx0[t] and d1K['iT',s,t])..
	        tK['iT',s,t]   =E= io_FakDutyEkso_v(s,t)*inf_growth_factor[t] / (pI_s['iT',s,t] * qK['iT',s,t]);    


	    E_pK_static_calib[k,sp,t]$(tx0[t] and d1k[k,sp,t-1] and not agri_sectors[sp] and not d1pK_t0[sp])..

	      (1-tCorp[t]) * pK[k,sp,t] =E= # pK.l[k,sp,t];
	         (pI_s[k,sp,t-1]/fp * (
	#        # Tobin's q today and tomorrow
	        (1-tCorp[t] * rTaxDep[k,t] / (rFirms[sp,t] + rTaxDep[k,t])) 
	        * ( rFirms[sp,t] + rDepr_static[k,sp,t] - (1 - rDepr_static[k,sp,t]) * gpI_s_static[k,sp,t])
	#        #   Production tax on capital
	        + (1-tCorp[t]) * (1+gpI_s_static[k,sp,t]) * tK[k,sp,t]
	#        # Tax shield.l
	        - tCorp[t] * rBonds[sp,t] * sDebt2K[k,sp,t-1]));     

    $LOOP E_pK:
        {name}_t0{sets}$(t0[t] and d1K[k,sp,t+1] and not agri_sectors[sp] and d1pK_t0[sp] and not sameas[sp,'68203'])..
            {LHS} =E= {RHS};
    $ENDLOOP

    $LOOP E_pK:
        {name}_t0_plant_sectors{sets}$(t0[t] and d1K[k,sp,t+1] and plant_sectors_sp[sp])..
            pK[k,sp,t+1] =E= sum((plant_pK,plant_sectors)$(agri2k[plant_pK,k] and map_plantsectors2s(plant_sectors,sp)), pPlant_uc[plant_sectors,plant_pK,t+1]);
    $ENDLOOP

    $LOOP E_pK:
        {name}_t0_ani_sectors{sets}$(t0[t] and d1K[k,sp,t+1] and ani_sectors_sp[sp])..
            pK[k,sp,t+1] =E= sum((ani_pK,ani_sectors)$(agri2k[ani_pK,k] and map_anisectors2s(ani_sectors,sp)), pAni_uc[ani_sectors,ani_pK,t+1]);
    $ENDLOOP

	    E_pK_t0_68203[k]..
	        pK[k,'68203',t1] =E= 0.045$(sameas[k,'ib']) + 0.165$(sameas[k,'iM']) + 0.255$(sameas[k,'it']);

	    #  E_pK_t0_51001[k]..
	    #      pK[k,'51001',t1] =E= 0.268$(sameas[k,'ib']) + 0.237$(sameas[k,'iM']) + 0.242$(sameas[k,'it']);

	    E_pTobinsQ_t0[k,sp,t]$(t0[t] and d1K[k,sp,t])..
	        pTobinsQ[k,sp,t] =E= pTobinsQ[k,sp,t+1];

	    E_rDepr_sp[k,sp,t]$(tx0[t] and d1K[k,sp,t])..
	        rDepr[k,sp,t] =E= rDepr_static[k,sp,t];


	    #  $LOOP00 E_pK_map:
	    #      {name}_t0{sets}$(t0[t] and d1Prod[prd,sp,t+1] and mapprd2k(prd,k))..
	    #          {LHS} =E= {RHS};
	    #  $ENDLOOP00
	                       
	   $ENDBLOCK

	  $MODEL M_production_private_static_calibration
	    M_production_private
	    -E_qI_s_end
	    -E_nL_tot
	    -E_dqKInstCost2dqK #qI_s[t+1] 
	    B_production_private_static_calibration
	 ;

	#Load mark-up target from time-series analysis of aggregate sectors. For now target is just set to zero
	    PARAMETER markup_target[sp,t]; markup_target[sp,t] = 0; 
	    $GROUP G_commonmarkup commonmarkup[ns69] "", penalty_markup[sp] "", penalty_capital[k,sp] "";

	    markup_target['01011',t] = 0.08; markup_target['01012',t] = 0.08; markup_target['01020',t] = 0.08;
	    markup_target['01031',t] = 0.08; markup_target['01032',t] = 0.08; 
	    markup_target['01051',t] = 0.19; markup_target['01052',t] = 0.19; 
	    markup_target['01061',t] = 0.1;  markup_target['01062',t] = 0.1; 
	    
	    set nottheseman/01070/;

	    #Pre-Model for the distribution of capital apparatus. We only have capital apparatus at the 69 division level. This provides degrees of freedom to move capital around, allowing us to hit lower (and more realistic) mark-ups for the disaggregated sectors.
	    #So far, there is a pre-model for the food industry
	    $BLOCK B_production_private_static_calibration_capital

	        E_markup_cali[sp,t]$(tx0[t] and sum(ns69, ns692s(ns69,sp)) and not agri_sectors[sp])..markup_cali[sp,t] =E= vY.l[sp,t]/(pY0[sp,t]*qY.l[sp,t])-1;

	        E_markup_cali_ani[ani_sectors,t]$(tx0[t] and sum(ns69, ns692s(ns69,ani_sectors)))..markup_cali[ani_sectors,t]   
	              =E= pYAni.l[ani_sectors,t]*qAni.l[ani_sectors,'netprod',t]/(pAni[Ani_sectors,'netprod',t]*qAni.l[ani_sectors,'netprod',t])-1;

	        E_markup_cali_plant[plant_sectors,t]$(tx0[t] and sum(ns69, ns692s(ns69,plant_sectors)))..markup_cali[plant_sectors,t]   
	              =E= pPlant_CET.l[plant_sectors,'netprod',t]*qPlant.l[plant_sectors,'netprod',t]/(pPlant.l[plant_sectors,'netprod',t]*qPlant[plant_sectors,'netprod',t])-1;


	        E_vY0[sp,t]$(tx0[t] and sum(ns69, ns692s(ns69,sp)) and not agri_sectors[sp]).. 
	            pY0[sp,t] * qY.l[sp,t] =E= pY0.l[sp,t] * qY.l[sp,t]  + sum(k,pK[k,sp,t] * qK[k,sp,t-1]/fq - pK.l[k,sp,t] * qK.l[k,sp,t-1]/fq);  

	        E_vY_ani[ani_sectors,t]$(tx0[t] and sum(ns69, ns692s(ns69,ani_sectors))).. 
	            pAni[Ani_sectors,'netprod',t]*qAni.l[ani_sectors,'netprod',t] =E= pAni.l[Ani_sectors,'netprod',t]*qAni.l[ani_sectors,'netprod',t] 
	                                                                        #  + sum(k,pK[k,ani_sectors,t] * qK[k,ani_sectors,t-1]/fq - pK.l[k,ani_sectors,t] * qK.l[k,ani_sectors,t-1]/fq)
	                                                                       +  sum(ani_pK, pAni[ani_sectors,ani_pK,t] * sum(k$agri2k[ani_pK,k], qK[k,ani_sectors,t-1]/fq)) - sum(ani_pK, pAni.l[ani_sectors,ani_pK,t] * sum(k$agri2k[ani_pK,k], qK.l[k,ani_sectors,t-1]/fq))
	                                                                       +  sum(plant_sectors$(d1RxE_nm[ani_sectors,plant_sectors,'CoarseFeed',t]), qRxE_nm[ani_sectors,plant_sectors,'CoarseFeed',t]  - qRxE_nm.l[ani_sectors,plant_sectors,'CoarseFeed',t])
	                                                                       +  sum(animals$(sum(emm,d1EmmAgrAni['ManureManagement',ani_sectors,Animals,t,emm])), -(pD_manure[t]-pD_manure.l[t]) * qNManure.l[ani_sectors,animals,t])
	                                                                       ; 

	                                     
	        E_vY_plant[plant_sectors,t]$(tx0[t] and sum(ns69, ns692s(ns69,plant_sectors)))..
	            pPlant.l[plant_sectors,'netprod',t]*qPlant[plant_sectors,'netprod',t] =E= pPlant.l[plant_sectors,'netprod',t]*qPlant.l[plant_sectors,'netprod',t] 
	                                                                                   +  sum(plant_pK, pPlant_uc[plant_sectors,plant_pK,t] * sum(k$agri2k[plant_pK,k], qK[k,plant_sectors,t-1]/fq)) - sum(plant_pK, pPlant_uc.l[plant_sectors,plant_pK,t] * sum(k$agri2k[plant_pK,k], qK.l[k,plant_sectors,t-1]/fq)) 
	                                                                                   +  sum(ani_sectors$(d1RxE_nm[ani_sectors,plant_sectors,'CoarseFeed',t]), qRxE_nm[ani_sectors,plant_sectors,'CoarseFeed',t]  - qRxE_nm.l[ani_sectors,plant_sectors,'CoarseFeed',t])
	                                                                                   +  (pD_manure[t]-pD_manure.l[t]) * qPlant.l[plant_sectors,'manure',t]$(d1Plant[plant_sectors,'Manure',t])
	                                                                                   ;    #For plant-sectors we use user-cost from agricultural module because tK in the CGE-model includes land-taxes which in the agricultural module is linked directly to land as it should be.

	        E_captot_constraint[k,ns69,t]$(tx0[t])..   sum(sp$(ns692s(ns69,sp)), qK[k,sp,t-1]) =E= sum(sp$(ns692s(ns69,sp)), qK.l[k,sp,t-1]);

	        E_obj_cap.. obj =E=     sum((sp,t)$(sum(ns69, ns692s(ns69,sp)) and tx0[t] and not (sameas[sp,'01070'])),                    sqr(markup_target[sp,t] - markup_cali[sp,t])$(not (sameas[sp,'01020'] or sameas[sp,'01080'])) 
	                                                                                                                                  + sqr(markup_target[sp,t] - markup_cali[sp,t])$(sameas[sp,'01020'] or sameas[sp,'01080']))
	                            +   sum((k,sp,t)$(sum(ns69, ns692s(ns69,sp)) and tx0[t]),                                          0.05*sqr(qK[k,sp,t-1]/qK.l[k,sp,t-1]-1))
	                            +   sum(t$(tx0[t]),                                                                                     sqr(pD_manure[t]/pD_manure.l[t]-1))
	                            +   sum((ani_sectors,plant_sectors,t)$(d1RxE_nm[ani_sectors,plant_sectors,'CoarseFeed',t] and tx0[t]),  sqr(qRxE_nm[ani_sectors,plant_sectors,'CoarseFeed',t]/qRxE_nm.l[ani_sectors,plant_sectors,'CoarseFeed',t]-1))

	                            ;
	        E_penalty_markup[sp].. penalty_markup[sp] =E= sum((t)$(sum(ns69, ns692s(ns69,sp)) and tx0[t]),  sqr(markup_target[sp,t] - markup_cali[sp,t]));

	        E_penalty_capital[k,sp].. penalty_capital[k,sp] =E= sum((t)$(sum(ns69, ns692s(ns69,sp)) and tx0[t]), sqr(qK[k,sp,t-1]/qK.l[k,sp,t-1]-1));

	        #We re-compute investments and the thereof following capital level
	        E_qI_s_cap[k,s,ns69,t]$(tx0[t] and ns692s(ns69,s)).. qI_s[k,s,t] =E= sum(ss$(ns692s(ns69,ss)), qI_s[k,ss,t]) * qK[k,s,t-1]/sum(ss$(ns692s(ns69,ss)), qK[k,ss,t-1]);

	        E_qI_s_constraint[k,ns69,t]$(tx0[t]).. sum(ss$(ns692s(ns69,ss)), qI_s[k,ss,t]) =E= sum(ss$(ns692s(ns69,ss)), qI_s.l[k,ss,t]);

	        E_qK_cap[k,s,t]$(tx0[t] and sum(ns69, ns692s(ns69,s))).. qK[k,s,t] =E= (1-rDepr[k,s,t]) * qK[k,s,t-1]/fq + qI_s[k,s,t] + jqI_s[k,s,t];

	        E_qK_notagri[k,s,t]$(tx0[t] and sum(ns69, ns692s(ns69,s)) and not agri_sectors_s[s] and not sameas[s,'35011'] and not sameas[s,'35002'] and not sameas[s,'01080'] and not sameas[s,'23001'] and not sameas[s,'23002']).. jqI_s[k,s,t] =E= 0;

	        E_qK_maskinstation[k,s,t]$(tx0[t] and sum(ns69, ns692s(ns69,s)) and not agri_sectors_s[s] and sameas[s,'01080']).. qK[k,s,t] =E= qK[k,s,t-1]; #Make it think we are in steady-state

	        E_qK_forsyning[k,s,t]$(tx0[t] and sum(ns69, ns692s(ns69,s)) and not agri_sectors_s[s] and (sameas[s,'35011'] or sameas[s,'35002'])).. qK[k,s,t] =E= qK[k,s,t-1]; #Make it think we are in steady-state

	        E_qK_mineralogi[k,s,t]$(tx0[t] and sum(ns69, ns692s(ns69,s)) and not agri_sectors_s[s] and (sameas[s,'23001'] or sameas[s,'23002'])).. qK[k,s,t] =E= qK[k,s,t-1]; #Make it think we are in steady-state

	        E_qK_agri[k,s,t]$(tx0[t] and sum(ns69, ns692s(ns69,s)) and sameas[s,'01070']).. jqI_s[k,s,t] =E= 0;

	        E_qK_plant[k,plant_sectors,t]$(tx0[t] and sum(ns69, ns692s(ns69,plant_sectors))).. qK[k,plant_sectors,t]/qK[k,plant_sectors,t-1] =E= KF_qPlant[plant_sectors,t+1]/KF_qPlant[plant_sectors,t];

	        E_qK_ani[k,ani_sectors,t]$(tx0[t] and sum(ns69, ns692s(ns69,ani_sectors)) and not sameas[ani_sectors,'01070']).. qK[k,ani_sectors,t]/qK[k,ani_sectors,t-1] =E= KF_qAni[ani_sectors,t+1]/KF_qAni[ani_sectors,t];
	               

        #Moving financial services according to accordeons 
            #Value of financial services should stay unchanged
            E_vFin_static_calibration_capital[s,t]$(tx0[t] and sum(ns69, ns692s(ns69,s))).. sum(k,pFin_k[k,s,t] * qFin_k[k,s,t]) =E= sum(k,pFin_k.l[k,s,t] * qFin_k.l[k,s,t]);


            #Financial services allocated according to re-sale of capital
            E_vFin2CAP_static_calibration_capital[k,s,t]$(tx0[t] and sum(ns69, ns692s(ns69,s)) and not plant_sectors_s[s])..
               pFin_k[k,s,t] * qFin_k[k,s,t] =E= sum(kk, pFin_k[kk,s,t] * qFin_k[kk,s,t]) *  qK[k,s,t-1]/fq/(sum(kk, qK[kk,s,t-1]/fq));            


	          
	    $ENDBLOCK 

	    $MODEL M_production_private_static_calibration_capital 
	        B_production_private_static_calibration_capital
	        E_tK_ib #We include equations for capital tax-rate because it influences user-cost, and in turn we need to endogenize user-cost
	        E_tK_im
	        E_tK_it
	        E_pK_static_calib
	        E_pK_t0
	        E_qK_ib_LINK_Plant
	        E_qK_im_LINK_Plant
	        E_qK_it_LINK_Plant
	        E_qK_ib_LINK_ani
	        E_qK_im_LINK_ani
	        E_qK_it_LINK_ani
	        E_qFin_im_LINK_ani
	        E_qFin_iB_LINK_ani
	        E_qFin_iT_LINK_ani
	    ;

	    $GROUP G_production_private_static_calibration_capital_exo 
	        rDepr 
	        pI_s$(tData[t])
	        rTaxDep$(tx0[t])
	        rFirms$(tx0[t])
	        rDepr_static$(tx0[t])
	        gpI_s_static$(tx0[t])
	        tCorp$(tx0[t])
	        sDebt2K$(tData[t])
	        pTobinsQ$(tx0[t] or t0[t])

	    ;

$ENDIF


# ======================================================================================================================
# Dynamic calibration
# ======================================================================================================================
$IF %stage% == "dynamic_calibration":


    parameter d1flatjpk[k,s,t], d1zerojpk[k,s,t], d1decayingjpk[k,s,t];
    d1decayingjpk[k,s,t] = no;

    d1flatjpk[k,sp,t] = yes;
    d1flatjpk[k,sp,t]$(sameas[sp,'68203'] 
                     or sameas[sp,'02000'] 
                     or sameas[sp,'41430']
                     or sameas[sp,'51001'] 
                     or sameas[sp,'03000'] 
                     or sameas[sp,'38393'] 
                     or sameas[sp,'35011'] 
                     or sameas[sp,'35012'] 
                     or sameas[sp,'23001'] 
                     or sameas[sp,'23002'] 
                     or sameas[sp,'35002'] 
                     or sameas[sp,'01080']
                     or sameas[sp,'19000']
                     or sameas[sp,'0600a']
                     
                     or sameas[sp,'01011']
                     or sameas[sp,'01012']
                     or sameas[sp,'01020']
                     or sameas[sp,'01031']
                     or sameas[sp,'01032']
                     or sameas[sp,'01051']
                     or sameas[sp,'01052']
                     or sameas[sp,'01061']
                     or sameas[sp,'01062']
                     or sameas[sp,'01070']
                     or sameas[sp,'01080']
                     or sameas[sp,'10020']
                     or sameas[sp,'10030']
                     or sameas[sp,'10040']
                     or sameas[sp,'10120']
                     or sameas[sp,'13150']
                     or sameas[sp,'20000']
                     or sameas[sp,'21000']
                     or sameas[sp,'25000']
                     or sameas[sp,'36000']
                     or sameas[sp,'37000']
                     or sameas[sp,'38391']
                     or sameas[sp,'38392']
                     or sameas[sp,'45000']
                     or sameas[sp,'46000']
                     or sameas[sp,'47000']
                     or sameas[sp,'49011']
                     or sameas[sp,'49024']
                     or sameas[sp,'49031']
                     or sameas[sp,'50001']
                     or sameas[sp,'51009']
                     or sameas[sp,'55560']
                     or sameas[sp,'64000']
                     or sameas[sp,'71000']
                     or sameas[sp,'10011']
                     or sameas[sp,'10012']
                     or sameas[sp,'10013']
                     or sameas[sp,'49509']
                    #  or plant_sectors_sp[sp]
                    #  or ani_sectors_sp[sp]
                     ) = no;
    
    d1zerojpk[k,sp,t] = not d1flatjpk[k,sp,t];
    
    
    d1flatjpk[k,'23001',t] = no;
    d1zerojpk[k,'23001',t] = no;

    d1flatjpk[k,'51001',t] = no;
    d1zerojpk[k,'51001',t] = no;
    #  d1decayingjpk[k,'51001',t] = yes;

    d1flatjpk[k,'41430',t] = no;
    d1zerojpk[k,'41430',t] = no;

    d1flatjpk[k,'68203',t] = no;
    d1zerojpk[k,'68203',t] = no;

    d1flatjpk[k,'19000',t] = no;
    d1zerojpk[k,'19000',t] = no;

    d1flatjpk[k,'35002',t] = no;
    d1zerojpk[k,'35002',t] = no;

    d1flatjpk[k,'01032',t] = no;
    d1zerojpk[k,'01032',t] = no;

    d1flatjpk[k,'01062',t] = no;
    d1zerojpk[k,'01062',t] = no;


    # d1flatjpk[k,plant_sectors,t] = no;
    # d1zerojpk[k,plant_sectors,t] = no;

    # d1flatjpk[k,'02000',t] = no;
    # d1zerojpk[k,'02000',t] = no;

    #  d1flatjpk[k,ani_sectors_s,t] = no;
    #  d1zerojpk[k,ani_sectors_s,t] = no;


    d1jqI_s[s] = yes$(not sum(k,d1flatjpk[k,s,'2019']) and not sum(k,d1zerojpk[k,s,'2019']) and not sum(k,d1decayingjpk[k,s,'2019']) and not sameas[s,'off']);


    #  d1flatjpk[k,'49509',t] = no;
    #  d1zerojpk[k,'49509',t] = no;



    $GROUP G_production_private_calib
           G_production_private_endo
               jpK$(t2[t] and (d1flatjpk[k,sp,t] or d1zerojpk[k,sp,t]  or d1decayingjpk[k,sp,t])), -qK$(tData[t] and (d1flatjpk[k,s,t] or d1zerojpk[k,s,t] or d1decayingjpk[k,s,t]))
               qK$(sameas(s,'OFF') and t1[t])
               -qI_s$(t1[t] and d1jqI_s[s] and not sameas[i_,'invt']), jqI_s$(t1[t] and d1jqI_s[s]), qK$(t1[t] and d1jqI_s[s])
               -jqI_s$(t1[t] and sameas[s,'01062'] and sameas[k,'it']), jpK$(t2[t] and sameas[sp,'01062'] and sameas[k,'it'])
               -jqI_s$(t1[t] and sameas[s,'01032'] and sameas[k,'it']), jpK$(t2[t] and sameas[sp,'01032'] and sameas[k,'it'])

               pM_CET$(tx1[t] and d1vM_CET[out,s,t] and sameas[out,'out_other'] and sameas[s,'53000'])

               #Cement
               -pY_CET$(tx1[t] and d1vY_CET[out,s,t] and sameas[out,'out_other'] and sameas[s,'23001'])
               markup$(tx1[t] and d1vY_CET[out,s,t] and sameas[out,'out_other'] and sameas[s,'23001'])

               #Øvrig mineralogi
               pM_CET$(tx1[t] and d1vM_CET[out,s,t] and sameas[out,'out_other'] and sameas[s,'23002'])
               pXF$(tx1[t] and sameas[s,'23002'])

               #Fly
               pM_CET$(tx1[t] and d1vM_CET[out,s,t] and sameas[out,'out_other'] and sameas[s,'51001'])
               pXF$(tx1[t] and sameas[s,'51001'])

  ;

    $GROUP G_production_private_calib_exo
            G_production_private_exo
            qK$(tData[t] and (d1flatjpk[k,s,t] or d1zerojpk[k,s,t] or d1decayingjpk[k,s,t])), -jPK$((d1flatjpk[k,sp,t] or d1zerojpk[k,sp,t] or d1decayingjpk[k,sp,t]))
            -qK$(sameas(s,'OFF') and t1[t])
            qI_s$(t1[t] and d1jqI_s[s] and not sameas[i_,'invt']), -jqI_s$(t1[t] and d1jqI_s[s]), -qK$(t1[t] and d1jqI_s[s])
            jqI_s$(t1[t] and sameas[s,'01062'] and sameas[k,'it']), -jpK$(t2[t] and sameas[sp,'01062'] and sameas[k,'it'])
            jqI_s$(t1[t] and sameas[s,'01032'] and sameas[k,'it']), -jpK$(t2[t] and sameas[sp,'01032'] and sameas[k,'it'])

           pY_CET$(tx1[t] and d1vY_CET[out,s,t] and sameas[out,'out_other'] and sameas[s,'23001'])
           -markup$(tx1[t] and d1vY_CET[out,s,t] and sameas[out,'out_other'] and sameas[s,'23001']) 
  ;


$BLOCK B_production_private_calib

    #THIS EQUATION IS SWAPPED IN INTEGRATION_AGR.GMS!!!!!!!!!!!!!!
#      E_jpK[k,sp,t]$(d1K[k,sp,t] and (d1zerojpk[k,sp,t] or d1flatjpk[k,sp,t] or d1decayingjpk[k,sp,t]) and tx1[t] and (t.val > t2.val))..
#          #  jpK[k,sp,t]=E= jpK[k,sp,t-1]$(not sameas[sp,'68203']) + jpK[k,sp,t-1]$(sameas[sp,'68203']);
#          jpK[k,sp,t]=E= jpK[k,sp,t-1]$(not (d1zerojpk[k,sp,t])) 
#                       + 0$(d1zerojpk[k,sp,t])
#                       + 0.8*jpK[k,sp,t-1]$(d1decayingjpk[k,sp,t]);

    E_pM_CET_53000[t]$(tx1[t])..
        pM_CET['out_other','53000',t] =E=  pM_CET['out_other','53000',t1];
    
    #Øvrig mineralogi
    E_pM_CET_oevrigmineralogi[t]$(tx1[t])..
        pM_CET['out_other','23002',t] =E=  pY_CET['out_other','23002',t];


    E_pXF_CET_oevrigmineralogi[t]$(tx1[t])..
        pXF['23002',t] =E=  pY_CET['out_other','23002',t];

    #Indenrigsflyvning (som eksporterer...)

    E_pM_CET_indenrigsfly[t]$(tx1[t])..
        pM_CET['out_other','51001',t] =E= pY_CET['out_other','51001',t];

    E_pXF_CET_indenrigsfly[t]$(tx1[t])..
        pXF['51001',t] =E= pY_CET['out_other','51001',t];



$ENDBLOCK
    
    jqI_s.l[k,s,tForecast]          = 0;
    markup.l[out,'02000',tForecast] = 0;
    markup.l[out,'02000','2020']    = 0.5 * markup.l[out,'02000','2019'];
    #  markup.l[out,'23001',tForecast] = 0;
    markup.l[out,'23002',tForecast] = 0;
    markup.l[out,'49509',tForecast] = 0;
    loop(t$(tForecast[t]), markup.l[out,'41430',t] = 0.8*markup.l[out,'41430',t-1]);
    loop(t$(tForecast[t]), markup.l[out,'53000',t] = 0.8*markup.l[out,'53000',t-1]);
    markup.l[out,'off',tForecast] = 0;
    #  loop(t$(tForecast[t]), markup.l[out,'68203',t] = 0.8*markup.l[out,'68203',t-1]);
    fKInstCost.l[k,s,tForecast]     = fq;

    $MODEL M_production_private_calib
    M_production_private
    B_production_private_calib
    ;
$ENDIF
