# ======================================================================================================================
# Production
# ======================================================================================================================
# Demand for production and factors

# ======================================================================================================================
# Variable definition
# ======================================================================================================================

$IF %stage% == "variables":

  $GROUP G_production_public_prices 
      pk_trans_off[t]                         "User cost of public transport capital"
      pGovDepr[k_,t]                          "Deflator of government depreciations"
      pR[t]                                   "Price of material inputs  (Energy plus non-energy)"
      pE_CGE[s,t]                             "CES price of qE aggregate"
  ;    


  $GROUP G_production_public_quantities
     qGovDepr[k_,t]                          "Public depreciation (Afskrivninger (bruttorestindkomst))"
     qR[t]                                   "Material input in sector s (Energy plus non-energy)"
      qE[s,t]
   ;


  $GROUP G_production_public_values
      vGovDepr[k_,t]                          "Public depreciation (Afskrivninger (bruttorestindkomst))"
      vLR_pub[t]                              "Value of labor and material costs in public sector - excl. production taxes"
      vI_pub_direct[t]                        "Input from public production to investments in R&D"
      uEP_off[purpose,t]                      ""
  ;


  $GROUP G_production_public_other
    eR                                      "Elasticity of substitution between the qRxE and qE, public production "
    svI_pub_direct2GDP[t]                 "Share of direct public investments out of total GrossValAdd"
    fqGovDepr[k,t]                         "Factor reflecting differences in prices of investments and depreciations"
    fpGovDepr[k,t]                         "Factor reflecting differences in prices of investments and depreciations"
    R2LR_pub[t]                            "Materials expenditure share of labor and materials"
    uEOFF[t]                              "Scale parameter for qE in split of qR in public production" 
    uRxEOFF[t]                            "Scale parameter for qRxE in split of qR in public production"
    j_pKELBM_off_markup[t]                "Calibration term in public sector to calibrate zero markup"
  ;

$ENDIF

$IF %stage% == "groupcompilation":

# ======================================================================================================================
# Compiling groups of endogenous and exogenous values
# ======================================================================================================================
    
    $GROUP G_production_public_endo 
        qY_CETgross$(sameas(s,'off')) # E_qY_CETgross_off
        pY0_CET$(d1vY_CET[out,s,t] and sameas(s,'off')) # E_pY_CET0_off
        qY$(sameas(s_,'off')) # E_qY_off
        pY_CET$(d1vY_CET[out,s,t] and sameas(s,'off')) # E_pY_CET_off
        vY$(sameas(s_,'off')) # E_vY_off
        pY$(sameas(s_,'off'))  # E_pY_off
        qKELBM$(sameas(s,'off')) # E_qKELBM_off
        pY0$(sameas(s,'off')) # E_pY0_off
        pE_CGE$(sameas(s,'off')) # E_pE_CGE_off
        qEP$(sameas(s,'off') and d1EP[purpose,s,t]) # E_qEP_off 
        pEP$(sameas(s,'off') and d1EP[purpose,s,t]) # E_pEP_off
        qREa$(sameas(s,'off') and d1pREa[purpose,energy19a,s,t]) # E_qREa_off 

        # E_pREa_off
        pREa$(sameas(s,'off') and d1pREa[purpose,energy19a,s,t]) 
        -pREa$(sameas(s,'off'))
        pREa$(tx0[t] and d1pREa[purpose,energy19a,s,t] and not (sum(techID, d1thetaID_k[techID,purpose,energy19a,s,t]) or sum(techCCS, sum(emm, d1thetaCCS[techCCS,purpose,energy19a,s,t,emm])) or sum(energy19,d1vREE_transport[purpose,energy19a,energy19,s,t])))
        j_pREa$(tx0[t] and d1pREa[purpose,energy19a,s,t] and (sum(techID, d1thetaID_k[techID,purpose,energy19a,s,t]) or sum(techCCS, sum(emm, d1thetaCCS[techCCS,purpose,energy19a,s,t,emm])) or sum(energy19,d1vREE_transport[purpose,energy19a,energy19,s,t])))

        # E_qI_s_off E_qI_s_inv_off
        qI_s$(sameas(s,'off') and sameas(i_,'invt') and d1I_s[i_,s,t]) 
        qK$(d1K[k,s,t] and sameas(s,'OFF'))

        qKInstCost$(sameas(s,'off') and d1K[k_,s,t]) # E_qKInstCost_off
        vREa$(sameas(s,'off') and d1pREa[purpose,energy19a,s,t]) # E_vREa_off
        vGrossValAdd$(tx0[t] and sameas(s_,'off')) # E_vGrossValAdd 
        vI_pub_direct # E_vI_pub_direct
        pGovDepr # E_pGovDepr
        qGovDepr # E_qGovDepr
        vGovDepr # E_vGovDepr
        vLR_pub # E_vLR_pub
        qR # E_qR_pub
        qL$(sameas(s_,'off')) # E_qL_pub 
        qE$(sameas(s,'off')) # E_qEOFF
        qRxE$(sameas(r_,'off')) # E_qRxEOFF
        pR # E_pR
        pKELBM$(sameas(s,'off')) # E_pKELBM_pub 
        pk_trans_off # E_pK_trans_off
    ;

    $GROUP G_production_public_endo G_production_public_endo$(tx0[t]);


    $GROUP G_production_public_non_flat_initial_values_from_MAKRO
        prod_s # Only public sector productivity is from MAKRO
        qI_s$(sameas(s,'OFF') and not sameas(i_,'invt'))
    ;

    $GROUP G_production_public_exo         
        G_production_public_other
        # E_qY_CETgross_off
        qY_CET$(tx0[t] and d1vY_CET[out,s,t] and sameas(s,'off'))
        qREgj$(tx0[t] and d1pREown[purpose,energy19,r,t] and sameas(r,'off'))

        # E_pY_CET0_off
        uY_CET$(tx0[t] and d1vY_CET[out,s,t] and sameas(s,'off'))
        eCET$(sameas(s,'off'))
        
        # E_pY_CET_off
        markup$(tx0[t] and d1vY_CET[out,s,t] and sameas(s,'off'))

        # E_pY0_off
        vtNetProductionRest$(tx0[t] and sameas(s_,'off'))
        vtBotDed$(tx0[t] and sameas(s,'off'))
        vtCO2_ETSxE_marg$(tx0[t] and sameas(r,'off') and d1EmmProdxE[r,t,'CO2e'] and d1CO2_ETS[r,t])
        pREa$(tx0[t] and sameas(s,'off') and d1pREa[purpose,energy19a,s,t] and eNotInEnergyNest[purpose,energy19a,s,t])
        qREa$(tx0[t] and sameas(s,'off') and d1pREa[purpose,energy19a,s,t] and eNotInEnergyNest[purpose,energy19a,s,t])
        vtVAT_RE$(tx0[t] and sameas(r,'off') and d1VAT_RE[purpose,energy19,r,t])
        vtCO2_ProdxE$(tx0[t] and sameas(s,'off') and d1EmmProdxE[s,t,emm] and d1CO2_ProdxE[s,t,emm])
        qLEVC_CCS_EmmxE$(tx0[t] and sameas(s,'off') and d1EmmProdxE[s,t,emm] and sum(techCCS, d1thetaCCSxE[techCCS,s,t,emm]) and sameas[emm,'CO2ubio'])
        pI_s$(tx0[t] and sameas(s,'off') and sameas(i_,'iM'))
        vSubsidy_CCS_EmmxE$(tx0[t] and sameas(s,'off') and d1EmmProdxE[s,t,emm] and sum(techCCS, d1thetaCCSxE[techCCS,s,t,emm]) and sameas[emm,'CO2ubio'])
        pRE_base$(tx0[t] and sameas(r,'off') and d1pRE_base[purpose,energy19,r,t])
        pRE_base_marg$(tx0[t])
        qREgj$(tx0[t] and sameas(r,'off') and d1pRE_base[purpose,energy19,r,t])
        
        # E_qEP_off
        uEP_off$(tx0(t))
        eREP$(sameas(s,'off'))

        # E_qREa_off
        uRE$(tx0[t] and sameas(s,'off') and d1pREa[purpose,energy19a,s,t] and not eNotInEnergyNest[purpose,energy19a,s,t])
        eRE$(sameas(s,'off'))

        # E_pREa_off
        pREgj$(tx0[t] and sameas(r,'off') and d1pREa[purpose,energy19,r,t] and d1pREgj[purpose,energy19,r,t])
        j_pREa$(tx0[t] and sameas(s,'off') and d1pREa[purpose,energy19a,'off',t])
        -j_pREa
        pREa$(tx0[t] and d1pREa[purpose,energy19a,s,t] and (sum(techID, d1thetaID_k[techID,purpose,energy19a,s,t]) or sum(techCCS, sum(emm, d1thetaCCS[techCCS,purpose,energy19a,s,t,emm])) or sum(energy19,d1vREE_transport[purpose,energy19a,energy19,s,t])))
        j_pREa$(tx0[t] and d1pREa[purpose,energy19a,s,t] and not (sum(techID, d1thetaID_k[techID,purpose,energy19a,s,t]) or sum(techCCS, sum(emm, d1thetaCCS[techCCS,purpose,energy19a,s,t,emm])) or sum(energy19,d1vREE_transport[purpose,energy19a,energy19,s,t])))

        # E_qI_s_off E_qI_s_inv_off
        qI_s$(tx0[t] and sameas[s,'off'] and not sameas[i_,'invt'] and d1I_s[i_,s,t]) #Public sector investments are determinded by exogenous path by FM
        qK$(t0[t] and sameas(s,'off') and d1K[k,s,t])
        rDepr$(tx0[t] and sameas(s,'off') and d1K[k,s,t])
        jqI_s$(tx0[t] and sameas(s,'off') and d1K[k,s,t])
        pI_s$(t0[t] and sameas(i_,'invt') and sameas(s,'off') and d1I_s[i_,s,t])
        rIL$(tx0[t] and sameas(s,'off'))
        pY$(t0[t] and sameas(s_,'off'))

        # E_qKInstCost_off
        uKInstCost$(tx0[t] and sameas(s,'off') and d1K[k,s,t])
        qI_s$(t0[t] and sameas(s,'off') and d1K[i_,s,t])
        fKInstCost$(tx0[t] and sameas(s,'off') and d1K[k,s,t])

        # E_vREa_off
        tvREmarg$(tx0[t] and sameas(r,'off') and d1pREa[purpose,energy19,r,t] and d1pREown[purpose,energy19,r,t]) 
        pREown$(tx0[t] and sameas(r,'off') and d1pREown[purpose,energy19,r,t])
        pREgj$(tx0[t] and sameas(r,'off') and d1pREown[purpose,energy19,r,t])
        
        # E_vGrossValAdd
        vtEAFG_RE$(tx0[t] and sameas(r,'off') and d1EAFG_RE[purpose,energy19,r,t])
        vtEAFG_REmarg$(tx0[t] and sameas(r,'off') and d1EAFG_RE[purpose,energy19,r,t])
        vtCO2_RE$(tx0[t] and sameas(r,'off') and d1CO2_RE[purpose,energy19,r,t])
        vtCO2_REmarg$(tx0[t] and sameas(r,'off') and d1CO2_RE[purpose,energy19,r,t])
        vRxE
        vtCO2_ETS_marg$(tx0[t] and sameas(r,'off') and d1CO2_ETS[r,t])
        vFin$(tx0[t] and sameas(r,'off'))
        qREgj$(tx0[t] and sameas(r,'off') and d1pRE_base[purpose,energy19,r,t])
        tCALIBENS$(tx0[t] and sameas(r,'off') and d1tRE[purpose,energy19,r,t])

        # E_vI_pub_direct
        svI_pub_direct2GDP$(tx0(t))
        vGDP$(tx0(t))

        # E_pGovDepr
        fpGovDepr$(tx0(t))
        pI_s$(tx0[t] and sameas(s,'off'))
        
        # E_qGovDepr
        fqGovDepr$(tx0(t))
        pGovDepr$(t0[t])

        # E_qR_pub
        R2LR_pub$(tx0(t))
        
        # E_qL_pub
        w$(tx0(t))

        # E_qEOFF
        uEOFF$(tx0(t))
        eR$(tx0(t))

        # E_qRxEOFF
        uRxEOFF$(tx0(t))
        pRxE$(tx0[t] and sameas(r_,'off'))

        # E_pKELBM_pub
        pKELBM$(t0[t] and sameas(s,'off'))
        pR$(t0[t])
        prod_s$(tx0[t] and sameas(s,'off'))
        prod_s$(t0[t] and sameas(s,'off'))
        w$(t0[t])

        # E_pK_trans_off
        pK_trans_off$(t1[t])
        pI_s$(tx0[t] and sameas(s,'off') and sameas(i_,'iT'))
    ;


    $GROUP G_production_public_data
        vGovDepr
        pGovDepr
        qGovDepr
    ;

$ENDIF

# ======================================================================================================================
# Equations
# ======================================================================================================================
$IF %stage% == "equations":

    $BLOCK B_production_public
        # ------------------------------------------------------------------------------------------------------------------
        # CET-transformation of output
        # ------------------------------------------------------------------------------------------------------------------

        # For consumption of own-produced energy-good we introduce the following two equations.qY_CETgross is production incl. production for own-consumption
        E_qY_CETgross_e19_off[energy19,t]$(tx0[t] and d1vY_CET[energy19,'off',t]).. qY_CETgross[energy19,'off',t] =E= qY_CET[energy19,'off',t] + sum((purpose,r)$(d1pREown[purpose,energy19,r,t] and mapownproduction(energy19,r,'off')), qREgj[purpose,energy19,r,t]); 
     
        E_qY_CETgross_oth_off[t]$(tx0[t] and d1vY_CET['out_other','off',t])..    qY_CETgross['out_other','off',t] =E= qY_CET['out_other','off',t];
     

        E_qY_CETgross_WholeAndRetailSaleMarginE_off[t]$(tx0[t] and d1vY_CET['WholeAndRetailSaleMarginE','off',t])..
                                                                          qY_CETgross['WholeAndRetailSaleMarginE','off',t] =E= qY_CET['WholeAndRetailSaleMarginE','off',t];

        E_pY_CET0_off[out,t]$(tx0[t] and d1vY_CET[out,'off',t]).. qY_CETgross[out,'off',t] =E= uY_CET[out,'off',t] * (pY0_CET[out,'off',t]/pY0['off',t])**eCET['off'] *qY['off',t];  


        E_qY_off[t]$(tx0[t])..    pY0['off',t]*qY['off',t] =E= sum(out$d1vY_CET[out,'off',t], pY0_CET[out,'off',t] * qY_CETgross[out,'off',t]);            

        E_pY_CET_off[out,t]$(tx0[t] and d1vY_CET[out,'off',t]).. pY_CET[out,'off',t] =E= (1+markup[out,'off',t]) * pY0_CET[out,'off',t];     

        #"Average" output-price is computed (£AKB: Is marginally poluted by the crossing of qY being including production for own-consumption.)
        E_vY_off[t]$(tx0[t])..               vY['off',t]               =E= sum(out$d1vY_CET[out,'off',t], pY_CET[out,'off',t] * qY_CET[out,'off',t]);
                                                                    #  +sum(out$d1vY_CET[out,s,t], pY_CET[out,s,t] * qY_CETgross[out,s,t])$(sameas[s,'19000']) #For refineries own-consumption of refinery-gas is recorded in National Accounts and hence should be included in computation of NA-value
                                                                    #  +  (pY_ElNL[t]*qY_ElNl[t])$(sameas[s,'35011'] and t.val <= 2019) #Revenue from Ørsteds joint venture (ended after 2019) 
                                                                    #  +  (pWoodproduct_markup[t]*qD_usewood_CGE[t])$(sameas[s,'02000']) #Revenue from woodproduct mark-up
                                                                    #  +  (pXE_bionatgas[t] * qXE_bionatgas[t])$(sameas[s,'35002']); 

        E_pY_off[t]$(tx0[t])..               vY['off',t] =E= pY['off',t] * qY['off',t];
                            

        # ------------------------------------------------------------------------------------------------------------------
        # Gross production from net production
        # ------------------------------------------------------------------------------------------------------------------

        E_qKELBM_off[t]$(tx0[t])..  qKELBM['off',t] =E= qY['off',t] + sum(k$d1K[k,'off',t], qKInstCost[k,'off',t]);
         

        E_pY0_off[t]$(tx0[t])..      pY0['off',t] * qY['off',t] =E= pKELBM['off',t] * qY['off',t] 
                                                         + vtNetProductionRest['off',t]
                                                         + vtCAP_top['off',t]$(agri_sectors_s['off'])
                                                        #Basic deduction (Bundfradrag) on energy, incl. basic deduction from free quotas (gratiskvoter) in ETS
                                                         + vtBotDed['off',t]#$(not sameas[s,'51001']) #Vi lader ikke indenrigsluftfarten indprise deres bundfradrag i endelig pris
                                                         + vtCO2_ETSxE_marg['off',t]$(d1EmmProdxE['off',t,'CO2e'] and d1CO2_ETS['off',t])
                                                         + sum((purpose,energy19)$(d1pREa[purpose,energy19,'off',t] and eNotInEnergyNest[purpose,energy19,'off',t]), pREa[purpose,energy19,'off',t]*qREa[purpose,energy19,'off',t])
                                                         + sum((purpose,energy19)$(d1VAT_RE[purpose,energy19,'off',t]), vtVAT_RE[purpose,energy19,'off',t])
                                                         #  + (pRE_NatGasNL[t]*qRE_NatGasNL[t])$(sameas[s,'35011'] and t.val <= 2019)
                                                         + sum(emm$(d1EmmProdxE['off',t,emm] and d1CO2_ProdxE['off',t,emm]), vtCO2_ProdxE['off',t,emm])                         # CO2e-tax on non-energy related emissions
                                                         + sum(emm$(d1EmmProdxE['off',t,emm] and sum(techCCS, d1thetaCCSxE[techCCS,'off',t,emm]) and sameas[emm,'CO2ubio']),   
                                                                                                                   + qLEVC_CCS_EmmxE['off',t,emm]*pI_s['iM','off',t]        # LEVC on non-energy related CCS
                                                                                                                   - vSubsidy_CCS_EmmxE['off',t,emm])                  # Subsidy to non-energy related CCS
                                                         + sum((purpose,energy19)$(d1pRE_base[purpose,energy19,'off',t]),(pRE_base[purpose,energy19,'off',t]-pRE_base_marg[purpose,energy19,'off',t])*qREgj[purpose,energy19,'off',t])
                                                        #  - sum((purpose,energy19)$(d1tRE[purpose,energy19,s,t]), vtCalibENS[purpose,energy19,s,t])
                                                        ;
    
        # ------------------------------------------------------------------------------------------------------------------
        # 6) Split of machine-aggregate onto machine-capital, financial services for machine-capital and energy for machine-capital
        # ------------------------------------------------------------------------------------------------------------------

        #Demand for public sector energy is in equation E_qEOFF
        E_pE_CGE_off[t]$(tx0[t] and d1E['off',t]).. pE_CGE['off',t] * qE['off',t] =E= sum(purpose$(d1EP[purpose,'off',t]), pEP[purpose,'off',t] * qEP[purpose,'off',t]); 

        # ------------------------------------------------------------------------------------------------------------------
        # 7) Split of energy into energy type and purpose (for all purposes except transport)
        # ------------------------------------------------------------------------------------------------------------------

        E_qEP_off[purpose,t]$(tx0[t] and d1EP[purpose,'off',t] )..   qEP[purpose,'off',t] =E= uEP_off[purpose,t] * (pEP[purpose,'off',t]/pE_CGE['off',t]) **(-eREP['off']) * qE['off',t];

        E_pEP_off[purpose,t]$(tx0[t] and d1EP[purpose,'off',t]).. 
          pEP[purpose,'off',t]*qEP[purpose,'off',t] =E= sum(energy19$(d1pREa[purpose,energy19,'off',t] and not eNotInEnergyNest[purpose,energy19,'off',t]), pREa[purpose,energy19,'off',t] * qREa[purpose,energy19,'off',t]);

        E_qREa_off[purpose,energy19a,t]$(tx0[t] and d1pREa[purpose,energy19a,'off',t] and not eNotInEnergyNest[purpose,energy19a,'off',t]).. 
          qREa[purpose,energy19a,'off',t] =E= uRE[purpose,energy19a,'off',t] * (pREa[purpose,energy19a,'off',t]/pEP[purpose,'off',t]) **(-eRE[purpose,'off']) * qEP[purpose,'off',t];

        E_pREa_off[purpose,energy19a,t]$(tx0[t] and d1pREa[purpose,energy19a,'off',t]).. 
          pREa[purpose,energy19a,'off',t] =E= pREgj[purpose,energy19a,'off',t]$(d1pREgj[purpose,energy19a,'off',t]) 
                                        + j_pREa[purpose,energy19a,'off',t]$(sum(techID, d1thetaID_k[techID,purpose,energy19a,'off',t]) or sum((techCCS,emm), d1thetaCCS[techCCS,purpose,energy19a,'off',t,emm]) or sum(energy19,d1vREE_transport[purpose,energy19a,energy19,'off',t]));

        # ------------------------------------------------------------------------------------------------------------------
        # Cost of capital
        # ------------------------------------------------------------------------------------------------------------------

        E_qI_s_off[k,t]$(tx0[t] and d1K[k,'off',t]).. qI_s[k,'off',t] =E= qK[k,'off',t] - (1 - rDepr[k,'off',t]) * qK[k,'off',t-1]/fq + jqI_s[k,'off',t];


        E_qI_s_inv_off[t]$(tx0[t] and d1I_s['invt','off',t])..      
          qI_s['invt','off',t] * pI_s['invt','off',t-1] =E= rIL['off',t] * pY['off',t-1] * qY['off',t];

        # ------------------------------------------------------------------------------------------------------------------
        # Installation costs
        # ------------------------------------------------------------------------------------------------------------------
        
        # Aggregate lost production from installation costs
        E_qKInstCost_kTot_off[t]$(tx0[t] and d1K['iTot','off',t]).. qKInstCost['iTot','off',t] =E= sum(k$d1K[k,'off',t], qKInstCost[k,'off',t]);

        E_qKInstCost_off[k,t]$(tx0[t] and d1K[k,'off',t])..        
          qKInstCost[k,'off',t] =E= uKInstCost[k,'off',t]/2 * sqr(qI_s[k,'off',t] - qI_s[k,'off',t-1]/fq * fKInstCost[k,'off',t]) /(qK[k,'off',t-1]/fq); 

        # ------------------------------------------------------------------------------------------------------------------
        # From finance
        # ------------------------------------------------------------------------------------------------------------------


        E_vREa_off[purpose,energy19,t]$(tx0[t] and d1pREa[purpose,energy19,'off',t]).. vREa[purpose,energy19,'off',t] =E= pREa[purpose,energy19,'off',t] * qREa[purpose,energy19,'off',t]  
                                                                                                              -(pREgj[purpose,energy19,'off',t] * qREgj[purpose,energy19,'off',t])$(d1pREown[purpose,energy19,'off',t]) #In the event that own-consumption is taxed it will enter GVA, we therefore substract and add only tax-component. 
                                                                                                              +(tvREmarg[purpose,energy19,'off',t] * pREown[purpose,energy19,'off',t] * qREgj[purpose,energy19,'off',t] )$(d1pREown[purpose,energy19,'off',t] and d1tRE[purpose,energy19,'off',t]);

        E_vGrossValAdd_off[t]$(tx0[t]).. vGrossValAdd['off',t] =E= vY['off',t] - vRxE['off',t] #Non-energy materials
                                                                     - vFin['off',t] #Financial services 
                                                                     - sum(emm$(d1EmmProdxE['off',t,emm] and d1CO2_ProdxE['off',t,emm]),  vtCO2_ProdxE['off',t,emm]) # CO2e-tax on non-energy related emissions
                                                                     # The aggregated value of the energy commodity including capital costs for abatement and CCS
                                                                     - sum((purpose,energy19a), vREa[purpose,energy19a,'off',t]$(d1pREa[purpose,energy19a,'off',t]) 
                                                                     # Adjustment of taxes to reflect the average tax rate (gennemsnitsafgiftssatsen) (vRE reflects the marginal tax rate)
                                                                        + (+vtEAFG_RE[purpose,energy19a,'off',t]$(d1EAFG_RE[purpose,energy19a,'off',t]) 
                                                                           -vtEAFG_REmarg[purpose,energy19a,'off',t]$(d1EAFG_RE[purpose,energy19a,'off',t])
                                                                           +vtCO2_RE[purpose,energy19a,'off',t]$(d1CO2_RE[purpose,energy19a,'off',t])
                                                                           -vtCO2_REmarg[purpose,energy19a,'off',t]$(d1CO2_RE[purpose,energy19a,'off',t])
                                                                           -vtCO2_ETS_marg[energy19a,'off',t]$(d1tCO2_ETS_marg[purpose,energy19a,'off',t])
                                                                           -vtCO2_ETS2_marg[purpose,energy19a,'off',t]$(d1CO2_ETS2_marg[purpose,energy19a,'off',t])
                                                                           +vtVAT_RE[purpose,energy19a,'off',t]$(d1VAT_RE[purpose,energy19a,'off',t])) 
                                                                           #We only deduct marginal ETS payments, as ETS is not part of GVA in the National Accounts definition
                                                                        # Deduct capital costs for ID abatement and energy-related CCS (because they are included in vRE)
                                                                        - sum(techID$(d1thetaID_k[techID,purpose,energy19a,'off',t]), rID_actual[techID,purpose,energy19a,'off',t] * thetaID_KMean[techID,purpose,energy19a,'off',t]*sum(energy19$(d1thetaID[techID,purpose,energy19a,energy19,'off',t] and sameas(energy19,energy19a)),-thetaID[techID,purpose,energy19a,energy19,'off',t]) * pI_s['iM','off',t])
                                                                        - pCCS_qRE['off',energy19a,purpose,t]*qREa[purpose,energy19a,'off',t]$(d1pREa[purpose,energy19a,'off',t] and sum((techCCS,emm), d1thetaCCS[techCCS,purpose,energy19a,'off',t,emm]))                 
                                                                             )
                                                                   #When deducting vREa (above) we subtract marginal prices. Here we add the marginal prices back, and subtract the average prices.
                                                                     + sum((purpose,energy19a)$(d1pRE_base[purpose,energy19a,'off',t]),(pRE_base_marg[purpose,energy19a,'off',t]-pRE_base[purpose,energy19a,'off',t])*qREgj[purpose,energy19a,'off',t])
                                                                     # Ørsted join-venture in the Netherlands. Ended in 2019
                                                                     #  - (pRE_NatGasNL[t]*qRE_NatGasNL[t])$(sameas[s,'35011'] and t.val <= 2019)
                                                                     # Technology costs (Tekologiomkostninger)
                                                                     - sum((ani_sectors,ss)$(map_anisectors2s(Ani_sectors,'off') and sum((Emmtype,animals),d1vEOPCostAni[Emmtype,ani_sectors,'off',animals,t])), vRxEEOP_ani[ani_sectors,'off',t])
                                                                     - sum((plant_sectors,ss)$(map_plantsectors2s(plant_sectors,'off') and sum(Emmtype,d1vEOPCostplant[Emmtype,plant_sectors,'off',t])), vRxEEOP_plant[plant_sectors,'off',t])
                                                                     + sum((purpose,energy19)$(d1tRE[purpose,energy19,'off',t]), tCALIBENS[purpose,energy19,'off',t]*qREgj[purpose,energy19,'off',t]) #LBS: Her er jeg i tvivl
                                                                     - (sum((energy19,purpose)$(d1vLE[purpose,energy19,t] and not tDataEnd[t]), vLE[purpose,energy19,t])* vY['off',t] /sum(TheBig7, vY[TheBig7,t]))$(TheBig7['off'])
                                                                    ;    
    

        # Public direct investments and purchases of existing capital follow gross value added (BVT)
        E_vI_pub_direct[t]$(tx0[t]).. vI_pub_direct[t] =E= svI_pub_direct2GDP[t] * vGDP[t]; 


    # ------------------------------------------------------------------------------------------------------------------------
    # Public production
    # ------------------------------------------------------------------------------------------------------------------------
      # Prince, quantity, and value of public depriciations (afskrivninger) - Equivalent to gross income as no markup is assumed in the public sector
       E_pGovDepr[k,t]$(tx0[t] and d1K[k,'OFF',t])..       
          pGovDepr[k,t] =E= fpGovDepr[k,t] * pI_s[k,'OFF',t];

       E_qGovDepr[k,t]$(tx0[t] and d1K[k,'OFF',t])..       
          qGovDepr[k,t] =E= fqGovDepr[k,t] * rDepr[k,'OFF',t] * qK[k,'OFF',t-1]/fq;

       E_vGovDepr[k,t]$(tx0[t] and d1K[k,'OFF',t])..       
          vGovDepr[k,t] =E= pGovDepr[k,t] * qGovDepr[k,t];

       E_vGovDepr_tot[t]$(tx0[t])..       
          vGovDepr['itot',t] =E= sum(k,vGovDepr[k,t]);

       E_qGovDepr_tot[t]$(tx0[t])..       
          qGovDepr['itot',t] * pGovDepr['itot',t-1]/fp =E= sum(k,pGovDepr[k,t-1]/fp * qGovDepr[k,t]);

       E_pGovDepr_tot[t]$(tx0[t])..       
          pGovDepr['itot',t] * qGovDepr['itot',t] =E= vGovDepr['itot',t];

        # Public production is satisfied by capital (measured by depreciation), labor, and material inputs (energy and non-energy)
        # Capital is exogenously determined by the accumulation equation, while labor and materials are determined by fixed shares to achieve production

      #Production goals excl. depreciations in value
        E_vLR_pub[t]$(tx0[t]).. 
          vLR_pub[t] =E= qY['OFF',t] * pKELBM['OFF',t] - vGovDepr['itot',t];

      # Input of materials (energy and non-energy) and labor are assumed to be constant shares of the production value after depreciation is subtracted 
        E_qR_pub[t]$(tx0[t]).. 
          qR[t] * pR[t] =E= R2LR_pub[t] * vLR_pub[t]; 

       E_qL_pub[t]$(tx0[t]).. 
          qL['OFF',t] * w[t] =E= (1-R2LR_pub[t]) * vLR_pub[t]; 

    # Splits the total material input into energy and non-energy
        E_qEOFF[t]$(tx0[t]).. qE['OFF',t] =E= uEOFF[t] * (pE_CGE['OFF',t]/pR[t])**(-eR)  * qR[t];

        E_qRxEOFF[t]$(tx0[t])..  qRxE['OFF',t]  =E= uRxEOFF[t]  * (pRxE['OFF',t]/pR[t])**(-eR) * qR[t];

        E_pR[t]$(tx0[t]).. pR[t] * qR[t] =E= pE_CGE['OFF',t] * qE['OFF',t] + pRxE['OFF',t] * qRxE['OFF',t];
     
    #Chain price index (Kædeprisindeks) - the cost-minimizing price - based on inputs and their price
     E_pKELBM_pub[t]$(tx0[t])..          
       pKELBM['OFF',t] =E= pKELBM['OFF',t-1]/fp *
                          (pGovDepr['itot',t] * qGovDepr['itot',t] + pR[t]*qR[t] + w[t]*qL['OFF',t])
                         / (pGovDepr['itot',t-1]/fp * qGovDepr['itot',t] + pR[t-1]/fp * qR[t] 
                           + ( prod_s['OFF',t]/prod_s['OFF',t-1] * w[t-1]/fv * qL['OFF',t]))
                          + j_pKELBM_off_markup[t];

     # User cost of public transport capital   
        E_pK_trans_off[t]$(tx0E[t])..
            pK_trans_off[t+1]*fp =E= pI_s["iT","off",t]-(1-rDepr["iT","off",t+1])*pI_s["iT","off",t+1]*fp;

    $ENDBLOCK

    $MODEL M_production_public
        B_production_public
    ;

$ENDIF


$IF %stage% == "exogenous_values":
    # ======================================================================================================================
    # Exogenous variables and data assignment
    # ======================================================================================================================

    #1) READ DATA 
    vLR_pub.l[t] = io_vL['OFF',t] + io_vRxE['OFF',t] + io_vRE['OFF',t];

    #From External Forecast

    ExtFor_pOffAfskr('iT',t) = ExtFor_pOffAfskr('iM',t);
    ExtFor_vOffAfskr('iT',t)$(t.val <=2014) =  ExtFor_vOffAfskr('iM',t) * IO_vK['iT','off','2014']/(IO_vK['iM','off','2014'] + IO_vK['iT','off','2014']);
    ExtFor_vOffAfskr('iM',t)$(t.val <=2014) =  ExtFor_vOffAfskr('iM',t) * IO_vK['iM','off','2014']/(IO_vK['iM','off','2014'] + IO_vK['iT','off','2014']);

    ExtFor_vOffAfskr('iT',t)$((t.val >=2014 and t.val <=2019)) =  ExtFor_vOffAfskr('iM',t) * IO_vK['iT','off',t]/(IO_vK['iM','off',t] + IO_vK['iT','off',t]);
    ExtFor_vOffAfskr('iM',t)$((t.val >=2014 and t.val <=2019)) =  ExtFor_vOffAfskr('iM',t) * IO_vK['iM','off',t]/(IO_vK['iM','off',t] + IO_vK['iT','off',t]);

    ExtFor_vOffAfskr('iT',t)$(t.val >2019) =  ExtFor_vOffAfskr('iM',t) * IO_vK['iT','off','2019']/(IO_vK['iM','off','2019'] + IO_vK['iT','off','2019']);
    ExtFor_vOffAfskr('iM',t)$(t.val >2019) =  ExtFor_vOffAfskr('iM',t) * IO_vK['iM','off','2019']/(IO_vK['iM','off','2019'] + IO_vK['iT','off','2019']); 

    pGovDepr.l[k_,t] = ExtFor_pOffAfskr(k_,t)/ExtFor_pOffAfskr(k_,'2019')/inf_factor[t];
    vGovDepr.l[k_,t] = ExtFor_vOffAfskr(k_,t)/MAKRO_inf_growth_factor[t];
    qGovDepr.l[k_,t]$pGovDepr.l[k_,t] = vGovDepr.l[k_,t]/pGovDepr.l[k_,t];

    #£AKB: Måske noget der skal tjekkes her ift. MAKRO. Det lader ikke til at afskrivningerne i Makro summer til totalen længere?? Hvorfor vi selv bliver nødt til at bygge totalen i værdi, samt korresponderende p/q for ikke at få dataafvigelse, som igen spiller over i det off. forbrug
    loop(t$(tData[t]),
    vGovDepr.l['itot',t] = sum(k, vGovDepr.l[k,t]);
    qGovDepr.l['itot',t]$(pGovDepr.l['itot',t-1]) = sum(k,pGovDepr.l[k,t-1] * qGovDepr.l[k,t])/pGovDepr.l['itot',t-1];
    pGovDepr.l['itot',t]$(qGovDepr.l['itot',t])   = vGovDepr.l['itot',t]/qGovDepr.l['itot',t];
    );


    vI_pub_direct.l[t] = ExtFor_vOffDirInv[t]/MAKRO_inf_growth_factor[t];

    #2) EXOGENOUS VALUES 

        eR.l = 0.5; #The remaining elasticities in the public sector are set close to 1 (based on the idea that they are close to budget shares). Why should it be different for energy?


    
#4) INITIAL VALUES 

    pR.l[t] = 1;
    pE_CGE.l[s,tData]  = 1;

    qR.l[t] = (pRxE.l['OFF',t] * qRxE.l['OFF',t] + pE_CGE.l['OFF',t] * qE.l['OFF',t])/pR.l[t];

    rDepr.l[k,'off',tData] = 0.05;

$ENDIF

# ======================================================================================================================
# Static calibration
# ======================================================================================================================
$IF %stage% == "static_calibration":
    
    $BLOCK B_production_public_static_calibration
       $LOOP E_pK_trans_off:
          {name}_t0{sets}$(t0[t])..
              {LHS} =E= {RHS};
      $ENDLOOP

    E_markup_off[out,t]$(tx0[t] and d1vY_CET[out,'off',t])..
        markup[out,'off',t] =E= markup_cali['off',t];

    E_rDepr_off[k,t]$(tx0[t] and d1K[k,'off',t])..
	        rDepr[k,'off',t] =E= rDepr_static[k,'off',t];

  
    E_sE[t]$(tx0[t]).. pE_CGE['off',t-1] * qE['off',t] =E= sum(purpose$(d1EP[purpose,'off',t]), pEP[purpose,'off',t-1] * qEP[purpose,'off',t]);

    E_sEP[purpose,t]$(tx0[t] and d1EP[purpose,'off',t]).. pEP[purpose,'off',t-1] * qEP[purpose,'off',t] =E= sum(energy19$(d1pREa[purpose,energy19,'off',t] and not eNotInEnergyNest[purpose,energy19,'off',t]), pREa[purpose,energy19,'off',t-1] * qREa[purpose,energy19,'off',t]);


	   E_fKInstCost_static_calibration_off[k,t]$(tx0[t] and d1K[k,'off',t] and d1I_s[k,'off',t-1])..
	     0 =E= qI_s[k,'off',t] - qI_s[k,'off',t-1]/fq * fKInstCost[k,'off',t];
	   
	   #In case of zero investments in the previous year, fK cannot be identified. It is then set to the previous year's value. In the current version, there are two sectors with zero investments, 53000,ib,2012 and 78000,ib,2012
	   E_fKInstCost_static_calibration_ifzero_[k,t]$(tx0[t] and d1K[k,'off',t] and not d1I_s[k,'off',t-1])..
	    fKInstCost[k,'off',t] =E=  fKInstCost[k,'off',t-1];



    $ENDBLOCK

  $GROUP G_production_public_static_calibration
    G_production_public_endo
    uY_CET$(d1vY_CET[out,s,t] and sameas[s,'off']), -pY_CET$(d1vY_CET[out,s,t] and sameas[s,'off'])
    -qY$(sameas[s_,'off']) #We do not create chain indexes for qY0/pY0, but instead use chain indexes from the data

    svI_pub_direct2GDP, -vI_pub_direct # E_vI_pub_direct

    fpGovDepr, -pGovDepr$(k[k_]) # E_pGovDepr
    fqGovDepr, -qGovDepr$(k[k_]) # E_qGovDepr

    R2LR_pub, -qL$(sameas(s_,'off')) # E_qL_pub
    uRxEOFF[t], -qRxE$(sameas(r_,'off')) # E_qRxEOFF


    -qREa$(tx0[t] and d1pREa[purpose,energy19a,s,t] and not eNotInEnergyNest[purpose,energy19a,s,t] and sameas[s,"off"]) # E_qREa_off
      uRE$(tx0[t] and d1pREa[purpose,energy19a,s,t] and not eNotInEnergyNest[purpose,energy19a,s,t] and sameas[s,"off"]) # E_qREa_off


    #Endo/exo til B_production_public_static_calibration
#      pk_trans_off$(t1[t]) # E_pK_trans_off_t0

    markup$(sameas(s,'off') and d1vY_CET[out,s,t]), - pY_CET$(sameas(s,'off') and d1vY_CET[out,s,t]) # E_markup_off
    markup_cali$(sameas(s,'off') and sum(out,d1vY_CET[out,s,t])) # E_pY_CET_off

    rDepr[k,s,t]$(d1K[k,s,t] and tx0[t] and sameas(s,'off')) # E_rDepr_off

    -qK$(sameas(s,'off')), jqI_s # E_qI_s_off
    rIL[s,t], -qI_s[i_,s,t]$(sameas(i_,'invt')) # E_qI_s_inv_off


    fKInstCost$(sameas[s,'off']) # E_fKInstCost_static_calibration_off

    uEOFF[t] # E_qEOFF
    -pE_CGE$(t1[t]) 

    # Public sector
    uEP_off, -pEP$(tBasis[t]) # E_qEP_off

    pE_CGE$(t0[t]), -pE_CGE$(tBasis[t])   # E_sE
    pEP, -pEP$(tBasis[t]) # E_sEP

  ;

  $GROUP G_production_public_static_calibration_exo 
    G_production_public_exo
    -uY_CET$(d1vY_CET[out,s,t] and sameas[s,'off']), pY_CET$(d1vY_CET[out,s,t] and sameas[s,'off'])
    qY$(sameas[s_,'off']) #We do not create chain indexes for qY0/pY0, but instead use chain indexes from the data

    -svI_pub_direct2GDP, vI_pub_direct # E_vI_pub_direct

    -fpGovDepr, pGovDepr$(k[k_]) # E_pGovDepr
    -fqGovDepr, qGovDepr$(k[k_]) # E_qGovDepr

    -R2LR_pub, qL$(sameas(s_,'off')) # E_qL_pub
    -uRxEOFF[t], qRxE$(sameas(r_,'off')) # E_qRxEOFF

    qREa$(tx0[t] and d1pREa[purpose,energy19a,s,t] and not eNotInEnergyNest[purpose,energy19a,s,t] and sameas[s,"off"]) # E_qREa_off
    -uRE$(tx0[t] and d1pREa[purpose,energy19a,s,t] and not eNotInEnergyNest[purpose,energy19a,s,t] and sameas[s,"off"]) # E_qREa_off

    #Endo/exo til B_production_public_static_calibration
    -markup$(sameas(s,'off') and d1vY_CET[out,s,t]), pY_CET$(sameas(s,'off') and d1vY_CET[out,s,t]) # E_markup_off
    markup_cali, -markup_cali$(sameas(s,'off') and sum(out,d1vY_CET[out,s,t])) # E_pY_CET_off
    
    -rDepr[k,s,t]$(d1K[k,s,t] and tx0[t] and sameas(s,'off')), rDepr_static$(d1K[k,s,t] and tx0[t] and sameas(s,'off')) # E_rDepr_off

    qK$(sameas(s,'off')), -jqI_s # E_qI_s_off
    -rIL[s,t], qI_s[i_,s,t]$(sameas(i_,'invt')) # E_qI_s_inv_off
    
    
    -fKInstCost$(sameas[s,'off']) # E_fKInstCost_static_calibration_off

    -uEOFF[t] # E_qEOFF
    pE_CGE$(t1[t])

    # #Public sector
    -uEP_off, pEP$(tBasis[t]) # E_qEP_off

    -pE_CGE$(t0[t]), pE_CGE$(tBasis[t])  # E_sE
     pEP$(tBasis[t]),-pEP$(t0[t]) # E_sEP

  ;

  $MODEL M_production_public_static_calibration
    M_production_public
    B_production_public_static_calibration
  ;

$ENDIF

# ======================================================================================================================
# Dynamic calibration
# ======================================================================================================================
$IF %stage% == "dynamic_calibration":

    $GROUP G_production_public_calib
           G_production_public_endo
               qK$(sameas(s,'OFF') and t1[t])
               #  -pK$(tStart[t])
               -qI_s$(t1[t] and d1jqI_s[s] and not sameas[i_,'invt'] and sameas(s,'OFF')), jqI_s$(t1[t] and d1jqI_s[s] and sameas(s,'OFF')), qK$(t1[t] and d1jqI_s[s] and sameas(s,'OFF'))
  ;

    $GROUP G_production_public_calib_exo
            G_production_public_exo
            -qK$(sameas(s,'OFF') and t1[t])
            qI_s$(t1[t] and d1jqI_s[s] and not sameas[i_,'invt'] and sameas(s,'OFF')), -jqI_s$(t1[t] and d1jqI_s[s] and sameas(s,'OFF')), -qK$(t1[t] and d1jqI_s[s] and sameas(s,'OFF'))
  ;

    $MODEL M_production_public_calib
    M_production_public
    ;

$ENDIF
