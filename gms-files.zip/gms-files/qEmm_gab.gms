qEmm_gab2030_pre = qEmm_gab2030;
qEmm_gab2035_pre = qEmm_gab2035;

qEmm_gab2030 = 0;
qEmm_gab2035 = 0;

$IF %Goal30%:
	qEmm_gab2030 =(qEmmTot.l['2029','CO2e','UNFCCC_lulucf']
         	      +qEmmTot.l['2030','CO2e','UNFCCC_lulucf']
            	  +qEmmTot.l['2031','CO2e','UNFCCC_lulucf'])/3 - maal2030;
$ENDIF

$IF %Goal35%:
	qEmm_gab2035 =(qEmmTot.l['2034','CO2e','UNFCCC_lulucf']
             	  +qEmmTot.l['2035','CO2e','UNFCCC_lulucf']
              	  +qEmmTot.l['2036','CO2e','UNFCCC_lulucf'])/3 - maal2035;
$ENDIF