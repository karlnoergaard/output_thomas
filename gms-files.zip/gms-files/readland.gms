#DBII måles i kroner per ha og arealerne måles i ha.

#Loading some "Data" - Tabel 6, Kommende støtteregime, høje priser. Budgetbegrænsning ved 50 000 ha for bioordning for biodiversitet??
#  qArea_tot['13']                 = 228473; qArea_tot_udtbase['13']                 = 67468;   DBII_gns_base['13']                 = 2768;
#  qArea_tot['14_water']           = 270602; qArea_tot_udtbase['14_water']           = 6065 ;   DBII_gns_base['14_water']           = 4584;
#  qArea_tot['13_livestock']       = 64133;  qArea_tot_udtbase['13_livestock']       = 18938;   DBII_gns_base['13_livestock']       = 5575;
#  qArea_tot['24']                 = 348006; qArea_tot_udtbase['24']                 = 50074;   DBII_gns_base['24']                 = 4986;
#  qArea_tot['13_cattle']          = 108224; qArea_tot_udtbase['13_cattle']          = 31958;   DBII_gns_base['13_cattle']          = 5420;
#  qArea_tot['14_water_livestock'] = 46510;  qArea_tot_udtbase['14_water_livestock'] = 1042 ;   DBII_gns_base['14_water_livestock'] = 6673;
#  qArea_tot['24_livestock']       = 97686;  qArea_tot_udtbase['24_livestock']       = 14056;   DBII_gns_base['24_livestock']       = 7931;
#  qArea_tot['24_cattle']          = 164845; qArea_tot_udtbase['24_cattle']          = 23719;   DBII_gns_base['24_cattle']          = 6173;
#  qArea_tot['11']                 = 128905; qArea_tot_udtbase['11']                 = 78765;   DBII_gns_base['11']                 = 5495;
#  qArea_tot['14_water_cattle']    = 105704; qArea_tot_udtbase['14_water_cattle']    = 2369 ;   DBII_gns_base['14_water_cattle']    = 6953;
#  qArea_tot['59']                 = 778561; qArea_tot_udtbase['59']                 = 70213;   DBII_gns_base['59']                 = 8113;
#  qArea_tot['59_cattle']          = 105211; qArea_tot_udtbase['59_cattle']          = 9488 ;   DBII_gns_base['59_cattle']          = 7664;
#  qArea_tot['59_livestock']       = 168337; qArea_tot_udtbase['59_livestock']       = 15181;   DBII_gns_base['59_livestock']       = 11247;
#  qArea_tot['11_high']            = 20700;  qArea_tot_udtbase['11_high']            = 10   ;   DBII_gns_base['11_high']            = 10332;
                                            #  There is not actually any out-take from this category in baseline, but GAMS need a non-zero value if this is to be made generically.
                                            #REMEMBER TO CREATE A DUMMY THAT CONSTRAINS THE OUT-TAKE EQUATION TO ONLY COUNT IF THERE IS ACTUAL BASELINE OUTTAKE


#Loading some "Data" - Tabel 3, Nuværende støtteregime, 2013-2018 priser. Budgetbegrænsning ved 50 000 ha for bioordning for biodiversitet??
qArea_tot['13']                 = 228473; qArea_tot_udtbase['13']                 = 67468;   DBII_gns_base['13']                 = -44 ;
qArea_tot['14_water']           = 270602; qArea_tot_udtbase['14_water']           = 6065 ;   DBII_gns_base['14_water']           = 691 ;
qArea_tot['13_livestock']       = 64133;  qArea_tot_udtbase['13_livestock']       = 18938;   DBII_gns_base['13_livestock']       = 806 ;
qArea_tot['24']                 = 348006; qArea_tot_udtbase['24']                 = 50074;   DBII_gns_base['24']                 = 1158;
qArea_tot['13_cattle']          = 108224; qArea_tot_udtbase['13_cattle']          = 31958;   DBII_gns_base['13_cattle']          = 1748;
qArea_tot['14_water_livestock'] = 46510;  qArea_tot_udtbase['14_water_livestock'] = 1042 ;   DBII_gns_base['14_water_livestock'] = 1756;
qArea_tot['24_livestock']       = 97686;  qArea_tot_udtbase['24_livestock']       = 14056;   DBII_gns_base['24_livestock']       = 2091;
qArea_tot['24_cattle']          = 164845; qArea_tot_udtbase['24_cattle']          = 23719;   DBII_gns_base['24_cattle']          = 2144;
qArea_tot['11']                 = 128905; qArea_tot_udtbase['11']                 = 78765;   DBII_gns_base['11']                 = 2284;
qArea_tot['14_water_cattle']    = 105704; qArea_tot_udtbase['14_water_cattle']    = 2369 ;   DBII_gns_base['14_water_cattle']    = 2284;
qArea_tot['59']                 = 778561; qArea_tot_udtbase['59']                 = 70213;   DBII_gns_base['59']                 = 2846;
qArea_tot['59_cattle']          = 105211; qArea_tot_udtbase['59_cattle']          = 9488 ;   DBII_gns_base['59_cattle']          = 2994;
qArea_tot['59_livestock']       = 168337; qArea_tot_udtbase['59_livestock']       = 15181;   DBII_gns_base['59_livestock']       = 3882;
qArea_tot['11_high']            = 20700;  qArea_tot_udtbase['11_high']            = 10   ;   DBII_gns_base['11_high']            = 3882;
                                            #  There is not actually any out-take from this category in baseline, but GAMS need a non-zero value if this is to be made generically.
                                            #REMEMBER TO CREATE A DUMMY THAT CONSTRAINS THE OUT-TAKE EQUATION TO ONLY COUNT IF THERE IS ACTUAL BASELINE OUTTAKE
