
$onmultiR
	sets set_output_industries /
	'Pris'
	'Produktion'
	'Udledninger'
	'EBITDA'
	/
	;

#  I excel udregnes der ændringer i:
	#  'p mekanisk'
	#  'P ligevægt'
	#  'Produktion'
	#  'Udledninger, relativt'
	#  'Udledninger, absolut'
	#  'Struktureffekt'
	#  'Teknisk effekt'
	#  'EBIDA'



	parameter
	output_industries[set_output_industries,s]
	;

$offmulti


Output_industries['Pris',s] = pY.l[s,'2030'];
Output_industries['Pris',s]$Plant_sectors_s(s) = sum(Plant_sectors$map_plantsectors2s(Plant_sectors,s), pPlant_CET.l[Plant_sectors,'netprod','2030']);
Output_industries['Pris',s]$Ani_sectors_s(s) = sum(Ani_sectors$map_Anisectors2s(Ani_sectors,s), pAni_CET.l[Ani_sectors,'out_other','2030']);


Output_industries['Produktion',s] = qY.l[s,'2030']; 
Output_industries['Produktion',s]$Plant_sectors_s(s) = sum(Plant_sectors$map_plantsectors2s(Plant_sectors,s), qPlant_CET.l[Plant_sectors,'netprod','2030']);
Output_industries['Produktion',s]$Ani_sectors_s(s) = sum(Ani_sectors$map_Anisectors2s(Ani_sectors,s), qAni_CET.l[Ani_sectors,'out_other','2030']);


Output_industries['Udledninger',s] = 
sum((emm_eq,purpose,energy19)$(d1CO2_REmarg[purpose,energy19,s,'2030',emm_eq] and d1EmmProdE[s,'2030',emm_eq,purpose, energy19] and not sameas[energy19,'district heat']), qEmmProdE.l[s,'2030',emm_eq,purpose,energy19])
+ sum((emm)$(d1EmmProdxE[s,'2030',emm] and d1CO2_ProdxE[s,'2030',emm] and sameas[emm,'CO2ubio']), qEmmProdxE.l[s,'2030',emm])
+ sum(ani_sectors$map_anisectors2s(Ani_sectors,s), sum((emmtype,Animals)$(d1EmmAgrAni[emmtype,ani_sectors,Animals,'2030','CO2e'] and reguleringsgrundlag_ani[emmtype] and not sameas[ani_sectors,'01061']and not sameas[ani_sectors,'01062']), qEmmAgrAni.l[emmtype,ani_sectors,Animals,'2030','co2e']))
+ sum(plant_sectors$map_plantsectors2s(Plant_sectors,s), sum((emmtype)$(d1EmmAgrxE[emmtype,plant_sectors,'2030','CO2e'] and reguleringsgrundlag[emmtype]), qEmmAgrxE.l[emmtype,Plant_sectors,'2030','co2e']));

Output_industries['EBITDA',sp] = vEBITDA.l[sp,'2030'];
