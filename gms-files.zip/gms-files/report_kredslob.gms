
$onmultiR
	sets set_kredslob /
	'BNP'
	'Afkast'
	#  '- Afkastkrav'
	#  'Cash flow'
	#  'Nettoafkast af udlandsformuen'
	'Netto overførsler fra udlandet'
	'|- Privatforbrug'
	'|- Offentligt forbrug'
	'|- Investeringer'
	'Sum af nettoopsparing'
	'Husholdningers formueændring'
	'Offentlig formueændring'
	'Virksomhedernes cash flow'
	'|- Virksomheders gæld'
	'Omvurdering og korrektion'
	'Sum af formueændringer'
	'vBoP'
	'test'
	/
	sets set_kredslob1(set_kredslob) /
	'BNP'
	'Afkast'
	#  '- Afkastkrav'
	#  'Cash flow'
	#  'Nettoafkast af udlandsformuen'
	'Netto overførsler fra udlandet'
	'|- Privatforbrug'
	'|- Offentligt forbrug'
	'|- Investeringer'
	/
	sets set_kredslob2(set_kredslob) /
	'Husholdningers formueændring'
	'Offentlig formueændring'
	'Virksomhedernes cash flow'
	'|- Virksomheders gæld'
	'Omvurdering og korrektion'
	/
	;

	parameter
	output_kredslob[set_kredslob,t]
	;

$offmulti

# Det vi tjener (BNP plus afkast på nettoformue i udlandet) minus det vi forbruger (C+G+I) skal være lige ændringen i vores opsparing
#  output_kredslob['handel',t]$(t.val ge 2020) = -vBoP.l[t];

#  det vi har af indkomst/inflow (BNP minus afkastkrav plus cash flow plus nettoafkast af udlandsformuen + omvurderinger og nettooverførsler fra udlandet) 
 #  minus det vi forbruger (C+G+I) skal være lige ændringen i vores opsparing

output_kredslob['BNP',t]$(t.val ge 2020) = vGDP.l[t];
#  output_kredslob['- Afkastkrav',t]$(t.val ge 2020) = sum(sp, -rInvestor.l[sp,t-1] * vEquity.l[sp,t-1]/fv);
#  output_kredslob['Cash flow',t]$(t.val ge 2020) = sum(sp,vFCFE.l[sp,t]);
output_kredslob['Afkast',t]$(t.val ge 2020) = sum(sp, rInvestor.l[sp,t-1] * vEquity.l[sp,t-1]/fv) + rForeignWealth.l[t]*vForeignWealth.l[t-1]/fv;

output_kredslob['Netto overførsler fra udlandet',t]$(t.val ge 2020) = - vtEU.l[t] + vtCO2_ETS_sales.l[t] - sum(s$(d1CO2_ETS[s,t]), vtCO2_ETS.l[s,t])+ vGovReceiveF.l[t] - vGov2Foreign.l[t] - sum(s$d1CO2_ETS2[s,t], vtCO2_ETS2.l[s,t]) - sum((purpose,energy19)$(d1CO2_CE_ETS2[purpose,energy19,t]), vtCO2_CE_ETS2.l[purpose,energy19,t]);
output_kredslob['|- Privatforbrug',t]$(t.val ge 2020) = -vC.l['ctot',t];
output_kredslob['|- Offentligt forbrug',t]$(t.val ge 2020) = -vG.l['gtot',t];
output_kredslob['|- Investeringer',t]$(t.val ge 2020) = -vI.l['itot',t];
output_kredslob['Sum af nettoopsparing',t]$(t.val ge 2020) = sum(set_kredslob1, output_kredslob[set_kredslob1,t]);

output_kredslob['Husholdningers formueændring',t] $(t.val ge 2020) = vWealth.l[t]-vWealth.l[t-1]/fv;
output_kredslob['Offentlig formueændring',t] $(t.val ge 2020) = vGovNetWealth.l[t]-vGovNetWealth.l[t-1]/fv;
output_kredslob['Virksomhedernes cash flow',t]$(t.val ge 2020) = sum(sp,vFCFE.l[sp,t]);
output_kredslob['|- Virksomheders gæld',t] $(t.val ge 2020) = -sum(sp, vFirmDebt.l[sp,t])+sum(sp, vFirmDebt.l[sp,t-1])/fv;
output_kredslob['Omvurdering og korrektion',t]$(t.val ge 2020) = -vGovReval.l[t] - JvWealth.l[t];
output_kredslob['Sum af formueændringer',t]$(t.val ge 2020) = sum(set_kredslob2, output_kredslob[set_kredslob2,t]);

output_kredslob['vBoP',t] $(t.val ge 2020) = vBoP.l[t]; 
output_kredslob['test',t] = output_kredslob['Sum af nettoopsparing',t]-output_kredslob['Sum af formueændringer',t]-vBoP.l[t];

