
##================================================================================================================
# Set dummies
##================================================================================================================


##================================================================================================================
# Solve model
##================================================================================================================

#  #Now we move start year to 2025 
$SETGLOBAL start_shock_year 2024 #Year where we start the shock
set_time_periods(%start_shock_year%,%terminal_year%);

# Eliminerer CCS fem år efter annonceringen af afgiften
rCCS.l[techCCS,s,purpose,energy19,t]$(sum(emm, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])) = 0;
rCCSxE.l[techCCS,s,t,emm]$(d1thetaCCSxE[techCCS,s,t,emm]) = 0;


$FIX G_exo;
$UNFIX G_endo;
#  execute_unloaddi 'Output\Pre.gdx';
@SOLVE(M_CO2eTax);




qEmm_s[s,t] =
  sum((emm_eq,purpose,energy19)$(d1CO2_REmarg[purpose,energy19,s,t,emm_eq] and d1EmmProdE[s,t,emm_eq,purpose, energy19] and not sameas[energy19,'district heat']), qEmmProdE.l[s,t,emm_eq,purpose,energy19])
+ sum((emm)$(d1EmmProdxE[s,t,emm] and d1CO2_ProdxE[s,t,emm] and sameas[emm,'CO2ubio']), qEmmProdxE.l[s,t,emm])
+ sum(ani_sectors$map_anisectors2s(Ani_sectors,s), sum((emmtype,Animals)$(d1EmmAgrAni[emmtype,ani_sectors,Animals,t,'CO2e'] and reguleringsgrundlag_ani[emmtype] and not sameas[ani_sectors,'01061']and not sameas[ani_sectors,'01062']), qEmmAgrAni.l[emmtype,ani_sectors,Animals,t,'co2e']))
+ sum(plant_sectors$map_plantsectors2s(Plant_sectors,s), sum((emmtype)$(d1EmmAgrxE[emmtype,plant_sectors,t,'CO2e'] and reguleringsgrundlag[emmtype]), qEmmAgrxE.l[emmtype,Plant_sectors,t,'co2e']));
;

parameter qEmm_s_pre[s,t], qEmm_s_diff[s,t];

qEmm_s_pre[s,t] = qEmm_s[s,t];


#  uEOPProdE.l[purpose,energy19,'19000',t,emm] $(uEOPProdE.l[purpose,energy19,'19000',t,emm] and t.val ge 2028) = uEOPProdE.l[purpose,energy19,'19000',t,emm]*(qEmm_s['19000',t]+100)/qEmm_s['19000',t]; 

uEmmProdE.l['19000',t,emm,energy19]$(uEmmProdE.l['19000',t,emm,energy19] and t.val ge 2028) = uEmmProdE.l['19000',t,emm,energy19]*(qEmm_s['19000',t]+100)/qEmm_s['19000',t]; 

$FIX G_exo;
$UNFIX G_endo;
@SOLVE(M_CO2eTax);


qEmm_s[s,t] =
  sum((emm_eq,purpose,energy19)$(d1CO2_REmarg[purpose,energy19,s,t,emm_eq] and d1EmmProdE[s,t,emm_eq,purpose, energy19] and not sameas[energy19,'district heat']), qEmmProdE.l[s,t,emm_eq,purpose,energy19])
+ sum((emm)$(d1EmmProdxE[s,t,emm] and d1CO2_ProdxE[s,t,emm] and sameas[emm,'CO2ubio']), qEmmProdxE.l[s,t,emm])
+ sum(ani_sectors$map_anisectors2s(Ani_sectors,s), sum((emmtype,Animals)$(d1EmmAgrAni[emmtype,ani_sectors,Animals,t,'CO2e'] and reguleringsgrundlag_ani[emmtype] and not sameas[ani_sectors,'01061']and not sameas[ani_sectors,'01062']), qEmmAgrAni.l[emmtype,ani_sectors,Animals,t,'co2e']))
+ sum(plant_sectors$map_plantsectors2s(Plant_sectors,s), sum((emmtype)$(d1EmmAgrxE[emmtype,plant_sectors,t,'CO2e'] and reguleringsgrundlag[emmtype]), qEmmAgrxE.l[emmtype,Plant_sectors,t,'co2e']));
;

qEmm_s_diff[s,t] = qEmm_s[s,t] - qEmm_s_pre[s,t];

$import Report_and_steps/report_all.gms

execute_unloaddi 'Output\RiskNB_CCS.gdx';
@check_vBoP();