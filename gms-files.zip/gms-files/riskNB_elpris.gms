
set_time_periods(2028,%terminal_year%);
display tx0;

#Vi eksogeniserer elektricitetsproduktionen og clearer med import 
d1vE_onesupplier['electricity',t] = 1;


$GROUP G_riskNB_elpris_new 
		adj_elpris[t] ""
		adj_el_supply[t] ""
;

$GROUP G_exo 
		G_exo 
		#  qY_CET$(sameas[out,'electricity'] and d1vY_CET[out,s,t])
		-markup$(sameas[out,'electricity'] and d1vY_CET[out,s,t])

		#  qM_CET$(t.val>=2029 and t.val<=2031 and sameas[out,'electricity'] and d1vM_CET[out,s,t])
		#  qY_CET$(t.val>=2029 and t.val<=2031 and sameas[out,'electricity'] and d1vY_CET[out,s,t] and sameas[s,'38393'])

;

$GROUP G_endo 
		G_endo 
		#  -qY_CET$(sameas[out,'electricity'] and d1vY_CET[out,s,t])
		markup$(sameas[out,'electricity'] and d1vY_CET[out,s,t])
		pM_CET$(tx0[t] and sameas[out,'electricity'] and d1vM_CET[out,s,t])

		#  -qM_CET$(t.val>=2029 and t.val<=2031 and sameas[out,'electricity'] and d1vM_CET[out,s,t])
		#  -qY_CET$(t.val>=2029 and t.val<=2031 and sameas[out,'electricity'] and d1vY_CET[out,s,t] and sameas[s,'38393'])
		#  -qY_CET$(t.val>2031 and sameas[out,'electricity'] and d1vY_CET[out,s,t])


;


#Beregner prisstigning
PARAMETER pKF_ElEngros[t], pKF_ElDist_IND[t], pKF_ElDist_HOU[t], DeltaP[t], DeltaP_reverseengi;
PARAMETER pKF_ElEngros_MWh22[t], pKF_ElDist_IND_MWh22[t], pKF_ElDist_HOU_MWh22[t], DeltaP_Mwh22[t]; #Same prices, but 2022 and in per MWh
PARAMETER pY_CET_riskNB_baseline[out,s,t], pM_CET_riskNB_baseline[out,s,t], pRE_base_marg_riskNB_baseline[energy19,t], pEtot_riskNB_baseline[energy19,t], qM_CET_riskNB_baseline[out,s,t], qY_CET_riskNB_baseline[out,s,t];

pY_CET_riskNB_baseline[out,s,t]  = pY_CET.l[out,s,t]; 
pM_CET_riskNB_baseline[out,s,t]  = pM_CET.l[out,s,t];
qY_CET_riskNB_baseline[out,s,t]  = qY_CET.l[out,s,t]; 
qM_CET_riskNB_baseline[out,s,t]  = qM_CET.l[out,s,t];

pRE_base_marg_riskNB_baseline[energy19,t] = pRE_base_marg.l[energy19,t];
pEtot_riskNB_baseline[energy19,t] = pEtot.l[energy19,t];

pKF_ElEngros[t]$(tx0[t])         = KF_pForEl[t]*inf_factor[t]/1000; #Omregner først engrosprisen på el fra KF24 til vores priser 
pKF_ElDist_IND[t]$(tx0[t])       = KF24_CostDel_in_['Elektricitet','IND',t] * inf_factor[t]/1000;
pKF_ElDist_HOU[t]$(tx0[t])       = KF24_CostDel_in_['Elektricitet','HOU',t] * inf_factor[t]/1000;

pKF_ElEngros_MWh22[t]$(tx0[t])   = KF_pForEl[t]*3.6*LOFT_pyf['2022']/LOFT_pyf[t];   #Omregner til kroner per MWh, 2022-priser
pKF_ElDist_IND_MWh22[t]$(tx0[t]) = pKF_ElDist_IND[t]*3.6*LOFT_pyf['2022']/LOFT_pyf[t]; #Omregner til kroner per MWh, 2022-priser
pKF_ElDist_HOU_MWh22[t]$(tx0[t]) = pKF_ElDist_HOU[t]*3.6*LOFT_pyf['2022']/LOFT_pyf[t]; #Omregner til kroner per MWh, 2022-priser

DeltaP[t] 						 = pKF_ElEngros[t]*(6.6-1); 
DeltaP_Mwh22[t] 				 = pKF_ElEngros_MWh22[t] * (6.6-1);

DeltaP_reverseengi = (258-34)*7.5/3.6/1000 * inf_factor['2022']; #NB vil gerne ramme 

PARAMETER itein/1/;

$BLOCK B_elprisshock
	E_pRE_base_marg_elec[t]$(tx0[t] and t.val>=2029 and t.val<=2031)..
			#  pRE_base_marg['electricity',t] =E= pKF_ElEngros[t]*itein + pKF_ElDist_IND[t];
			pRE_base_marg['electricity',t] =E= pRE_base_marg_riskNB_baseline['electricity',t] + DeltaP_reverseengi*itein;

	#  E_pY_CET_elec_after2031[out,s,t]$(tx0[t] and t.val>2031 and d1vY_CET[out,s,t] and sameas[out,'electricity'])..
	#  		pY_CET[out,s,t] =E= pY_CET[out,s,t-1]*0.75 + pY_CET_riskNB_baseline[out,s,t]*0.25;
	#  		#  pY_CET[out,s,t] =E= pY_CET_riskNB_baseline[out,s,t];


	#  E_pY_CET_elec_before2031[out,s,t]$(tx0[t] and t.val>=2029 and t.val<=2031 and d1vY_CET[out,s,t] and sameas[out,'electricity'])..
	#  		pY_CET[out,s,t] =E= pY_CET_riskNB_baseline[out,s,t] + adj_elpris[t];


	#  E_pM_CET_elec_after2031[out,s,t]$(tx0[t] and t.val>2031 and d1vM_CET[out,s,t] and sameas[out,'electricity'])..
	#  		pM_CET[out,s,t] =E= pM_CET[out,s,t-1]*0.75 + pM_CET_riskNB_baseline[out,s,t]*0.25;
	#  		#  pM_CET[out,s,t] =E= pM_CET_riskNB_baseline[out,s,t];


	#  E_pM_CET_elec_before2031[out,s,t]$(tx0[t] and t.val>=2029 and t.val<=2031 and d1vM_CET[out,s,t] and sameas[out,'electricity'])..
	#  		pM_CET[out,s,t] =E= pM_CET_riskNB_baseline[out,s,t] + adj_elpris[t];


	E_pY_CET_elec_after2029[out,s,t]$(tx0[t] and t.val>=2029 and d1vY_CET[out,s,t] and sameas[out,'electricity'])..
			pY_CET[out,s,t] =E= pY_CET_riskNB_baseline[out,s,t] + adj_elpris[t];

	E_pM_CET_elec_after2029[out,s,t]$(tx0[t] and t.val>=2029 and d1vM_CET[out,s,t] and sameas[out,'electricity'])..
			pM_CET[out,s,t] =E= pM_CET_riskNB_baseline[out,s,t] + adj_elpris[t];


	E_pEtot_after_2031[t]$(tx0[t] and t.val>2031)..
		pEtot['electricity',t] =E=  pEtot_riskNB_baseline['electricity',t];


	E_qY_CET_electricity[s,t]$(tx0[t] and d1vY_CET['electricity',s,t])..
		qY_CET['electricity',s,t] =E= qY_CET.l['electricity',s,t] *adj_el_supply[t];

	E_qM_CET_electricity[s,t]$(tx0[t] and d1vM_CET['electricity',s,t])..
		qM_CET['electricity',s,t] =E= qM_CET.l['electricity',s,t] *adj_el_supply[t];


    #  E_qIb_alt[sp,t]$(tx0[t]).. qIb[sp,t] =E= uIb[sp,t] * abs(pIb[sp,t] / pKELB[sp,t])**(-eKELB[sp]) * qKELB[sp,t];
    #  E_qIm_alt[sp,t]$(tx0[t]).. qIm[sp,t] =E= uIm[sp,t] * abs(pIm[sp,t]/pMKE[sp,t])**(-eMKE[sp]) * qMKE[sp,t];



$ENDBLOCK 

$MODEL M_elprisshock
		M_CO2tax
		B_elprisshock
		#  -E_qIb,-E_qIm
;



#  $FOR {itein} in ['1','2','3','4','5','6.6']:
#  $FOR {itein} in ['0','0.2','0.4','0.6','0.8','1']:

#  qM_CET.l['electricity','19000',t]$(t.val>=2029 and t.val<=2031) = 1.2 * qM_CET_riskNB_baseline['electricity','19000',t];
#  uKinstcost.l[k,'38393',t] = 0;
#  PARAMETER negpk[k,sp,t];

set elpriceitems/
	engrospris_og_distribution
	punktafgifter 
	moms 
	tot
	/;

set elpriceitemsxtot[elpriceitems];
set indhus/ind,hus/;
elpriceitemsxtot[elpriceitems] = yes$(not sameas[elpriceitems,'tot']);

PARAMETER report_electricityprice[indhus,elpriceitems,t];
$FUNCTION compute_report():

report_electricityprice['ind','engrospris_og_distribution',t] = pRE_base_marg.l['electricity',t];

report_electricityprice['ind','punktafgifter',t]$(tx0[t]) 
											= sum((purpose,s)$d1EAFG_RE[purpose,'electricity',s,t], vtEAFG_RE.l[purpose,'electricity',s,t])  #+ sum(purpose$d1EAFG_CE[purpose,'electricity',t], vtEAFG_CE.l[purpose,'electricity',t]))
											/(sum((purpose,s)$d1qREgj[purpose,'electricity',s,t], qREgj.l[purpose,'electricity',s,t]));  #+ sum(purpose$d1vCE[purpose,'electricity',t], qCE.l[purpose,'electricity',t]));

report_electricityprice['ind','punktafgifter',t]$(tx0[t]) 
											= sum((purpose,s)$d1VAT_RE[purpose,'electricity',s,t], vtVAT_RE.l[purpose,'electricity',s,t]) # + sum(purpose$d1VAT_CE[purpose,'electricity',t], vtVAT_CE.l[purpose,'electricity',t]))
											/(sum((purpose,s)$d1qREgj[purpose,'electricity',s,t], qREgj.l[purpose,'electricity',s,t])); # + sum(purpose$d1vCE[purpose,'electricity',t], qCE.l[purpose,'electricity',t]));

report_electricityprice['ind','tot',t] = sum(elpriceitemsxtot,report_electricityprice['ind',elpriceitemsxtot,t]);


report_electricityprice['hus','engrospris_og_distribution',t] = pCE_base.l['appliances','electricity',t];

report_electricityprice['hus','punktafgifter',t]$(tx0[t]) 
											= (sum(purpose$d1EAFG_CE[purpose,'electricity',t], vtEAFG_CE.l[purpose,'electricity',t]))
											/(sum(purpose$d1vCE[purpose,'electricity',t], qCE.l[purpose,'electricity',t]));

report_electricityprice['hus','punktafgifter',t]$(tx0[t]) 
											= (sum(purpose$d1VAT_CE[purpose,'electricity',t], vtVAT_CE.l[purpose,'electricity',t]))
											/(sum(purpose$d1vCE[purpose,'electricity',t], qCE.l[purpose,'electricity',t]));

report_electricityprice['hus','tot',t] = sum(elpriceitemsxtot,report_electricityprice['hus',elpriceitemsxtot,t]);


report_electricityprice[indhus,elpriceitems,t] = report_electricityprice[indhus,elpriceitems,t]*3600;
$ENDFUNCTION

$FOR {itein} in ['1']:
#  $FOR {itein} in ['0.05','0.1','0.2','0.5','0.7','1']:
	itein = {itein};
	@print("------------------------------------------ Current iteration is: itein = {itein} --------------------------")

		$FIX G_exo;
		$UNFIX G_endo;

		@compute_report();
		execute_unload 'output\riskNB_elpris_pre.gdx';
		@SOLVE(M_elprisshock);
		@compute_report();
		execute_unload 'output\riskNB_elpris_{itein}.gdx';

$ENDFOR

