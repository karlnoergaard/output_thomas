
#Check for non-negative prices on land
	LOOP(t$tx0[t],
	tjek = pLand.l[t];
	ABORT$(tjek <= 0) tjek, "Calibration has resulted in negative land-prices - this does not make sense. Rethink your settings in agricultural module"
	);


	LOOP((t,plant_sectors)$(tx0[t]),
		tjek = pPlant.l[plant_sectors,'land',t];
		ABORT$(tjek <= 0) tjek, "Shock has resulted in negative user-cost on land - this does not make sense. Rethink your settings in agricultural module"
		);

#Check that total area in LULUCF is unchanged
	LOOP(t$tx0[t],
	tjek = sum(land12,qLu12.l[land12,t])-sum(land12,qLu12.l[land12,t-1]);
	ABORT$(abs(tjek) > 1e-6) tjek, "Total area in LULUCF-module is changing over time. Check whatever land-change adjustments you are making";
	);


# Check that the quantities that comes out of the waste treatment sector match matches the quantities that goes into the waste treatment sector
	LOOP(t$(tx0[t]),
    ABORT$(abs(qWasteQ_bar_dom_check.l[t] - qWasteQ_bar_dom_tot.l[t])>1e-6) 'The mass balance in the waste treatment sector does not hold'
	);


#Test af udtagningsmodulet

    $IF %sanitycheckendoland%:
      $OnMultiR   
      PARAMETER TheMin, NextToMin, Wheresthemin[grid,gridtax,HaUdtag,Lavbundsmodel], DBII_themin, HectaresLookedup[alt,btype], HectaresModel[alt,btype], DistanceToModelDBII, DistanceToModelOuttake[alt],
                DBII_nexttomin, HectaresLookedup_nexttomin[alt,btype];
      $OffMulti


      #Først beregnes afstanden fra modellens DBII til DBII i tabellerne fra udtagningsmodulet
      Wheresthemin[grid,gridtax,HaUdtag,Lavbundsmodel]$(d1UdtagOptions[gridtax,HaUdtag,lavbundsmodel] and d1currentgrid[gridtax]) =  abs(vDBII_input.l['2030']-vDBII_iomdrift_total[grid,gridtax,HaUdtag,lavbundsmodel]);

  
      #Smin finder minimumsværdien i "Wheresthemin"
      TheMin                            = smin((grid,gridtax,HaUdtag,lavbundsmodel)$(d1UdtagOptions[gridtax,HaUdtag,lavbundsmodel] and d1currentgrid[gridtax]), Wheresthemin[grid,gridtax,HaUdtag,Lavbundsmodel]);


      #Finder DBII, der er tættest på modellens i opslagstabellen
      DBII_themin                       = sum((grid,gridtax,HaUdtag,lavbundsmodel)$(d1UdtagOptions[gridtax,HaUdtag,lavbundsmodel] and d1currentgrid[gridtax] and abs(vDBII_input.l['2030']-vDBII_iomdrift_total[grid,gridtax,HaUdtag,lavbundsmodel])=TheMin), vDBII_iomdrift_total[grid,gridtax,HaUdtag,lavbundsmodel]);
      #Finder det hektar udtag i opslagstabellen, der hører til DBII_themin
      HectaresLookedup[alt,btype]       = sum((grid,gridtax,HaUdtag,lavbundsmodel)$(d1UdtagOptions[gridtax,HaUdtag,lavbundsmodel] and d1currentgrid[gridtax] and abs(vDBII_input.l['2030']-vDBII_iomdrift_total[grid,gridtax,HaUdtag,lavbundsmodel])=TheMin), udtag_udf[grid,gridtax,HaUdtag,lavbundsmodel,alt,btype]); 
      #Beregner afstand til modellens DBII (det er bare af interesse -bruges ikke i test)
      DistanceToModelDBII               = vDBII_input.l['2030']-DBII_themin;

      #Det samlede hektar udtag i modellen beregnes
      HectaresModel[alt,btype]          = sum(gridtax$(d1currentgrid[gridtax]), qLandUdtag_pot.l[alt,btype,gridtax,'2030']);
      									#qLandUdtag_pot.l[alt,btype,'0','2030']$(d1currentgrid['0'])
                                                                                 #  +(
                                                                                 #    sum((gridtax)$(d1currentgrid[gridtax]), qLandUdtag_pot.l['GLM',btype,gridtax,'2030']$(sameas[alt,'GLM']))
                                                                                 #  + sum((gridtax)$(d1currentgrid[gridtax]), qLandUdtag_pot.l['BIO',btype,gridtax,'2030']$(sameas[alt,'BIO']))
                                                                                 #  + qLandSko.l['2030']$(sameas[alt,'sko'] and sameas[btype,'11'])/scaleha*10**6 #Bruger 11 som placeholder for hele brak/skov. 
                                                                                 #  + qLandBRK.l['2030']$(sameas[alt,'brk'] and sameas[btype,'11'])/scaleha*10**6)$(not d1currentgrid['0']);


      #Beregner afstand i udtagne hektar (også bare af interesse bruges ikke i test)
      DistanceToModelOuttake[alt]       = sum(btype, HectaresLookedup[alt,btype] -  HectaresModel[alt,btype]);


      #Vi kan nu have to tilfælde. Enten a) DBII_themin < DBII_input, eller b) DBII_themain> DBII_input. 
      #For a) vil vi gerne slå udtag op i opslagstabellerne for DBII_themin < DBII_input < DBII_nexttomin 
      #For b) vil vi gerne slå udtag op i opslagstabellerne for DBII_themin > DBII_input > DBII_nexttomin 

      #Det vil vi gerne fordi det skal gælde at (bemærk at ulighedstegnene vender ift. ovenstående, da lavere DBII associeres med højere udtag)
      # a)  udtag(DBII_themin) > udtagmodel(DBII_input) > udtag(DBII_nexttomin)
      # b)  udtag(DBII_themin) < udtagmodel(DBII_input) < udtag(DBII_nexttomin)
      #Og det er a)/b) vi tester for også er det modellen producerer af udtag.

      #Hvis DBII i modellen er større end DBII_themin skal den kigge efter værdier højere end DBII_themin 
      NextToMin$(vDBII_input.l['2030']>DBII_themin) 
          = smin((grid,gridtax,HaUdtag,lavbundsmodel)$(vDBII_iomdrift_total[grid,gridtax,HaUdtag,lavbundsmodel]>DBII_themin and d1UdtagOptions[gridtax,HaUdtag,lavbundsmodel] and d1currentgrid[gridtax] and not abs(vDBII_input.l['2030']-vDBII_iomdrift_total[grid,gridtax,HaUdtag,lavbundsmodel])=TheMin), Wheresthemin[grid,gridtax,HaUdtag,Lavbundsmodel]);
     
      #Hvis DBII i modellen er mindre end DBII_themin skal den kigge efter værdier lavere end DBII_themin
      NextToMin$(vDBII_input.l['2030']<DBII_themin)
          = smin((grid,gridtax,HaUdtag,lavbundsmodel)$(vDBII_iomdrift_total[grid,gridtax,HaUdtag,lavbundsmodel]<DBII_themin and d1UdtagOptions[gridtax,HaUdtag,lavbundsmodel] and d1currentgrid[gridtax] and not abs(vDBII_input.l['2030']-vDBII_iomdrift_total[grid,gridtax,HaUdtag,lavbundsmodel])=TheMin), Wheresthemin[grid,gridtax,HaUdtag,Lavbundsmodel]);

      #Pba. af ovenstående finder vi nærmeste til den retning vDBII_input ligger
      DBII_nexttomin = sum((grid,gridtax,HaUdtag,lavbundsmodel)$(d1UdtagOptions[gridtax,HaUdtag,lavbundsmodel] and d1currentgrid[gridtax] and abs(vDBII_input.l['2030']-vDBII_iomdrift_total[grid,gridtax,HaUdtag,lavbundsmodel])=NextToMin),
                          vDBII_iomdrift_total[grid,gridtax,HaUdtag,lavbundsmodel]);

      #Og vi kan slå hektar op
      HectaresLookedup_nexttomin[alt,btype] = sum((grid,gridtax,HaUdtag,lavbundsmodel)$(d1UdtagOptions[gridtax,HaUdtag,lavbundsmodel] and d1currentgrid[gridtax] and abs(vDBII_input.l['2030']-vDBII_iomdrift_total[grid,gridtax,HaUdtag,lavbundsmodel])=NextToMin), 
                      udtag_udf[grid,gridtax,HaUdtag,lavbundsmodel,alt,btype]); 


      #Resetter tjek
      tjek = 0;
      #Testen er at det udtag hektar modellen vælger skal ligge imellem DBII_themin og det tætteste derpå. Testen slår altså til, hvis det ikke er tilfældet og afbryder. 
      #Den må ikke ramme mere end 1000 forkert.
        #a) 
        tjek$(vDBII_input.l['2030']>DBII_themin and not ((sum((alt,btype), HectaresLookedup_nexttomin[alt,btype])-2000< sum((alt,btype), HectaresModel[alt,btype])) 
                                                                  and (sum((alt,btype), HectaresModel[alt,btype]) < sum((alt,btype),HectaresLookedup[alt,btype])+2000))) = 1;
        #b)
        tjek$(vDBII_input.l['2030']<DBII_themin and not ((sum((alt,btype), 2000+HectaresLookedup_nexttomin[alt,btype]) > sum((alt,btype), HectaresModel[alt,btype])) 
                                                                  and (sum((alt,btype), HectaresModel[alt,btype]) > sum((alt,btype),HectaresLookedup[alt,btype])-2000))) = 1;

       #  Abort$(tjek<>0) tjek, "Udtagningsfunktionen producerer resultater, der ikke stemmer overens med det partielle udtagningsmodul";
    $ENDIF 
  #Tester vBoP
  	#  @check_vBoP()


  #Test af produktivitet i udtagningsmodulet 
    $IF %sanitycheckendoland%:
      LOOP(t$(t.val>2050),
          tjek = sUdtaget_af_pot.l[t]-1;
          Abort$(abs(tjek) > 1e-5) tjek, "Der er muligvis noget i vejen. Al træg jordudtag burde være indfaset i 2050 og sUdtaget_af_pot burde derfor (rundt regnet) være 1";
          );
    $ENDIF

  #Jordprisen på skov må ikke være lavere end jordprisen på brak i skovstød 
  $IF %shockmodel%==1:
    $IF1 %negativafgiftskov%==1:
      LOOP(t$(tx0[t]),
        tjek = pLand_nonproductive.l['Skov','01011',t] - pLand_nonproductive.l['Brak','01011',t];
        #  ABORT$(tjek<0) tjek, "Prisen på skov er lavere end prisen på braklagte arealer - hvis dette er et skovstød, da genovervej skovstøttesats";
        );
    $ENDIF1 
  $ENDIF



  #Test of marginal CO2-taxes taxes 
    $OnMultiR 
      $PGROUP PG_checktCO2marg
                 emissions_sc[GSR_ag,t] "", marginaltaxes_sc[GSR_ag,t] "", imputedtax_sc[GSR_ag,t] "",  tCO2_REmarg_SKM_mapped[GSR_ag,t]"",
                 emissions_sc_full[GSR_ag,purpose,energy19,r,t] "", marginaltaxes_sc_full[GSR_ag,purpose,energy19,r,t] "", imputedtax_sc_full[GSR_ag,purpose,energy19,r,t] ""
      ;

      $PGROUP PG_checktCO2marg_mappings 
        mapGrREFORM2GSR[purpose,energy19,r,GSR_ag,t] ""
        impliedmapping_GSR_ag_SKM[GSR_ag,tREbase_SKM] ""
      ;

    $OffMulti 

    impliedmapping_GSR_ag_SKM[GSR_ag,tREbase_SKM] = yes$(sum((Categoryens,purpose,energy19,s), sENS2GR(categoryENS, GSR_ag, purpose, energy19, s) and tREbase_SKM_2_ENS(tREbase_SKM,categoryENS,GSR_ag,energy19) and not sameas[tREbase_SKM,'El_proces']));
    mapGrREFORM2GSR[purpose,energy19,r,GSR_ag,t]  = yes$sum((categoryENS), sENS2GR(categoryENS,GSR_ag,purpose,energy19,r));

      #Renser parametre for tidligere værdier
      $LOOP PG_checktCO2marg: {name}{sets} = 0; $ENDLOOP


    
      #Computing emissions
      emissions_sc[GSR_ag,t]    = sum((purpose,energy19,r) $ (mapGrREFORM2GSR[purpose,energy19,r,GSR_ag,t] and d1EmmProdE[r,t,'CO2ubio',purpose,energy19]), qEmmProdE.l[r,t,'co2ubio',purpose,energy19])
                       #Vi betinger på at der også skal være ubio emissioner fra naturgas. Der er nogle få tilfælde, hvor det lader til at virksomhederne bruger ren bionaturgas. Det er enten en datafejl, eller fordi de ikke modtager fra ledningsnettet og derfor kan få det rent. Det antages at det er sidstnævnte - og i de tilfælde skal naturgassen ikke beskattes, da det er ren bionaturgas.
                                          +sum((purpose,r) $ (mapGrREFORM2GSR[purpose,'Natural gas incl. biongas',r,GSR_ag,t] and d1EmmProdE[r,t,'CO2bio',purpose,'Natural gas incl. biongas'] and d1EmmProdE[r,t,'CO2ubio',purpose,'Natural gas incl. biongas']), qEmmProdE.l[r,t,'co2bio',purpose,'Natural gas incl. biongas']);

      #Computing tax-revenues
      marginaltaxes_sc[GSR_ag,t] = sum((purpose,energy19,r) $ (mapGrREFORM2GSR[purpose,energy19,r,GSR_ag,t] and d1CO2_REmarg_sumemm[purpose,energy19,r,t] and not sameas[energy19,'District heat']), vtCO2_REmarg.l[purpose,energy19,r,t]);
     
      #Computing implied tax-rate  
      imputedtax_sc[GSR_ag,t]$(emissions_sc[GSR_ag,t]) = marginaltaxes_sc[GSR_ag,t]/emissions_sc[GSR_ag,t]/growth_factor[t]*10**6;

      emissions_sc_full[GSR_ag,purpose,energy19,r,t]$ (mapGrREFORM2GSR[purpose,energy19,r,GSR_ag,t] and d1EmmProdE[r,t,'CO2ubio',purpose,energy19]) = qEmmProdE.l[r,t,'co2ubio',purpose,energy19];
      emissions_sc_full[GSR_ag,purpose,energy19,r,t] = emissions_sc_full[GSR_ag,purpose,energy19,r,t] + qEmmProdE.l[r,t,'co2bio',purpose,'Natural gas incl. biongas']$(mapGrREFORM2GSR[purpose,'Natural gas incl. biongas',r,GSR_ag,t] and d1EmmProdE[r,t,'CO2bio',purpose,'Natural gas incl. biongas'] and d1EmmProdE[r,t,'CO2ubio',purpose,'Natural gas incl. biongas'] and sameas[energy19,'Natural gas incl. biongas']);                                                             

      marginaltaxes_sc_full[GSR_ag,purpose,energy19,r,t]$ (mapGrREFORM2GSR[purpose,energy19,r,GSR_ag,t] and d1CO2_REmarg_sumemm[purpose,energy19,r,t] and not sameas[energy19,'District heat']) =   vtCO2_REmarg.l[purpose,energy19,r,t];

      imputedtax_sc_full[GSR_ag,purpose,energy19,r,t]$emissions_sc_full[GSR_ag,purpose,energy19,r,t] = marginaltaxes_sc_full[GSR_ag,purpose,energy19,r,t]/emissions_sc_full[GSR_ag,purpose,energy19,r,t];
      #  #
      #  tCO2_REmarg_SKM_mapped[GSR_ag,t]$(sum((categoryENS,purpose,energy19,s,tREbase_SKM)$(sENS2GR(categoryENS, GSR_ag, purpose, energy19, s) and tREbase_SKM_2_ENS(tREbase_SKM,categoryENS,GSR_ag,energy19)), 1))  
      #                                 =  sum((categoryENS,purpose,energy19,s,tREbase_SKM)$(sENS2GR(categoryENS, GSR_ag, purpose, energy19, s) and tREbase_SKM_2_ENS(tREbase_SKM,categoryENS,GSR_ag,energy19)), tCO2_REmarg_SKM.l[tREbase_SKM,t])
      #                                   /sum((categoryENS,purpose,energy19,s,tREbase_SKM)$(sENS2GR(categoryENS, GSR_ag, purpose, energy19, s) and tREbase_SKM_2_ENS(tREbase_SKM,categoryENS,GSR_ag,energy19)), 1);

      tCO2_REmarg_SKM_mapped[GSR_ag,t]$sum(tREbase_SKM$(sum((Categoryens,purpose,energy19,s), sENS2GR(categoryENS, GSR_ag, purpose, energy19, s) and tREbase_SKM_2_ENS(tREbase_SKM,categoryENS,GSR_ag,energy19) and not sameas[tREbase_SKM,'el_proces'])), 1)
                                     = sum(tREbase_SKM$(sum((Categoryens,purpose,energy19,s), sENS2GR(categoryENS, GSR_ag, purpose, energy19, s) and tREbase_SKM_2_ENS(tREbase_SKM,categoryENS,GSR_ag,energy19) and not sameas[tREbase_SKM,'el_proces'])), tCO2_REmarg_SKM.l[tREbase_SKM,t])
                                      /sum(tREbase_SKM$(sum((Categoryens,purpose,energy19,s), sENS2GR(categoryENS, GSR_ag, purpose, energy19, s) and tREbase_SKM_2_ENS(tREbase_SKM,categoryENS,GSR_ag,energy19) and not sameas[tREbase_SKM,'el_proces'])), 1); #Vi holder el-proces ude af mappingen, da denne gælder energiafgifter og ikke CO2-afgifter

parameter 
  tjek_imputed_tax[GSR_ag,t]
  tjek_imputed_tax_full[GSR_ag,purpose,energy19,r,t]
  ;

  tjek_imputed_tax[GSR_ag,t] = imputedtax_sc[GSR_ag,t] - tCO2_REmarg_SKM_mapped[GSR_ag,t];
  tjek_imputed_tax_full[GSR_ag,purpose,energy19,r,t] = imputedtax_sc_full[GSR_ag,purpose,energy19,r,t] - marginaltaxes_sc_full[GSR_ag,purpose,energy19,r,t];
  tjek_imputed_tax_full[GSR_ag,purpose,energy19,r,t]$(abs(tjek_imputed_tax_full[GSR_ag,purpose,energy19,r,t]) < 5) = 0;

  #Test af marginal rax-rates. The test isn't perfect - it does not catch errors in the mapping of SKM-data to the model in the first place. In that instance there will be no tax in the model, and hence it will not be compared in the below test 
  #Further the category notinGSR_ETS is a mix of taxed emissions (electricity for fossile og fjernvarme)
    #  LOOP((GSR_ag,t)$(tx0[t] and imputedtax_sc[GSR_ag,t] and not sameas[GSR_ag,'notinGSR_ETS']),
    #    tjek = imputedtax_sc[GSR_ag,t] - tCO2_REmarg_SKM_mapped[GSR_ag,t];
    #    ABORT$(abs(tjek) > 5) tjek, "Hvis de imputerede afgifter paa GSR-niveau afviger mere end 5 kroner fra data, slaar testen ud. I princippet skulle testen give nul over det hele";                       
    #      );

  #Test of marginal end-user prices. We only test prices after calibration to ENS, where end-user prices have been calibrated to uniform levels across afgiftsgrundlag

    $OnMultiR
    PARAMETER tjekuEmmBionatgas[purpose,s,t]; 
    $OffMulti

    tjekuEmmBionatgas[purpose,s,t]$(tx1[t]) = 0;

    tjekuEmmBionatgas[purpose,s,t]$(tx1[t] and (d1EmmProdE[s,t,'CO2ubio',purpose,'Natural gas incl. biongas'] or d1EmmProdE[s,t,'CO2bio',purpose,'Natural gas incl. biongas']) and qREgj.l[purpose,'Natural gas incl. biongas',s,t]) 
           =(qGrossEmmE.l[s,t,'CO2ubio',purpose,'Natural gas incl. biongas']$d1EmmProdE[s,t,'CO2ubio',purpose,'Natural gas incl. biongas'] 
          +  qGrossEmmE.l[s,t,'CO2bio',purpose,'Natural gas incl. biongas']$d1EmmProdE[s,t,'CO2bio',purpose,'Natural gas incl. biongas'])/(qREgj.l[purpose,'Natural gas incl. biongas',s,t])*growth_factor[t];

  #Test of implicit emission-coefficients on natural gas 
    LOOP((t,purpose,s)$(tx1[t] and (d1EmmProdE[s,t,'CO2ubio',purpose,'Natural gas incl. biongas'] or d1EmmProdE[s,t,'CO2bio',purpose,'Natural gas incl. biongas']) and qREgj.l[purpose,'Natural gas incl. biongas',s,t] and not sum((techCCS,energy19,emm), d1thetaCCS[techCCS,purpose,energy19,s,t,emm])),
      tjek =tjekuEmmBionatgas[purpose,s,t];
      ABORT$(tjek > 55.55+0.05 or tjek < 55.55-0.05) tjek, "De implicitte emissionskoefficienter på naturgas afviger fra de tekniske koefficienter";     
        );


  #Test of holes in the cheese
    $OnMultiR
    parameter tjek_hulleriosten[purpose,energy19,r,t];
    $OffMulti

    
    LOOP(t$(tx0[t]),
        #Der optræder varmepumper, der indføres imellem 2020-2024 nogle få steder i ENS-data for derefter at blive udfaset igen.
        tjek_hulleriosten[purpose,energy19,r,t]$(not sameas[energy19,'heat pumps'] and d1qREgj[purpose,energy19,r,t] and not d1qREgj[purpose,energy19,r,t+1] and sum(tt$(tt.val>t.val+1), d1qREgj[purpose,energy19,r,tt])) = 1;        
        );

    LOOP((purpose,energy19,r,t)$(tx1[t] and tjek_hulleriosten[purpose,energy19,r,t]),
        tjek = tjek_hulleriosten[purpose,energy19,r,t];
        #  ABORT$(tjek <>0) tjek, "Energiforbrug optraeder for at blive udfaset og genindfaset i ENS-data. Undersoeg om det skyldes datafejl";     
        );


  #Test of tax-rate 
    $OnMultiR
    PARAMETER test_tvREmarg[purpose,energy19,r,t], test_tqREmarg[purpose,energy19,r,t];
    $OffMulti
    test_tvREmarg[purpose,energy19,r,t]$(d1qREgj[purpose,energy19,r,t])  = 0;
    test_tqREmarg[purpose,energy19,r,t]$(d1qREgj[purpose,energy19,r,t])  = 0;

    vtCalibENS.l[purpose,energy19,r,t]$(tCalibENS.l[purpose,energy19,r,t] and (d1pRE_base[purpose,energy19,r,t] or d1pREown[purpose,energy19,r,t]))
      = tCALIBENS.l[purpose,energy19,r,t] * qREgj.l[purpose,energy19,r,t];

    vtCalibENS.l[purpose,energy19,r,t]$(tCalibENS.l[purpose,energy19,r,t] and not(d1pRE_base[purpose,energy19,r,t] or d1pREown[purpose,energy19,r,t]))
      = tCalibENS.l[purpose,energy19,r,t] * qREgj.l[purpose,energy19,r,t];

    test_tvREmarg[purpose,energy19,r,t]$(tx0[t] and d1tRE[purpose,energy19,r,t] and  d1pRE_base[purpose,energy19,r,t] and pRE_base_marg.l[purpose,energy19,r,t]*qREgj.l[purpose,energy19,r,t])
                                        = tvREmarg.l[purpose,energy19,r,t]
                                        -   (vtEAFG_REmarg.l[purpose,energy19,r,t]$d1EAFG_RE[purpose,energy19,r,t] 
                                                + vtSO2_RE.l[purpose,energy19,r,t]$d1SO2_RE[purpose,energy19,r,t]
                                                + vtPSO_RE.l[purpose,energy19,r,t]$d1PSO_RE[purpose,energy19,r,t]
                                                + vtNOx_RE.l[purpose,energy19,r,t]$d1NOx_RE[purpose,energy19,r,t] 
                                                + vtCO2_REmarg.l[purpose,energy19,r,t]$d1CO2_RE[purpose,energy19,r,t] 
                                               # + vtVAT_RE.l[purpose,energy19,r,t]$d1VAT_RE[purpose,energy19,r,t] #No more VAT on the margin
                                                + vEAV_RE.l[purpose,energy19,r,t]$d1EAV_RE[purpose,energy19,r,t]
                                                + vDAV_RE.l[purpose,energy19,r,t]$d1DAV_RE[purpose,energy19,r,t]
                                                + vCAV_RE.l[purpose,energy19,r,t]$d1CAV_RE[purpose,energy19,r,t]
                                                + vtCO2_ETS_marg.l[energy19,r,t]$(d1tCO2_ETS_marg[purpose,energy19,r,t] and sameas[purpose,'in_ETS'])
                                                + vtCO2_ETS2_marg.l[purpose,energy19,r,t]$(d1CO2_ETS2_marg[purpose,energy19,r,t])
                                                + vtCalibENS.l[purpose,energy19,r,t]$(d1pREgj[purpose,energy19,r,t]))/(pRE_base_marg.l[purpose,energy19,r,t]*qREgj.l[purpose,energy19,r,t]
                                                )
                                              ;     

    test_tvREmarg[purpose,energy19,r,t]$(tx0[t] and d1tRE[purpose,energy19,r,t] and d1pREown[purpose,energy19,r,t] and qREgj.l[purpose,energy19,r,t])
                                             = tvREmarg.l[purpose,energy19,r,t]
                                               -(vtEAFG_REmarg.l[purpose,energy19,r,t]$d1EAFG_RE[purpose,energy19,r,t] 
                                                + vtSO2_RE.l[purpose,energy19,r,t]$d1SO2_RE[purpose,energy19,r,t]
                                                + vtPSO_RE.l[purpose,energy19,r,t]$d1PSO_RE[purpose,energy19,r,t]
                                                + vtNOx_RE.l[purpose,energy19,r,t]$d1NOx_RE[purpose,energy19,r,t] 
                                                + vtCO2_REmarg.l[purpose,energy19,r,t]$d1CO2_RE[purpose,energy19,r,t] 
                                               # + vtVAT_RE.l[purpose,energy19,r,t]$d1VAT_RE[purpose,energy19,r,t] #No more VAT on the margin
                                                + vEAV_RE.l[purpose,energy19,r,t]$d1EAV_RE[purpose,energy19,r,t] 
                                                + vDAV_RE.l[purpose,energy19,r,t]$d1DAV_RE[purpose,energy19,r,t]
                                                + vCAV_RE.l[purpose,energy19,r,t]$d1CAV_RE[purpose,energy19,r,t]
                                                + vtCO2_ETS_marg.l[energy19,r,t]$(d1tCO2_ETS_marg[purpose,energy19,r,t] and sameas[purpose,'in_ETS'])
                                                + vtCO2_ETS2_marg.l[purpose,energy19,r,t]$(d1CO2_ETS2_marg[purpose,energy19,r,t])
                                                + vtCalibENS.l[purpose,energy19,r,t]$(d1pREgj[purpose,energy19,r,t])
                                                )/(pREown.l[purpose,energy19,r,t]$d1pREown[purpose,energy19,r,t] * qREgj.l[purpose,energy19,r,t])
                                              ;

      test_tvREmarg[purpose,energy19,r,t]$(test_tvREmarg[purpose,energy19,r,t] and abs(test_tvREmarg[purpose,energy19,r,t])<1e-6) = 0;

#  execute_unload 'output\tjek.gdx';
      LOOP((purpose,energy19,r,t)$(tx0[t] and test_tvREmarg[purpose,energy19,r,t]),
        tjek  = test_tvREmarg[purpose,energy19,r,t];    
        ABORT$(abs(tjek)> 1e-6) tjek, "Modellens samlede energiafgifter afviger fra sin imputerede pendant";     
            );


      test_tqREmarg[purpose,energy19,r,t]$(tx0[t] and d1tRE[purpose,energy19,r,t] and not ( d1pRE_base[purpose,energy19,r,t] or d1pREown[purpose,energy19,r,t]))
                                                                       = tqREmarg.l[purpose,energy19,r,t] 
                                                                        -(vtEAFG_REmarg.l[purpose,energy19,r,t]$d1EAFG_RE[purpose,energy19,r,t] 
                                                                        + vtSO2_RE.l[purpose,energy19,r,t]$d1SO2_RE[purpose,energy19,r,t] 
                                                                        + vtCO2_REmarg.l[purpose,energy19,r,t]$d1CO2_RE[purpose,energy19,r,t] 
                                                                        + vtNOx_RE.l[purpose,energy19,r,t]$d1NOx_RE[purpose,energy19,r,t]
                                                                        + vtPSO_RE.l[purpose,energy19,r,t]$d1PSO_RE[purpose,energy19,r,t]
#                                                                          + vtVAT_RE.l[purpose,energy19,r,t]$d1VAT_RE[purpose,energy19,r,t] #No more VAT on the margin
                                                                        + vEAV_RE.l[purpose,energy19,r,t]$d1EAV_RE[purpose,energy19,r,t]
                                                                        + vDAV_RE.l[purpose,energy19,r,t]$d1DAV_RE[purpose,energy19,r,t]
                                                                        + vCAV_RE.l[purpose,energy19,r,t]$d1CAV_RE[purpose,energy19,r,t]
                                                                        + vtCO2_ETS_marg.l[energy19,r,t]$(d1tCO2_ETS_marg[purpose,energy19,r,t] and sameas[purpose,'in_ETS'])
                                                                        + vtCO2_ETS2_marg.l[purpose,energy19,r,t]$(d1CO2_ETS2_marg[purpose,energy19,r,t])
                                                                        + vtCalibENS.l[purpose,energy19,r,t]$(d1pREgj[purpose,energy19,r,t])
                                                                        )/qREgj.l[purpose,energy19,r,t];

      test_tqREmarg[purpose,energy19,r,t]$(test_tqREmarg[purpose,energy19,r,t] and abs(test_tqREmarg[purpose,energy19,r,t])<1e-6) = 0;

      LOOP((purpose,energy19,r,t)$(tx0[t] and test_tqREmarg[purpose,energy19,r,t]),
        tjek  = test_tqREmarg[purpose,energy19,r,t];    
        ABORT$(abs(tjek)> 1e-6) tjek, "Modellens samlede energiafgifter afviger fra sin imputerede pendant";     
            );


    #Test relationship between GVA and EBITDA
      $OnMultiR
      set GVA2EBITDAels/GVA, EBITDA, ETS1, ETS2, LABOR, WeirdFlow2Gov,CapitalandLandTaxes, CAP, OtherAgr, NorthSea2Gov, DistributionProfits/;
      PARAMETER GVA2EBITDA[GVA2EBITDAels,s,t], DiffEBITDA[sp,t], GVA2EBITDA_aff_sub[sp,t];
      $OffMulti

      GVA2EBITDA_aff_sub[sp,t] = sum(map_plantsectors2s(plant_sectors,sp), tAfforestationPerHa.l[plant_sectors,t] * (qLand_Nonproductive.l['skov',plant_sectors,t]-qLand_Nonproductive.l['skov',plant_sectors,t-1]));

      GVA2EBITDA['GVA',s,tx0]                    = vGrossValAdd.l[s,tx0];
      GVA2EBITDA['ETS1',s,tx0]                   = vtCO2_ETS.l[s,tx0]; #In grossvaldd we add all marginal ETS1-payments to GVA, but add all deductions on domestic CO2-tax. In EBITDA when we subtract vREa and add vtBotded and take into account vtCO2_ETSxEmarg we should get the difference
      GVA2EBITDA['ETS2',s,tx0]                   = sum((purpose,energy19)$(d1CO2_ETS2_marg[purpose,energy19,s,tx0]), vtCO2_ETS2_marg.l[purpose,energy19,s,tx0]);
      GVA2EBITDA['LABOR',sp,tx0]                 = pL.l[sp,tx0] * qL.l[sp,tx0];
      GVA2EBITDA['WeirdFlow2Gov',sp,tx0]         = (vGovReceiveFirms.l[tx0]-vGov2Firms.l[tx0])*qY.l[sp,tx0]/sum(ssp,qY.l[ssp,tx0]) 
                                                  - vSubProductionRest.l[tx0]*vY.l[sp,tx0]/sum(ssp, vY.l[ssp,tx0]); 
      GVA2EBITDA['CapitalandLandTaxes',s,tx0]    = vtLand.l[s,tx0] + vtFirmsWeight.l[s,tx0] + vtNetproductionRest.l[s,tx0];
      GVA2EBITDA['NorthSea2Gov',s,tx0]           = vGovRent.l[tx0]$(sameas[s,'0600a']);
      GVA2EBITDA['CAP',sp,tx0]                   = vtCAP.l[sp,tx0]; 
      GVA2EBITDA['OtherAgr',sp,tx0]              =  -  vtCO2_LULUCF.l[tx0]$(sameas[sp,'02000']) 
                                                    + (vtCO2_organicinproduction.l[tx0] + vtCO2_organic_outofproduction.l[tx0])$(sameas[sp,'01011']) 
                                                    -  vKompOmk.l[tx0]$(sameas[sp,'01011']) 
                                                    -vtPerHectareBottomDeduction.l[sp,tx0]$(plant_sectors_sp[sp])
                                                    + sum((ani_sectors,emmtype,animals)$(map_anisectors2s(Ani_sectors,sp) and d1EmmAgrAni[emmtype,ani_sectors,Animals,tx0,'CO2e']), vCO2_ani.l[EmmType,Ani_sectors,Animals,tx0])
                                                    + sum((plant_sectors,plant_)$(map_plantsectors2s(Plant_sectors,sp) and sum(emmtype$(emmtype2plant_[emmtype,plant_] and reguleringsgrundlag[emmtype]), d1EmmAgrxE[emmtype,plant_sectors,tx0,'CO2e'])), vCO2_plant.l[Plant_sectors,plant_,tx0])
                                                    - sum((Techani,Ani_sectors,emmtype,animals)$(map_anisectors2s(Ani_sectors,sp) and sum(emm,d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,tx0,emm])), vTech_subsidy_ani.l[techani,EmmType,Ani_sectors,Animals,tx0])
                                                    - vBotdedPerAnimal.l[sp,tx0]$(ani_sectors_sp[sp]) 
                                                    - sum((Techplant,plant_sectors,emmtype)$(map_plantsectors2s(Plant_sectors,sp) and sum(emm,d1Thetaplant[Techplant,plant_sectors,Emmtype,tx0,emm])), vTech_subsidy_plant.l[Techplant,EmmType,plant_sectors,tx0])
                                                    - GVA2EBITDA_aff_sub[sp,tx0]
                                                    + sum(ani_sectors$(map_anisectors2s(ani_sectors,sp)), sum((TechAni,Emmtype,Animals)$(sum(emm,d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,tx0,emm])), vI_EOPCostAni.l['iM',TechAni,Emmtype,ani_sectors,animals,tx0]))
                                                    + sum(plant_sectors$(map_plantsectors2s(plant_sectors,sp)), sum((TechPlant,Emmtype)$(sum(emm,d1Thetaplant[Techplant,plant_sectors,Emmtype,tx0,emm])), vI_EOPCostplant.l['iM',Techplant,Emmtype,plant_sectors,tx0]))
                                                    ;

      GVA2EBITDA['DistributionProfits',sp,tx0] = sum(energy19, vDistributionProfits_e19.l[energy19,sp,tx0]$d1vY_CET[energy19,sp,tx0]) 
                                                  +  vOtherDistributionProfits_EAV.l[tx0]$(sameas[sp,'46000']) 
                                                  +  vOtherDistributionProfits_DAV.l[tx0]$(sameas[sp,'47000'])
                                                  +  vOtherDistributionProfits_CAV.l[tx0]$(sameas[sp,'45000'])
                                                  ;


      GVA2EBITDA['EBITDA',s,tx0] = GVA2EBITDA['GVA',s,tx0] 
                                  -GVA2EBITDA['ETS1',s,tx0]
                                  -GVA2EBITDA['ETS2',s,tx0]
                                  -GVA2EBITDA['LABOR',s,tx0]
                                  -GVA2EBITDA['WeirdFlow2Gov',s,tx0]
                                  -GVA2EBITDA['CapitalandLandTaxes',s,tx0]
                                  -GVA2EBITDA['CAP',s,tx0]
                                  -GVA2EBITDA['OtherAgr',s,tx0]
                                  -GVA2EBITDA['NorthSea2Gov',s,tx0]
                                  +GVA2EBITDA['DistributionProfits',s,tx0]
                                  ;


                                  DiffEBITDA[sp,t] = GVA2EBITDA['EBITDA',sp,t] - vEBITDA.l[sp,t];

      $IF %testGVA%==1:
        LOOP((sp,t)$(tx0[t] and not sameas[sp,'51001']), #For 51001 there needs to be done a correction for bottom deductions
          tjek = GVA2EBITDA['EBITDA',sp,t] - vEBITDA.l[sp,t];
          ABORT$(abs(tjek)> 1e-5) tjek, "The relationship between GVA and EBITDA is not consistent with EBITDA-breakdown in sanitychecks.gms. Update the break-down for consistent reporting"; 
          );
       $ENDIF
      #Test relationship between GVA and bottom-up computed GVA 
      $OnMultiR
      PARAMETER vGrossValAdd_bu[sp,t], Diff_vGrossValAdd[s,t];
      $OffMulti

      vGrossValAdd_bu[sp,t]$(tx0[t])             = sum(k$d1K[k,sp,t-1], pK.l[k,sp,t] *qK.l[k,sp,t-1]/fq)     #Capital
                                                 - pKELBM.l[sp,t] * sum(k$d1K[k,sp,t], qKInstCost.l[k,sp,t]) #Capital
                                                 + GVA2EBITDA['LABOR',sp,t]                                  #Labour
                                                 + sum(out$(d1vY_CET[out,sp,t]), pY_CET.l[out,sp,t] * (qY_CET.l[out,sp,t]$(not sameas[sp,'19000']) + qY_CETgross.l[out,sp,t]$(sameas[sp,'19000']))) - pY0.l[sp,t]*qY.l[sp,t] #Value of mark-up
                                                 + (pRE_NatGasNL.l[t]*qRE_NatGasNL.l[t])$(sameas[sp,'35011'] and t.val <= 2019)                                              #Natural gas Ørsted joint-venture in Netherlands
                                                 + (pXE_bionatgas.l[t] * qXE_bionatgas.l[t])$(sameas[sp,'35002'])
                                                 + sum((purpose,energy19)$(d1tRE[purpose,energy19,sp,t]), tCALIBENS.l[purpose,energy19,sp,t]*qREgj.l[purpose,energy19,sp,t]) #Energy-expenses in calibration to ENS not accounted for in production-function
                                                 + GVA2EBITDA['ETS1',sp,t] #Expenses to ETS1 
                                                 + GVA2EBITDA['ETS2',sp,t] #Expenses to ETS2
                                                 + vtCAP_top.l[sp,t]       #Not all CAP is in this GVA-parity as most of CAP is non-production related
                                                 + vtNetproductionRest.l[sp,t] #Production taxes and subsidies in production function, not accounted for in user- or labor-cost.
                                                 - (sum((energy19,purpose)$(d1vLE[purpose,energy19,t] and not tDataEnd[t]), vLE.l[purpose,energy19,t])* vY.l[sp,t] /sum(TheBig7, vY.l[TheBig7,t]))$(TheBig7[sp])
                                                 ; 

      Diff_vGrossValAdd[sp,t] = vGrossValAdd_bu[sp,t] - vGrossValAdd.l[sp,t];

  # display Diff_vGrossValAdd;     


      $IF %testGVA%==1:
        LOOP((sp,t)$(tx0[t] and not agri_sectors[sp] and not sameas[sp,'0600a'] and not sameas[sp,'51001']),
        tjek = vGrossValAdd_bu[sp,t] - vGrossValAdd.l[sp,t];
        # execute_unload 'output\sanitycheck.gdx';
        # ABORT$(abs(tjek)> 1e-5) tjek, "Testing GVA bottom-up versus the models top-down computation in sanitychecks.gms breaks down. Update the break-down for consistent reporting"; 
        );
      $ENDIF
  
    #Decompebitda

    $OnMultiR
    set setreportEBITDA/vY, vRxE, vFin, vExCO2, vL, vtCO2, vtCO2_ETS, vtNetProductionSubsidiesAndTaxes, vDistributionProfits, EBITDA, CCS/; 
    parameter reportEBITDA[setreportEBITDA,sp,t], reportEBITDA_relative[setreportEBITDA,sp,t];
    $OffMulti

    reportEBITDA['vY',sp,t]$(tx0[t])      = vY.l[sp,t];
    reportEBITDA['vRxE',sp,t]$(tx0[t])    = vRxE.l[sp,t];
    reportEBITDA['vFin',sp,t]$(tx0[t])    = vFin.l[sp,t];
    reportEBITDA['vExCO2',sp,t]$(tx0[t])  = sum((purpose,energy19)$(d1pREa[purpose,energy19,sp,t]), vREa.l[purpose,energy19,sp,t])  #Energy-expenses #(v)
                                          + sum((purpose,energy19)$(d1VAT_RE[purpose,energy19,sp,t]), vtVAT_RE.l[purpose,energy19,sp,t]) #VAT on energy
                                          - sum((purpose,energy19)$(d1tRE[purpose,energy19,sp,t]), tCALIBENS.l[purpose,energy19,sp,t]*qREgj.l[purpose,energy19,sp,t]) #(v)
                                          #Subtract difference between margin and average prices
                                          - sum((purpose,energy19)$(d1pRE_base[purpose,energy19,sp,t]),
                                              (pRE_base_marg.l[purpose,energy19,sp,t]-pRE_base.l[purpose,energy19,sp,t])*qREgj.l[purpose,energy19,sp,t])
                                          -sum(energy19,  vtCO2_ETS_marg.l[energy19,sp,t]$(d1tCO2_ETS_marg['in_ETS',energy19,sp,t])) 
                                          -sum((purpose,energy19)$(d1CO2_RE[purpose,energy19,sp,t]), vtCO2_REmarg.l[purpose,energy19,sp,t])
                                          ;

    reportEBITDA['vL',sp,t]$(tx0[t])      = w.l[t]*qL.l[sp,t];
    reportEBITDA['vtCO2',sp,t]$(tx0[t])   = sum((purpose,energy19)$(d1CO2_RE[purpose,energy19,sp,t]),    vtCO2_RE.l[purpose,energy19,sp,t]) 
                                           +sum(emm$(d1EmmProdxE[sp,t,emm] and d1CO2_ProdxE[sp,t,emm]),  vtCO2_ProdxE.l[sp,t,emm]);
    reportEBITDA['vtCO2_ETS',sp,t]$(tx0[t] and d1CO2_ETS[sp,t]) = vtCO2_ETS.l[sp,t]; 

    reportEBITDA['CCS',sp,t]$(tx0[t]) =
                    -sum((purpose,energy19a,emm)$(sum(energy19, d1qREE[purpose,energy19a,energy19,sp,t] and sum(techCCS, d1thetaCCS[techCCS,purpose,energy19,sp,t,emm])) and (sameas[emm,'CO2ubio'] or sameas[emm,'CO2bio'])), 
                                              qLEVC_CCS_EmmE_RE.l[purpose,energy19a,sp,t,emm]*pI_s.l['iM',sp,t]) # Levelized investments on energy CCS should be added, as it enters in vREa above
                    + qI_CCS_actual.l['iM',sp,t]*pI_s.l['iM',sp,t]$(sum((techCCS,purpose,energy19,tt,emm), d1thetaCCS[techCCS,purpose,energy19,sp,tt,emm]) or sum((techCCS,tt,emm), d1thetaCCSxE[techCCS,sp,tt,emm])) # Actual investments on both energy and non-energy CCS
                    + sum(emm$(d1EmmProdxE[sp,t,emm] and sum(techCCS, d1thetaCCSxE[techCCS,sp,t,emm]) and sameas[emm,'CO2ubio']), - vSubsidy_CCS_EmmxE.l[sp,t,emm])   # Subsidy for non-energy related CCS does not enter above         
                    #When deducting vREa (above) we subtract marginal prices. Here we add the marginal prices back, and subtract the average prices.
                      ;

    reportEBITDA['vtNetProductionSubsidiesAndTaxes',sp,t]$(tx0[t]) = (  vtLand.l[sp,t]
                                                                   + vtLPayRoll.l[sp,t]
                                                                   + vtFirmsWeight.l[sp,t]
                                                                   + vtLAM.l[sp,t] 
                                                                   + vtNetProductionRest.l[sp,t]
                                                                   + vtCAP.l[sp,t]$(agri_sectors[sp]) #The CAP is measured with negative sign and thus contributes positively to the result
                                                                   - vtLSubsidy.l[sp,t]
                                                                   + (vGovReceiveFirms.l[t]-vGov2Firms.l[t])*qY.l[sp,t]/sum(ssp,qY.l[ssp,t])
                                                                   - vSubProductionRest.l[t]*vY.l[sp,t]/sum(ssp, vY.l[ssp,t])
                                                                   + vGovRent.l[t]$(sameas[sp,'0600a']) 
                                                                   - vtCO2_LULUCF.l[t]$(sameas[sp,'02000']) #We assume (at least starting out) that the forrest is planted on conventional land. 
                                                                    # Instead, it is uncluded as fully CAP-funded - i.e., it falls under the vtCAP
                                                                   - vKompOmk.l[t]$(sameas[sp,'01011']) #Compensation for lowland withdrawal (Kompensation for udtagning af lavbund). 
                                                                   + (vtCO2_organicinproduction.l[t] + vtCO2_organic_outofproduction.l[t])$(sameas[sp,'01011'])
                                                                   - vtPerHectareBottomDeduction.l[sp,t]$(plant_sectors_sp[sp])
                                                                   - sum(map_plantsectors2s(plant_sectors,sp), tAfforestationPerHa.l[plant_sectors,t] * (qLand_Nonproductive.l['skov',plant_sectors,t]-qLand_Nonproductive.l['skov',plant_sectors,t-1]))

                                                                   );


    reportEBITDA['vDistributionProfits',sp,t]$(tx0[t]) = sum(energy19, vDistributionProfits_e19.l[energy19,sp,t]$d1vY_CET[energy19,sp,t]);

    reportEBITDA['EBITDA',sp,t]$(tx0[t]) = reportEBITDA['vY',sp,t] + reportEBITDA['vDistributionProfits',sp,t]
                                          -reportEBITDA['vRxE',sp,t]
                                          -reportEBITDA['vFin',sp,t]
                                          -reportEBITDA['vExCO2',sp,t]
                                          -reportEBITDA['vtCO2',sp,t]
                                          -reportEBITDA['vtCO2_ETS',sp,t]
                                          -reportEBITDA['CCS',sp,t]
                                          -reportEBITDA['vL',sp,t]
                                          -reportEBITDA['vtNetProductionSubsidiesAndTaxes',sp,t];

    LOOP((t,sp)$(tx1[t] and sameas[sp,'19000']),
     tjek = vEBITDA.l[sp,t] - reportEBITDA['EBITDA',sp,t];
     ABORT$(abs(tjek)> 1e-4) tjek, "EBITDA breakdown for refineries does not hold"; 
     );

    reportEBITDA_relative[setreportEBITDA,sp,t]$(tx0[t]) = reportEBITDA[setreportEBITDA,sp,t] - reportEBITDA[setreportEBITDA,sp,'2019'];
  
  #parameter
    #  $OnMultiR
    #  set taxelements/EAFG,SO2,PSO,NOx,CO2_REmarg,VAT,EAV,DAV,CAV,ETS,AV/;
    #  $PGROUP PG_tjekpriser tjek_priser[purpose,energy19,r,t,taxelements];
    #  $OffMulti

    #  tjek_priser[purpose,energy19,r,t,taxelements] = 0;

    #  #  tjek_priser[purpose,energy19,r,t,taxelements]$(tx0[t] and not d1qREgj[purpose,energy19,r,t]) = 0;
    #  tjek_priser[purpose,energy19,r,t,'EAFG']$(t.val=2030 and d1EAFG_RE[purpose,energy19,r,t] and d1qREgj[purpose,energy19,r,t]) = vtEAFG_REmarg.l[purpose,energy19,r,t]/qREgj.l[purpose,energy19,r,t];
    #  tjek_priser[purpose,energy19,r,t,'SO2']$(sameas[t,'2030'] and d1SO2_RE[purpose,energy19,r,t] and d1qREgj[purpose,energy19,r,t])   = vtSO2_RE.l[purpose,energy19,r,t]/qREgj.l[purpose,energy19,r,t];
    #  tjek_priser[purpose,energy19,r,t,'PSO']$(sameas[t,'2030'] and d1PSO_RE[purpose,energy19,r,t] and d1qREgj[purpose,energy19,r,t])   = vtPSO_RE.l[purpose,energy19,r,t]/qREgj.l[purpose,energy19,r,t];
    #  tjek_priser[purpose,energy19,r,t,'NOx']$(sameas[t,'2030'] and d1NOx_RE[purpose,energy19,r,t] and d1qREgj[purpose,energy19,r,t])   = vtNOx_RE.l[purpose,energy19,r,t]/qREgj.l[purpose,energy19,r,t];
    #  tjek_priser[purpose,energy19,r,t,'CO2_REmarg']$(sameas[t,'2030'] and d1CO2_RE[purpose,energy19,r,t] and d1qREgj[purpose,energy19,r,t]) = vtCO2_REmarg.l[purpose,energy19,r,t]/qREgj.l[purpose,energy19,r,t];
    #  tjek_priser[purpose,energy19,r,t,'VAT']$(sameas[t,'2030'] and d1VAT_RE[purpose,energy19,r,t] and d1qREgj[purpose,energy19,r,t])   = vtVAT_RE.l[purpose,energy19,r,t]/qREgj.l[purpose,energy19,r,t];
    #  tjek_priser[purpose,energy19,r,t,'EAV']$(sameas[t,'2030'] and d1EAV_RE[purpose,energy19,r,t] and d1qREgj[purpose,energy19,r,t])   = vEAV_RE.l[purpose,energy19,r,t]/qREgj.l[purpose,energy19,r,t];
    #  tjek_priser[purpose,energy19,r,t,'DAV']$(sameas[t,'2030'] and d1DAV_RE[purpose,energy19,r,t] and d1qREgj[purpose,energy19,r,t])   = vDAV_RE.l[purpose,energy19,r,t]/qREgj.l[purpose,energy19,r,t];
    #  tjek_priser[purpose,energy19,r,t,'CAV']$(sameas[t,'2030'] and d1CAV_RE[purpose,energy19,r,t] and d1qREgj[purpose,energy19,r,t])   = vCAV_RE.l[purpose,energy19,r,t]/qREgj.l[purpose,energy19,r,t];
    #  tjek_priser[purpose,energy19,r,t,'ETS']$(sameas[t,'2030'] and d1tCO2_ETS_marg[purpose,energy19,r,t] and sameas[purpose,'in_ETS'] and d1qREgj[purpose,energy19,r,t]) = vtCO2_ETS_marg.l[energy19,r,t]/qREgj.l[purpose,energy19,r,t]; 
    #  tjek_priser[purpose,energy19,r,t,'AV']$(sameas[t,'2030'] and d1qREgj[purpose,energy19,r,t]) = (vEAV_RE.l[purpose,energy19,r,t]$d1EAV_RE[purpose,energy19,r,t] + vDAV_RE.l[purpose,energy19,r,t]$d1DAV_RE[purpose,energy19,r,t] + vCAV_RE.l[purpose,energy19,r,t]$d1CAV_RE[purpose,energy19,r,t])
    #      / qREgj.l[purpose,energy19,r,t]; 
     

    #  $IF %postCalibKF%:
    #    $PGROUP PG_checktpREgj
    #               imputedprice_agg[GSR_ag,t],  marginalpricesENS_mapped_ag[GSR_ag,t], 
    #               imputedprice_agg_full[GSR_ag,purpose,energy19,r,t]
    #    ;



    #  $ENDIF
