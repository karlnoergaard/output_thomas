# ======================================================================================================================
# 1) Settings
# ======================================================================================================================
# In this file we control major settings:
# - Module files to include
# - Data sources

# - Growth and inflation adjustment
# - Years where model should be calibrated

# The remaining model runs in the following order:
# 2) sets.gms
# 3) Data.gms - import and arrange data
# 4) Model.gms
#   4.1) Define variables
#   4.2) Define equations
#   4.3) Set exogenous values assigning data to variables
# 5) static_calibration.gms - Calibrate most model parameters to fit data
# 7) dynamic_calibration.gms - calibration of parameters that depend on expectations

# ======================================================================================================================
# Moduler
# ======================================================================================================================
# Funktion til at importere fra hvert modul
$FUNCTION import_from_modules(stage_key):
  $SETGLOBAL stage stage_key;
  $IMPORT aggregates.gms;
  $IMPORT energy_markets.gms;
  $IMPORT IO.gms;
  $IMPORT taxes.gms;
  $IMPORT taxes_energy.gms;
  $IMPORT exports.gms;
  $IMPORT labor_market.gms;
  $IMPORT production_private.gms;
  $IMPORT production_public.gms;
  $IMPORT consumers.gms;
  $IMPORT government.gms;
  $IMPORT emissions.gms;
  $IMPORT abatement.gms;
  $IMPORT production_agr_ani.gms;
  $IMPORT production_agr_plant.gms;
  $IMPORT production_agr.gms;
  $IMPORT waste.gms;
  $IMPORT lulucf.gms;
  $IMPORT leakage.gms;
  $IMPORT udvaskning.gms;
  $IMPORT Pyrolyse.gms;
$ENDFUNCTION

# ======================================================================================================================
# Skalering
# ======================================================================================================================

PARAMETERS 
  correction_factor_values /1000000/
  correction_factor_joule /1000000/
  correction_factor_pop /1/ 
  correction_factor_investment /1/
  correction_factor_values_up /1/ #For MAKRO data we don't scale because data is already in billions
;

$SETGLOBAL modelinmillions 0

$IF %modelinmillions%:
  correction_factor_values = 1000;
  correction_factor_joule  = 100000;
  correction_factor_pop    = 1000;
  correction_factor_investment = 1000;
  correction_factor_values_up  = 1000;
$ENDIF


# ======================================================================================================================
# Growth and inflation adjustment
# ======================================================================================================================
parameters
  gq "Rate of growth (labor-augmenting technological progress rate)" /0.01/
  gp "Rate of foreign inflation" /0.018/
  #  gp /0.0175/
;

# ======================================================================================================================
# Small cells
# ======================================================================================================================

  parameter min_cell_size;
  min_cell_size = 0.00001; #Minimum 10K kroner

# ======================================================================================================================
# Model testing
# ======================================================================================================================

PARAMETER tjek;

# ======================================================================================================================
# Sets
# ======================================================================================================================
# ----------------------------------------------------------------------------------------------------------------------
# Time periods
# ----------------------------------------------------------------------------------------------------------------------
$SETGLOBAL base_year 2019 # Basis year for growth and inflation adjustments
$SETGLOBAL cal_start 2018 # Calibration start year
$SETGLOBAL cal_end 2019 # Last calibration year
$SETGLOBAL terminal_year 2099 # The terminal year

$SETGLOBAL bf_start     1990 # First year of energy outlook ("basisfremskrivningen")
$SETGLOBAL bf_end       2035 # Last year of energy outlook ("basisfremskrivningen")

$SETGLOBAL forest_data  2020  # Initial year of forest data
$SETGLOBAL forest_model 2021 #First year of forest model
$SETGLOBAL forest_model_increment 5 # Time increment of forest model (years)

$SETGLOBAL CRF_start       1990     # Initial year of CRF table data
$SETGLOBAL CRF_end         2019     # Final year of CRF table data

$SETGLOBAL BF_calib_start 2019 #First year of energy outlook ("basisfremskrivningen") we calibrate energy production and use to
$SETGLOBAL BF_calib_end   2050 #Last year of energy outlook ("basisfremskrivningen") we calibrate energy production and use to
$SETGLOBAL BF_calib_prices_start 2020  #First year of energy outlook ("basisfremskrivningen") we calibrate energy prices to
$SETGLOBAL BF_calib_prices_end 2050  #First year of energy outlook ("basisfremskrivningen") we calibrate energy prices to

# ======================================================================================================================
# Data-check
# ======================================================================================================================

$SETGLOBAL tolerance_data 1e-6

PARAMETER tjek;

# ======================================================================================================================
# Set data path for calibration of macro-economic variables to external forecast
# ======================================================================================================================

#The user can choose between the official macro-economic forecast from the Ministry of Finance called 'Konvergensprogram' or alternatively to a forecast from the beta version of MAKRO 
$SETGLOBAL MACRODATA "../Data/MAKRO/konjunktur_juni2025.gdx"        #Set path for external forecast
$SETGLOBAL MACRODATA2 "../Data/MAKRO/konjunktur_juni2025.gdx"       #Set path for external forecast for variables not in kp21
$SETGLOBAL calib2KP 0 # 1 if KP21-data is used. 0 if real MAKRO-data is used 

# ======================================================================================================================
# Set data path for marginal tax-rates
# ======================================================================================================================

#The user can choose between the official macro-economic forecast from the Ministry of Finance called 'Konvergensprogram' or alternatively to a forecast from the beta version of MAKRO 
$SETGLOBAL MargTaxesBefore2022 ../Data\Energiafgifter_marginal/SKM_base_old_lobende_priser_v2_korrElAfgift       
$SETGLOBAL MargTaxesAfter2022 ../Data\Energiafgifter_marginal/Kopi_af_SKM_base_old_lobende_priser_v2_REFORM   
$SETGLOBAL MargTaxesAfter2022Corrected ../Data/Energiafgifter_marginal/Kopi_af_SKM_base_old_lobende_priser_v2_REFORM_korrFiskogIndenrigsfaerger 

# ======================================================================================================================
# Bottom deduction on CO2-emissions after 2025 (this options is used to re-introduce bottom deductions on CO2-tax if we roll back 2022-reform on industry. See taxes.gms for application)
# ======================================================================================================================
 
parameter d1BotdedCO2post25;
d1BotdedCO2post25=1; #Because of calibration issues this is initially set to 1, but switched to zero in Calibrate2ENS 

# ======================================================================================================================
# Calibration to previous solution?
# ======================================================================================================================

$SETGLOBAL readfromprevious 0     #Before committing to master please set this to zero and run the entire calibration
$SETGLOBAL readfromprevious_KF22 0 #We have a specific previous solution for calibration to KF22 that can be turned on
$SETGLOBAL pathvbop ../Data/cal_dyn_load/vBoP_previous.gdx


# ======================================================================================================================
# Calibrate with elasticiteties from Fontagne et al. from GSR-work   
# ======================================================================================================================

$SETGLOBAL FontagneGSR 1

# ======================================================================================================================
# Set this option to 1 if you want exports to react rigidly to changes in export-prices (in baseline there is no rigidity) 
# ======================================================================================================================

$SETGLOBAL rigid_export 0

# ======================================================================================================================
# Set this option to 1 if you want pig production to be split in (01051 = Piglets and Pigssows/ 01052 = Pigs fattening), in contrast to con/org  
# ======================================================================================================================

$SETGLOBAL smaagrisesplit 1

# ======================================================================================================================
# AP-baseline   
# ======================================================================================================================

$SETGLOBAL shockAP 0

# ======================================================================================================================
# Dummy used report to be turned on when shocking the model to appropriately calculate reporting parameters   
# ======================================================================================================================

$SETGLOBAL shockmodel 0
$SETGLOBAL sanitycheckendoland 0

# ======================================================================================================================
# Setting used to turn on GVA-test   
# ======================================================================================================================

$SETGLOBAL testGVA 1

# ======================================================================================================================
# Import of functions used in various parts of the model
# ======================================================================================================================

$import functions.gms

# ======================================================================================================================
# GAMS options
# ======================================================================================================================
$OFFDIGIT

# LST output options
OPTION
  SYSOUT=OFF
  SOLPRINT=OFF
  LIMROW=0
  LIMCOL=0
  DECIMALS=6
;

# Solve options
OPTION
  DOMLIM=0  # Number of domain error ignored
  SOLVELINK=5  # Keep model in memory instead of using temporary files (quicker for solving many smaller models)
  CNS=CONOPT4  # Choose solver
  NLP=CONOPT4  # Choose solver
;

# ======================================================================================================================
# Solver options
# ======================================================================================================================
$ONECHO > conopt4.opt
  #  Keep searching for a solution even if a bound is hit (due to non linearities)
  lmmxsf = 1

  #  Time limit in seconds
  rvtime = 1000000
  reslim = 1000000

  #  Optimality tolerance for reduced gradient
  RTREDG = 1.e-9

  #  Absolute pivot tolerance, Range: [2.2e-16, 1.e-7], Default: 1.e-10
  #  RTPIVA = 1.e-15

  #  Relative pivot tolerance during basis factorizations, Range: [1.e-3, 0.9], Default: 0.05
  #  RTPIVR = 1.e-3

  #  Multi-threating
  Threads=8
  THREADF=8

  #Turn of autosv
  #Frq_Rescale = 0
$OFFECHO

