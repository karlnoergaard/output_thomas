#Template for creating new shocks to the model

$GROUP G_exo 
  G_exo 
  #Add any new exogenous variables 

;

$GROUP G_endo 
  G_endo 
  #Add any new endogenous variables
;

#Setting up shock-model
$MODEL M_shock_template
  M_CO2tax
  #If you have new equations to add, add them to your model here
;

#If you want to adjust an exogenous variable change its level here:
# ExampleVariable.l[t] = 2500; #This example sets the example-variable at 2500. 

$FIX G_exo;
$UNFIX G_endo;
@SOLVE(M_CO2tax);
$import sanitycheck.gms
$import report_all.gms
execute_unload 'output\shock_template.gdx';

