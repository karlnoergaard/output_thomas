# ======================================================================================================================
# Static calibration
# ======================================================================================================================

$GROUP G_save_for_squareness_test
  G_endo 
  G_exo 
  G_dynamic_calibration_endo
  G_dynamic_calibration_exo
  G_static_calibration
  G_static_calibration_exo
;

@Save(G_save_for_squareness_test);

  $FUNCTION assert_modularity({group_exo},{group_endo},{model},{testoverexo}):

  
    $SETGLOBAL tolerance_overexogenization 1000
    #We use these dummy-equations to set up an DNLP for test of over-exogenization
    $OnMultiR
    variables xobj;
    $BLOCK B_obj
    EQ_obj.. xobj =e= 0 ;
    $ENDBLOCK
    $OffMulti
    
    $GROUP G_donotchecktheseforoverexogenization
      #Exogenous variables without dimensions. Makes test break down so they are removed
      eCE 
      eX_tur
      eHt
      uIDbeta
      uCCSbeta
      eC_R
      pDeath
      JvWealth_LongTerm
      JvWealth_MediumTerm
      JvWealth_MediumLongTerm

    ;

    $FIX {group_exo};
    $UNFIX {group_endo};
    @SOLVE({model});
    $UNFIX {group_exo};
   
      #If test of over-exogenization is turned on
      $IF ({testoverexo}=='testoverexo'):
          $OnMultiR
          $MODEL {model}_test_overexo
            {model}
            B_obj
          ;
          #Set save-point option 
          {model}_test_overexo.savePoint = 1;
          $OffMulti

        #Save variable values so as to reset them after test for over-exogenization
        # @Save({group_endo}); 
        # @Save({group_exo});

        #Solve model with save-point. The savepoint-gdx now contains all variables that enter model equations
        # execute_unload '{model}_test_overexo_p.gdx' obj.l;
        Solve {model}_test_overexo using DNLP maximizing xobj;

        #Remove all values in exo-group
        $LOOP {group_exo}:
        option clear={name}; 
        $ENDLOOP

       # We load the save-point gdx file, which contains all variables that enter model equations
        execute_loadpoint '{model}_test_overexo_p.gdx';

        #We now create parameters based on the exo-group with suffix "true_exo"
        $LOOP {group_exo}:
            parameter {name}_true_exo{sets};
        $ENDLOOP

        #We transfer all variable marginals (marginals for zero-entries) or levels into the "true_exo"-parameters
        $LOOP {group_exo}:
            {name}_true_exo{sets}$({subsets}) = {name}.m{sets} or {name}.l{sets};
        $ENDLOOP

        #We now reset variable values (the exo-group namely is important for this check, the endo-group is reset as well for the sake of running the rest of this file)
        $LOOP {group_endo}: {name}.l{sets} = {name}_saved{sets}; $ENDLOOP 
        $LOOP {group_exo}: {name}.l{sets} = {name}_saved{sets};  $ENDLOOP
        #  @reset({group_endo}); $FIX {group_endo};
        #  @reset({group_exo});  $FIX {group_exo};
      
        $GROUP G_{group_exo}_loop
          {group_exo}
          -G_donotchecktheseforoverexogenization
        ;

        #We now check which variables are in the exo-group but are not truly exogenous in the model equations
          $LOOP G_{group_exo}_loop:
            $OnMultiR
            parameter {name}_check_exo{sets}, count_overexo_elements;
            $OffMulti
            count_overexo_elements = no; #Resetting counter

            #Inserting all elements in exo-group that are not not truly exogenous.
            {name}_check_exo{sets}$({subsets} and not {name}_true_exo{sets}) = {name}.l{sets};
            display {name}_check_exo; #Displaying over-exogenized elements

            #Counting number of over-exogenized elements
            count_overexo_elements = sum({sets}$({name}_check_exo{sets}), 1${name}_check_exo{sets});
            display count_overexo_elements; #Displaying counter

            if (count_overexo_elements>%tolerance_overexogenization%,
                loop({sets}${subsets},
                  abort$({subsets} and not {name}_true_exo{sets}) '{name} is over-exogenized in {group_exo} in {model}';
                ));
            $ENDLOOP

        execute 'rm -f {model}_test_overexo_p.gdx';
      $ENDIF
  $ENDFUNCTION 

# ======================================================================================================================
# Static calibration
# ======================================================================================================================

	# ----------------------------------------------------------------------------------------------------------------------
	# Set time periods
	# ----------------------------------------------------------------------------------------------------------------------

	  set_time_periods(%cal_start%, %cal_end%);
	  set_bf_calib_periods(%BF_calib_start%,%BF_calib_end%, %BF_calib_prices_start%,%BF_calib_prices_end%);
	  set_lulucf_periods(1990,2099,2021,2099);

	# ----------------------------------------------------------------------------------------------------------------------
	# Solve models
	# ----------------------------------------------------------------------------------------------------------------------

		$UNFIX G_static_calibration_exo, G_static_calibration;
		$UNFIX G_dynamic_calibration_exo, G_dynamic_calibration_endo;

		#Note: Production og production_agr kan ikke testes pt. fordi j-led-ligninger udskiftes. Find en måde at håndtere...
		@assert_modularity(G_taxes_static_calibration_exo,G_taxes_static_calibration,M_taxes_static_calibration,'testoverexo'); # 0
		@assert_modularity(G_taxes_energy_static_calibration_exo,G_taxes_energy_static_calibration,M_taxes_energy_static_calibration,'testoverexo'); # 0
		@assert_modularity(G_exports_static_calibration_exo,G_exports_static_calibration,M_exports_static_calibration,'testoverexo'); # 0
		@assert_modularity(G_labor_market_static_calibration_exo,G_labor_market_static_calibration,M_labor_market_static_calibration,'testoverexo'); # 0
		@assert_modularity(G_consumers_static_calibration_exo,G_consumers_static_calibration,M_consumers_static_calibration,'testoverexo');
		@assert_modularity(G_Government_static_calibration_exo,G_Government_static_calibration,M_Government_static_calibration, 'testoverexo');	# 0	
 		@assert_modularity(G_IO_static_calibration_exo,G_IO_static_calibration,M_IO_static_calibration,'donttestoverexo');
		@assert_modularity(G_aggregates_static_calibration_exo,G_aggregates_static_calibration,M_aggregates_static_calibration, 'testoverexo');
 		@assert_modularity(G_emissions_static_calibration_exo,G_emissions_static_calibration,M_emissions_static_calibration,'donttestoverexo');
		@assert_modularity(G_abatement_static_calibration_exo,G_abatement_static_calibration,M_abatement_static_calibration,'donttestoverexo');
#  		@assert_modularity(G_production_private_static_calibration_exo,G_production_private_static_calibration,M_production_private_static_calibration,'donttestoverexo');
 		#  @assert_modularity(G_production_agr_static_calibration_exo,G_production_agr_static_calibration,M_production_agr_static_calibration,'donttestoverexo');
		@assert_modularity(G_waste_static_calibration_exo,G_waste_static_calibration,M_waste_static_calibration,'donttestoverexo');
		@assert_modularity(G_leakage_static_calibration_exo,G_leakage_static_calibration,M_leakage_static_calibration,'donttestoverexo');	
		#  @assert_modularity(G_lulucf_static_calibration_exo,G_lulucf_static_calibration,M_lulucf_static_calibration,'donttestoverexo');
		@assert_modularity(G_udvaskning_static_calibration_exo,G_udvaskning_static_calibration,M_udvaskning_static_calibration,'donttestoverexo');		
		@assert_modularity(G_energy_markets_static_calibration_exo,G_energy_markets_static_calibration,M_energy_markets_static_calibration,'testoverexo');	
		

 		
 			
		



 # ======================================================================================================================
 # Dynamic calibration
 # ======================================================================================================================

 	# ----------------------------------------------------------------------------------------------------------------------
 	# Set time periods
 	# ----------------------------------------------------------------------------------------------------------------------

 		set_time_periods(%cal_start%, %terminal_year%);

 	# ----------------------------------------------------------------------------------------------------------------------
 	# Solve models
 	# ----------------------------------------------------------------------------------------------------------------------

		$UNFIX G_dynamic_calibration_exo, G_dynamic_calibration_endo;
		@assert_modularity(G_taxes_calib_exo,G_taxes_calib,M_taxes_calib,'testoverexo'); # 0
		@assert_modularity(G_taxes_energy_calib_exo,G_taxes_energy_calib,M_taxes_energy_calib,'testoverexo'); # 0
		@assert_modularity(G_exports_calib_exo,G_exports_calib,M_exports_calib,'testoverexo'); #0
		@assert_modularity(G_labor_market_calib_exo,G_labor_market_calib,M_labor_market_calib,'testoverexo'); # 0
		@assert_modularity(G_consumers_calib_exo,G_consumers_calib,M_consumers_calib,'testoverexo');
		@assert_modularity(G_Government_calib_exo,G_Government_calib,M_Government_calib,'testoverexo');	# 0
		@assert_modularity(G_IO_calib_exo,G_IO_calib,M_IO_calib,'donttestoverexo');
		@assert_modularity(G_aggregates_calib_exo,G_aggregates_calib,M_aggregates_calib,'testoverexo');
		@assert_modularity(G_emissions_calib_exo,G_emissions_calib,M_emissions_calib,'donttestoverexo');
		@assert_modularity(G_abatement_calib_exo,G_abatement_calib,M_abatement_calib,'donttestoverexo');
		# @assert_modularity(G_production_private_calib_exo,G_production_private_calib,M_production_private_calib,'donttestoverexo');
		# @assert_modularity(G_production_agr_calib_exo,G_production_agr_calib,M_production_agr_calib,'donttestoverexo');
		@assert_modularity(G_waste_calib_exo,G_waste_calib,M_waste_calib,'testoverexo');	# 0 
		@assert_modularity(G_leakage_calib_exo,G_leakage_calib,M_leakage_calib,'donttestoverexo');
		# @assert_modularity(G_lulucf_calib_exo,G_lulucf_calib,M_lulucf_calib,'donttestoverexo');
		@assert_modularity(G_udvaskning_calib_exo,G_udvaskning_calib,M_udvaskning_calib,'donttestoverexo');
		@assert_modularity(G_energy_markets_calib_exo,G_energy_markets_calib,M_energy_markets_calib,'testoverexo');
		



#  		#  @assert_modularity(G_partial_plus_exo,G_partial_plus_endo,M_partial_plus,1);


		#Testing that the 	
		#  set_time_periods(%cal_start%, 2025); 

		#  @assert_modularity(G_dynamic_calibration_exo_saved, G_dynamic_calibration_endo_saved,M_dynamic_calibration_xlulucf);

		#  set_time_periods(%cal_start%, 2051); 

		#  @assert_modularity(G_dynamic_calibration_exo_saved, G_dynamic_calibration_endo_saved,M_dynamic_calibration_xlulucf);

		#  set_time_periods(%cal_start%, %terminal_year%);



# ======================================================================================================================
# Zero-shocks
# ======================================================================================================================

	#We test zero-shocks at three points in time. Last data year, 2024 and 2030
	
		# #Last data year
		set_time_periods(%cal_start%, %terminal_year%);
			$UNFIX G_exo, G_endo;
			@assert_modularity(G_taxes_bottom_exo,G_taxes_bottom_endo,M_taxes_bottom,'testoverexo'); # 0
			@assert_modularity(G_taxes_total_exo,G_taxes_total_endo,M_taxes_total,'testoverexo'); # 0
			@assert_modularity(G_taxes_energy_exo,G_taxes_energy_endo,M_taxes_energy,'testoverexo'); # 0
			@assert_modularity(G_exports_exo,G_exports_endo,M_exports,'testoverexo'); # 0
			@assert_modularity(G_labor_market_exo,G_labor_market_endo,M_labor_market,'testoverexo'); # 0
			@assert_modularity(G_consumers_exo,G_consumers_endo,M_consumers,'testoverexo');
			@assert_modularity(G_Government_exo,G_government_endo,M_government, 'testoverexo');		# 0
			@assert_modularity(G_IO_exo,G_IO_endo,M_IO,'donttestoverexo');
			@assert_modularity(G_aggregates_exo,G_aggregates_endo,M_aggregates,'testoverexo');
			@assert_modularity(G_emissions_exo, G_emissions_endo,M_emissions,'donttestoverexo');
			@assert_modularity(G_abatement_exo,G_abatement_endo,M_abatement,'donttestoverexo');
			#  @assert_modularity(G_production_private_exo,G_production_private_endo,M_production_private,'donttestoverexo');
			#  @assert_modularity(G_production_agr_exo,G_production_agr_endo,M_production_agr);
			@assert_modularity(G_waste_exo,G_waste_endo,M_waste,'testoverexo');	# 0
			@assert_modularity(G_leakage_shock_exo,G_leakage_shock_endo,B_leakage,'donttestoverexo');
			#  @assert_modularity(G_lulucf_exo,G_lulucf_endo,M_lulucf);
			@assert_modularity(G_udvaskning_exo,G_udvaskning_endo,B_udvaskning,'donttestoverexo');
			@assert_modularity(G_energy_markets_exo,G_energy_markets_endo,M_energy_markets,'testoverexo');
			

		# #With first year being 2024
			$SETGLOBAL start_shock_year 2023 #t0 where we start the 0-shock
			set_time_periods(%start_shock_year%,%terminal_year%);

			$UNFIX G_exo, G_endo;

			@assert_modularity(G_taxes_bottom_exo,G_taxes_bottom_endo,M_taxes_bottom,'testoverexo'); # 0
			@assert_modularity(G_taxes_total_exo,G_taxes_total_endo,M_taxes_total,'testoverexo'); # 0
			@assert_modularity(G_taxes_energy_exo,G_taxes_energy_endo,M_taxes_energy,'testoverexo'); # 0
			@assert_modularity(G_exports_exo,G_exports_endo,M_exports,'testoverexo');  # 0
			@assert_modularity(G_labor_market_exo,G_labor_market_endo,M_labor_market,'testoverexo'); # 0
			# @assert_modularity(G_consumers_exo,G_consumers_endo,M_consumers,'testoverexo');
			@assert_modularity(G_Government_exo,G_government_endo,M_government, 'testoverexo');		# 0
			@assert_modularity(G_IO_exo,G_IO_endo,M_IO,'donttestoverexo');
			@assert_modularity(G_aggregates_exo,G_aggregates_endo,M_aggregates,'testoverexo');
			@assert_modularity(G_emissions_exo, G_emissions_endo,M_emissions,'donttestoverexo');
			@assert_modularity(G_abatement_exo,G_abatement_endo,M_abatement,'donttestoverexo');
			#  @assert_modularity(G_production_private_exo,G_production_private_endo,M_production_private,'donttestoverexo');
			#  @assert_modularity(G_production_agr_exo,G_production_agr_endo,M_production_agr);
			@assert_modularity(G_waste_exo,G_waste_endo,M_waste,'testoverexo');	# 0
			@assert_modularity(G_leakage_shock_exo,G_leakage_shock_endo,B_leakage,'donttestoverexo');
			#  @assert_modularity(G_lulucf_exo,G_lulucf_endo,M_lulucf);
			@assert_modularity(G_udvaskning_exo,G_udvaskning_endo,B_udvaskning,'donttestoverexo');
			@assert_modularity(G_energy_markets_exo,G_energy_markets_endo,M_energy_markets,'testoverexo');



		# #With first year being 2030
			$SETGLOBAL start_shock_year 2029 #Year where we start the 0-shock
			set_time_periods(%start_shock_year%,%terminal_year%);

			$UNFIX G_exo, G_endo;

			@assert_modularity(G_taxes_bottom_exo,G_taxes_bottom_endo,M_taxes_bottom,'testoverexo'); # 0
			@assert_modularity(G_taxes_total_exo,G_taxes_total_endo,M_taxes_total,'testoverexo'); # 0
			@assert_modularity(G_taxes_energy_exo,G_taxes_energy_endo,M_taxes_energy,'testoverexo'); # 0
			@assert_modularity(G_exports_exo,G_exports_endo,M_exports,'testoverexo'); # 0
			@assert_modularity(G_labor_market_exo,G_labor_market_endo,M_labor_market,'testoverexo'); # 0
			# @assert_modularity(G_consumers_exo,G_consumers_endo,M_consumers,'testoverexo');
			@assert_modularity(G_Government_exo,G_government_endo,M_government,'testoverexo');		# 0
			@assert_modularity(G_IO_exo,G_IO_endo,M_IO,'donttestoverexo');
			@assert_modularity(G_aggregates_exo,G_aggregates_endo,M_aggregates,'testoverexo');
			@assert_modularity(G_emissions_exo, G_emissions_endo,M_emissions,'donttestoverexo');
			@assert_modularity(G_abatement_exo,G_abatement_endo,M_abatement,'donttestoverexo');
			#  @assert_modularity(G_production_agr_exo,G_production_agr_endo,M_production_agr);
			#  @assert_modularity(G_production_private_exo,G_production_private_endo,M_production_private,'donttestoverexo');
			@assert_modularity(G_waste_exo,G_waste_endo,M_waste,'testoverexo');	# 0 
			@assert_modularity(G_leakage_shock_exo,G_leakage_shock_endo,B_leakage,'donttestoverexo');
			#  @assert_modularity(G_lulucf_exo,G_lulucf_endo,M_lulucf);
			@assert_modularity(G_udvaskning_exo,G_udvaskning_endo,B_udvaskning,'donttestoverexo');
			@assert_modularity(G_energy_markets_exo,G_energy_markets_endo,M_energy_markets,'testoverexo');

	


# ======================================================================================================================
# Tests on model truncated at 2051
# ======================================================================================================================

	# set time_periods(2018,2051);

	#Dynamic calibration 




# ======================================================================================================================
# Subtraction of submodels 
# ======================================================================================================================

		#  $FUNCTION Subtractsubmodel({endhere}):

		#  	$GROUP G_exo 
		#  		G_exo 
		#  	;


		#  	$GROUP G_endo 
		#  		G_endo 
		#  	;

		#  	#Starter loop med udgangspunkt i M_zeroshock
		#  	$SETLOCAL previousmodel zeroshock


		#  	$FOR {model} in ['endolandlinks','energy_markets']:

		#  		$GROUP G_exo 
		#  			G_exo 
		#  			G_{model}_endo
		#  			#  -G_{model}_exo
		#  		;

		#  		$GROUP G_endo 
		#  			G_endo 
		#  			-G_{model}_endo 
		#  		;

		#  		$MODEL M_%previousmodel%_{model}
		#  			M_%previousmodel%
		#  			-M_{model}
		#  		;

		#  		$FIX G_exo;
		#  		$UNFIX G_endo;
		#  		@SOLVE(M_%previousmodel%_{model},1);

		#  		#Opdaterer previousmodel til næste iteration
		#  		$SETLOCAL previousmodel %previousmodel%_{model}
		#  	$ENDFOR
		#  $ENDFUNCTION


		#  @Subtractsubmodel();




