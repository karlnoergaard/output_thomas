# ======================================================================================================================
# Static calibration
# ======================================================================================================================
# ----------------------------------------------------------------------------------------------------------------------
# Set time periods
# ----------------------------------------------------------------------------------------------------------------------

  set_time_periods(%cal_start%, %cal_end%);
  set_bf_calib_periods(%BF_calib_start%,%BF_calib_end%, %BF_calib_prices_start%,%BF_calib_prices_end%);
  set_lulucf_periods(1990,%terminal_year%,2021,%terminal_year%);

  #Check that demand equals supply for energi in quantities and values
  $import check_ds.gms
# ----------------------------------------------------------------------------------------------------------------------
# Import the static calibration models from the modules and combine them
# ----------------------------------------------------------------------------------------------------------------------

  @import_from_modules("static_calibration")

  $MODEL M_static_calibration
    M_taxes_static_calibration
    M_energy_markets_static_calibration
    M_aggregates_static_calibration
    M_labor_market_static_calibration
    M_government_static_calibration
    M_consumers_static_calibration
    M_exports_static_calibration
    M_IO_static_calibration
    M_production_private_static_calibration
    M_production_public_static_calibration
    M_emissions_static_calibration
    M_LULUCF_static_calibration
    M_abatement_static_calibration
    M_production_plant_static_calibration
    M_production_ani_static_calibration
    M_production_agr_static_calibration
    M_waste_static_calibration
    M_leakage_static_calibration
    M_udvaskning_static_calibration
    M_pyrolyse_static_calibration
  ;

  $GROUP G_static_calibration
    G_taxes_static_calibration
    G_energy_markets_static_calibration
    G_aggregates_static_calibration
    G_labor_market_static_calibration
    G_government_static_calibration #, qG$(gtot[g_])
    G_consumers_static_calibration #, vPersincome$(t0[t])
    G_production_private_static_calibration
    G_production_public_static_calibration
    G_IO_static_calibration
    G_exports_static_calibration
    G_emissions_static_calibration
    G_LULUCF_static_calibration 
    G_abatement_static_calibration
    G_production_plant_static_calibration
    G_production_ani_static_calibration
    G_production_agr_static_calibration
    G_waste_static_calibration
    G_leakage_static_calibration
    G_udvaskning_static_calibration
    G_pyrolyse_static_calibration
  ;

  $GROUP G_static_calibration_exo
    G_taxes_static_calibration_exo
    G_energy_markets_static_calibration_exo
    G_aggregates_static_calibration_exo
    G_labor_market_static_calibration_exo 
    G_Government_static_calibration_exo
    G_consumers_static_calibration_exo
    G_production_public_static_calibration_exo
    G_production_private_static_calibration_exo
    G_IO_static_calibration_exo
    G_exports_static_calibration_exo
    G_emissions_static_calibration_exo
    G_lulucf_static_calibration_exo
    G_abatement_static_calibration_exo
    G_production_agr_static_calibration_exo
    G_production_plant_static_calibration_exo
    G_production_ani_static_calibration_exo
    G_waste_static_calibration_exo  
    G_leakage_static_calibration_exo
    G_udvaskning_static_calibration_exo
    G_pyrolyse_static_calibration
  ;

  $GROUP ALLREFORM  
     ALL
    -G_energiIO_in
  ;

#Population korrigeres
  nPop.l[t]        = nPop.l[t]        * correction_factor_pop;
  nEmployed.l[t]   = nEmployed.l[t]   * correction_factor_pop;
  nUnemployed.l[t] = nUnemployed.l[t] * correction_factor_pop;
  nLaborForce.l[t] = nLaborForce.l[t] * correction_factor_pop;

# Marginal tax-rate option? 
  d1tREmarg[s] = 1; #Set to 1 for marginal tax-rates and 0 for average tax-rates

# ----------------------------------------------------------------------------------------------------------------------
# Solve static calibration model in years where we have full data
# ----------------------------------------------------------------------------------------------------------------------

  set_time_periods(%cal_start%, %cal_end%);

  #The static calibration takes three steps (1) the cost structure is computed given capital-stock, (2) capital-stock is adjusted for food- and beverages industries (we only have data for the aggregate), (3) static calibration is computed with new cost-structure
  #(1)

  $FIX G_static_calibration_exo;
  $UNFIX G_static_calibration;
   execute_unload 'output\pre.gdx';
  @solve(M_static_calibration);
  #  execute_unload 'output\static_raw.gdx';
  
  #(2)
  $FIX G_production_static_calibration_capital_incl_agrcapital_exo;
  $UNFIX(0,inf) pY0$(sum(ns69,ns692s(ns69,s))), qI_s$(sum(ns69,ns692s(ns69,s))), qFin_k$(sum(ns69,ns692s(ns69,s)));
  $UNFIX(0.1,inf) qK$(sum(ns69,ns692s(ns69,s)));

  Solve M_production_static_calibration_capital_incl_agrcapital using NLP minimizing obj;

  qAni.l[Ani_sectors,'Buildings',t]            = qK.l['ib',Ani_sectors,t-1]/fq; #uK 
  qAni.l[Ani_sectors,'MachinesPrivate',t]      = qK.l['im',Ani_sectors,t-1]/fq; 
  qAni.l[Ani_sectors,'TransportCapital',t]     = qK.l['it',Ani_sectors,t-1]/fq; 

  qPlant.l[Plant_sectors,'Buildings',t]        = qK.l['ib',Plant_sectors,t-1]/fq;  #uK
  qPlant.l[Plant_sectors,'MachinesPrivate',t]  = qK.l['im',Plant_sectors,t-1]/fq; #uK
  qPlant.l[Plant_sectors,'TransportCapital',t] = qK.l['it',Plant_sectors,t-1]/fq; #uK

  qProd.fx['iB',sp,t]              = qK.l['iB',sp,t];
  qProd.fx['iM',sp,t]              = qK.l['iM',sp,t];
  qProd.fx['iT',sp,t]              = qK.l['it',sp,t];


  #(3)
  $FIX G_static_calibration_exo; 
  $UNFIX G_static_calibration;
  @solve(M_static_calibration);

  execute_unload 'output\static_calibration.gdx';

  #Various checks
    #Check that demand equals supply for energy-goods. The check is carried out for both values and quantities
    $import sanitycheck.gms 
    $import check_ds.gms

    #Check that input-data is not changed after static-calibration
      $GROUP G_load_G_data G_data;
      @load_previous_difference(G_load_G_data,'..\data\cal_dyn_load\previous_differences_static_calibration.gdx');
      @assert_no_difference(G_data,%tolerance_data%);

    #  UNLOAD NEW DIFFERENCES - TO BE COMMENTED IN IF YOU WANT TO CHANGE THE DIFFERENCE-GDX. PROCEED ONLY WITH CAUTION, thank you :) 
        #  @unload_differences(G_data,'..\data\cal_dyn_load\previous_differences_static_calibration.gdx');

# ----------------------------------------------------------------------------------------------------------------------
# Extend the last calibration as our forecast of parameters
# ----------------------------------------------------------------------------------------------------------------------
  set_time_periods(%cal_start%, %terminal_year%);

  $PGROUP pG_dummies_Flat 
    pG_dummies
    -PGROUP_taxes_NonFlat_Dummies
    -PGROUP_emissions_NonFlat_Dummies
    -PGROUP_Waste_NonFlat_Dummies
    -PGROUP_WasteKlimaplan_NonFlat_Dummies
    -PGROUP_LULUCF_NonFlat_Dummies
    -PGROUP_Abatement_NonFlat_Dummies
    -PGROUP_production_plant_NonFlat_Dummies
    -PGROUP_production_ani_NonFlat_Dummies
  ;

  $LOOP PGROUP_Waste_NonFlat_Dummies:
      {name}{sets}{$}[<t>tForecastWaste_dst] = {name}{sets}{$}[<t>tWasteEnd_dst];
  $ENDLOOP

  $LOOP PGROUP_WasteKlimaplan_NonFlat_Dummies:
      {name}{sets}{$}[<t>tForecastWaste_klimaplan] = {name}{sets}{$}[<t>tWasteEnd_klimaplan];
  $ENDLOOP


  $GROUP G_flat_initial_values 
    ALLREFORM
    -G_production_public_non_flat_initial_values_from_MAKRO
    -G_Government_non_flat_initial_values_from_MAKRO
    -G_labor_market_non_flat_initial_values_from_MAKRO
    -G_no_forecast_lulucf
    -G_non_flat_from_taxes
    -G_agr_non_flat_initial_values
    -G_ani_non_flat_initial_values
    -G_plant_non_flat_initial_values
    -G_udvaskning_noforecast
    -G_waste_projection_data_arima
    -G_PSO_taxes_to_zero
    -G_waste_klimaplan_virkemidler
    -G_waste_2014_2020
    -uWaste_arima_hus_adjust
    -G_waste_CET_function
    -G_emissions_non_flat_initial_values
  ;

  $LOOP G_waste_projection_data_arima:
      {name}.l{sets}{$}[<t>tForecastWaste_arima] = {name}.l{sets}{$}[<t>tWasteEnd_arima];
  $ENDLOOP

  $LOOP G_waste_klimaplan_virkemidler:
      {name}.l{sets}{$}[<t>tForecastWaste_klimaplan] = {name}.l{sets}{$}[<t>tWasteEnd_klimaplan];
  $ENDLOOP

  $LOOP G_waste_2014_2020:
      {name}.l{sets}{$}[<t>tForecastWaste_dst] = {name}.l{sets}{$}[<t>tWasteEnd_dst];
  $ENDLOOP

  $LOOP G_waste_CET_function:
      {name}.l{sets}{$}[<t>tForecastWaste_CET] = {name}.l{sets}{$}[<t>'2025'];
  $ENDLOOP


  $LOOP G_flat_initial_values: #Important to subset as long as variables in G_glat_initial_values are subsetted
    {name}.l{sets}{$}[<t>tForecast]$({subsets}) = {name}.l{sets}{$}[<t>tDataEnd];
  $ENDLOOP

  $LOOP G_agr_qK:
    {name}.l{sets}$({name}.l{sets}=0 and {subsets} and tForecast[t]) = {name}.l{sets}{$}[<t>tForecastStart];
  $ENDLOOP


#  ---------------------------------------------------------------------------------------------------------------------
#  Solve calibration model a block at a time
#  ---------------------------------------------------------------------------------------------------------------------



  #  $SETLOCAL prev_model M_cal
  #  $FOR {id}, {block}, {group}, {solve_block}, {add_block} in [
  #    # Use these only to check if modules are square
  #       ('TAX',  'M_taxes_static_calibration',           'G_taxes_static_calibration',           1, 0),
  #       ('IO',  'M_IO_static_calibration',           'G_IO_static_calibration',           1, 0),
  #       ('AGG', 'M_aggregates_static_calibration', 'G_aggregates_static_calibration', 1, 0),
  #       ('EXP', 'M_exports_static_calibration' , 'G_exports_static_calibration', 1,0),
  #       ('PRO', 'M_production_static_calibration', 'G_production_static_calibration', 1,0),
  #       ('CON', 'M_consumers_static_calibration', 'G_consumers_static_calibration', 1, 0),
  #       ('LAB', 'M_labor_market_static_calibration', 'G_labor_market_static_calibration', 1, 0),
  #       ('GOV', 'M_government_static_calibration', 'G_government_static_calibration', 1, 0),

  #    ## Use these to solve modules sequentially or to check if calibration is square
    
  #       ('TAX',  'M_taxes_static_calibration',           'G_taxes_static_calibration',           0, 1),
  #       ('IO',  'M_IO_static_calibration',           'G_IO_static_calibration',           0, 1),
  #       ('AGG', 'M_aggregates_static_calibration', 'G_aggregates_static_calibration', 0, 1),
  #       ('EXP', 'M_exports_static_calibration' , 'G_exports_static_calibration', 0,1),
  #       ('PRO', 'M_production_static_calibration', 'G_production_static_calibration', 0,1),
  #       ('CON', 'M_consumers_static_calibration', 'G_consumers_static_calibration', 0, 1),
  #       ('LAB', 'M_labor_market_static_calibration', 'G_labor_market_static_calibration', 0, 1),
  #       ('GOV', 'M_government_static_calibration', 'G_government_static_calibration', 0, 1),

  #    ## Solve the entire calibration model (with some variables bounded)
  #    #  ('',    'M_dynamic_calibration', 'G_dynamic_calibration_endo', 1, 0),
  #  ]:

  #    # Solve block individually
  #    $IF {solve_block}:
  #      $FIX {group}_exo; $UNFIX {group};
  #      @solve({block});
  #    $ENDIF

  #    # Add block to model and solve new combined model
  #    $IF {add_block}:
  #      $SETLOCAL new_model %prev_model%_{id} # Generate new model name
  #      $MODEL %new_model% # Define new model as previous model plus the module
  #        $IF2 "%prev_model%"!="M_cal": %prev_model% $ENDIF2
  #        {block}
  #      ;
  #      $GROUP G_cal_blockwise # Add module calib group to group
  #        $IF2 "%prev_model%"!="M_cal": G_cal_blockwise $ENDIF2
  #        {group}
  #      ;
  #      $FIX All; $UNFIX G_cal_blockwise;  
  #      @solve(%new_model%);
  #      $SET prev_model %new_model%
  #    $ENDIF
  #  $ENDFOR

#===================================================================================================================================================#
# Little bit of LULUCF
#===================================================================================================================================================#
#  #Hvad bestemmer udviklingen i NRE.

#  set alts /mitbud,ign/;

#  PARAMETER ErDetHerNREareal[alts,ite,joe07,spec_type,acl], ImplitcitpSurvival[forvalt,ite,joe07,spec_type,acl], Kulstofpulje[ite], HWP[ite], Kulstofindhold_NRE_AG[ite,joe07,spec_type,acl],
#      Kulstofindhold_NRE_BG[ite,joe07,spec_type,acl], Kulstofindhold_NRE_DW[ite,joe07,spec_type,acl], Kulstofindhold_NRE_CL[ite,joe07,spec_type,acl],
#      Kulstofindhold_FRF_AG[ite,joe07,spec_type,acl], Kulstofindhold_FRF_BG[ite,joe07,spec_type,acl], Kulstofindhold_FRF_DW[ite,joe07,spec_type,acl], Kulstofindhold_FRF_CL[ite,joe07,spec_type,acl];

#  ErDetHerNREareal[alts,ite,joe07,spec_type,acl] = Tabel_11_11[ite,joe07,'NRE',spec_type,acl,'area'];

#  #  Tabel_11_11[ite,joe07,forvalt,spec_type,acl,items]

#  Kulstofindhold_NRE_AG[ite,joe07,spec_type,acl]$(Tabel_11_11[ite,joe07,'NRE',spec_type,acl,'area']) = Tabel_11_11[ite,joe07,'NRE',spec_type,acl,'CA3']/Tabel_11_11[ite,joe07,'NRE',spec_type,acl,'area'];
#  Kulstofindhold_NRE_BG[ite,joe07,spec_type,acl]$(Tabel_11_11[ite,joe07,'NRE',spec_type,acl,'area']) = Tabel_11_11[ite,joe07,'NRE',spec_type,acl,'CB3']/Tabel_11_11[ite,joe07,'NRE',spec_type,acl,'area'];
#  Kulstofindhold_NRE_DW[ite,joe07,spec_type,acl]$(Tabel_11_11[ite,joe07,'NRE',spec_type,acl,'area']) = Tabel_11_11[ite,joe07,'NRE',spec_type,acl,'CDW']/Tabel_11_11[ite,joe07,'NRE',spec_type,acl,'area'];
#  Kulstofindhold_NRE_CL[ite,joe07,spec_type,acl]$(Tabel_11_11[ite,joe07,'NRE',spec_type,acl,'area']) = Tabel_11_11[ite,joe07,'NRE',spec_type,acl,'CL']/Tabel_11_11[ite,joe07,'NRE',spec_type,acl,'area'];

#  Kulstofindhold_FRF_AG[ite,joe07,spec_type,acl]$(Tabel_11_11[ite,joe07,'FRF',spec_type,acl,'area']) = Tabel_11_11[ite,joe07,'FRF',spec_type,acl,'CA3']/Tabel_11_11[ite,joe07,'FRF',spec_type,acl,'area'];
#  Kulstofindhold_FRF_BG[ite,joe07,spec_type,acl]$(Tabel_11_11[ite,joe07,'FRF',spec_type,acl,'area']) = Tabel_11_11[ite,joe07,'FRF',spec_type,acl,'CB3']/Tabel_11_11[ite,joe07,'FRF',spec_type,acl,'area'];
#  Kulstofindhold_FRF_DW[ite,joe07,spec_type,acl]$(Tabel_11_11[ite,joe07,'FRF',spec_type,acl,'area']) = Tabel_11_11[ite,joe07,'FRF',spec_type,acl,'CDW']/Tabel_11_11[ite,joe07,'FRF',spec_type,acl,'area'];
#  Kulstofindhold_FRF_CL[ite,joe07,spec_type,acl]$(Tabel_11_11[ite,joe07,'FRF',spec_type,acl,'area']) = Tabel_11_11[ite,joe07,'FRF',spec_type,acl,'CL']/ Tabel_11_11[ite,joe07,'FRF',spec_type,acl,'area'];


#  LOOP(ite$(not sameas[ite,'ite0']),
#    ErDetHerNREareal['mitbud',ite,joe07,spec_type,acl] = ErDetHerNREareal['mitbud',ite-1,joe07,spec_type,acl-1] - Tabel_11_11[ite,joe07,'NRE',spec_type,acl,'Harea'];
#    ErDetHerNREareal['mitbud',ite,joe07,spec_type,acl] = ErDetHerNREareal['mitbud',ite-1,joe07,spec_type,acl-1] - Tabel_11_11[ite,joe07,'NRE',spec_type,acl,'Harea'];

#    ImplitcitpSurvival[forvalt,ite,joe07,spec_type,acl-1]$(Tabel_11_11[ite-1,joe07,forvalt,spec_type,acl-1,'area']) 
#      #I dokumentationen står at Hovedskovningsarealet er per år.
#      #  = (Tabel_11_11[ite,joe07,'NRE',spec_type,acl,'area']+Tabel_11_11[ite,joe07,'NRE',spec_type,acl,'Harea']*5)/Tabel_11_11[ite-1,joe07,'NRE',spec_type,acl-1,'area'];
#      = Tabel_11_11[ite,joe07,forvalt,spec_type,acl,'area']/Tabel_11_11[ite-1,joe07,forvalt,spec_type,acl-1,'area'];
#      );


#  Kulstofpulje[ite] = sum((joe07,spec_type,forvalt,acl), Tabel_11_11[ite,joe07,forvalt,spec_type,acl,'CA3'] 
#                                                      + Tabel_11_11[ite,joe07,forvalt,spec_type,acl,'CB3'] 
#                                                      + Tabel_11_11[ite,joe07,forvalt,spec_type,acl,'CDW']
#                                                      + Tabel_11_11[ite,joe07,forvalt,spec_Type,acl,'CL'])*44/12;

#  #  HWP[ite] = 

#  PARAMETER ErNREDef_lig_lys[ite,joe07,spec_type], Deforestation_NRE[ite,joe07,spec_type], NewLyst[ite,joe07,spec_type];

#  ErNREDef_lig_lys[ite,joe07,spec_type] = sum(acl, Tabel_11_11[ite,joe07,'NRE',spec_Type,acl,'Harea'])*5 - Tabel_11_11[ite,joe07,'LYS',spec_type,'acl5','AREA']; 

#  Deforestation_NRE[ite,joe07,spec_type] = sum(acl, Tabel_11_11[ite,joe07,'NRE',spec_type,acl,'Harea'])*5;
#  NewLyst[ite,joe07,spec_type]           = Tabel_11_11[ite,joe07,'LYS',spec_type,'acl5','AREA'];


#  PARAMETER ErDetHerHugst[ite,joe07,spec_type,acl], ErDetHerHugst_tot[ite], ErdetherHWPcoeff[ite,joe07,forvalt,spec_type,acl], ErHovedskof_fastkoeff[ite,joe07,forvalt,spec_type,acl];
#  ErDetHerHugst[ite,joe07,spec_type,acl] = (Tabel_11_11[ite,joe07,'FRF',spec_Type,acl,'CA2'])*44/12; # + Tabel_11_11[ite,joe07,'FRF',spec_Type,acl,'HCA2'])*44/12;
#  ErDetHerHugst_tot[ite] = sum((joe07,spec_type,acl), ErDetHerHugst[ite,joe07,spec_type,acl]);
#  ErdetherHWPcoeff[ite,joe07,forvalt,spec_type,acl]$(Tabel_11_11[ite,joe07,forvalt,spec_Type,acl,'area'])
#     = Tabel_11_11[ite,joe07,forvalt,spec_Type,acl,'CA2']/Tabel_11_11[ite,joe07,forvalt,spec_Type,acl,'area'];

#     ErHovedskof_fastkoeff[ite,joe07,forvalt,spec_type,acl]$((-(Tabel_11_11[ite,joe07,forvalt,spec_Type,acl,'area']-Tabel_11_11[ite-1,joe07,forvalt,spec_Type,acl-1,'area']))) 
#      =  Tabel_11_11[ite,joe07,forvalt,spec_Type,acl,'Harea']/(-(Tabel_11_11[ite,joe07,forvalt,spec_Type,acl,'area']-Tabel_11_11[ite-1,joe07,forvalt,spec_Type,acl-1,'area']));
#  #Harea er det samme som det der, dør i FRF-modellen. Men betyder det så at HWP skal beregnes af dette areal? 

#                                                      #  + Tabel_11_11[ite,joe07,forvalt,spec_Type,acl,'CA2'])*44/12;
