# # #  Struktureffekter på SKM-metoden

$IF %cement%:
  cement_prod[t]$(t.val ge 2025) = exp(-0.3824/100*tX.l[t]/inf_factor['2022']);
$ENDIF
raffi_prod[t]$(t.val ge 2025) = exp(-0.1054/100*tX.l[t]/inf_factor['2022']);

fisk_prod[t]$(t.val ge 2025) = exp(-0.0348/100*tX.l[t]/inf_factor['2022']);
#  Her sættes de eksogene variable til deres nye niveauer
$import ..\level_for_exo_production.gms



