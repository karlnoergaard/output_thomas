$SETGLOBAL shockAP 1

#Zum erst berechnen wir die elasticitäten

  #Vielleicht sollten wir nicht 2020 zähler benutzen weil est ist ein model berechnung. 2018 ist wahrscheinlich besser
  elasticiteter[Vsh2,'Andel af produktion der eksporteres']$(not EksportVsh(Vsh2))          = sum(s$(s2Vsh(s,Vsh2)), sum(x, vX_y.l[x,s,'2020'])/vY.l[s,'2020']);
  elasticiteter[Vsh2,'Andel af samlet indenlandsk forbrug af varen']$(not ImportVsh(Vsh2))  = sum(s$(s2Vsh(s,Vsh2)), (vY.l[s,'2020']-sum(x, vX_y.l[x,s,'2020']))/(vY.l[s,'2020']-sum(x, vX_y.l[x,s,'2020'])+qM_CET.l['out_other',s,'2020']));
  elasticiteter[Vsh2,'Substitutionselasticitet mellem forskellige indenlandske vare']       = sum(s$(s2Vsh(s,Vsh2)), vY.l[s,'2020']/sum(ss, vY.l[ss,'2020']));

  parameter egenpriselasticitet[Vsh2], omkostningsstigning[Vsh2], produktionsnedgang[Vsh2], CO2reduktion[Vsh2];
  
  egenpriselasticitet[Vsh2] = elasticiteter[Vsh2,'Andel af produktion der eksporteres']*elasticiteter[Vsh2,'Eksport-elasticitet'] 
                         + (1-elasticiteter[Vsh2,'Andel af produktion der eksporteres'])
                         * (  elasticiteter[Vsh2,'Importelasticitet']-(elasticiteter[Vsh2,'Importelasticitet']-elasticiteter[Vsh2,'Substitutionselasticitet mellem forskellige indenlandske vare'])*elasticiteter[Vsh2,'Andel af samlet indenlandsk forbrug af varen']
                         + (  elasticiteter[Vsh2,'Substitutionselasticitet mellem forskellige indenlandske vare']-1)*elasticiteter[Vsh2,'Andel af samlet forbrug af samtlige varer']);

#  Først beregnes den lineære produktionsnedgang af en CO2-afgift på 100 kr. pr. t CO2, hvilket senere bruges til at finde semielasticiteten for struktureffekten
#  Beregner virksomhedernes omkostningsstigning i pct. ved en CO2-afgift på 100 kr. pr. t CO2
  omkostningsstigning[Vsh2] = (emm_base[Vsh2,'2020']*100)/produktionsomk_base[Vsh2];

produktionsnedgang[Vsh2] = -omkostningsstigning[Vsh2]*egenpriselasticitet[Vsh2];

CO2reduktion[Vsh2] = produktionsnedgang[Vsh2]*emm_base[Vsh2,'2020'];

#  display egenpriselasticitet, omkostningsstigning, produktionsnedgang, CO2reduktion; 

$OnMultiR
parameter emm_agg[GSR_ag,t], CO2reduktion_agg[GSR_ag], Struktur_semielasticitet[GSR_ag], afgiftssats_base[GSR_ag], afgiftssats_stod[GSR_ag], afgiftssats_diff[GSR_ag], teknisk_semielasticitet[GSR_ag], produktionsnedgang_samlet[GSR_ag], CO2reduktion_struktur[GSR_ag], produktionsnedgang_struktur[GSR_ag,t];

set GSR_ag_mineralogi_proces[GSR_ag]/Mineralogi_cement,Mineralogi_oevrig,proces_ETS,proces_non_ETS/;
set GSR_ag_mineralogi_ETSproces[GSR_ag]/Mineralogi_cement,Mineralogi_oevrig,proces_ETS/;
$OffMulti
# (a) Beregning hvor cement er placeholder for 23001
#  emm_agg[GSR_ag_mineralogi_ETSproces,t] = sum((s,Vsh2)$(s2Vsh(s,Vsh2) and sum((categoryENS,energy19), sENS2GR(categoryENS,GSR_ag_mineralogi_ETSproces,'in_ETS',energy19,s))), emm_base[Vsh2,t]);
#
# (b) Beregning, hvor cement er cement
 emm_agg[GSR_ag_mineralogi_ETSproces,t] = sum(Vsh2$(GSR_ag2Vsh2(GSR_ag_mineralogi_ETSproces,Vsh2)), emm_base[Vsh2,t]);

#  PARAMETER whatisnothere[s], vshnothere[vsh2];
#  whatisnothere[s] = yes$(sum(vsh2,s2Vsh(s,Vsh2)) and not sum((categoryENS,GSR_ag_mineralogi_ETSproces,energy19),sENS2GR(categoryENS,GSR_ag_mineralogi_ETSproces,'in_ETS',energy19,s)));
#  vshnothere[vsh2] = yes$(not sum(s,s2Vsh(s,Vsh2)));


#  CO2-udledninger i 2030 for mineralogi (ex Mineralogi_cement) passer ikke med KF22. Sætter derfor tallene til KF22.
  emm_agg['Mineralogi_oevrig','2030'] = 0.86698244; #Passer det? I Maries tal er det 0.7 mio. t

# (a) Beregning, hvor 'cement' er placeholder for 23001
#  CO2reduktion_agg[GSR_ag_mineralogi_ETSproces] = sum((s,Vsh2)$(s2Vsh(s,Vsh2) and sum((categoryENS,energy19), sENS2GR(categoryENS,GSR_ag_mineralogi_ETSproces,'in_ETS',energy19,s))), CO2reduktion[Vsh2]);

# (b erstatter a lige ovenfor) Beregning, hvor cement er cement
 CO2reduktion_agg[GSR_ag_mineralogi_ETSproces] = sum(Vsh2$(GSR_ag2Vsh2(GSR_ag_mineralogi_ETSproces,Vsh2)), CO2reduktion[Vsh2]);



#  Tilføjer CO2-reduktioner for teglværker, som tages direkte fra SKM-beregninger. 
  # (a) Kategorien 'Mineralogi_cement' er lavet om til en paraply kategori for virksomhederne i 23001. I rapporteringen skille mineralogi ad i Mineralogi_cement/ikke-Mineralogi_cement
  #  CO2reduktion_agg['Mineralogi_cement'] = CO2reduktion_agg['Mineralogi_cement'] + 0.0065;
  # (b erstatter a lige herover) Går tilbage til at cement ikke er paraply 
  CO2reduktion_agg['Mineralogi_oevrig'] = CO2reduktion_agg['Mineralogi_oevrig'] + 0.0065;

  #  Dermed skal CO2-grundlag for teglværker også tilføjes i 2020 for at få retvisende semielasticitet
    #(a)
    #emm_agg['Mineralogi_cement','2020'] = emm_agg['Mineralogi_cement','2020'] + emm_base['Teglvaerker','2020'];
    #(b)
    emm_agg['Mineralogi_oevrig','2020'] = emm_agg['Mineralogi_oevrig','2020'] + emm_base['Teglvaerker','2020'];

#  Tilføjer "proces_non_ETS" direkte fra SKM
  #(a)
  emm_agg['proces_non_ETS','2020'] = 0.8;
  emm_agg['proces_non_ETS','2030'] = 0.701464640056872;
  LOOP(t$(t.val>2020 and t.val<2030),
     emm_agg['proces_non_ETS',t] = emm_agg['proces_non_ETS',t-1] + (emm_agg['proces_non_ETS','2030']-emm_agg['proces_non_ETS','2020'])/10;
     );

  #(b) Ændrer til at tage tal fra modellen - NB. almindelig proces (ikke-kvote) stemmer ikke med ovenstående. Derfor bruges stadig ovenstående. Afventer svar fra ENS på hvorfor alm. proces ikke stemmer
  #  emm_agg['proces_non_ETS',t] = (sum((purpose,energy19,r)$(d1EmmProdE[r,t,'CO2ubio',purpose,energy19] and mapGrREFORM2GSR[purpose,energy19,r,'proces_non_ETS',t]), qEmmProdE.l[r,t,'co2ubio',purpose,energy19])
  #                                +sum((purpose,r) $(d1EmmProdE[r,t,'CO2bio',purpose,'Natural gas incl. biongas'] and mapGrREFORM2GSR[purpose,'Natural gas incl. biongas',r,'proces_non_ETS',t]), qEmmProdE.l[r,t,'co2bio',purpose,'Natural gas incl. biongas']))
  #                                /1000 #Omregner til mio. tCO2e;

#Indsætter reduktion for alm proces (ikke-kvote)
  CO2reduktion_agg['proces_non_ETS'] = 0.0052;

#  Beregner semielasticiteten
  Struktur_semielasticitet[GSR_ag]$(emm_agg[GSR_ag,'2020']) = (1/emm_agg[GSR_ag,'2020'])*CO2reduktion_agg[GSR_ag];

  #Afgiftssatser baseline 
  afgiftssats_base['Mineralogi_cement'] = 27.6747578385265; 
  afgiftssats_base['Mineralogi_oevrig'] = 42.7296127356853;
  
  afgiftssats_base['proces_ETS']        = 143.947368421053;
  afgiftssats_base['proces_non_ETS']    = 323.147368421053;
  afgiftssats_base['raffinaderier']     = 0;
  afgiftssats_base['fiskeri']           = 0;


  afgiftssats_stod['proces_ETS']        = 375;
  afgiftssats_stod['proces_non_ETS']    = 750;
  afgiftssats_stod['raffinaderier']     = 375;
  afgiftssats_stod['fiskeri']           = 375;


  $IF %saerbehandl_mineralogi%==1:
    #Afgiftssatser stød
    afgiftssats_stod['Mineralogi_cement'] = 125;
    afgiftssats_stod['Mineralogi_oevrig'] = 125;

  $ENDIF 

  $IF %saerbehandl_mineralogi%==0:
    afgiftssats_stod['Mineralogi_cement'] = 375;
    afgiftssats_stod['Mineralogi_oevrig'] = 375;
  $ENDIF

  #Ændring i afgift
  afgiftssats_diff[GSR_ag] = afgiftssats_stod[GSR_ag] - afgiftssats_base[GSR_ag];
  #  $IF %saerbehandl_mineralogi%==1:
  #    afgiftssats_diff['Mineralogi_cement'] = 27.21;
  #    afgiftssats_diff['Mineralogi_oevrig'] = 40.69;
  #  $ENDIF 

  #  afgiftssats_diff['proces_non_ets']    = 673.85;
  #  afgiftssats_diff['proces_ETS']        = 349.34;



  #Indsætter teknisk semielasticitet fra SKM
  teknisk_semielasticitet['Mineralogi_cement'] = 0.071547;
  teknisk_semielasticitet['Mineralogi_oevrig'] = 0.03733333;
  teknisk_semielasticitet['proces_ETS']        = 0.077342458378378;
  teknisk_semielasticitet['proces_non_ETS']    = 0.077342458378378;

  #Beregning af produktionsnedgang
  produktionsnedgang_samlet[GSR_ag] = 1 - exp(-(Struktur_semielasticitet[GSR_ag]+teknisk_semielasticitet[GSR_ag])/100*afgiftssats_diff[GSR_ag]);

  #CO2-reduktion som følge af nedlukning (struktur) beregnes
  CO2reduktion_struktur[GSR_ag]$((Struktur_semielasticitet[GSR_ag]+teknisk_semielasticitet[GSR_ag]))
     = produktionsnedgang_samlet[GSR_ag]*emm_agg[GSR_ag,'2030']*(Struktur_semielasticitet[GSR_ag]/(Struktur_semielasticitet[GSR_ag]+teknisk_semielasticitet[GSR_ag]));

  produktionsnedgang_struktur[GSR_ag,'2030']$(emm_agg[GSR_ag,'2030']) = CO2reduktion_struktur[GSR_ag]/emm_agg[GSR_ag,'2030'];

  #  display emm_agg, CO2reduktion_agg, Struktur_semielasticitet, afgiftssats_diff, produktionsnedgang_samlet, CO2reduktion_struktur, produktionsnedgang_struktur;
  $OnMultiR
  Parameter rGSR_Teknik[GSR_ag,t], rGSR_Total[GSR_ag,t], rGSR_Struktur[GSR_ag,t],
            rGSR_Teknik_Corr[GSR_ag,t], rGSR_Struktur_Corr[GSR_ag,t], EmmTotShock[GSR_ag];
  $OffMulti
  rGSR_Teknik[GSR_ag,'2030']    = exp(-teknisk_semielasticitet[GSR_ag]/100*afgiftssats_diff[GSR_ag]);
  rGSR_Struktur[GSR_ag,'2030']  = exp(-Struktur_semielasticitet[GSR_ag]/100*afgiftssats_diff[GSR_ag]);
  rGSR_Total[GSR_ag,'2030']     = exp(-(teknisk_semielasticitet[GSR_ag]+Struktur_semielasticitet[GSR_ag])/100*afgiftssats_diff[GSR_ag]);

  #Kommenter ind, hvis både struktur og teknik skal modelleres som nedlukning
    #  rGSR_Struktur[GSR_ag,'2030'] = rGSR_Total[GSR_ag,'2030'];"


  #De tekniske effekter er udelukkende på energi. I nedlukningen underforstås at tekniske effekter kan spredes både på ikke-energi og energi. Det er kun i mineralogi, der er (nævneværdig) ikke-energi effekt. 
  #Struktureffekten justeres derfor til at tage højde for at de tekniske effekter kun implementeres på de energimæssige udledninger.

  EmmTotShock[GSR_ag] = rGSR_Total[GSR_ag,'2030'] * output_GSR[GSR_ag,'qEmmProd_baseline','2030']; #Her beregnes den totale udledning i 2030 efter både teknik og struktur.

  #Her korrigeres struktureffekterne i mineralogi
  #  rGSR_Struktur['Mineralogi_cement','2030'] = EmmTotShock['Mineralogi_cement']/((1-tek_effekt['2030','Mineralogi_cement'])*output_GSR['Mineralogi_cement','qEmmProdE_baseline','2030'] + output_GSR['Mineralogi_cement','qEmmProdxE_baseline','2030']); 
  #  rGSR_Struktur['Mineralogi_oevrig','2030'] = EmmTotShock['Mineralogi_oevrig']/((1-tek_effekt['2030','Mineralogi_oevrig'])*output_GSR['Mineralogi_oevrig','qEmmProdE_baseline','2030'] + output_GSR['Mineralogi_oevrig','qEmmProdxE_baseline','2030']); 

  #Der laves en indfasningsstruktur à la SEH:
    rGSR_Struktur[GSR_ag,t]$(t.val lt 2022) = 0;
    rGSR_Struktur[GSR_ag,'2022'] = 1/3*1 + 2/3*rGSR_Struktur[GSR_ag,'2030'];
    rGSR_Struktur[GSR_ag,'2023'] = 1/3*1 + 2/3*rGSR_Struktur[GSR_ag,'2030'];
    rGSR_Struktur[GSR_ag,'2024'] = 1/3*1 + 2/3*rGSR_Struktur[GSR_ag,'2030'];
    rGSR_Struktur[GSR_ag,'2025'] = (1/3-1/6*1/3)*1 + (2/3+1/6*1/3)*rGSR_Struktur[GSR_ag,'2030'];
    rGSR_Struktur[GSR_ag,'2026'] = (1/3-2/6*1/3)*1 + (2/3+2/6*1/3)*rGSR_Struktur[GSR_ag,'2030'];
    rGSR_Struktur[GSR_ag,'2027'] = (1/3-3/6*1/3)*1 + (2/3+3/6*1/3)*rGSR_Struktur[GSR_ag,'2030'];
    rGSR_Struktur[GSR_ag,'2028'] = (1/3-4/6*1/3)*1 + (2/3+4/6*1/3)*rGSR_Struktur[GSR_ag,'2030'];
    rGSR_Struktur[GSR_ag,'2029'] = (1/3-5/6*1/3)*1 + (2/3+5/6*1/3)*rGSR_Struktur[GSR_ag,'2030'];
    rGSR_Struktur[GSR_ag,t]$(t.val gt 2030) = rGSR_Struktur[GSR_ag,'2030'];


    rGSR_Struktur_Corr[GSR_ag,t] = rGSR_Struktur[GSR_ag,t];


  #I rGSR_Struktur_Corr bruges 'Cement' som placeholder for hele 23001, således at parameteren afspejler modellens nuværende struktur
    #  rGSR_Struktur_Corr['Mineralogi_cement',t] =  (1-s23001notAP[t]) * rGSR_Struktur['Mineralogi_cement',t] + s23001notAP[t] * rGSR_Struktur['Mineralogi_oevrig',t];
    #  rGSR_Struktur_Corr['Mineralogi_cement',t]$(t.val >2030) = rGSR_Struktur_Corr['Mineralogi_cement','2030'];
  
#  ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#  tilføjer reduktioner i de forrige år - konvergering består af en kortsigts- og langsigtseffekt. Langsigtseffekten udgør 2/3 af samlet effekt og gælder allerede når afgift annoceres i 2022 (gælder derfor i 9 år). Korsigtseffekt udgør 1/3 af samlet effekt og gælder fra afgift indfases i 2025 (gælder derfor i 6 år)
#  ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  
  $OnMultiR
  parameter CO2reduktion_struktur_t;
  $OffMulti

  CO2reduktion_struktur_t[GSR_ag,t]$(t.val lt 2022) = 0;
  CO2reduktion_struktur_t[GSR_ag,'2022'] = (1/9)*(2/3)*CO2reduktion_struktur[GSR_ag];
  CO2reduktion_struktur_t[GSR_ag,'2023'] = (1/9)*(2/3)*CO2reduktion_struktur[GSR_ag] + CO2reduktion_struktur_t[GSR_ag,'2022'];
  CO2reduktion_struktur_t[GSR_ag,'2024'] = (1/9)*(2/3)*CO2reduktion_struktur[GSR_ag] + CO2reduktion_struktur_t[GSR_ag,'2023'];
  CO2reduktion_struktur_t[GSR_ag,'2025'] = (1/9)*(2/3)*CO2reduktion_struktur[GSR_ag] + CO2reduktion_struktur_t[GSR_ag,'2024'] + (1/6)*(1/3)*CO2reduktion_struktur[GSR_ag];
  CO2reduktion_struktur_t[GSR_ag,'2026'] = (1/9)*(2/3)*CO2reduktion_struktur[GSR_ag] + CO2reduktion_struktur_t[GSR_ag,'2025'] + (1/6)*(1/3)*CO2reduktion_struktur[GSR_ag];
  CO2reduktion_struktur_t[GSR_ag,'2027'] = (1/9)*(2/3)*CO2reduktion_struktur[GSR_ag] + CO2reduktion_struktur_t[GSR_ag,'2026'] + (1/6)*(1/3)*CO2reduktion_struktur[GSR_ag];
  CO2reduktion_struktur_t[GSR_ag,'2028'] = (1/9)*(2/3)*CO2reduktion_struktur[GSR_ag] + CO2reduktion_struktur_t[GSR_ag,'2027'] + (1/6)*(1/3)*CO2reduktion_struktur[GSR_ag];
  CO2reduktion_struktur_t[GSR_ag,'2029'] = (1/9)*(2/3)*CO2reduktion_struktur[GSR_ag] + CO2reduktion_struktur_t[GSR_ag,'2028'] + (1/6)*(1/3)*CO2reduktion_struktur[GSR_ag];
  CO2reduktion_struktur_t[GSR_ag,'2030'] = CO2reduktion_struktur[GSR_ag];
  CO2reduktion_struktur_t[GSR_ag,t]$(t.val gt 2030) = CO2reduktion_struktur[GSR_ag];

  display CO2reduktion_struktur_t;

  #Beregner produktionsnedgang_struktur, hvor cement kun er AP
  produktionsnedgang_struktur[GSR_ag,t]$(emm_agg[GSR_ag,t]) = CO2reduktion_struktur_t[GSR_ag,t]/emm_agg[GSR_ag,t]


#Korrigerer nedlukning til at tage højde for at en del af emissionerne i 23001 ikke er AP
  $OnMultiR
  PARAMETER sMineralogiOevrig23001[t] "Andel af øvrig mineralogi, der er 23001 i baseline";
  $OffMulti
  sMineralogiOevrig23001[t]$(sum(Vsh2$(not sameas[vsh2,'Aalborg Portland'] and GSR_ag2Vsh2('Mineralogi_oevrig',Vsh2)), emm_base[vsh2,t])) 
                            = sum(Vsh2$(not sameas[vsh2,'Aalborg Portland'] and s2Vsh['23001',vsh2] and GSR_ag2Vsh2('Mineralogi_oevrig',Vsh2)), emm_base[vsh2,t])
                             /sum(Vsh2$(not sameas[vsh2,'Aalborg Portland'] and GSR_ag2Vsh2('Mineralogi_oevrig',Vsh2)), emm_base[vsh2,t]);

  #'Mineralogi_cement' bliver nu igen placeholder for 23001 
  CO2reduktion_struktur_t['Mineralogi_cement',t] = CO2reduktion_struktur_t['Mineralogi_cement',t] 
                                                 + sMineralogiOevrig23001[t] * CO2reduktion_struktur_t['Mineralogi_oevrig',t];

  CO2reduktion_struktur_t['Mineralogi_oevrig',t] = CO2reduktion_struktur_t['Mineralogi_oevrig',t] 
                                                 - sMineralogiOevrig23001[t] * CO2reduktion_struktur_t['Mineralogi_oevrig',t];

  #
  emm_agg['Mineralogi_cement',t]                 = emm_agg['Mineralogi_cement',t] 
                                                 + sMineralogiOevrig23001[t] * emm_agg['Mineralogi_oevrig',t];

  emm_agg['Mineralogi_oevrig',t]                 = emm_agg['Mineralogi_oevrig',t] 
                                                 - sMineralogiOevrig23001[t] * emm_agg['Mineralogi_oevrig',t];




#Nedlukningsprofilen beregnes 
  $OnMultiR
  parameter rCO2reduktion_struktur_t[GSR_ag,t], afgiftssats_diff_ps[purpose,s];
  $OffMulti

  #Tager udledninger fra modellen
  #  emm_base_GSR_ag[GSR_ag_mineralogi_ETSproces,t] = #Energi-mæssige, eksl. naturgas
  #                                                    sum((purpose,energy19,r)$(d1EmmProdE[r,t,'CO2ubio',purpose,energy19] and mapGrREFORM2GSR[purpose,energy19,r,GSR_ag_mineralogi_ETSproces,t]), qEmmProdE.l[r,t,'co2ubio',purpose,energy19])
  #                                                    #Naturgas
  #                                                   +sum((purpose,r) $(d1EmmProdE[r,t,'CO2bio',purpose,'Natural gas incl. biongas'] and mapGrREFORM2GSR[purpose,'Natural gas incl. biongas',r,GSR_ag_mineralogi_ETSproces,t]), qEmmProdE.l[r,t,'co2bio',purpose,'Natural gas incl. biongas'])
  #                                                    #Mineralogi, 23001
  #                                                   +qEmmProdxE.l['23001',t,'CO2ubio']$(sameas[GSR_ag_mineralogi_ETSproces,'Mineralogi_cement'])
  #                                                    #Mineralogi, ikke 23001
  #                                                   + sum(s$(sENS2GR('Fremstillingsvirksomhed', 'Mineralogi_oevrig', 'in_ETS','Coal and coke', s) and d1EmmProdxE[s,t,'CO2ubio']), qEmmProdxE.l[s,t,'CO2ubio'])$(sameas[GSR_ag_mineralogi_ETSproces,'Mineralogi_oevrig'])
  #                                                  ;

  rCO2reduktion_struktur_t[GSR_ag,t]$(emm_agg[GSR_ag,t]) 
    = CO2reduktion_struktur_t[GSR_ag,t]/emm_agg[GSR_ag,t];

  rCO2reduktion_struktur_t[GSR_ag,t]$(t.val > 2030) = rCO2reduktion_struktur_t[GSR_ag,'2030'];
  rCO2reduktion_struktur_t[GSR_ag,t] = (1-rCO2reduktion_struktur_t[GSR_ag,t]);

  afgiftssats_diff_ps[purpose,s] =     sum(GSR_ag_mineralogi_proces$(sum((categoryENS,energy19), sENS2GR(categoryENS,GSR_ag_mineralogi_proces,purpose,energy19,s))), afgiftssats_diff[GSR_ag_mineralogi_proces]);
#Mapper nedlukningsprofil til brancher
  #  rShutdown.l[purpose,s,t] = sum(GSR_ag_mineralogi_proces$(sum((categoryENS,energy19), sENS2GR(categoryENS,GSR_ag_mineralogi_proces,purpose,energy19,s))), rCO2reduktion_struktur_t[GSR_ag_mineralogi_proces,t]);
    rShutdown.l[purpose,s,t] = sum(GSR_ag_mineralogi_proces$(sum((categoryENS,energy19), sENS2GR(categoryENS,GSR_ag_mineralogi_proces,purpose,energy19,s) and sum(vsh2,s2vsh(s,vsh2)) and not eNotInEnergyNest[purpose,energy19,s,t])), rGSR_Struktur_Corr[GSR_ag_mineralogi_proces,t]);


  #  #  ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  #  #  Metode til at dele CO2-reduktionen ud på GrønREFORM-brancher
  #  #  ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  #  parameter s_andel_GSR, s_CO2reduktion, Mineralogi_cement_e_xe_andel;

  #  s_andel_GSR[GSR_ag,r,'qEmmProdE',t]$(sum((purpose,energy19,s) $ mapGrREFORM2GSR[purpose,energy19,s,GSR_ag,t], qEmmProdE.l[s,t,'co2ubio',purpose,energy19])) = (sum((purpose,energy19) $ mapGrREFORM2GSR[purpose,energy19,r,GSR_ag,t], qEmmProdE.l[r,t,'co2ubio',purpose,energy19]) + sum((purpose) $ mapGrREFORM2GSR[purpose,'Natural gas incl. biongas',r,GSR_ag,t], qEmmProdE.l[r,t,'co2bio',purpose,'Natural gas incl. biongas']))/(sum((purpose,energy19,s) $ mapGrREFORM2GSR[purpose,energy19,s,GSR_ag,t], qEmmProdE.l[s,t,'co2ubio',purpose,energy19]) + sum((purpose,s) $ mapGrREFORM2GSR[purpose,'Natural gas incl. biongas',s,GSR_ag,t], qEmmProdE.l[s,t,'co2bio',purpose,'Natural gas incl. biongas']));
  #  s_andel_GSR[GSR_ag,r,'qEmmProdE',t]$(t.val gt 2030) = s_andel_GSR[GSR_ag,r,'qEmmProdE','2030'];

  #  Mineralogi_cement_e_xe_andel[t]$(qEmmProdxE.l['23001',t,'CO2e'] + sum((purpose,energy19), qEmmProdE.l['23001',t,'co2ubio',purpose,energy19]) + sum((purpose), qEmmProdE.l['23001',t,'co2bio',purpose,'Natural gas incl. biongas'])) = qEmmProdxE.l['23001',t,'CO2e']/(qEmmProdxE.l['23001',t,'CO2e'] + sum((purpose,energy19), qEmmProdE.l['23001',t,'co2ubio',purpose,energy19]) + sum((purpose), qEmmProdE.l['23001',t,'co2bio',purpose,'Natural gas incl. biongas']));
  #  Mineralogi_cement_e_xe_andel[t]$(t.val gt 2030) = Mineralogi_cement_e_xe_andel['2030'];

  #  s_CO2reduktion['Mineralogi_oevrig',r,'qEmmProdE',t] = s_andel_GSR['Mineralogi_oevrig',r,'qEmmProdE',t]*CO2reduktion_struktur_t['Mineralogi_oevrig',t];

  #  s_CO2reduktion['Mineralogi_cement',r,'qEmmProdE',t] = (1-Mineralogi_cement_e_xe_andel[t])*s_andel_GSR['Mineralogi_cement',r,'qEmmProdE',t]*CO2reduktion_struktur_t['Mineralogi_cement',t];

  #  s_CO2reduktion['Mineralogi_cement',r,'qEmmProdxE',t] = Mineralogi_cement_e_xe_andel[t]*s_andel_GSR['Mineralogi_cement',r,'qEmmProdE',t]*CO2reduktion_struktur_t['Mineralogi_cement',t];

  #  s_CO2reduktion['proces_ETS',r,'qEmmProdE',t] = s_andel_GSR['proces_ETS',r,'qEmmProdE',t]*CO2reduktion_struktur_t['proces_ETS',t];

  #  s_CO2reduktion['proces_non_ETS',r,'qEmmProdE',t] = s_andel_GSR['proces_non_ETS',r,'qEmmProdE',t]*CO2reduktion_struktur_t['proces_non_ETS',t];

  #  display s_CO2reduktion;

  #  #  ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  #  #  Alternativ metode til at dele CO2-reduktionen ud på GrønREFORM-brancher - bruges ikke, da der ikke er overenstemmelse mellem branchegrupperingen her og den der bruges i resten af modellen ift. de aggregerede GSR-brancer
  #  #  ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  #  #  parameter CO2reduktion_Vsh2_andel, CO2reduktion_Vsh2_q, CO2reduktion_s_q, emm_s, CO2reduktion_s_pct;

  #  #  CO2reduktion_Vsh2_andel[GSR_ag,Vsh2]$(GSR_ag2Vsh(GSR_ag,Vsh2)) = CO2reduktion[Vsh2]/CO2reduktion_agg[GSR_ag];

  #  #  CO2reduktion_Vsh2_q[Vsh2] = sum(GSR_ag, CO2reduktion_Vsh2_andel[GSR_ag,Vsh2]*CO2reduktion_struktur[GSR_ag]);

  #  #  CO2reduktion_s_q[s] = sum(Vsh2$(s2Vsh(s,Vsh2)), CO2reduktion_Vsh2_q[Vsh2]);

  #  #  emm_s[s] = sum(Vsh2$(s2Vsh(s,Vsh2)), emm_base[Vsh2,'2030']);

  #  #  CO2reduktion_s_pct[s]$emm_s[s] = CO2reduktion_s_q[s]/emm_s[s];

  #  #  display CO2reduktion_Vsh2_andel, CO2reduktion_Vsh2_q, CO2reduktion_s_q, emm_s, CO2reduktion_s_pct;