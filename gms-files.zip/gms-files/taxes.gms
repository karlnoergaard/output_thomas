# =====================================================================================================================
# Taxes
# =====================================================================================================================
# Tax rates and revenue

# =====================================================================================================================
# Variable definition
# =====================================================================================================================
$IF %stage% == "variables":

  $GROUP G_taxes_prices
    empty_group_dummy[t]                                    ""
  ;

  $GROUP G_taxes_values
    vtCVAT[c_,t]$(c[c_] or sameas[c_,'Ctot'])               "VAT on Private consumption"
    vtGVAT[g_,t]                                            "VAT on Public consumption"
    vtXVAT[x_,t]                                            "VAT on Exports"
    vtIVAT[i_,t]                                            "VAT on Investments"
    vtRxEVAT[r_,t]$(not sameas(r_,'tot'))                   "VAT on Material input"
    vtFinVAT[r_,t]$(not sameas(r_,'tot'))                   "VAT on financial service"
    vtVAT[t]                                                "Total revenue from VAT (samlet Moms-provenu)"
    vtCDuty[c_,t]$(c[c_] or sameas[c_,'cTot'])              "Duty on Private consumption"
    vtGDuty[g_,t]                                           "Duty on Public consumption"
    vtXDuty[x_,t]                                           "Duty on Exports"
    vtIDuty[i_,t]                                           "Duty on Investments"
    vtRxEDuty[r_,t]$(not sameas(r_,'tot'))                  "Duty on Material input"
    vtFinDuty[r_,t]$(not sameas(r_,'tot'))                  "Duty on financial service"
    vtDuty[t]                                               "Total revenue from duties (nettoprovenu fra punktafgifter, registreringsafgifter og produktsubsidier)"
    
    vtCus_RxE_m[r_,t]$(not sameas(r_,'tot'))                "Value of customs taxes on material inputs to production of foreign origin"
    vtCus_Fin_m[r_,t]$(not sameas(r_,'tot'))                "Value of customs taxes on financial service of foreign origin"
    vtCus_I_m[i_,t]                                         "Value of customs taxes on investment input of foreign origin"
    vtCus_G_m[g_,t]                                         "Value of customs taxes on gov. consumption of foreign origin"
    vtCus_C_m[c_,t]$(c[c_] or sameas[c_,'cTot'])            "Value of customs taxes on consumption of foreign origin"
    vtCus_X_m[x_,t]                                         "Value of customs taxes on import for export of foreign origin"
    vtCus[t]                                                "Total customs revenue"
    
    vtLand[s_,t]$(d1K['iB',s_,t] and not rTot[s_])          "Value of land taxes (ejendomskatter)"
    vtFirmsWeight[s_,t]$(d1K['iM',s_,t] and not rTot[s_])   "Value of weight taxes (v�gtafgift) from vehicels used in production"
    vtLAM[s_,t]$(not rTot[s_])                              "Value of firms AM contributions - AM-bidrag betalt af virksomheder"
    vtLPayRoll[s_,t]$(not rTot[s_])                         "Value of payroll taxes"
    vtLSubsidy[s_,t]$(not rTot[s_])                         "Value of worker subsidies - l�ntilskud"
    vtL[s_,t]$(not rTot[s_])                                "Value of payroll taxes"
    vtNetProductionRest[s_,t]$(not rTot[s_])                "Value of exogenous production taxes"
 ;

  $GROUP G_tDuty
    tDuty_C_y[c,s,afgsub,t]$(d1C_y[c,s,t]     and d1Duty_C_y[c,s,afgsub,t])      "Duty tax rate on private consumption of domestic origin"
    tDuty_C_m[c,s,afgsub,t]$(d1C_m[c,s,t]     and d1Duty_C_m[c,s,afgsub,t])      "Duty tax rate on private consumption of foreign origin"
    tDuty_G_y[g,s,afgsub,t]$(d1G_y[g,s,t]     and d1Duty_G_y[g,s,afgsub,t])      "Duty tax rate on public consumption of domestic origin"
    tDuty_G_m[g,s,afgsub,t]$(d1G_m[g,s,t]     and d1Duty_G_m[g,s,afgsub,t])      "Duty tax rate on public consumption of foreign origin"
    tDuty_X_y[x,s,afgsub,t]$(d1X_y[x,s,t]     and d1Duty_X_y[x,s,afgsub,t])      "Duty tax rate on exports of domestic origin"
    tDuty_X_m[x,s,afgsub,t]$(d1X_m[x,s,t]     and d1Duty_X_m[x,s,afgsub,t])      "Duty tax rate on exports of foreign origin"
    tDuty_RxE_y[r,s,afgsub,t]$(d1RxE_y[r,s,t] and d1Duty_RxE_y[r,s,afgsub,t])  "Duty tax rate on domestic material input"
    tDuty_RxE_m[r,s,afgsub,t]$(d1RxE_m[r,s,t] and d1Duty_RxE_m[r,s,afgsub,t])  "Duty tax rate on foreign material input"
    tDuty_I_y[i,s,afgsub,t]$(d1I_y[i,s,t]     and d1Duty_I_y[i,s,afgsub,t])      "Duty tax rate on domestic investment input"
    tDuty_I_m[i,s,afgsub,t]$(d1I_m[i,s,t]     and d1Duty_I_m[i,s,afgsub,t])      "Duty tax rate on foreign investment input"
    tDuty_Fin_y[r,afgsub,t]$(d1Fin_y[r,t]     and d1Duty_Fin_y[r,afgsub,t])                                   "Duty tax rate on domestic financial service"
    tDuty_Fin_m[r,afgsub,t]$(d1Fin_m[r,t]     and d1Duty_Fin_m[r,afgsub,t])                                   "Duty tax rate on foreign financial service"

    tSub_C_y[c,s,afgsub,t]$(d1C_y[c,s,t]     and d1Sub_C_y[c,s,afgsub,t])      "Subsidy rate on private consumption of domestic origin"
    tSub_C_m[c,s,afgsub,t]$(d1C_m[c,s,t]     and d1Sub_C_m[c,s,afgsub,t])      "Subsidy rate on private consumption of foreign origin"
    tSub_G_y[g,s,afgsub,t]$(d1G_y[g,s,t]     and d1Sub_G_y[g,s,afgsub,t])      "Subsidy rate on public consumption of domestic origin"
    tSub_G_m[g,s,afgsub,t]$(d1G_m[g,s,t]     and d1Sub_G_m[g,s,afgsub,t])      "Subsidy rate on public consumption of foreign origin"
    tSub_X_y[x,s,afgsub,t]$(d1X_y[x,s,t]     and d1Sub_X_y[x,s,afgsub,t])      "Subsidy rate on exports of domestic origin"
    tSub_X_m[x,s,afgsub,t]$(d1X_m[x,s,t]     and d1Sub_X_m[x,s,afgsub,t])      "Subsidy rate on exports of foreign origin"
    tSub_RxE_y[r,s,afgsub,t]$(d1RxE_y[r,s,t] and d1Sub_RxE_y[r,s,afgsub,t])  "Subsidy rate on domestic material input"
    tSub_RxE_m[r,s,afgsub,t]$(d1RxE_m[r,s,t] and d1Sub_RxE_m[r,s,afgsub,t])  "Subsidy rate on foreign material input"
    tSub_I_y[i,s,afgsub,t]$(d1I_y[i,s,t]     and d1Sub_I_y[i,s,afgsub,t])      "Subsidy rate on domestic investment input"
    tSub_I_m[i,s,afgsub,t]$(d1I_m[i,s,t]     and d1Sub_I_m[i,s,afgsub,t])      "Subsidy rate on foreign investment input"
    tSub_Fin_y[r,afgsub,t]$(d1Fin_y[r,t]     and d1Sub_Fin_y[r,afgsub,t])                                   "Sub rate on domestic financial service"
    tSub_Fin_m[r,afgsub,t]$(d1Fin_m[r,t]     and d1Sub_Fin_m[r,afgsub,t])                                   "Sub rate on foreign financial service"
  ;   


  $GROUP G_tax_rates_endo
    tC_y[c,s,t]$(d1C_y[c,s,t])      "Tax rate on private consumption of domestic origin"
    tC_m[c,s,t]$(d1C_m[c,s,t])      "Tax rate on private consumption of foreign origin"
    tG_y[g,s,t]$(d1G_y[g,s,t])      "Tax rate on public consumption of domestic origin"
    tG_m[g,s,t]$(d1G_m[g,s,t])      "Tax rate on public consumption of foreign origin"
    tX_y[x,s,t]$(d1X_y[x,s,t])      "Tax rate on exports of domestic origin"
    tX_m[x,s,t]$(d1X_m[x,s,t])      "Tax rate on exports of foreign origin"
    tRxE_y[r,s,t]$(d1RxE_y[r,s,t])  "Tax rate on domestic material input"
    tRxE_m[r,s,t]$(d1RxE_m[r,s,t])  "Tax rate on foreign material input"
    tFin_y[r,t]$(d1Fin_y[r,t])      "Tax rate on domestic input from the financial sector"
    tFin_m[r,t]$(d1Fin_m[r,t])      "Tax rate on foreign input from the financial sector"
    tI_y[i,s,t]$(d1I_y[i,s,t])      "Tax rate on domestic investment input"
    tI_m[i,s,t]$(d1I_m[i,s,t])      "Tax rate on foreign investment input"
    tL[s,t]                         "Tax rate on labor in production"
   ;


  $GROUP G_taxes_IO
    G_tDuty

    tCus_C_m[c,s,t]$(d1C_m[c,s,t])      "Customs tax rate on private consumption of foreign origin"
    tCus_G_m[g,s,t]$(d1G_m[g,s,t])      "Customs tax rate on public consumption of foreign origin"
    tCus_X_m[x,s,t]$(d1X_m[x,s,t])      "Customs tax rate on exports of foreign origin"
    tCus_RxE_m[r,s,t]$(d1RxE_m[r,s,t])  "Customs tax rate on foreign material input"
    tCus_I_m[i,s,t]$(d1I_m[i,s,t])      "Customs tax rate on foreign investment input"
    tCus_Fin_m[r,t]                     "Customs tax rate on foreign financial service"

    tVAT_C_y[c,s,t]$(d1C_y[c,s,t])      "VAT rate on private consumption of domestic origin"
    tVAT_C_m[c,s,t]$(d1C_m[c,s,t])      "VAT rate on private consumption of foreign origin"
    tVAT_G_y[g,s,t]$(d1G_y[g,s,t])      "VAT rate on public consumption of domestic origin"
    tVAT_G_m[g,s,t]$(d1G_m[g,s,t])      "VAT rate on public consumption of foreign origin"
    tVAT_X_y[x,s,t]$(d1X_y[x,s,t])      "VAT rate on exports of domestic origin"
    tVAT_X_m[x,s,t]$(d1X_m[x,s,t])      "VAT rate on exports of foreign origin"
    tVAT_RxE_y[r,s,t]$(d1RxE_y[r,s,t])  "VAT rate on domestic material input"
    tVAT_RxE_m[r,s,t]$(d1RxE_m[r,s,t])  "VAT rate on foreign material input"
    tVat_Fin_y[r,t]$(d1Fin_y[r,t])      "VAT rate on domestic financial service"
    tVat_Fin_m[r,t]$(d1Fin_m[r,t])      "VAT rate on foreign financial service" 

    tVAT_I_y[i,s,t]$(d1I_y[i,s,t])      "VAT rate on domestic investment input"
    tVAT_I_m[i,s,t]$(d1I_m[i,s,t])      "VAT rate on foreign investment input"

    tLPayRoll[s,t]                      "Tax rate of payroll taxes"
    tLAM[s,t]                           "Tax rate of firms AM contributions - AM-bidrag betalt af virksomheder"
    tLSubsidy[s,t]                      "Tax rate of worker subsidies - l�ntilskud"
  ;

  $GROUP G_taxes_other
    tNetYRest[s,t]$(not Agri_sectors_s[s])                               "Other production taxes relative to Gross value added"
    jtCO2_RE[purpose,energy19,r,t]$(d1CO2_RE[purpose,energy19,r,t])      "J-term to capture issues with data and for the cases where the marignal tax-rate is zero, but the revenue is positive"
    jtEAFG_RE[purpose,energy19,r,t]$(d1EAFG_RE[purpose,energy19,r,t])    "J-term to capture issues with data and for the cases where the marignal tax-rate is zero, but the revenue is positive"
    jEmmProdE_dedETS[r,t]$(d1CO2_ETS[r,t])                               "�J-term to ensure that total quota payments in data year is matched�"

    pY_CET[out,s,t]$(sameas[out,'out_other'] and (sum(c,d1C_y[c,s,t]) or sum(g,d1G_y[g,s,t]) or sum(x,d1X_y[x,s,t]) or sum(r,d1RxE_y[r,s,t]) or sum(i,d1I_y[i,s,t]))) ""
    pM_CET[out,s,t]$(sameas[out,'out_other'] and (sum(c,d1C_m[c,s,t]) or sum(g,d1G_m[g,s,t]) or sum(x,d1X_m[x,s,t]) or sum(r,d1RxE_m[r,s,t]) or sum(i,d1I_m[i,s,t]))) ""

    vCO2_ani[emmtype,Ani_sectors,Animals,t]$(d1EmmAgrAni[emmtype,ani_sectors,Animals,t,'CO2e']) ""
    vCO2_plant[plant_sectors,Plant_,t]$(sum(emmtype, emmtype2plant_(emmtype,plant_) and d1EmmAgrxE[emmtype,plant_sectors,t,'CO2e'])) ""
  ;

  PARAMETER d1tREmarg(s);

$ENDIF 



$IF %stage% == "groupcompilation":

  $GROUP G_taxes_bottom_endo
  G_tax_rates_endo                        
  ;

 $GROUP G_taxes_bottom_endo G_taxes_bottom_endo$(tx0[t]); # Restrict endo group to tx0[t]

  $GROUP G_taxes_bottom_exo
    G_taxes_IO
    -tLPayRoll                     
    -tLAM                         
    -tLSubsidy
    -tCus_Fin_m[r,t]$(not d1Fin_m[r,t])

pY_CET$(sameas[out,'out_other'] and (sum(c,sum(afgsub,d1Duty_C_y[c,s,afgsub,t])) or sum(c,sum(afgsub,d1Sub_C_y[c,s,afgsub,t]))))
pY_CET$(sameas[out,'out_other'] and (sum(g,sum(afgsub,d1Duty_G_y[g,s,afgsub,t])) or sum(g,sum(afgsub,d1Sub_G_y[g,s,afgsub,t]))))
pY_CET$(sameas[out,'out_other'] and (sum(x,sum(afgsub,d1Duty_X_y[x,s,afgsub,t])) or sum(x,sum(afgsub,d1Sub_X_y[x,s,afgsub,t]))))
pY_CET$(sameas[out,'out_other'] and (sum(r,sum(afgsub,d1Duty_RxE_y[r,s,afgsub,t])) or sum(r,sum(afgsub,d1Sub_RxE_y[r,s,afgsub,t]))))
pY_CET$(sameas[out,'out_other'] and (sum(i,sum(afgsub,d1Duty_I_y[i,s,afgsub,t])) or sum(i,sum(afgsub,d1Sub_I_y[i,s,afgsub,t]))))

pM_CET$(sameas[out,'out_other'] and (sum(c,sum(afgsub,d1Duty_C_m[c,s,afgsub,t])) or sum(c,sum(afgsub,d1Sub_C_m[c,s,afgsub,t]))))
pM_CET$(sameas[out,'out_other'] and (sum(g,sum(afgsub,d1Duty_G_m[g,s,afgsub,t])) or sum(g,sum(afgsub,d1Sub_G_m[g,s,afgsub,t]))))
pM_CET$(sameas[out,'out_other'] and (sum(x,sum(afgsub,d1Duty_X_m[x,s,afgsub,t])) or sum(x,sum(afgsub,d1Sub_X_m[x,s,afgsub,t]))))
pM_CET$(sameas[out,'out_other'] and (sum(r,sum(afgsub,d1Duty_RxE_m[r,s,afgsub,t])) or sum(r,sum(afgsub,d1Sub_RxE_m[r,s,afgsub,t]))))
pM_CET$(sameas[out,'out_other'] and (sum(i,sum(afgsub,d1Duty_I_m[i,s,afgsub,t])) or sum(i,sum(afgsub,d1Sub_I_m[i,s,afgsub,t]))))
    
    # E_tL
    vtL$(s[s_])
    w
    qL$(s[s_])
  ;

 $GROUP G_taxes_bottom_exo G_taxes_bottom_exo$(tx0[t]); # Restrict exo group to tx0[t]

  $GROUP G_taxes_total_endo
    G_taxes_values
  ;

 $GROUP G_taxes_total_endo G_taxes_total_endo$(tx0[t]); # Restrict endo group to tx0[t]

  $GROUP G_taxes_total_exo
    G_taxes_IO

    tC_m$(d1C_m[c,s,t]) 
    tG_m$(d1G_m[g,s,t])
    tX_m$(d1X_m[x,s,t])
    tRxE_m$(d1RxE_m[r,s,t]) 
    tFin_m
    tI_m$(d1I_m[i,s,t])

    vC_y$(d1C_y[c,s,t])
    vC_m$(d1C_m[c,s,t])
    vG_y$(d1G_y[g,s,t])
    vG_m$(d1G_m[g,s,t])
    vX_y$(d1X_y[x,s,t])
    vX_m$(d1X_m[x,s,t])
    vRxE_y$(d1RxE_y[r,s,t])
    vRxE_m$(d1RxE_m[r,s,t])
    vFin_y$(d1Fin_y[r,t])
    vFin_m
    vI_y$(d1I_y[i,s,t])
    vI_m$(d1I_m[i,s,t])
    qC_m$(sum(afgsub,d1Duty_C_m[c,s,afgsub,t]) or sum(afgsub,d1Sub_C_m[c,s,afgsub,t]))
    qC_y$(sum(afgsub,d1Duty_C_y[c,s,afgsub,t]) or sum(afgsub,d1Sub_C_y[c,s,afgsub,t]))

    qY$(not Agri_sectors_s_[s_] and s(s_)) 
    
    qG_m$(sum(afgsub,d1Duty_G_m[g,s,afgsub,t]) or sum(afgsub,d1Sub_G_m[g,s,afgsub,t]))
    qG_y$(sum(afgsub,d1Duty_G_y[g,s,afgsub,t]) or sum(afgsub,d1Sub_G_y[g,s,afgsub,t]))

    qI_m$(d1I_m[i,s,t] and (sum(afgsub,d1Duty_I_m[i,s,afgsub,t]) or sum(afgsub,d1Sub_I_m[i,s,afgsub,t])))
    qI_y$(d1I_y[i,s,t] and (sum(afgsub,d1Duty_I_y[i,s,afgsub,t]) or sum(afgsub,d1Sub_I_y[i,s,afgsub,t])))

    qRxE_m$(sum(afgsub,d1Duty_RxE_m[r,s,afgsub,t]) or sum(afgsub,d1Sub_RxE_m[r,s,afgsub,t]))
    qRxE_y$(sum(afgsub,d1Duty_RxE_y[r,s,afgsub,t]) or sum(afgsub,d1Sub_RxE_y[r,s,afgsub,t]))

    qFin_y$(sum(afgsub,d1Duty_Fin_y[r,afgsub,t]) or sum(afgsub,d1Sub_Fin_y[r,afgsub,t]))
    qFin_m$(sum(afgsub,d1Duty_Fin_m[r,afgsub,t]) or sum(afgsub,d1Sub_Fin_m[r,afgsub,t]))

    qX_m$(sum(afgsub,d1Duty_X_m[x,s,afgsub,t]) or sum(afgsub,d1Sub_X_m[x,s,afgsub,t]))
    qX_y$(sum(afgsub,d1Duty_X_y[x,s,afgsub,t]) or sum(afgsub,d1Sub_X_y[x,s,afgsub,t]))
    

    vtVAT_RE$(d1VAT_RE[purpose,energy19,r,t]), vtVAT_CE$(d1VAT_CE[purpose,energy19,t]), vtVAT_LE$(d1VAT_LE[purpose,energy19,t]), vtVAT_XE$(d1VAT_XE[purpose,energy19,t])
    vRxEEOP_ani$(sum(Emmtype, sum(animals,d1vEOPCostAni[Emmtype,ani_sectors,s,animals,t])))
    vRxEEOP_plant$(sum(Emmtype, d1vEOPCostplant[Emmtype,plant_sectors,s,t]))

    vtEAFG_RE$(d1EAFG_RE[purpose,energy19,r,t]), vtSO2_RE$(d1SO2_RE[purpose,energy19,r,t]), vtPSO_RE$(d1PSO_RE[purpose,energy19,r,t]), vtNOx_RE$(d1NOx_RE[purpose,energy19,r,t]), vtCO2_RE$(d1CO2_RE[purpose,energy19,r,t])
    vtEAFG_CE$(d1EAFG_CE[purpose,energy19,t]), vtSO2_CE$(d1SO2_CE[purpose,energy19,t]), vtPSO_CE$(d1PSO_CE[purpose,energy19,t]), vtNOx_CE$(d1NOx_CE[purpose,energy19,t]), vtCO2_CE$(d1CO2_CE[purpose,energy19,t])
    vtEAFG_LE$(d1EAFG_LE[purpose,energy19,t]), vtSO2_LE$(d1SO2_LE[purpose,energy19,t]), vtCO2_LE$(d1CO2_LE[purpose,energy19,t])
    vtEAFG_XE$(d1EAFG_XE[purpose,energy19,t]), vtSO2_XE$(d1SO2_XE[purpose,energy19,t]), vtPSO_XE$(d1PSO_XE[purpose,energy19,t]), vtCO2_XE$(d1CO2_XE[purpose,energy19,t])
    vtCO2_ProdxE$(d1EmmProdxE[s,t,emm] and d1CO2_ProdxE[s,t,emm])

    vCO2_ani$(d1EmmAgrAni[emmtype,ani_sectors,Animals,t,'CO2e'])
#      sum((ani_sectors,Animals,emmtype)$(d1EmmAgrAni[emmtype,ani_sectors,Animals,t,'CO2e']), vCO2_ani[Emmtype,Ani_sectors,Animals,t])
    vCO2_plant$(sum(emmtype, emmtype2plant_(emmtype,plant_) and d1EmmAgrxE[emmtype,plant_sectors,t,'CO2e']))

    tK$(d1K[k,s,t] and (sameas[k,'iB'] or sameas[k,'it']))
    pI_s$(d1K[i_,s,t] and (sameas[i_,'iB'] or sameas[i_,'it']))
    qK$(d1K[k,s,t] and (sameas[k,'iB'] or sameas[k,'it']))

    w$(tx0[t])
    qL$(s[s_])

    tNetYRest$(not Agri_sectors_s[s]) 

    #E_vtDuty 
    vTech_subsidy_ani$(tx0[t] and sum(emm, d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm]))
  ;

 $GROUP G_taxes_total_exo G_taxes_total_exo$(tx0[t]); # Restrict exo group to tx0[t]

  $GROUP G_taxes_data
    tL[s,t]                        "Tax rate on labor in production"
    G_taxes_IO
    vtNetProductionRest$(not sameas[s_,'tot'])
    tL
  ;

$ENDIF


# ========================================================================================================================
# Equations
# ========================================================================================================================
$IF %stage% == "equations":

  $BLOCK B_taxes_bottom
    # Total rate on duties, taxes and VAT (Samlet sats for told, afgifter og moms)
    E_tC_y[c,s,t]$(tx0[t] and d1C_y[c,s,t]).. tC_y[c,s,t] =E= (1+(1/pY_CET['out_other',s,t])*sum(afgsub, tDuty_C_y[c,s,afgsub,t]$d1Duty_C_y[c,s,afgsub,t] + tSub_C_y[c,s,afgsub,t]$d1Sub_C_y[c,s,afgsub,t])) * (1+tVAT_C_y[c,s,t]) - 1;

    E_tC_m[c,s,t]$(tx0[t] and d1C_m[c,s,t]).. tC_m[c,s,t] =E= (1+tCus_C_m[c,s,t]) * (1+(1/pM_CET['out_other',s,t])*sum(afgsub, tDuty_C_m[c,s,afgsub,t]$d1Duty_C_m[c,s,afgsub,t] + tSub_C_m[c,s,afgsub,t]$d1Sub_C_m[c,s,afgsub,t])) * (1+tVAT_C_m[c,s,t]) - 1;

    E_tG_y[g,s,t]$(tx0[t] and d1G_y[g,s,t]).. tG_y[g,s,t] =E= (1+(1/pY_CET['out_other',s,t])*sum(afgsub,tDuty_G_y[g,s,afgsub,t]$d1Duty_G_y[g,s,afgsub,t] + tSub_G_y[g,s,afgsub,t]$d1Sub_G_y[g,s,afgsub,t])) * (1+tVAT_G_y[g,s,t]) - 1;

    E_tG_m[g,s,t]$(tx0[t] and d1G_m[g,s,t]).. tG_m[g,s,t] =E= (1+tCus_G_m[g,s,t]) * (1+(1/pM_CET['out_other',s,t])*sum(afgsub,tDuty_G_m[g,s,afgsub,t]$d1Duty_G_m[g,s,afgsub,t] + tSub_g_m[g,s,afgsub,t]$d1Sub_G_m[g,s,afgsub,t])) * (1+tVAT_G_m[g,s,t]) - 1;

    E_tX_y[x,s,t]$(tx0[t] and d1X_y[x,s,t]).. tX_y[x,s,t] =E= (1+(1/pY_CET['out_other',s,t])*sum(afgsub,tDuty_X_y[x,s,afgsub,t]$d1Duty_X_y[x,s,afgsub,t] + tSub_x_y[x,s,afgsub,t]$d1Sub_x_y[x,s,afgsub,t])) * (1+tVAT_X_y[x,s,t]) - 1;

    E_tX_m[x,s,t]$(tx0[t] and d1X_m[x,s,t]).. tX_m[x,s,t] =E= (1+tCus_X_m[x,s,t]) * (1+(1/pM_CET['out_other',s,t])*sum(afgsub,tDuty_X_m[x,s,afgsub,t]$d1Duty_X_m[x,s,afgsub,t] + tSub_x_m[x,s,afgsub,t]$d1Sub_x_m[x,s,afgsub,t])) * (1+tVAT_X_m[x,s,t]) - 1;

    E_tRxE_y[r,s,t]$(tx0[t] and d1RxE_y[r,s,t]).. tRxE_y[r,s,t] =E= (1+(1/pY_CET['out_other',s,t])*sum(afgsub, tDuty_RxE_y[r,s,afgsub,t]$d1Duty_RxE_y[r,s,afgsub,t] + tSub_RxE_y[r,s,afgsub,t]$d1Sub_RxE_y[r,s,afgsub,t])) * (1+tVAT_RxE_y[r,s,t]) - 1;

    E_tRxE_m[r,s,t]$(tx0[t] and d1RxE_m[r,s,t]).. tRxE_m[r,s,t] =E= (1+tCus_RxE_m[r,s,t]) * (1+(1/pM_CET['out_other',s,t])*sum(afgsub,tDuty_RxE_m[r,s,afgsub,t]$d1Duty_RxE_m[r,s,afgsub,t] + tSub_RxE_m[r,s,afgsub,t]$d1Sub_RxE_m[r,s,afgsub,t])) * (1+tVAT_RxE_m[r,s,t]) - 1;

    E_tFin_y[r,t]$(tx0[t] and d1Fin_y[r,t]).. tFin_y[r,t] =E= (1+(1/pY_CET['out_other','64000',t])*sum(afgsub,tDuty_Fin_y[r,afgsub,t]$d1Duty_Fin_y[r,afgsub,t] + tSub_Fin_y[r,afgsub,t]$d1Sub_Fin_y[r,afgsub,t])) * (1+tVAT_Fin_y[r,t]) - 1;

    E_tFin_m[r,t]$(tx0[t] and d1Fin_m[r,t]).. tFin_m[r,t] =E= (1+tCus_Fin_m[r,t]) * (1+(1/pM_CET['out_other','64000',t])*sum(afgsub,tDuty_Fin_m[r,afgsub,t]$d1Duty_Fin_m[r,afgsub,t] + tSub_Fin_m[r,afgsub,t]$d1Sub_Fin_m[r,afgsub,t])) * (1+tVAT_Fin_m[r,t]) - 1;

    E_tI_y[i,s,t]$(tx0[t] and d1I_y[i,s,t]).. tI_y[i,s,t] =E= (1+(1/pY_CET['out_other',s,t])*sum(afgsub,tDuty_I_y[i,s,afgsub,t]$d1Duty_I_y[i,s,afgsub,t] + tSub_I_y[i,s,afgsub,t]$d1Sub_I_y[i,s,afgsub,t])) * (1+tVAT_I_y[i,s,t]) - 1;

    E_tI_m[i,s,t]$(tx0[t] and d1I_m[i,s,t]).. tI_m[i,s,t] =E= (1+tCus_I_m[i,s,t]) * (1+(1/pM_CET['out_other',s,t])*sum(afgsub,tDuty_I_m[i,s,afgsub,t]$d1Duty_I_m[i,s,afgsub,t] + tSub_i_m[i,s,afgsub,t]$d1Sub_I_m[i,s,afgsub,t])) * (1+tVAT_I_m[i,s,t]) - 1;

    E_tL[s,t]$(tx0[t])..                          tL[s,t] =E= vtL[s,t] / (w[t] * qL[s,t]);

  $ENDBLOCK

  $BLOCK B_taxes_total

    # Provenu from VAT (moms)  
    E_vtCVAT[c,t]$(tx0[t])..   vtCVAT[c,t]      =E= sum(s$d1C_y[c,s,t], tVAT_C_y[c,s,t] * vC_y[c,s,t] / (1+tVAT_C_y[c,s,t])) 
                                                  + sum(s$d1C_m[c,s,t], tVAT_C_m[c,s,t] * vC_m[c,s,t] / (1+tVAT_C_m[c,s,t]));

    E_vtCVAT_tot[t]$(tx0[t]).. vtCVAT['Ctot',t] =E= sum(c, vtCVAT[c,t]);
   
    E_vtGVAT[g,t]$(tx0[t])..   vtGVAT[g,t]      =E= sum(s$d1G_y[g,s,t], tVAT_G_y[g,s,t] * vG_y[g,s,t] / (1+tVAT_G_y[g,s,t]))
                                                        + sum(s$d1G_m[g,s,t],tVAT_G_m[g,s,t] * vG_m[g,s,t] / (1+tVAT_G_m[g,s,t]));

    E_vtGVAT_tot[t]$(tx0[t]).. vtGVAT['Gtot',t] =E= sum(g, vtGVAT[g,t]);
   
    E_vtXVAT[x,t]$(tx0[t])..   vtXVAT[x,t]      =E= sum(s$d1X_y[x,s,t], tVAT_X_y[x,s,t] * vX_y[x,s,t] / (1+tVAT_X_y[x,s,t]))
                                                        + sum(s$d1X_m[x,s,t],tVAT_X_m[x,s,t] * vX_m[x,s,t] / (1+tVAT_X_m[x,s,t]));

    E_vtXVAT_tot[t]$(tx0[t]).. vtXVAT['xtot',t] =E= sum(x, vtXVAT[x,t]);
   
    E_vtRxEVAT[r,t]$(tx0[t]).. vtRxEVAT[r,t]    =E= sum(s$d1RxE_y[r,s,t], tVAT_RxE_y[r,s,t] * vRxE_y[r,s,t] / (1+tVAT_RxE_y[r,s,t]))
                                                  + sum(s$d1RxE_m[r,s,t],tVAT_RxE_m[r,s,t] * vRxE_m[r,s,t] / (1+tVAT_RxE_m[r,s,t]));

    E_vtRxEVAT_tot[t]$(tx0[t]).. vtRxEVAT['Rtot',t] =E= sum(r, vtRxEVAT[r,t]);

    E_vtFinVAT[r,t]$(tx0[t]).. vtFinVAT[r,t]     =E= (tVAT_Fin_y[r,t] * vFin_y[r,t] / (1+tVAT_Fin_y[r,t]))$(d1Fin_y[r,t])
                                                        + (vFin_m[r,t] / (1+tVAT_Fin_m[r,t]))$(d1Fin_m[r,t]);

    E_vtFinVAT_tot[t]$(tx0[t]).. vtFinVAT['Rtot',t] =E= sum(r, vtFinVAT[r,t]);
   
    E_vtIVAT[i,t]$(tx0[t])..   vtIVAT[i,t]      =E= sum(s$d1I_y[i,s,t], tVAT_I_y[i,s,t] * vI_y[i,s,t] / (1+tVAT_I_y[i,s,t]))
                                                        + sum(s$d1I_m[i,s,t],tVAT_I_m[i,s,t] * vI_m[i,s,t] / (1+tVAT_I_m[i,s,t]));

    E_vtIVAT_tot[t]$(tx0[t]).. vtIVAT['Itot',t] =E= sum(i, vtIVAT[i,t]);

    E_vtVAT[t] $tx0[t].. vtVAT[t] =E= vtCVAT['ctot',t]
                                    + vtGVAT['gtot',t]
                                    + vtXVAT['xtot',t]
                                    + vtIVAT['itot',t]
                                    + vtRxEVAT['rtot',t]
                                    + vtFinVAT['rtot',t]
                                    + sum((purpose,energy19,r)$d1VAT_RE[purpose,energy19,r,t], vtVAT_RE[purpose,energy19,r,t])
                                    + sum((purpose,energy19)$d1VAT_CE[purpose,energy19,t],     vtVAT_CE[purpose,energy19,t])
                                    + sum((purpose,energy19)$d1VAT_LE[purpose,energy19,t],     vtVAT_LE[purpose,energy19,t])
                                    + sum((purpose,energy19)$d1VAT_XE[purpose,energy19,t],     vtVAT_XE[purpose,energy19,t])
                                    + sum((ani_sectors,s)$(sum((Emmtype,animals),d1vEOPCostAni[Emmtype,ani_sectors,s,animals,t])), vRxEEOP_ani[ani_sectors,s,t])
                                    + sum((plant_sectors,s)$(sum(Emmtype,d1vEOPCostplant[Emmtype,plant_sectors,s,t])), vRxEEOP_plant[plant_sectors,s,t])
                                    ;

    # Net provenu from excise duties, subsidies on products and registration fees (punktafgifter, produktsubsidier og registreringsafgifter) 
    # E_vtCDuty[c,t]$(tx0[t])..   vtCDuty[c,t]            =E=  sum(s$d1C_y[c,s,t],                       sum(afgsub, tDuty_C_y[c,s,afgsub,t]$d1Duty_C_y[c,s,afgsub,t] + tSub_C_y[c,s,afgsub,t]$d1Sub_C_y[c,s,afgsub,t]) * vC_y[c,s,t] / (1+tC_y[c,s,t]))
    #                                                        + sum(s$d1C_m[c,s,t], (1+tCus_C_m[c,s,t]) * sum(afgsub, tDuty_C_m[c,s,afgsub,t]$d1Duty_C_m[c,s,afgsub,t] + tSub_C_m[c,s,afgsub,t]$d1Sub_C_m[c,s,afgsub,t]) * vC_m[c,s,t] / (1+tC_m[c,s,t]));

    E_vtCDuty[c,t]$(tx0[t])..   vtCDuty[c,t]            =E=  sum(s$d1C_y[c,s,t],                       sum(afgsub, tDuty_C_y[c,s,afgsub,t]$d1Duty_C_y[c,s,afgsub,t] + tSub_C_y[c,s,afgsub,t]$d1Sub_C_y[c,s,afgsub,t]) * qC_y[c,s,t])
                                                           + sum(s$d1C_m[c,s,t], (1+tCus_C_m[c,s,t]) * sum(afgsub, tDuty_C_m[c,s,afgsub,t]$d1Duty_C_m[c,s,afgsub,t] + tSub_C_m[c,s,afgsub,t]$d1Sub_C_m[c,s,afgsub,t]) * qC_m[c,s,t]);


    E_vtCDuty_tot[t]$(tx0[t]).. vtCDuty['Ctot',t]       =E= sum(c, vtCDuty[c,t]);
    
    # E_vtGDuty[g,t]$(tx0[t])..   vtGDuty[g,t]            =E= sum(s$d1G_y[g,s,t],                       sum(afgsub,tDuty_G_y[g,s,afgsub,t]$d1Duty_G_y[g,s,afgsub,t] + tSub_G_y[g,s,afgsub,t]$d1Sub_G_y[g,s,afgsub,t]) * vG_y[g,s,t] / (1+tG_y[g,s,t]))
    #                                                         + sum(s$d1G_m[g,s,t], (1+tCus_G_m[g,s,t]) * sum(afgsub,tDuty_G_m[g,s,afgsub,t]$d1Duty_G_m[g,s,afgsub,t] + tSub_G_m[g,s,afgsub,t]$d1Sub_g_m[g,s,afgsub,t]) * vG_m[g,s,t] / (1+tG_m[g,s,t]));

    E_vtGDuty[g,t]$(tx0[t])..   vtGDuty[g,t]            =E= sum(s$d1G_y[g,s,t],                       sum(afgsub,tDuty_G_y[g,s,afgsub,t]$d1Duty_G_y[g,s,afgsub,t] + tSub_G_y[g,s,afgsub,t]$d1Sub_G_y[g,s,afgsub,t]) * qG_y[g,s,t])
                                                            + sum(s$d1G_m[g,s,t], (1+tCus_G_m[g,s,t]) * sum(afgsub,tDuty_G_m[g,s,afgsub,t]$d1Duty_G_m[g,s,afgsub,t] + tSub_G_m[g,s,afgsub,t]$d1Sub_g_m[g,s,afgsub,t]) * qG_m[g,s,t]);


    E_vtGDuty_tot[t]$(tx0[t]).. vtGDuty['Gtot',t]       =E= sum(g, vtGDuty[g,t]);
    
    # E_vtXDuty[x,t]$(tx0[t])..   vtXDuty[x,t]            =E= sum(s$d1X_y[x,s,t],                       sum(afgsub,tDuty_X_y[x,s,afgsub,t]$d1DUty_x_y[x,s,afgsub,t] + tSub_x_y[x,s,afgsub,t]$d1SUb_x_y[x,s,afgsub,t]) * vX_y[x,s,t] / (1+tX_y[x,s,t]))
    #                                                         + sum(s$d1X_m[x,s,t], (1+tCus_X_m[x,s,t]) * sum(afgsub,tDuty_X_m[x,s,afgsub,t]$d1Duty_x_m[x,s,afgsub,t] + tSub_x_m[x,s,afgsub,t]$d1Sub_x_m[x,s,afgsub,t]) * vX_m[x,s,t] / (1+tX_m[x,s,t]));

    E_vtXDuty[x,t]$(tx0[t])..   vtXDuty[x,t]            =E= sum(s$d1X_y[x,s,t],                       sum(afgsub,tDuty_X_y[x,s,afgsub,t]$d1DUty_x_y[x,s,afgsub,t] + tSub_x_y[x,s,afgsub,t]$d1SUb_x_y[x,s,afgsub,t]) * qX_y[x,s,t])
                                                            + sum(s$d1X_m[x,s,t], (1+tCus_X_m[x,s,t]) * sum(afgsub,tDuty_X_m[x,s,afgsub,t]$d1Duty_x_m[x,s,afgsub,t] + tSub_x_m[x,s,afgsub,t]$d1Sub_x_m[x,s,afgsub,t]) * qX_m[x,s,t]);


    E_vtXDuty_tot[t]$(tx0[t]).. vtXDuty['Xtot',t]       =E= sum(x, vtXDuty[x,t]);
    
    # E_vtRxEDuty[r,t]$(tx0[t]).. vtRxEDuty[r,t]          =E= sum(s$d1RxE_y[r,s,t],                       sum(afgsub,tDuty_RxE_y[r,s,afgsub,t]$d1Duty_RxE_y[r,s,afgsub,t] + tSub_RxE_y[r,s,afgsub,t]$d1Sub_RxE_y[r,s,afgsub,t]) * vRxE_y[r,s,t] / (1+tRxE_y[r,s,t]))
    #                                                         + sum(s$d1RxE_m[r,s,t], (1+tCus_RxE_m[r,s,t]) * sum(afgsub,tDuty_RxE_m[r,s,afgsub,t]$d1Duty_RxE_m[r,s,afgsub,t] + tSub_RxE_m[r,s,afgsub,t]$d1Sub_RxE_m[r,s,afgsub,t]) * vRxE_m[r,s,t] / (1+tRxE_m[r,s,t]));

    E_vtRxEDuty[r,t]$(tx0[t]).. vtRxEDuty[r,t]          =E= sum(s$d1RxE_y[r,s,t],                       sum(afgsub,tDuty_RxE_y[r,s,afgsub,t]$d1Duty_RxE_y[r,s,afgsub,t] + tSub_RxE_y[r,s,afgsub,t]$d1Sub_RxE_y[r,s,afgsub,t]) * qRxE_y[r,s,t])
                                                            + sum(s$d1RxE_m[r,s,t], (1+tCus_RxE_m[r,s,t]) * sum(afgsub,tDuty_RxE_m[r,s,afgsub,t]$d1Duty_RxE_m[r,s,afgsub,t] + tSub_RxE_m[r,s,afgsub,t]$d1Sub_RxE_m[r,s,afgsub,t]) * qRxE_m[r,s,t]);


    E_vtRxEDuty_tot[t]$(tx0[t]).. vtRxEDuty['Rtot',t]   =E= sum(r, vtRxEDuty[r,t]);

    # E_vtFinDuty[r,t]$(tx0[t])..   vtFinDuty[r,t]     =E= (sum(afgsub,tDuty_Fin_y[r,afgsub,t]$d1Duty_Fin_y[r,afgsub,t] + tSub_fin_y[r,afgsub,t]$d1Sub_Fin_y[r,afgsub,t]) * vFin_y[r,t] / (1+tFin_y[r,t]))$(d1Fin_y[r,t])
    #                                                       + ((1+tCus_Fin_m[r,t]) * sum(afgsub,tDuty_Fin_m[r,afgsub,t]$d1Duty_Fin_m[r,afgsub,t] + tSub_Fin_m[r,afgsub,t]$d1Sub_Fin_m[r,afgsub,t]) * vFin_m[r,t] / (1+tFin_m[r,t]))$(d1Fin_m[r,t]);

    E_vtFinDuty[r,t]$(tx0[t])..   vtFinDuty[r,t]     =E= (sum(afgsub,tDuty_Fin_y[r,afgsub,t]$d1Duty_Fin_y[r,afgsub,t] + tSub_fin_y[r,afgsub,t]$d1Sub_Fin_y[r,afgsub,t]) * qFin_y[r,t]$(d1Fin_y[r,t]))
                                                          + ((1+tCus_Fin_m[r,t]) * sum(afgsub,tDuty_Fin_m[r,afgsub,t]$d1Duty_Fin_m[r,afgsub,t] + tSub_Fin_m[r,afgsub,t]$d1Sub_Fin_m[r,afgsub,t]) * qFin_m[r,t]$d1Fin_m[r,t]);


    E_vtFinDuty_tot[t]$(tx0[t]).. vtFinDuty['Rtot',t] =E= sum(r, vtFinDuty[r,t]);

    # E_vtIDuty[i,t]$(tx0[t])..   vtIDuty[i,t]     =E= sum(s$d1I_y[i,s,t],                       sum(afgsub,tDuty_I_y[i,s,afgsub,t]$d1Duty_I_y[i,s,afgsub,t] + tSub_I_y[i,s,afgsub,t]$d1Sub_I_y[i,s,afgsub,t]) * vI_y[i,s,t] / (1+tI_y[i,s,t]))
    #                                                       + sum(s$d1I_m[i,s,t], (1+tCus_I_m[i,s,t]) * sum(afgsub,tDuty_I_m[i,s,afgsub,t]$d1Duty_I_m[i,s,afgsub,t] + tSub_I_m[i,s,afgsub,t]$d1Sub_I_m[i,s,afgsub,t]) * vI_m[i,s,t] / (1+tI_m[i,s,t]));

    E_vtIDuty[i,t]$(tx0[t])..   vtIDuty[i,t]     =E= sum(s$d1I_y[i,s,t],                       sum(afgsub,tDuty_I_y[i,s,afgsub,t]$d1Duty_I_y[i,s,afgsub,t] + tSub_I_y[i,s,afgsub,t]$d1Sub_I_y[i,s,afgsub,t]) * qI_y[i,s,t])
                                                          + sum(s$d1I_m[i,s,t], (1+tCus_I_m[i,s,t]) * sum(afgsub,tDuty_I_m[i,s,afgsub,t]$d1Duty_I_m[i,s,afgsub,t] + tSub_I_m[i,s,afgsub,t]$d1Sub_I_m[i,s,afgsub,t]) * qI_m[i,s,t]);

    E_vtIDuty_tot[t]$(tx0[t]).. vtIDuty['Itot',t]       =E= sum(i, vtIDuty[i,t]);

    
    E_vtDuty[t] $tx0[t]..       vtDuty[t]        =E= vtCDuty['Ctot',t]
                                                   + vtGDuty['Gtot',t]
                                                   + vtXDuty['Xtot',t]
                                                   + vtIDuty['Itot',t]
                                                   + vtRxEDuty['Rtot',t]
                                                   + vtFinDuty['Rtot',t]
                                                   + sum((purpose,energy19,r), vtEAFG_RE[purpose,energy19,r,t]$d1EAFG_RE[purpose,energy19,r,t] + vtSO2_RE[purpose,energy19,r,t]$d1SO2_RE[purpose,energy19,r,t] + vtPSO_RE[purpose,energy19,r,t]$d1PSO_RE[purpose,energy19,r,t] + vtNOx_RE[purpose,energy19,r,t]$d1NOx_RE[purpose,energy19,r,t] + vtCO2_RE[purpose,energy19,r,t]$d1CO2_RE[purpose,energy19,r,t])
                                                   + sum((purpose,energy19),   vtEAFG_CE[purpose,energy19,t]$d1EAFG_CE[purpose,energy19,t]     + vtSO2_CE[purpose,energy19,t]$d1SO2_CE[purpose,energy19,t]     + vtPSO_CE[purpose,energy19,t]$d1PSO_CE[purpose,energy19,t] + vtNOx_CE[purpose,energy19,t]$d1NOx_CE[purpose,energy19,t] + vtCO2_CE[purpose,energy19,t]$d1CO2_CE[purpose,energy19,t])
                                                   + sum((purpose,energy19),   vtEAFG_LE[purpose,energy19,t]$d1EAFG_LE[purpose,energy19,t]     + vtSO2_LE[purpose,energy19,t]$d1SO2_LE[purpose,energy19,t]     + vtCO2_LE[purpose,energy19,t]$d1CO2_LE[purpose,energy19,t])
                                                   + sum((purpose,energy19),   vtEAFG_XE[purpose,energy19,t]$d1EAFG_XE[purpose,energy19,t]     + vtSO2_XE[purpose,energy19,t]$d1SO2_XE[purpose,energy19,t]     + vtPSO_XE[purpose,energy19,t]$d1PSO_XE[purpose,energy19,t] + vtCO2_XE[purpose,energy19,t]$d1CO2_XE[purpose,energy19,t])
                                                   + sum((s,emm)$(d1EmmProdxE[s,t,emm] and d1CO2_ProdxE[s,t,emm]), vtCO2_ProdxE[s,t,emm])
                                                   + sum((ani_sectors,Animals,emmtype)$(d1EmmAgrAni[emmtype,ani_sectors,Animals,t,'CO2e']), vCO2_ani[Emmtype,Ani_sectors,Animals,t])
                                                   + sum((plant_sectors,plant_)$(sum(emmtype, emmtype2plant_(emmtype,plant_) and d1EmmAgrxE[emmtype,plant_sectors,t,'CO2e'])), vCO2_plant[plant_sectors,plant_,t])
                                                   + sum((ani_sectors,s)$(sum((Emmtype,animals),d1vEOPCostAni[Emmtype,ani_sectors,s,animals,t])), vRxEEOP_ani[ani_sectors,s,t])
                                                   + sum((plant_sectors,s)$(sum(Emmtype,d1vEOPCostplant[Emmtype,plant_sectors,s,t])), vRxEEOP_plant[plant_sectors,s,t])
                                                   - sum((Techani,Ani_sectors,emmtype,animals)$(sum(emm,d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm])), vTech_subsidy_ani[techani,EmmType,Ani_sectors,Animals,t])
                                                   ;

    # Value of customs
    E_vtCus_RxE_m[r,t]$(tx0[t])..        vtCus_RxE_m[r,t] =E= sum(s$d1RxE_m[r,s,t], tCus_RxE_m[r,s,t] * vRxE_m[r,s,t] / (1+tRxE_m[r,s,t]));
    E_vtCus_RxE_m_tot[t]$(tx0[t]).. vtCus_RxE_m['rtot',t] =E= sum(r, vtCus_RxE_m[r,t]);
    E_vtCus_Fin_m[r,t]$(tx0[t])..  vtCus_Fin_m[r,t]   =E= tCus_Fin_m[r,t] * vFin_m[r,t] / (1+tFin_m[r,t]);
    E_vtCus_Fin_m_tot[t]$(tx0[t]).. vtCus_Fin_m['rtot',t] =E= sum(r, vtCus_Fin_m[r,t]);
    E_vtCus_I_m[i,t]$(tx0[t])..        vtCus_I_m[i,t]     =E= sum(s$d1I_m[i,s,t], tCus_I_m[i,s,t] * vI_m[i,s,t] / (1+tI_m[i,s,t]));
    E_vtCus_I_tot[t]$(tx0[t])..       vtCus_I_m['Itot',t] =E= sum(i, vtCus_I_m[i,t]);
    E_vtCus_G_m[g,t]$(tx0[t])..            vtCus_G_m[g,t] =E= sum(s$d1G_m[g,s,t], tCus_G_m[g,s,t] * vG_m[g,s,t] / (1+tG_m[g,s,t]));
    E_vtCus_G_m_tot[t]$(tx0[t])..     vtCus_G_m['Gtot',t] =E= sum(g, vtCus_G_m[g,t]);
    E_vtCus_C_m[c,t]$(tx0[t])..            vtCus_C_m[c,t] =E= sum(s$d1C_m[c,s,t], tCus_C_m[c,s,t] * vC_m[c,s,t] / (1+tC_m[c,s,t]));
    E_vtCus_C_tot[t]$(tx0[t])..       vtCus_C_m['Ctot',t] =E= sum(c, vtCus_C_m[c,t]);
    E_vtCus_X_m[x,t]$(tx0[t])..            vtCus_X_m[x,t] =E= sum(s$d1X_m[x,s,t], tCus_X_m[x,s,t] * vX_m[x,s,t] / (1+tX_m[x,s,t]));
    E_vtCus_X_m_tot[t]$(tx0[t])..     vtCus_X_m['xtot',t] =E= sum(x, vtCus_X_m[x,t]);


    E_vtCus[t]$(tx0[t])..          vtCus[t]           =E= vtCus_C_m['Ctot',t]
                                                        + vtCus_G_m['Gtot',t] 
                                                        + vtCus_RxE_m['Rtot',t]
                                                        + vtCus_Fin_m['Rtot',t]
                                                        + vtCus_I_m['Itot',t]  
                                                        + vtCus_X_m['Xtot',t]; #AKB: Mangler energy-customs

                                                        

    # PRODUCTION TAXES
    E_vtLand[s,t]$(tx0[t] and d1K['iB',s,t])..        vtLand[s,t]              =E= tK['iB',s,t] * pI_s['iB',s,t] * qK['iB',s,t];
    E_vtFirmsWeight[s,t]$(tx0[t] and d1K['iT',s,t]).. vtFirmsWeight[s,t]  =E= tK['iT',s,t] * pI_s['iT',s,t] * qK['iT',s,t];

    E_vtLAM[s,t]$(tx0[t])..             vtLAM[s,t]      =E= tLAM[s,t]      * w[t] * qL[s,t];
    E_vtLSubsidy[s,t]$(tx0[t])..        vtLSubsidy[s,t] =E= tLSubsidy[s,t] * w[t] * qL[s,t];
    E_vtLPayRoll[s,t]$(tx0[t])..        vtLPayRoll[s,t] =E= tLPayRoll[s,t] * w[t] * qL[s,t];

    E_vtL[s,t]$(tx0[t])..               vtL[s,t] =E= vtLAM[s,t] + vtLPayRoll[s,t] - vtLSubsidy[s,t];
    
    E_vtNetProductionRest[s,t]$(tx0[t] and not agri_sectors_s[s])..  vtNetProductionRest[s,t] =E= tNetYRest[s,t] * qY[s,t];
    E_vtNetProductionRest_agri[s,t]$(tx0[t] and agri_sectors_s[s]).. vtNetProductionRest[s,t] =E= vtNetProductionRest.l[s,t];
    
    
    E_vtLand_tot[t]$(tx0[t])..                   vtLand['TOT',t]              =E= sum(s, vtLand[s,t]);
    E_vtFirmsWeight_tot[t]$(tx0[t])..            vtFirmsWeight['TOT',t]       =E= sum(s, vtFirmsWeight[s,t]);
    E_vtLPayRoll_tot[t]$(tx0[t])..               vtLPayRoll['TOT',t]          =E= sum(s, vtLPayRoll[s,t]);
    E_vtLAM_tot[t]$(tx0[t])..                    vtLAM['TOT',t]               =E= sum(s, vtLAM[s,t]);
    E_vtLSubsidy_tot[t]$(tx0[t])..               vtLSubsidy['TOT',t]          =E= sum(s, vtLSubsidy[s,t]);
    E_vtL_tot[t]$(tx0[t])..                      vtL['TOT',t]                 =E= sum(s, vtL[s,t]);
    E_vtNetProductionRest_tot[t]$(tx0[t])..      vtNetProductionRest['TOT',t] =E= sum(s, vtNetProductionRest[s,t]);
    
  $ENDBLOCK


   $MODEL M_taxes_bottom
    B_taxes_bottom
   ;

   $MODEL M_taxes_total
    B_taxes_total
   ;

 $ENDIF


# =====================================================================================================================
# Data assignment
# =====================================================================================================================
$IF %stage% == "exogenous_values":

  #1) READ DATA 
  
    #IO  
      $LOOP G_taxes_data:
        {name}.l{sets} = IO_{name}{sets};
      $ENDLOOP

      tLPayRoll.l[s,t] = io_tLPayRoll[s,t];
      tLSubsidy.l[s,t] = io_tLSubsidy[s,t];
      tLAM.l[s,t]      = io_tLAM[s,t];


  #2) EXOGENOUS PARAMETERS AND VARIABLES

  #3) COMPUTATIONS 

    #IO 
      # In forecast years we tax rates on net inventory investments follow the tax on material inputs.
    # As inventory investments are net, but tax revenue is gross, the imputed tax rates are nonsense. AKB: Update - all inventories are killed in forecast. 
    #  set_data_periods(%cal_start%, %cal_end%);
    tCus_I_m.l['invt',s,t]$tForecast[t]      = tCus_RxE_m.l[s,s,t];
    tDuty_I_y.l['invt',s,afgsub,t]$tForecast[t] = tDuty_RxE_y.l[s,s,afgsub,t];
    tDuty_I_m.l['invt',s,afgsub,t]$tForecast[t] = tDuty_RxE_m.l[s,s,afgsub,t];
    tVAT_I_y.l['invt',s,t]$tForecast[t]      = tVAT_RxE_y.l[s,s,t];
    tVAT_I_m.l['invt',s,t]$tForecast[t]      = tVAT_RxE_m.l[s,s,t];

  #4) INITIAL VALUES 

  #5) DUMMIES - NOTE, AGGREGATE DUMMY d1tRE IS CREATED IN UPDATE_DUMMIES.GMS
    #DUTIES 
      d1Duty_C_y[c,s,afgsub,t]   = yes$(IO_vtDuty_C_y[c,s,afgsub,t]);
      d1Duty_C_m[c,s,afgsub,t]   = yes$(IO_vtDuty_C_m[c,s,afgsub,t]);
      d1Duty_G_y[g,s,afgsub,t]   = yes$(IO_vtDuty_G_y[g,s,afgsub,t]);
      d1Duty_G_m[g,s,afgsub,t]   = yes$(IO_vtDuty_G_m[g,s,afgsub,t]);
      d1Duty_X_y[x,s,afgsub,t]   = yes$(IO_vtDuty_X_y[x,s,afgsub,t]);
      d1Duty_X_m[x,s,afgsub,t]   = yes$(IO_vtDuty_X_m[x,s,afgsub,t]);
      d1Duty_RxE_y[r,s,afgsub,t]   = yes$(IO_vtDuty_RxE_y[r,s,afgsub,t]);
      d1Duty_RxE_m[r,s,afgsub,t]   = yes$(IO_vtDuty_RxE_m[r,s,afgsub,t]);
      d1Duty_I_y[i,s,afgsub,t]   = yes$(IO_vtDuty_I_y[i,s,afgsub,t]);
      d1Duty_I_m[i,s,afgsub,t]   = yes$(IO_vtDuty_I_m[i,s,afgsub,t]);
      d1Duty_Fin_y[r,afgsub,t]   = yes$(IO_vtDuty_Fin_y[r,afgsub,t]);
      d1Duty_Fin_m[r,afgsub,t]   = yes$(IO_vtDuty_Fin_m[r,afgsub,t]);

      d1Sub_C_y[c,s,afgsub,t]   = yes$(IO_vtSub_C_y[c,s,afgsub,t]);
      d1Sub_C_m[c,s,afgsub,t]   = yes$(IO_vtSub_C_m[c,s,afgsub,t]);
      d1Sub_G_y[g,s,afgsub,t]   = yes$(IO_vtSub_G_y[g,s,afgsub,t]);
      d1Sub_G_m[g,s,afgsub,t]   = yes$(IO_vtSub_G_m[g,s,afgsub,t]);
      d1Sub_X_y[x,s,afgsub,t]   = yes$(IO_vtSub_X_y[x,s,afgsub,t]);
      d1Sub_X_m[x,s,afgsub,t]   = yes$(IO_vtSub_X_m[x,s,afgsub,t]);
      d1Sub_RxE_y[r,s,afgsub,t]   = yes$(IO_vtSub_RxE_y[r,s,afgsub,t]);
      d1Sub_RxE_m[r,s,afgsub,t]   = yes$(IO_vtSub_RxE_m[r,s,afgsub,t]);
      d1Sub_I_y[i,s,afgsub,t]   = yes$(IO_vtSub_I_y[i,s,afgsub,t]);
      d1Sub_I_m[i,s,afgsub,t]   = yes$(IO_vtSub_I_m[i,s,afgsub,t]);
      d1Sub_Fin_y[r,afgsub,t]   = yes$(IO_vtSub_Fin_y[r,afgsub,t]);
      d1Sub_Fin_m[r,afgsub,t]   = yes$(IO_vtSub_Fin_m[r,afgsub,t]);

$ENDIF


# =====================================================================================================================
# Static calibration
# =====================================================================================================================
$IF %stage% == "static_calibration":


  $GROUP G_taxes_static_calibration
    G_taxes_total_endo
    G_taxes_bottom_endo
    tNetYRest$(tx0[t] and not agri_sectors_s[s]), -vtNetProductionRest$(tx0[t] and s(s_))
  ;

  $GROUP G_taxes_static_calibration_exo
    G_taxes_total_exo
    -tC_m, -tG_m, -tX_m, -tRxE_m, -tFin_m$(d1Fin_m[r,t]), -tI_m
    G_taxes_bottom_exo
    -vtL
    vtNetProductionRest$(tx0[t] and s(s_)), -tNetYRest$(tx0[t] and not agri_sectors_s[s])
 ;

  $MODEL M_taxes_static_calibration
    B_taxes_total
    B_taxes_bottom
  ;

$ENDIF

# =====================================================================================================================
# Dynamic calibration
# =====================================================================================================================
$IF %stage% == "dynamic_calibration":

$GROUP G_taxes_calib
    G_taxes_bottom_endo
    G_taxes_total_endo
;

$GROUP G_taxes_calib_exo
    G_taxes_bottom_exo
    -tC_m, -tG_m, -tX_m, -tRxE_m, -tFin_m$(d1Fin_m[r,t]), -tI_m
    G_taxes_total_exo
    -vtL
;

$MODEL M_taxes_calib 
    B_taxes_bottom
    B_taxes_total
;
      
$ENDIF
