# =====================================================================================================================
# Taxes
# =====================================================================================================================
# Tax rates and revenue

# =====================================================================================================================
# Variable definition
# =====================================================================================================================
$IF %stage% == "variables":

  $GROUP G_energy_taxes_values 
    vtEAFG_RE[purpose,energy19,r,t]$(d1EAFG_RE[purpose,energy19,r,t])     "Value of energy-duty and water-duty, firms"
    vtEAFG_CE[purpose,energy19,t]$(d1EAFG_CE[purpose,energy19,t])         "Value of energy-duty and water-duty, consumers"
    vtEAFG_LE[purpose,energy19,t]$(d1EAFG_Le[purpose,energy19,t])         "Value of energy-duty and water-duty, inventories"
    vtEAFG_XE[purpose,energy19,t]$(d1EAFG_XE[purpose,energy19,t])         "Value of energy-duty and water-duty, exports"

    vtCO2_RE[purpose,energy19,r,t]$(d1CO2_RE[purpose,energy19,r,t])       "Value of CO2-duty, firms"
    vtCO2_ProdxE[s,t,emm]$(d1EmmProdxE[s,t,emm] and d1CO2_ProdxE[s,t,emm]) "Value of CO2-duty on non-energyrelated emissions, firms"
    vtCO2_CE[purpose,energy19,t]$(d1CO2_CE[purpose,energy19,t])           "Value of CO2-duty, consumers"
    vtCO2_CE_ETS2[purpose,energy19,t]$(d1CO2_CE_ETS2[purpose,energy19,t]) "Value of ETS2-paid by consumers"
    vtCO2_LE[purpose,energy19,t]$(d1CO2_LE[purpose,energy19,t])           "Value of CO2-duty, inventories"
    vtCO2_XE[purpose,energy19,t]$(d1CO2_XE[purpose,energy19,t])           "Value of CO2-duty, exports"

    vtCO2_ETS[r,t]$(d1CO2_ETS[r,t])                                       "Value of CO2-ETS paid by firms"
    vtCO2_ETS2[r,t]$(d1CO2_ETS2[r,t])                                     "Value of CO2-ETS2 paid by firms - as there are no allowances, this is also the marginal rate?"
    vtCO2_ETS2_marg[purpose,energy19,r,t]$(d1CO2_ETS2_marg[purpose,energy19,r,t]) "Value of CO2-ETS2 paid by firms"
    vtCO2_ETS_marg[energy19,r,t]$(d1tCO2_ETS_marg['in_ETS',energy19,r,t])  "Value of CO2-ETS paid by firms if there was zero free allowances on all ETS-use"
    vtCO2_ETSxE_marg[r,t]$(d1EmmProdxE[r,t,'CO2e'] and d1CO2_ETS[r,t])   "Tax revenue from ETS on non-energy emissions paid by firms, if there was zero free allowances on ETS-emissions "

    vtSO2_RE[purpose,energy19,r,t]$(d1SO2_RE[purpose,energy19,r,t])       "Value of SO2-duty, firms"
    vtSO2_CE[purpose,energy19,t]$(d1SO2_CE[purpose,energy19,t])           "Value of SO2-duty, consumers"
    vtSO2_LE[purpose,energy19,t]$(d1SO2_LE[purpose,energy19,t])           "Value of SO2-duty, inventories"
    vtSO2_XE[purpose,energy19,t]$(d1so2_XE[purpose,energy19,t])           "Value of SO2-duty, exports"

    vtPSO_RE[purpose,energy19,r,t]$(d1PSO_RE[purpose,energy19,r,t]) "Value of PSO-duty, firms"
    vtPSO_CE[purpose,energy19,t]$(d1PSO_CE[purpose,energy19,t]) "Value of PSO-duty, consumers"
    vtPSO_LE[purpose,energy19,t]$(d1PSO_LE[purpose,energy19,t]) "Value of PSO-duty, inventories"
    vtPSO_XE[purpose,energy19,t]$(d1PSO_XE[purpose,energy19,t]) "Value of PSO-duty, exports"


    vtNOx_RE[purpose,energy19,r,t]$(d1NOx_RE[purpose,energy19,r,t]) "Value of NOx-duty, firms"
    vtNOx_CE[purpose,energy19,t]$(d1NOx_CE[purpose,energy19,t]) "Value of NOx-duty, consumers"
    vtNOx_LE[purpose,energy19,t]$(d1NOx_LE[purpose,energy19,t]) "Value of NOx-duty, inventories"
    vtNOx_XE[purpose,energy19,t]$(d1NOx_XE[purpose,energy19,t]) "Value of NOx-duty, exports"

  
    vtVAT_RE[purpose,energy19,r,t]$(d1VAT_RE[purpose,energy19,r,t])       "Value of VAT on energy-goods, firms"
    vtVAT_CE[purpose,energy19,t]$(d1VAT_CE[purpose,energy19,t])           "Value of VAT on energy-goods, consumers"
    vtVAT_LE[purpose,energy19,t]$(d1VAT_LE[purpose,energy19,t])           "Value of VAT on energy-goods, inventories"
    vtVAT_XE[purpose,energy19,t]$(d1VAT_XE[purpose,energy19,t])           "Value of VAT on energy-goods, exports"

    vtEAFG_REmarg[purpose,energy19,r,t]$(d1EAFG_RE[purpose,energy19,r,t]) "Value of marginal energy-duty and water-duty, firms"
    vtCO2_REmarg[purpose,energy19,r,t]$(d1CO2_RE[purpose,energy19,r,t])   "Value of marginal CO2-duty, firms"    
    vBottomDeduction_EAFG[purpose,energy19,r,t] ""
    vBottomDeduction_CO2[purpose,energy19,r,t] ""
    vBottomDeduction_CO2_ETS[r,t] ""
    vtBotDed[s,t]                  "Sum of deductible emissions and energy-use in sector s"
    vtCalibENS[purpose,energy19,r,t]$(d1pREgj[purpose,energy19,r,t]) ""

;

    $GROUP G_taxes_quantities
    qEAFG_REgj_ded[purpose,energy19,r,t]$(d1EAFG_RE[purpose,energy19,r,t])  "Energy-duty and water-duty, firms"
    qCO2_REgj_ded[purpose,energy19,r,t]$(d1CO2_RE[purpose,energy19,r,t] and sameas[energy19,'district heat'] and sum(emm_eq, d1CO2_REmarg[purpose,energy19,r,t,emm_eq])) "CO2-duty, firms"
    qEmmProdE_ded[r,t,emm_eq,purpose,energy19]$(not sameas[energy19,'district heat'] and t1[t] and d1EmmProdE[r,t,emm_eq,purpose,energy19])  "CO2-tax deductible emissions"   

    #  qEmmProdE_ded[r,t,emm_eq,purpose,energy19]$(tx1[t] and d1CO2_RE[purpose,energy19,r,t] and d1CO2_REmarg[purpose,energy19,r,t,emm_eq] and d1EmmProdE[r,t,emm_eq,purpose,energy19] and not sameas[energy19,'district heat'])  "CO2-tax deductible emissions"
    qEmmProdE_dedETS[r,t]$(d1CO2_ETS[r,t])                                  "CO2-ETS free allowances"
;

$GROUP G_energy_taxes_rates 
    tEAFG_CE[purpose,energy19,t]$(d1EAFG_CE[purpose,energy19,t])            "Energy-duty and water-duty, consumers"
    tEAFG_LE[purpose,energy19,t]$(d1EAFG_Le[purpose,energy19,t])            "Energy-duty and water-duty, inventories"
    tEAFG_XE[purpose,energy19,t]$(d1EAFG_XE[purpose,energy19,t])            "Energy-duty and water-duty, exports"

    tCO2_ProdxE[s,t,emm]$(d1CO2_ProdxE[s,t,emm])                            "CO2-duty on non-energy related emissions, firms"
    tCO2_CE[purpose,energy19,t]$(d1CO2_CE[purpose,energy19,t])              "CO2-duty, consumers"
    tCO2_LE[purpose,energy19,t]$(d1CO2_LE[purpose,energy19,t])              "CO2-duty, inventories"
    tCO2_XE[purpose,energy19,t]$(d1CO2_XE[purpose,energy19,t])              "CO2-duty, exports"

    tCO2_ETS[t]                                                             "CO2, ETS-price on emissions"
    tCO2_ETS_avg[r,t]$(d1CO2_ETS[r,t])                                      "CO2, Average ETS-price on emissions"
    tCO2_ETS2[t]                                                            "CO2, ETS2-prices on emissions"

    tSO2_RE[purpose,energy19,r,t]$(d1SO2_RE[purpose,energy19,r,t])          "SO2-duty, firms"
    tSO2_CE[purpose,energy19,t]$(d1SO2_CE[purpose,energy19,t])              "SO2-duty, consumers"
    tSO2_LE[purpose,energy19,t]$(d1SO2_LE[purpose,energy19,t])              "SO2-duty, inventories"
    tSO2_XE[purpose,energy19,t]$(d1so2_XE[purpose,energy19,t])              "SO2-duty, exports"

    tPSO_RE[purpose,energy19,r,t]$(d1PSO_RE[purpose,energy19,r,t]) "PSO-duty, firms"
    tPSO_CE[purpose,energy19,t]$(d1PSO_CE[purpose,energy19,t]) "PSO-duty, consumers"
    tPSO_XE[purpose,energy19,t]$(d1PSO_XE[purpose,energy19,t]) "PSO-duty, exports"

    tNOx_RE[purpose,energy19,r,t]$(d1NOx_RE[purpose,energy19,r,t]) "NOx-duty, firms"
    tNOx_CE[purpose,energy19,t]$(d1NOx_CE[purpose,energy19,t]) "NOx-duty, consumers"

    tVAT_RE[purpose,energy19,r,t]$(d1VAT_RE[purpose,energy19,r,t])          "VAT on energy-goods, firms"
    tVAT_CE[purpose,energy19,t]$(d1VAT_CE[purpose,energy19,t])              "VAT on energy-goods, consumers"
    tVAT_LE[purpose,energy19,t]$(d1VAT_LE[purpose,energy19,t])              "VAT on energy-goods, inventories"
    tVAT_XE[purpose,energy19,t]$(d1VAT_XE[purpose,energy19,t])              "VAT on energy-goods, exports"

    tEAFG_REmarg[purpose,energy19,r,t]$(d1tRE[purpose,energy19,r,t])        "Marginal energy tax, firms, kr. per GJ"
    tSO2_REmarg[purpose,energy19,r,t]$(d1tRE[purpose,energy19,r,t])         "Marginal SO2 tax, firms, kr. per kg. SO2"    
    tCO2_REmarg[purpose,energy19,r,t,emm_eq]$(d1tRE[purpose,energy19,r,t])  "Marginal CO2 tax, firms, kr. per ton CO2"   

    tCO2_REmarg_GJ[purpose,energy19,r,t,emm_eq]$(d1CO2_REmarg[purpose,energy19,r,t,emm_eq]) "Marginal CO2 tax, firms, bio. kroner per PJ (or equivalently 1000 kroner per GJ)"
    tCO2_ETS_GJ[purpose,energy19,r,t]$(d1tCO2_ETS_marg[purpose,energy19,r,t])               "Marginal ETS-price, firms, bio. kroner per PJ (or equivalently 1000 kroner per GJ)"
    tCO2_ETS2_GJ[purpose,energy19,r,t]$(d1CO2_ETS2_marg[purpose,energy19,r,t])             "Marginal ETS-price, firms, bio. kroner per PJ (or equivalently 1000 kroner per GJ)"

    tCALIBENS[purpose,energy19,r,t]$(d1pREgj[purpose,energy19,r,t]) ""

;

$GROUP G_PSO_taxes_to_zero
    tPSO_RE[purpose,energy19,r,t] 
    tPSO_CE[purpose,energy19,t] 
    tPSO_XE[purpose,energy19,t] 
    vtPSO_RE  
    vtPSO_CE  
    vtPSO_XE 
;

$GROUP G_energy_taxes_rates_endo
    tvRE[purpose,energy19,r,t]$(d1tRE[purpose,energy19,r,t] and (d1pRE_base[purpose,energy19,r,t] or d1pREown[purpose,energy19,r,t])) "Tax-rate on energy-goods to firms, energy-goods traded on markets (Unit = tax-rates share of base-price)"
    tqRE[purpose,energy19,r,t]$(d1tRE[purpose,energy19,r,t] and not (d1pRE_base[purpose,energy19,r,t]  or d1pREown[purpose,energy19,r,t])) "Tax-rate on energy-goods to firms, energy-goods not traded on markets (Unit = Bio. DKK per PJ)"
    tCE[purpose,energy19,t]$(d1tCE[purpose,energy19,t])                                               "Tax-rate on energy-goods to consumers"
    tLE[purpose,energy19,t]$(d1tLE[purpose,energy19,t])                                               "Tax-rate on energy-goods on inventories"
    tXE_[purpose,energy19,t]$(d1tXE[purpose,energy19,t])                                              "Tax-rate on energy-goods to exports"

    tvREmarg[purpose,energy19,r,t]$(d1tRE[purpose,energy19,r,t] and (d1pRE_base[purpose,energy19,r,t] or d1pREown[purpose,energy19,r,t]))      "Marginal tax-rate on energy-goods to firms, "
    tqREmarg[purpose,energy19,r,t]$(d1tRE[purpose,energy19,r,t] and not (d1pRE_base[purpose,energy19,r,t] or d1pREown[purpose,energy19,r,t]))  "Marginal tax-rate on energy-goods to firms"
    tCO2_ETS_avg$(d1CO2_ETS[r,t])

    #Consider having exogenous
    tCO2_REmarg_GJ[purpose,energy19,r,t,emm_eq]$(d1CO2_REmarg[purpose,energy19,r,t,emm_eq]) "Marginal CO2 tax, firms, bio. kroner per PJ (or equivalently 1000 kroner per GJ)"
    tCO2_ETS_GJ[purpose,energy19,r,t]$(d1tCO2_ETS_marg[purpose,energy19,r,t])               "Marginal ETS-price, firms, bio. kroner per PJ (or equivalently 1000 kroner per GJ)"
    tCO2_ETS2_GJ[purpose,energy19,r,t]$(d1CO2_ETS2_marg[purpose,energy19,r,t])              "Marginal ETS-price, firms, bio. kroner per PJ (or equivalently 1000 kroner per GJ)"
;


  $GROUP G_taxes_parameters                "Parameters (defined as exogenous values) to recaculate some input data"
    tEAFG_REmarg_SKM(tREbase_SKM,t)   "Marginal energy taxes defined across the ministry's categories - measured in DKK per KJ"
    tSO2_REmarg_SKM(tREbase_SKM,t)    "Marginal energy taxes defined across the ministry's categories - measured in DKK per kg SO2"
    tCO2_REmarg_SKM(tREbase_SKM,t)    "Marginal energy taxes defined across the ministry's categories - measured in DKK per ton CO2"
;  

$ENDIF 



$IF %stage% == "groupcompilation":

  $GROUP G_taxes_energy_endo 
    G_energy_taxes_values, -vtCalibENS, -vBottomDeduction_CO2, -vBottomDeduction_CO2_ETS, -vBottomDeduction_EAFG
    G_energy_taxes_rates_endo, -tCO2_ETS_avg             
    qEmmProdE_ded$(tx1[t] and d1CO2_REmarg[purpose,energy19,r,t,emm_eq] and d1EmmProdE[r,t,emm_eq,purpose,energy19] and not sameas[energy19,'district heat'])
  ;

 $GROUP G_taxes_energy_endo G_taxes_energy_endo$(tx0[t]); # Restrict endo group to tx0[t]

  $GROUP G_taxes_energy_exo
    G_taxes_quantities
    G_energy_taxes_rates 
    -tSO2_REmarg, -tCALIBENS, -tCO2_ETS2, -tCO2_ETS_GJ, -tCO2_ETS_avg, -tCO2_REmarg, -tCO2_REmarg_GJ, -tEAFG_REmarg
    tCALIBENS$(d1pREgj[purpose,energy19,r,t] and d1tRE[purpose,energy19,r,t]) 
    tCO2_ETS2$(sum(purpose,(sum(energy19,d1CO2_CE_ETS2[purpose,energy19,t]))))
    tCO2_REmarg$(d1CO2_RE[purpose,energy19,r,t] and d1CO2_REmarg[purpose,energy19,r,t,emm_eq] )
    tEAFG_REmarg$(d1EAFG_RE[purpose,energy19,r,t])

    qCE$(d1EAFG_CE[purpose,energy19,t] or d1SO2_CE[purpose,energy19,t] or d1CO2_CE[purpose,energy19,t] or d1VAT_CE[purpose,energy19,t] or d1tCE[purpose,energy19,t])
    qLE$(d1qLE[purpose,energy19,t] and (d1EAFG_LE[purpose,energy19,t] or d1SO2_LE[purpose,energy19,t] or d1CO2_LE[purpose,energy19,t] or d1VAT_LE[purpose,energy19,t] or d1tLE[purpose,energy19,t]))
    qXE$(d1EAFG_XE[purpose,energy19,t] or d1SO2_XE[purpose,energy19,t] or d1CO2_XE[purpose,energy19,t] or d1VAT_XE[purpose,energy19,t] or d1tXE[purpose,energy19,t])


    pCE_base$((d1vCE[purpose,energy19,t] and d1tCE[purpose,energy19,t]) or d1VAT_CE[purpose,energy19,t])
    pRE_base_marg$(d1pRE_base[purpose,energy19,r,t] and (d1VAT_RE[purpose,energy19,r,t] or d1tRE[purpose,energy19,r,t])) 

    pLE_base$(d1VAT_LE[purpose,energy19,t] or (d1vLE[purpose,energy19,t] and d1tLE[purpose,energy19,t]))
    pXE_base$(d1VAT_XE[purpose,energy19,t] or (d1vXE[purpose,energy19,t] and d1tXE[purpose,energy19,t]))
  
  #E_tCO2_REmarg_GJ, E_tCO2_ETS_GJ, E_tCO2_ETS2_GJ
    uEmmProdE$(sum(purpose,d1CO2_REmarg[purpose,energy19,s,t,emm]) and not sameas[energy19,'district heat'] and (sameas[emm,'CO2ubio'] or (sameas[energy19,'natural gas incl. biongas'] and sameas[emm,'CO2bio'])))
    uEmmProdE$(sum(purpose,d1tCO2_ETS_marg[purpose,energy19,s,t]) and (sameas[emm,'CO2ubio'] or (sameas[energy19,'natural gas incl. biongas'] and sameas[emm,'CO2bio'])))
    uEOPProdE$(d1CO2_REmarg[purpose,energy19,s,t,emm] and not sameas[energy19,'district heat'] and (sameas[emm,'CO2ubio'] or (sameas[energy19,'natural gas incl. biongas'] and sameas[emm,'CO2bio'])))
    uEOPProdE$(d1tCO2_ETS_marg[purpose,energy19,s,t] and (sameas[emm,'CO2ubio'] or (sameas[energy19,'natural gas incl. biongas'] and sameas[emm,'CO2bio'])))
    sBioNatgas$(d1CO2_ETS2_marg[purpose,'natural gas incl. biongas',r,t] or d1tCO2_ETS_marg[purpose,'natural gas incl. biongas',r,t] or d1CO2_REmarg[purpose,'natural gas incl. biongas',r,t,'CO2ubio']  or d1CO2_REmarg[purpose,'natural gas incl. biongas',r,t,'CO2bio'])
    
    #E_vtCO2_CE_ETS2
    qEmmConsE$(d1EmMConsE[t,emm_eq,purpose,energy19]  and ((d1CO2_CE[purpose,energy19,t] and not sameas[energy19,'District heat']) or d1CO2_CE_ETS2[purpose,energy19,t]) and (sameas[emm_eq,'CO2ubio'] or (sameas[emm_eq,'CO2bio'] and sameas[energy19,'Natural gas incl. biongas'])))

    #E_tREmarg_market_own, E_tRE_own
    pREown$(d1pREown[purpose,energy19,r,t] and d1tRE[purpose,energy19,r,t])

    qREgj$(d1EAFG_RE[purpose,energy19,r,t]) # E_vtEAFG_RE
    qREgj$(d1PSO_RE[purpose,energy19,r,t]) # E_vtPSO_RE
    qREgj$(d1NOx_RE[purpose,energy19,r,t]) # E_vtNOx_RE
    qREgj$(d1SO2_RE[purpose,energy19,r,t]) # E_vtSO2_RE
    qREgj$(d1CO2_RE[purpose,energy19,r,t] and sameas[energy19,'district heat'] and sum(emm_eq,d1CO2_REmarg[purpose,energy19,r,t,emm_eq])) # E_vtCO2_RE_district_heat and E_vtCO2_REmarg_district_heat
    qREgj$(d1pRE_base[purpose,energy19,r,t] and d1VAT_RE[purpose,energy19,r,t]) # E_vtVAT_RE
    qREgj$(d1tRE[purpose,energy19,r,t]) # E_tREmarg_market and E_tREmarg_nonmarket

    qEmmProdE$(d1CO2_RE[purpose,energy19,s,t] and not sameas[energy19,'district heat'] and d1CO2_REmarg[purpose,energy19,s,t,emm_eq] and d1EmmProdE[s,t,emm_eq,purpose,energy19]) # E_vtCO2_RE E_vtCO2_REmarg
    qEmmProdE$(d1tCO2_ETS_marg[purpose,energy19,s,t] and d1EmmProdE[s,t,emm_eq,purpose,energy19] and sameas[purpose,'in_ETS'] and (sameas[emm_eq,'CO2ubio'] or (sameas[emm_eq,'CO2bio'] and sameas[energy19,'Natural gas incl. biongas'])))
    qEmmProdE$(tx1[t] and d1CO2_REmarg[purpose,energy19,s,t,emm_eq] and d1EmmProdE[s,t,emm_eq,purpose,energy19] and not sameas[energy19,'district heat'] and not d1qREgj_KFnew[purpose,energy19,s,t] and not d1qREgj_ABnew[purpose,energy19,s,t]) # E_qEmmProdE_ded
    qEmmProdE$(t1[t] and sum(tt,d1CO2_REmarg[purpose,energy19,s,tt,emm_eq]) and sum(tt,d1EmmProdE[s,tt,emm_eq,purpose,energy19]) and not sameas[energy19,'district heat']) # E_qEmmProdE_ded

    -qEmmProdE_ded[r,t,emm_eq,purpose,energy19]$(not sameas[energy19,'district heat'] and t1[t] and d1EmmProdE[r,t,emm_eq,purpose,energy19])
    qEmmProdE_ded$(t1[t] and sum(tt,d1CO2_REmarg[purpose,energy19,r,tt,emm_eq]) and sum(tt,d1EmmProdE[r,tt,emm_eq,purpose,energy19]) and not sameas[energy19,'district heat']) # E_qEmmProdE_ded

    qEmmProdxE$(tx0[t] and d1EmmProdxE[s,t,emm_eq] and d1CO2_ProdxE[s,t,emm_eq] and sameas[emm_eq,'CO2ubio']) # E_vtCO2_ProdxE
    qEmmProdxE$(d1EmmProdxE[s,t,emm_eq] and d1CO2_ETS[s,t] and sameas[emm_eq,'CO2e'])   # E_vtCO2_ProdxE

    vEAV_RE$(d1EAV_RE[purpose,energy19,r,t] and (d1VAT_RE[purpose,energy19,r,t] or d1tRE[purpose,energy19,r,t]))
    vEAV_CE$(d1EAV_CE[purpose,energy19,t])
    vDAV_RE$(d1DAV_RE[purpose,energy19,r,t])
    vDAV_CE$(d1DAV_CE[purpose,energy19,t])
    vCAV_RE$(d1CAV_RE[purpose,energy19,r,t])
    vCAV_CE$(d1CAV_CE[purpose,energy19,t])

    pEAV_RE$(d1EAV_RE[purpose,energy19,r,t]  and d1tRE[purpose,energy19,r,t])
    pDAV_RE$(d1DAV_RE[purpose,energy19,r,t])
    pCAV_RE$(d1CAV_RE[purpose,energy19,r,t])

    jtEAFG_RE$(d1EAFG_RE[purpose,energy19,r,t]) # E_vBottomDeduction E_vtEAFG_RE
    jtCO2_RE$(d1CO2_RE[purpose,energy19,r,t] ) # E_vtCO2_RE_district_heat E_vtCO2_RE E_vBottomDeduction
    jEmmProdE_dedETS$(d1CO2_ETS[r,t]) # E_vtCO2_ETS E_vBottomDeduction

  ; 

 $GROUP G_taxes_energy_exo G_taxes_energy_exo$(tx0[t]); # Restrict exo group to tx0[t]


  $GROUP G_non_flat_from_energy_taxes   
    tEAFG_REmarg
    tEAFG_CE
    tCO2_REmarg
    tCO2_CE
    tCO2_REmarg_SKM 
    tEAFG_REmarg_SKM  
    tSO2_REmarg
    tSO2_REmarg_SKM

    tCO2_ETS
    tCO2_ETS2
    tCO2_ProdxE
    qEmmProdE_dedETS
    tCO2_REmarg_GJ
    #  tCO2_ETS_GJ
    tCO2_ETS2_GJ
  ;

  $PGROUP PGROUP_taxes_NonFlat_Dummies
    d1CO2_ProdxE
    d1CO2_RE #$(notthese[purpose,energy19,r,tForecast]) 
    d1CO2_REmarg #$(notthese[purpose,energy19,r,tForecast]) 
    d1CO2_REmarg_sumemm #$(notthese[purpose,energy19,r,tForecast])
    d1CO2_ETS2 
    d1CO2_ETS2_marg
    d1CO2_CE_ETS2
    #  d1tRE
  ;

$ENDIF


# ========================================================================================================================
# Equations
# ========================================================================================================================
$IF %stage% == "equations":

  $BLOCK B_taxes_energy

    # Energy-duties calculated on quantities

    #Energy-taxes on firms
        E_vtEAFG_RE[purpose,energy19,r,t]$(tx0[t] and d1EAFG_RE[purpose,energy19,r,t])..      vtEAFG_RE[purpose,energy19,r,t] =E= tEAFG_REmarg[purpose,energy19,r,t]*10**(-3) 
                                                                                                                                * (qREgj[purpose,energy19,r,t] - qEAFG_REgj_ded[purpose,energy19,r,t]) 
                                                                                                                                + jtEAFG_RE[purpose,energy19,r,t];
        
        E_vtEAFG_REmarg[purpose,energy19,r,t]$(tx0[t] and d1EAFG_RE[purpose,energy19,r,t])..               vtEAFG_REmarg[purpose,energy19,r,t] =E= tEAFG_REmarg[purpose,energy19,r,t] * qREgj[purpose,energy19,r,t]  *10**(-3);  # mia DKK = DKK per GJ * number of PJ / 1000


    E_vtEAFG_CE[purpose,energy19,t]$(tx0[t] and d1EAFG_CE[purpose,energy19,t])..          vtEAFG_CE[purpose,energy19,t]   =E= tEAFG_CE[purpose,energy19,t] *10**(-3) * qCE[purpose,energy19,t];

    E_vtEAFG_LE[purpose,energy19,t]$(tx0[t] and d1EAFG_LE[purpose,energy19,t])..          vtEAFG_LE[purpose,energy19,t]   =E= tEAFG_LE[purpose,energy19,t] * qLE[purpose,energy19,t];
    E_vtEAFG_XE[purpose,energy19,t]$(tx0[t] and d1EAFG_XE[purpose,energy19,t])..          vtEAFG_XE[purpose,energy19,t]   =E= tEAFG_XE[purpose,energy19,t] * qXE[purpose,energy19,t];

    E_vtPSO_RE[purpose,energy19,r,t]$(tx0[t] and d1PSO_RE[purpose,energy19,r,t])..        vtPSO_RE[purpose,energy19,r,t]  =E= tPSO_RE[purpose,energy19,r,t] * qREgj[purpose,energy19,r,t];
    E_vtPSO_CE[purpose,energy19,t]$(tx0[t] and d1PSO_CE[purpose,energy19,t])..            vtPSO_CE[purpose,energy19,t]    =E= tPSO_CE[purpose,energy19,t] * qCE[purpose,energy19,t];
    E_vtPSO_XE[purpose,energy19,t]$(tx0[t] and d1PSO_XE[purpose,energy19,t])..            vtPSO_XE[purpose,energy19,t]    =E= tPSO_XE[purpose,energy19,t] * qXE[purpose,energy19,t];

    E_vtNOx_RE[purpose,energy19,r,t]$(tx0[t] and d1NOx_RE[purpose,energy19,r,t])..        vtNOx_RE[purpose,energy19,r,t]  =E= tNOx_RE[purpose,energy19,r,t] * qREgj[purpose,energy19,r,t];
    E_vtNOx_CE[purpose,energy19,t]$(tx0[t] and d1NOx_CE[purpose,energy19,t])..            vtNOx_CE[purpose,energy19,t]    =E= tNOx_CE[purpose,energy19,t] * qCE[purpose,energy19,t];

    E_vtSO2_RE[purpose,energy19,r,t]$(tx0[t] and d1SO2_RE[purpose,energy19,r,t])..        vtSO2_RE[purpose,energy19,r,t] =E= tSO2_RE[purpose,energy19,r,t] * qREgj[purpose,energy19,r,t];
    E_vtSO2_CE[purpose,energy19,t]$(tx0[t] and d1SO2_CE[purpose,energy19,t])..            vtSO2_CE[purpose,energy19,t]   =E= tSO2_CE[purpose,energy19,t] * qCE[purpose,energy19,t];
    E_vtSO2_LE[purpose,energy19,t]$(tx0[t] and d1SO2_LE[purpose,energy19,t])..            vtSO2_LE[purpose,energy19,t]   =E= tSO2_LE[purpose,energy19,t] * qLE[purpose,energy19,t];
    E_vtSO2_XE[purpose,energy19,t]$(tx0[t] and d1SO2_XE[purpose,energy19,t])..            vtSO2_XE[purpose,energy19,t]   =E= tSO2_XE[purpose,energy19,t] * qXE[purpose,energy19,t];
    
    #CO2-tax on firms
        E_vtCO2_RE_district_heat[purpose,energy19,r,t]$(tx0[t] and d1CO2_RE[purpose,energy19,r,t] and sameas[energy19,'district heat'])..      
          vtCO2_RE[purpose,energy19,r,t] =E= sum(emm_eq$(d1CO2_REmarg[purpose,energy19,r,t,emm_eq]), tCO2_REmarg[purpose,energy19,r,t,emm_eq] * (qREgj[purpose,energy19,r,t] - qCO2_REgj_ded[purpose,energy19,r,t]))+ jtCO2_RE[purpose,energy19,r,t];
        
        E_vtCO2_RE[purpose,energy19,r,t]$(tx0[t] and d1CO2_RE[purpose,energy19,r,t] and not sameas[energy19,'district heat'])..      
          vtCO2_RE[purpose,energy19,r,t] =E= sum(emm_eq$(d1CO2_REmarg[purpose,energy19,r,t,emm_eq] and d1EmmProdE[r,t,emm_eq,purpose, energy19]), 
                        tCO2_REmarg[purpose,energy19,r,t,emm_eq]/10**6 * growth_factor[t] * (qEmmProdE[r,t,emm_eq,purpose,energy19] - qEmmProdE_ded[r,t,emm_eq,purpose,energy19])) + jtCO2_RE[purpose,energy19,r,t];


        E_vtCO2_REmarg[purpose,energy19,r,t]$(tx0[t] and d1CO2_RE[purpose,energy19,r,t] and not sameas[energy19,'District heat'])..      
            vtCO2_REmarg[purpose,energy19,r,t] =E= sum(emm_eq$(d1CO2_REmarg[purpose,energy19,r,t,emm_eq]), tCO2_REmarg[purpose,energy19,r,t,emm_eq]/10**6 * growth_factor[t]*qEmmProdE[r,t,emm_eq,purpose,energy19]$(d1EmmProdE[r,t,emm_eq,purpose, energy19])); 
            # mia. DKK = DKK per ton CO2 * number of PJ * number of kg. CO2 per GJ*10**(-6)  

        # District heat doesn't have any direct emissions. Tax is levied on energy-use. Tax-rate is taken from DST-data
        E_vtCO2_REmarg_district_heat[purpose,energy19,r,t]$(tx0[t] and d1CO2_RE[purpose,energy19,r,t] and sameas[energy19,'District heat'])..      
           vtCO2_REmarg[purpose,energy19,r,t] =E= sum(emm_eq$(d1CO2_REmarg[purpose,energy19,r,t,emm_eq]), tCO2_REmarg[purpose,energy19,r,t,emm_eq]) * qREgj[purpose,energy19,r,t];    #     number of 1000 tons per PJ 

        E_tCO2_REmarg_GJ[purpose,energy19,r,t,emm_eq]$(tx0[t] and d1CO2_REmarg[purpose,energy19,r,t,emm_eq] and not sameas[energy19,'district heat'] and (sameas[emm_eq,'CO2ubio'] or sameas[emm_eq,'CO2bio']))..
          tCO2_REmarg_GJ[purpose,energy19,r,t,emm_eq] =E= tCO2_REmarg[purpose,energy19,r,t,emm_eq] /10**6 * ( (           uEmmProdE[r,t,'CO2ubio',energy19] * uEOPProdE[purpose,energy19,r,t,'CO2ubio'])$(not sameas[energy19,'natural gas incl. biongas'] and sameas[emm_eq,'CO2ubio'])
                                                                                       + (   sBionatgas[purpose,r,t]    * uEmmProdE[r,t,'CO2bio',energy19]  * uEOPProdE[purpose,energy19,r,t,'CO2bio'])$(sameas[energy19,'natural gas incl. biongas'] and sameas[emm_eq,'CO2bio'])
                                                                                       + ((1-sBionatgas[purpose,r,t])   * uEmmProdE[r,t,'CO2ubio',energy19] * uEOPProdE[purpose,energy19,r,t,'CO2ubio'])$(sameas[energy19,'natural gas incl. biongas'] and sameas[emm_eq,'CO2ubio'])
                                                                                       #Consider removing bionatgas distinction as uEmm in forecast years are set to the same for ubio/bio
                                                                                       )
                                                                                        ;

        E_tCO2_REmarg_GJ_districtheat[purpose,energy19,r,t]$(tx0[t] and d1CO2_REmarg[purpose,energy19,r,t,'CO2ubio'] and sameas[energy19,'district heat'])..
            tCO2_REmarg_GJ[purpose,energy19,r,t,'CO2ubio'] =E= tCO2_REmarg[purpose,energy19,r,t,'CO2ubio'];

        # Tax revenue from CO2-tax on non-energy related emissions
        #Deductions
            E_qEmmProdE_ded[r,t,emm_eq,purpose,energy19]$(tx1[t] and d1CO2_REmarg[purpose,energy19,r,t,emm_eq] 
                                                                 and d1EmmProdE[r,t,emm_eq,purpose,energy19] 
                                                                 and not sameas[energy19,'district heat'] 
                                                                 and not d1qREgj_KFnew[purpose,energy19,r,t]
                                                                 and not d1qREgj_ABnew[purpose,energy19,r,t])..
             qEmmProdE_ded[r,t,emm_eq,purpose,energy19]/qEmmProdE[r,t,emm_eq,purpose,energy19] =E=  (qEmmProdE_ded[r,t1,emm_eq,purpose,energy19]/qEmmProdE[r,t1,emm_eq,purpose,energy19])$(d1BotdedCO2post25=1)                 #Old policy-regime gives deductions on CO2-tax.
                                                                                                  + (qEmmProdE_ded[r,t1,emm_eq,purpose,energy19]/qEmmProdE[r,t1,emm_eq,purpose,energy19])$(d1BotdedCO2post25=0 and t.val<2025)  #2022-reform phases out bottom deductions after 2025.
                                                                                                  + 0$(d1BotdedCO2post25=0 and t.val>=2025)                                                                                     #2022-reform phases out bottom deductions after 2025
                                                                                                  ;


           # Any "new energy" that enters the model through calibration to KF-data is assumed not to carry any tax-deductions (in lack of better assumption)
            E_qEmmProdE_ded_new[r,t,emm_eq,purpose,energy19]$(tx1[t] and d1CO2_REmarg[purpose,energy19,r,t,emm_eq] and d1EmmProdE[r,t,emm_eq,purpose,energy19] and not sameas[energy19,'district heat'] and (d1qREgj_KFnew[purpose,energy19,r,t] or d1qREgj_ABnew[purpose,energy19,r,t]))..
              qEmmProdE_ded[r,t,emm_eq,purpose,energy19] =E= 0$(not (sameas[emm_eq,'CO2bio'] and sameas[energy19,'Natural gas incl. biongas']))
                                                                # The exception is for bio-natural gas in which case we assume full deduction
                                                            #  + qEmmProdE[r,t,emm_eq,purpose,energy19]$(sameas[emm_eq,'CO2bio'] and sameas[energy19,'Natural gas incl. biongas'])
                                                                # Uden oprindelsesgarantier
                                                            + 0$(sameas[emm_eq,'CO2bio'] and sameas[energy19,'Natural gas incl. biongas'])
                                                            ;

        E_vtCO2_ProdxE[s,t,emm]$(tx0[t] and d1EmmProdxE[s,t,emm] and d1CO2_ProdxE[s,t,emm] and sameas[emm,'CO2ubio'])..
          vtCO2_ProdxE[s,t,emm] =E= qEmmProdxE[s,t,emm]*growth_factor[t] * tCO2_ProdxE[s,t,emm]*10**(3)*10**(-9);

        E_vtCO2_ProdxE_Fgasser[s,t,emm]$(tx0[t] and d1EmmProdxE[s,t,emm] and d1CO2_ProdxE[s,t,emm] and (sameas[emm,'HFC'] or sameas[emm,'PFC'] or sameas[emm,'SF6']))..
          vtCO2_ProdxE[s,t,emm] =E= qEmmProdxE[s,t,emm]*growth_factor[t] * tCO2_ProdxE[s,t,emm]*GWP[emm] * 10**(3)*10**(-9);


    #CO2-tax on private consumers 
        E_vtCO2_CE[purpose,energy19,t]$(tx0[t] and d1CO2_CE[purpose,energy19,t] and not sameas[energy19,'District heat'])..
                    vtCO2_CE[purpose,energy19,t]   =E= tCO2_CE[purpose,energy19,t]/10**6 * growth_factor[t] * (qEmmConsE[t,'CO2ubio',purpose,energy19]$(d1EmmConsE[t,'CO2ubio',purpose,energy19])
                                                                                                            +  qEmmConsE[t,'CO2bio',purpose,energy19]$(d1EmmConsE[t,'CO2ubio',purpose,energy19] and sameas[energy19,'Natural gas incl. biongas']));
        
        E_vtCO2_CE_district_heat[purpose,energy19,t]$(tx0[t] and d1CO2_CE[purpose,energy19,t] and sameas[energy19,'District heat']).. vtCO2_CE[purpose,energy19,t]   =E= tCO2_CE[purpose,energy19,t] * qCE[purpose,energy19,t];

    #Other CO2-taxes
        E_vtCO2_LE[purpose,energy19,t]$(tx0[t] and d1CO2_LE[purpose,energy19,t])..          vtCO2_LE[purpose,energy19,t]   =E= tCO2_LE[purpose,energy19,t] * qLE[purpose,energy19,t];
        E_vtCO2_XE[purpose,energy19,t]$(tx0[t] and d1CO2_XE[purpose,energy19,t])..          vtCO2_XE[purpose,energy19,t]   =E= tCO2_XE[purpose,energy19,t] * qXE[purpose,energy19,t];

                   

    # ETS1
      E_vtCO2_ETS[r,t]$(tx0[t] and d1CO2_ETS[r,t])..
              # Total quota payments are given by:
                                  # Quota payments on energy-related emissions
              vtCO2_ETS[r,t] =E= sum(energy19$(d1tCO2_ETS_marg['in_ETS',energy19,r,t]) , 
                                              vtCO2_ETS_marg[energy19,r,t])
                                  # Plus quota payments on process emissions 
                                           +  vtCO2_ETSxE_marg[r,t]$(d1EmmProdxE[r,t,'CO2e'] and  d1CO2_ETS[r,t])
                                  # Minus the value of allocated free allowances (the J-term ensures that we meet the total quota payments in data years) 
                                           - tCO2_ETS[t]/10**6 *growth_factor[t] * (qEmmProdE_dedETS[r,t] + jEmmProdE_dedETS[r,t]);

      # We decompose CO2-ETS on per PJ base
      E_vtCO2_ETS_marg[energy19,r,t]$(tx0[t] and d1tCO2_ETS_marg['in_ETS',energy19,r,t]).. 
          vtCO2_ETS_marg[energy19,r,t] =E= tCO2_ETS[t]/10**6 *growth_factor[t] * (qEmmProdE[r,t,'CO2ubio','in_ETS',energy19]$(d1EmmProdE[r,t,'CO2ubio','in_ETS',energy19]) 
                                                                                + qEmmProdE[r,t,'CO2bio','in_ETS',energy19]$(d1EmmProdE[r,t,'CO2bio','in_ETS',energy19] and sameas[energy19,'Natural gas incl. biongas'])
                                                                                 );

      E_vtCO2_ETSxE_marg[r,t]$(tx0[t] and d1EmmProdxE[r,t,'CO2e'] and  d1CO2_ETS[r,t])..
          vtCO2_ETSxE_marg[r,t] =E= tCO2_ETS[t]/10**6 *growth_factor[t] * qEmmProdxE[r,t,'CO2e']$(d1EmmProdxE[r,t,'CO2e'] and d1CO2_ETS[r,t]);

      #  E_tCO2_ETS_avg[r,t]$(tx0[t] and d1CO2_ETS[r,t])..
      #      tCO2_ETS_avg[r,t] /10**6 *growth_factor[t] * qEmmCO2ETS[r,t] =E= vtCO2_ETS[r,t];

      E_tCO2_ETS_GJ[purpose,energy19,r,t]$(tx0[t] and d1tCO2_ETS_marg[purpose,energy19,r,t])..
            tCO2_ETS_GJ[purpose,energy19,r,t] =E= tCO2_ETS[t]/10**6 * ( (                                 uEmmProdE[r,t,'CO2ubio',energy19]   * uEOPProdE[purpose,energy19,r,t,'CO2ubio'])$(not sameas[energy19,'natural gas incl. biongas'])
                                                                        + (   sBionatgas[purpose,r,t]  * uEmmProdE[r,t,'CO2bio',energy19]     * uEOPProdE[purpose,energy19,r,t,'CO2bio'])$(sameas[energy19,'natural gas incl. biongas'])
                                                                        + ((1-sBionatgas[purpose,r,t])* uEmmProdE[r,t,'CO2ubio',energy19]     * uEOPProdE[purpose,energy19,r,t,'CO2ubio'])$(sameas[energy19,'natural gas incl. biongas'])
                                                                        #Consider removing bionatgas distinction as uEmm in forecast years are set to the same for ubio/bio
                                                                        )
                                                                        ;


    
    # ETS2 - no deductions are granted to our knowledge and marginal/avg ETS2 are the same 
      E_vtCO2_ETS2_marg[purpose,energy19,r,t]$(tx0[t] and d1CO2_ETS2_marg[purpose,energy19,r,t])..
        vtCO2_ETS2_marg[purpose,energy19,r,t] =E= tCO2_ETS2[t]/10**6 *growth_factor[t] *  (qEmmProdE[r,t,'CO2ubio',purpose,energy19]$(d1EmmProdE[r,t,'CO2ubio',purpose,energy19])
                                                                                          +qEmmProdE[r,t,'CO2bio',purpose,energy19]$(d1EmmProdE[r,t,'CO2bio',purpose,energy19] and sameas[energy19,'Natural gas incl. biongas']));
      
      E_vtCO2_ETS2[r,t]$(tx0[t] and d1CO2_ETS2[r,t])..
        vtCO2_ETS2[r,t] =E= sum((purpose,energy19)$(d1CO2_ETS2_marg[purpose,energy19,r,t]), vtCO2_ETS2_marg[purpose,energy19,r,t]);

      E_tCO2_ETS2_GJ[purpose,energy19,r,t]$(tx0[t] and d1CO2_ETS2_marg[purpose,energy19,r,t])..
        tCO2_ETS2_GJ[purpose,energy19,r,t] =E= tCO2_ETS2[t]/10**6 *                    ( (                                 uEmmProdE[r,t,'CO2ubio',energy19]   * uEOPProdE[purpose,energy19,r,t,'CO2ubio'])$(not sameas[energy19,'natural gas incl. biongas'])
                                                                                       + (   sBionatgas[purpose,r,t]     * uEmmProdE[r,t,'CO2bio',energy19]    * uEOPProdE[purpose,energy19,r,t,'CO2bio'])$(sameas[energy19,'natural gas incl. biongas'])
                                                                                       + ((1-sBionatgas[purpose,r,t])    * uEmmProdE[r,t,'CO2ubio',energy19]   * uEOPProdE[purpose,energy19,r,t,'CO2ubio'])$(sameas[energy19,'natural gas incl. biongas'])
                                                                                       #Consider removing bionatgas distinction as uEmm in forecast years are set to the same for ubio/bio
                                                                                       )
                                                                                        ;


      #For husholdninger 
      E_vtCO2_CE_ETS2[purpose,energy19,t]$(tx0[t] and d1CO2_CE_ETS2[purpose,energy19,t])..
        vtCO2_CE_ETS2[purpose,energy19,t] =E= tCO2_ETS2[t]/10**6 * growth_factor[t] * (qEmmConsE[t,'CO2ubio',purpose,energy19]$(d1EmmConsE[t,'CO2ubio',purpose,energy19])
                                                                                      +  qEmmConsE[t,'CO2bio',purpose,energy19]$(d1EmmConsE[t,'CO2ubio',purpose,energy19] and sameas[energy19,'Natural gas incl. biongas']))
                ;

    # VAT calculated on values - we calculate the VAT based on marginal rates and excluding payments for ETS-quotas
    E_vtVAT_RE[purpose,energy19,r,t]$(tx0[t] and d1VAT_RE[purpose,energy19,r,t])..      vtVAT_RE[purpose,energy19,r,t] =E= tVAT_RE[purpose,energy19,r,t] * (pRE_base_marg[purpose,energy19,r,t]*qREgj[purpose,energy19,r,t]$(d1pRE_base[purpose,energy19,r,t]) 
                                                                                                                                                            + vtEAFG_REmarg[purpose,energy19,r,t]$(d1EAFG_RE[purpose,energy19,r,t])

                                                                                                                                              + vtNOx_RE[purpose,energy19,r,t]$(d1NOx_RE[purpose,energy19,r,t])
                                                                                                                                                            + vtPSO_RE[purpose,energy19,r,t]$(d1PSO_RE[purpose,energy19,r,t])
                                                                                                                                                            + vtSO2_RE[purpose,energy19,r,t]$(d1SO2_RE[purpose,energy19,r,t])
                                                                                                                                                            + vtCO2_REmarg[purpose,energy19,r,t]$(d1CO2_RE[purpose,energy19,r,t])
                                                                                                                                                            + vEAV_RE[purpose,energy19,r,t]$(d1EAV_RE[purpose,energy19,r,t])
                                                                                                                                                            + vDAV_RE[purpose,energy19,r,t]$(d1DAV_RE[purpose,energy19,r,t])
                                                                                                                                                            + vCAV_RE[purpose,energy19,r,t]$(d1CAV_RE[purpose,energy19,r,t])
                                                                                                                                                            )
                                                                                                                                                            ;

    E_vtVAT_CE[purpose,energy19,t]$(tx0[t] and d1VAT_CE[purpose,energy19,t])..          vtVAT_CE[purpose,energy19,t]   =E= tVAT_CE[purpose,energy19,t]   *  (pCE_base[purpose,energy19,t]*qCE[purpose,energy19,t]$(d1vCE[purpose,energy19,t])
                                                                                                                                                            + vtEAFG_CE[purpose,energy19,t]$(d1EAFG_CE[purpose,energy19,t])
                                                                                                                                                            + vtSO2_CE[purpose,energy19,t]$(d1SO2_CE[purpose,energy19,t]) 
                                                                                                                                                            + vtCO2_CE[purpose,energy19,t]$(d1CO2_CE[purpose,energy19,t])
                                                                                                                                                            + vtNOx_CE[purpose,energy19,t]$(d1NOx_CE[purpose,energy19,t])
                                                                                                                                                            + vtPSO_CE[purpose,energy19,t]$(d1PSO_CE[purpose,energy19,t])  
                                                                                                                                                            + vEAV_CE[purpose,energy19,t]$(d1EAV_CE[purpose,energy19,t])
                                                                                                                                                            + vDAV_CE[purpose,energy19,t]$(d1DAV_CE[purpose,energy19,t])
                                                                                                                                                            + vCAV_CE[purpose,energy19,t]$(d1CAV_CE[purpose,energy19,t])
                                                                                                                                                            )
                                                                                                                                                            ;

    E_vtVAT_LE[purpose,energy19,t]$(tx0[t] and d1VAT_LE[purpose,energy19,t])..          vtVAT_LE[purpose,energy19,t]   =E= tVAT_LE[purpose,energy19,t]   *  (pLE_base[purpose,energy19,t]$d1vLE[purpose,energy19,t]*qLE[purpose,energy19,t]   
                                                                                                                                                            + vtEAFG_LE[purpose,energy19,t]$d1EAFG_LE[purpose,energy19,t] 
                                                                                                                                                            + vtSO2_LE[purpose,energy19,t]$d1SO2_LE[purpose,energy19,t] 
                                                                                                                                                            + vtCO2_LE[purpose,energy19,t]$d1CO2_LE[purpose,energy19,t]);

    E_vtVAT_XE[purpose,energy19,t]$(tx0[t] and d1VAT_XE[purpose,energy19,t])..          vtVAT_XE[purpose,energy19,t]   =E= tVAT_XE[purpose,energy19,t]   *  (pXE_base[purpose,energy19,t]$d1vXE[purpose,energy19,t]*qXE[purpose,energy19,t]   
                                                                                                                                                            + vtEAFG_XE[purpose,energy19,t]$d1EAFG_XE[purpose,energy19,t] 
                                                                                                                                                            + vtSO2_XE[purpose,energy19,t]$d1SO2_XE[purpose,energy19,t] 
                                                                                                                                                            + vtPSO_XE[purpose,energy19,t]$d1PSO_XE[purpose,energy19,t]
                                                                                                                                                            + vtCO2_XE[purpose,energy19,t]$d1CO2_XE[purpose,energy19,t]);    
    E_vBottomDeduction[r,t]$(tx0[t]).. vtBotDed[r,t] =E= 

                                                         sum((purpose,energy19)$(d1EAFG_RE[purpose,energy19,r,t]), - tEAFG_REmarg[purpose,energy19,r,t]*10**(-3) * qEAFG_REgj_ded[purpose,energy19,r,t] + jtEAFG_RE[purpose,energy19,r,t])
                                                       + sum((purpose,energy19,emm_eq)$(d1CO2_RE[purpose,energy19,r,t] and d1CO2_REmarg[purpose,energy19,r,t,emm_eq] and sameas[energy19,'district heat']),         -tCO2_REmarg[purpose,energy19,r,t,emm_eq] * qCO2_REgj_ded[purpose,energy19,r,t]) + sum((purpose,energy19)$(d1CO2_RE[purpose,energy19,r,t] and sameas[energy19,'district heat']),  jtCO2_RE[purpose,energy19,r,t])
                                                       + sum((purpose,energy19,emm_eq)$(d1CO2_RE[purpose,energy19,r,t] and d1CO2_REmarg[purpose,energy19,r,t,emm_eq] and d1EmmProdE[r,t,emm_eq,purpose,energy19] and not sameas[energy19,'district heat']),     -tCO2_REmarg[purpose,energy19,r,t,emm_eq]/10**6 * growth_factor[t]  * qEmmProdE_ded[r,t,emm_eq,purpose,energy19]) + sum((purpose,energy19)$(d1CO2_RE[purpose,energy19,r,t] and not sameas[energy19,'district heat']),  jtCO2_RE[purpose,energy19,r,t])
                                                       # Base deduction/free allowances based solely on the exptected allocation of quotas 
                                                       - tCO2_ETS[t]/10**6 *growth_factor[t] * (qEmmProdE_dedETS[r,t] + jEmmProdE_dedETS[r,t])$(d1CO2_ETS[r,t]);
                                 
    E_tRE_market[purpose,energy19,r,t]$(tx0[t] and d1tRE[purpose,energy19,r,t] and d1pRE_base[purpose,energy19,r,t]).. 
        tvRE[purpose,energy19,r,t] =E= (vtEAFG_RE[purpose,energy19,r,t]$d1EAFG_RE[purpose,energy19,r,t] 
                                       + vtSO2_RE[purpose,energy19,r,t]$d1SO2_RE[purpose,energy19,r,t] 
                                       + vtPSO_RE[purpose,energy19,r,t]$d1PSO_RE[purpose,energy19,r,t] 
                                       + vtNOx_RE[purpose,energy19,r,t]$d1NOx_RE[purpose,energy19,r,t] 
                                       + vtCO2_RE[purpose,energy19,r,t]$d1CO2_RE[purpose,energy19,r,t]
                                       + vtCO2_ETS2_marg[purpose,energy19,r,t]$(d1CO2_ETS2_marg[purpose,energy19,r,t])
                                       + vEAV_RE[purpose,energy19,r,t]$d1EAV_RE[purpose,energy19,r,t]
                                       + vDAV_RE[purpose,energy19,r,t]$d1DAV_RE[purpose,energy19,r,t]
                                       + vCAV_RE[purpose,energy19,r,t]$d1CAV_RE[purpose,energy19,r,t] 
                                       + vtVAT_RE[purpose,energy19,r,t]$d1VAT_RE[purpose,energy19,r,t]
                                       + vtCO2_ETS_marg[energy19,r,t]$(d1tCO2_ETS_marg[purpose,energy19,r,t] and sameas[purpose,'in_ETS'])
                                       #  + vtCalibENS[purpose,energy19,r,t]$(d1tRE[purpose,energy19,r,t])
                                      )/(pRE_base_marg[purpose,energy19,r,t]$d1pRE_base[purpose,energy19,r,t] * qREgj[purpose,energy19,r,t]);
  
    E_tRE_nonmarket[purpose,energy19,r,t]$(tx0[t] and d1tRE[purpose,energy19,r,t] and not (d1pRE_base[purpose,energy19,r,t] or d1pREown[purpose,energy19,r,t])).. 
        tqRE[purpose,energy19,r,t] * qREgj[purpose,energy19,r,t] =E= (vtEAFG_RE[purpose,energy19,r,t]$d1EAFG_RE[purpose,energy19,r,t] 
                                                                    + vtSO2_RE[purpose,energy19,r,t]$d1SO2_RE[purpose,energy19,r,t] 
                                                                    + vtPSO_RE[purpose,energy19,r,t]$d1PSO_RE[purpose,energy19,r,t] 
                                                                    + vtNOx_RE[purpose,energy19,r,t]$d1NOx_RE[purpose,energy19,r,t] 
                                                                    + vtCO2_RE[purpose,energy19,r,t]$d1CO2_RE[purpose,energy19,r,t] 
                                                                    + vtCO2_ETS2_marg[purpose,energy19,r,t]$(d1CO2_ETS2_marg[purpose,energy19,r,t])
                                                                    + vEAV_RE[purpose,energy19,r,t]$d1EAV_RE[purpose,energy19,r,t]
                                                                    + vDAV_RE[purpose,energy19,r,t]$d1DAV_RE[purpose,energy19,r,t]
                                                                    + vCAV_RE[purpose,energy19,r,t]$d1CAV_RE[purpose,energy19,r,t]

                                                                    + vtVAT_RE[purpose,energy19,r,t]$d1VAT_RE[purpose,energy19,r,t]
                                                                    + vtCO2_ETS_marg[energy19,r,t]$(d1tCO2_ETS_marg[purpose,energy19,r,t] and sameas[purpose,'in_ETS'])
                                                                    #  + vtCalibENS[purpose,energy19,r,t]$(d1tRE[purpose,energy19,r,t])
                                                                    );

    E_tRE_own[purpose,energy19,r,t]$(tx0[t] and d1tRE[purpose,energy19,r,t] and d1pREown[purpose,energy19,r,t]).. 
        tvRE[purpose,energy19,r,t] * pREown[purpose,energy19,r,t] * qREgj[purpose,energy19,r,t] 
                                                                 =E= (vtEAFG_RE[purpose,energy19,r,t]$d1EAFG_RE[purpose,energy19,r,t] 
                                                                    + vtSO2_RE[purpose,energy19,r,t]$d1SO2_RE[purpose,energy19,r,t] 
                                                                    + vtPSO_RE[purpose,energy19,r,t]$d1PSO_RE[purpose,energy19,r,t] 
                                                                    + vtNOx_RE[purpose,energy19,r,t]$d1NOx_RE[purpose,energy19,r,t] 
                                                                    + vtCO2_RE[purpose,energy19,r,t]$d1CO2_RE[purpose,energy19,r,t] 
                                                                    + vtCO2_ETS2_marg[purpose,energy19,r,t]$(d1CO2_ETS2_marg[purpose,energy19,r,t])
                                                                    + vEAV_RE[purpose,energy19,r,t]$d1EAV_RE[purpose,energy19,r,t]
                                                                    + vDAV_RE[purpose,energy19,r,t]$d1DAV_RE[purpose,energy19,r,t]
                                                                    + vCAV_RE[purpose,energy19,r,t]$d1CAV_RE[purpose,energy19,r,t]

                                                                    + vtVAT_RE[purpose,energy19,r,t]$d1VAT_RE[purpose,energy19,r,t]
                                                                    + vtCO2_ETS_marg[energy19,r,t]$(d1tCO2_ETS_marg[purpose,energy19,r,t] and sameas[purpose,'in_ETS'])
                                                                    #  + vtCalibENS[purpose,energy19,r,t]$(d1tRE[purpose,energy19,r,t])
                                                                    );
     
 
    E_tCE[purpose,energy19,t]$(tx0[t] and d1tCE[purpose,energy19,t]).. 
        tCE[purpose,energy19,t]       =E= (vEAV_CE[purpose,energy19,t]$d1EAV_CE[purpose,energy19,t]    
                                         + vDAV_CE[purpose,energy19,t]$d1DAV_CE[purpose,energy19,t]  
                                         + vCAV_CE[purpose,energy19,t]$d1CAV_CE[purpose,energy19,t] 
                                         + vtEAFG_CE[purpose,energy19,t]$d1EAFG_CE[purpose,energy19,t] 
                                         + vtSO2_CE[purpose,energy19,t]$d1SO2_CE[purpose,energy19,t] 
                                         + vtCO2_CE[purpose,energy19,t]$d1CO2_CE[purpose,energy19,t] 
                                         + vtPSO_CE[purpose,energy19,t]$d1PSO_CE[purpose,energy19,t] 
                                         + vtNOx_CE[purpose,energy19,t]$d1NOx_CE[purpose,energy19,t] 
                                         + vtVAT_CE[purpose,energy19,t]$d1VAT_CE[purpose,energy19,t]
                                         + vtCO2_CE_ETS2[purpose,energy19,t]$d1CO2_CE_ETS2[purpose,energy19,t])/(pCE_base[purpose,energy19,t]$d1vCE[purpose,energy19,t] * qCE[purpose,energy19,t]);
   
    E_tLE[purpose,energy19,t]$(tx0[t] and d1tLE[purpose,energy19,t]).. 
        tLE[purpose,energy19,t]       =E= (vtEAFG_LE[purpose,energy19,t]$d1EAFG_LE[purpose,energy19,t] + vtSO2_LE[purpose,energy19,t]$d1SO2_LE[purpose,energy19,t] + vtCO2_LE[purpose,energy19,t]$d1CO2_LE[purpose,energy19,t] + vtVAT_LE[purpose,energy19,t]$d1VAT_LE[purpose,energy19,t])/(pLE_base[purpose,energy19,t]$d1vLE[purpose,energy19,t] * qLE[purpose,energy19,t]);

    E_tXE[purpose,energy19,t]$(tx0[t] and d1tXE[purpose,energy19,t]).. 
      tXE_[purpose,energy19,t]*(pXE_base[purpose,energy19,t]$d1vXE[purpose,energy19,t] * qXE[purpose,energy19,t])   =E= (vtEAFG_XE[purpose,energy19,t]$d1EAFG_XE[purpose,energy19,t] + vtSO2_XE[purpose,energy19,t]$d1SO2_XE[purpose,energy19,t] + vtPSO_XE[purpose,energy19,t]$d1PSO_XE[purpose,energy19,t] + vtCO2_XE[purpose,energy19,t]$d1CO2_XE[purpose,energy19,t] + vtVAT_XE[purpose,energy19,t]$d1VAT_XE[purpose,energy19,t]);
    




      E_tREmarg_market[purpose,energy19,r,t]$(tx0[t] and d1tRE[purpose,energy19,r,t] and d1pRE_base[purpose,energy19,r,t])..  
          (1+tvREmarg[purpose,energy19,r,t]) * pRE_base_marg[purpose,energy19,r,t] =E=            pRE_base_marg[purpose,energy19,r,t]
                                                                                       +(tEAFG_REmarg[purpose,energy19,r,t]/1000)$(d1EAFG_RE[purpose,energy19,r,t])
                                                                                        +tSO2_RE[purpose,energy19,r,t]$d1SO2_RE[purpose,energy19,r,t]
                                                                                        +tPSO_RE[purpose,energy19,r,t]$d1PSO_RE[purpose,energy19,r,t]
                                                                                        +tNOx_RE[purpose,energy19,r,t]$d1NOx_RE[purpose,energy19,r,t]
                                                                                        +sum(emm_eq$d1CO2_REmarg[purpose,energy19,r,t,emm_eq] ,tCO2_REmarg_GJ[purpose,energy19,r,t,emm_eq])
                                                                                        + pEAV_RE[purpose,energy19,r,t]$(d1EAV_RE[purpose,energy19,r,t])
                                                                                        + pDAV_RE[purpose,energy19,r,t]$(d1DAV_RE[purpose,energy19,r,t])
                                                                                        + pCAV_RE[purpose,energy19,r,t]$(d1CAV_RE[purpose,energy19,r,t])                                                                                        
                                                                                        + tCALIBENS[purpose,energy19,r,t]$(d1pREgj[purpose,energy19,r,t])
                                                                                        + tCO2_ETS_GJ[purpose,energy19,r,t]$(d1tCO2_ETS_marg[purpose,energy19,r,t]) #No VAT on quotas
                                                                                        + tCO2_ETS2_GJ[purpose,energy19,r,t]$(d1CO2_ETS2_marg[purpose,energy19,r,t]) #No VAT on quotas - in principle the supplier should be paying this
                                                                                      ;

                                                                                         
                                                                                       

     E_tREmarg_market_own[purpose,energy19,r,t]$(tx0[t] and d1tRE[purpose,energy19,r,t] and d1pREown[purpose,energy19,r,t])..  
          (1+tvREmarg[purpose,energy19,r,t])*pREown[purpose,energy19,r,t] =E=  
                                                                                       pREown[purpose,energy19,r,t]
                                                                                       +(tEAFG_REmarg[purpose,energy19,r,t]/1000)$(d1EAFG_RE[purpose,energy19,r,t])
                                                                                       +tSO2_RE[purpose,energy19,r,t]$d1SO2_RE[purpose,energy19,r,t]
                                                                                       +tPSO_RE[purpose,energy19,r,t]$d1PSO_RE[purpose,energy19,r,t]
                                                                                       +tNOx_RE[purpose,energy19,r,t]$d1NOx_RE[purpose,energy19,r,t]
                                                                                       +sum(emm_eq$d1CO2_REmarg[purpose,energy19,r,t,emm_eq] ,tCO2_REmarg_GJ[purpose,energy19,r,t,emm_eq])
                                                                                       + pEAV_RE[purpose,energy19,r,t]$(d1EAV_RE[purpose,energy19,r,t])
                                                                                       + pDAV_RE[purpose,energy19,r,t]$(d1DAV_RE[purpose,energy19,r,t])
                                                                                       + pCAV_RE[purpose,energy19,r,t]$(d1CAV_RE[purpose,energy19,r,t])
                                                                                       + tCO2_ETS_GJ[purpose,energy19,r,t]$(d1tCO2_ETS_marg[purpose,energy19,r,t])
                                                                                       + tCO2_ETS2_GJ[purpose,energy19,r,t]$(d1CO2_ETS2_marg[purpose,energy19,r,t])
                                                                                       + tCALIBENS[purpose,energy19,r,t]$(d1pREgj[purpose,energy19,r,t])
                                                                                       
                                                                                      ;

     E_tREmarg_nonmarket[purpose,energy19,r,t]$(tx0[t] and d1tRE[purpose,energy19,r,t] and not (d1pRE_base[purpose,energy19,r,t] or d1pREown[purpose,energy19,r,t]))..  

        tqREmarg[purpose,energy19,r,t]  =E=   
                                                 +(tEAFG_REmarg[purpose,energy19,r,t]/1000)$(d1EAFG_RE[purpose,energy19,r,t])
                                                 +tSO2_RE[purpose,energy19,r,t]$d1SO2_RE[purpose,energy19,r,t]
                                                 +tPSO_RE[purpose,energy19,r,t]$d1PSO_RE[purpose,energy19,r,t]
                                                 +tNOx_RE[purpose,energy19,r,t]$d1NOx_RE[purpose,energy19,r,t]
                                                 +sum(emm_eq$d1CO2_REmarg[purpose,energy19,r,t,emm_eq] ,tCO2_REmarg_GJ[purpose,energy19,r,t,emm_eq])
                                                 + pEAV_RE[purpose,energy19,r,t]$(d1EAV_RE[purpose,energy19,r,t])
                                                 + pDAV_RE[purpose,energy19,r,t]$(d1DAV_RE[purpose,energy19,r,t])
                                                 + pCAV_RE[purpose,energy19,r,t]$(d1CAV_RE[purpose,energy19,r,t])
                                                 + tCO2_ETS_GJ[purpose,energy19,r,t]$(d1tCO2_ETS_marg[purpose,energy19,r,t])
                                                 + tCO2_ETS2_GJ[purpose,energy19,r,t]$(d1CO2_ETS2_marg[purpose,energy19,r,t])
                                                 + tCALIBENS[purpose,energy19,r,t]$(d1pREgj[purpose,energy19,r,t]);

   $ENDBLOCK

   $MODEL M_taxes_energy
    B_taxes_energy
   ;

    $MODEL M_taxes_aggregate_energy_tax_rates 
    E_tREmarg_market
    E_tREmarg_market_own
    E_tREmarg_nonmarket
  ;


 $ENDIF


# =====================================================================================================================
# Data assignment
# =====================================================================================================================
$IF %stage% == "exogenous_values":

  #1) READ DATA 

    #ENERGY-TAXES
      vtEAFG_RE.l[purpose,energy19,r,t]        = EN_vEAFG_RE[purpose,energy19,r,t];
      vtEAFG_CE.l[purpose,energy19,t]          = EN_vEAFG_CE[purpose,energy19,t];
      vtEAFG_XE.l[purpose,energy19,t]          = EN_vEAFG_XE[purpose,energy19,t];
          
      vtPSO_RE.l[purpose,energy19,r,t]         = EN_vPSO_RE[purpose,energy19,r,t];
      vtPSO_CE.l[purpose,energy19,t]           = EN_vPSO_CE[purpose,energy19,t];
      vtPSO_XE.l[purpose,energy19,t]           = EN_vPSO_XE[purpose,energy19,t];
          
      vtNOx_RE.l[purpose,energy19,r,t]         = EN_vNOx_RE[purpose,energy19,r,t];
      vtNOx_CE.l[purpose,energy19,t]           = EN_vNOx_CE[purpose,energy19,t];
          
      vtSO2_RE.l[purpose,energy19,r,t]         = EN_vSO2_RE[purpose,energy19,r,t];
      vtSO2_CE.l[purpose,energy19,t]           = EN_vSO2_CE[purpose,energy19,t];
          
      vtCO2_RE.l[purpose,energy19,r,t]         = EN_vCO2_RE[purpose,energy19,r,t];
      vtCO2_CE.l[purpose,energy19,t]           = EN_vCO2_CE[purpose,energy19,t];
          
      vtVAT_RE.l[purpose,energy19,r,t]         = EN_vMOMS_RE[purpose,energy19,r,t];
      vtVAT_CE.l[purpose,energy19,t]           = EN_vMOMS_CE[purpose,energy19,t];


      tCO2_ProdxE.l['23001',t,'CO2ubio']       =  tCO2_REmarg_SKM.l['cement_ETS',t];   #sum((categoryENS,GSR_ag,tREbase_SKM)$(sum((energy19,purpose),sENS2GR(categoryENS, GSR_ag, purpose, energy19, s)) and sum(energy19,tREbase_SKM_2_ENS(tREbase_SKM,categoryENS,GSR_ag,energy19)) and EM_NER[emm,s,'2019']), tCO2_REmarg_SKM.l[tREbase_SKM,t])/GWP_UN_obs[emm];
      tCO2_ProdxE.l['23002',t,'CO2ubio']       =  tCO2_REmarg_SKM.l['cement_ETS',t];   #sum((categoryENS,GSR_ag,tREbase_SKM)$(sum((energy19,purpose),sENS2GR(categoryENS, GSR_ag, purpose, energy19, s)) and sum(energy19,tREbase_SKM_2_ENS(tREbase_SKM,categoryENS,GSR_ag,energy19)) and EM_NER[emm,s,'2019']), tCO2_REmarg_SKM.l[tREbase_SKM,t])/GWP_UN_obs[emm];

      tCO2_ProdxE.l[s,t,'CO2ubio']$(sum((purpose,energy19,categoryENS), sENS2GR(categoryENS,'Mineralogi_oevrig',purpose,energy19,s))) =  tCO2_REmarg_SKM.l['cement_ETS',t];

      #MARGINAL TAX-RATES
        #ON BUSINESSES
          # Loading marginal rates via mappings
          tEAFG_REmarg.l[purpose,energy19,s,t]               = sum((categoryENS,GSR_ag,tREbase_SKM)$(sENS2GR(categoryENS, GSR_ag, purpose, energy19, s) and tREbase_SKM_2_ENS(tREbase_SKM,categoryENS,GSR_ag,energy19) and EN_qRE[purpose,energy19,s,'2019'] and not sameas[energy19,'Jet petroleum']), tEAFG_REmarg_SKM.l[tREbase_SKM,t]);
          #  tEAFG_REmarg.l[purpose_xt,'electricity','64000',t]$(EN_qRE[purpose_xt,'electricity','64000','2019']) = tEAFG_REmarg_SKM.l['el_ikke-proces',t]; #Finansiel sektor (strengt taget momsfritagne/l?nsumsomfattede vsh) betaler fuld elafgift, jf. mail fra Sebastian Lind SKM d. 22.5.2024. Kh AKB
          tEAFG_REmarg.l[purpose_xt,'electricity','64000',t]$(EN_qRE[purpose_xt,'electricity','64000','2019']) = tEAFG_REmarg_SKM.l['el_ikke-proces',t]; #Finansiel sektor (strengt taget momsfritagne/l?nsumsomfattede vsh) betaler fuld elafgift, jf. mail fra Sebastian Lind SKM d. 22.5.2024. Kh AKB
          # Test of energy taxes
              LOOP((purpose,energy19,s),
                tjek = tEAFG_REmarg.l[purpose,energy19,s,'2019'];

                ABORT$(tjek > smax(tREbase_SKM,tEAFG_REmarg_SKM.l(tREbase_SKM,'2019'))) tjek, "De indl?te energiafgifter m?ikke overstige max i input fra data - hvis det g?r er der fejl i mappingen tREbase_SKM_2_ENS";
                );
              
          # Post-correcting for cement. Cement is not calculated for itself until next data delivery.
          tEAFG_REmarg.l['in_ETS',energy19,'23001',t]$(energy19_SKM[energy19] and EN_qRE['in_ETS',energy19,'23001','2019']) = tEAFG_REmarg_SKM.l['cement_ETS',t];
          tEAFG_REmarg.l['in_ETS',energy19,'23002',t]$(energy19_SKM[energy19] and EN_qRE['in_ETS',energy19,'23002','2019']) = tEAFG_REmarg_SKM.l['cement_ETS',t];

          # Correction on district heat (At DST the energy tax is put on the end consumer of the district heat. At SKM the tax is put on the district heat producer's use of fossil fuel. Therefore, we cannot use the marginal "producer rate" on the end consumer bur uses instead the average from DST-data)
          tEAFG_REmarg.l[purpose,'District heat',s,tDataEnd]$(EN_vEAFG_RE[purpose,'District heat',s,tDataEnd]) = EN_vEAFG_RE[purpose,'District heat',s,tDataEnd]/EN_qRE[purpose,'District heat',s,tDataEnd]*1000; #We have to multiply by 1000 because the unit is kr per GJ on marginal tax-rates
          tEAFG_REmarg.l[purpose,'District heat',s,tForecast] = tEAFG_REmarg.l[purpose,'District heat',s,tDataEnd]; 

          vtEAFG_REmarg.l[purpose,energy19,r,t] = tEAFG_REmarg.l[purpose,energy19,r,t] * EN_qRE[purpose,energy19,r,t]  *10**(-3);


          tCO2_REmarg.l[purpose,energy19,s,t,'CO2ubio']                   = sum((categoryENS,GSR_ag,tREbase_SKM)$(sENS2GR(categoryENS, GSR_ag, purpose, energy19, s) and tREbase_SKM_2_ENS(tREbase_SKM,categoryENS,GSR_ag,energy19) and EM_RE['CO2ubio',purpose,energy19,s,'2019']), tCO2_REmarg_SKM.l[tREbase_SKM,t]);
          tCO2_REmarg.l[purpose,'Natural gas incl. biongas',s,t,'CO2bio'] = sum((categoryENS,GSR_ag,tREbase_SKM)$(sENS2GR(categoryENS, GSR_ag, purpose, 'Natural gas incl. biongas', s) and tREbase_SKM_2_ENS(tREbase_SKM,categoryENS,GSR_ag,'Natural gas incl. biongas') and EM_RE['CO2bio',purpose,'Natural gas incl. biongas',s,'2019'] and EM_RE['CO2ubio',purpose,'Natural gas incl. biongas',s,'2019']), tCO2_REmarg_SKM.l[tREbase_SKM,t]);

          # Test of loaded energu taxes
              LOOP((purpose,energy19,s),
                # Checking for CO2ubio
                tjek = tCO2_REmarg.l[purpose,energy19,s,'2019','CO2ubio'];
                ABORT$(tjek > smax(tREbase_SKM,tCO2_REmarg_SKM.l(tREbase_SKM,'2019'))) tjek, "De indl?te CO2-afgifter m?ikke overstige max i input fra data - hvis det g?r er der fejl i mappingen tREbase_SKM_2_ENS";
                # Checking for CO2bio
                tjek = tCO2_REmarg.l[purpose,energy19,s,'2019','CO2bio'];
                ABORT$(tjek > smax(tREbase_SKM,tCO2_REmarg_SKM.l(tREbase_SKM,'2019'))) tjek, "De indl?te CO2-afgifter m?ikke overstige max i input fra data - hvis det g?r er der fejl i mappingen tREbase_SKM_2_ENS";
                );

          # We take marginal tax-rates on district heat as the one computed from DST data  
          tCO2_REmarg.l[purpose,'District heat',s,tDataEnd,'CO2ubio']$(EN_vCO2_RE[purpose,'District heat',s,tDataEnd]) = EN_vCO2_RE[purpose,'District heat',s,tDataEnd]/EN_qRE[purpose,'District heat',s,tDataEnd];
        #ON HOUSEHOLDS 
          tCO2_CE.l['transport','Gasoline for transport',tForecast]    =  tCO2_REmarg_SKM.l['Benzin',tForecast];
          tCO2_CE.l['transport','Diesel for transport',tForecast]      =  tCO2_REmarg_SKM.l['Diesel',tForecast];
          tCO2_CE.l['transport','Natural gas incl. biongas',tForecast] =  tCO2_REmarg_SKM.l['Diesel',tForecast]; #Antager, der også skal afgift på naturgas...

          tCO2_CE.l['heating',energy19,tForecast]$(energy19fosxbunk[energy19] and qCE.l['heating',energy19,tDataEnd]) =  tCO2_REmarg_SKM.l['Rumvarme',tForecast];

          tEAFG_CE.l['transport','Gasoline for transport',tForecast]                = tEAFG_REmarg_SKM.l['Benzin',tForecast];
          tEAFG_CE.l['transport','Diesel for transport',tForecast]                  = tEAFG_REmarg_SKM.l['Diesel',tForecast];
          tEAFG_CE.l['transport','natural gas incl. biongas',tForecast]             = 3/4*tEAFG_REmarg_SKM.l['Diesel',tForecast]; #Der ser ud til at være energiafgift på naturgas i data, men hvad skal satsen være? Sætter den til 3/4 af diesel.

          tEAFG_CE.l['heating',energy19,tForecast]$(energy19fosxbunk[energy19] and qCE.l['heating',energy19,tDataEnd])     = tEAFG_REmarg_SKM.l['Rumvarme',tForecast];
          tEAFG_CE.l['heating',energy19,tForecast]$(not energy19fosxbunk[energy19] and qCE.l['heating',energy19,tDataEnd]) = tEAFG_REmarg_SKM.l['Rumvarme',tForecast];
          #  tEAFG_CE.l['appliances','electricity',tForecast]                          = tEAFG_REmarg_SKM.l['el_privat',tForecast];
          #  tEAFG_CE.l['transport','electricity',tForecast]                           = tEAFG_REmarg_SKM.l['el_privat',tForecast];
          tEAFG_CE.l['appliances','electricity',tForecast]                          = tEAFG_REmarg_SKM.l['el_privat',tForecast];
          tEAFG_CE.l['transport','electricity',tForecast]                           = tEAFG_REmarg_SKM.l['el_privat',tForecast];


      # EU-ETS QUOTAS 
        tCO2_ETS.l[t]  = KF25_pETS[t]; 
        tCO2_ETS2.l[t] = KF25_pETS2[t];  

        #Ad hoc solution to free allowances being phased out towards 2034, cf. https://www.ey.com/en_gl/tax-alerts/european-parliament-approves-eu-emission-trading-system-reform-a
        kvotedata[brch,'2031'] = kvotedata[brch,'2030']*0.75;   kvotedata[brch,'2032'] = kvotedata[brch,'2030']*0.5;   kvotedata[brch,'2033'] = kvotedata[brch,'2030']*0.25; 

        qEmmProdE_dedETS.l[r,t] = sum(ns105$(map1052five(r,ns105)), sum(nsGR$(nsGR2ns105(ns105,nsGR)), sum(brch$(brch2nsGR(brch,nsGR)), kvotedata[brch,t])))/1000; #Omregner til kiloton CO2
        qEmmProdE_dedETS.l['23002',t] = 0.1 * qEmmProdE_dedETS.l['23001',t]; 
        qEmmProdE_dedETS.l['23001',t] = 0.9 * qEmmProdE_dedETS.l['23001',t]; 

        vtCO2_ETS.l[r,t]        = sum(ns105$(map1052five(r,ns105)), sum(nsGR$(nsGR2ns105(ns105,nsGR)), sum(brch$(brch2nsGR(brch,nsGR)), vkvote_data[brch,t])))/10**6; #Omregner til mia. kr.

  #2) EXOGENOUS PARAMETERS AND VARIABLES


  #3) COMPUTATIONS 



    #ENERGY-TAXES 
      tCO2_REmarg_GJ.l[purpose,energy19,r,t,'CO2ubio'] = tCO2_REmarg.l[purpose,energy19,r,t,'CO2ubio']/10**6 * uEmmHardCoded['CO2ubio',energy19];
      tCO2_REmarg_GJ.l[purpose,energy19,r,t,'CO2bio']$(sameas[energy19,'Natural gas incl. biongas'])  = tCO2_REmarg.l[purpose,energy19,r,t,'CO2bio']/10**6 * uEmmHardCoded['CO2bio',energy19];
      tCO2_REmarg_GJ.l[purpose,'District heat',r,t,'CO2ubio'] = tCO2_REmarg.l[purpose,'District heat',r,t,'CO2ubio'];

  #4) INITIAL VALUES 
  
    #ENERGY-TAXES
      tEAFG_CE.l[purpose,energy19,t]$(vtEAFG_CE.l[purpose,energy19,t])     = vtEAFG_CE.l[purpose,energy19,t]/qCE.l[purpose,energy19,t]; 
      tEAFG_XE.l[purpose,energy19,t]$(vtEAFG_XE.l[purpose,energy19,t] and qXE.l[purpose,energy19,t])     = vtEAFG_XE.l[purpose,energy19,t]/qXE.l[purpose,energy19,t];
      tCO2_CE.l[purpose,energy19,t]$(vtCO2_CE.l[purpose,energy19,t])       = vtCO2_CE.l[purpose,energy19,t]/qCE.l[purpose,energy19,t]; 
      tSO2_RE.l[purpose,energy19,r,t]$(vtSO2_RE.l[purpose,energy19,r,t] and qREgj.l[purpose,energy19,r,t])   = vtSO2_RE.l[purpose,energy19,r,t]/qREgj.l[purpose,energy19,r,t];
      tSO2_CE.l[purpose,energy19,t]$(vtSO2_CE.l[purpose,energy19,t])       = vtSO2_CE.l[purpose,energy19,t]/qCE.l[purpose,energy19,t]; 
      #  tSO2_LE.l[purpose,energy19,t]$(vtSO2_LE.l[purpose,energy19,t])       = vtSO2_LE.l[purpose,energy19,t]/qLE.l[purpose,energy19,t]; 
      #  tSO2_XE.l[purpose,energy19,t]$(vtSO2_XE.l[purpose,energy19,t])       = vtSO2_XE.l[purpose,energy19,t]/qXE.l[purpose,energy19,t]; 
      tPSO_RE.l[purpose,energy19,r,t]$(vtPSO_RE.l[purpose,energy19,r,t] and qREgj.l[purpose,energy19,r,t])   = vtPSO_RE.l[purpose,energy19,r,t]/qREgj.l[purpose,energy19,r,t];
      tPSO_CE.l[purpose,energy19,t]$(vtPSO_CE.l[purpose,energy19,t])       = vtPSO_CE.l[purpose,energy19,t]/qCE.l[purpose,energy19,t];
      #  tPSO_XE.l[purpose,energy19,t]$(vtPSO_XE.l[purpose,energy19,t])      = vtPSO_XE.l[purpose,energy19,t]/qXE.l[purpose,energy19,t]; #AKB: Man kunne give en startv�rdi her, men GAMS tror at den dividerer med nul... s� derfor udkommenteret
      tNOx_RE.l[purpose,energy19,r,t]$(vtNOx_RE.l[purpose,energy19,r,t] and qREgj.l[purpose,energy19,r,t])   = vtNOx_RE.l[purpose,energy19,r,t]/qREgj.l[purpose,energy19,r,t];
      tNOx_CE.l[purpose,energy19,t]$(vtNOx_CE.l[purpose,energy19,t])       = vtNOx_CE.l[purpose,energy19,t]/qCE.l[purpose,energy19,t];
      tVAT_RE.l[purpose,energy19,r,t]$(vtVAT_RE.l[purpose,energy19,r,t] and qREgj.l[purpose,energy19,r,t])   = vtVAT_RE.l[purpose,energy19,r,t]/qREgj.l[purpose,energy19,r,t];
      tVAT_CE.l[purpose,energy19,t]$(vtVAT_CE.l[purpose,energy19,t])       = vtVAT_CE.l[purpose,energy19,t]/qCE.l[purpose,energy19,t]; 


      vtCO2_REmarg.l[purpose,energy19,r,t] = sum(emm, tCO2_REmarg.l[purpose,energy19,r,t,emm]/10**6 * growth_factor[t]*EM_RE[emm,purpose,energy19,r,t]);


    #ENERGY
      #EU-ETS
        vtCO2_ProdxE.l[s,t,emm]            =  tCO2_ProdxE.l[s,t,emm]/10**6; 


      #ETS2 
      vtCO2_ETS2_marg.l[purpose,energy19,r,t]$(tForecast[t] and d1CO2_ETS2_marg[purpose,energy19,r,t])
        = tCO2_ETS2.l[t]/10**6 *growth_factor[t] *  (qEmmProdE.l[r,tDataEnd,'CO2ubio',purpose,energy19]$(d1EmmProdE[r,tDataEnd,'CO2ubio',purpose,energy19])
                                                    +qEmmProdE.l[r,tDataEnd,'CO2bio',purpose,energy19]$(d1EmmProdE[r,tDataEnd,'CO2bio',purpose,energy19] and sameas[energy19,'Natural gas incl. biongas']));
      

  #5) DUMMIES - NOTE, AGGREGATE DUMMY d1tRE IS CREATED IN UPDATE_DUMMIES.GMS

    #ENERGY-TAXES
      d1EAFG_RE[purpose,energy19,r,t]           = yes$(tEAFG_REmarg.l[purpose,energy19,r,t] or vtEAFG_RE.l[purpose,energy19,r,t]);
      d1EAFG_RE_marg[purpose,energy19,r,t]      = yes$(tEAFG_REmarg.l[purpose,energy19,r,t]);
      d1EAFG_CE[purpose,energy19,t]             = yes$(vtEAFG_CE.l[purpose,energy19,t]);
      d1EAFG_LE[purpose,energy19,t]             = yes$(vtEAFG_LE.l[purpose,energy19,t]);
      d1EAFG_XE[purpose,energy19,t]             = yes$(vtEAFG_XE.l[purpose,energy19,t]);

      d1SO2_RE[purpose,energy19,r,t]            = yes$(vtSO2_RE.l[purpose,energy19,r,t]);
      d1SO2_CE[purpose,energy19,t]              = yes$(vtSO2_CE.l[purpose,energy19,t]);
      d1SO2_LE[purpose,energy19,t]              = yes$(vtSO2_LE.l[purpose,energy19,t]);
      d1SO2_XE[purpose,energy19,t]              = yes$(vtSO2_XE.l[purpose,energy19,t]);

      d1PSO_RE[purpose,energy19,r,t]            = yes$(vtPSO_RE.l[purpose,energy19,r,t]);
      d1PSO_CE[purpose,energy19,t]              = yes$(vtPSO_CE.l[purpose,energy19,t]);
      d1PSO_LE[purpose,energy19,t]              = yes$(vtPSO_LE.l[purpose,energy19,t]); 
      d1PSO_XE[purpose,energy19,t]              = yes$(vtPSO_XE.l[purpose,energy19,t]);


      d1NOx_RE[purpose,energy19,r,t]            = yes$(vtNOx_RE.l[purpose,energy19,r,t]);
      d1NOx_CE[purpose,energy19,t]              = yes$(vtNOx_CE.l[purpose,energy19,t]);
      d1NOx_LE[purpose,energy19,t]              = yes$(vtNOx_LE.l[purpose,energy19,t]); 
      d1NOx_XE[purpose,energy19,t]              = yes$(vtNOx_XE.l[purpose,energy19,t]);

      d1CO2_CE[purpose,energy19,t]              = yes$(vtCO2_CE.l[purpose,energy19,t]);
      d1CO2_LE[purpose,energy19,t]              = yes$(vtCO2_LE.l[purpose,energy19,t]);
      d1CO2_XE[purpose,energy19,t]              = yes$(vtCO2_XE.l[purpose,energy19,t]);

      d1VAT_RE[purpose,energy19,r,t]            = yes$(vtVAT_RE.l[purpose,energy19,r,t]);
      d1VAT_CE[purpose,energy19,t]              = yes$(vtVAT_CE.l[purpose,energy19,t]);
      d1VAT_LE[purpose,energy19,t]              = yes$(vtVAT_LE.l[purpose,energy19,t]);
      d1VAT_XE[purpose,energy19,t]              = yes$(vtVAT_XE.l[purpose,energy19,t]);

      d1tCE[purpose,energy19,t]                 = yes$(EN_vnCE[purpose,energy19,t]    and (d1EAFG_CE[purpose,energy19,t] or d1SO2_CE[purpose,energy19,t] or d1PSO_CE[purpose,energy19,t] or d1NOx_CE[purpose,energy19,t] or d1CO2_CE[purpose,energy19,t] or d1VAT_CE[purpose,energy19,t]));
      d1tLE[purpose,energy19,t]                 = yes$(EN_vnLE[purpose,energy19,t]    and (d1EAFG_LE[purpose,energy19,t] or d1SO2_LE[purpose,energy19,t] or d1PSO_LE[purpose,energy19,t] or d1NOx_LE[purpose,energy19,t] or d1CO2_LE[purpose,energy19,t] or d1VAT_LE[purpose,energy19,t]));
      d1tXE[purpose,energy19,t]                 = yes$(EN_vnXE[purpose,energy19,t]    and (d1EAFG_XE[purpose,energy19,t] or d1SO2_XE[purpose,energy19,t] or d1PSO_XE[purpose,energy19,t] or d1NOx_XE[purpose,energy19,t] or d1CO2_XE[purpose,energy19,t] or d1VAT_XE[purpose,energy19,t]));


      d1qRE_new[purpose,energy19,r,t]           = no;
      d1qREgj_KFnew[purpose,energy19,r,t]       = no;
      d1qREgj_ABnew[purpose,energy19,r,t]       = no;

      #CO2 firms
      d1CO2_RE[purpose,energy19,r,t] = no; d1CO2_REmarg[purpose,energy19,r,t,emm_eq] = no; d1CO2_REmarg_sumemm[purpose,energy19,r,t] = no;
      d1CO2_RE[purpose,energy19,r,t]            = yes$(sum(emm_eq, tCO2_REmarg.l[purpose,energy19,r,t,emm_eq]) or vtCO2_RE.l[purpose,energy19,r,t]);
      d1CO2_REmarg[purpose,energy19,r,t,emm_eq] = yes$(tCO2_REmarg.l[purpose,energy19,r,t,emm_eq]);
      d1CO2_REmarg_sumemm[purpose,energy19,r,t] = yes$(sum(emm_eq, d1CO2_REmarg[purpose,energy19,r,t,emm_eq]));

         #After last data year
        d1CO2_RE[purpose,energy19,r,tForecast]            = yes$(sum(emm_eq, tCO2_REmarg.l[purpose,energy19,r,tForecast,emm_eq])); #I data favner vi begge muligheder
        d1CO2_REmarg[purpose,energy19,r,tForecast,emm_eq] = yes$(tCO2_REmarg.l[purpose,energy19,r,tForecast,emm_eq]);
        d1CO2_REmarg_sumemm[purpose,energy19,r,tForecast] = yes$(sum(emm_eq, d1CO2_REmarg[purpose,energy19,r,tForecast,emm_eq]));

        #From non-energy related emissions
         d1CO2_ProdxE[s,t,emm]                     = yes$(vtCO2_ProdxE.l[s,t,emm]);

      #EU-ETS
        #ETS2-rely on CO2-mapping

      d1CO2_ETS2_marg[purpose,energy19,r,t]   = no; d1CO2_ETS2[r,t] = no;
      d1CO2_ETS2_marg[purpose,energy19,r,t]$(tCO2_ETS2.l[t] and not sLan[r] 
                                                    and d1qREgj[purpose,energy19,r,t]
                                                    and not sameas[purpose,'in_ETS'] 
                                                    and (d1EmmProdE[r,t,'CO2ubio',purpose,energy19] or (d1EmmProdE[r,t,'CO2bio',purpose,energy19] and sameas[energy19,'Natural gas incl. biongas']))
                                                    and not sameas[energy19,'District heat']) = yes;

       d1CO2_ETS2[r,t]                         = yes$(sum((purpose,energy19),d1CO2_ETS2_marg[purpose,energy19,r,t]));
 
$ENDIF


# =====================================================================================================================
# Static calibration
# =====================================================================================================================
$IF %stage% == "static_calibration":

  $GROUP G_taxes_energy_static_calibration
    G_taxes_energy_endo
    -G_energy_taxes_values
      vtBotDed 
      vtCO2_ETS_marg$(d1tCO2_ETS_marg['in_ETS',energy19,r,t])
      vtCO2_ETSxE_marg$(d1EmmProdxE[r,t,'CO2e'] and d1CO2_ETS[r,t])
      vtCO2_ETS2_marg$(d1CO2_ETS2_marg[purpose,energy19,r,t])
      vtEAFG_REmarg$(d1EAFG_RE[purpose,energy19,r,t])
      vtCO2_REmarg$(d1CO2_RE[purpose,energy19,r,t]) 
    G_energy_taxes_rates
      -tEAFG_REmarg$(d1tRE[purpose,energy19,r,t])
      -tCO2_REmarg 
      -tCO2_ETS
      -tCO2_ETS2$(tx0[t])
      -tCALIBENS$(d1pREgj[purpose,energy19,r,t])
      -tCO2_ETS_avg
      -tSO2_REmarg
    jtCO2_RE$(d1CO2_RE[purpose,energy19,r,t] and not d1CO2_REmarg_sumemm[purpose,energy19,r,t]) 
    qEAFG_REgj_ded$(d1EAFG_RE[purpose,energy19,r,t] and d1EAFG_RE_marg[purpose,energy19,r,t] )
    jtEAFG_RE$(d1EAFG_RE[purpose,energy19,r,t] and not d1EAFG_RE_marg[purpose,energy19,r,t] )

    qEmmProdE_ded$(d1CO2_REmarg[purpose,energy19,r,t,emm_eq] and d1EmmProdE[r,t,emm_eq,purpose,energy19] and not sameas[energy19,'district heat'])
    qCO2_REgj_ded$(d1CO2_RE[purpose,energy19,r,t] and sameas[energy19,'district heat'])

    jEmmProdE_dedETS$(d1CO2_ETS[r,t]), -vtCO2_ETS, -vtCO2_ETS2$(tData[t])
  ;

 $GROUP G_taxes_energy_static_calibration G_taxes_energy_static_calibration$(tx0[t]); 

  $GROUP G_taxes_energy_static_calibration_exo
    G_taxes_energy_exo
    G_energy_taxes_values
     -vtBotDed
     -vtCO2_ETS_marg
     -vtCO2_ETSxE_marg
     -vtCO2_ETS2_marg$(d1CO2_ETS2_marg[purpose,energy19,r,t])
     -vtEAFG_REmarg
     -vtCO2_REmarg
     -vtCO2_ETS2
     -vBottomDeduction_CO2
     -vBottomDeduction_EAFG
     -vBottomDeduction_CO2_ETS
     -vtCalibENS
    -G_energy_taxes_rates
      tEAFG_REmarg$(d1EAFG_RE[purpose,energy19,r,t])
      tCO2_REmarg$(d1CO2_RE[purpose,energy19,r,t] and d1CO2_REmarg[purpose,energy19,r,t,emm_eq])
      tCO2_ETS
      tCALIBENS$(d1pREgj[purpose,energy19,r,t] and d1tRE[purpose,energy19,r,t])
    -jtCO2_RE$(d1CO2_RE[purpose,energy19,r,t] and not d1CO2_REmarg_sumemm[purpose,energy19,r,t])
    -qEAFG_REgj_ded$(d1EAFG_RE[purpose,energy19,r,t] and d1EAFG_RE_marg[purpose,energy19,r,t] )
    -jtEAFG_RE$(d1EAFG_RE[purpose,energy19,r,t] and not d1EAFG_RE_marg[purpose,energy19,r,t] )


    -qEmmProdE_ded$(sum(tt,d1CO2_REmarg[purpose,energy19,r,tt,emm_eq]))
    -qCO2_REgj_ded$(d1CO2_RE[purpose,energy19,r,t] and sameas[energy19,'district heat'])

    -jEmmProdE_dedETS$(d1CO2_ETS[r,t])
    -qEmmProdE, qEmmProdE$(d1CO2_RE[purpose,energy19,s,t] and not sameas[energy19,'district heat'] and d1CO2_REmarg[purpose,energy19,s,t,emm_eq] and d1EmmProdE[s,t,emm_eq,purpose,energy19]), qEmmProdE$(d1tCO2_ETS_marg[purpose,energy19,s,t] and d1EmmProdE[s,t,emm_eq,purpose,energy19] and sameas[purpose,'in_ETS'] and (sameas[emm_eq,'CO2ubio'] or (sameas[emm_eq,'CO2bio'] and sameas[energy19,'Natural gas incl. biongas']))), qEmmProdE$(tx1[t] and d1CO2_REmarg[purpose,energy19,s,t,emm_eq] and d1EmmProdE[s,t,emm_eq,purpose,energy19] and not sameas[energy19,'district heat'] and not d1qREgj_KFnew[purpose,energy19,s,t] and not d1qREgj_ABnew[purpose,energy19,s,t]) 

 ;
 
 $GROUP G_taxes_energy_static_calibration_exo G_taxes_energy_static_calibration_exo$(tx0[t]); 


    $BLOCK B_taxes_static_calibration 
        # In the case of Natural gas incl. biongas we assume no deductions
        E_qEmmProdE_ded_biogas[r,t,purpose]$(tx0[t] and d1CO2_REmarg_sumemm[purpose,'Natural gas incl. biongas',r,t] and d1EmmProdE[r,t,'CO2bio',purpose,'Natural gas incl. biongas'] and d1EmmProdE[r,t,'CO2ubio',purpose,'Natural gas incl. biongas'])..
            qEmmProdE_ded[r,t,'CO2bio',purpose,'Natural gas incl. biongas'] =E= 0;

    $ENDBLOCK


  $MODEL M_taxes_energy_static_calibration
    B_taxes_energy
    B_taxes_static_calibration
  ;

$ENDIF

# =====================================================================================================================
# Dynamic calibration
# =====================================================================================================================
$IF %stage% == "dynamic_calibration":

$BLOCK B_taxes_calib 
    E_tREmarg_market_calib[purpose,energy19,r,t]$(tx0[t] and d1tRE[purpose,energy19,r,t] and d1pRE_base[purpose,energy19,r,t])..  
        tvREmarg[purpose,energy19,r,t] * (pRE_base_marg[purpose,energy19,r,t] * qREgj[purpose,energy19,r,t]) 
                                             =E= (vtEAFG_REmarg[purpose,energy19,r,t]$d1EAFG_RE[purpose,energy19,r,t] 
                                                + vtSO2_RE[purpose,energy19,r,t]$d1SO2_RE[purpose,energy19,r,t]
                                                + vtPSO_RE[purpose,energy19,r,t]$d1PSO_RE[purpose,energy19,r,t]
                                                + vtNOx_RE[purpose,energy19,r,t]$d1NOx_RE[purpose,energy19,r,t] 
                                                + vtCO2_REmarg[purpose,energy19,r,t]$d1CO2_RE[purpose,energy19,r,t] 
                                                + vEAV_RE[purpose,energy19,r,t]$d1EAV_RE[purpose,energy19,r,t]
                                                + vDAV_RE[purpose,energy19,r,t]$d1DAV_RE[purpose,energy19,r,t]
                                                + vCAV_RE[purpose,energy19,r,t]$d1CAV_RE[purpose,energy19,r,t]
                                                + vtCO2_ETS_marg[energy19,r,t]$(d1tCO2_ETS_marg[purpose,energy19,r,t] and sameas[purpose,'in_ETS'])
                                                + vtCO2_ETS2_marg[purpose,energy19,r,t]$(d1CO2_ETS2_marg[purpose,energy19,r,t])
                                                + vtCalibENS[purpose,energy19,r,t]$(d1pREgj[purpose,energy19,r,t])
                                                );



    E_tREmarg_own_calib[purpose,energy19,r,t]$(tx0[t] and d1tRE[purpose,energy19,r,t] and d1pREown[purpose,energy19,r,t])..  

        tvREmarg[purpose,energy19,r,t] * (pREown[purpose,energy19,r,t] * qREgj[purpose,energy19,r,t]) 
                                             =E= (vtEAFG_REmarg[purpose,energy19,r,t]$d1EAFG_RE[purpose,energy19,r,t] 
                                                + vtSO2_RE[purpose,energy19,r,t]$d1SO2_RE[purpose,energy19,r,t]
                                                + vtPSO_RE[purpose,energy19,r,t]$d1PSO_RE[purpose,energy19,r,t]
                                                + vtNOx_RE[purpose,energy19,r,t]$d1NOx_RE[purpose,energy19,r,t] 
                                                + vtCO2_REmarg[purpose,energy19,r,t]$d1CO2_RE[purpose,energy19,r,t] 
                                                + vEAV_RE[purpose,energy19,r,t]$d1EAV_RE[purpose,energy19,r,t]
                                                + vDAV_RE[purpose,energy19,r,t]$d1DAV_RE[purpose,energy19,r,t]
                                                + vCAV_RE[purpose,energy19,r,t]$d1CAV_RE[purpose,energy19,r,t]
                                                + vtCO2_ETS_marg[energy19,r,t]$(d1tCO2_ETS_marg[purpose,energy19,r,t] and sameas[purpose,'in_ETS'])
                                                + vtCO2_ETS2_marg[purpose,energy19,r,t]$(d1CO2_ETS2_marg[purpose,energy19,r,t])
                                                + vtCalibENS[purpose,energy19,r,t]$(d1pREgj[purpose,energy19,r,t])
                                                );




    E_tREmarg_nonmarket_calib[purpose,energy19,r,t]$(tx0[t] and d1tRE[purpose,energy19,r,t] and not (d1pRE_base[purpose,energy19,r,t] or d1pREown[purpose,energy19,r,t]))..  

        tqREmarg[purpose,energy19,r,t] * qREgj[purpose,energy19,r,t] =E= (vtEAFG_REmarg[purpose,energy19,r,t]$d1EAFG_RE[purpose,energy19,r,t] 
                                                                        + vtSO2_RE[purpose,energy19,r,t]$d1SO2_RE[purpose,energy19,r,t] 
                                                                        + vtCO2_REmarg[purpose,energy19,r,t]$d1CO2_RE[purpose,energy19,r,t] 
                                                                        + vtNOx_RE[purpose,energy19,r,t]$d1NOx_RE[purpose,energy19,r,t]
                                                                        + vtPSO_RE[purpose,energy19,r,t]$d1PSO_RE[purpose,energy19,r,t]
                                                                        + vEAV_RE[purpose,energy19,r,t]$d1EAV_RE[purpose,energy19,r,t]
                                                                        + vDAV_RE[purpose,energy19,r,t]$d1DAV_RE[purpose,energy19,r,t]
                                                                        + vCAV_RE[purpose,energy19,r,t]$d1CAV_RE[purpose,energy19,r,t]
                                                                        + vtCO2_ETS_marg[energy19,r,t]$(d1tCO2_ETS_marg[purpose,energy19,r,t] and sameas[purpose,'in_ETS'])
                                                                        + vtCO2_ETS2_marg[purpose,energy19,r,t]$(d1CO2_ETS2_marg[purpose,energy19,r,t])
                                                                        + vtCalibENS[purpose,energy19,r,t]$(d1pREgj[purpose,energy19,r,t])
                                                                        );
$ENDBLOCK


$GROUP G_taxes_energy_calib
    G_taxes_energy_endo
;

$GROUP G_taxes_energy_calib_exo
    G_taxes_energy_exo
;

$MODEL M_taxes_energy_calib 
    B_taxes_energy
;

#BOTTOM DEDUCTIONS ON SELECTED ITEMS SET TO ZERO
  qCO2_REgj_ded.fX[purpose,energy19,r,tForecast] = 0;
  qEAFG_REgj_ded.fx[purpose,energy19,r,tForecast] = 0; #Måske burde finansiel sektor ikke få udfaset**
  #  LOOP(t$(tForecast[t]),
  #    qEAFG_REgj_ded.fx[purpose,energy19,'51001',t] = 0.95 * qEAFG_REgj_ded.l[purpose,energy19,'51001',t-1];
  #    );

#J-TERMS TO CAPTURE DATA ODDITIES ARE SET TO ZERO IN FORECAST
  jEmmProdE_dedETS.fx[r,tForecast]           = 0; 
  jtCO2_RE.fx[purpose,energy19,r,tForecast]  = 0;
  jtEAFG_RE.fx[purpose,energy19,r,tForecast] = 0;


#AD HOC SOLUTION FOR TAXES ON ELECTRICITY AND DISTRICT HEAT
  LOOP(t$tForecast[t],
   tCO2_REmarg.l[purpose,'district heat',r,t,emm_eq] = tCO2_REmarg.l[purpose,'district heat',r,t-1,emm_eq] -0.1*tCO2_REmarg.l[purpose,'district heat',r,t1,emm_eq]; 
   tCO2_CE.l[purpose,'district heat',t]              = tCO2_CE.l[purpose,'district heat',t-1] - 0.1*tCO2_CE.l[purpose,'district heat',t1];
  );

  tCO2_REmarg.l[purpose,'district heat',r,t,emm_eq]$(tForecast[t] and tCO2_REmarg.l[purpose,'district heat',r,t,emm_eq]<0) = 0;
  d1CO2_RE[purpose,'district heat',r,t]  = yes$(sum(emm_eq, tCO2_REmarg.l[purpose,'district heat',r,t,emm_eq])>0);
  d1CO2_REmarg[purpose,'district heat',r,t,emm_eq] = yes$(tCO2_REmarg.l[purpose,'district heat',r,t,emm_eq]>0);
  tCO2_CE.l[purpose,'district heat',t]$(tForecast[t] and tCO2_CE.l[purpose,'district heat',t]<0) = 0;     
  d1CO2_CE[purpose,'district heat',t]$(tCO2_CE.l[purpose,'district heat',t] <=0) = no;

# PSO tax phased out from 2022, but since we dont know the magnitude and sign we forecast the inbetween years with zero PSO
  tPSO_CE.l[purpose,energy19,t]$(t.val > tDataEnd.val) = 0; vtPSO_CE.l[purpose,energy19,t]$(t.val > tDataEnd.val) = 0;
  d1PSO_CE[purpose,energy19,t]$(tPSO_CE.l[purpose,energy19,t]=0) = no;
  tPSO_RE.l[purpose,energy19,r,t]$(t.val > tDataEnd.val) = 0; vtPSO_RE.l[purpose,energy19,r,t]$(t.val > tDataEnd.val) = 0;
  d1PSO_RE[purpose,energy19,r,t]$(tPSO_RE.l[purpose,energy19,r,t]=0) = no;
  tPSO_XE.l[purpose,energy19,t]$(t.val > tDataEnd.val) = 0; vtPSO_XE.l[purpose,energy19,t]$(t.val > tDataEnd.val) = 0;
  d1PSO_XE[purpose,energy19,t]$(tPSO_XE.l[purpose,energy19,t]=0) = no;

  #The export competing price is set to 
  pXF_ene.l['electricity',tForecast] = pXE.l['unspecified','electricity',tDataEnd]/(1 + tXE_.l['unspecified','electricity',tDataEnd]);


# Phasing out district heat towards 2030
  LOOP(t$tForecast[t],
   tEAFG_REmarg.l[purpose,'district heat',r,t]        = tEAFG_REmarg.l[purpose,'district heat',r,t-1] -0.1*tEAFG_REmarg.l[purpose,'district heat',r,t1]; 
   tEAFG_CE.l[purpose,'district heat',t]              = tEAFG_CE.l[purpose,'district heat',t-1] - 0.1*tEAFG_CE.l[purpose,'district heat',t1];
  );

  tEAFG_REmarg.l[purpose,'district heat',r,t]$(tForecast[t] and tEAFG_REmarg.l[purpose,'district heat',r,t]<0) = 0;
  d1EAFG_RE[purpose,'district heat',r,t]$(tEAFG_REmarg.l[purpose,'district heat',r,t]=0) = no;
  tEAFG_CE.l[purpose,'district heat',t]$(tForecast[t] and tEAFG_CE.l[purpose,'district heat',t]<0) = 0;     
  d1EAFG_CE[purpose,'district heat',t]$(tCO2_CE.l[purpose,'district heat',t] <=0) = no;

  tVAT_RE.l[purpose,energy19,r,t]$(tForecast[t] and tVAT_RE.l[purpose,energy19,r,t]>0.25) = 0.25;
  tVAT_CE.l[purpose,energy19,t]$(tForecast[t] and tVAT_CE.l[purpose,energy19,t]) = 0.25;
  
# =====================================================================================================================

  #INITIAL VALUES FOR MARGINAL TAX-RATE     
      $MODEL M_taxes_initial_values_marginal_tax_rates 
        E_tCO2_REmarg_GJ
        E_tCO2_REmarg_GJ_districtheat
        E_tCO2_ETS_GJ
        E_tCO2_ETS2_GJ
        E_tREmarg_market
        E_tREmarg_market_own      
        E_tREmarg_nonmarket
      ;

      $GROUP G_taxes_initial_values_marginal_tax_rates_exo 
        tCO2_ETS$(tx0[t])
        tCO2_ETS2$(tx0[t])
        tCO2_REmarg$(tx0[t] and d1CO2_REmarg[purpose,energy19,r,t,emm_eq])
        tEAFG_REmarg$(tx0[t] and d1EAFG_RE[purpose,energy19,r,t])
        tSO2_RE$(d1SO2_RE[purpose,energy19,r,t])
        tPSO_RE$(d1PSO_RE[purpose,energy19,r,t])
        tNOx_RE$(d1NOx_RE[purpose,energy19,r,t])
        pEAV_RE$(d1EAV_RE[purpose,energy19,r,t])
        pDAV_RE$(d1DAV_RE[purpose,energy19,r,t])
        pCAV_RE$(d1CAV_RE[purpose,energy19,r,t])
        tCALIBENS$(d1pREgj[purpose,energy19,r,t])
        pRE_base_marg$(tx0[t] and d1pRE_base[purpose,energy19,r,t])
        pREown$(tx0[t] and d1pREown[purpose,energy19,r,t])

        #tCO2_PJ equations
        uEmmProdE$(tx0[t] and sum(purpose, d1EmmProdE[s,t,emm,purpose,energy19]))
        uEOPProdE$(tx0[t] and d1EmmProdE[s,t,emm,purpose,energy19])
        sBioNatgas$(tx0[t]) # and sum(emm, d1EmmProdE[r,t,emm,purpose,'natural gas incl. biongas']))
      ;



      $GROUP G_taxes_initial_values_marginal_tax_rates_endo  
        tvREmarg$(tx0[t] and d1tRE[purpose,energy19,r,t] and d1pRE_base[purpose,energy19,r,t])
        tvREmarg$(tx0[t] and d1tRE[purpose,energy19,r,t] and d1pREown[purpose,energy19,r,t])
        tqREmarg$(tx0[t] and d1tRE[purpose,energy19,r,t] and not (d1pRE_base[purpose,energy19,r,t] or d1pREown[purpose,energy19,r,t]))
        tCO2_REmarg_GJ$(d1CO2_REmarg[purpose,energy19,r,t,emm_eq]) "Marginal CO2 tax, firms, bio. kroner per PJ (or equivalently 1000 kroner per GJ)"
        tCO2_ETS_GJ$(d1tCO2_ETS_marg[purpose,energy19,r,t])               "Marginal ETS-price, firms, bio. kroner per PJ (or equivalently 1000 kroner per GJ)"
        tCO2_ETS2_GJ$(d1CO2_ETS2_marg[purpose,energy19,r,t])             "Marginal ETS-price, firms, bio. kroner per PJ (or equivalently 1000 kroner per GJ)"
      ;
      
$ENDIF