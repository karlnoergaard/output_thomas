 

Parameter
	data_eTeknisk_SKM[GSR_ag]
  data_eStruktur_SKM[GSR_ag]
	eTeknisk_SKM[purpose,energy19a,s,emm]
	d1TekniskSKM[purpose,energy19a,s,t,emm_eq]
  eTekniskSKMxE[s,emm]
  d1TekniskSKMxE[s,t,emm_eq]
;

d1TekniskSKM[purpose,energy19a,s,t,emm_eq]  = no;
d1TekniskSKMxE[s,t,emm_eq]                  = no;

$GROUP G_TekniskEffekt_SKM_endo
  # Energy related technical effects
  uEOPProdE_CCS[purpose,energy19,s,t,emm]$(tx0[t] and sum(techCCS, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])) ""
  uEOPProdE_SKM[purpose,energy19,s,t,emm]$(tx0[t] and d1TekniskSKM[purpose,energy19,s,t,emm]) "Reduktion af emissionskoefficient baseret på SKM's elasticiteter"
  uEOPProdE[purpose,energy19,s,t,emm]$(tx0[t] and (sum(techCCS, d1thetaCCS[techCCS,purpose,energy19,s,t,emm]) or d1TekniskSKM[purpose,energy19,s,t,emm]))
  qEmmSKM_teknisk[s,t,emm_eq,purpose,energy19]$(tx0[t] and d1TekniskSKM[purpose,energy19,s,t,emm_eq]) ""
  vCostSKM_teknisk[purpose,energy19,s,t]$(tx0[t] and sum(emm, d1TekniskSKM[purpose,energy19,s,t,emm])) ""
  pCostSKM_teknisk[purpose,energy19a,s,t]$(tx0[t] and sum(emm, d1TekniskSKM[purpose,energy19a,s,t,emm]) and d1pREa[purpose,energy19a,s,t]) ""
  qI_SKM_actual[i,sp,t]$(tx0[t] and sameas[i,'iM'] and sum(purpose, sum(energy19, sum(emm, d1TekniskSKM[purpose,energy19,sp,t,emm])))) ""
  j_pREa$(tx0[t] and d1pREa[purpose,energy19a,s,t] and (sum(techID, d1thetaID_k[techID,purpose,energy19a,s,t]) or sum(techCCS, sum(emm, d1thetaCCS[techCCS,purpose,energy19a,s,t,emm])) or sum(energy19,d1vREE_transport[purpose,energy19a,energy19,s,t]) or sum(emm, d1TekniskSKM[purpose,energy19a,s,t,emm])))
  qGrossEmmE_tot[s,t,emm,purpose,energy19]$(tx0[t] and d1EmmProdE[s,t,emm,purpose,energy19] and (sameas[emm,'CO2ubio'] or sameas[emm,'CO2bio'])) ""
  #  qGrossEmmE_SKM[s,t,emm,purpose,energy19a]$(tx0[t])
  # Non-energy related technical effects
  uEOPProdxE_CCS[s,t,emm]$(tx0[t] and sum(techCCS, d1thetaCCSxE[techCCS,s,t,emm])) ""
  uEOPProdxE_SKM[s,t,emm]$(tx0[t] and d1TekniskSKMxE[s,t,emm]) ""
  uEOPProdxE[s,t,emm]$(tx0[t] and (sum(techCCS, d1thetaCCSxE[techCCS,s,t,emm]) or d1TekniskSKMxE[s,t,emm]))
  qGrossEmmxE_tot[s,t,emm]$(tx0[t] and d1EmmProdxE[s,t,emm] and (sum(techCCS, d1thetaCCSxE[techCCS,s,t,emm]) or d1TekniskSKMxE[s,t,emm])) ""
  qEmmxESKM_teknisk[s,t,emm]$(tx0[t] and d1TekniskSKMxE[s,t,emm]) ""
  vCostxESKM_teknisk[s,t]$(tx0[t] and sum(emm, d1TekniskSKMxE[s,t,emm])) ""
  qIxE_SKM_actual[i,sp,t]$(tx0[t] and sameas[i,'iM'] and sum(emm, d1TekniskSKMxE[sp,t,emm])) "Investments needed for non-energy related technical effects"
;

$GROUP G_TekniskEffekt_SKM_exo
  tCO2_SKM[purpose,energy19a,s,t,emm]$(tx0[t] and d1TekniskSKM[purpose,energy19a,s,t,emm]) ""
  uEOPProdE_CCS[purpose,energy19,s,t,emm]$(tx0[t] and d1EmmProdE[s,t,emm,purpose,energy19] and (sameas[emm,'CO2ubio'] or sameas[emm,'CO2bio']))
  uEOPProdE_SKM[purpose,energy19,s,t,emm]$(tx0[t] and sum(techCCS, d1thetaCCS[techCCS,purpose,energy19,s,t,emm]))
  tCO2_REmarg_baseline[purpose,energy19,r,t,emm_eq]$(tx0[t] and d1TekniskSKM[purpose,energy19,r,t,emm_eq])

  tCO2xE_SKM[s,t,emm]$(tx0[t] and d1TekniskSKMxE[s,t,emm]) ""
  uEOPProdxE_CCS[s,t,emm]$(tx0[t] and d1TekniskSKMxE[s,t,emm])
  uEOPProdxE_SKM[s,t,emm]$(tx0[t] and sum(techCCS, d1thetaCCSxE[techCCS,s,t,emm]))
  tCO2_ProdxE_baseline[s,t,emm]$(tx0[t] and d1TekniskSKMxE[s,t,emm])
  ;

$BLOCK B_TekniskEffekt_SKM

# --------------------------------------------------------------------------------------------------
# Energy related technical effects
# --------------------------------------------------------------------------------------------------

### EMISSIONS ###

# Update emission coefficients:
  E_uEOPProdE_CCS[purpose,energy19,s,t,emm]$(tx0[t] and sum(techCCS, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])).. 
    uEOPProdE_CCS[purpose,energy19,s,t,emm] =E= 1-sum(techCCS$(d1thetaCCS[techCCS,purpose,energy19,s,t,emm]), rCCS_actual[techCCS,purpose,energy19,s,t,emm]*thetaCCS[techCCS,purpose,energy19,s,t,emm]);

  E_uEOPProdE_SKM[purpose,energy19,s,t,emm]$(tx0[t] and d1TekniskSKM[purpose,energy19,s,t,emm]).. 
    uEOPProdE_SKM[purpose,energy19,s,t,emm] =E= exp(-eTeknisk_SKM[purpose,energy19,s,emm]*tCO2_SKM[purpose,energy19,s,t,emm]/100);

  # New equation for uEOPProdE
  E_uEOPProdE_tot[purpose,energy19,s,t,emm]$(tx0[t] and (sum(techCCS, d1thetaCCS[techCCS,purpose,energy19,s,t,emm]) or d1TekniskSKM[purpose,energy19,s,t,emm])).. 
    uEOPProdE[purpose,energy19,s,t,emm] =E= uEOPProdE_CCS[purpose,energy19,s,t,emm]*uEOPProdE_SKM[purpose,energy19,s,t,emm];

# Gross emissions (Change in qGrossEmmE to properly account for CCS)

  # Total energy related emissions (excl. CCS and technical effects)
  E_qGrossEmmE_tot[s,t,emm,purpose,energy19]$(tx0[t] and d1EmmProdE[s,t,emm,purpose,energy19] and (sameas[emm,'CO2ubio'] or sameas[emm,'CO2bio']))..
    qGrossEmmE_tot[s,t,emm,purpose,energy19] =E= qEmmProdE[s,t,emm,purpose,energy19]/uEOPProdE[purpose,energy19,s,t,emm];

  # Total energy related emissions (excl. CCS)
  E_qGrossEmmE_alt[s,t,emm,purpose,energy19]$(tx0[t] and d1EmmProdE[s,t,emm,purpose,energy19] and (sameas[emm,'CO2ubio'] or sameas[emm,'CO2bio']))..
    qGrossEmmE[s,t,emm,purpose,energy19] =E= qEmmProdE[s,t,emm,purpose,energy19]/uEOPProdE_CCS[purpose,energy19,s,t,emm];

# Emissions reduction from technical effects 
  E_qEmmSKM_teknisk[s,t,emm,purpose,energy19]$(tx0[t] and d1TekniskSKM[purpose,energy19,s,t,emm]).. 
    qEmmSKM_teknisk[s,t,emm,purpose,energy19] =E= qGrossEmmE_tot[s,t,emm,purpose,energy19] - qGrossEmmE_tot[s,t,emm,purpose,energy19]*uEOPProdE_SKM[purpose,energy19,s,t,emm];

  #  E_qEmmSKM_teknisk_CO2e[s,t,purpose,energy19]$(tx0[t] and d1TekniskSKM[purpose,energy19,s,t,'CO2e']).. 
  #    qEmmSKM_teknisk[s,t,'CO2e',purpose,energy19] =E= sum(emm$(d1TekniskSKM[purpose,energy19,s,t,emm]), qEmmSKM_teknisk[s,t,emm,purpose,energy19]*GWP[emm]);

### TECHNICAL COSTS ###

  # Total costs techical change
  E_vCostSKM_teknisk[purpose,energy19,s,t]$(tx0[t] and sum(emm, d1TekniskSKM[purpose,energy19,s,t,emm]))..
    vCostSKM_teknisk[purpose,energy19,s,t] =E= sum(emm$(d1TekniskSKM[purpose,energy19,s,t,emm]), qEmmSKM_teknisk[s,t,emm,purpose,energy19]*growth_factor[t]
                                                * (tCO2_REmarg_baseline[purpose,energy19,s,t,emm] 
                                                  + tCO2_ETS[t]$(d1tCO2_ETS_marg[purpose,energy19,s,t])
                                                  + tCO2_ETS2[t]$(d1CO2_ETS2_marg[purpose,energy19,s,t])
                                                  + tCO2_SKM[purpose,energy19,s,t,emm]/2))
                                                * (10**(-6));

  # Cost pr. energy use
  E_pCostSKM_teknisk[purpose,energy19a,s,t]$(tx0[t] and sum(emm, d1TekniskSKM[purpose,energy19a,s,t,emm]) and d1pREa[purpose,energy19a,s,t])..
   pCostSKM_teknisk[purpose,energy19a,s,t] =E= vCostSKM_teknisk[purpose,energy19a,s,t] / qREa[purpose,energy19a,s,t];

  #   CES price of energy activities:
  E_j_pREa_swap_SKM[purpose,energy19a,s,t]$(tx0[t] and d1pREa[purpose,energy19a,s,t] and (sum(techID, d1thetaID_k[techID,purpose,energy19a,s,t]) or sum((techCCS,emm), d1thetaCCS[techCCS,purpose,energy19a,s,t,emm]) or sum(emm, d1TekniskSKM[purpose,energy19a,s,t,emm]))).. 
    pREa[purpose,energy19a,s,t] =E= 
    #Energy costs:
    sum(energy19$(sum(techID, d1thetaID[techID,purpose,energy19a,energy19,s,t])), uREE[purpose,energy19a,energy19,s,t]*pREgj[purpose,energy19,s,t])
    #Capital costs from ID:
    + sum(techID$(d1thetaID_k[techID,purpose,energy19a,s,t]), rID_actual[techID,purpose,energy19a,s,t] * thetaID_KMean[techID,purpose,energy19a,s,t]
        * sum(energy19$(d1thetaID[techID,purpose,energy19a,energy19,s,t] and sameas(energy19,energy19a)),-thetaID[techID,purpose,energy19a,energy19,s,t]) 
        * pI_s['iM',s,t])
    # Energy costs in absence of ID-abatement
    + pREgj[purpose,energy19a,s,t]$((sum((techCCS,emm), d1thetaCCS[techCCS,purpose,energy19a,s,t,emm]) or sum(emm, d1TekniskSKM[purpose,energy19a,s,t,emm])) and not sum((techID,energy19), d1thetaID[techID,purpose,energy19a,energy19,s,t]))
    #Capital costs from CCS:
    + pCCS_qRE[s,energy19a,purpose,t]$(sum((techCCS,emm), d1thetaCCS[techCCS,purpose,energy19a,s,t,emm]))
    # Capital costs from SKM technical effects
    + pCostSKM_teknisk[purpose,energy19a,s,t]$(sum(emm, d1TekniskSKM[purpose,energy19a,s,t,emm]));

  E_pREa_swap_SKM[purpose,energy19a,sp,t]$(tx0[t] and d1pREa[purpose,energy19a,sp,t]).. 
    pREa[purpose,energy19a,sp,t] =E= pREgj[purpose,energy19a,sp,t]$(d1pREgj[purpose,energy19a,sp,t]) 
                                  + j_pREa[purpose,energy19a,sp,t]$(sum(techID, d1thetaID_k[techID,purpose,energy19a,sp,t]) or sum((techCCS,emm), d1thetaCCS[techCCS,purpose,energy19a,sp,t,emm]) or sum(energy19,d1vREE_transport[purpose,energy19a,energy19,sp,t]) or sum(emm, d1TekniskSKM[purpose,energy19a,sp,t,emm]));

  E_pREa_off_swap_SKM[purpose,energy19a,t]$(tx0[t] and d1pREa[purpose,energy19a,'off',t]).. 
    pREa[purpose,energy19a,'off',t] =E= pREgj[purpose,energy19a,'off',t]$(d1pREgj[purpose,energy19a,'off',t]) 
                                  + j_pREa[purpose,energy19a,'off',t]$(sum(techID, d1thetaID_k[techID,purpose,energy19a,'off',t]) or sum((techCCS,emm), d1thetaCCS[techCCS,purpose,energy19a,'off',t,emm]) or sum(energy19,d1vREE_transport[purpose,energy19a,energy19,'off',t]) or sum(emm, d1TekniskSKM[purpose,energy19a,'off',t,emm]));

### TECHNICAL INVESTMENTS ###

  E_qI_SKM_actual[sp,t]$(tx0[t] and sum((purpose,energy19,emm), d1TekniskSKM[purpose,energy19,sp,t,emm]))..
    qI_SKM_actual['iM',sp,t] =E= sum((purpose,energy19)$(sum(emm, d1TekniskSKM[purpose,energy19,sp,t,emm])), vCostSKM_teknisk[purpose,energy19,sp,t] / pI_s['iM',sp,t]);

 
# --------------------------------------------------------------------------------------------------
# Non-Energy related technical effects
# --------------------------------------------------------------------------------------------------

### EMISSIONS ###

  E_uEOPProdxE_CCS[s,t,emm]$(tx0[t] and sum(techCCS, d1thetaCCSxE[techCCS,s,t,emm])).. 
    uEOPProdxE_CCS[s,t,emm] =E= 1-sum(techCCS$(d1thetaCCSxE[techCCS,s,t,emm]), rCCSxE_actual[techCCS,s,t,emm]*thetaCCSxE[techCCS,s,t,emm]);

  E_uEOPProdxE_SKM[s,t,emm]$(tx0[t] and d1TekniskSKMxE[s,t,emm]).. 
    uEOPProdxE_SKM[s,t,emm] =E= exp(-eTekniskSKMxE[s,emm]*tCO2xE_SKM[s,t,emm]/100);

  E_uEOPProdxE_tot[s,t,emm]$(tx0[t] and (sum(techCCS, d1thetaCCSxE[techCCS,s,t,emm]) or d1TekniskSKMxE[s,t,emm])).. 
    uEOPProdxE[s,t,emm] =E= uEOPProdxE_CCS[s,t,emm]*uEOPProdxE_SKM[s,t,emm];

# Gross emissions (Change in qGrossEmmxE to properly account for CCS)

  # Total non-energy related emissions (excl. CCS and technical effects)
  E_qGrossEmmxE_tot[s,t,emm]$(tx0[t] and d1EmmProdxE[s,t,emm] and (sum(techCCS, d1thetaCCSxE[techCCS,s,t,emm]) or d1TekniskSKMxE[s,t,emm]))..
    qGrossEmmxE_tot[s,t,emm] =E= qEmmProdxE[s,t,emm]/uEOPProdxE[s,t,emm];

  # Total non-energy related emissions (excl. CCS)
  E_qGrossEmmxE_alt[s,t,emm]$(tx0[t] and d1EmmProdxE[s,t,emm] and sum(techCCS, d1thetaCCSxE[techCCS,s,t,emm]))..
    qGrossEmmxE[s,t,emm] =E= qEmmProdxE[s,t,emm]/uEOPProdxE_CCS[s,t,emm];

# Emissions reduction from technical effects 
  E_qEmmxESKM_teknisk[s,t,emm]$(tx0[t] and d1TekniskSKMxE[s,t,emm]).. 
    qEmmxESKM_teknisk[s,t,emm] =E= qGrossEmmxE_tot[s,t,emm] - qGrossEmmxE_tot[s,t,emm]*uEOPProdxE_SKM[s,t,emm];

### TECHNICAL COSTS ###

  # Total costs techical change
  E_vCostxESKM_teknisk[s,t]$(tx0[t] and sum(emm, d1TekniskSKMxE[s,t,emm]))..
    vCostxESKM_teknisk[s,t] =E= sum(emm$(d1TekniskSKMxE[s,t,emm]), qEmmxESKM_teknisk[s,t,emm]*growth_factor[t]
                                                * (tCO2_ProdxE_baseline[s,t,emm] 
                                                  + tCO2_ETS[t]$(d1EmmProdxE[s,t,emm] and  d1CO2_ETS[s,t])
                                                  + tCO2xE_SKM[s,t,emm]/2))
                                                * (10**(-6));

  # Tilføjelse af (ikke-energirelaterede) tekniske omkostninger til produktionsomkostninger
  $LOOP00 E_pY0:
      {name}_swap_SKM{sets}${subsets}..      {LHS} =E= {RHS} 
                                                + vCostxESKM_teknisk[sp,t]$(sum(emm, d1TekniskSKMxE[sp,t,emm]))
                                                ;
  $ENDLOOP00

  $LOOP00 E_vEBITDA:
      {name}_SKM{sets}${subsets}..      {LHS} =E= {RHS} 
                                                - vCostxESKM_teknisk[sp,t]$(sum(emm, d1TekniskSKMxE[sp,t,emm]))
                                                ;
  $ENDLOOP00


#  ### TECHNICAL INVESTMENTS ###

  E_qIxE_SKM_actual[sp,t]$(tx0[t] and sum(emm, d1TekniskSKMxE[sp,t,emm]))..
    qIxE_SKM_actual['iM',sp,t] =E= sum((purpose,energy19)$(sum(emm, d1TekniskSKM[purpose,energy19,sp,t,emm])), vCostSKM_teknisk[purpose,energy19,sp,t] / pI_s['iM',sp,t]);

# --------------------------------------------------------------------------------------------------
# Joint equations for technical effects
# --------------------------------------------------------------------------------------------------

  # Tilføjelse af tekniske omkostninger til aggregerede investeringer
  $LOOP00 E_qI:
      {name}_SKM{sets}${subsets}..      {LHS} =E= {RHS} 
                                                + sum(sp$(d1I_s[i,sp,t-1] and sum((purpose,energy19,emm), d1TekniskSKM[purpose,energy19,sp,t,emm])), (qI_SKM_actual['iM',sp,t]*pI_s['iM',sp,t-1]))$(sameas[i,'iM'])
                                                + sum(sp$(d1I_s[i,sp,t-1] and sum(emm, d1TekniskSKMxE[sp,t,emm])), (qIxE_SKM_actual['iM',sp,t]*pI_s['iM',sp,t-1]))$(sameas[i,'iM'])
                                                ;
  $ENDLOOP00

$ENDBLOCK
	 

   # Elasticiteter fra SKM
   data_eTeknisk_SKM['proces_ETS'] 													= 0.087; #0.0732; # LBS: Struktureffekten er for lav i modellen ift. SKM
   data_eTeknisk_SKM['proces_non_ETS'] 											= 0.095; #0.0732; # LBS: Struktureffekten er for lav i modellen ift. SKM
   data_eTeknisk_SKM['LandOgSkov'] 													= 0.0732;
   data_eTeknisk_SKM['LandOgSkov_diesel'] 									= 0.0176;
   data_eTeknisk_SKM['LandOgSkov_gartneri_ETS'] 						= 0.073;
   data_eTeknisk_SKM['LandOgSkov_gartneri_non_ETS'] 				= 0.073;
   data_eTeknisk_SKM['Mineralogi_cement'] 									= 0.072;
   data_eTeknisk_SKM['Mineralogi_oevrig'] 									= 0.037;
   data_eTeknisk_SKM['Mineralogi_oevrig_notETS']            = 0.037;
   data_eTeknisk_SKM['Nordsoeen'] 													= 0.0398;
   data_eTeknisk_SKM['Raffinaderier'] 											= 0.0476;
   data_eTeknisk_SKM['Fiskeri'] 														= 0.0296;
   data_eTeknisk_SKM['Indenrigssoefart'] 										= 0.0293;
   data_eTeknisk_SKM['Jernbane'] 														= 0.0222;
   #  data_eTeknisk_SKM['Alm_elforbrug'] 											= 0.0225;
   data_eTeknisk_SKM['Indenrigsflyvninger'] 								= 0.0145;

   # Skal have rigtige elasticiteter senere
   #  data_eTeknisk_SKM['Vejtransport'] 												= 0.0222;
   #  data_eTeknisk_SKM['OevrigTransport'] 										= 0.0222;
   #  data_eTeknisk_SKM['intern_trans'] 												= 0.0222;
   data_eTeknisk_SKM['BraendslertilElOgFjernvarme_ETS'] 		= 0.0225; 
   data_eTeknisk_SKM['BraendslertilElOgFjernvarme_notETS'] 	= 0.0225; 
   #  data_eTeknisk_SKM['DataCentre'] 													= 0.0222;
   #  data_eTeknisk_SKM['notinGSR'] 														= 0.0222;
   #  data_eTeknisk_SKM['notinGSR_ETS'] 												= 0.0222;
   #  data_eTeknisk_SKM['Rumvarme'] 														= 0.0222;

  eTeknisk_SKM[purpose,energy19a,s,'CO2ubio']$(sum(t, d1EmmProdE[s,t,'CO2ubio',purpose, energy19a]))
        = sum(GSR_ag$(mapGrREFORM2GSR[purpose,energy19a,s,GSR_ag,'2030']), data_eTeknisk_SKM[GSR_ag]);

  d1TekniskSKM[purpose,energy19a,s,t,emm] = no;  
  d1TekniskSKM[purpose,energy19a,s,t,'CO2ubio'] = yes$(eTeknisk_SKM[purpose,energy19a,s,'CO2ubio'] and d1EmmProdE[s,t,'CO2ubio',purpose, energy19a]);
  # LBS: Skal der være teknisk effekt på CO2bio fra naturgas?
  #  d1TekniskSKM[purpose,'Natural gas incl. biongas',s,t,'CO2bio'] = yes$(eTeknisk_SKM[purpose,'Natural gas incl. biongas',s,'CO2bio'] and d1EmmProdE[s,t,'CO2bio',purpose, 'Natural gas incl. biongas']);
  d1TekniskSKM[purpose,energy19a,s,t,'CO2e'] = yes$(eTeknisk_SKM[purpose,energy19a,s,'CO2ubio'] and d1EmmProdE[s,t,'CO2e',purpose, energy19a]);

  # Der er ingen pris på waste oil
  d1TekniskSKM[purpose,energy19a,s,t,emm_eq]$(sameas[energy19a,'Waste oil']) = no;
  # Aalborg Portland antages ikke at få afgiften på grund af CCS
  d1TekniskSKM[purpose,energy19a,s,t,emm_eq]$(sameas[s,'23001']) = no;

  # Non-energy related technical effects
  eTekniskSKMxE[s,'CO2ubio']$(sum(energy19, sENS2GR['OevrigMineralogi', 'Mineralogi_oevrig', 'in_ETS',energy19,s]) and sum(t, d1EmmProdxE[s,t,'CO2ubio'])) = eTeknisk_SKM['in_ETS','Oil products',s,'CO2ubio'];
  d1TekniskSKMxE[s,t,emm]       = no;
  d1TekniskSKMxE[s,t,'CO2ubio'] = yes$(eTekniskSKMxE[s,'CO2ubio'] and d1EmmProdxE[s,t,'CO2ubio']);

  # INITIALISATION
  tCO2_SKM.l[purpose,energy19,s,t,emm]$(tx0[t] and d1TekniskSKM[purpose,energy19,s,t,emm])  = 0;
  tCO2xE_SKM.l[s,t,emm]$(tx0[t] and d1TekniskSKMxE[s,t,emm])                                = 0;

  uEOPProdE_SKM.l[purpose,energy19,s,t,emm]$(tx0[t] and (sum(techCCS, d1thetaCCS[techCCS,purpose,energy19,s,t,emm]) or d1TekniskSKM[purpose,energy19,s,t,emm])) = 1;
  uEOPProdE_CCS.l[purpose,energy19,s,t,emm]$(tx0[t] and d1EmmProdE[s,t,emm,purpose,energy19] and (sameas[emm,'CO2ubio'] or sameas[emm,'CO2bio'])) = 1;

  uEOPProdxE_CCS.l[s,t,emm]$(tx0[t] and (sum(techCCS, d1thetaCCSxE[techCCS,s,t,emm]) or d1TekniskSKMxE[s,t,emm])) = 1;
  uEOPProdxE_SKM.l[s,t,emm]$(tx0[t] and (sum(techCCS, d1thetaCCSxE[techCCS,s,t,emm]) or d1TekniskSKMxE[s,t,emm])) = 1;

# Struktureffekter på industri (SKM)
   data_eStruktur_SKM['proces_ETS']                       = 0.0275;
   data_eStruktur_SKM['proces_non_ETS']                   = 0.0275;
   data_eStruktur_SKM['LandOgSkov']                       = 0.0275;
   data_eStruktur_SKM['LandOgSkov_diesel']                = 0.0;
   data_eStruktur_SKM['LandOgSkov_gartneri_ETS']          = 0.027;
   data_eStruktur_SKM['LandOgSkov_gartneri_non_ETS']      = 0.027; #LBS antagelse
   data_eStruktur_SKM['Mineralogi_cement']                = 0.515;
   data_eStruktur_SKM['Mineralogi_oevrig']                = 0.092;
   #  data_eStruktur_SKM['Mineralogisk_oevrige_nonETS'] = 0.092;
   data_eStruktur_SKM['Nordsoeen']                        = 0.0057;
   data_eStruktur_SKM['Raffinaderier']                    = 0.0999;
   data_eStruktur_SKM['Fiskeri']                          = 0.0592;
   data_eStruktur_SKM['Indenrigssoefart']                 = 0.0211;
   data_eStruktur_SKM['Jernbane']                         = 0.0;
   data_eStruktur_SKM['BraendslertilElOgFjernvarme_ETS']    = 0.0225;
   data_eStruktur_SKM['BraendslertilElOgFjernvarme_notETS'] = 0.0225;
   data_eStruktur_SKM['Indenrigsflyvninger']              = 0.0145;


#  execute_unload 'Output\teknisk_SKM.gdx';