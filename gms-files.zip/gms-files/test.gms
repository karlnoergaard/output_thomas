 #  ----------------------------------------------------------------------------------------------------------------------
 #  Testing Abatement 1,2,3
 #  ----------------------------------------------------------------------------------------------------------------------
 


#  d1thetaID_k['t1','process_normal','diesel for transport','03000',t]             = yes;
#  d1thetaID['t1','process_normal','diesel for transport','Bunkering of Danish operated vessels on foreign territory','03000',t]  = yes;
#  d1thetaID['t1','process_normal','diesel for transport','diesel for transport','03000',t]   = yes;

#  thetaID.l['t1','process_normal','diesel for transport','Bunkering of Danish operated vessels on foreign territory','03000',t]  = 0.5;
#  thetaID.l['t1','process_normal','diesel for transport','diesel for transport','03000',t]   = -0.5;

#  #  rID_actual['t1','process_normal','diesel for transport','03000',t] = 1;

#  #  -E_rID_actual$(sameas[techID,'t1'])

#  $MODEL M_testaba 
#    E_rID_input
#    E_rID
#    #  E_rID_preferred
#    #  E_rID_preferred_terminal_condition
#    #  E_uREE
#    #  E_rID_actual
#  ;


#  $FIX G_exo;
#  @SOLVE(M_testaba);
#  execute_unload 'output\test.gdx';


      set elementary/pV2_ha, pHV2_ha, pFireH_ha, pFireV_ha, pHoved_tot_ha, pTynd_tot_ha/;
      set head2head/Hoved,tynd/;

      $PGROUP PG_ReportSkov 
                       Report_pI_FRF_perha_firstgen[joe07,spec_type,t], 
                       Report_pV2_firstgen[joe07,spec_type,t], 
                       Report_pHV2_firstgen[joe07,spec_type,t], 
                       Report_qV2_tynd_FRF_firstgen[joe07,spec_type,t], 
                       Report_qV2_hoved_FRF_firstgen[joe07,spec_type,t],
                       Report_vV2_tynd_FRF_firstgen[joe07,spec_type,t],
                       Report_pV_total_firstgen[joe07,spec_type,t]
                       ReportSurv_diff[joe07,spec_type,acl,t], 
                       Report_Surf_diff_firstgen[joe07,spec_type,t],
                       Report_pFirewoodHoved_firstgen[joe07,spec_type,t], 
                       Report_pFirewoodTynd_firstgen[joe07,spec_type,t], 
                       Report_pTynd_tot_firtsgen[joe07,spec_type,t],
                       Report_pHoved_tot_firstgen[joe07,spec_type,t],
                       Report_PricesFirstgen[elementary,joe07,spec_type,t],
                       Report_NPV[t]
                       Report_pPerha[head2head,joe07,spec_type,acl,t] ""
                       ;
      $PGROUP PG_ReportSkov_diff 
        $LOOP PG_ReportSkov:
        Diff_{name}{sets} 
        $ENDLOOP
      ;



      $FUNCTION reportskov({mode}):
      Report_pI_FRF_perha_firstgen[joe07,spec_type,t]$(sameas[spec_type,'B'])     = sum((ite,acl)$(ite2t(ite,t) and firstgen(ite,acl)), pI_FRF_perha.l[joe07,spec_type,acl,t]);
      Report_pV2_firstgen[joe07,spec_type,t]$(sameas[spec_type,'B'])              = sum((ite,acl)$(ite2t(ite,t) and firstgen(ite,acl)), pV2_tynd_FRF_perha.l[joe07,spec_type,acl,t]);
      Report_pHV2_firstgen[joe07,spec_type,t]$(sameas[spec_type,'B'])             = sum((ite,acl)$(ite2t(ite,t) and firstgen(ite,acl)), pHV2_hoved_FRF_perha.l[joe07,spec_type,acl,t]);
      Report_qV2_tynd_FRF_firstgen[joe07,spec_type,t]$(sameas[spec_type,'B'])     = sum((ite,acl)$(ite2t(ite,t) and firstgen(ite,acl)), qV2_tynd_FRF.l[joe07,spec_type,acl,t]); #Der er en mængde 
      Report_qV2_hoved_FRF_firstgen[joe07,spec_type,t]$(sameas[spec_type,'B'])    = sum((ite,acl)$(ite2t(ite,t) and firstgen(ite,acl)), qHV2_hoved_FRF.l[joe07,spec_type,acl,t]); #Der er en mængde 
      
      Report_vV2_tynd_FRF_firstgen[joe07,spec_type,t]$(sameas[spec_type,'B'])     = sum((ite,acl)$(ite2t(ite,t) and firstgen(ite,acl)), vV2_tynd_FRF.l[joe07,spec_type,acl,t]); #Men ingen værdi
      Report_pV_total_firstgen[joe07,spec_type,t]$(sameas[spec_type,'B'])         = Report_pV2_firstgen[joe07,spec_type,t] + Report_pHV2_firstgen[joe07,spec_type,t];
      ReportSurv_diff[joe07,spec_type,acl,t]$(pSurv.l[joe07,spec_type,acl,t] <> pSurvival.l[joe07,spec_type,acl] and t.val>2016) = pSurv.l[joe07,spec_type,acl,t] - pSurvival.l[joe07,spec_type,acl];
      Report_pFirewoodHoved_firstgen[joe07,spec_type,t]$(sameas[spec_type,'B'])   = sum((ite,acl)$(ite2t(ite,t) and firstgen(ite,acl)), pHoved_Firewood_perha.l[joe07,spec_type,acl,t]);
      Report_pFirewoodTynd_firstgen[joe07,spec_type,t]$(sameas[spec_type,'B'])    = sum((ite,acl)$(ite2t(ite,t) and firstgen(ite,acl)), pTynd_firewood_perha.l[joe07,spec_type,acl,t]);
      Report_pTynd_tot_firtsgen[joe07,spec_type,t]$(sameas[spec_type,'B'])        = sum((ite,acl)$(ite2t(ite,t) and firstgen(ite,acl)), pPerHa_tynd_tot.l[joe07,spec_type,acl,t]);
      Report_pHoved_tot_firstgen[joe07,spec_type,t]$(sameas[spec_type,'B'])       = sum((ite,acl)$(ite2t(ite,t) and firstgen(ite,acl)), pPerHa_hoved_tot.l[joe07,spec_type,acl,t]);

      Report_PricesFirstgen['pV2_ha',joe07,spec_type,t] = Report_pV2_firstgen[joe07,spec_type,t];
      Report_PricesFirstgen['pHV2_ha',joe07,spec_type,t] = Report_pHV2_firstgen[joe07,spec_type,t];
      Report_PricesFirstgen['pFireH_ha',joe07,spec_type,t] = Report_pFirewoodHoved_firstgen[joe07,spec_type,t];
      Report_PricesFirstgen['pFireV_ha',joe07,spec_type,t] = Report_pFirewoodTynd_firstgen[joe07,spec_type,t];
      Report_PricesFirstgen['pTynd_tot_ha',joe07,spec_type,t] = Report_pTynd_tot_firtsgen[joe07,spec_type,t];
      Report_PricesFirstgen['pHoved_tot_ha',joe07,spec_type,t] = Report_pHoved_tot_firstgen[joe07,spec_type,t];
      
      Report_Surf_diff_firstgen[joe07,spec_type,t] = sum((ite,acl)$(ite2t(ite,t) and firstgen(ite,acl)), ReportSurv_diff[joe07,spec_type,acl,t]);

      Report_NPV[t] = sum(acl, pI_FRF_perha.l['islands','B',acl,t]*qF5_FRF.l['islands','B',acl,t]) 
                    + sum(acl, vHoved_Firewood.l['islands','B',acl,t]) 
                    + sum(acl, vTynd_firewood.l['islands','B',acl,t]) 
                    + sum(acl, vHV2_hoved_FRF.l['islands','B',acl,t])
                    + sum(acl, vV2_tynd_FRF.l['islands','B',acl,t])
                    ;


      $IF '{mode}'=='base':
        $LOOP PG_ReportSkov:
          Diff_{name}{sets}= {name}{sets};
        $ENDLOOP
      $ENDIF 

      $IF '{mode}'=='shoc':
        $LOOP PG_ReportSkov:
          Diff_{name}{sets} = {name}{sets} - Diff_{name}{sets};
        $ENDLOOP
      $ENDIF

      $ENDFUNCTION

 #  ----------------------------------------------------------------------------------------------------------------------
 #  Testing 1,2,3
 #  ----------------------------------------------------------------------------------------------------------------------


    #SETTINGS !!!!!!!!!!

      PARAMETER d1Endoprice, d1OnlyFirstgen, scaleprices;
      d1Endoprice = yes;
      d1OnlyFirstgen = no;
      $SETGLOBAL flatdemandforecast 0
      scaleprices = 1000; #Try to get better scaling.



    #VARIABLES
      $GROUP G_newage 
        pHV2_hoved_FRF_perha[joe07,spec_type,acl,t]
        pV2_tynd_FRF_perha[joe07,spec_type,acl,t]
        pSurv[joe07,spec_type,acl,t]
        pSurv_inp[joe07,spec_type,acl,t]
        eLasticityMan 
        sqHV2_hoved_FRF[joe07,spec_type,acl,t]
        sqV2_tynd_FRF[joe07,spec_type,acl,t]

        pI_FRF_perha[joe07,spec_type,acl,t] ""

        vHoved_Firewood[joe07,spec_type,acl,t] ""
        pHoved_Firewood_perha[joe07,spec_type,acl,t] ""
        pFirewood[t]  ""
        qPJ5_hoved[joe07,spec_type,acl,t] ""
        vTynd_firewood[joe07,spec_type,acl,t] ""
        pTynd_firewood_perha[joe07,spec_type,acl,t] ""
        pFirewood[t] ""
        qPJ5_tynd[joe07,spec_type,acl,t] ""

        rDiskForest
        qS_firewood[t] ""
        sFireWood[t] ""
        eFirewood ""
        jSurv_inp[joe07,spec_type,acl,t] ""

        pPerHa_hoved_tot[joe07,spec_type,acl,t] ""
        pPerHa_tynd_tot[joe07,spec_type,acl,t] ""
      ;

      $GROUP G_levelsusedasdummies
        vHV2_hoved_FRF
        vV2_tynd_FRF
        qPJ5_hoved
        qPJ5_tynd
      ;

      $PGROUP PG_levelsusedasdummies
       $LOOP G_levelsusedasdummies:
        d1{name}{sets}
       $ENDLOOP
      ; 


      $GROUP G_newage_exo 
        pSurv[joe07,spec_type,acl,t]
        pSurv_inp[joe07,spec_type,acl,t]
        pSurvival
        jC5_flow_hoved_FRF
        jC5_flow_tynd_FRF
        qF5_FRF_NST
        jF5_FRF
        pHV2_hoved_FRF
        pV2_tynd_FRF
        eLasticityMan
        sqHV2_hoved_FRF[joe07,spec_type,acl,t]
        sqV2_tynd_FRF[joe07,spec_type,acl,t]
        sFireWood
        pFirewood
        adjloss_C5_FRF
        rDiskForest
        eFirewood
        jSurv_inp[joe07,spec_type,acl,t]
      ;

      $GROUP G_newage_endo 
        #  pSurv$(tF[t] and acl_spec_type[acl,spec_type])
        pSurv$(sum(ite,ite2t(ite,t)) and t.val<2096 and acl_spec_type[acl,spec_type])
        
        qF5_FRF[joe07,spec_type,acl,t]$(tF[t] and acl_spec_type[acl,spec_type]) 
        qC5_hoved_FRF[joe07,spec_type,acl,t]$(tF[t])   
        qC5_tynd_FRF[joe07,spec_type,acl,t]$(tF[t])                                              "Flow of carbon from thinning of the forest - note that this is per year variable. So to arrive at a five-year total we multiply by 5"
 
        qHV2_hoved_FRF[joe07,spec_type,acl,t]$(tF[t])
        qV2_tynd_FRF[joe07,spec_type,acl,t]$(tF[t])        
        vHV2_hoved_FRF[joe07,spec_type,acl,t]$(tF[t])                                            "Value of of harvested wood products from main logging of FRF, bio. DKR."
        vV2_tynd_FRF[joe07,spec_type,acl,t]$(tF[t])                                              "Value of of harvested wood products from thinning of FRF, bio. DKR."
        pHV2_hoved_FRF_perha[joe07,spec_type,acl,t]
        pV2_tynd_FRF_perha[joe07,spec_type,acl,t]
        pHV2_hoved_FRF$(d1Endoprice and tF[t] and d1vHV2_hoved_FRF[joe07,spec_type,acl,t])
        pV2_tynd_FRF$(d1Endoprice and tF[t] and d1vV2_tynd_FRF[joe07,spec_type,acl,t])
      
        pI_FRF_perha$(tF[t])

        vHoved_Firewood[joe07,spec_type,acl,t]$(tF[t]) ""
        pFirewood[t]$(tF[t] and d1Endoprice)  ""
        qPJ5_hoved[joe07,spec_type,acl,t]$(tF[t]) ""
        vTynd_firewood[joe07,spec_type,acl,t]$(tF[t]) ""
        
        qPJ5_tynd[joe07,spec_type,acl,t]$(tF[t]) ""
        pHoved_Firewood_perha[joe07,spec_type,acl,t]$(tF[t]) ""
        pTynd_firewood_perha[joe07,spec_type,acl,t]$(tF[t]) ""

        pPerHa_hoved_tot[joe07,spec_type,acl,t] ""
        pPerHa_tynd_tot[joe07,spec_type,acl,t] ""

       #  pSurv_inp$(tF[t and spec_type[acl,spec_type])
      ;

      $GROUP G_newage_calib_exo 
       G_newage_exo
       pHV2_hoved_FRF$(d1Endoprice)
       pV2_tynd_FRF$(d1Endoprice)
       pFirewood$(d1Endoprice)
       -sqHV2_hoved_FRF$(d1Endoprice)
       -sqV2_tynd_FRF$(d1Endoprice)
       -sFireWood$(d1Endoprice)

       -jSurv_inp, pSurv
      ;


      $GROUP G_newage_calib_endo 
       G_newage_endo 
       -pHV2_hoved_FRF$(d1Endoprice)
       -pV2_tynd_FRF$(d1Endoprice)
       -pFirewood$(d1Endoprice)
       sqHV2_hoved_FRF$(d1Endoprice)
       sqV2_tynd_FRF$(d1Endoprice)
       sFireWood$(d1Endoprice)
       jSurv_inp, -pSurv
      ;


      #Flade priser
      pHV2_hoved_FRF.l[joe07,spec_type,acl,t]$(sum(ite, ite2t(ite,t))) = scaleprices * pHV2_hoved_FRF.l[joe07,spec_type,acl,t1];
      pV2_tynd_FRF.l[joe07,spec_type,acl,t]$(sum(ite, ite2t(ite,t)))   = scaleprices * pV2_tynd_FRF.l[joe07,spec_type,acl,t1];

      pSurv.l[joe07,spec_type,acl,t]$(t.val>=2016) = pSurvival.l[joe07,spec_type,acl];
      pSurv_inp.l[joe07,spec_type,acl,t]$(t.val>=2016) = pSurvival.l[joe07,spec_type,acl];
      eLasticityMan.l = 5;
      eFirewood.l = 5;
      #  eLasticityMan.l = 0.5;

      pFirewood.l[t] = scaleprices * 0.005;

      rDiskForest.l = 0.075;

      qPJ5_hoved.l[joe07,spec_type,acl,t] = adjloss_C5_FRF.l[t] *  qC5_hoved_FRF.l[joe07,spec_type,acl,t]*sHTynd_FRF.l['ite1',joe07,spec_type,acl,'tynd_fuel']/5 * 44/12 /103.4;
      qPJ5_tynd.l[joe07,spec_type,acl,t]  =  qC5_tynd_FRF.l[joe07,spec_type,acl,t]*sTynd_FRF.l['ite1',joe07,spec_type,acl,'tynd_fuel']* 44/12 /103.4;

      $LOOP G_levelsusedasdummies:
        d1{name}{sets} = yes$({name}.l{sets});
      $ENDLOOP

      #NEW EQUATIONS -OPTIMERING
      $BLOCK B_newage

        #--------------------------------------------------------------------------------------------------------------------------------------#
        # AREAS
        #--------------------------------------------------------------------------------------------------------------------------------------#

        E_pSurv[joe07,spec_type,acl,t]$(sum(ite,ite2t(ite,t)) and t.val<2096 and not acl_terminal[acl,spec_type] and acl_spec_type[acl,spec_type] and sameas[spec_type,'B'] and sameas[joe07,'islands']).. #and not acl_init[acl]).. 
          #  pSurv[joe07,spec_type,acl,t] =E=  pSurv_inp[joe07,spec_type,acl,t]+jSurv_inp[joe07,spec_type,acl,t];
         pSurv[joe07,spec_type,acl,t] =E=  @cdfNorm(pSurv_inp[joe07,spec_type,acl,t]+jSurv_inp[joe07,spec_type,acl,t],pSurvival[joe07,spec_type,acl]/2,pSurvival[joe07,spec_type,acl]/4);
          #  pSurv[joe07,spec_type,acl,t] =E= pSurv_inp[joe07,spec_type,acl,t];

        E_pSurv_terminal[joe07,spec_type,acl,t]$(sum(ite,ite2t(ite,t)) and t.val<2096 and acl_terminal[acl,spec_type] and acl_spec_type[acl,spec_type] and sameas[spec_type,'B'] and sameas[joe07,'islands']).. #and not acl_init[acl])..
          pSurv[joe07,spec_type,acl,t] =E= pSurv_inp[joe07,spec_type,acl,t] + pSurv_inp[joe07,spec_type,acl-1,t] - pSurv_inp.l[joe07,spec_type,acl-1,t]; 

        E_qF5_FRF_regenerated_alt[joe07, spec_type, acl,t]$(tF[t] and acl_init[acl] and sameas[spec_type,'B'] and sameas[joe07,'islands'])..              
          #New forest is then equal to what didn't survive from all other age-classes (acl_a)     
          qF5_FRF[joe07,spec_type,acl,t] =E= sum(acl_a$(acl_xinit[acl_a,spec_type]),    qF5_FRF[joe07, spec_type, acl_a-1,t-5]*(1-pSurv[joe07, spec_type, acl_a-1,t-5])) #Note that this also sums the survivors of acl0
                                           + sum(acl_a$(acl_terminal[acl_a,spec_type]), qF5_FRF[joe07, spec_type, acl_a,t-5] *(1-pSurv[joe07,spec_type,acl_a,t-5]))     #Survivors of terminal age
                                           #The area that doesn't survive is the variable 'Harea' in Tqble 11-11. Note that the numbers in table 11-11 needs to be multiplied by five to arrive at 5-year increments
                                           #  + sum((acl_a,skmodel)$(d1qF5_AFF[skmodel,joe07,spec_type,acl_a-1,t-5]), (1-pSurvival_AFF[skmodel,joe07,spec_type,acl_a-1]) * qF5_AFF[skmodel,joe07,spec_type,acl_a-1,t-5])
                                           #  + jF5_FRF[joe07,spec_type,acl,t];
                                           ;

        #Equation for all other age-classes (the not new-planted/newly-grown forest). Note the conditional acl_xinit_term which states all age-classes except from 1 (and the "terminal age").
        E_qF5_FRF_alt[joe07,spec_type,acl,t]$(tF[t] and acl_xinit_term[acl,spec_type] and sameas[spec_type,'B'] and sameas[joe07,'islands'])..               
            qF5_FRF[joe07,spec_type,acl,t] =E= (qF5_FRF[joe07, spec_type, acl-1,t-5])*pSurv[joe07,spec_type,acl-1,t-5]
                                            #  + jF5_FRF[joe07,spec_type,acl,t]; 
                                            ;

        #Equation for "terminal"-stage trees. After a certain age (200 years as this is written) the trees can, for all practical purposes, be lumped in to the same category. In particular because they do not absorb any more CO2 at this point.
        E_qF5_FRF_alt_terminal[joe07, spec_type, acl,t]$(tF[t] and acl_terminal[acl,spec_type] and sameas[spec_type,'B'] and sameas[joe07,'islands'])..                 
            qF5_FRF[joe07,spec_type,acl,t] =E= qF5_FRF[joe07,spec_type,acl-1,t-5]*pSurv[joe07,spec_type,acl-1,t-5] + qF5_FRF[joe07, spec_type, acl,t-5] *pSurv[joe07,spec_type,acl,t]
                                             #  + jF5_FRF[joe07,spec_type,acl,t];
                                             ; 


        #--------------------------------------------------------------------------------------------------------------------------------------#
        # HUGSTMÆNGDER
        #--------------------------------------------------------------------------------------------------------------------------------------#
          E_qHV2_hoved_FRF_alt[joe07,spec_type,acl,t]$(tF[t] and spec_type_xp[spec_type] and sameas[spec_type,'B'] and sameas[joe07,'islands'])..
              qHV2_hoved_FRF[joe07,spec_type,acl,t] =E= sHTyndCorr_FRF[joe07,spec_type,acl]  * sHTynd_FRF['ite1',joe07,spec_type,acl,'tynd_use'] * qC5_hoved_FRF[joe07,spec_type,acl,t]/5;

          E_qV2_tynd_FRF_alt[joe07,spec_type,acl,t]$(tF[t] and spec_type_xp[spec_type] and sameas[spec_type,'B'] and sameas[joe07,'islands'])..
              qV2_tynd_FRF[joe07,spec_type,acl,t]   =E= 1/sCA2V2[spec_type] * sTynd_FRF['ite1',joe07,spec_type,acl,'tynd_use']  *qC5_tynd_FRF[joe07,spec_type,acl,t];

          E_qC5_tynd_FRF_alt[joe07,spec_type,acl,t]$(tF[t] and acl_spec_type[acl,spec_type] and sameas[spec_type,'B'] and sameas[joe07,'islands'])..
            qC5_tynd_FRF[joe07,spec_type,acl,t] =E=  qF5_FRF[joe07,spec_type,acl,t] * Tynding_coefs[joe07,spec_type,acl] 
                                                        #  - 0.3 * Tynding_coefs[joe07,spec_type,acl] * qF5_FRF_NST[joe07,spec_type,acl,t]$(ite2t('ite2',t) and d1qF5_FRF_NST[joe07,spec_type,acl,t])
                                                        + jC5_flow_tynd_FRF[joe07,spec_type,acl,t];
                                                        #The negative term corresponds to 'Sum af kulstof i levende biomasse over jord i hugstreduktion som følge af reduceret hugst i 2025-2031' from table 11.10. The variable "CA2NST"

          E_qC5_hoved_FRF_alt[joe07,spec_type,acl,t]$(tF[t] and acl_spec_type[acl,spec_type] and sameas[spec_type,'B'] and sameas[joe07,'islands'])..
            qC5_hoved_FRF[joe07,spec_type,acl,t] =E= qF5_FRF[joe07, spec_type, acl-1,t-5]*(1-pSurv[joe07, spec_type, acl-1,t-5]) * content_coeffs_data[joe07,spec_type,acl,'CA_ha']
                                                           +jC5_flow_hoved_FRF[joe07,spec_type,acl,t] ;  #Above-ground mass not transferred to next iteration is hovedskovning. It's a bit odd that it is measured not as a weighted average of acl and acl-1 (with weights 0.5/0.5), but whatevs..
          

          E_qPJ5_hoved[joe07,spec_type,acl,t]$(tF[t] and acl_spec_type[acl,spec_type] and sameas[spec_type,'B'] and sameas[joe07,'islands'])..
            qPJ5_hoved[joe07,spec_type,acl,t] =E= adjloss_C5_FRF[t] *  qC5_hoved_FRF[joe07,spec_type,acl,t]*sHTynd_FRF['ite1',joe07,spec_type,acl,'tynd_fuel']/5 * 44/12 /103.4;


          E_qPJ5_tynd[joe07,spec_type,acl,t]$(tF[t] and acl_spec_type[acl,spec_type] and sameas[spec_type,'B'] and sameas[joe07,'islands'])..
            qPJ5_tynd[joe07,spec_type,acl,t] =E=  qC5_tynd_FRF[joe07,spec_type,acl,t]*sTynd_FRF['ite1',joe07,spec_type,acl,'tynd_fuel']* 44/12 /103.4;
            

        #--------------------------------------------------------------------------------------------------------------------------------------#
        # VÆRDI AF HUGST
        #--------------------------------------------------------------------------------------------------------------------------------------#

          E_vHV2_hoved_FRF_alt[joe07,spec_type,acl,t]$(tF[t] and spec_type_xp[spec_type] and d1vHV2_hoved_FRF[joe07,spec_type,acl,t] and sameas[spec_type,'B'] and sameas[joe07,'islands']).. 
            vHV2_hoved_FRF[joe07,spec_type,acl,t] =E= pHV2_hoved_FRF[joe07,spec_type,acl,t] * qHV2_hoved_FRF[joe07,spec_type,acl,t];

          E_vV2_tynd_FRF_alt[joe07,spec_type,acl,t]$(tF[t] and spec_type_xp[spec_type] and d1vV2_tynd_FRF[joe07,spec_type,acl,t] and sameas[spec_type,'B'] and sameas[joe07,'islands'])..  
            vV2_tynd_FRF[joe07,spec_type,acl,t]  =E= pV2_tynd_FRF[joe07,spec_type,acl,t]  * qV2_tynd_FRF[joe07,spec_type,acl,t];

          E_vHoved_Firewood[joe07,spec_type,acl,t]$(tF[t] and acl_spec_type[acl,spec_type] and sameas[spec_type,'B'] and sameas[joe07,'islands'] and d1qPJ5_hoved[joe07,spec_type,acl,t])..
            vHoved_Firewood[joe07,spec_type,acl,t] =E= pFirewood[t] * qPJ5_hoved[joe07,spec_type,acl,t];
  
          E_vTynd_Firewood[joe07,spec_type,acl,t]$(tF[t] and acl_spec_type[acl,spec_type] and sameas[spec_type,'B'] and sameas[joe07,'islands'] and d1qPJ5_tynd[joe07,spec_type,acl,t])..       
            vTynd_firewood[joe07,spec_type,acl,t] =E= pFirewood[t] * qPJ5_tynd[joe07,spec_type,acl,t];


        #--------------------------------------------------------------------------------------------------------------------------------------#
        # VÆRDI AF HUGST PER HEKTAR
        #--------------------------------------------------------------------------------------------------------------------------------------#

          E_pHoved_Firewood_perha[joe07,spec_type,acl,t]$(tF[t] and acl_spec_type[acl,spec_type] and sameas[spec_type,'B'] and sameas[joe07,'islands'] and d1qPJ5_hoved[joe07,spec_type,acl,t])..
             vHoved_Firewood[joe07,spec_type,acl,t] =E=  pHoved_Firewood_perha[joe07,spec_type,acl,t] * qF5_FRF[joe07,spec_type,acl-1,t-5];
  
          E_pTynd_firewood_perha[joe07,spec_type,acl,t]$(tF[t] and acl_spec_type[acl,spec_type] and sameas[spec_type,'B'] and sameas[joe07,'islands'] and d1qPJ5_tynd[joe07,spec_type,acl,t])..       
             vTynd_firewood[joe07,spec_type,acl,t] =E=  pTynd_firewood_perha[joe07,spec_type,acl,t] * qF5_FRF[joe07,spec_type,acl,t];


          E_pHV2_hoved_FRF_perha[joe07,spec_type,acl,t]$(tF[t] and spec_type_xp[spec_type] and d1vHV2_hoved_FRF[joe07,spec_type,acl,t] and sameas[spec_type,'B'] and sameas[joe07,'islands']).. 
            pHV2_hoved_FRF_perha[joe07,spec_type,acl,t]*qF5_FRF[joe07,spec_type,acl-1,t-5] =E= vHV2_hoved_FRF[joe07,spec_type,acl,t];

          E_pV2_tynd_FRF_perha[joe07,spec_type,acl,t]$(tF[t] and spec_type_xp[spec_type] and d1vV2_tynd_FRF[joe07,spec_type,acl,t] and sameas[spec_type,'B'] and sameas[joe07,'islands'])..    
              pV2_tynd_FRF_perha[joe07,spec_type,acl,t]*qF5_FRF[joe07,spec_type,acl,t]  =E= vV2_tynd_FRF[joe07,spec_type,acl,t]; #SKal arealerne lagges?

          E_pPerHa_hoved_tot[joe07,spec_type,acl,t]$(tF[t] and acl_spec_type[acl,spec_type] and sameas[spec_type,'B'] and sameas[joe07,'islands'])..
            pPerHa_hoved_tot[joe07,spec_type,acl,t] =E= pHV2_hoved_FRF_perha[joe07,spec_type,acl,t]$(d1vHV2_hoved_FRF[joe07,spec_type,acl,t]) 
                                                + pHoved_Firewood_perha[joe07,spec_type,acl,t]$(d1qPJ5_hoved[joe07,spec_type,acl,t]);

          E_pPerHa_tynd_tot[joe07,spec_type,acl,t]$(tF[t] and acl_spec_type[acl,spec_type] and sameas[spec_type,'B'] and sameas[joe07,'islands'])..
            pPerHa_tynd_tot[joe07,spec_type,acl,t] =E= pV2_tynd_FRF_perha[joe07,spec_type,acl,t]$(d1vV2_tynd_FRF[joe07,spec_type,acl,t]) 
                                                + pTynd_Firewood_perha[joe07,spec_type,acl,t]$(d1qPJ5_tynd[joe07,spec_type,acl,t]);

        #--------------------------------------------------------------------------------------------------------------------------------------#
        # MARKEDER FOR TRÆPRODUKTER
        #--------------------------------------------------------------------------------------------------------------------------------------#
          E_pHV2_hoved_FRF_alt[joe07,spec_type,acl,t]$(d1Endoprice and tF[t] and spec_type_xp[spec_type] and d1vHV2_hoved_FRF[joe07,spec_type,acl,t] and sameas[spec_type,'B'] and sameas[joe07,'islands']).. 
           qHV2_hoved_FRF[joe07,spec_type,acl,t] =E= sqHV2_hoved_FRF[joe07,spec_type,acl,t] * (1/pHV2_hoved_FRF[joe07,spec_type,acl,t])**(eLasticityMan);

         E_pV2_tynd_FRF_alt[joe07,spec_type,acl,t]$(d1Endoprice and tF[t] and spec_type_xp[spec_type] and d1vV2_tynd_FRF[joe07,spec_type,acl,t] and sameas[spec_type,'B'] and sameas[joe07,'islands'])..             
           qV2_tynd_FRF[joe07,spec_type,acl,t] =E= sqV2_tynd_FRF[joe07,spec_type,acl,t] * (1/pV2_tynd_FRF[joe07,spec_type,acl,t])**(eLasticityMan);
              

          E_qS_firewood[t]$(tF[t]).. 
            qS_firewood[t] =E= sum(acl, qPJ5_hoved['islands','B',acl,t] + qPJ5_tynd['islands','B',acl,t]);

          E_qD_firewood[t]$(tF[t] and d1Endoprice).. 
            #  qS_firewood[t] =E= sFireWood[t] * sqr(1/pFirewood[t]);
            qS_firewood[t] =E= sFireWood[t] * (1/pFirewood[t])**(eFirewood);



        #--------------------------------------------------------------------------------------------------------------------------------------#
        # ECONOMICS
        #--------------------------------------------------------------------------------------------------------------------------------------#
          E_uc1[joe07,spec_type,acl,t]$(tF[t] and spec_type_xp[spec_type] and not ite2t('ite16',t) and sameas[spec_type,'B'] and not acl_terminal[acl,spec_type] and sameas[joe07,'islands']).. 
            (1+rDiskForest)**5 * pI_FRF_perha[joe07,spec_type,acl,t]=E= pSurv[joe07,spec_type,acl,t]  * pI_FRF_perha[joe07,spec_type,acl+1,t+5]*fv**5 
                                                          +       pSurv[joe07,spec_type,acl,t]        * pV2_tynd_FRF_perha[joe07,spec_type,acl+1,t+5]$(d1vV2_tynd_FRF[joe07,spec_type,acl+1,t+5])*fv**5
                                                          +       pSurv[joe07,spec_type,acl,t]        * pTynd_firewood_perha[joe07,spec_type,acl+1,t+5]$(d1qPJ5_tynd[joe07,spec_type,acl+1,t+5])*fv**5
                                                          +(1-pSurv[joe07,spec_type,acl,t])           * pI_FRF_perha[joe07,spec_type,'acl5',t+5]*fv**5
                                                          +(1-pSurv[joe07,spec_type,acl,t])           * pHV2_hoved_FRF_perha[joe07,spec_type,acl+1,t+5]$(d1vHV2_hoved_FRF[joe07,spec_type,acl+1,t+5])*fv**5
                                                          +(1-pSurv[joe07,spec_type,acl,t])           * pHoved_Firewood_perha[joe07,spec_type,acl+1,t+5]$(d1qPJ5_hoved[joe07,spec_type,acl+1,t+5])*fv**5
                                                          ;

          E_uc2[joe07,spec_type,acl,t]$(tF[t] and spec_type_xp[spec_type] and not ite2t('ite16',t) and sameas[spec_type,'B'] and acl_terminal[acl,spec_type] and sameas[joe07,'islands']).. 
            (1+rDiskForest)**5 * pI_FRF_perha[joe07,spec_type,acl,t]=E= pSurv[joe07,spec_type,acl,t]  * pI_FRF_perha[joe07,spec_type,acl,t+5]*fv**5 
                                                          +   pSurv[joe07,spec_type,acl,t]            * pV2_tynd_FRF_perha[joe07,spec_type,acl,t+5]$(d1vV2_tynd_FRF[joe07,spec_type,acl,t+5])*fv**5
                                                          +   pSurv[joe07,spec_type,acl,t]            * pTynd_firewood_perha[joe07,spec_type,acl,t+5]$(d1qPJ5_tynd[joe07,spec_type,acl,t+5])*fv**5
                                                          +(1-pSurv[joe07,spec_type,acl,t])           * pI_FRF_perha[joe07,spec_type,'acl5',t+5]*fv**5
                                                          +(1-pSurv[joe07,spec_type,acl,t])           * pHV2_hoved_FRF_perha[joe07,spec_type,acl,t+5]$(d1vHV2_hoved_FRF[joe07,spec_type,acl,t+5])*fv**5
                                                          +(1-pSurv[joe07,spec_type,acl,t])           * pHoved_Firewood_perha[joe07,spec_type,acl,t+5]$(d1qPJ5_hoved[joe07,spec_type,acl,t+5])*fv**5
                                                          ;


          E_uc_end1[joe07,spec_type,acl,t]$(tF[t] and spec_type_xp[spec_type] and ite2t('ite16',t) and sameas[spec_type,'B'] and not acl_terminal[acl,spec_type] and sameas[joe07,'islands']).. 
              pI_FRF_perha[joe07,spec_type,acl,t] =E= pI_FRF_perha[joe07,spec_type,acl,t-5];

          E_uc_end2[joe07,spec_type,acl,t]$(tF[t] and spec_type_xp[spec_type] and ite2t('ite16',t) and sameas[spec_type,'B'] and acl_terminal[acl,spec_type] and sameas[joe07,'islands']).. 
              pI_FRF_perha[joe07,spec_type,acl,t] =E= pI_FRF_perha[joe07,spec_type,acl,t-5];


          E_obj.. obj =E= 0;
          #  E_obj.. obj =E= sum((joe07,spec_type,acl,t)$(sum(ite,ite2t(ite,t)) and t.val<2096 and not acl_terminal[acl,spec_type] and acl_spec_type[acl,spec_type] and sameas[spec_type,'B'] and sameas[joe07,'islands']),
                               #  sqr(pSurv[joe07,spec_type,acl,t] - pSurvival[joe07,spec_type,acl]));

      $ENDBLOCK 


      $GROUP G_add 
        j_hugstdec[joe07,spec_type,acl,t] ""
      ;

      $BLOCK B_add
            #OPTIMALITY FOR ALL GENERATIONS! 
            E_pHugstdecis[joe07,spec_type,acl,t]$(tF[t] and spec_type_xp[spec_type] and 
                                                        (d1vHV2_hoved_FRF[joe07,spec_type,acl,t] or d1vV2_tynd_FRF[joe07,spec_type,acl,t] or d1qPJ5_hoved[joe07,spec_type,acl,t] or d1qPJ5_tynd[joe07,spec_type,acl,t])
                                                        and sameas[spec_type,'B'] and sameas[joe07,'islands']
                                                        )..

            + pI_FRF_perha[joe07,spec_type,'acl5',t] 
            + pHV2_hoved_FRF_perha[joe07,spec_type,acl,t]$(d1vHV2_hoved_FRF[joe07,spec_type,acl,t]) 
            + pHoved_Firewood_perha[joe07,spec_type,acl,t]$(d1qPJ5_hoved[joe07,spec_type,acl,t])
        
            =E= 
              pI_FRF_perha[joe07,spec_type,acl,t]
            + pV2_tynd_FRF_perha[joe07,spec_type,acl,t]$(d1vV2_tynd_FRF[joe07,spec_type,acl,t])
            + pTynd_firewood_perha[joe07,spec_type,acl,t]$(d1qPJ5_tynd[joe07,spec_type,acl,t])    
            + j_hugstdec[joe07,spec_type,acl,t]
            ;


          #OPTIMALITY FOR FIRST-GEN!
            #  E_pHugstdecis[joe07,spec_type,acl,t]$(tF[t] and spec_type_xp[spec_type] and 
            #                                              (d1vHV2_hoved_FRF[joe07,spec_type,acl,t] or d1vV2_tynd_FRF[joe07,spec_type,acl,t] or d1qPJ5_hoved[joe07,spec_type,acl,t] or d1qPJ5_tynd[joe07,spec_type,acl,t])
            #                                              and sameas[spec_type,'B'] and sameas[joe07,'islands']
            #                                              and sum(ite, ite2t(ite,t) and firstgen(ite,acl)))..

            #  + pI_FRF_perha[joe07,spec_type,'acl5',t] 
            #  + pHV2_hoved_FRF_perha[joe07,spec_type,acl,t]$(d1vHV2_hoved_FRF[joe07,spec_type,acl,t]) 
            #  + pHoved_Firewood_perha[joe07,spec_type,acl,t]$(d1qPJ5_hoved[joe07,spec_type,acl,t])
        
            #  =E= 
            #    pI_FRF_perha[joe07,spec_type,acl,t]
            #  + pV2_tynd_FRF_perha[joe07,spec_type,acl,t]$(d1vV2_tynd_FRF[joe07,spec_type,acl,t])
            #  + pTynd_firewood_perha[joe07,spec_type,acl,t]$(d1qPJ5_tynd[joe07,spec_type,acl,t])    
            #  + j_hugstdec[joe07,spec_type,acl,t]
            #  ;



      $ENDBLOCK


     
     
      
      $MODEL M_newage 
        B_newage
      ;

      $FIX G_newage_calib_exo;
      $UNFIX G_newage_calib_endo;


      @SOLVE(M_newage);
      @SOLVE(M_newage);
 
        LOOP(t$(tF[t]),
        tjek = sum(acl, qF5_FRF.l['islands','B', acl,t])-sum(acl, qF5_FRF.l['islands','B', acl,t-1]);
        ABORT$(abs(tjek) gt 1e-6) tjek, "Model er ikke arealbevarende";
        );

      #--------------------------------------------------------------------------------------------------------------------------------------#
      # Genkalibrer med faste andelsparametre
      #--------------------------------------------------------------------------------------------------------------------------------------#

      $IF %flatdemandforecast%==1:
        sqHV2_hoved_FRF.l[joe07,spec_type,acl,t]$(t.val > 2015 and not ite2t('ite1',t) and sqHV2_hoved_FRF.l[joe07,spec_type,acl,'2024']) = sqHV2_hoved_FRF.l[joe07,spec_type,acl,'2024']; 
        sqV2_tynd_FRF.l[joe07,spec_type,acl,t]$(t.val > 2015   and not ite2t('ite1',t) and sqV2_tynd_FRF.l[joe07,spec_type,acl,'2024']) = sqV2_tynd_FRF.l[joe07,spec_type,acl,'2024']; 
        sFireWood.l[t]$(not ite2t('ite1',t)) = sFireWood.l['2024'];
      $ENDIF

      $FIX G_newage_exo;
      $UNFIX G_newage_endo;
      @SOLVE(M_newage);
      #  Solve M_newage using NLP maximizing obj;

      $MODEL M_newage_add
       M_newage
       B_add 
      ;

      $GROUP G_newage_exo 
        G_newage_exo
        #  j_hugstdec
      ;

      $GROUP G_newage_endo
        G_newage_endo
        #  pSurv_inp$(sum(ite,ite2t(ite,t)) and t.val<2096 and not acl_terminal[acl,spec_type] and spec_type_xp[spec_type] and sameas[spec_type,'B'] and sameas[joe07,'islands'] and (d1vHV2_hoved_FRF[joe07,spec_type,acl+1,t+5] or d1vV2_tynd_FRF[joe07,spec_type,acl+1,t+5] or d1qPJ5_hoved[joe07,spec_type,acl+1,t+5] or d1qPJ5_tynd[joe07,spec_type,acl+1,t+5])) 
        #  j_hugstdec$(ite2t('ite16',t))

      ;

      $FIX G_newage_exo;
      $UNFIX G_newage_endo;
      @SOLVE(M_newage_add);
      #  $UNFIX(0,1) pSurv;
      #  Solve M_newage_add using NLP minimizing obj;
      @reportskov(base);
      execute_unload 'output\calib.gdx';

      #Setting up shock-model
      $GROUP G_newage_exo
        G_newage_exo
        j_hugstdec
      ;

      $GROUP G_newage_endo 
        G_newage_endo 
        #Man overendogeniserer pSurv_inp i terminal, da E_qF5_FRF_alt_terminal både bestemmes af acl245 og acl250
        #  pSurv_inp$(sum(ite,ite2t(ite,t)) and t.val<2096 and not acl_terminal[acl,spec_type] and spec_type_xp[spec_type] and sameas[spec_type,'B'] and sameas[joe07,'islands'] and (d1vHV2_hoved_FRF[joe07,spec_type,acl+1,t+5] or d1vV2_tynd_FRF[joe07,spec_type,acl+1,t+5]))                                  

        #All gens
        pSurv_inp$(sum(ite,ite2t(ite,t)) and t.val<2091 and not acl_terminal[acl,spec_type] and spec_type_xp[spec_type] and sameas[spec_type,'B'] and sameas[joe07,'islands'] and (d1vHV2_hoved_FRF[joe07,spec_type,acl+1,t+5] or d1vV2_tynd_FRF[joe07,spec_type,acl+1,t+5] or d1qPJ5_hoved[joe07,spec_type,acl+1,t+5] or d1qPJ5_tynd[joe07,spec_type,acl+1,t+5])) 
        j_hugstdec$(ite2t('ite16',t))
        #First-gen only
        #  pSurv_inp$(sum(ite,ite2t(ite,t) and ite2t(ite,t) and firstgen(ite,acl)) and t.val<2096 and not acl_terminal[acl,spec_type] and spec_type_xp[spec_type] and sameas[spec_type,'B'] and sameas[joe07,'islands'] and (vHV2_hoved_FRF.l[joe07,spec_type,acl+1,t+5] or vV2_tynd_FRF.l[joe07,spec_type,acl+1,t+5] or qPJ5_hoved.l[joe07,spec_type,acl+1,t+5] or qPJ5_tynd.l[joe07,spec_type,acl+1,t+5])) 

      ;

      @Save(G_newage_endo);


      #Zero-shock
      $FIX G_newage_exo;
      $UNFIX G_newage_endo;
      @solve(M_newage_add);


      PARAMETER TotalArea[t], MaerkeligpSurv[acl,t];
      MaerkeligpSurv[acl,t]$(pSurv.l['islands','B',acl,t]>1 or pSurv.l['islands','B',acl,t]<0) = pSurv.l['islands','B',acl,t]; 
      TotalArea[t]$(tF[t]) = sum(acl,qF5_FRF.l['islands','B', acl,t]);

      @reportskov(base);
      execute_unload 'output\post_calib.gdx';

      #  M_newage_add.optfile = 1;
      #  M_newage_add.holdFixed = 1;
      #  M_newage_add.workfactor = 2;
      #  SOLVE M_newage_add using CNS;


      #  j_hugstdec.l[joe07,spec_type,acl,t]$(t.val>2040) = 0.5*j_hugstdec.l[joe07,spec_type,acl,t];

      PARAMETER j_hugstdec_init[joe07,spec_type,acl,t]; j_hugstdec_init[joe07,spec_type,acl,t] = j_hugstdec.l[joe07,spec_type,acl,t];

      #  j_hugstdec.l[joe07,spec_type,acl,t] = j_hugstdec.l[joe07,spec_type,acl,t]*0.99;


      set looper/loop1*loop2/;

      LOOP(looper,

      j_hugstdec.l[joe07,spec_type,acl,t]$(not t.val>=2096) = j_hugstdec.l[joe07,spec_type,acl,t] - 0.01*j_hugstdec_init[joe07,spec_type,acl,t];

      $FIX G_newage_exo;
      $UNFIX G_newage_endo;
      @Solve(M_newage_add);
      );
      #  SOLVE M_newage_add using NLP minimizing obj;




      #  $FIX G_newage_exo;
      #  $UNFIX G_newage_endo;
      #        SOLVE M_newage_add using NLP maximizing obj;
      #  Solve M_newage_add using CNS;

      #  j_hugstdec.l[joe07,spec_type,acl,t] = 0;

      #  $FIX G_newage_exo;
      #  $UNFIX G_newage_endo;
      #  Solve M_newage_add using CNS;

      #  Solve M_newage_add using NLP maximizing obj;
      #  j_hugstdec.l[joe07,spec_type,acl,t] = 0;
      #  Solve M_newage_add using NLP maximizing obj;
      
      #  @Solve(M_newage_add);


      #  $LOOP G_newage_endo:
      #      PARAMETER Diff_{name}{sets};
      #      Diff_{name}{sets}$({name}.l{sets} <> {name}_saved{sets}) = {name}.l{sets} - {name}_saved{sets};
      #  $ENDLOOP

      #  SOLVE M_newage_add using NLP maximizing obj;


      #  Solve M_newage using NLP maximizing obj;
      @reportskov(shoc);

      MaerkeligpSurv[acl,t]$(pSurv.l['islands','B',acl,t]>1 or pSurv.l['islands','B',acl,t]<0) = pSurv.l['islands','B',acl,t]; 
      TotalArea[t]$(tF[t]) = sum(acl,qF5_FRF.l['islands','B', acl,t]);

      execute_unload 'output\post.gdx';

        LOOP(t$(tF[t]),
        tjek = sum(acl, qF5_FRF.l['islands','B', acl,t])-sum(acl, qF5_FRF.l['islands','B', acl,t-1]);
        ABORT$(abs(tjek) gt 1e-6) tjek, "Model er ikke arealbevarende";
        );

#  $exit


#  #  $GROUP G_Testi 
#  #   p_out 
#  #   po_out
#  #   q_out 
#  #   m_out
#  #   s_out
#  #   e_out 
#  #   artiv
#  #   j_out
#  #   shutit
#  #  ;

#  #  $GROUP G_testiexo 
#  #   artiv 
#  #   e_out 
#  #   s_out 
#  #   m_out 
#  #   j_out
#  #   po_out_base
#  #  ;

#  #  $GROUP G_testiendo
#  #   m_out 
#  #   p_out 
#  #   q_out 
#  #   po_out
#  #   shutit
#  #  ;


#  #  $BLOCK B_testi 

#  #   E_q_out.. q_out =E= s_out*p_out**(-e_out);

#  #   E_p_out.. p_out =E= (1+m_out) * po_out;

#  #   E_po_out.. po_out =E= po_out_base + artiv;

#  #   E_q_out_edging.. q_out =E= q_out.l * shutit ;

#  #   E_shutit.. shutit =E=  errorf((m_out)/(0.01))*j_out; #@cdfNorm(m_out-m_out.l,(-0.1),0.01) + j_out;
#  #  #  $FUNCTION cdfNorm({x},{mu},{std}): errorf(({x}-{mu})/({std})) $ENDFUNCTION

#  #   #  E_m_out.. m_out =E= m_out*exp(50*m_out)/(exp(50*m_out)+1) + j_out;

#  #  $ENDBLOCK 

#  #  m_out.l = 0.2;
#  #  q_out.l = 10;
#  #  s_out.l = 1;
#  #  po_out_base.l = 1;
#  #  po_out.l = 1;
#  #  p_out.l = 1.2;
#  #  e_out.l = 2;
#  #  shutit.l = 1;

#  #  $MODEL M_testi
#  #   B_testi
#  #  ;

#  #  $GROUP G_testiexo_calib
#  #   G_testiexo
#  #   p_out
#  #   #  m_out
#  #   -s_out
#  #   shutit, -j_out
#  #   #  -j_out

#  #  ;

#  #  $GROUP G_testiendo_calib 
#  #   G_testiendo
#  #   -p_out
#  #   #  -m_out
#  #   s_out
#  #   -shutit, j_out
#  #   #  j_out
#  #  ;


#  #  $FIX G_testiexo_calib;
#  #  $UNFIX G_testiendo_calib;
#  #  @SOLVE(M_testi);
#  #  execute_unload 'output\testi_calib.gdx' $LOOP G_testi: {name}.l $ENDLOOP;

#  #  #Nulstød 
#  #  $FIX G_testiexo;
#  #  $UNFIX G_testiendo;
#  #  @SOLVE(M_testi);


#  #  artiv.l =0.2;

#  #  $FIX G_testiexo;
#  #  $UNFIX G_testiendo;
#  #  @SOLVE(M_testi);

#  #  execute_unload 'output\testi.gdx' $LOOP G_testi: {name}.l $ENDLOOP;
#  #  $exit

#  # Set your start year for the shock   
#  $SETLOCAL start_shock_year 2023 #Year where we start the 0-shock
#  set_time_periods(%start_shock_year%,%terminal_year%);


#  $GROUP G_newones 
#    markup_tot[s,t] ""
#    sEndoStructRaffi[t] ""
#    markup_targ[s,t] ""
#    inp_max[t] ""
#    j_calib[t] ""
#  ;

#  $PGROUP PG_newones 
#    d1ExoProduction[out,s]
#    markup_baseline[s,t]
#    markup_threshold[s,t]
#    alpha_max 
#  ;

#  alpha_max = 50;
#  sEndoStructRaffi.l[tx0] = 1;
#  markup_tot.l[s,t]$(tx0[t]) = (sum(out, pY_CET.l[out,s,t]*qY_CET.l[out,s,t]) - pY0.l[s,t]*qY.l[s,t])/(pY0.l[s,t]*qY.l[s,t]);
#  markup_baseline[s,t] = markup_tot.l[s,t];
#  markup_threshold[s,t] = 0.95*markup_baseline[s,t];

#  d1ExoProduction('Diesel for transport','19000')   = 1;
#  d1ExoProduction('Gasoline for transport','19000') = 1;
#  d1ExoProduction('Oil products','19000')           = 1;    
#  d1ExoProduction('Jet petroleum','19000')          = 1;
#  #  d1ExoProduction('Semi-refined oil','19000')       = 1;


#  $BLOCK B_testshutdownraffi 
#    E_markup_tot[s,t]$(tx0[t]).. markup_tot[s,t] =E= (sum(out$(d1vY_CET[out,s,t]), pY_CET[out,s,t]*qY_CET[out,s,t]) - pY0[s,t]*qY[s,t])/(pY0[s,t]*qY[s,t]);

#    E_qY_CET_raffi[out,s,t]$(tx0[t] and d1ExoProduction[out,s] and d1vY_CET[out,s,t] and sameas[s,'19000'])..
#      qY_CET[out,s,t] =E= sEndoStructRaffi[t] * qY_CET.l[out,s,t];


#    E_sEndoStructRaffi[t]$(tx0[t])..
#      sEndoStructRaffi[t] =E= errorf((markup_tot['19000',t]-markup_threshold['19000',t])/0.01) + j_calib[t];


#    E_inp_max[t]$(tx0[t])..
#      inp_max[t] =E= markup_tot['19000',t]/markup_threshold['19000',t]-1;

#    #    E_sEndoStructRaffi[t]$(tx0[t])..
#    #      inp_max[t] =E= inp_max[t]*exp(alpha_max * (inp_max[t]))/(exp(alpha_max*inp_max[t]) + 1) + j_calib[t];

#  $ENDBLOCK 


#  #Setting up model
#  $MODEL M_zerohock_test 
#    M_zeroshock
#    B_testshutdownraffi
#  ;


#  $GROUP G_endo 
#    G_endo

#    #Lukker modellen
#      vLumpsum, -vGovPrimBalance 

#    #Raffinaderi
#    -qY_CET$(d1ExoProduction[out,s])
#    markup$(d1ExoProduction[out,s])   
#    -pY_CET$(d1vY_CET[out,s,t] and sameas[out,'semi-refined oil']), markup$(d1vY_CET[out,s,t] and sameas[out,'semi-refined oil'])


#    qY_CET$(d1ExoProduction[out,s])
#  ;


#  $GROUP G_exo 
#    G_exo 
#    #Lukker modellen
#      -vLumpsum, vGovPrimBalance

#    # Raffinaderi
#    qY_CET$(d1ExoProduction[out,s])
#    -markup$(d1ExoProduction[out,s]), - markup$(d1vY_CET[out,s,t] and sameas[out,'semi-refined oil']) 
#    pY_CET$(d1vY_CET[out,s,t] and sameas[out,'semi-refined oil'])

#    sEndoStructRaffi


#  ;


#  #Another zero-shock test  
#  $GROUP G_EndoAndExo 
#    G_endo 
#    G_exo
#    -sigmaID
#  ;
#  @save(G_EndoAndExo);

#  $FIX G_exo;
#  $UNFIX G_endo;
#  @SOLVE(M_zerohock_test);
#  $IMPORT sanitycheck.gms

#  execute_unload 'output\test_calib.gdx';
#  $GROUP G_endo 
#    G_endo 
#    -j_calib
#    sEndoStructRaffi
#  ;

#  $GROUP G_exo 
#    G_exo 
#    j_calib
#    -sEndoStructRaffi
#  ;

#  $FIX G_exo;
#  $UNFIX G_endo;
#  execute_unload 'output\pre.gdx';
#  @SOLVE(M_zerohock_test);
#  execute_unload 'output\test_zeroshock.gdx';
#  #Shock"
#  $GROUP G_newones2 vArti[t];

#  $BLOCK B_test 
#         E_pY0_alt[s,t]$(tx0[t])..      pY0[s,t] * qY[s,t] =E= pKELBM[s,t] * qY[s,t] 
#                                                       + vtNetProductionRest[s,t]
#                                                       + vtCAP_top[s,t]$(agri_sectors_s[s])
#                                                      #Basic deduction (Bundfradrag) on energy, incl. basic deduction from free quotas (gratiskvoter) in ETS
#                                                       + vtBotDed[s,t]
#                                                       + vtCO2_ETSxE_marg[s,t]$(d1EmmProdxE[s,t,'CO2e'] and d1CO2_ETS[s,t])
#                                                       + sum((purpose,energy19)$(d1pREa[purpose,energy19,s,t] and eNotInEnergyNest[purpose,energy19,s,t]), pREa[purpose,energy19,s,t]*qREa[purpose,energy19,s,t])
#                                                       + (pRE_NatGasNL[t]*qRE_NatGasNL[t])$(sameas[s,'35011'] and t.val <= 2019)
#                                                       + sum(emm$(d1EmmProdxE[s,t,emm] and d1CO2_ProdxE[s,t,emm]), vtCO2_ProdxE[s,t,emm])                         # CO2e-tax on non-energy related emissions
#                                                       + sum(emm$(d1EmmProdxE[s,t,emm] and sum(techCCS, d1thetaCCSxE[techCCS,s,t,emm]) and sameas[emm,'CO2ubio']),   
#                                                                                                                 + qLEVC_CCS_EmmxE[s,t,emm]*pI_s['iM',s,t]        # LEVC on non-energy related CCS
#                                                                                                                 - vSubsidy_CCS_EmmxE[s,t,emm])                  # Subsidy to non-energy related CCS    
#                                                      + vArti[t]$(sameas[s,'19000'])
#                                                      ;       

#  $ENDBLOCK 

#  #  vArti.l[t]$(t.val > t1.val) = 0.05 * pY0.l['19000',t]*qY.l['19000',t];

#  LOOP(t$(tx1[t] and t.val <t1.val + 35), vArti.l[t] = vArti.l[t-1] + 0.01);
#  vArti.l[t]$(t.val >= t1.val+30) = 0.35;

#  #  vArti.l[t]$(t.val > t1.val) = 0.35;  #375 kroner gange 900 ktCO2e base.

#  $MODEL M_zerohock_test2
#    M_zerohock_test
#    B_test,-E_pY0
#  ;

#  $FIX G_exo;
#  $UNFIX G_endo;
#  $FIX vArti;
#  @SOLVE(M_zerohock_test2);
#  execute_unload 'output\test_shock.gdx';
#  @assert_no_difference(G_EndoAndExo,1e-8);



#  @check_vBoP();




#  $exit

#  # Set your start year for the shock   
#  $SETLOCAL start_shock_year 2023 #Year where we start the 0-shock
#  set_time_periods(%start_shock_year%,%terminal_year%);


#  $GROUP G_newones 
#    markup_tot[s,t] ""
#    sEndoStructRaffi[t] ""
#    markup_targ[s,t] ""
#    inp_max[t] ""
#    j_calib[t] ""
#  ;

#  $PGROUP PG_newones 
#    d1ExoProduction[out,s]
#    markup_baseline[s,t]
#    markup_threshold[s,t]
#    alpha_max 
#  ;

#  alpha_max = 50;
#  sEndoStructRaffi.l[tx0] = 1;
#  markup_tot.l[s,t]$(tx0[t]) = (sum(out, pY_CET.l[out,s,t]*qY_CET.l[out,s,t]) - pY0.l[s,t]*qY.l[s,t])/(pY0.l[s,t]*qY.l[s,t]);
#  markup_baseline[s,t] = markup_tot.l[s,t];
#  markup_threshold[s,t] = 0.95*markup_baseline[s,t];

#  d1ExoProduction('Diesel for transport','19000')   = 1;
#  d1ExoProduction('Gasoline for transport','19000') = 1;
#  d1ExoProduction('Oil products','19000')           = 1;    
#  d1ExoProduction('Jet petroleum','19000')          = 1;


#  $BLOCK B_testshutdownraffi 
#    E_markup_tot[s,t]$(tx0[t]).. markup_tot[s,t] =E= (sum(out$(d1vY_CET[out,s,t]), pY_CET[out,s,t]*qY_CET[out,s,t]) - pY0[s,t]*qY[s,t])/(pY0[s,t]*qY[s,t]);

#    E_qY_CET_raffi[out,s,t]$(tx0[t] and d1ExoProduction[out,s] and d1vY_CET[out,s,t] and sameas[s,'19000'])..
#      qY_CET[out,s,t] =E= sEndoStructRaffi[t] * qY_CET.l[out,s,t];

#    E_inp_max[t]$(tx0[t])..
#      inp_max[t] =E= markup_tot['19000',t]/markup_threshold['19000',t]-1;

#      E_sEndoStructRaffi[t]$(tx0[t])..
#        inp_max[t] =E= inp_max[t]*exp(alpha_max * (inp_max[t]))/(exp(alpha_max*inp_max[t]) + 1) + j_calib[t];

#  $ENDBLOCK 


#  #Setting up model
#  $MODEL M_zerohock_test 
#    M_zeroshock
#    B_testshutdownraffi
#  ;


#  $GROUP G_endo 
#    G_endo

#    #Lukker modellen
#      vLumpsum, -vGovPrimBalance 

#    #Raffinaderi
#    -qY_CET$(d1ExoProduction[out,s])
#    markup$(d1ExoProduction[out,s])   
#    -pY_CET$(d1vY_CET[out,s,t] and sameas[out,'semi-refined oil']), markup$(d1vY_CET[out,s,t] and sameas[out,'semi-refined oil'])


#    qY_CET$(d1ExoProduction[out,s])
#  ;


#  $GROUP G_exo 
#    G_exo 
#    #Lukker modellen
#      -vLumpsum, vGovPrimBalance

#    # Raffinaderi
#    qY_CET$(d1ExoProduction[out,s])
#    -markup$(d1ExoProduction[out,s]), - markup$(d1vY_CET[out,s,t] and sameas[out,'semi-refined oil']) 
#    pY_CET$(d1vY_CET[out,s,t] and sameas[out,'semi-refined oil'])

#    sEndoStructRaffi


#  ;


#  #Another zero-shock test  
#  $GROUP G_EndoAndExo 
#    G_endo 
#    G_exo
#    -sigmaID
#  ;
#  @save(G_EndoAndExo);

#  $FIX G_exo;
#  $UNFIX G_endo;
#  @SOLVE(M_zerohock_test);
#  $IMPORT sanitycheck.gms

#  execute_unload 'output\test_calib.gdx';
#  $GROUP G_endo 
#    G_endo 
#    -j_calib
#    sEndoStructRaffi
#  ;

#  $GROUP G_exo 
#    G_exo 
#    j_calib
#    -sEndoStructRaffi
#  ;

#  $FIX G_exo;
#  $UNFIX G_endo;
#  execute_unload 'output\pre.gdx';
#  @SOLVE(M_zerohock_test);
#  execute_unload 'output\test_zeroshock.gdx';
#  #Shock"
#  $GROUP G_newones2 vArti[t];

#  $BLOCK B_test 
#         E_pY0_alt[s,t]$(tx0[t])..      pY0[s,t] * qY[s,t] =E= pKELBM[s,t] * qY[s,t] 
#                                                       + vtNetProductionRest[s,t]
#                                                       + vtCAP_top[s,t]$(agri_sectors_s[s])
#                                                      #Basic deduction (Bundfradrag) on energy, incl. basic deduction from free quotas (gratiskvoter) in ETS
#                                                       + vtBotDed[s,t]
#                                                       + vtCO2_ETSxE_marg[s,t]$(d1EmmProdxE[s,t,'CO2e'] and d1CO2_ETS[s,t])
#                                                       + sum((purpose,energy19)$(d1pREa[purpose,energy19,s,t] and eNotInEnergyNest[purpose,energy19,s,t]), pREa[purpose,energy19,s,t]*qREa[purpose,energy19,s,t])
#                                                       + (pRE_NatGasNL[t]*qRE_NatGasNL[t])$(sameas[s,'35011'] and t.val <= 2019)
#                                                       + sum(emm$(d1EmmProdxE[s,t,emm] and d1CO2_ProdxE[s,t,emm]), vtCO2_ProdxE[s,t,emm])                         # CO2e-tax on non-energy related emissions
#                                                       + sum(emm$(d1EmmProdxE[s,t,emm] and sum(techCCS, d1thetaCCSxE[techCCS,s,t,emm]) and sameas[emm,'CO2ubio']),   
#                                                                                                                 + qLEVC_CCS_EmmxE[s,t,emm]*pI_s['iM',s,t]        # LEVC on non-energy related CCS
#                                                                                                                 - vSubsidy_CCS_EmmxE[s,t,emm])                  # Subsidy to non-energy related CCS    
#                                                      + vArti[t]$(sameas[s,'19000'])
#                                                      ;       

#  $ENDBLOCK 

#  #  vArti.l[t]$(t.val > t1.val) = 0.05 * pY0.l['19000',t]*qY.l['19000',t];

#  LOOP(t$(tx1[t] and t.val <t1.val + 30), vArti.l[t] = vArti.l[t-1] + 0.01);
#  vArti.l[t]$(t.val > t1.val+30) = 0.35;

#  #  vArti.l[t]$(t.val > t1.val) = 0.35;  #375 kroner gange 900 ktCO2e base.

#  $MODEL M_zerohock_test2
#    M_zerohock_test
#    B_test,-E_pY0
#  ;

#  $FIX G_exo;
#  $UNFIX G_endo;
#  $FIX vArti;
#  @SOLVE(M_zerohock_test2);
#  execute_unload 'output\test_shock.gdx';
#  @assert_no_difference(G_EndoAndExo,1e-8);



#  @check_vBoP();




#  $exit
 
#   #  #  ----------------------------------------------------------------------------------------------------------------------
#   #  #  Testing 1,2,3
#   #  #  ----------------------------------------------------------------------------------------------------------------------
#   #       $GROUP G_newage 
#   #         pHV2_hoved_FRF_perha[joe07,spec_type,acl,t]
#   #         pV2_tynd_FRF_perha[joe07,spec_type,acl,t]
#   #         pSurv[joe07,spec_type,acl,t]
#   #         pSurv_inp[joe07,spec_type,acl,t]
#   #         eLasticityMan 
#   #       ;

#   #       $GROUP G_newage_exo 
#   #         pSurv[joe07,spec_type,acl,t]
#   #         pSurv_inp[joe07,spec_type,acl,t]
#   #         jC5_flow_hoved_FRF
#   #         jC5_flow_tynd_FRF
#   #         qF5_FRF_NST
#   #         jF5_FRF
#   #         pHV2_hoved_FRF
#   #         pV2_tynd_FRF

#   #       ;

#   #       $GROUP G_newage_endo 
#   #         pSurv$(tF[t] and acl_spec_type[acl,spec_type])
#   #         pHV2_hoved_FRF_perha
#   #         pV2_tynd_FRF_perha
#   #         qF5_FRF[joe07,spec_type,acl,t]$(tF[t] and acl_spec_type[acl,spec_type]) 
#   #         qC5_hoved_FRF[joe07,spec_type,acl,t]$(tF[t])   
#   #         qC5_tynd_FRF[joe07,spec_type,acl,t]$(tF[t])                                              "Flow of carbon from thinning of the forest - note that this is per year variable. So to arrive at a five-year total we multiply by 5"
 
#   #         qHV2_hoved_FRF[joe07,spec_type,acl,t]$(tF[t])
#   #         qV2_tynd_FRF[joe07,spec_type,acl,t]$(tF[t])        
#   #         vHV2_hoved_FRF[joe07,spec_type,acl,t]$(tF[t])                                            "Value of of harvested wood products from main logging of FRF, bio. DKR."
#   #         vV2_tynd_FRF[joe07,spec_type,acl,t]$(tF[t])                                              "Value of of harvested wood products from thinning of FRF, bio. DKR."

#   #       ;

#   #         pSurv.l[joe07,spec_type,acl,t] = pSurvival.l[joe07,spec_type,acl];
#   #         pSurv_inp.l[joe07,spec_type,acl,t] = pSurvival.l[joe07,spec_type,acl];


#   #       #NEW EQUATIONS -OPTIMERING
#   #       $BLOCK B_newage
#   #         E_pSurv[joe07,spec_type,acl,t]$(tF[t] and acl_spec_type[acl,spec_type]).. #and not acl_init[acl])..
#   #           pSurv[joe07,spec_type,acl,t] =E= pSurvival[joe07,spec_type,acl] * @cdfNorm(pSurv_inp[joe07,spec_type,acl,t],pSurvival[joe07,spec_type,acl]/2,pSurvival[joe07,spec_type,acl]/4);


#   #         E_qF5_FRF_regenerated_alt[joe07, spec_type, acl,t]$(tF[t] and acl_init[acl])..              
#   #           #New forest is then equal to what didn't survive from all other age-classes (acl_a)     
#   #           qF5_FRF[joe07,spec_type,acl,t] =E= sum(acl_a$(acl_xinit[acl_a,spec_type]),    qF5_FRF[joe07, spec_type, acl_a-1,t-5]*(1-pSurv[joe07, spec_type, acl_a-1,t-5])) #Note that this also sums the survivors of acl0
#   #                                            + sum(acl_a$(acl_terminal[acl_a,spec_type]), qF5_FRF[joe07, spec_type, acl_a,t-5] *(1-pSurv[joe07,spec_type,acl_a,t-5]))     #Survivors of terminal age
#   #                                            #The area that doesn't survive is the variable 'Harea' in Tqble 11-11. Note that the numbers in table 11-11 needs to be multiplied by five to arrive at 5-year increments
#   #                                            #  + sum((acl_a,skmodel)$(d1qF5_AFF[skmodel,joe07,spec_type,acl_a-1,t-5]), (1-pSurvival_AFF[skmodel,joe07,spec_type,acl_a-1]) * qF5_AFF[skmodel,joe07,spec_type,acl_a-1,t-5])
#   #                                            + jF5_FRF[joe07,spec_type,acl,t];

#   #         #Equation for all other age-classes (the not new-planted/newly-grown forest). Note the conditional acl_xinit_term which states all age-classes except from 1 (and the "terminal age").
#   #         E_qF5_FRF_alt[joe07,spec_type,acl,t]$(tF[t] and acl_xinit_term[acl,spec_type])..               
#   #             qF5_FRF[joe07,spec_type,acl,t] =E= (qF5_FRF[joe07, spec_type, acl-1,t-5])*pSurv[joe07,spec_type,acl-1,t-5]
#   #                                             + jF5_FRF[joe07,spec_type,acl,t]; 


#   #         #Equation for "terminal"-stage trees. After a certain age (200 years as this is written) the trees can, for all practical purposes, be lumped in to the same category. In particular because they do not absorb any more CO2 at this point.
#   #         E_qF5_FRF_alt_terminal[joe07, spec_type, acl,t]$(tF[t] and acl_terminal[acl,spec_type])..                 
#   #             qF5_FRF[joe07,spec_type,acl,t] =E= qF5_FRF[joe07,spec_type,acl-1,t-5]*pSurv[joe07,spec_type,acl-1,t-5] + qF5_FRF[joe07, spec_type, acl,t-5] *pSurv[joe07,spec_type,acl,t]
#   #                                              + jF5_FRF[joe07,spec_type,acl,t]; 

#   #         #HUGSTMÆNGDER
#   #           E_qHV2_hoved_FRF_alt[joe07,spec_type,acl,t]$(tF[t] and spec_type_xp[spec_type])..
#   #               qHV2_hoved_FRF[joe07,spec_type,acl,t] =E= sHTyndCorr_FRF[joe07,spec_type,acl]  * sHTynd_FRF['ite1',joe07,spec_type,acl,'tynd_use'] * qC5_hoved_FRF[joe07,spec_type,acl,t]/5;

#   #           E_qV2_tynd_FRF_alt[joe07,spec_type,acl,t]$(tF[t] and spec_type_xp[spec_type])..
#   #               qV2_tynd_FRF[joe07,spec_type,acl,t]   =E= 1/sCA2V2[spec_type] * sTynd_FRF['ite1',joe07,spec_type,acl,'tynd_use']  *qC5_tynd_FRF[joe07,spec_type,acl,t];

#   #           E_qC5_tynd_FRF_alt[joe07,spec_type,acl,t]$(tF[t] and acl_spec_type[acl,spec_type])..
#   #             qC5_tynd_FRF[joe07,spec_type,acl,t] =E=  qF5_FRF[joe07,spec_type,acl,t] * Tynding_coefs[joe07,spec_type,acl] 
#   #                                                         - 0.3 * Tynding_coefs[joe07,spec_type,acl] * qF5_FRF_NST[joe07,spec_type,acl,t]$(ite2t('ite2',t) and d1qF5_FRF_NST[joe07,spec_type,acl,t])
#   #                                                         + jC5_flow_tynd_FRF[joe07,spec_type,acl,t];
#   #                                                         #The negative term corresponds to 'Sum af kulstof i levende biomasse over jord i hugstreduktion som følge af reduceret hugst i 2025-2031' from table 11.10. The variable "CA2NST"

#   #           #Kulstoflager i hovedskovning.
#   #           E_qC5_hoved_FRF_alt[joe07,spec_type,acl,t]$(tF[t] and acl_spec_type[acl,spec_type])..
#   #             qC5_hoved_FRF[joe07,spec_type,acl,t] =E= qF5_FRF[joe07, spec_type, acl-1,t-5]*(1-pSurv[joe07, spec_type, acl-1,t-5]) * content_coeffs_data[joe07,spec_type,acl,'CA_ha']
#   #                                                            +jC5_flow_hoved_FRF[joe07,spec_type,acl,t] ;  #Above-ground mass not transferred to next iteration is hovedskovning. It's a bit odd that it is measured not as a weighted average of acl and acl-1 (with weights 0.5/0.5), but whatevs..
#   #         #  #VÆRDI AF HUGST
#   #           E_vHV2_hoved_FRF_alt[joe07,spec_type,acl,t]$(tF[t] and spec_type_xp[spec_type]).. vHV2_hoved_FRF[joe07,spec_type,acl,t] =E= pHV2_hoved_FRF[joe07,spec_type,acl,t] * qHV2_hoved_FRF[joe07,spec_type,acl,t];
#   #           E_vV2_tynd_FRF_alt[joe07,spec_type,acl,t]$(tF[t] and spec_type_xp[spec_type])..  vV2_tynd_FRF[joe07,spec_type,acl,t]  =E= pV2_tynd_FRF[joe07,spec_type,acl,t]  * qV2_tynd_FRF[joe07,spec_type,acl,t];


#   #         #Pris per areal
#   #           E_pHV2_hoved_FRF_alt[joe07,spec_type,acl,t]$(tF[t] and spec_type_xp[spec_type] and vHV2_hoved_FRF.l[joe07,spec_type,acl,t]).. pHV2_hoved_FRF_perha[joe07,spec_type,acl,t]*qF5_FRF[joe07,spec_type,acl,t] =E= vHV2_hoved_FRF[joe07,spec_type,acl,t];
#   #           E_pV2_tynd_FRF_alt[joe07,spec_type,acl,t]$(tF[t] and spec_type_xp[spec_type] and vV2_tynd_FRF.l[joe07,spec_type,acl,t])..    pV2_tynd_FRF_perha[joe07,spec_type,acl,t]*qF5_FRF[joe07,spec_type,acl,t]  =E= vV2_tynd_FRF[joe07,spec_type,acl,t]; #SKal arealerne lagges?


          
#   #       $ENDBLOCK 


#   #       $MODEL M_newage 
#   #         B_newage
#   #       ;

#   #       $FIX G_newage_exo;
#   #       $UNFIX G_newage_endo;
#   #       execute_unload 'output\pre.gdx';
#   #       @SOLVE(M_newage);
#   #       execute_unload 'output\post.gdx';

#  #----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#  # TEST AF MODEL M. HETEROGEN JORD
#  #----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#  


#  $GROUP G_newvars 
#    uJord[t]
#    tJord[t]  "Produktivitet"
#    qJord[t]
#    pJord[t] 
#    pJordHandel[t] ""
#    uinpX[t] 
#    qinpx[t] 
#    pinpX[t] 
#    pinpX_base[t] ""
  
#    p_out[t] 
#    q_out[t] 
#    v_out[t]

#    lowerb[t]
#    mu[t]
#    sigma_[t]
#    indmad_pos[t] 
#    indmad_neg[t]
#    gns_produktivitet[t] ""
#    samletproduktion[t] ""
#    inputerf[t]
#    erf2errorf[t]
#    s_out[t]
#    TFP_[t] 
#    pAfkastperha[t]

#    vjord[t]
#    vXinpx[t]

#    qEmmX[t] "Lad os sige at der er emissioner fra X som kan være gødning + kalkning med udledninger på 4 mio. t"
#    uEmmX[t] ""
#    tCO2_inpx[t] ""
#    vtCO2_inpx[t] ""
#    tBundfradrag[t] ""
#    tHektarstoette[t] ""
#    tGrundskyld[t] ""
#    tSelskabsskat[t] ""
#    rNomafkast[t] ""
#    pBundfradrag[t] ""
#    sGaeldskvote[t] ""
#    rGaeld[t] ""
#    jpK_jord[t] ""
#    pExcessHarmoni[t] ""
#    pAlt[t] ""
#    pAltHandel[t] ""
#    rDisk_defacto[t] ""
#    jpK_jord_controlled[t] ""
#  ; 

#  $GROUP G_newvars_endo 
#    pJord 
#    qInpx
#    p_out
#    q_out
#    v_out
#    pJordHandel$(tx0[t])
#    pAfkastperha
#    vjord
#    vXinpx
#    vtCO2_inpx[t] ""
#    qEmmX
#    pinpX
#    pAltHandel
#    rDisk_defacto
#  ;

#  $GROUP G_newvars_exo
#    mu[t]
#    sigma_[t]
#    lowerb[t]
#    qJord
#    uInpx
#    uJord
#    tJord
#    s_out
#    TFP_
#    pinpX_base 
#    tCO2_inpx
#    uEmmX
#    #  pinpX
#    tBundfradrag
#    tHektarstoette
#    tGrundskyld
#    tSelskabsskat
#    rNomafkast
#    pBundfradrag
#    sGaeldskvote
#    rGaeld
#    pJordHandel$(t0[t])
#    jpK_jord
#    pExcessHarmoni
#    pAlt
#    jpK_jord_controlled
  
#  ;

#  set mode/base,shoc,diff,pct_diff/;
#  set element/$LOOP G_newvars:
#                     {name}
#                      $ENDLOOP/;
#  PARAMETER reporttestmodel[mode,element,t];

#  sigma_.l[tx0] = 1;
#  mu.l[tx0] = 1;
#  lowerb.l[tx0]= -4;

#  qJord.l[tx0] = 2.2;
#  #  pJord.l[tx0] = 0.40399;
#  #  pJord.l[tx0] = 0.49822769020382851;  
#  pJord.l[tx0] = 0.5;  

#  tJord.l[tx0] = 1;
#  pinpX.l[tx0] = 1;
#  pinpX_base.l[tx0] = 1;
#  qinpX.l[tx0] = 13;
#  qEmmX.l[tx0] = 4;



#  TFP_.l[tx0] =1;
#  p_out.l[tx0] =1;
#  q_out.l[tx0] = pJord.l[tx0] * qJord.l[tx0] + pinpX.l[tx0] *qinpx.l[tx0];

#  #  pJordHandel.l[tx0] = 110; pJordHandel.l[t0]=110;

#  tHektarstoette.l[tx0] = 1.9;

#  #  tHektarstoette.l[t] = 1.9*0.5;
#  tHektarstoette.l[t] = tHektarstoette.l[t] * inf_growth_factor[t];
#  #  tGrundskyld.l[tx0] = 0.00302343797318018;
#  tGrundskyld.l[tx0] = 0.00268379872186707;


#  #Hvis værdien af pAlt er fast dyrkningsværdi 

#  pAlt.l['2019'] = 4.486;
#  pAlt.l['2020'] = 4.435;
#  pAlt.l['2021'] = 4.384;
#  pAlt.l['2022'] = 4.335;
#  pAlt.l['2023'] = 4.288;
#  pAlt.l['2024'] = 4.204;
#  pAlt.l['2025'] = 4.121;
#  pAlt.l['2026'] = 4.040;
#  pAlt.l['2027'] = 3.960;
#  pAlt.l['2028'] = 3.881;
#  pAlt.l['2029'] = 3.803;
#  pAlt.l['2030'] = 3.726;
#  pAlt.l['2031'] = 3.651;
#  pAlt.l['2032'] = 3.576;
#  pAlt.l['2033'] = 3.503;
#  pAlt.l['2034'] = 3.430;
#  pAlt.l['2035'] = 3.358;
#  pAlt.l['2036'] = 3.325;
#  pAlt.l['2037'] = 3.293;
#  pAlt.l['2038'] = 3.261;
#  pAlt.l['2039'] = 3.231;
#  pAlt.l['2040'] = 3.201;
#  pAlt.l['2041'] = 3.172;
#  pAlt.l['2042'] = 3.144;
#  pAlt.l['2043'] = 3.116;
#  pAlt.l['2044'] = 3.089;
#  pAlt.l['2045'] = 3.064;
#  pAlt.l['2046'] = 3.038;
#  pAlt.l['2047'] = 3.014;
#  pAlt.l['2048'] = 2.990;
#  pAlt.l['2049'] = 2.967;
#  pAlt.l['2050'] = 2.944;
#  pAlt.l['2051'] = 2.922;
#  pAlt.l['2052'] = 2.901;
#  pAlt.l['2053'] = 2.880;
#  pAlt.l['2054'] = 2.860;
#  pAlt.l['2055'] = 2.840;
#  pAlt.l['2056'] = 2.821;
#  pAlt.l['2057'] = 2.802;
#  pAlt.l['2058'] = 2.784;
#  pAlt.l['2059'] = 2.766;
#  pAlt.l['2060'] = 2.749;
#  pAlt.l['2061'] = 2.733;
#  pAlt.l['2062'] = 2.716;
#  pAlt.l['2063'] = 2.701;
#  pAlt.l['2064'] = 2.685;
#  pAlt.l['2065'] = 2.670;
#  pAlt.l['2066'] = 2.656;
#  pAlt.l['2067'] = 2.642;
#  pAlt.l['2068'] = 2.628;
#  pAlt.l['2069'] = 2.615;
#  pAlt.l['2070'] = 2.601;
#  pAlt.l['2071'] = 2.589;
#  pAlt.l['2072'] = 2.577;
#  pAlt.l['2073'] = 2.565;
#  pAlt.l['2074'] = 2.553;
#  pAlt.l['2075'] = 2.542;
#  pAlt.l['2076'] = 2.531;
#  pAlt.l['2077'] = 2.520;
#  pAlt.l['2078'] = 2.509;
#  pAlt.l['2079'] = 2.499;
#  pAlt.l['2080'] = 2.489;
#  pAlt.l['2081'] = 2.480;
#  pAlt.l['2082'] = 2.470;
#  pAlt.l['2083'] = 2.461;
#  pAlt.l['2084'] = 2.452;
#  pAlt.l['2085'] = 2.444;
#  pAlt.l['2086'] = 2.435;
#  pAlt.l['2087'] = 2.427;
#  pAlt.l['2088'] = 2.419;
#  pAlt.l['2089'] = 2.412;
#  pAlt.l['2090'] = 2.404;
#  pAlt.l['2091'] = 2.397;
#  pAlt.l['2092'] = 2.390;
#  pAlt.l['2093'] = 2.383;
#  pAlt.l['2094'] = 2.376;
#  pAlt.l['2095'] = 2.370;
#  pAlt.l['2096'] = 2.363;
#  pAlt.l['2097'] = 2.357;
#  pAlt.l['2098'] = 2.351;
#  pAlt.l['2099'] = 2.345;



#  pExcessHarmoni.l[tx0] = 0.450;
#  #  pExcessHarmoni.l[t]$(t.val<2023) = pExcessHarmoni.l['2023'];
#  LOOP(t$(t.val> 2023 and t.val <=2035),
#      pExcessHarmoni.l[t] = pExcessHarmoni.l[t-1] - 0.45/(2035-2023);
#    );

#  pExcessHarmoni.l[t]$(t.val > 2035) = pExcessHarmoni.l['2035'];



#  #  jpK_jord.l[t] = (1.75-0.44);

#  tSelskabsskat.l[tx0] = 0.22;
#  rNomafkast.l[tx0] = 0.05;
#  sGaeldskvote.l[tx0] = 0.6;
#  rGaeld.l[tx0] = 0.05915;
#  #  pJord.l[tx0] = - (rNomafkast.l[tx0]/(1-tSelskabsskat.l[tx0]) - rGaeld.l[tx0]) * sGaeldskvote.l[tx0] * pJordHandel.l[tx0]  # Det her er gældsfordel - som faktisk bliver en bagdel, fordi gæld er dyrere end egenkapital...
#  #                                       + tGrundskyld.l[tx0] * pJordHandel.l[tx0] # grundskyld 
#  #                                       -tHektarstoette.l[tx0] #Hektarstøtte 
#  #                                       -pBundfradrag.l[tx0] * pJordHandel.l[tx0]
#  #                                       + (1+rNomafkast.l[tx0]-fv)/(1-tSelskabsskat.l[tx0]) * pJordHandel.l[tx0];

#  uJord.l[tx0]  = 0.1;
#  uinpX.l[tx0]  = 0.9;

#  pJordHandel.l[tx0] = 131.251;

#  #  TFP_.l['2020'] = 1.05;
#  #  TFP_.l['2021'] = 1.1;
#  #  TFP_.l['2022'] = 1.15;
#  #  TFP_.l['2023'] = 1.2;
#  #  TFP_.l['2024'] = 1.25;
#  #  TFP_.l['2025'] = 1.3;
#  #  TFP_.l['2026'] = 1.35;
#  #  TFP_.l['2027'] = 1.4;
#  #  TFP_.l['2028'] = 1.45;
#  #  TFP_.l['2029'] = 1.5;
#  #  TFP_.l['2030'] = 1.55;
#  #  TFP_.l['2031'] = 1.6;
#  #  TFP_.l['2032'] = 1.65;
#  #  TFP_.l['2033'] = 1.7;
#  #  TFP_.l['2034'] = 1.75;
#  #  TFP_.l['2035'] = 1.8;
#  #  TFP_.l['2036'] = 1.85;
#  #  TFP_.l['2037'] = 1.9;
#  #  TFP_.l['2038'] = 1.95;
#  #  TFP_.l['2039'] = 2;
#  #  TFP_.l[t]$(t.val >=2040) = 2;

#  rDisk_defacto.l[tx0] = 0.01;

#  $BLOCK B_neweqs

#    E_indmad_pos[t]$(tx0[t])..  indmad_pos[t] =E= 1/(2*sqr(sigma_[t])) * (sqr(mu[t])+sqr(lowerb[t]));

#    E_indmad_neg[t]$(tx0[t]).. indmad_neg[t] =E= 1/(2*sqr(sigma_[t])) * (-sqr(mu[t])-sqr(lowerb[t]));


#    E_inputerf[t]$(tx0[t]).. inputerf[t] =E= (mu[t]-lowerb[t])/(sqrt(2)*sigma_[t]);

#    E_erf2errorf[t]$(tx0[t]).. erf2errorf[t] =E= 2*errorf(inputerf[t]*sqrt(2)) -1;
#    #  errorf((mu[t]-lowerb[t])/(sqrt(2)*sigma_[t]))=E= (1+ erf2errorf((mu[t]-lowerb[t])/(sqrt(2)*sigma_[t])/sqrt(2)))/2;


  
#    E_samletproduktion[t]$(tx0[t]).. 
#                                    samletproduktion[t] =E= 
#                                    exp(indmad_neg[t])* 
#                                     (sqrt(2)*mu[t] *exp(indmad_pos[t]) * sigma_[t] * (erf2errorf[t] + 1)
#                                      )/(2*sqrt(2)*sigma_[t])
#                                     + sigma_[t]*exp(indmad_neg[t]+lowerb[t]*mu[t]/sqr(sigma_[t]))/(sqrt(2*pi));








#    E_gnsproduktivitet[t]$(tx0[t])..
#                              gns_produktivitet[t] =E= samletproduktion[t]/(1-@cdfNorm(lowerb[t],mu[t],sigma_[t]));




#    E_qJord[t]$(tx0[t]).. TFP_[t] * qJord[t] * tJord[t] =E= uJord[t] * (pJord[t]/p_out[t]/tJord[t])**(-0.1) * q_out[t];

#    E_qinpX[t]$(tx0[t]).. TFP_[t] * qinpx[t] =E= uInpx[t] * (pinpX[t]/p_out[t])**(-0.1) * q_out[t];

#    E_p_out[t]$(tx0[t]).. p_out[t] * q_out[t] =E= pJord[t] * qJord[t] + pinpX[t] * qinpx[t];

#    E_v_out[t]$(tx0[t]).. v_out[t] =E= p_out[t] * q_out[t];

#    E_qOut[t]$(tx0[t]).. q_out[t] =E= s_out[t]*(p_out[t])**(-3.4);

#    #  E_pJord[t]$(tx0[t]).. pJord[t] =E= 
#    #                                       - (rNomafkast[t]/(1-tSelskabsskat[t]) - rGaeld[t]) * sGaeldskvote[t] * pJordHandel[t]  # Det her er gældsfordel - som faktisk bliver en bagdel, fordi gæld er dyrere end egenkapital... De 0.22 er selskabsskat
#    #                                        + tGrundskyld[t] * pJordHandel[t] # grundskyld 
#    #                                        - tHektarstoette[t] #
#    #                                        - pBundfradrag[t]
#    #                                       + (1+rNomafkast[t]-fv)/(1-tSelskabsskat[t])* pJordHandel[t];

#    E_pJord[t]$(tx0E[t]).. 
#        pJord[t+1] * (1-tSelskabsskat[t+1]) * fv =E=

#            (1+rNomafkast[t+1]) * pJordHandel[t]  - pJordHandel[t+1]*fv 

#          #  - (rNomafkast[t+1] - rGaeld[t+1]*(1-tSelskabsskat[t+1])) * sGaeldskvote[t] * pJordHandel[t]
#          - (rNomafkast[t+1] - rBonds['01011',t+1]*(1-tSelskabsskat[t+1])) * sGaeldskvote[t] * pJordHandel[t]

#          - (1-tSelskabsskat[t+1]) * tHektarstoette[t+1] *fv

#          + (1-tSelskabsskat[t+1]) * tGrundskyld[t+1]* pJordHandel[t] 

#          #  - (1-tSelskabsskat[t+1]) * pBundfradrag[t+1] * fv 

#          - (1-tSelskabsskat[t+1]) * jpK_jord[t+1] *fv

#          - (1-tSelskabsskat[t+1]) * pExcessHarmoni[t+1] * fv

#          + (1-tSelskabsskat[t+1])  * jpK_jord_controlled[t+1]

#        ;


#    E_pJord_tEnd[t]$(tEnd[t])..
#        pJordHandel[t] =E= pJordHandel[t-1]; 

#    E_pAlt[t]$(tx0E[t])..
#      pAlt[t+1] *(1-tSelskabsskat[t+1]) * fv =E=
#          (1+rNomafkast[t+1]) * pAltHandel[t]  - pAltHandel[t+1]*fv 

#          #  - (rNomafkast[t+1] - rGaeld[t+1]*(1-tSelskabsskat[t+1])) * sGaeldskvote[t] * pJordHandel[t]
#          - (rNomafkast[t+1] - rBonds['01011',t+1]*(1-tSelskabsskat[t+1])) * sGaeldskvote[t] * pAltHandel[t]

#          + (1-tSelskabsskat[t+1]) * tGrundskyld[t+1]* pAltHandel[t] 
#        ;

#    E_pAlt_tEnd[t]$(tEnd[t])..
#      pAltHandel[t] =E= pAltHandel[t-1];

#    E_pDiskDefacto[t]$(tx0[t])..
#        pAltHandel[t]  =E=  pAlt[t]*1/rDisk_defacto[t];

#    E_pinpX[t]$(tx0[t]).. pinPx[t] =E= vtCO2_inpx[t]/qInpx[t]  + pinpX_base[t];

#    E_vtCO2_inpx[t]$(tx0[t]).. vtCO2_inpx[t] =E= tCO2_inpx[t] * qEmmX[t];

#    E_qEmmX[t]$(tx0[t]).. qEmmX[t] =E= uEmmX[t] * qInpx[t];


#    #Rapporter
#    E_pAfkastperha[t]$(tx0[t]).. pAfkastperha[t] =E= v_out[t]/qJord[t];

#    E_budgetjord[t]$(tx0[t]).. vJord[t] =E= pJord[t] * qJord[t];

#    E_budgetx[t]$(tx0[t]).. vXinpx[t] =E= pinpX[t] * qInpx[t];

#  $ENDBLOCK 



#  #=============================================================================================================================#
#  # KALIBRERING
#  #=============================================================================================================================#
#  $SETGLOBAL calibratepAlthandel 1

#  $BLOCK B_calibrate 

#    E_uJord[t]$(tx1[t])..
#      uJord[t] =E= uJord[t-1];

#    E_uinpx[t]$(tx1[t])..
#      uinpx[t] =E= uinpx[t-1];

#    E_s_out[t]$(tx1[t])..
#      s_out[t] =E= s_out[t-1];

#    E_uEmmX[t]$(tx1[t])..
#      uEmmX[t] =E= uEmmX[t-1];

#    E_jpK_jord[t]$(tx1[t] and t.val > t2.val)..
#      jpK_jord[t] =E= jpK_jord[t2];

#    $IF %calibratepAlthandel%==1:
#     E_pAlt_handel[t]$(tx1[t])..
#        pAlt[t] =E= pAlt[t-1];
#    $ENDIF 

#  $ENDBLOCK 


#  $MODEL M_neweqs
#    B_neweqs
#  ;


#  $MODEL M_neweqs_calib 
#    B_neweqs
#    #  -E_pJord_tEnd
#    #  E_pJord_t0
#    E_uJord
#    E_uinpx
#    E_s_out
#    E_uEmmX
#    E_jpK_jord
#    $IF %calibratepAlthandel%==1:
#      E_pAlt_handel
#    $ENDIF 
#    #  E_jJord_t1_calib

#    #  E_pJord_handel_t0
#  ;

#  $GROUP G_newvars_calib_exo 
#    G_newvars_exo
#    #  pJord, -uJord
#    #  pJordHandel,-uJord
#    #  pJordHandel$(t0[t] or t1[t]), -uJord
#    -uJord, pJord$(t1[t])
#    qinpx$(t1[t]),-uinpx
#    q_out$(t1[t]), -s_out
#    qEmmX$(t1[t]),-uEmmX
#    -jpK_jord, pJordHandel$(t1[t])
#    $IF %calibratepAlthandel%==1:
#      #  pAltHandel$(t1[t])
#      pAltHandel$(t.val = 2025)
#      #  pAltHandel$(t.val =2022)
#      -pAlt$(tx0[t])
#    $ENDIF 
#  ;

#  $GROUP G_newvars_calib_endo
#    G_newvars_endo
#    #  -pJord, uJord
#    #  -pJordHandel$(t0[t] or t1[t]), uJord
#    uJord,-pJord$(t1[t])
#    -qinpx$(t1[t]), uinpx
#    -q_out$(t1[t]), s_out
#    -qEmmX$(t1[t]), uEmmX
#    -pJordHandel$(t1[t]), jpK_jord
#    $IF %calibratepAlthandel%==1:
#      #  -pAltHandel$(t1[t])
#      -pAltHandel$(t.val =2025)
#      #  -pAltHandel$(t.val =2022)
#      pAlt$(tx0[t])
#    $ENDIF 
#  ;


#  #  pAltHandel.l[tx0] = 6.332; #Optionsværdi 
#  #  pAltHandel.l[tx0] = 8.442; #Jagt
#  #  pAltHandel.l[tx0] = 13.637; #Herlighed
#  #  pAltHandel.l[tx0] = 13.637+8.442; #Jagt & herlighed
#  #  pAltHandel.l[tx0] = 34.03268316; #Residual
#  #  pAltHandel.l[tx0] = 62.5; #Vådlagt lavbund
#  #  pAltHandel.l[tx0] = 29.77; #2019 vækst- og inflations

#  #  pAltHandel.l[tx0] = 17.28; #Maximal værdi af uendelig hektarstøtte ift. 12 år støtte ved skovrejsning (med udgangspunkt i 2025)
#  #  pAltHandel.l[tx0] = 17.28; #Maximal værdi af uendelig hektarstøtte ift. 12 år støtte ved skovrejsning (med udgangspunkt i 2025)
#  #  pAltHandel.l[tx0] = 21.87;
#  #  pAltHandel.l[tx0] = 35.28; #Værdien af hektarstøtte i 2019
#  #  pAltHandel.l[tx0] = 28.28; #Værdien af ha-støtte i 2025
#  #  pAltHandel.l[tx0] = 16.48; #Værdien af ha-støtte i 2025 fratrukket første 12 år
#    #  pAltHandel.l[tx0] = 11.8;
#  #  pAltHandel.l[tx0] = 59.4; #2025-værdi af skov i excelark (pt...)

#  #  pAlt.l[t] = 0.001;
#  #  pAlt.l[t]$(t.val >= 2019 and t.val <2031) = 1.9*inf_growth_factor[t];
#  #  pAlt.l[t] = 0.445923; 
#  #  pAlt.l[t] = 0.7;
#  #  pAlt.l[t] =  0.508577387591655; #Jagt & herlighed 
#  #  pAlt.l[t] = 1.0278; #Fortrængt DBII og kile imellem hektarstøtte.
#  #  pAlt.l[t] = (1.9 + 1.5)*inf_growth_factor[t] + 0.146 + 0.509; #Værdi af miljø- og klimavenligt græs (inkl. grundbetaling, optionsværdi og jagt & herlighed)
#  #  pAlt.l[t] = (1.9)*inf_growth_factor[t] + 0.146 + 0.509; #Værdi brak af miljø- og klimavenligt græs (inkl. grundbetaling, optionsværdi og jagt & herlighed)

#  #  pAlt.l[tx0] = 0.741045;
#  #  pAlt.l[tx0] = 0.65;

#  $FIX G_newvars_calib_exo;
#  $UNFIX G_newvars_calib_endo;
#  @SOLVE(M_neweqs_calib);
#  $LOOP G_newvars:
#    reporttestmodel['base','{name}',t] = {name}.l{sets};
#  $ENDLOOP

#  execute_unload 'output\calib_test.gdx' $LOOP G_newvars: {name}.l $ENDLOOP reporttestmodel;


#  #=============================================================================================================================#
#  # NULSTØD OG TEST AF NULSTØD
#  #=============================================================================================================================#

#    $GROUP G_save
#      G_newvars
#    ;
#    @SAVE(G_save);

#    $FIX G_newvars_exo;
#    $UNFIX G_newvars_endo;
#    @SOLVE(M_neweqs);

#        $LOOP G_newvars:
#        reporttestmodel['shoc','{name}',t] = {name}.l{sets};
#        $ENDLOOP
#        reporttestmodel['diff',element,t] = reporttestmodel['shoc',element,t] - reporttestmodel['base',element,t];
#        reporttestmodel['pct_diff',element,t]$(reporttestmodel['base',element,t]) 
#        = reporttestmodel['diff',element,t]/reporttestmodel['base',element,t]*100;

#    execute_unload 'output\test_zeroshock.gdx';
#    @assert_no_difference(G_save,1e-8);

#  #=============================================================================================================================#
#  # STØD
#  #=============================================================================================================================#

#    #  tHektarstoette.l[t] = tHektarstoette.l[t] * inf_growth_factor[t];

#    #  tGrundskyld.l[tx0] = tGrundskyld.l[tx0] + 0.001;

#    $GROUP G_newvars_exo
#    G_newvars_exo
#    #  pJordHandel, -pBundfradrag
#  ;

#  $GROUP G_newvars_endo
#    G_newvars_endo
#    #  -pJordHandel, pBundfradrag
#  ;


#  #  pBundfradrag.l[tx0] = (93000-54000)*0.0275154067937009/1000;

#    #  loop(t$(tx1[t]),
#    #  s_out.l[t] = s_out.l[t-1]*1.001;
#    #      );

#    #  TFP_.l[t] = TFP_.l[t] * 1.01;

#    #Test af om stigende rente gør noget 

#    #  rGaeld.l[tx0] = rGaeld.l[tx0] + 0.01;


#    #Nulstil J
#    #  jpK_jord.l[t] = 0;

#    $FIX G_newvars_exo;
#    $UNFIX G_newvars_endo;
#    @SOLVE(M_neweqs);


#    $LOOP G_newvars:
#      reporttestmodel['shoc','{name}',t] = {name}.l{sets};
#    $ENDLOOP

#    reporttestmodel['diff',element,t] = reporttestmodel['shoc',element,t] - reporttestmodel['base',element,t];
#    reporttestmodel['pct_diff',element,t]$(reporttestmodel['base',element,t]) 
#      = reporttestmodel['diff',element,t]/reporttestmodel['base',element,t]*100;

#    execute_unload 'output\test_dyn.gdx' $LOOP G_newvars: {name}.l $ENDLOOP reporttestmodel;

#  $exit


#  #  #  d1UdtagOptions[gridtax,HaUdtag,Lavbundsmodel] = no;
#  #  #  d1UdtagOptions['0','35000','1'] = yes;

#  #  PARAMETER d1UdtagOptions_maal[gridtax,HaUdtag,Lavbundsmodel];
#  #  d1UdtagOptions_maal['750','70000','2'] = yes;
#  #  d1UdtagOptions_maal['625','70000','2'] = yes;
#  #  d1UdtagOptions_maal['500','70000','2'] = yes;
#  #  d1UdtagOptions_maal['375','70000','2'] = yes;
#  #  #  d1UdtagOptions_maal['250','70000','2'] = yes;


#  #  #  d1UdtagOptions['750','70000','2'] = no;
#  #  #  d1UdtagOptions['500','70000','2'] = yes;

#  #  $GROUP G_maalsoegskov 

#  #    NW_denom_maal[grid,gridtax,alt,btype,t] ""
#  #    NW_nom_maal[grid,gridtax,alt,btype,t] ""
#  #    NW_maalkomp1[grid,gridtax,alt,btype,t] ""
#  #    NW_maalkomp2[grid,gridtax,alt,btype,t] ""
#  #    qLandUdtag_pot_maal[alt,btype,t] ""
#  #    tTilskud_maal[btype] ""
#  #    adj_targetskov
#  #  ;

#  #  tTilskud_maal.l[btype] = AfkastTilskov['500',btype];

#  #  udtag_udf[grid,'750','70000','2','sko',btype] = udtag_udf[grid,'750','70000','2','sko',btype]*2;

#  #  #  adj_targetskov.l = 1;
#  #  parameter sigmamaal /15/; #God

#  #  #  parameter sigmamaal /30/; #God
#  #  $BLOCK B_testmeup 



#  #     #   #Vægt i nævneren jordudtagsfunktionens "glidende gennemsnit" over grid af hektarafgift for given samlet vDBII_INPUT
#  #     #  E_NW_denom_ifbase[grid,alt,btype,HadUdtag,lavbundsmodel,t]$(tx0E[t] and d1UdtagOptions[gridtax,HaUdtag,lavbundsmodel])..  
#  #     #     NW_denom[grid,gridtax,alt,btype,t] =E=  @pdfNorm(vDBII_INPUT[t], profitiomdrift_total[grid,gridtax,HaUdtag,lavbundsmodel], 100000);

#  #     #   #Væg i tælleren af jordudtagsfunktionen "glidende gennemsnit" over grid af hektarafgift for et givent samlet vDBII_INPUT
#  #     #   E_NW_nom_ifbase[grid,gridtax,alt,btype,HaUdtag,lavbundsmodel,t]$(tx0E[t] and d1UdtagOptions[gridtax,HaUdtag,lavbundsmodel])..   
#  #     #     NW_nom[grid,gridtax,alt,btype,t]   =E= udtag_udf[grid,gridtax,HaUdtag,lavbundsmodel,alt,btype] * @pdfNorm(vDBII_INPUT[t], profitiomdrift_total[grid,gridtax,HaUdtag,lavbundsmodel], 100000);
   
#  #     #   #Jordudtag til en given allokering for en given bedriftstype bestemt ved det "glidende gennemsnit" over grid af hektarafgift.
#  #     #   E_qLandUdtag_pot_ifbase[alt,btype,gridtax,HaUdtag,lavundsmodel,t]$(tx0E[t] and d1UdtagOptions[gridtax,HaUdtag,lavbundsmodel])..
#  #     #     qLandUdtag_pot[alt,btype,gridtax,t] * sum(grid, NW_denom[grid,gridtax,alt,btype,t]) 
#  #     #       =E= sum(grid, NW_nom[grid,gridtax,alt,btype,t]);#/sum(grid, NW_denom[grid,gridtax,alt,btype,t]);

#  #     E_NW_maalkomp1[grid,alt,btype,gridtax,HaUdtag,lavbundsmodel,t]$(tx0E[t] and d1UdtagOptions_maal[gridtax,HaUdtag,lavbundsmodel])..  
#  #       NW_maalkomp1[grid,gridtax,alt,btype,t] =E=  @pdfNorm(vDBII_INPUT[t], profitiomdrift_total[grid,gridtax,HaUdtag,lavbundsmodel], 100000);

#  #     E_NW_maalkomp2[grid,alt,btype,gridtax,HaUdtag,lavbundsmodel,t]$(tx0E[t] and d1UdtagOptions_maal[gridtax,HaUdtag,lavbundsmodel])..  
#  #       NW_maalkomp2[grid,gridtax,alt,btype,t] =E= @pdfNorm(tTilskud_maal[btype], AfkastTilskov[gridtax,btype], sigmamaal); 



#  #      #Vægt i nævneren jordudtagsfunktionens "glidende gennemsnit" over grid af hektarafgift for given samlet vDBII_INPUT
#  #     E_NW_denom_maal[grid,alt,btype,gridtax,HaUdtag,lavbundsmodel,t]$(tx0E[t] and d1UdtagOptions_maal[gridtax,HaUdtag,lavbundsmodel])..  
#  #        #  NW_denom_maal[grid,gridtax,alt,btype,t] =E=  @pdfNorm(vDBII_INPUT[t], profitiomdrift_total[grid,gridtax,HaUdtag,lavbundsmodel], 100000) * @pdfNorm(tTilskud_maal[btype], AfkastTilskov[gridtax,btype], sigmamaal); 
#  #        NW_denom_maal[grid,gridtax,alt,btype,t] =E= NW_maalkomp1[grid,gridtax,alt,btype,t] * NW_maalkomp2[grid,gridtax,alt,btype,t];
#  #      #Væg i tælleren af jordudtagsfunktionen "glidende gennemsnit" over grid af hektarafgift for et givent samlet vDBII_INPUT
#  #      E_NW_nom_maal[grid,gridtax,alt,gridtax,btype,HaUdtag,lavbundsmodel,t]$(tx0E[t] and d1UdtagOptions_maal[gridtax,HaUdtag,lavbundsmodel])..   
#  #        #  NW_nom_maal[grid,gridtax,alt,btype,t]   =E= udtag_udf[grid,gridtax,HaUdtag,lavbundsmodel,alt,btype] * @pdfNorm(vDBII_INPUT[t], profitiomdrift_total[grid,gridtax,HaUdtag,lavbundsmodel], 100000) * @pdfNorm(tTilskud_maal[btype], AfkastTilskov[gridtax,btype], sigmamaal);
#  #        NW_nom_maal[grid,gridtax,alt,btype,t]   =E= udtag_udf[grid,gridtax,HaUdtag,lavbundsmodel,alt,btype] * NW_denom_maal[grid,gridtax,alt,btype,t];


#  #      E_qLandUdtag_pot_maal[alt,btype,t]$(tx0E[t] and sum((gridtax,Haudtag,Lavbundsmodel), d1UdtagOptions_maal[gridtax,HaUdtag,lavbundsmodel]))..
#  #        qLandUdtag_pot_maal[alt,btype,t] * sum((grid,gridtax)$(sum((HaUdtag,lavbundsmodel), d1UdtagOptions_maal[gridtax,HaUdtag,lavbundsmodel])), NW_denom_maal[grid,gridtax,alt,btype,t]) 
#  #          =E= sum((grid,gridtax)$(sum((HaUdtag,lavbundsmodel), d1UdtagOptions_maal[gridtax,HaUdtag,lavbundsmodel])), NW_nom_maal[grid,gridtax,alt,btype,t]);




#  #    #----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#  #    # Udtagning til SKOV
#  #    #----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#  

#  #      #---------------------------------------------------------------------
#  #      # Udtagning til skov a) udtagningsen, der går ind i landbrugsmodulet
#  #      #------------------------------------- -------------------------------

#  #       #Beregner, hvor meget skov der potentielt kan udtages for en given negativ afgift
#  #       E_qLandSko_pot_inp_maal[t]$(tx0E[t])..
#  #          #  qLandSko_pot[t] =E= sum((btype,gridtax)$(d1currentgrid[gridtax]), qLandUdtag_pot['sko',btype,gridtax,t])/10**6;
#  #          #Vi bruger 2050 som anker. Vi sætter loft over skovrejsning på 250 000 ha. 
#  #          qLandSko_pot_inp[t] =E= sum(btype, qLandUdtag_pot_maal['sko',btype,'2050'])/10**6;

#  #        E_qLandSkov_pot_hoej_maal[t]$(tx0E[t])..
#  #          qLandSko_pot_hoej[t] =E= sum(btypeH, qLandUdtag_pot_maal['sko',btypeH,'2050'])/10**6;

#  #        E_qLandSkov_pot_lav_maal[t]$(tx0E[t])..
#  #          qLandSko_pot_lav[t] =E= sum(btypeL, qLandUdtag_pot_maal['sko',btypeL,'2050'])/10**6;




#  #      #Totalt udtaget jord målt i mio. ha. for et givent DBII målt ved opslag ved "glidende gennemsnit" i de kombinationer af hektarafgift og DBII, der bliver beregnet på IFRO's tal
#  #      E_qLandUdtag_tot_maal[t]$(tx0E[t])..
#  #             qLandUdtag_tot[t] =E= sum(btype, qLandUdtag_pot_maal['GLM',btype,t] + qLandUdtag_pot_maal['BIO',btype,t])*scaleha/10**6
#  #                                                              + qLandSko[t] + qLandBRK[t]
#  #                                                              + qLavUdtaget[t]*scaleha/10**6
#  #                                                              ; #Lavbund der ikke er udtaget endnu lægges til


#  #      E_targetskov..
#  #        #  sum(btype$(btypexlav[btype]), qLandUdtag_pot_maal['sko',btype,'2050'])/10**6 =E= 0.25;
#  #        #  sum(btype$(btypexlav[btype]), qLandUdtag_pot_maal['sko',btype,'2050']) =E= 250000;
#  #        qLandSko['2099'] =E= 0.25;


#  #      E_tilskudmaal[btype]$(btypexlav[btype] and btypeL[btype])..
#  #        tTilskud_maal[btype] =E= tTilskud_maal.l[btype] + adj_targetskov;

#  #      E_tilskudmaal2[btype]$(btypexlav[btype] and btypeH[btype])..
#  #        tTilskud_maal[btype] =E= tTilskud_maal.l[btype] + adj_targetskov;


#  #  $ENDBLOCK 


#  #  $MODEL M_moretesty 
#  #    E_NW_maalkomp1
#  #    E_NW_maalkomp2
#  #    E_NW_nom_maal
#  #    E_NW_denom_maal
#  #    E_qLandUdtag_pot_maal
#  #    #  E_tilskudmaal
#  #    #  E_targetskov
#  #  ;

#  #  $FIX tTilskud_maal, vDBII_input;
#  #  @SOLVE(M_moretesty);
#  #  execute_unload 'output\post.gdx';

#  #  #  $MODEL M_moretestytesty 
#  #  #    M_moretesty
#  #  #    E_tilskudmaal
#  #  #    E_tilskudmaal2
#  #  #    E_targetskov
#  #  #  ;

#  #  #  $UNFIX tTilskud_maal$(btypexlav[btype] and btypeL[btype]);
#  #  #  $UNFIX tTilskud_maal$(btypexlav[btype] and btypeH[btype]);
#  #  #  @SOLVE(M_moretestytesty);


#  #  $MODEL M_endolandlinks_test 
#  #    M_endolandlinks
#  #    #  -E_NW_denom 
#  #    #  -E_NW_nom 
#  #    #  -E_qLandUdtag_pot

#  #    -E_qLandSko_pot_inp
#  #    -E_qLandSkov_pot_hoej 
#  #    -E_qLandSkov_pot_lav
#  #    -E_qLandUdtag_tot
#  #    B_testmeup

#  #    -E_targetskov
#  #    -E_tilskudmaal
#  #    -E_tilskudmaal2
#  #  ;


#  #  $FIX G_endolandlinks_exo;
#  #  $UNFIX G_endolandlinks_endo;
#  #  $FIX vDBII;
#  #  $FIX tTilskud_maal;
#  #  @Solve(M_endolandlinks_test);

#  #  $MODEL M_endolandlinks_test_maal 
#  #    M_endolandlinks_test
#  #    E_targetskov
#  #    E_tilskudmaal
#  #    E_tilskudmaal2
#  #  ;
#  #  $UNFIX tTilskud_maal$(btypeXlav[btype]);
#  #  @SOLVE(M_endolandlinks_test_maal);
#  #  $FIX tTilskud_maal$(btypelav[btype]);
#  #  #  $FIX tTilskud_maal;
#  #  #  execute_unload 'output\pre.gdx';
#  #  execute_unload 'output\post.gdx';


#  #  $MODEL M_CO2tax_test 
#  #    M_CO2tax
#  #    -M_endolandlinks
#  #    M_endolandlinks_test_maal
#  #  ;

#  #  $FIX G_exo;
#  #  $UNFIX G_endo;
#  #  @SOLVE(M_CO2tax);

#  #  #  execute_unload 'output\test.gdx';
