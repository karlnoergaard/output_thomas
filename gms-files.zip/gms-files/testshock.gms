
# Set your start year for the shock   
	#  $SETLOCAL start_shock_year 2023 #Year where we start the 0-shock
	#  set_time_periods(%start_shock_year%,%terminal_year%);


	$ONECHO > conopt4.opt
	  #  Keep searching for a solution even if a bound is hit (due to non linearities)
	  lmmxsf = 1
	
	  #  Time limit in seconds
	  rvtime = 1000000
	  reslim = 1000000
	
	  #  Optimality tolerance for reduced gradient
	  RTREDG = 1.e-9
	
	  #  Absolute pivot tolerance, Range: [2.2e-16, 1.e-7], Default: 1.e-10
	  #  RTPIVA = 1.e-15
	
	  #  Relative pivot tolerance during basis factorizations, Range: [1.e-3, 0.9], Default: 0.05
	  #  RTPIVR = 1.e-3
	
	  #  Multi-threating
	  Threads=8
	  THREADF=8
	
	  #iterLim = 0
	
	  #Turn of autosv
	  #Frq_Rescale = 0
	$OFFECHO


$GROUP G_EndoAndExo 
	G_endo 
	G_exo
-sigmaID
;
@save(G_EndoAndExo);

$FIX G_exo;
$UNFIX G_endo;
M_zeroshock.optfile = 1;
M_zeroshock.holdFixed = 1;
M_zeroshock.workfactor = 2;
SOLVE M_zeroshock using CNS;


$LOOP M_zeroshock: 
	PARAMETER {name}_infeas{sets};
	{name}_infeas{sets}$({name}.infeas{sets}<>0 and {subsets}) = {name}.l{sets};
	display {name}_infeas;
$ENDLOOP
@assert_no_difference(G_EndoAndExo,1e-8);
$exit


	#  $FIX G_exo;
	#  $UNFIX G_endo;
	#  execute_unload 'output\pre.gdx';
	#  @SOLVE(M_zeroshock,1);


	PARAMETER phaseitin[t];
	phaseitin['2025'] = 0.1;
	phaseitin['2026'] = 0.3;
	phaseitin['2027'] = 0.5;
	phaseitin['2028'] = 0.7;
	phaseitin['2029'] = 0.9;
	phaseitin['2030'] = 1;
	phaseitin[t]$(t.val >2030) = 1;

	tCO2_ProdxE.l[s,t,emm]$(tCO2_ProdxE.l[s,t,emm]) = tCO2_ProdxE.l[s,t,emm] + 100*phaseitin[t];
	tCO2_REmarg.l[purpose,energy19,r,t,emm_eq]$(d1CO2_REmarg[purpose,energy19,r,t,emm_eq] and not sameas[energy19,'District heat']) 
			= tCO2_REmarg.l[purpose,energy19,r,t,emm_eq] + 100*phaseitin[t];

	#  tCO2_ProdxE.l['23001',t,'CO2ubio'] = 0;
	#  tCO2_ProdxE.l['23001',t,'CO2ubio'] =  tCO2_REmarg_SKM.l['cement_ETS',t];
	#  tCO2_ProdxE.l[s,t,'CO2ubio']$(sum((purpose,energy19), mapGrREFORM2GSR[purpose,energy19,s,'Mineralogi_oevrig',t])) =  tCO2_REmarg_SKM.l['cement_ETS',t];

	#  $FIX G_taxes_initial_values_marginal_tax_rates_exo;
	#  $UNFIX G_taxes_initial_values_marginal_tax_rates_endo;
	#  @SOLVE(M_taxes_initial_values_marginal_tax_rates);


	$FIX G_exo;
	$UNFIX G_endo;
	execute_unload 'output\pre.gdx';
  	M_zeroshock.optfile = 1;
  	M_zeroshock.holdFixed = 1;
  	M_zeroshock.workfactor = 2;
  	SOLVE M_zeroshock using CNS;

	$import report.gms

	execute_unload 'output\testshock.gdx';