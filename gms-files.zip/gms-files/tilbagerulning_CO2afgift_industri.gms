#====================================================================================================================================================================================================================#
# TILBAGERULNING AF CO2-AFGIFT PÅ INDUSTRIEN
#====================================================================================================================================================================================================================#

	#Laver baseline-værdier
	$import create_baseline_values.gms

	#Koden har følgende struktur
	# 1) Gamle afgiftsregime indlæses
	# 2) Struktur for raffinaderi og fiskeri
	# 3) Pyrolysemodellering 
	# 4) Cementstruktur
	# 5) REFORM-metoden for struktureffekter på almindelig proces (ETS/non-ETS)
	# 6) Der laves ligninger med tilføjelser til de oprindelige i modellen. Ligningerne trækker på 1)-6)
	# 7) Endelig stødmodel opstilles 

	set_time_periods(%cal_start%, %terminal_year%);

	# ----------------------------------------------------------------------------------------------------------------------
	# 1) INDLÆSNING AF AFGIFTER FØR REFORM
	# ----------------------------------------------------------------------------------------------------------------------

		#Genindfører bundfradrag på CO2-afgift efter 2025
		d1BotdedCO2post25 = 1;


		$PGROUP PSAVE_taxes_2022reform
			tEAFG_REmarg_SKM_2022[tREbase_SKM,t]
			tCO2_REmarg_SKM_2022[tREbase_SKM,t]
		;

			tEAFG_REmarg_SKM_2022[tREbase_SKM,t] = tEAFG_REmarg_SKM.l[tREbase_SKM,t]; 
			tCO2_REmarg_SKM_2022[tREbase_SKM,t]  = tCO2_REmarg_SKM.l[tREbase_SKM,t] ; 

		#Her indlæses excelark fra gamle afgiftsregime
		$OnMultiR
			$call gdxxrw.exe I="%MargTaxesBefore2022%.xlsx" O="%MargTaxesBefore2022%.gdx" par=tEAFG_REmarg_SKM_in rng=Energi!A1:S20 par=tSO2_REmarg_SKM_in rng=SO2_done!A1:O29 par=tCO2_REmarg_SKM_in rng=CO2_done!A1:T25
			$gdxin "%MargTaxesBefore2022%.gdx"
			$onUNDF
			$load tEAFG_REmarg_SKM_in tSO2_REmarg_SKM_in tCO2_REmarg_SKM_in
			$gdxin
		$OffMulti
	
	
		$GROUP G_save_taxes tCO2_REmarg$(tx0[t]), tEAFG_REmarg$(tx0[t]); 
		@Save_as(G_save_taxes,_savetaxes);

	
		$FUNCTION set_marginaltaxes():

			tEAFG_REmarg_SKM.l(tREbase_SKM,t)      = tEAFG_REmarg_SKM_in(tREbase_SKM,t); 
			tEAFG_REmarg_SKM.l('el_ikke-proces',t) = tEAFG_REmarg_SKM.l('el_privat',t);
			#tEAFG_REmarg_SKM.l('el_ikke-proces',t)= tEAFG_REmarg_SKM.l('el_proces',t);


			tCO2_REmarg_SKM.l(tREbase_SKM,t)       = tCO2_REmarg_SKM_in(tREbase_SKM,t); 
			tCO2_REmarg_SKM.l('el_ikke-proces',t)  = tCO2_REmarg_SKM.l('el_privat',t);


			# Afgiftssatserne skal tolkes som en pris, og skal derfor inflationskorrigeres, når de kommer ind i modellen.  
			#  tEAFG_REmarg_SKM.l(tREbase_SKM,t) = tEAFG_REmarg_SKM.l(tREbase_SKM,t)*inf_factor[t]; 
			#  tSO2_REmarg_SKM.l(tREbase_SKM,t)  = tSO2_REmarg_SKM.l(tREbase_SKM,t)*inf_factor[t];  
			#  tCO2_REmarg_SKM.l(tREbase_SKM,t)  = tCO2_REmarg_SKM.l(tREbase_SKM,t)*inf_factor[t];  

			#AKB: Vi inflationskorrigerer med skats inflationsfaktor for at få samme satser i 2021 som skat (341 pr tCO2)
			tEAFG_REmarg_SKM.l(tREbase_SKM,t) = tEAFG_REmarg_SKM.l(tREbase_SKM,t)*fp**(t.val-2021)/((1.019)**(t.val-2021))*inf_factor[t];
			tCO2_REmarg_SKM.l(tREbase_SKM,t)  = tCO2_REmarg_SKM.l(tREbase_SKM,t)*fp**(t.val-2021) /((1.019)**(t.val-2021))*inf_factor[t];

			#Efter 2030 antages det, at afgifterne indekseres, så de følger prisudviklingen, hvormed de ikke skal inflationskorrigeres.
			tEAFG_REmarg_SKM.l(tREbase_SKM,t) $ (ord(t) GT (2030+1-1967))   = tEAFG_REmarg_SKM.l(tREbase_SKM,'2030');
			tCO2_REmarg_SKM.l(tREbase_SKM,t)  $ (ord(t) GT (2030+1-1967))   = tCO2_REmarg_SKM.l(tREbase_SKM,'2030');

			#Dog indekseres elafgiften på proces-el ikke, hvormed den inflationskorrigeres.
			tEAFG_REmarg_SKM.l('el_proces',t) $ (ord(t) GT (2030+1-1967))   = tEAFG_REmarg_SKM.l('el_proces','2030')*inf_factor[t]/inf_factor['2030'];
			tEAFG_REmarg_SKM.l('proces',t) $ (ord(t) GT (2030+1-1967))      = tEAFG_REmarg_SKM.l('proces','2030')*inf_factor[t]/inf_factor['2030'];
			tEAFG_REmarg_SKM.l('proces_ets',t) $ (ord(t) GT (2030+1-1967))  = tEAFG_REmarg_SKM.l('proces_ets','2030')*inf_factor[t]/inf_factor['2030'];
			tEAFG_REmarg_SKM.l('landbrug',t) $ (ord(t) GT (2030+1-1967))    = tEAFG_REmarg_SKM.l('landbrug','2030')*inf_factor[t]/inf_factor['2030'];
			tEAFG_REmarg_SKM.l('gartner_ETS',t) $ (ord(t) GT (2030+1-1967)) = tEAFG_REmarg_SKM.l('gartner_ETS','2030')*inf_factor[t]/inf_factor['2030'];

			#HACK: Vi indekserer dog efter 2050 for at få pæne shock/baseline-forløb, når vi laver SKM-stød
			tEAFG_REmarg_SKM.l('el_proces',t)$(t.val >=2050)   = tEAFG_REmarg_SKM.l('el_proces','2050');
			tEAFG_REmarg_SKM.l('proces',t)$(t.val >=2050)      = tEAFG_REmarg_SKM.l('proces','2050');
			tEAFG_REmarg_SKM.l('proces_ets',t) $(t.val >=2050) = tEAFG_REmarg_SKM.l('proces_ets','2050'); 
			tEAFG_REmarg_SKM.l('landbrug',t)$(t.val >=2050)    = tEAFG_REmarg_SKM.l('landbrug','2050');
			tEAFG_REmarg_SKM.l('gartner_ETS',t)$(t.val >=2050) = tEAFG_REmarg_SKM.l('gartner_ETS','2050');

			#Antager at det er en fejl, at denne ikke har samme sats før/efter reform
			tEAFG_REmarg_SKM.l('el_privat',t) = tEAFG_REmarg_SKM_2022('el_privat',t);

			$IF %saerbehandl_mineralogi%==0:
				tCO2_REmarg_SKM.l('cement_ETS',t) = tCO2_REmarg_SKM.l('proces_ETS',t);
			$ENDIF
			
		# ----------------------------------------------------------------------------------------------------------------------
		# Overskriver afgiftssatser med satser fra før reform på industri
		# ----------------------------------------------------------------------------------------------------------------------

			# Loading marginal rates via mappings'

			  tEAFG_REmarg.l[purpose,energy19,s,t]$(not sameas[energy19,'District heat']) = 0;
 			  tEAFG_REmarg.l[purpose,energy19,s,t]$(not sameas[energy19,'District heat']) = sum((categoryENS,GSR_ag,tREbase_SKM)$(sENS2GR(categoryENS, GSR_ag, purpose, energy19, s) and tREbase_SKM_2_ENS(tREbase_SKM,categoryENS,GSR_ag,energy19) and d1qREgj[purpose,energy19,s,t] and not sameas[energy19,'Jet petroleum']), tEAFG_REmarg_SKM.l[tREbase_SKM,t]);
  		      tEAFG_REmarg.l[purpose_xt,'electricity','64000',t]$(d1qREgj[purpose_xt,'electricity','64000',t]) = tEAFG_REmarg_SKM_2022['el_ikke-proces',t]; 
  		      #Finansiel sektor (strengt taget momsfritagne/lønsumsomfattede vsh) betaler fuld elafgift, jf. mail fra Sebastian Lind SKM d. 22.5.2024. Kh AKB. Vi sætter satsen til den gamle sats, selvom det nok ville være mere rigtigt at sætte den gamle til den nye
		  
			  # Test of energy taxes
			      LOOP((purpose,energy19,s),
			        tjek = tEAFG_REmarg.l[purpose,energy19,s,'2019'];
			        ABORT$(tjek > smax(tREbase_SKM,tEAFG_REmarg_SKM.l(tREbase_SKM,'2019'))) tjek, "De indlæste energiafgifter må ikke overstige max i input fra data - hvis det gør er der fejl i mappingen tREbase_SKM_2_ENS";
			        );
    	 

			  # Correction on district heat (At DST the energy tax is put on the end consumer of the district heat. At SKM the tax is put on the district heat producer's use of fossil fuel. Therefore, we cannot use the marginal "producer rate" on the end consumer bur uses instead the average from DST-data)
			  #  tEAFG_REmarg.l[purpose,'District heat',s,t]$(tEAFG_REmarg.l[purpose,'District heat',s,t]=0 and tEAFG_RE.l[purpose,'District heat',s,t]) = tEAFG_RE.l[purpose,'District heat',s,t]*1000; #We have to multiply by 1000 because the unit is kr per GJ on marginal tax-rates
			  #  tEAFG_REmarg.l[purpose,'District heat',s,tForecast] = tEAFG_REmarg.l[purpose,'District heat',s,tDataEnd]; 

			  vtEAFG_REmarg.l[purpose,energy19,r,t] = tEAFG_REmarg.l[purpose,energy19,r,t] * qREgj.l[purpose,energy19,r,t]  *10**(-3);


			  tCO2_REmarg.l[purpose,energy19,s,t,emm_eq]$(not sameas[energy19,'District heat']) = 0;
			  tCO2_REmarg.l[purpose,energy19,s,t,'CO2ubio']$(not sameas[energy19,'District heat']) = sum((categoryENS,GSR_ag,tREbase_SKM)$(sENS2GR(categoryENS, GSR_ag, purpose, energy19, s) and tREbase_SKM_2_ENS(tREbase_SKM,categoryENS,GSR_ag,energy19) and qEmmProdE.l[s,t,'CO2ubio',purpose,energy19]), tCO2_REmarg_SKM.l[tREbase_SKM,t]);
			  tCO2_REmarg.l[purpose,'Natural gas incl. biongas',s,t,'CO2bio'] 
				  = sum((categoryENS,GSR_ag,tREbase_SKM)$(sENS2GR(categoryENS, GSR_ag, purpose, 'Natural gas incl. biongas', s) and tREbase_SKM_2_ENS(tREbase_SKM,categoryENS,GSR_ag,'Natural gas incl. biongas') and qEmmProdE.l[s,t,'CO2ubio',purpose,'Natural gas incl. biongas'] and qEmmProdE.l[s,t,'CO2bio',purpose,'natural gas incl. biongas']),  tCO2_REmarg_SKM.l[tREbase_SKM,t]);

			  # Test of loaded energu taxes
			      LOOP((purpose,energy19,s),
			        # Checking for CO2ubio
			        tjek = tCO2_REmarg.l[purpose,energy19,s,'2019','CO2ubio'];
			        ABORT$(tjek > smax(tREbase_SKM,tCO2_REmarg_SKM.l(tREbase_SKM,'2019'))) tjek, "De indlæste CO2-afgifter må ikke overstige max i input fra data - hvis det gør er der fejl i mappingen tREbase_SKM_2_ENS";
			        # Checking for CO2bio
			        tjek = tCO2_REmarg.l[purpose,energy19,s,'2019','CO2bio'];
			        ABORT$(tjek > smax(tREbase_SKM,tCO2_REmarg_SKM.l(tREbase_SKM,'2019'))) tjek, "De indlæste CO2-afgifter må ikke overstige max i input fra data - hvis det gør er der fejl i mappingen tREbase_SKM_2_ENS";
			        );

			  #  # We take marginal tax-rates on district heat as the one computed from DST data  
			  #  tCO2_REmarg.l[purpose,'District heat',s,t,'CO2ubio']$(tCO2_REmarg.l[purpose,'District heat',s,t,'CO2ubio']=0 and tCO2_RE.l[purpose,'District heat',s,t]) = tCO2_RE.l[purpose,'District heat',s,t];

			  #Re-setter
			  #  vtEAFG_REmarg.l[purpose,energy19,r,t] = 0;
			  #  vtCO2_REmarg.l[purpose,energy19,r,t]  = 0;

			  $OnMultiR
			  set energy19_SKM_x[energy19];
			  $OffMulti

			  tEAFG_REmarg.l[purpose,'Waste oil','21000',t] = 0;
			  tEAFG_REmarg.l[purpose,'Waste oil','20000',t] = 0;

			  energy19_SKM_x[energy19] = yes$(energy19_SKM[energy19] and not sameas[energy19,'waste oil']);
			  vtEAFG_REmarg.l[purpose,energy19,r,t]$(d1qREgj[purpose,energy19,r,t] and energy19_SKM_x[energy19])         = tEAFG_REmarg.l[purpose,energy19,r,t]*qREgj.l[purpose,energy19,r,t]*10**(-3); #Dividerer med mio. pga. enhed - ellers sendes solveren udover kanten
			  vtCO2_REmarg.l[purpose,energy19,r,t]$(d1qREgj[purpose,energy19,r,t])                                       = sum(emm_eq, tCO2_REmarg.l[purpose,energy19,r,t,emm_eq]/10**6*growth_factor[t]*qEmmProdE.l[r,t,emm_eq,purpose,energy19]);

			  d1CO2_REmarg[purpose,energy19,r,t,emm_eq] = yes$(tCO2_REmarg.l[purpose,energy19,r,t,emm_eq]);
 		 	  d1CO2_REmarg_sumemm[purpose,energy19,r,t] = yes$(sum(emm_eq, d1CO2_REmarg[purpose,energy19,r,t,emm_eq]));

			  d1CO2_RE[purpose,energy19,r,t] = no;
			  d1CO2_RE[purpose,energy19,r,t] = yes$(d1CO2_REmarg_sumemm[purpose,energy19,r,t] and d1qREgj[purpose,energy19,r,t]); 

  			  d1EAFG_RE[purpose,energy19,r,t] = no;
  			  d1EAFG_RE[purpose,energy19,r,t] = yes$(tEAFG_REmarg.l[purpose,energy19,r,t] and d1qREgj[purpose,energy19,r,t]);
		
		      d1tRE[purpose,energy19,r,t] = no;
  			  d1tRE[purpose,energy19,r,t]               = yes$(d1qREgj[purpose,energy19,r,t] and (d1EAFG_RE[purpose,energy19,r,t] 
    	                                                                                  or d1SO2_RE[purpose,energy19,r,t] 
    	                                                                                  or d1PSO_RE[purpose,energy19,r,t] 
    	                                                                                  or d1NOx_RE[purpose,energy19,r,t] 
    	                                                                                  or d1CO2_RE[purpose,energy19,r,t] 
    	                                                                                  or d1VAT_RE[purpose,energy19,r,t] 
    	                                                                                  or d1tCO2_ETS_marg[purpose,energy19,r,t]
    	                                                                                  or d1CO2_ETS2_marg[purpose,energy19,r,t]));
			  #  LOOP((GSR_ag,t)$(tx0[t]),
			  #  	tjek = output_GSR[GSR_ag,'tmarg_imputed',t] - sum((categoryENS,purpose,energy19,s)$(sENS2GR(categoryENS, GSR_ag, purpose, energy19, s) and tREbase_SKM_2_ENS(tREbase_SKM,categoryENS,GSR_ag,energy19)), tCO2_REmarg_SKM.l[tREbase_SKM,t])/
			  #  										  		  sum((categoryENS,purpose,energy19,s)$(sENS2GR(categoryENS, GSR_ag, purpose, energy19, s) and tREbase_SKM_2_ENS(tREbase_SKM,categoryENS,GSR_ag,energy19)), 1);
			  #    ABORT$(tjek > smax(tREbase_SKM,tCO2_REmarg_SKM.l(tREbase_SKM,'2019'))) tjek, "De indlæste CO2-afgifter må ikke overstige max i input fra data - hvis det gør er der fejl i mappingen tREbase_SKM_2_ENS";
			  #  	);
			  	
		$ENDFUNCTION

		$IF %afgiftsreform%:
			@set_marginaltaxes();
		$ENDIF

		#ikk-energirelaterede udledninger
		tCO2_ProdxE.l[s,t,'CO2ubio'] = 0;
    	d1CO2_ProdxE[s,t,emm]        = yes$(tCO2_ProdxE.l[s,t,emm]);


	# ----------------------------------------------------------------------------------------------------------------------
	# 2) RAFFINADERIPRODUKTION UDVIDES TIL FØR-REFORM NIVEAU
	# ----------------------------------------------------------------------------------------------------------------------

		#Koden herunder er sakset fra GSR_1delrap_mode2SKMmarg.gms

		#==============================
		# Raffinaderier køres eksogent 
		#==============================
		Parameter d1ExoProduction[out,s], tImplement[t], ShutdownStructRaff, TechnicalRaff;

		   ShutdownStructRaff = 0;
		   d1ExoProduction[out,s] = no;

		 	$IF %Inkl_Raffinaderi_struktur%==1:
		 	  #  ShutdownStructRaff = 0.435;
		 	  ShutdownStructRaff = 0.29; #https://ens.dk/sites/ens.dk/files/Basisfremskrivning/skm_notat_om_effekter_af_aftale_om_groen_skattereform_for_industri_mv._til_kf23.pdf
		 	  
 			$ENDIF

 			 $IF %Inkl_Raffinaderi%==1:
			  d1ExoProduction('Diesel for transport','19000')   = 1;
			  d1ExoProduction('Gasoline for transport','19000') = 1;
			  d1ExoProduction('Oil products','19000')           = 1;    
			  d1ExoProduction('Jet petroleum','19000')          = 1;
			 $ENDIF

		  # Produktionen falder med 32,5 pct. ifølge ekspertgruppen (XXXX TJEK AT DET OGSÅ VAR DEN ENDELIGE REFORM EFFEKT)
		  
		  tImplement[t]      = 1;
		  tImplement['2029'] = 0.9;
		  tImplement['2028'] = 0.8;
		  tImplement['2027'] = 0.7;
		  tImplement['2026'] = 0.6;
		  tImplement['2025'] = 0.5;
	      tImplement[t] $ (t.val lt 2025) = 0;
		  tImplement['2025'] = 0.3; #Nedgangen i produktionen følger indfasningen af skatten. Dog korrigeres indfasningen en smule i 2025 (hvilket sker her).
		  #  qY_CET.l[out,s,t] $(d1ExoProduction[out,s]) = qY_CET.l[out,s,t] /(1-0.325*tImplement[t]);  
		  qY_CET.l[out,s,t] $(d1ExoProduction[out,s]) = qY_CET.l[out,s,t] /(1-ShutdownStructRaff * tImplement[t]); #Retter til 0.435 pba. Delrapport 1 figur 2.10. Jf. mail med Steffen Dockweiler er det både struktur og teknik, der er lagt ind i raffinaderierne for i KF
		  tImplement['2025'] = 0.5; #sættes tilbage


		#==============================
		# Fiskeri køres eksogent 
		#==============================
		  PARAMETER ShutdownStructFish, TechnicalFish;
		  ShutdownStructFish = 0;
		  # Produktionen falder 12 pct. ifølge ekspertgruppen. Nedgangen i produktionen følger indfasningen af skatten.
		  #  qY.l['03000',t] = qY.l['03000',t] / (1-0.12*tImplement[t]); 
		  #  qY.l['03000',t] = qY.l['03000',t] / (1-0.45*tImplement[t]); 
		  #  qY_CET.l['out_other','03000',t] = qY_CET.l['out_other','03000',t] /(1-0.475 * tImplement[t]); #Retter til 0.325 pba. delrapport 1 figur 2.10. Jf. mail med Steffen Dockweiler er det kun struktur (og ikke teknik), der er lagt ind for fiskere i GSR
		  #  qY_CET.l['out_other','03000',t] = qY_CET.l['out_other','03000',t] /(1-0.325 * tImplement[t]); #Retter til 0.325 pba. delrapport 1 figur 2.10. Jf. mail med Steffen Dockweiler er det kun struktur (og ikke teknik), der er lagt ind for fiskere i GSR
		  
		  $IF %Inkl_Fiskeri%==1:
			  ShutdownStructFish = 0.23; #https://ens.dk/sites/ens.dk/files/Basisfremskrivning/skm_notat_om_effekter_af_aftale_om_groen_skattereform_for_industri_mv._til_kf23.pdf
			  qY_CET.l['out_other','03000',t] = qY_CET.l['out_other','03000',t] /(1-ShutdownStructFish * tImplement[t]); #Fiskeri får halvdelen af afgiften i Model 1 og Model 2 i Eksertgruppens rapport. Vi regner derfor som groft slag på tasken med halv struktur+teknisk effekt
			
			#  uREExID.l['process_normal','Diesel for transport','Diesel for transport','03000',t] = 1/(1-ShutdownStructFish*tImplement[t]);
			#  uREExID.l['process_normal','Diesel for transport','Bunkering of Danish operated vessels on foreign territory','03000',t] = 1/ShutdownStructFish*tImplement[t];
			
			#  d1qREE['process_normal','Diesel for transport','Diesel for transport','03000',t] = yes; #Eksisterer allerede, men ja..
			#  d1qREE['process_normal','Diesel for transport','Bunkering of Danish operated vessels on foreign territory','03000',t] = yes;
			#  d1_qgj_tech['process_normal','Bunkering of Danish operated vessels on foreign territory','03000',t] = yes;
			#  d1tRE['process_normal','Bunkering of Danish operated vessels on foreign territory','03000',t] = yes;
			#  d1pRE_base['process_normal','Bunkering of Danish operated vessels on foreign territory','03000',t] = yes;
			#  pREagg.l['process_normal','Bunkering of Danish operated vessels on foreign territory','03000',t] = 0.1; #Initial værdi
			#  pRE_base.l['process_normal','Bunkering of Danish operated vessels on foreign territory','03000',t] = 0.1;
			#  qREgj.l['process_normal','Bunkering of Danish operated vessels on foreign territory','03000',t] = 0.1;
			#  (pRE_base[purpose,energy19,r,t]$d1pRE_base[purpose,energy19,r,t] * qREgj[purpose,energy19,r,t])

			$ENDIF


#====================================================================================================================================================================================================================#
# 3) MODELLING BIOCHAR
#====================================================================================================================================================================================================================#


  $GROUP G_Pyrolyse_endo
      rPyrolyse_gains[t]$(tx0[t])         "Unit gains of implementing technology"
      rPyrolyse_costs[t]$(tx0[t])         "Unit costs of implementing technology"
      rPyrolyse_input[t]$(tx0[t])         "Input for calculating instantaneous adoption rate (assuming normally distributed costs)"
      rPyrolyse[t]$(tx0[t])               "Instantanous technology adoption rate (without forward-looking or sluggsihness)"
      rPyrolyse_preferred[t]$(tx0[t])     "Technology adoption with forward-looking mechanism (if switch_forward_looking = 1)"
      rPyrolyse_actual[t]$(tx0[t])        "Actual technology adoption (with sluggishness, if switch_sluggish = 1)"
      qEmmPyrolyse[t]$(tx0[t])            "Abated emmisions"
      qI_Pyrolyse_levelized[t]$(tx0[t])   "LCOE of capital (quantities)"
      vI_Pyrolyse_levelized[t]$(tx0[t])   "LCOE of capital (values)"
      qK_Pyrolyse_demand[t]$(tx0[t])      "Total capital demand, implied by levelized investment demand and user cost"
      qI_Pyrolyse_tilde[t]$(tx0[t])       "Investment necessary to cover total capital demand"
      qI_Pyrolyse_actual[t]$(tx0[t])      "Actual investments that drives investment demand"
      vBiomass_Pyrolyse[t]$(tx0[t])       "Biomass demand (values)"
      qBiomass_Pyrolyse[t]$(tx0[t])       "Biomass demand (quantities)"
      vLCOE_Pyrolyse[t]$(tx0[t])          "Total LCOE (values)"
      vSubsidy_Pyrolyse[t]$(tx0[t])       "Total subsidies (values)" 
  ;

  $GROUP G_Pyrolyse_exo
      #  rPyrolyse[t]$(tx0[t])
      j_rPyrolyse[t]$(tx0[t]) ""
      #  rPyrolyse_preferred[t]$(tx0[t])
      rPyrolyse_actual[t]$(t0[t])
      PyrolysePot[t]$(tx0[t]) ""
      PyrolysePrice[t]$(tx0[t]) ""
      tSubsidy_Pyrolyse[t]$(tx0[t]) ""
      rDepr_Pyrolyse[t]$(tx0[t]) ""
      qK_Pyrolyse_demand$(t0[t]) ""
      pY_CET_baseline$(sameas[out,'Straw for energy purposes'] and sameas[s,'01011']) ""
  ;

  parameter
      switch_Pyrolyse_forward_looking
      switch_Pyrolyse_sluggish
      switch_Pyrolyse_frontloading
      uT_Pyrolyse[t]
      sigmaPyrolyse
      uBetaPyrolyse
      rhoPyrolyse
      T_Pyrolyse
      ;


  sets
      CostType_pyrolyse /
          'Capital'
          'Biomass'
          / ;

  parameter
      shPyrolysePrice_type[CostType_pyrolyse,t]
      ;


  $BLOCK B_pyrolyse

  # ADOPTION

      # Unit gains of implementing technology 
      E_rPyrolyse_gains[t]$(tx0[t]).. 
          rPyrolyse_gains[t] =E= tSubsidy_Pyrolyse[t];

      # Unit cost of implementing technology 
      E_rPyrolyse_costs[t]$(tx0[t]).. 
          rPyrolyse_costs[t] =E= shPyrolysePrice_type['Capital',t] * PyrolysePrice[t]*pI_s['iM','01011',t]/pI_s_baseline['iM','01011',t]
                               + shPyrolysePrice_type['Biomass',t] * PyrolysePrice[t];

      # Input for calculating instantaneous adoption rate (assuming normally distributed costs)
      # We add 3 to rPyrolyse_input such that 99.865 pct of the potential is adopted when rPyrolyse_gains=rPyrolyse_costs and sigmaPyrolyse=1   
      E_rPyrolyse_input[t]$(tx0[t]).. 
          rPyrolyse_input[t] =E= ((rPyrolyse_gains[t] - rPyrolyse_costs[t] + 3) - uT_Pyrolyse[t])/ sigmaPyrolyse;

      # Instantanous technology adoption rate (without forward-looking or sluggsihness)
      E_rPyrolyse[t]$(tx0[t]).. 
          rPyrolyse[t] =E= (errorf(rPyrolyse_input[t]) + j_rPyrolyse[t]);

      # Technology adoption with forward-looking mechanism (if switch_forward_looking = 1)
      E_rPyrolyse_preferred[t]$(tx0E[t])..
          rPyrolyse_preferred[t] =E= (1-switch_Pyrolyse_forward_looking)*rPyrolyse[t] 
                                   + switch_Pyrolyse_forward_looking*( (1-uBetaPyrolyse)*rPyrolyse[t]+(uBetaPyrolyse)*rPyrolyse_preferred[t+1]);

      # Terminal condition for forward-looking mechanism
      E_rPyrolyse_preferred_terminal_condition[t]$(tend[t])..
          rPyrolyse_preferred[tend] =E= rPyrolyse[tend];

      # Actual technology adoption (with sluggishness, if switch_sluggish = 1)
      E_rPyrolyse_actual[t]$(tx0[t])..
          rPyrolyse_actual[t] =E= 
              (1-switch_Pyrolyse_sluggish)*rPyrolyse_preferred[t]  
              + switch_Pyrolyse_sluggish*( exp(-sqr(rPyrolyse_preferred[t] - rPyrolyse_actual[t-1])/rhoPyrolyse)
              * (rPyrolyse_preferred[t]) 
              + (1-exp(-sqr(rPyrolyse_preferred[t] - rPyrolyse_actual[t-1])/rhoPyrolyse)) * rPyrolyse_actual[t-1]);


  # EMISSIONS

      E_qEmmPyrolyse[t]$(tx0[t])..
          qEmmPyrolyse[t] =E= rPyrolyse_actual[t]*PyrolysePot[t];


      $LOOP00 E_qEmmLU12xF:
          {name}_alt{sets}${subsets}..      {LHS} =E= {RHS} 
                                                    + qEmmPyrolyse[t]$(sameas[land12xF,'crop_u6'] and tx0[t])
                                                    ;
      $ENDLOOP00   


  # INVESTMENTS

      E_qI_Pyrolyse_levelized[t]$(tx0[t])..
          qI_Pyrolyse_levelized[t] =E= -qEmmPyrolyse[t] * growth_factor[t] * shPyrolysePrice_type['Capital',t] * PyrolysePrice[t] * 10**3 * 10**(-9);

      E_vI_Pyrolyse_levelized[t]$(tx0[t])..
          vI_Pyrolyse_levelized[t] =E= qI_Pyrolyse_levelized[t] * pI_s['iM','01011',t]/pI_s_baseline['iM','01011',t];

      # Total capital demand, implied by levelized investment demand and user cost
      E_qK_Pyrolyse_demand[t]$(tx1[t])..
          qK_Pyrolyse_demand[t-1] =E= qI_Pyrolyse_levelized[t]/pK_CCS['iM','01011',t];

      # Total capital demand, terminal condition
      E_qK_Pyrolyse_demand_terminal[t]$(tend[t])..
          qK_Pyrolyse_demand[t] =E= qK_Pyrolyse_demand[t-1];

      # Investment necessary to cover total capital demand
      E_qI_Pyrolyse_accum[t]$(tx0[t])..
          qI_Pyrolyse_tilde[t] =E= switch_Pyrolyse_frontloading    *(qK_Pyrolyse_demand[t] - (1 - rDepr_Pyrolyse[t]) * qK_Pyrolyse_demand[t-1]/fq)
                                 + (1-switch_Pyrolyse_frontloading)* qI_Pyrolyse_levelized[t];

      # Spread necessary investments evenly over T_Pyrolyse periods preceeding year of capital demand (if front-loading is activated)
      E_qI_Pyrolyse_actual[t]$(tx0[t] and (t.val<=(tend.val-T_Pyrolyse)))..
          qI_Pyrolyse_actual[t] =E= switch_Pyrolyse_frontloading    *sum(tt$(tt.val >= t.val and tt.val < t.val + T_Pyrolyse and not tt.val=2019), qI_Pyrolyse_tilde[tt])/T_Pyrolyse
                                  + (1-switch_Pyrolyse_frontloading)*qI_Pyrolyse_levelized[t];

      # Spread necessary investments evenly over T_Pyrolyse periods preceeding year of capital demand (if front-loading is activated)
      E_qI_Pyrolyse_actual_terminal[t]$(tx0[t] and (t.val>(tend.val-T_Pyrolyse)))..
          qI_Pyrolyse_actual[t] =E= switch_Pyrolyse_frontloading    *sum(tt$(tt.val >= t.val and tt.val < t.val + T_Pyrolyse and not tt.val=2019), qI_Pyrolyse_tilde[tt])/T_Pyrolyse*(T_Pyrolyse/(tend.val - t.val + 1))
                                  + (1-switch_Pyrolyse_frontloading)*qI_Pyrolyse_levelized[t];

     # CES Quantities - top-down split given prices
    E_qI_alt_pyrolyse[i,t]$(tx0[t] and k_[i])..                        qI[i,t] * pI_r[i,t-1] =E=   sum(s$d1I_s[i,s,t], (qI_s[i,s,t] + qI_ID_actual[i,s,t]$(not sameas(s,'off')) 
                                                                                                             + qI_CCS_actual[i,s,t]$(sameas(i,'iM') and (sum(techCCS, sum(emm, sum(purpose,sum(energy19, d1thetaCCS[techCCS,purpose,energy19,s,t,emm])) or d1thetaCCSxE[techCCS,s,t,emm]))))  )* pI_s[i,s,t-1]$(d1I_s[i,s,t-1]))
                                                                                    + sum((ani_sectors,TechAni,Emmtype,animals)$(sum(emm, d1ThetaAni[TechAni,ani_sectors,Emmtype,animals,t,emm])), qI_EOPCostAni_actual[i,TechAni,Emmtype,ani_sectors,animals,t]$(sameas(i,'iM')) * pI_s[i,ani_sectors,t-1]$(d1I_s[i,ani_sectors,t-1]))
                                                                                    + sum((plant_sectors,Techplant,Emmtype)$(sum(emm, d1Thetaplant[Techplant,plant_sectors,Emmtype,t,emm])), qI_EOPCostplant_actual[i,Techplant,Emmtype,plant_sectors,t]$(sameas(i,'iM')) * pI_s[i,plant_sectors,t-1]$(d1I_s[i,plant_sectors,t-1]))
                                                                                    + (pI_r[i,t-1]* qEOPcost[t])$(sameas(i,'iM'))
                                                                                    + (pI_r[i,t-1]*qI_s_vaadlaeglavbund[t])$(sameas[i,'iB'])
                                                                                    + (qI_Pyrolyse_actual[t]*pI_s['iM','01011',t-1]/pI_s_baseline['iM','01011',t-1])$(sameas[i,'iM'])
                                                                                    ;

  # BIOMASS USE

      E_vBiomass_Pyrolyse[t]$(tx0[t])..
          vBiomass_Pyrolyse[t] =E= -qEmmPyrolyse[t] * growth_factor[t] * shPyrolysePrice_type['Biomass',t] * PyrolysePrice[t] * 10**3 * 10**(-9);

      E_qBiomass_Pyrolyse[t]$(tx0[t])..
          qBiomass_Pyrolyse[t] =E= vBiomass_Pyrolyse[t] / pY_CET_baseline['Straw for energy purposes','01011',t];

      $LOOP00 E_vM_tot:
          {name}_alt{sets}${subsets}..      {LHS} =E= {RHS} 
                                                    + qBiomass_Pyrolyse[t] * pY_CET_baseline['Straw for energy purposes','01011',t]
                                                    ;
      $ENDLOOP00

      $LOOP00 E_qM_tot:
          {name}_alt{sets}${subsets}..      {LHS} =E= {RHS} 
                                                    + qBiomass_Pyrolyse[t] * pY_CET_baseline['Straw for energy purposes','01011',t-1]
                                                    ;
      $ENDLOOP00


  # TOTAL COSTS AND SUBSIDIES

      E_vLCOE_Pyrolyse[t]$(tx0[t])..
          vLCOE_Pyrolyse[t] =E= vI_Pyrolyse_levelized[t] + vBiomass_Pyrolyse[t];

      E_vSubsidy_Pyrolyse[t]$(tx0[t])..
          vSubsidy_Pyrolyse[t] =E= -qEmmPyrolyse[t] * growth_factor[t] * tSubsidy_Pyrolyse['2030'] * 10**3 * 10**(-9);


  # COST IN PRODUCTION FUNCTION

      $LOOP00 E_pPlant_netprod:
          {name}_alt{sets}${subsets}..      {LHS} =E= {RHS} 
                                                    + (vLCOE_Pyrolyse[t] - vSubsidy_Pyrolyse[t])$(sameas[plant_sectors,'01011'])
                                                    ;
      $ENDLOOP00


  $ENDBLOCK

  #Setting parameters
  switch_Pyrolyse_forward_looking = 0;
  switch_Pyrolyse_sluggish        = 0;
  switch_Pyrolyse_frontloading    = 1;
  uT_Pyrolyse[t]                  = 0;
  sigmaPyrolyse                   = 1;
  uBetaPyrolyse                   = 0.5;
  rhoPyrolyse                     = 0.8;
  T_Pyrolyse                      = 5; 
  shPyrolysePrice_type['Capital',t] = 0.5;
  shPyrolysePrice_type['Biomass',t] = 0.5;

  PyrolysePot.l[t]                        = -2000;    # Potential with 50 production facilities of 20 MW each
  PyrolysePrice.l[t]                      = 2000; # Average price per tonne of CO2 reduced with 50 production facilities
  tSubsidy_Pyrolyse.l[t]$(t.val > 2029)   = 2000; # Subsidy per tonne abated
  rDepr_Pyrolyse.l[t]                     = 1/25; # KEFM assumes that facilities have a lifespan of 25 years


#====================================================================================================================================================================================================================#
# 4) CEMENT PRODUCTION
#====================================================================================================================================================================================================================#

	$PGROUP PG_cementstr 
		ShutdownStructCement "Struktureffekt på cementproduktion som følge af GSR på industri"
	;

	$GROUP G_adj_cement 
		adj_cement[t]  ""
	;

	adj_cement.l[t] = 1;

	ShutdownStructCement = 0.38; #https://ens.dk/sites/ens.dk/files/Basisfremskrivning/skm_notat_om_effekter_af_aftale_om_groen_skattereform_for_industri_mv._til_kf23.pdf
	#In background note to the Climate Outlook 2024 (22 Fremstillings- og bygge-anlægserhverv) it is mentioned that the CO2-tax is going to reduce production by 10 pct. between 2025 and 2030

	$BLOCK B_cement_rollback
		E_qY_cement[t]$(tx0[t] and t.val>=2025 and t.val<=2030)..
			qY_CET['out_other','23001',t] =E=  (t.val-2024)/(2030-2025+1) * 1/(1-ShutdownStructCement) * qY_CET_baseline['out_other','23001',t]
										+	(1-(t.val-2024)/(2030-2025+1))        * qY_CET_baseline['out_other','23001',t];

		E_sRxE_y_23001_2025_2030[r,t]$(tx0[t] and t.val>=2025 and t.val<=2030 and d1RxE_ym[r,'23001',t] and includetheser[r])..
			sRxE_ym[r,'23001',t] =E= sRxE_ym.l[r,'23001',t] * adj_cement[t];

		E_sRxE_y_23001_after2030[r,t]$(tx0[t] and t.val>2030 and d1RxE_ym[r,'23001',t] and includetheser[r])..
			sRxE_ym[r,'23001',t] =E= sRxE_ym[r,'23001','2030'];

		E_sX_y_23001_2025_2030[t]$(tx0[t] and t.val>=2025 and t.val<=2030)..
			sX_y['xOth','23001',t] =E= sX_y.l['xOth','23001',t] * adj_cement[t];

		E_sX_y_23001_after2030[t]$(tx0[t] and t.val>2030)..
			sX_y['xOth','23001',t] =E= sX_y['xOth','23001','2030'];
	$ENDBLOCK


#====================================================================================================================================================================================================================#
# 5) SETTING UP CLOSE-FUNCTION FOR MINERAL INDUSTRY, NORMAL PROCES (ETS/NON-ETS)
#====================================================================================================================================================================================================================#

	$PGROUP PG_Process_Close 
						d1RxE_m_Shutdown_E[purpose,s,t], d1RxE_m_Shutdown_xE[s,t], d1ProcesInEts[s,t], 
							d1EncompassedbyREFORMmetode[purpose,s,t],  d1ExCludeInClose[purpose,energy19,s,t]
							d1tRE_base[purpose,energy19,s,t], d1EAFG_RE_base[purpose,energy19,s,t], d1CO2_RE_base[purpose,energy19,s,t];

	d1tRE_base[purpose,energy19,s,t]     = d1tRE[purpose,energy19,s,t];
	d1EAFG_RE_base[purpose,energy19,s,t] = d1EAFG_RE[purpose,energy19,s,t];
	d1CO2_RE_base[purpose,energy19,s,t]  = d1CO2_RE[purpose,energy19,s,t];

	$GROUP G_Process_Close 
	  rShutdown[purpose,s,t]
	  pRxE_m[r,s,t]
	  ty_cement[s,t] ""
	  vRxE_m_Shutdown_E[purpose,s,t] "Energy-related import costs of shutting down sector"
	  vRxE_m_Shutdown_xE[s,t] "Non-energy related import costs of shutting down sector"
	  vBesparetenergi[purpose,s,t] ""
	  vBesparetumiddelbarbelastning_E[purpose,s,t] ""
	  vBesparetumiddelbarbelastning_xE[s,t] ""
	  vAfloeftningvCCS_E[purpose,s,t] ""
	  vAfloeftningvCCS_xE[s,t] ""
	  vTeknikCCS_E[purpose,s,t] ""

	  afgiftssats_base_s[s,t] ""
	  afgiftssats_base_s_E[purpose,s,t] ""
	  afgiftssats_base_s_xE[s,t] ""
	  

	  afgiftssats_diff_s_E[purpose,s,t] ""
	  afgiftssats_diff_s_xE[s,t] ""
	  afgiftssats_diff_s[s,t] ""

	  umiddelbarbelastning_s[s,t] ""
	  umiddelbarbelastning_s_E[purpose,s,t] ""
	  umiddelbarbelastning_s_xE[s,t] ""


	  vRxE_m_Shutdown_correction_botded[s,t] ""
	  vRxE_m_Shutdown_top[s,t] ""

	  vRE_unaccountedREFORMmetode[purpose,energy19,s,t] ""
	  uShutdownE[purpose,s,t] ""
	  uShutdownxE[s,t] ""

	;

	$GROUP Process_Close_exo
	    rShutdown[purpose,s,t]
	    vRxE_m_Shutdown_E[purpose,s,t] "Energy-related import costs of shutting down sector"
	    vRxE_m_Shutdown_xE[s,t] "Non-energy related import costs of shutting down sector"
	    vRxE_m_Shutdown_E_baseline[purpose,s,t] "Energy-related import costs of shutting down sector"
	    vRxE_m_Shutdown_xE_baseline[s,t] "Non-energy related import costs of shutting down sector"
	    pRxE_m[r,s,t]
	    ty_cement[s,t]
	    #  vRE_baseline$(d1tRE[purpose,energy19,s,t])
	    #  qEmmProdE_baseline$(d1EmmProdE[s,t,emm_eq,purpose, energy19])
	    #  qEmmProdxE_baseline$(d1EmmProdxE[s,t,emm_eq])
	    vREa_baseline$(tx0[t])
	    qEmmProdE_baseline$(tx0[t])
	    qEmmProdxE_baseline$(tx0[t])
   	    qEmmProdE_baseline$(d1EmmProdE[s,t,emm_eq,purpose,energy19])
   	    qREgj_baseline$(d1qREgj[purpose,energy19,r,t])
   	    tvRE_baseline$(d1qREgj[purpose,energy19,r,t])
   	    tqRE_baseline$(d1qREgj[purpose,energy19,r,t])
   	    tvRE$(d1qREgj[purpose,energy19,r,t]) #Over-exo
   	    tqRE$(d1qREgj[purpose,energy19,r,t]) #Over-exo
   	    pRE_base_baseline$(d1qREgj[purpose,energy19,r,t])
   	    tCO2_ProdxE_baseline$(d1RxE_m_Shutdown_xE[s,t])
   	    vBottomDeduction_EAFG_baseline[purpose,energy19,r,t]$(d1EAFG_RE[purpose,energy19,r,t])
		vBottomDeduction_CO2_baseline[purpose,energy19,r,t]$(d1CO2_RE[purpose,energy19,r,t] and sum(emm_eq,d1CO2_REmarg[purpose,energy19,r,t,emm_eq]))
		vBottomDeduction_CO2_ETS_baseline[r,t]$(d1CO2_ETS[r,t])
		pREgj_baseline$(d1tRE[purpose,energy19,r,t])
		qREgj$(d1tRE[purpose,energy19,r,t])
		rShutdown_baseline
		pEP_baseline, qEP_baseline, pY0_baseline
		qY_baseline
		uShutdownE
		uShutdownE_baseline
		pCCS_qRE[s,energy19,purpose,t]
	;

		  $GROUP Process_Close_endo
	      vRxE_m_Shutdown_E[purpose,s,t]$(tx0[t] and d1RxE_m_Shutdown_E[purpose,s,t]) 
	      vRxE_m_Shutdown_xE[s,t]$(tx0[t] and d1RxE_m_Shutdown_xE[s,t])
	      uShutdownE$(tx0[t] and d1RxE_m_Shutdown_E[purpose,s,t])
	      uShutdownxE$(tx0[t] and d1RxE_m_Shutdown_xE[s,t])
	      j_qREgj[purpose,energy19,r,t]$(d1pREgj[purpose,energy19,r,t] and d1EncompassedbyREFORMmetode[purpose,r,t])
	  ;	


	  uShutdownE.l[purpose,s,tx0] = 1;
	  uShutdownxE.l[s,tx0] = 1;

	$GROUP G_savebaseline_Process_Close
		qEmmProdE 
		qEmmProdxE 
		qREgj 
		vRE ""
	;
		@Save_as(G_savebaseline_Process_Close,_baselineAP);


	  #HENTER NEDLUKNINGSPROFIL FRA SEH - "REFORM-metode"
	  $IMPORT STRUKTUREFFEKTER.gms;
	  	rShutdown_baseline.l[purpose,s,t]$rShutdown.l[purpose,s,t] = 1; 
	  	#Her vendes matematikken på hovedet, så vi får en udvidelse i stedet for en nedlukning 
	  	rShutdown.l[purpose,s,t]$rShutdown.l[purpose,s,t] = 1/rShutdown.l[purpose,s,t];
	  	

	  	#Tilføjer fiskeri og raffinaderi 
	  	#  rShutdown.l['process_normal','03000',t] = tImplement[t] * 1/(1-0.15);
	  	#  rShutdown.l['in_ETS','19000',t]         = tImplement[t] * 1/(1-0.1);

	  set turntheseoff_struct[s]/

	  		10020	
			10030	
			10040	
			10120	
			13150	
			16000	
			20000	
			21000	
			#  23001 #Ingen AP, der er egen branche
			23002	
			25000	
			36000	
			37000	
			41430	
			45000	
			46000	
			47000	
			49024	
			49031	
			55560	
			64000	
			71000	
			53000	
			10011	
			10012	
			10013	
			#  off	#Ingen offentlig sektor, der ikke er modelleret som resten af vshs
			/
			;

	  	#  execute_unload 'output\pre.gdx' rShutdown.l;
	  	rShutdown.l[purpose,s,t]$(not turntheseoff_struct[s]) = 0;
	  	#  rShutdown.l['process_normal','21000',t] = 0;	
	  	#  rShutdown.l['in_ETS','21000',t] = 0;

	  $IF %OnlyAP%:
	  	rShutdown.l[purpose,s,t]$(not sameas[s,'23001']) = 0;
	  $ENDIF

	  #  rShutdown.l[purpose,s,t]$(rShutdown.l[purpose,s,t]) = 1;
	  #We need a dummy for sectors where process-emissions are in ETS. 
	  #  d1EncompassedbyREFORMmetode[purpose,s,t] = yes$(rShutdown.l[purpose,s,'2030']);
	  d1EncompassedbyREFORMmetode[purpose,s,t] = yes$(rShutdown.l[purpose,s,'2030'] and d1EP[purpose,s,t]);
	  d1RxE_m_Shutdown_E[purpose,s,t]$(tx0[t] and rShutdown.l[purpose,s,'2030'] and d1EP[purpose,s,t]) = yes;
	  d1RxE_m_Shutdown_xE[s,t]$(tx0[t] and sum(purpose,rShutdown.l[purpose,s,'2030'])) = yes;

	
	  #Control set 
	  d1ExCludeInClose[purpose,energy19,s,t]            =yes; # no;



	$BLOCK B_Process_Close

	#====================================================================================================================================================================================================================#
	# Mere generel nedlukning
	#====================================================================================================================================================================================================================#

		#Den her skal i virkeligheden virke ved at skrue energiaktivitet ned..
	    E_j_qREgj_alt[purpose,energy19,s,t]$(tx0[t] and d1pREgj[purpose,energy19,s,t] and d1EncompassedbyREFORMmetode[purpose,s,t]).. 
		  	  qREgj[purpose,energy19,s,t] =E= qREa[purpose,energy19,s,t] * uShutdownE[purpose,s,t];
	
		  E_uShutdownE[purpose,s,t]$(tx0[t] and sum(energy19,d1pREgj[purpose,energy19,s,t]) and d1EncompassedbyREFORMmetode[purpose,s,t])..
		  	uShutdownE[purpose,s,t] =E= uShutdownE_baseline[purpose,s,t] * rShutdown[purpose,s,t];

		#============================

       E_vRE_unaccountedREFORMmetode[purpose,energy19,s,t]$(tx0[t] and d1pREa[purpose,energy19,s,t] and d1EncompassedbyREFORMmetode[purpose,s,t])..
       	#Energy that has not been "paid for" in the CES-production function
       	#  vRE_unaccountedREFORMmetode[purpose,energy19,s,t] =E= pREagg[purpose,energy19,s,t] * qREa[purpose,energy19,s,t]  -pRE[purpose,energy19,s,t] * qREgj[purpose,energy19,s,t];

       	#CCS is accounted for £
       	vRE_unaccountedREFORMmetode[purpose,energy19,s,t] =E= (pREa[purpose,energy19,s,t]- pCCS_qRE[s,energy19,purpose,t]) * qREa[purpose,energy19,s,t]  -pREa[purpose,energy19,s,t] * qREgj[purpose,energy19,s,t];


	    #Nedlukning af kvoteomfattede virksomheder beregnet med 'REFORM-metoden'.

	    #Energi, der ikke er omfattet af proces (ets/ikke-ets), eller mineralogi  
	    #  E_uREE_notREFORMmetode[purpose,energy19a,energy19,s,t]$(tx0[t] and (d1qREE[purpose,energy19a,energy19,s,t] or d1uREE_tech[purpose,energy19a,energy19,s,t]) and not d1EncompassedbyREFORMmetode[purpose,s,t] and not (sameas[s,'03000'] and %Inkl_Fiskeri%=1))..
	    #      uREE[purpose,energy19a,energy19,s,t] =E= uREExID[purpose,energy19a,energy19,s,t] 
	    #         + sum(techID$(d1thetaID_k[techID,purpose,energy19a,s,t] and d1thetaID[techID,purpose,energy19a,energy19,s,t]), rID_actual[techID,purpose,energy19a,s,t]*thetaID[techID,purpose,energy19a,energy19,s,t]);

	    #  E_uREE_notREFORMmetode_Fisk[purpose,energy19a,energy19,s,t]$(tx0[t] and (d1qREE[purpose,energy19a,energy19,s,t] or d1uREE_tech[purpose,energy19a,energy19,s,t]) and not d1EncompassedbyREFORMmetode[purpose,s,t] and (sameas[s,'03000'] and %Inkl_Fiskeri%=1))..
	    #      uREE[purpose,energy19a,energy19,s,t] =E= uREExID[purpose,energy19a,energy19,s,t] 
	    #         + sum(techID$(d1thetaID_k[techID,purpose,energy19a,s,t] and d1thetaID[techID,purpose,energy19a,energy19,s,t]), rID_actual[techID,purpose,energy19a,s,t]*thetaID[techID,purpose,energy19a,energy19,s,t]);



	    #For proces (ets/ikke-ets) og mineralogi lukkes andelsparametrene ned med rShutdown som angiver hvor meget af produktionen, der ikke nedlukkes. rShutdown beregnes ved REFORM-metoden
	    #  E_uREE_REFORMmetode[purpose,energy19a,energy19,s,t]$(tx0[t] and (d1qREE[purpose,energy19a,energy19,s,t] or d1uREE_tech[purpose,energy19a,energy19,s,t]) and d1EncompassedbyREFORMmetode[purpose,s,t] and not sameas[energy19,'natural gas incl. biongas'])..
	    #      uREE[purpose,energy19a,energy19,s,t] =E= 
	    #        (uREExID[purpose,energy19a,energy19,s,t] 
	    #         + sum(techID$(d1thetaID_k[techID,purpose,energy19a,s,t] and d1thetaID[techID,purpose,energy19a,energy19,s,t]), rID_actual[techID,purpose,energy19a,s,t]*thetaID[techID,purpose,energy19a,energy19,s,t])
	    #         )*(rShutdown[purpose,s,t]$(not d1ExCludeInClose[purpose,energy19,s,t]) + 1$(d1ExCludeInClose[purpose,energy19,s,t])); 

	    #  E_uREE_REFORMmetode_natgas[purpose,energy19a,energy19,s,t]$(tx0[t] and (d1qREE[purpose,energy19a,energy19,s,t] or d1uREE_tech[purpose,energy19a,energy19,s,t]) and d1EncompassedbyREFORMmetode[purpose,s,t] and sameas[energy19,'natural gas incl. biongas'])..
	    #      uREE[purpose,energy19a,energy19,s,t] =E= 
	    #        (uREExID[purpose,energy19a,energy19,s,t] 
	    #         + sum(techID$(d1thetaID_k[techID,purpose,energy19a,s,t] and d1thetaID[techID,purpose,energy19a,energy19,s,t]), rID_actual[techID,purpose,energy19a,s,t]*thetaID[techID,purpose,energy19a,energy19,s,t])
	    #         )*(rShutdown[purpose,s,t]$(not d1ExCludeInClose[purpose,energy19,s,t]) + 1$(d1ExCludeInClose[purpose,energy19,s,t])); 




	    E_qEmmProdxE_notREFORMmetode[s,t,emm]$(tx0[t] and d1EmmProdxE[s,t,emm] and not d1RxE_m_Shutdown_xE[s,t])..                 
	      qEmmProdxE[s,t,emm] =E= (qKELBM[s,t]/growth_factor[t])*uEmmProdxE[s, t, emm]*uEOPProdxE[s, t, emm];

	    #For nogle brancher tæller procesemissioner med i kvoteregnskabet. Uden nærmere information antages det indtil videre at alle procesemissionerne i disse brancher er ETS-omfattede.
	    E_qEmmProdxE_REFORMmetode[s,t,emm]$(tx0[t] and d1EmmProdxE[s,t,emm] and d1RxE_m_Shutdown_xE[s,t] and sum(purpose,rShutdown.l[purpose,s,t]))..                 
	      qEmmProdxE[s,t,emm] =E= (qKELBM[s,t]/growth_factor[t])* uShutdownxE[s,t] * uEmmProdxE[s, t, emm]*uEOPProdxE[s, t, emm];

	     E_uShutdownxE_ETS[s,t]$(tx0[t] and d1RxE_m_Shutdown_xE[s,t] and rShutdown.l['in_ETS',s,t])..
	     	uShutdownxE[s,t] =E= uShutdownxE.l[s,t] *rShutdown['in_ETS',s,t];

	     E_uShutdownxE_notETS[s,t]$(tx0[t] and d1RxE_m_Shutdown_xE[s,t] and not rShutdown.l['in_ETS',s,t])..
	     	uShutdownxE[s,t] =E= uShutdownxE.l[s,t] *sum(purpose, rShutdown[purpose,s,t])/sum(purpose, 1$(rShutdown.l[purpose,s,t]));



	     #Umiddelbar belastning, afgiftsbase og sats
		     E_afgiftssats_diff_s[s,t]$(tx0[t] and (sum(purpose,d1RxE_m_Shutdown_E[purpose,s,t]) or d1RxE_m_Shutdown_xE[s,t]))..
	     			afgiftssats_diff_s[s,t] * afgiftssats_base_s[s,t] =E= umiddelbarbelastning_s[s,t]*10**6;

		     E_afgiftssats_diff_s_E[purpose,s,t]$(tx0[t] and d1RxE_m_Shutdown_E[purpose,s,t])..
	     			afgiftssats_diff_s_E[purpose,s,t] * afgiftssats_base_s_E[purpose,s,t]     =E= umiddelbarbelastning_s_E[purpose,s,t]*10**6;

		     E_afgiftssats_diff_s_xE[s,t]$(tx0[t] and d1RxE_m_Shutdown_xE[s,t])..
	     			afgiftssats_diff_s_xE[s,t] * afgiftssats_base_s_xE[s,t] =E= umiddelbarbelastning_s_xE[s,t]*10**6;



		     E_afgiftssats_base_s_E[purpose,s,t]$(tx0[t] and d1RxE_m_Shutdown_E[purpose,s,t])..
		     		  											afgiftssats_base_s_E[purpose,s,t] =E= sum((energy19)$(d1EmmProdE[s,t,'CO2ubio',purpose,energy19] and d1RxE_m_Shutdown_E[purpose,s,t]), qEmmProdE_baseline[s,t,'CO2ubio',purpose,energy19])
		     		  																					 							   +sum((energy19)$(d1EmmProdE[s,t,'CO2bio',purpose,energy19] and sameas[energy19,'natural gas incl. biongas'] and d1RxE_m_Shutdown_E[purpose,s,t]), qEmmProdE_baseline[s,t,'CO2bio',purpose,energy19])
		     		  																					 			;

		     E_afgiftssats_base_s_xE[s,t]$(tx0[t] and d1RxE_m_Shutdown_xE[s,t])..
		     		  											afgiftssats_base_s_xE[s,t] =E=qEmmProdxE_baseline[s,t,'CO2ubio'];  		  																					 			
		     		  																					 			;

		     E_afgiftssats_base_s[s,t]$(tx0[t] and (d1RxE_m_Shutdown_xE[s,t] or sum(purpose,d1RxE_m_Shutdown_E[purpose,s,t])))..
		     		afgiftssats_base_s[s,t] =E= sum(purpose$(d1RxE_m_Shutdown_E[purpose,s,t]), afgiftssats_base_s_E[purpose,s,t]) 
		     																					 +afgiftssats_base_s_xE[s,t]$d1RxE_m_Shutdown_xE[s,t]
		     																					 ;





		     E_umiddelbarbelastning_s_E[purpose,s,t]$(tx0[t] and d1RxE_m_Shutdown_E[purpose,s,t])..
		     		umiddelbarbelastning_s_E[purpose,s,t] =E= 		(sum((energy19)$(d1EmmProdE[s,t,'CO2ubio',purpose,energy19] and d1RxE_m_Shutdown_E[purpose,s,t] and d1qREgj[purpose,energy19,s,t]),
		     		  																					  (tvRE[purpose,energy19,s,t] - tvRE_baseline[purpose,energy19,s,t]) * pRE_base_baseline[purpose,energy19,s,t] *qREgj_baseline[purpose,energy19,s,t]
		     		  																					+ (tqRE[purpose,energy19,s,t] - tqRE_baseline[purpose,energy19,s,t]) * qREgj_baseline[purpose,energy19,s,t])
		     		  																					+
		     		  																				sum((energy19)$(d1EmmProdE[s,t,'CO2bio',purpose,energy19] and sameas[energy19,'natural gas incl. biongas'] and d1RxE_m_Shutdown_E[purpose,s,t] and d1qREgj[purpose,energy19,s,t]),
		     		  																					  (tvRE[purpose,energy19,s,t] - tvRE_baseline[purpose,energy19,s,t]) * pRE_base_baseline[purpose,energy19,s,t] *qREgj_baseline[purpose,energy19,s,t]
		     		  																					+ (tqRE[purpose,energy19,s,t] - tqRE_baseline[purpose,energy19,s,t]) * qREgj_baseline[purpose,energy19,s,t])
		     		  																						)
		     																								;

		     E_umiddelbarbelastning_s_xE[s,t]$(tx0[t] and d1RxE_m_Shutdown_xE[s,t])..
		     		umiddelbarbelastning_s_xE[s,t] =E= 	 (tCO2_ProdxE[s,t,'CO2ubio']$(d1CO2_ProdxE[s,t,'CO2ubio']) - tCO2_ProdxE_baseline[s,t,'CO2ubio']) * qEmmProdxE_baseline[s,t,'CO2ubio']*growth_factor[t]/10**6	     		  																						
		     																								;



		     E_umiddelbarbelastning_s[s,t]$(tx0[t] and (sum(purpose,d1RxE_m_Shutdown_E[purpose,s,t]) or d1RxE_m_Shutdown_xE[s,t]))..
		     							umiddelbarbelastning_s[s,t] =E=	umiddelbarbelastning_s_xE[s,t]$(d1RxE_m_Shutdown_xE[s,t]) + sum(purpose,umiddelbarbelastning_s_E[purpose,s,t]$(d1RxE_m_Shutdown_E[purpose,s,t]));


	    #Additional demand for imports
		    E_vRxE_m_Shutdown_E[purpose,s,t]$(tx0[t] and d1RxE_m_Shutdown_E[purpose,s,t] and d1EP[purpose,s,t])..
		    	vRxE_m_Shutdown_E[purpose,s,t] =E= sum((energy19)$(d1pREa[purpose,energy19,s,t] and  d1EncompassedbyREFORMmetode[purpose,s,t]), 
	  	  																		      	vRE_unaccountedREFORMmetode[purpose,energy19,s,t]);

		    	;

		    #Den her bruges ikke pt og sættes bare til noget for at løse.. fjern den evt snart
		    E_vRxE_m_Shutdown_xE[s,t]$(tx0[t] and d1RxE_m_Shutdown_xE[s,t])..
		    	vRxE_m_Shutdown_xE[s,t] =E= 0.00001;

	  	  	E_vRxE_m_Shutdown_top[s,t]$(tx0[t] and d1RxE_m_Shutdown_xE[s,t]).. # or sum(purpose, d1RxE_m_Shutdown_E[purpose,s,t])))..
	  	  		vRxE_m_Shutdown_top[s,t] =E=  0.5 * umiddelbarbelastning_s_xE[s,t];
	  	  		#  pY0[s,t] =E= pY0_baseline[s,t] + 0.5 * (umiddelbarbelastning_s_xE[s,t]+ sum(purpose$(d1RxE_m_Shutdown_E[purpose,s,t]), umiddelbarbelastning_s_E[purpose,s,t]))/qY_baseline[s,t]; #Måske skal det her være qY og ikke qY_baseline...


	    # Modified output price to account for implicit tax rate
	    $LOOP00 E_pY0:
	     {name}_alt{sets}${subsets}..      {LHS} =E= {RHS} 
  													+vRxE_m_Shutdown_top[sp,t]$(d1RxE_m_Shutdown_xE[sp,t]) # or sum(purpose, d1RxE_m_Shutdown_E[purpose,s,t])) #$((d1RxE_m_Shutdown_xE[s,t] or sum(purpose,d1RxE_m_Shutdown_E[purpose,s,t])))
  													#  -sum(purpose$(d1RxE_m_Shutdown_E[purpose,s,t]), vRxE_m_Shutdown_E[purpose,s,t])
	                                               ;
	    $ENDLOOP00    



	    #  We add shut-down import costs of energy to pEP aggregate
	    $LOOP00 E_pEP:       
	    	{name}_alt{sets}${subsets}.. {LHS} =E= {RHS} 
	    			#  + vRxE_m_Shutdown_E[purpose,s,t]$(d1RxE_m_Shutdown_E[purpose,s,t] and not (sameas[purpose,'Transport'] or sameas[purpose,'intern_trans']))
	    			;
	    $ENDLOOP00

	    $LOOP00 E_pEP_trans:    
	    	  {name}_alt{sets}${subsets}.. {LHS} =E= {RHS} 
	    	  	#  + vRxE_m_Shutdown_E[purpose,sp,t]$(d1RxE_m_Shutdown_E[purpose,sp,t] and (sameas[purpose,'Transport'] or sameas[purpose,'intern_trans']))
	    	  	;
	    $ENDLOOP00


	    $LOOP00 E_qM_CET_other:
	    	{name}_alt{sets}$({subsets}).. {LHS} =E= {RHS} 
													+ vRxE_m_Shutdown_top[s,t]$(d1RxE_m_Shutdown_xE[s,t])/pM_CET['out_other',s,t]
													+ sum(purpose$(d1RxE_m_Shutdown_E[purpose,s,t]), vRxE_m_Shutdown_E[purpose,s,t])/pM_CET['out_other',s,t]
													;
	    $ENDLOOP00



	$ENDBLOCK

#====================================================================================================================================================================================================================#
# 6) Equation swaps that go across different shut-down elements 
#====================================================================================================================================================================================================================#


$GROUP G_otherswaps
	vBotdedPerAnimal[sp,t] ""
;

$BLOCK B_otherswaps 


    # GOVERNMENT BUDGET
    $LOOP00 E_vtIndirect:
        {name}_swap{sets}${subsets}..      {LHS} =E= {RHS} 
        										  $IF %pyrolyse%:
                                                  - vSubsidy_Pyrolyse[t]
                                                  $ENDIF
                                                  ;
    $ENDLOOP00 

  #FIRMS 

	#EBITDA
    $LOOP00 E_vEBITDA:
	    	{name}_swap{sets}$({subsets})..
	    		{LHS} =E= {RHS} 
	    				#Bundfradrag på dyr
	    				+ vBotdedPerAnimal[sp,t]$(ani_sectors_sp[sp])

	    				$IF %Inkl_REFORMmetode%:
	    				#Struktureffekter
    					- sum(purpose,vRxE_m_Shutdown_E[purpose,sp,t]$(d1RxE_m_Shutdown_E[purpose,sp,t]))	
						- vRxE_m_Shutdown_top[sp,t]$(d1RxE_m_Shutdown_xE[sp,t]) # or sum(purpose, d1RxE_m_Shutdown_E[purpose,sp,t]))
						$ENDIF
                                                                                             
          				$IF %pyrolyse%:
                        + vSubsidy_Pyrolyse[t]$(sameas[sp,'01011'])
                        - (vBiomass_Pyrolyse[t])$(sameas[sp,'01011'])
                       	$ENDIF
	    				;
    $ENDLOOP00

    $LOOP00 E_vGrossValAdd:
    {name}_swap{sets}${subsets}..      {LHS} =E= {RHS} 
    										  $IF %Inkl_REFORMmetode%:
    										  - sum(purpose,vRxE_m_Shutdown_E[purpose,s,t]$(d1RxE_m_Shutdown_E[purpose,s,t]))	
											  - vRxE_m_Shutdown_top[s,t]$(d1RxE_m_Shutdown_xE[s,t]) # or sum(purpose, d1RxE_m_Shutdown_E[purpose,s,t]))
											  $ENDIF

											  $IF %pyrolyse%:
                                              - (vBiomass_Pyrolyse[t])$(sameas[s,'01011'])
                                              $ENDIF
                                              ;
    $ENDLOOP00

    $LOOP00 E_vFCFE:
        {name}_swap{sets}${subsets}..      {LHS} =E= {RHS} 
        										  $IF %pyrolyse%:
                                                  - (qI_Pyrolyse_actual[t]*pI_s['iM','01011',t]/pI_s_baseline['iM','01011',t])$(sameas[sp,'01011'])
                                                  $ENDIF
                                                  ;
    $ENDLOOP00

 #     $LOOP00 E_vNFE:
 #     	{name}_swap{sets}$({subsets})..
	#  				{LHS} =E= {RHS}
	#  										 - sum(s, vRxE_m_Shutdown_top[s,t]$(d1RxE_m_Shutdown_xE[s,t]));
	#  										 #  - sum((purpose,s)$(d1RxE_m_Shutdown_E[purpose,s,t]), vRxE_m_Shutdown_E[purpose,s,t]);

	#  $ENDLOOP00
$ENDBLOCK

#====================================================================================================================================================================================================================#
# 7) SETTING UP SHOCK MODEL 
#====================================================================================================================================================================================================================#

$MODEL M_reset_GSRdel1 
	M_CCS_baseline
	#  M_zeroshock

	B_otherswaps, -E_vEBITDA,-E_vtIndirect,-E_vGrossValAdd,-E_vFCFE #,-E_vNFE


	$IF %Inkl_cement%:
		B_cement_rollback
	$ENDIF

    #STRUKTUREFFEKTER, INKL. AALBORG PORTLAND
  $IF %Inkl_REFORMmetode%:
    #  -E_uREE, E_uREE_REFORMmetode, E_uREE_REFORMmetode_natgas, E_uREE_notREFORMmetode, E_uREE_notREFORMmetode_Fisk
    E_vRE_unaccountedREFORMmetode
    -E_qEmmProdxE, E_qEmmProdxE_REFORMmetode, E_qEmmProdxE_notREFORMmetode, E_uShutdownxE_ETS, E_uShutdownxE_notETS
    E_j_qREgj_alt, E_uShutdownE

    E_vRxE_m_Shutdown_E
    E_vRxE_m_Shutdown_xE
    #  E_vRxE_m_Shutdown_correction_botded
    E_vRxE_m_Shutdown_top
    -E_pY0, E_pY0_alt
    -E_pEP, E_pEP_alt
    -E_pEP_trans, E_pEP_trans_alt
    -E_qM_CET_other, E_qM_CET_other_alt
    E_afgiftssats_diff_s_E
    E_afgiftssats_diff_s_xE

    E_umiddelbarbelastning_s
    E_umiddelbarbelastning_s_E
    E_umiddelbarbelastning_s_xE

    E_afgiftssats_base_s
    E_afgiftssats_base_s_E
    E_afgiftssats_base_s_xE

    #  E_uRE
    #  E_uPE
  
  $ENDIF


  #  B_report_taxreform



;


$GROUP G_endo 
	G_endo

	#Lukker modellen
    vLumpsum, -vGovPrimBalance 

	#B_otherswaps
    -vBotdedPerAnimal[sp,t] ""

		$IF %Inkl_Raffinaderi%:
	  	#Raffinaderiantagelsen
		  -qY_CET$(d1ExoProduction[out,s])
		  markup$(d1ExoProduction[out,s])   
		  -pY_CET$(d1vY_CET[out,s,t] and sameas[out,'semi-refined oil']), markup$(d1vY_CET[out,s,t] and sameas[out,'semi-refined oil'])
		$ENDIF

		$IF %Inkl_RaffiExoPrices%:
		  -pEtot$(tx0[t] and d1ExoProduction[energy19,'19000'])
		  pM_CET$(tx0[t] and d1ExoProduction[out,'19000'])
		$ENDIF

		$IF %Inkl_Fiskeri%:
   	  #Fiskeri
	  	sX_y$(sameas[x,'xOth'] and sameas[s,'03000']), -pY_CET$(sameas[s,'03000'] and d1vY_CET[out,s,t])
	  $ENDIF

	$IF %Inkl_REFORMmetode%:
		#AP!!!!!!!!!!!!!!!!!!!!
		Process_Close_endo
		#  uRE$((d1tRE[purpose,energy19,s,t] or d1pREown[purpose,energy19,s,t]) and not eNotInEnergyNest[purpose,energy19,s,t] and d1EncompassedbyREFORMmetode[purpose,s,t])
		#  -qRE$((d1tRE[purpose,energy19,s,t] or d1pREown[purpose,energy19,s,t]) and not eNotInEnergyNest[purpose,energy19,s,t] and d1EncompassedbyREFORMmetode[purpose,s,t])
		#  uEP$(tx0[t] and d1EP[purpose,s,t] and d1EncompassedbyREFORMmetode[purpose,s,t])
	$ENDIF

	$IF %Inkl_cement%:
		sRxE_ym$(tx0[t] and sameas[s,'23001'] and t.val>=2025 and includetheser[r] and d1RxE_ym[r,s,t])
		sX_y$(tx0[t] and sameas[s,'23001'] and t.val>=2025 and sameas[x,'xOth'])
	$ENDIF
;


$GROUP G_exo 
	G_exo 
	#Lukker modellen
   	-vLumpsum, vGovPrimBalance

	#B_otherswaps
    vBotdedPerAnimal[sp,t] ""


	$IF %Inkl_Raffinaderi%:	
	  # Raffinaderiantagelsen
	  qY_CET$(d1ExoProduction[out,s])
	  -markup$(d1ExoProduction[out,s]), - markup$(d1vY_CET[out,s,t] and sameas[out,'semi-refined oil']) 
	  pY_CET$(d1vY_CET[out,s,t] and sameas[out,'semi-refined oil'])
	$ENDIF

	$IF %Inkl_RaffiExoPrices%:
	  pEtot$(tx0[t] and d1ExoProduction[energy19,'19000'])
	  -pM_CET$(tx0[t] and d1ExoProduction[out,'19000'])
	$ENDIF

	$IF %Inkl_Fiskeri%:
	  #Fiskeri
	  -sX_y$(sameas[x,'xOth'] and sameas[s,'03000']), pY_CET$(sameas[s,'03000'] and d1vY_CET[out,s,t]), 
	$ENDIF

	$IF %Inkl_REFORMmetode%:
    #AP!!!!!!!!!!!!!!!!!!!!
   	   Process_Close_exo
 		#  	 -uRE$((d1tRE[purpose,energy19,s,t] or d1pREown[purpose,energy19,s,t]) and not eNotInEnergyNest[purpose,energy19,s,t] and d1EncompassedbyREFORMmetode[purpose,s,t])
			#  qRE$((d1tRE[purpose,energy19,s,t] or d1pREown[purpose,energy19,s,t]) and not eNotInEnergyNest[purpose,energy19,s,t] and d1EncompassedbyREFORMmetode[purpose,s,t])
  $ENDIF


  	qY_CET_baseline$(tx0[t] and sameas[s,'23001'] and sameas[out,'out_other'])

   	#Pyrolyse
   	G_Pyrolyse_exo, G_Pyrolyse_endo #Eksogeniserer al pyrolyse i grundforløb

;


# Set your start year for the shock   
$SETLOCAL start_shock_year 2023 #Year where we start the 0-shock
set_time_periods(%start_shock_year%,%terminal_year%);


$FIX G_exo;
$UNFIX G_endo;
#  execute_unload 'output\pre.gdx';
@SOLVE(M_reset_GSRdel1);
$IMPORT report.gms;


#ASSEMBLE SHOCK-MODEL 
	$GROUP G_endo 
		G_endo 
		$IF %Inkl_cement%:
		-sRxE_ym$(tx0[t] and sameas[s,'23001'] and t.val>=2025 and includetheser[r])
		-sX_y$(tx0[t] and sameas[s,'23001'] and t.val>=2025 and sameas[x,'xOth'])
		$ENDIF
	;
	
	$MODEL M_shock_GSRdel1
		M_reset_GSRdel1
		$IF %Inkl_cement%:
		-B_cement_rollback
		$ENDIF
	;


execute_unload 'Output\tilbagerulning_afgift_industri_%Name%.gdx';
$IMPORT sanitycheck.gms
@check_vBoP();

