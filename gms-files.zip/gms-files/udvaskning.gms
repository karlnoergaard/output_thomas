
$IF %stage% == "variables":

	$GROUP G_udvaskning_prices
		pN_red[KystomraadeID,t]                        "Shadow-price on leached N (bio. kr. per ktN) - in the prices equation the leached N, which is otherwise measured in tonnes per yer, is scaled to ktN per year"
 	;

	$GROUP G_udvaskning_quantities 
		qN_target[KystomraadeID_,t]                    "N-leach target for Vandrammedirektiv. Defineret som baselinebelastning 2027 fratrukket indsatsbehovet"
		qN_rodzone[KystomraadeID_,Nkilder,t]           "N from source split on sources (tonnes per year)"
		qN_indsats[KystomraadeID_,indsatserNudvask,t]  "Decided policy that will implement the vandrammedirektiv by 2027, N (tonnes per year)"
		qN_kystvand[KystomraadeID_,t]                  "Leached N to coastal area with id KystomraadeID,  N (tonnes per year) "
		qN_rodzone_agr[KystomraadeID_,plantxhort,t]    "Leached N to coastal area with id KystomraadeID from either conventionel or organic farms"
	;

	$GROUP G_udvaskning_values 
		vNred_kystomraade[KystomraadeID_,t]            "Shadow-value of fully implementing the vandramme-direktiv (bio. kr.). Taking the difference between this in shock and base therefore measures how much the shock contributes"
	;

	$GROUP G_udvaskning_other 
		sBelastning[KystomraadeID,Nkilder,t]           "Andel af belastning fordelet på kilde"
		sAgrKystomraade[KystomraadeID,t]     					 "Andel af kystområdets landbrugsareal, der er hhv. kon/øko"
		sLeachOf2TotalN                                "Only a fraction of total N leaches. Need a better understanding of this - see CRF 3D for inspiration"
		RetentionTotal[KystomraadeID]                  "Total retention i kystområde"
		jqN_rodzone[KystomraadeID,Nkilder,t]		       "J-led, der sørger for at udledningen i rodzonen matcher MST-baseline"
	;

$ENDIF


$IF %stage% == "groupcompilation":
	$GROUP G_udvaskning_endo 
		qN_kystvand$(tx0[t] and d1qN_kystvand[KystomraadeID_,t] and t.val <=2030)
		qN_rodzone$( t.val<=2030 and ((tx1[t] and sameas[Nkilder,'landbrug'] and d1qN_rodzone[KystomraadeID_,t]) or (tx0[t] and sameas[KystomraadeID_,'tot'])))
		vNred_kystomraade$(tx0[t] and t.val <=2030)
	;

	$GROUP G_udvaskning_exo 
		qPlant$(tx0[t] and t.val <=2030 and d1plant[Plant_sectors,plant_,t] and (sameas[plant_,'manure'] or sameas[plant_,'NPK']))
		pN_red[KystomraadeID,t]$(tx0[t] and d1qN_kystvand[KystomraadeID,t] and t.val <=2030)
		qN_target$(tx0[t] and not sameas[KystomraadeID_,'tot'] and t.val <=2030)

		qN_rodzone$(t.val <= 2030 and tx0[t] and (not sameas[Nkilder,'landbrug'] or (sameas[Nkilder,'landbrug'] and d1qN_rodzone[KystomraadeID_,t])) and not (t.val<=2030 and ((tx1[t] and sameas[Nkilder,'landbrug'] and d1qN_rodzone[KystomraadeID_,t]) or (tx0[t] and sameas[KystomraadeID_,'tot']))))

		qN_indsats$(tx0[t] and d1qN_kystvand[KystomraadeID_,t] and not sameas[KystomraadeID_,'tot'] and t.val <=2030)
		RetentionTotal
		jqN_rodzone$(tx1[t] and t.val <=2030 and d1qN_rodzone[KystomraadeID,t] and sameas[Nkilder,'landbrug'])
	;


	$GROUP G_udvaskning_noforecast 
  	qN_indsats
  	qN_kystvand
  	qN_rodzone
	;

$ENDIF

$IF %stage% == "equations":
  $BLOCK B_udvaskning

  # Value of N-reduction
  E_vNred_kystomraade[KystomraadeID,t]$(tx0[t] and d1qN_kystvand[KystomraadeID,t] and t.val <=2030).. 
  	# Skalerer til kt
  	vNred_kystomraade[KystomraadeID,t] =E= pN_red[KystomraadeID,t] * @cdfNorm(qN_kystvand[KystomraadeID,t],qN_target[KystomraadeID,t],0.01) * (qN_kystvand[KystomraadeID,t]-qN_target[KystomraadeID,t])/1000;
  																	# Normalfordelingen bruges som dummy. Den slår til når udvaskningen er højere end målsætningen
  	  # Total over kystområder
	  E_vN_red_kystomraade_tot[t]$(tx0[t] and t.val <=2030)..
	  	# Totalen omregnes til milliarder
	  	vNred_kystomraade['tot',t] =E= sum(KystomraadeID$(d1qN_kystvand[KystomraadeID,t]), vNred_kystomraade[KystomraadeID,t]);


  # Udledning til delopland. Bemærk vi i nedenstående dummyer både d1qN_Kystvand og sum(plantxhort, d1qN_kystvand_agr) flere steder. Dette skyldes diskrepans imellem MST og DST data. 
  # Der kommer til at opstå udledninger pba. 
  E_qN_kystvand[KystomraadeID,t]$(tx0[t] and d1qN_kystvand[KystomraadeID,t] and t.val <=2030).. 
  		qN_kystvand[KystomraadeID,t] =E= -   sum(indsatserNudvask, qN_indsats[KystomraadeID,indsatserNudvask,t])
  										 								 +   (1-RetentionTotal[KystomraadeID]) *  sum(Nkilder$(not sameas[Nkilder,'Landbrug']), qN_rodzone[KystomraadeID,Nkilder,t])
  										 								 +   (1-RetentionTotal[KystomraadeID]) *  sum(NKilder$(sameas[Nkilder,'landbrug'] and d1qN_rodzone[KystomraadeID,t]), qN_rodzone[KystomraadeID,'Landbrug',t]);
  	  # Total over kystområder
	  E_qN_kystvand_tot[t]$(tx0[t] and t.val <=2030).. qN_kystvand['tot',t] =E= sum(KystomraadeID$d1qN_kystvand[KystomraadeID,t], qN_kystvand[KystomraadeID,t]);


  E_qN_rodzone_agr[KystomraadeID,t]$(tx1[t] and t.val <=2030 and d1qN_rodzone[KystomraadeID,t])..
  	  # Udledningen til kystvand er            
  	  qN_rodzone[KystomraadeID,'Landbrug',t]/qN_rodzone[KystomraadeID,'Landbrug',t-1]
  	  	 =E= fq*(sum(plant_sectors$(d1Plant[plant_sectors,'NPK',t]), qPlant[plant_sectors,'NPK',t]) + sum(plant_sectors$(d1PLant[plant_sectors,'manure',t]), qPlant[plant_sectors,'Manure',t]))/
  	  	 	    (sum(plant_sectors$(d1Plant[plant_sectors,'NPK',t-1]), qPlant[plant_sectors,'NPK',t-1]) + sum(plant_sectors$(d1PLant[plant_sectors,'manure',t-1]), qPlant[plant_sectors,'Manure',t-1]))
  	  	 	 + jqN_rodzone[KystomraadeID,'Landbrug',t];

  #  E_qN_rodzone_agr[KystomraadeID,t]$(tx0[t] and t.val<=2030 and sum(plantxhort, d1qN_rodzone_agr[KystomraadeID,plantxhort,t]))..     
  #  	qN_rodzone[KystomraadeID,'Landbrug',t] =E= sum(PlantXhort$(d1qN_rodzone_agr[KystomraadeID,plantxhort,t]),
  #  																 qN_rodzone_agr[KystomraadeID,plantxhort,t]) + jqN_rodzone[KystomraadeID,'Landbrug',t];

  	  # Total over kystområder
	  E_qN_rodzone_tot[Nkilder,t]$(tx0[t] and t.val <=2030)..
	  	qN_rodzone['tot',Nkilder,t] =E= sum(KystomraadeID$(not sameas[Nkilder,'Landbrug']), qN_rodzone[KystomraadeID,Nkilder,t])
	  								  + sum(KystomraadeID$(sameas[Nkilder,'landbrug'] and d1qN_rodzone[KystomraadeID,t]), qN_rodzone[KystomraadeID,'Landbrug',t]);

  #  #  # N udledt i rodzonen fra landbrug. Der omregnes fra kt-N i landbrugsmodulet til t-N
  #    E_qN_rodzone_agr_plantxhort[KystomraadeID,plantXhort,t]$(tx0[t] and d1qN_rodzone_agr[KystomraadeID,plantxhort,t] and t.val <=2030).. 	
	 #   	qN_rodzone_agr[KystomraadeID,plantxhort,t] =E= sAgrKystomraade[KystomraadeID,plantXhort,t] 
	 #   												#AKB: SLEACH SHOULD BE FORECAST FROM 2018 TO LATEST DATA YEAR IN DCE, AS DCE USE sLEACH FROM LATEST DATA-YEAR IN THEIR FORECAST
	 #   												 * sLeachOf2TotalN 
	 #   												 * (qPlant[plantXhort,'NPK',t]$(d1Plant[Plantxhort,'NPK',t])+qPlant[plantXhort,'manure',t]$(d1Plant[Plantxhort,'Manure',t]))*10**6;


  #    # Total over kystområder
  #    E_qN_rodzone_agr_plantxhort_tot[plantXhort,t]$(tx0[t] and t.val <=2030)..
		#  qN_rodzone_agr['tot',plantxhort,t] =E= sum(KystomraadeID$(d1qN_rodzone_agr[KystomraadeID,plantxhort,t]), qN_rodzone_agr[KystomraadeID,plantxhort,t]);

  	  												

  $ENDBLOCK
$ENDIF 

$IF %stage% == "exogenous_values":
	
	# Skyggepris 200 kroner per kg N (Jacobsen 2017), 63 000 kroner per t N, 0.000063 mia. kr. per t N 
	pN_red.l[KystomraadeID,t] = -0.000200;
	pN_red.l[KystomraadeID,t] = -0.200; # 200 kroner per kg N = 200*10^6 kr per ktN = 0.2 mia. kr. per ktN. I skyggepris beregningerne omregnes til ktN og den endelige værdi bliver derfor mia. kr.

	# Statusbelastning indlæses før 2023
		qN_kystvand.l[KystomraadeID,t]$(t.val<=2022 and t.val >=2018)      = sum(idKystvand$KystomraadeID2idKystvand(KystomraadeID,idKystvand), udvaskningsdata[idKystvand,'Statusbelastning']);
		qN_kystvand.l[KystomraadeID,'2027']                                = sum(idKystvand$KystomraadeID2idKystvand(KystomraadeID,idKystvand), udvaskningsdata[idKystvand,'Baselinebelastning']);

		# Belastningen ændres lineært op til baseline belastning i 2027. 
		LOOP(t$(t.val>=2022 and t.val<2027),
			qN_kystvand.l[KystomraadeID,t+1] = qN_kystvand.l[KystomraadeID,t] + (qN_kystvand.l[KystomraadeID,'2027']-qN_kystvand.l[KystomraadeID,'2022'])/5;
			);

		# Efter 2027 trækkes belastningen flad
		qN_kystvand.l[KystomraadeID,t]$(t.val >2027) = qN_kystvand.l[KystomraadeID,'2027'];
		qN_kystvand.l['tot',t] 											 = sum(KystomraadeID, qN_kystvand.l[KystomraadeID,t]);

	# De forventede 2027-indsatser indlæses
		qN_indsats.l[KystomraadeID,indsatserNudvask,'2027']   = sum(idKystvand$KystomraadeID2idKystvand(KystomraadeID,idKystvand), udvaskningsdata[idKystvand,indsatserNudvask]);

		qN_indsats.l[KystomraadeID,'MaalrettetRegulering3500','2027'] = 0; # Vi kalibrerer til et baseline, hvor målrettet regulering ikke er brugt.		
		qN_indsats.l[KystomraadeID,'MaalrettetRegulering3000','2027'] = 0; # Vi kalibrerer til et baseline, hvor målrettet regulering ikke er brugt.		

		# Der trækkes en lineær indfasning af alle indsatserne frem til 2027
		LOOP(t$(t.val>=2022 and t.val<2027),
			qN_indsats.l[KystomraadeID,indsatserNudvask,t+1]  				= qN_indsats.l[KystomraadeID,indsatserNudvask,t] + qN_indsats.l[KystomraadeID,indsatserNudvask,'2027']/5;
			);
		qN_indsats.l[KystomraadeID,indsatserNudvask,t]$(t.val>2027) = qN_indsats.l[KystomraadeID,indsatserNudvask,'2027'];


	# Indlæser fordelingen af N-belastning på kilder
		sBelastning.l[KystomraadeID,Nkilder,t]$(sum(idKystvand$KystomraadeID2idKystvand(KystomraadeID,idKystvand), udvaskningsdata[idKystvand,'Areal']))
											            = sum(idKystvand$KystomraadeID2idKystvand(KystomraadeID,idKystvand), udvaskningsdata[idKystvand,nKilder]*udvaskningsdata[idKystvand,'Areal'])
															    /sum(idKystvand$KystomraadeID2idKystvand(KystomraadeID,idKystvand), udvaskningsdata[idKystvand,'Areal']);
	
	# Indlæser retentionen. Den aggregeres en smule fra idKystvand -> KystomraadeID
		RetentionTotal.l[KystomraadeID]$(sum(idKystvand$KystomraadeID2idKystvand(KystomraadeID,idKystvand), udvaskningsdata[idKystvand,'Areal']))                     
															    = (sum(idKystvand$KystomraadeID2idKystvand(KystomraadeID,idKystvand), udvaskningsdata[idKystvand,'Retention'] * udvaskningsdata[idKystvand,'Areal'])
															    /sum(idKystvand$KystomraadeID2idKystvand(KystomraadeID,idKystvand), udvaskningsdata[idKystvand,'Areal']))/100;

	# AKB: DST HAR IKKE OPDATERET MAPPING, HVILKET NOK ER GRUNDEN TIL AT DER OPSTÅR KYSTOMRAADER UDEN RENTENTION!
		PARAMETER noretention[KystomraadeID];
		noretention[KystomraadeID] 										  = yes$(RetentionTotal.l[KystomraadeID]=0);

	# Udvaskningen i rodzonen på Nkilder beregnes
		qN_rodzone.l[KystomraadeID,Nkilder,t]           = qN_kystvand.l[KystomraadeID,t]*sBelastning.l[KystomraadeID,Nkilder,t]/(1-RetentionTotal.l[KystomraadeID]);
		qN_rodzone.l['tot',Nkilder,t]                   = sum(KystomraadeID, qN_rodzone.l[KystomraadeID,Nkilder,t]);

	# Målvariabel defineres
		qN_target.l[KystomraadeID,t]                    = sum(idKystvand$KystomraadeID2idKystvand(KystomraadeID,idKystvand), udvaskningsdata[idKystvand,'Baselinebelastning'])
															  										- sum(idKystvand$KystomraadeID2idKystvand(KystomraadeID,idKystvand), udvaskningsdata[idKystvand,'FordeltIndsatsbehov']);

	# FRA DST
	#  	# Nogle få små kystvandoplande er ikke opdelt kon/øko. De henføres alle til konventionel
	#  	data_LGT_kystvand_kon[KystomraadeID,LGTkystvandCols_plant]$((data_LGT_kystvand_kon[KystomraadeID,LGTkystvandCols_plant]=0) and data_LGT_kystvand_oek[KystomraadeID,LGTkystvandCols_plant]=0) 
	#  		= data_LGT_kystvand_tot[KystomraadeID,LGTkystvandCols_plant];

	#  # Fordelingen af bedrifter på kystvandopland, kon:
	#  	sAgrKystomraade.l[KystomraadeID,'01011','2018']$(sum((KystomraadeID_a,LGTkystvandCols_plant),data_LGT_kystvand_kon[KystomraadeID,LGTkystvandCols_plant]))
	#  		              = sum(LGTkystvandCols_plant,data_LGT_kystvand_kon[KystomraadeID,LGTkystvandCols_plant])/sum((KystomraadeID_a,LGTkystvandCols_plant),data_LGT_kystvand_kon[KystomraadeID_a,LGTkystvandCols_plant]);

	#  # Fordelingen af bedrifter på kystvandopland, øko:
	#  	sAgrKystomraade.l[KystomraadeID,'01012','2018']$(sum((KystomraadeID_a,LGTkystvandCols_plant),data_LGT_kystvand_oek[KystomraadeID,LGTkystvandCols_plant]))
	#  		              = sum(LGTkystvandCols_plant,data_LGT_kystvand_oek[KystomraadeID,LGTkystvandCols_plant])/sum((KystomraadeID_a,LGTkystvandCols_plant),data_LGT_kystvand_oek[KystomraadeID_a,LGTkystvandCols_plant]);


		#  bAgrKystomraade.l = -0.0001;

    # INITIALVÆRDIER
    	# We calculate leached N as a fixed proportion of applied N (needs to be investigated if this is a good assumption)
    	sLeachOf2TotalN.l = qN_rodzone.l['tot','Landbrug',tDataEnd]/(sum(plant_sectors, qPlant.l[plant_sectors,'NPK',tDataEnd]+qPlant.l[plant_sectors,'manure',tDataEnd])*10**6);

   		#  qN_rodzone_agr.l[KystomraadeID,plantxhort,t] = sAgrKystomraade.l[KystomraadeID,plantXhort,t] * sLeachOf2TotalN.l*  (qPlant.l[plantXhort,'NPK',t]+qPlant.l[plantXhort,'manure',t])*10**6;
    	#  qN_rodzone.l[KystomraadeID,'Landbrug',t]     = sum(plantXhort, qN_rodzone_agr.l[KystomraadeID,plantxhort,t]);


	# Dummies 
	d1qN_rodzone_agr[KystomraadeID,plantxhort,t]  = yes$(qN_rodzone_agr.l[KystomraadeID,plantxhort,t]);
	d1qN_kystvand[KystomraadeID_,t]               = yes$(qN_kystvand.l[KystomraadeID_,t]);
	d1qN_rodzone[KystomraadeID_,t]                = yes$(qN_rodzone.l[KystomraadeID_,'landbrug',t]);

	# Før vi gemmer data trækker vi indsatser fra 
	qN_kystvand.l[KystomraadeID,t] = qN_kystvand.l[KystomraadeID,t] - sum(indsatserNudvask, qN_indsats.l[KystomraadeID,indsatserNudvask,t]);
	qN_kystvand.l['tot',t]  	     = sum(KystomraadeID, qN_kystvand.l[KystomraadeID,t]);

	$GROUP G_udvaskning_data
	  qN_indsats
	  qN_kystvand
	  qN_rodzone
	;


$ENDIF


$IF %stage% == "static_calibration":
	$GROUP G_udvaskning_static_calibration
		G_udvaskning_endo
		-qN_rodzone$(sameas[Nkilder,'landbrug'] and not sameas[Kystomraadeid_,'tot']), jqN_rodzone$(sameas[Nkilder,'landbrug'])
		-sAgrKystomraade #, j_sAgrKystomraade
	;

	$GROUP G_udvaskning_static_calibration_exo 
		G_udvaskning_exo
		qN_rodzone$(sameas[Nkilder,'landbrug'] and not sameas[Kystomraadeid_,'tot']), -jqN_rodzone$(sameas[Nkilder,'landbrug'])
		sAgrKystomraade #, -j_sAgrKystomraade
	;

	$MODEL M_udvaskning_static_calibration 
		B_udvaskning
	;
	
$ENDIF


$IF %stage% == "dynamic_calibration":
	$GROUP G_udvaskning_calib
		G_udvaskning_endo
		# We want baseline leaching to match the leaching predicted by MST in Vandmiljøplanerne 2023-2027
		-qN_rodzone$(sameas[Nkilder,'landbrug']), jqN_rodzone$(sameas[Nkilder,'landbrug'])
	;

	$GROUP G_udvaskning_calib_exo 
		G_udvaskning_exo
		qN_rodzone$(sameas[Nkilder,'landbrug']), -jqN_rodzone$(sameas[Nkilder,'landbrug'])
	;

	$MODEL M_udvaskning_calib 
		B_udvaskning
	;
	
$ENDIF
