

  #Bio-diesel 
  d1vM_CET['Biodiesel','19000',t] = 1;

  #Also from aggregates.gms
  d1vY_CET[out,s,t]             = yes$(pY_CET.l[out,s,t]);
  d1vM_CET[out,s,t]             = yes$(pM_CET.l[out,s,t]);
  d1qY_CET[out,s,t]             = yes$(qY_CET.l[out,s,t]);
  d1qM_CET[out,s,t]             = yes$(qM_CET.l[out,s,t]);

  #Energy-markets clearing 
  d1vE_onesupplier[energy19,t]  = yes$(sum(s,1$d1vY_CET[energy19,s,t]) + sum(s, 1$d1vM_CET[energy19,s,t]) = 1);  

  d1vE_onesupplier['Natural gas (Extraction)',tData]    = 1; 
  d1vE_onesupplier['Crude oil',tData]                   = 1; # North-sea
  d1vE_onesupplier['Semi-refined oil',tData]            = 1; # Bi-products in refineries
  d1vE_onesupplier['Gasoline for transport',tData]      = 1; # Bi-products in refineries
  d1vE_onesupplier['Diesel for transport',tData]        = 1; # Bi-products in refineries
  d1vE_onesupplier['Jet petroleum',tData]               = 1; # Bi-products in refineries
  d1vE_onesupplier['Oil products',tData]                = 1; # Bi-products in refineries
  d1vE_onesupplier['Biodiesel',tData]                   = 1; #Er allerede 1, men sÃ¦ttes for en god ordens skyld
  d1pEtot[energy19,t]           = yes$(sum(s, pY_CET.l[energy19,s,t] + pM_CET.l[energy19,s,t]));

  #Initial values 
      pEtot.l[energy19,t]$((sum(s, qY_CET.l[energy19,s,t]$d1vY_CET[energy19,s,t] + qM_CET.l[energy19,s,t]$d1vM_CET[energy19,s,t]) + qRENEWABLE.l[energy19,t]))
      = sum(s, pY_CET.l[energy19,s,t] * qY_CET.l[energy19,s,t]$d1vY_CET[energy19,s,t] + pM_CET.l[energy19,s,t] * qM_CET.l[energy19,s,t]$d1vM_CET[energy19,s,t])/(sum(s, qY_CET.l[energy19,s,t]$d1vY_CET[energy19,s,t] + qM_CET.l[energy19,s,t]$d1vM_CET[energy19,s,t]) + qRENEWABLE.l[energy19,t]);
    qEtot.l[energy19,t] = sum(s$d1vY_CET[energy19,s,t], qY_CET.l[energy19,s,t]) + sum(s$d1vY_CET[energy19,s,t], qM_CET.l[energy19,s,t]);


    sY_AGG.l[energy19,s,t]$((sum(ss$d1vY_CET[energy19,ss,t], qY_CET.l[energy19,ss,t]) + sum(ss$d1vM_CET[energy19,ss,t], qM_CET.l[energy19,ss,t]))) 
      = qY_CET.l[energy19,s,t]/(sum(ss$d1vY_CET[energy19,ss,t], qY_CET.l[energy19,ss,t]) + sum(ss$d1vM_CET[energy19,ss,t], qM_CET.l[energy19,ss,t])) * pY_CET.l[energy19,s,t] ** (eAGG.l[energy19]);

    sM_AGG.l[energy19,s,t]$((sum(ss$d1vY_CET[energy19,ss,t], qY_CET.l[energy19,ss,t]) + sum(ss$d1vM_CET[energy19,ss,t], qM_CET.l[energy19,ss,t]))) 
      = qM_CET.l[energy19,s,t]/(sum(ss$d1vY_CET[energy19,ss,t], qY_CET.l[energy19,ss,t]) + sum(ss$d1vM_CET[energy19,ss,t], qM_CET.l[energy19,ss,t])) * pM_CET.l[energy19,s,t] ** (eAGG.l[energy19]);



#  #FROM IO.GMS
  pRE_base_marg.l[purpose,energy19,r,t] = pEtot.l[energy19,t];

# FROM TAXES.GMS
  d1CO2_ETS[r,t]          = yes$(vtCO2_ETS.l[r,t] or sum(energy19,d1EmmProdE[r,t,'CO2ubio','IN_ETS',energy19] or d1EmmProdE[r,t,'CO2bio','IN_ETS','Natural gas incl. biongas'])); # There's currently a discrepancy between energy-use in purpose 'in_ETS' and quota-payments. There is, for instance, only payments from horticulture whereas all agricutural sectors have ETS-consumption. It is being investigated with DST why this is the case.

  d1tCO2_ETS_marg[purpose,energy19,r,t] = no;   #We assume that only CO2-emissions (and not the very small emissions of methane and N2O from incomplete combustion is in the ETS)
  d1tCO2_ETS_marg[purpose,energy19,r,t]$((d1EmmProdE[r,t,'CO2ubio',purpose,energy19] 
                                      or (d1EmmProdE[r,t,'CO2bio',purpose,energy19] and sameas[energy19,'Natural gas incl. biongas'])) 
                                          and d1CO2_ETS[r,t] and sameas[purpose,'in_ETS']) = yes;

  d1tRE[purpose,energy19,r,t]               = no;
                                                                              #Hvis der er et energiforbrug i sidste dataperiode regner vi med at der også er i vores første bud på en fremskrivning
  d1tRE[purpose,energy19,r,t]               = yes$(d1qREgj[purpose,energy19,r,t] and (d1EAFG_RE[purpose,energy19,r,t] 
                                                                                          or d1SO2_RE[purpose,energy19,r,t] 
                                                                                          or d1PSO_RE[purpose,energy19,r,t] 
                                                                                          or d1NOx_RE[purpose,energy19,r,t] 
                                                                                          or d1CO2_RE[purpose,energy19,r,t] 
                                                                                          or d1VAT_RE[purpose,energy19,r,t] 
                                                                                          or d1tCO2_ETS_marg[purpose,energy19,r,t]
                                                                                          or d1CO2_ETS2_marg[purpose,energy19,r,t]));

  #ETS 
  d1CO2_CE_ETS2[purpose,energy19,t] = no;
  d1CO2_CE_ETS2[purpose,energy19,t] = yes$(tCO2_ETS2.l[t] and (sameas[purpose,'transport'] or sameas[purpose,'heating']) and energy19fosxbunk[energy19] and qEmmConsE.l[tDataEnd,'CO2ubio',purpose,energy19]);


  d1pREgj[purpose,energy19,r,t]   = no;
  d1pREgj[purpose,energy19,r,t] 	= yes$(d1tRE[purpose,energy19,r,t] or d1pRE_base[purpose,energy19,r,t] or d1pREown[purpose,energy19,r,t]);
  d1vREgj[purpose,energy19,r,t]		= yes$(d1pREgj[purpose,energy19,r,t] and d1qREgj[purpose,energy19,r,t]);

# ENERGY_MARKETS.GMS 
  d1vREE_transport[purpose,energy19a,energy19,s,t] = yes$(d1qREE_transport[purpose,energy19a,energy19,s,t] and d1pREgj[purpose,energy19,s,t]);

  d1pREa[purpose,energy19,s,t]    = no;
  #  d1pREa[purpose,energy19,s,t] 		= yes$( (d1pREgj[purpose,energy19,s,t] and not (sameas[purpose,'transport'] and (sameas[energy19,'Diesel for transport'] or sameas[energy19,'Gasoline for transport'] or sameas[energy19,'Biodiesel'] or sameas[energy19,'Bioethanol']))) 
  #                                           or
  #                                         (d1pREgj[purpose,energy19,s,t] and (sameas[purpose,'transport']     and (sameas[energy19,'Diesel for transport'] or sameas[energy19,'Gasoline for transport'] or sameas[energy19,'Biodiesel'] or sameas[energy19,'Bioethanol']))
  #                                                                        and sum(energy19a$(sameas[energy19,energy19a]), d1vREE_transport[purpose,energy19a,energy19,s,t]))); #AKB: The "sameas" means that we only allow pREa where there is an entry on the diagonal for transport, eg. diesel <-> diesel and hence not diesel <-> biodiesel

  d1pREa[purpose,energy19,r,t]     = yes$(d1pREgj[purpose,energy19,r,t]);
  d1pREa[purpose,'Biodiesel',s,t]$( sENS2GR('vejtransport','vejtransport',purpose,'Diesel for transport',s)   and d1pREgj[purpose,'Biodiesel',s,t]  and d1pREgj[purpose,'Diesel for transport',s,t])   = no;
  d1pREa[purpose,'Bioethanol',s,t]$(sENS2GR('vejtransport','vejtransport',purpose,'Gasoline for transport',s) and d1pREgj[purpose,'Bioethanol',s,t] and d1pREgj[purpose,'Gasoline for transport',s,t]) = no;

    #Energy-activity
      qREa.l[purpose,energy19,r,t]  = EN_qRE[purpose,energy19,r,t];
      qREa.l[purpose,'Diesel for transport',r,t]$(sENS2GR('vejtransport','vejtransport',purpose,'Diesel for transport',r) and qREa.l[purpose,'diesel for transport',r,t] and qREa.l[purpose,'Biodiesel',r,t]) = qREa.l[purpose,'Diesel for transport',r,t] + qREa.l[purpose,'biodiesel',r,t];
      qREa.l[purpose,'biodiesel',r,t]$(sENS2GR('vejtransport','vejtransport',purpose,'Diesel for transport',r) and qREa.l[purpose,'diesel for transport',r,t] and qREa.l[purpose,'Biodiesel',r,t]) = 0;
  
      qREa.l[purpose,'Gasoline for transport',r,t]$(sENS2GR('vejtransport','vejtransport',purpose,'Gasoline for transport',r) and qREa.l[purpose,'Gasoline for transport',r,t] and qREa.l[purpose,'Bioethanol',r,t]) = qREa.l[purpose,'Gasoline for transport',r,t] + qREa.l[purpose,'Bioethanol',r,t];
      qREa.l[purpose,'Bioethanol',r,t]$(sENS2GR('vejtransport','vejtransport',purpose,'Gasoline for transport',r) and qREa.l[purpose,'Gasoline for transport',r,t] and qREa.l[purpose,'Bioethanol',r,t]) = 0;
  


  #Initial values 
  tCO2_ETS_GJ.l[purpose,energy19,r,t]$(d1tCO2_ETS_marg[purpose,energy19,r,t])              = tCO2_ETS.l[t]/10**6 * uEmmHardCoded['CO2ubio',energy19];
  tCO2_ETS2_GJ.l[purpose,energy19,r,t]$(d1CO2_ETS2_marg[purpose,energy19,r,t])             = tCO2_ETS2.l[t]/10**6 * uEmmHardCoded['CO2ubio',energy19];


#FROM PRODUCTION.GMS

  d1EP[purpose,s,t]                 = yes$(sum(energy19a, d1pREa[purpose,energy19a,s,t] and not eNotInEnergyNest[purpose,energy19a,s,t]));
  d1Etrans[s,t] = no; d1Etrans[s,t] = yes$(sum(purpose$(sameas[purpose,'transport'] or sameas[purpose,'intern_trans']), d1EP[purpose,s,t]));
  d1E[s,t]      = no;      d1E[s,t] = yes$(sum(purpose$(not (sameas[purpose,'transport'] or sameas[purpose,'intern_trans'])), d1EP[purpose,s,t]));

  
  # Initial values
  qEP.l[purpose,s,t]          = sum(energy19$(d1pREa[purpose,energy19,s,t]), qREa.l[purpose,energy19,s,t]);
  qE.l[s,t]                   = sum(purpose, qEP.l[purpose,s,t]);

  pREa.l[purpose,energy19,s,t]$(d1pREa[purpose,energy19,s,t]) = 1;
  pREgj.l[purpose,energy19,s,t]$(d1pREgj[purpose,energy19,s,t]) = 1;

    # Energy
    qProd.l['Etrans',sp,t]             = sum(purpose$(sameas[purpose,'Transport'] or sameas[purpose,'intern_trans']), qEP.l[purpose,sp,t]);
    qProd.l['Eother',sp,t]              = sum(purpose, qEP.l[purpose,sp,t]);

    pProd.l['Eother',sp,tData]  = 1;
    pProd.l['Etrans',sp,t]$(sum(purpose$(sameas[purpose,'Transport'] or sameas[purpose,'intern_trans']), qEP.l[purpose,sp,t])) = 1; 

    pProd.l[prd,sp,'2018']$(prdNest(prd)) = 1;
    pProd.l[prd,sp,'2019']$(prdNest(prd)) = 1;
    
    $FUNCTION variables_to_prod():
    qProd.l['KELBM',sp,t]           = qKELBM.l[sp,t];
    qProd.l['iB',sp,t]              = qK.l['iB',sp,t];
    qProd.l['iM',sp,t]              = qK.l['iM',sp,t];
    qProd.l['iT',sp,t]              = qK.l['it',sp,t];
    qProd.l['FiniB',sp,t]           = qFin_k.l['iB',sp,t];
    qProd.l['FiniM',sp,t]           = qFin_k.l['iM',sp,t];
    qProd.l['FiniT',sp,t]           = qFin_k.l['iT',sp,t];
    qProd.l['RxE',sp,t]             = qRxE.l[sp,t];
    qProd.l['L',sp,t]               = qL.l[sp,t];
    pProd.l['KELBM',sp,t]           = pKELBM.l[sp,t];
    pProd.l['iB',sp,t]              = pK.l['iB',sp,t];
    pProd.l['iM',sp,t]              = pK.l['iM',sp,t];
    pProd.l['iT',sp,t]              = pK.l['it',sp,t];
    pProd.l['FiniB',sp,t]           = pFin_k.l['iB',sp,t];
    pProd.l['FiniM',sp,t]           = pFin_k.l['iM',sp,t];
    pProd.l['FiniT',sp,t]           = pFin_k.l['iT',sp,t];
    pProd.l['RxE',sp,t]             = pRxE.l[sp,t];
    pProd.l['L',sp,t]               = pL.l[sp,t];
    $ENDFUNCTION 
    @variables_to_prod();
    
    $BLOCK B_populate_nestingtree
        E_qProdNest[prdNest,sp,t]$(tx0[t])..
            qProd[prdNest,sp,t] =E=  sum(prd$(prdNest2Prd(prdNest,prd) and not prdBotUlt[prd]), qProd[prd,sp,t]*pProd[prd,sp,t]) 
                                    +sum(prd$(prdNest2Prd(prdNest,prd) and prdBotUlt[prd]), qProd[prd,sp,t-1]*pProd[prd,sp,t-1]/fq); #Done on input variables before inflation-korrektion
        E_obj_populate.. obj =E= 0;
    $ENDBLOCK
    $GROUP G_populate_nestingtree_exo 
        qProd$(prdBot[prd])
        pProd$(prdBot[prd])
        qProd$(sameas(prd,'Eother') or sameas(prd,'Etrans'))
        pProd$(sameas(prd,'Eother') or sameas(prd,'Etrans'))
    ;

    $FIX G_populate_nestingtree_exo;
    SOLVE B_populate_nestingtree using NLP minimizing obj;
    
    #Production function
    d1Prod[prd,sp,t] = yes$(tData[t] and qProd.l[prd,sp,t]);


#FROM EMISSIONS.GMS 

  d1sBioNatGasC[purpose,t]     =yes$(sBioNatGasC.l[purpose,t]=1  and d1EmmConsE[t,'CO2bio',purpose,'Natural gas incl. biongas']    and not d1EmmConsE[t,'CO2ubio',purpose,'Natural gas incl. biongas']);
  d1sBioNatGasCzero[purpose,t] =yes$(sBioNatGasC.l[purpose,t]=0  and d1EmmConsE[t,'CO2ubio',purpose,'Natural gas incl. biongas']   and not d1EmmConsE[t,'CO2bio',purpose,'Natural gas incl. biongas']);
  d1sBioNatGas[purpose,s,t]    =yes$(sBionatgas.l[purpose,s,t]=1 and d1EmmProdE[s,t,'CO2bio',purpose,'Natural gas incl. biongas']  and not d1EmmProdE[s,t,'CO2ubio',purpose,'Natural gas incl. biongas']);
  d1sBioNatGaszero[purpose,s,t]=yes$(sBionatgas.l[purpose,s,t]=0 and d1EmmProdE[s,t,'CO2ubio',purpose,'Natural gas incl. biongas'] and not d1EmmProdE[s,t,'CO2bio',purpose,'Natural gas incl. biongas']);

# ABATEMENT.GMS

uREExID.l[purpose,energy19a,energy19,s,t] = 1$(sameas[energy19,energy19a] and d1pREgj[purpose,energy19,s,t]);
uREE.l[purpose,energy19a,energy19,s,t]    = uREExID.l[purpose,energy19a,energy19,s,t];
qREE.l[purpose,energy19a,energy19,s,t]    = qREgj.l[purpose,energy19,s,t]$(sameas[energy19,energy19a] and d1pREgj[purpose,energy19,s,t]);

d1qREE[purpose,energy19a,energy19,s,t] = yes$((qREE.l[purpose,energy19a,energy19,s,t] and not sum(energy1919,d1vREE_transport[purpose,energy1919,energy19,s,t])) or sum(techID, d1thetaID[techID,purpose,energy19a,energy19,s,t]));




## OVERBLIK
#  
#  AGGREGATES
#  qREa
#  qREgj
#  d1qREgj

#  IO.GMS
#  pRE_base
#  pREown
#  d1pRE_base
#  d1pREown