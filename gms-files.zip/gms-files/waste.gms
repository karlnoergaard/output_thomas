# ======================================================================================================================
# Waste sector module
# ======================================================================================================================

# Key links with other modules:
# - Controls waste energy qRENEWABLE("waste"), which is otherwise a flat forecast  (in aggregates.gms)
# - Controls emissionss coefficient (uEmmProd("waste")), which is otherwise constant (in emissions.gms)
# - Takes over control of net exports from recycling sector (in exports.gms)

# ----------------------------------------------------------------------------------------------------------------------
# NOTES ON INTEGRATION WITH ENERGY MODEL
# ----------------------------------------------------------------------------------------------------------------------
# The following should be added when energy model is uploaded to master git branch (located in run.gms on branch energi_affald currently)

# EQUATIONS
    #  # Link emissions coefficients for waste. Weighted average between change in coefficients in sectors 35001 and 38393
    #      E_uEmmProdE_WASTE_CO2e_LINK[t,BFt]$(tBFF[t] and sameas(BFt,'BFt11') and d1PROP['co2e','waste',BFt,t])..
    #      CO2prop[t,BFt] =E= CO2prop[t-1,BFt] * sum(energy19$(BFt2Energy19[BFt,energy19]), 
    #          ((sum(purpose$(d1EmmProdE['35001',t,'co2e',purpose, energy19]), uEmmProdE['35001',t,'co2e',energy19]*qEmmProdE['35001',t,'co2e',purpose,energy19])
    #          + sum(purpose$(d1EmmProdE['38393',t,'co2e',purpose, energy19]), uEmmProdE['38393',t,'co2e',energy19]*qEmmProdE['38393',t,'co2e',purpose,energy19]))
    #          / (sum(purpose$(d1EmmProdE['35001',t,'co2e',purpose, energy19]), qEmmProdE['35001',t,'co2e',purpose,energy19]) + sum(purpose$(d1EmmProdE['38393',t,'co2e',purpose, energy19]), qEmmProdE['38393',t,'co2e',purpose,energy19])))   
    #          / ((sum(purpose$(d1EmmProdE['35001',t,'co2e',purpose, energy19]), uEmmProdE['35001',t-1,'co2e',energy19]*qEmmProdE['35001',t-1,'co2e',purpose,energy19])
    #          + sum(purpose$(d1EmmProdE['38393',t,'co2e',purpose, energy19]), uEmmProdE['38393',t-1,'co2e',energy19]*qEmmProdE['38393',t-1,'co2e',purpose,energy19]))
    #          / (sum(purpose$(d1EmmProdE['35001',t,'co2e',purpose, energy19]), qEmmProdE['35001',t-1,'co2e',purpose,energy19]) + sum(purpose$(d1EmmProdE['38393',t,'co2e',purpose, energy19]), qEmmProdE['38393',t-1,'co2e',purpose,energy19]))));   

    #      E_uEmmProdE_WASTE_SO2e_LINK[t,BFt]$(tBFF[t] and sameas(BFt,'BFt11') and d1PROP['so2','waste',BFt,t])..
    #          SO2prop[t,BFt] =E= SO2prop[t-1,BFt] * sum(energy19$(BFt2Energy19[BFt,energy19]), 
    #          ((sum(purpose$(d1EmmProdE['35001',t,'SO2',purpose, energy19]), uEmmProdE['35001',t,'SO2',energy19]*qEmmProdE['35001',t,'SO2',purpose,energy19])
    #          + sum(purpose$(d1EmmProdE['38393',t,'SO2',purpose, energy19]), uEmmProdE['38393',t,'SO2',energy19]*qEmmProdE['38393',t,'SO2',purpose,energy19]))
    #          / (sum(purpose$(d1EmmProdE['35001',t,'SO2',purpose, energy19]), qEmmProdE['35001',t,'SO2',purpose,energy19]) + sum(purpose$(d1EmmProdE['38393',t,'SO2',purpose, energy19]), qEmmProdE['38393',t,'SO2',purpose,energy19])))   
    #          / ((sum(purpose$(d1EmmProdE['35001',t,'SO2',purpose, energy19]), uEmmProdE['35001',t-1,'SO2',energy19]*qEmmProdE['35001',t-1,'SO2',purpose,energy19])
    #          + sum(purpose$(d1EmmProdE['38393',t,'SO2',purpose, energy19]), uEmmProdE['38393',t-1,'SO2',energy19]*qEmmProdE['38393',t-1,'SO2',purpose,energy19]))
    #          / (sum(purpose$(d1EmmProdE['35001',t,'SO2',purpose, energy19]), qEmmProdE['35001',t-1,'SO2',purpose,energy19]) + sum(purpose$(d1EmmProdE['38393',t,'SO2',purpose, energy19]), qEmmProdE['38393',t-1,'SO2',purpose,energy19]))));   

# TO G_ELB_ENDO GROUP:
    #  CO2prop$(tBFF[t] and sameas(BFt,'BFt11') and d1PROP['co2e','waste',BFt,t]), SO2prop$(tBFF[t] and sameas(BFt,'BFt11') and d1PROP['so2','waste',BFt,t])

# TO G_ENDO_LINKED: 
    #  CO2prop$(tBFF[t] and sameas(BFt,'BFt11') and d1PROP['co2e','waste',BFt,t]), SO2prop$(tBFF[t] and sameas(BFt,'BFt11') and d1PROP['so2','waste',BFt,t])

# TO G_EXO_LINKED: 
    #  CO2prop$(t.val <= t0.val and sameas(BFt,'BFt11') and d1PROP['co2e','waste',BFt,t]), SO2prop$(t.val <= t0.val and sameas(BFt,'BFt11') and d1PROP['so2','waste',BFt,t])

# ======================================================================================================================
# Variable definition
# ======================================================================================================================
$IF %stage% == "variables":

# ----------------------------------------------------------------------------------------------------------------------
# Waste parameters
# ----------------------------------------------------------------------------------------------------------------------
$GROUP G_waste_param
   # Waste generatinon parameters 
        uWaste_arima_GEN[sec,n,t]$(tx0[t] and sum(g_waste,d1qWasteQ_GEN[sec,g_waste,n,t]))                              "ARIMA estimate of waste generating coefficient (generated waste in kilo ton pr material input in mia DKK)"
        uWaste_adjust_GEN[sec,g_waste,n,t]$(tx0[t] and d1qWasteQ_GEN[sec,g_waste,n,t])                                  "Adjustment terms to link ARIMA activity data and model activity data (Should be equal to 1 for all years as long as the activity data in the model is the same as in the estimation)"
        uWaste_adjust_GEN_2020[sec,g_waste,n,t]$(tx0[t] and d1qWasteQ_GEN[sec,g_waste,n,t])                             "Adjustment term to ensure that the model fits waste data from 2020"
        uWaste_MWshare[sec,g_waste,n,t]$(tx0[t] and d1qWasteQ_GEN[sec,g_waste,n,t])                                     "Share of municipal waste for each sector and waste fraction"
        uWaste_arima_SORT[sec,n,t]$(tx0[t] and sum(g_waste,d1qWasteQ_GEN[sec,g_waste,n,t]) and not sameas[n,'Dag'])     "ARIMA estimate of waste sortering coefficient (sorted waste in kilo ton pr generated waste in kilo ton)"
        UWaste_arima_hus_adjust[t]$(tx0[t])                                                                             "Correction of ARIMA waste generating coefficients for the households (-1.2pct pr year)"
    # Waste treatment parameters 
        uWasteD[origin_waste,g_waste,n,t]$(tx0[t] and (d1qWasteD[origin_waste,g_waste,n,t] or d1qWasteE[origin_waste,g_waste,n,t] or d1qWasteR[origin_waste,g_waste,n,t]))     "Fraction of disposed waste"
        uWasteChi[origin_waste,g_waste,n,t]$(tx0[t] and (d1qWasteR[origin_waste,g_waste,n,t] or d1qWasteE[origin_waste,g_waste,n,t]))                                          "Waste hierachy - fraction of waste that is send to recycling"
        uWasteChi_E[origin_waste,g_waste,n,t]$(tx0[t] and (d1qWasteE_utilize[origin_waste,g_waste,n,t] or d1qWasteE_burn[origin_waste,g_waste,n,t] or d1qWasteE[origin_waste,g_waste,n,t] or d1qWasteE[origin_waste,g_waste,n,t]))   "Burned/utilized waste hierachy - fraction of burned waste"
        uWastePhi_R[g_waste,n,gg_waste,nn,t]$(tx0[t] and sum(origin_waste,d1WasteResidual[origin_waste,g_waste,n,gg_waste,nn,t]))                                              "Residual waste coefficient"
        uWasteBeta_R[g_waste,n,t]$(tx0[t] and sum(origin_waste,sum(gg_waste,sum(nn,d1WasteResidual[origin_waste,g_waste,n,gg_waste,nn,t]))))                                                                                                                                              "Level coefficient in residual waste function"
    # Waste parameters for waste import
        uWaste_MWshare_im[g_waste,n,t]$(tx0[t] and sameas[g_waste, 'Manufacturing Waste'] and sameas[n, 'Dag'])                                                                "Municipal waste share for imported waste"
        uWaste_im[g_waste,n,t]$(tx0[t] and d1qWasteQ_bar_dom['Import',g_waste,n,t])                                                                                            "Share of imported waste treated in DK relative to the total waste generated in DK"
    # Waste parameters for waste export
        uWaste_ex[origin_waste,g_waste,n,t]$(tx0[t] and d1qWasteQ_ex[origin_waste,g_waste,n,t])                                                                                "Share of exported waste relative to the total waste generated in DK"
        uWasteD_ex[origin_waste,g_waste,n,t]$(tx0[t] and (d1qWasteD_ex[origin_waste,g_waste,n,t] or d1qWasteQ_ex[origin_waste,g_waste,n,t]))                                   "Fraction of disposed exported waste"
        uWasteChi_ex[origin_waste,g_waste,n,t]$(tx0[t] and (d1qWasteE_ex[origin_waste,g_waste,n,t] or d1qWasteR_ex[origin_waste,g_waste,n,t]))                                 "Exported waste hierachy - fraction of exported waste that is send to recycling"
        uWasteChi_E_ex[origin_waste,g_waste,n,t]$(tx0[t] and d1qWasteE_ex[origin_waste,g_waste,n,t])                                                                           "Exported burned/utilized waste hierachy - fraction of exported waste that is burned"
    # Parameters in the CET function 
        uWasteOmega[g_waste,n,t]$(tx0[t] and sum(origin_waste,d1WasteCET_ex[origin_waste,g_waste,n,t]))                                                                        "Scale parameter in CET function"
        uWasteGamma[g_waste,n,t]$(tx0[t] and (sum(origin_waste,d1WasteCET_ex[origin_waste,g_waste,n,t]) or sum(origin_waste, d1WasteCET[origin_waste,g_waste,n,t])))           "Share parameter in CET functions"
        uWasteEpsilon[g_waste,n,t]$(tx0[t] and (sum(origin_waste,d1WasteCET[origin_waste,g_waste,n,t]) or sum(origin_waste,d1WasteCET_ex[origin_waste,g_waste,n,t])))          "Elasticity of substitution in CET functions"
        uWasteXi_E[g_waste,n,t]$(tx0[t] and ((sum(origin_waste,d1WasteCET[origin_waste,g_waste,n,t] and d1qWasteE[origin_waste,g_waste,n,t]) and not d1Waste_Hardcoded_recycling) or (sum(origin_waste, d1WasteCET_ex[origin_waste,g_waste,n,t] and d1qWasteE_ex[origin_waste,g_waste,n,t]))))     "Parameter in linear term for 'qWasteE' added to regular CET function"
        uWasteXi_R[g_waste,n,t]$(tx0[t] and (sum(origin_waste,d1WasteCET[origin_waste,g_waste,n,t]) or sum(origin_waste, d1WasteCET_ex[origin_waste,g_waste,n,t])))            "Parameter in linear term for 'qWasteR' added to regular CET function"
    # Parameters for hardcoded degree of recycling
        uWasteR[g_waste,n,t]$(tx0[t] and sum(origin_waste, d1WasteCET[origin_waste,g_waste,n,t]) and d1Waste_Hardcoded_recycling)    ""
    # Emissions and energy coefficients from burning waste
        uWasteEnergyValue[n,t]$((d1uWasteEnergyValue[n,t] and sum(g_waste,d1qWasteE_burn['DK',g_waste,n,t])) or (d1uWasteEnergyValue[n,t] and sum(g_waste,d1qWasteE_burn['Import',g_waste,n,t] and not sameas[n,'Dag'])))   "Energy content in emissions pr mass of burned waste for eache waste fraction (measured in MJ pr kg)"                   
        uWasteEmissionCoefficient[n,emm,t]$(tx0[t] and d1WasteEmissionValue[n,emm,t] and sum(s,d1uEmmWaste[s,t,emm]) and sum(origin_waste, sum(g_waste,d1qWasteE_burn[origin_waste,g_waste,n,t])))                    "Mass of emissions pr energy from burned waste for each emission type and waste fraction (measured in kilo ton pr PJ)"
    # Climate plan waste parameters
        uWasteKlimaplan_GEN[sec,g_waste,n,t]$(tx0[t] and d1qWasteQ_GEN[sec,g_waste,n,t] and d1WasteKlimaplan_GEN[sec,g_waste,n,t])                                              "Effects on waste generating from the climate plan"
        uWasteKlimaplan_SORT[sec,g_waste,n,t]$(tx0[t] and (not sameas[n,'Dag']) and d1qWasteQ[sec,g_waste,n,t] and d1WasteKlimaplan_SORT[sec,g_waste,n,t])                      "Effects on waste sorting from the climate plan"
        uWasteKlimaplan_Chi[origin_waste,g_waste,n,t]$(tx0[t] and d1WasteKlimaplan_Chi[origin_waste,g_waste,n,t] and d1qWasteE[origin_waste,g_waste,n,t])                       "Effects on split between recycled and burned/utilized waste from the climate plan"
      
;

$GROUP G_waste_param_calib
    # Waste data variables (used in calibration)
        # Danish waste
        qWasteD_DK[g_waste,n,t]                                        "Data for disposed waste from DK" 
        qWasteR_DK[g_waste,n,t]                                        "Data for recycled waste from DK"    
        qWasteE_utilize_DK[g_waste,n,t]                                "Data for utilized waste from DK"    
        qWasteE_burn_DK[g_waste,n,t]                                   "Data for burned waste from DK"       
        # Imported waste
        qWasteD_im[g_waste,n,t]                                        "Data for disposed waste from import"                                    
        qWasteR_im[g_waste,n,t]                                        "Data for recycled waste from import"    
        qWasteE_utilize_im[g_waste,n,t]                                "Data for utilized waste from import"    
        qWasteE_burn_im[g_waste,n,t]                                   "Data for burned waste from import"  
        # Exported waste
        qWasteD_ex_data[g_waste,n,t]                                   "Data for disposed waste from export"    
        qWasteR_ex_data[g_waste,n,t]                                   "Data for recycled waste from export"    
        qWasteE_utilize_ex_data[g_waste,n,t]                           "Data for utilized waste from export"       
        qWasteE_burn_ex_data[g_waste,n,t]                              "Data for burned waste from export"      

    # Emissions and energy coefficients from burning waste
        uWasteEmissionValue[n,emm,t]$(d1WasteEmissionValue[n,emm,t])                                   "Mass of emissions pr mass of burned waste for each emission type and waste fracion (measured in kg pr kg)"

;

# ----------------------------------------------------------------------------------------------------------------------
# Waste quantities  
# ----------------------------------------------------------------------------------------------------------------------
$GROUP G_wasteGeneration_quantities
    qWasteQ_GEN_ARIMA[sec,g_waste,n,t]$(d1qWasteQ_GEN[sec,g_waste,n,t]) "ARIMA forecast of generated waste for each sector, type and fraction (in kilo ton)"
    qWasteQ_GEN[sec,g_waste,n,t]$(d1qWasteQ_GEN[sec,g_waste,n,t])       "Generated waste for each sector, type and fraction with the possible effects from the climateplan (in kilo ton)"

;

$GROUP G_wasteSorting_quantities
    qWasteQ_ARIMA[sec,g_waste,n,t]$(d1qWasteQ_ARIMA[sec,g_waste,n,t])  "ARIMA forecast of sorted waste for each sector, type and fraction (in kilo ton)"
    qWasteQ[sec,g_waste,n,t]$(d1qWasteQ[sec,g_waste,n,t])              "Sorted waste for each sector, type and fraction with the possible effects from the climateplan (in kilo ton)"
    qWasteRestaffald[sec,g_waste,n,t]$(d1qWasteQ_GEN[sec,g_waste,n,t]) "Amount of each waste fraction in 'Dag' ('Restaffald')"
;

# ----------------------------------------------------------------------------------------------------------------------
# Waste treatment quantities
# ----------------------------------------------------------------------------------------------------------------------
$GROUP G_wasteTreatment_quantities
    qWasteQ_bar[g_waste,n,t]$(d1qWasteQ_bar[g_waste,n,t])                                         "Waste generated in DK including residual waste for each type and fraction (in kilo ton)"
    qWasteQ_im[g_waste,n,t]$(d1qWasteQ_bar_dom['Import',g_waste,n,t] and not sameas[n,'Dag'])     "Waste imported to be treated in DK - without residual waste"
    qWasteQ_bar_dom[origin_waste,g_waste,n,t]$(d1qWasteQ_bar_dom[origin_waste,g_waste,n,t])       "Waste mass treated in DK (both danish and imported) including residual waste (in kilo ton)"
    qWasteD[origin_waste,g_waste,n,t]$(d1qWasteD[origin_waste,g_waste,n,t])                       "Waste mass disposed (in kilo ton)"
    qWasteW[origin_waste,g_waste,n,t]$(d1qWasteE[origin_waste,g_waste,n,t] or d1qWasteR[origin_waste,g_waste,n,t]) "Waste mass burned, utilized or recycled in DK (in kilo ton)"
    qWasteE[origin_waste,g_waste,n,t]$(d1qWasteE[origin_waste,g_waste,n,t])                       "Waste mass burned or utilized (in kilo ton)"
    qWasteE_utilize[origin_waste,g_waste,n,t]$(d1qWasteE_utilize[origin_waste,g_waste,n,t])       "Waste mass utilized (in kilo ton)"
    qWasteE_burn[origin_waste,g_waste,n,t]$(d1qWasteE_burn[origin_waste,g_waste,n,t])             "Waste mass burned (in kilo ton)" 
    qWasteR[origin_waste,g_waste,n,t]$(d1qWasteR[origin_waste,g_waste,n,t])                       "Waste mass send to recycling (in kilo ton)"
    qWasteR_bar[origin_waste,g_waste,n,t]$(d1qWasteR[origin_waste,g_waste,n,t])                   "Waste mass that is actually recycled (in kilo ton)"
    qWasteQ_R_out_in[origin_waste,g_waste,n,gg_waste,nn,t]$(d1WasteResidual[origin_waste,g_waste,n,gg_waste,nn,t])          "Residual waste of type [gg_waste,nn] from recycling waste of type [g_waste,n] (in kilo ton)"
    qWasteQ_R_out[origin_waste,g_waste,n,t]$(sum(gg_waste, sum(nn, d1WasteResidual[origin_waste,g_waste,n,gg_waste,nn,t]))) "Residual waste that goes out from the recycling process (in kilo ton)"
    qWasteM_R_bar[origin_waste,g_waste,n,t]$(d1qWasteR[origin_waste,g_waste,n,t])                 "Mass of emissions/AEM from recycling (in kilo ton)"    
    qWasteQ_R_in[origin_waste,g_waste,n,t]$(sum(gg_waste, sum(nn, d1WasteResidual[origin_waste,gg_waste,nn,g_waste,n,t])))  "Residual waste that goes into the treatment process (in kilo ton)"
    qWasteM_R_bar_emissions[origin_waste,g_waste,n,t]$(tx0[t] and d1qWasteR[origin_waste,g_waste,n,t] and (sameas[n,'Org'] or sameas[n,'Have'])) ""
    qWasteM_R_bar_AEM[origin_waste,g_waste,n,t]$(tx0[t] and d1qWasteR[origin_waste,g_waste,n,t] and (sameas[n,'byg'] or sameas[n,'Rest'] or sameas[n,'Tekst'])) "Mass of specific emission types from recycling (in kilo ton)"
;

# ----------------------------------------------------------------------------------------------------------------------
# Waste quantities for exported waste
# ----------------------------------------------------------------------------------------------------------------------
$GROUP G_waste_export
    qWasteQ_ex[origin_waste,g_waste,n,t]$(d1qWasteQ_ex[origin_waste,g_waste,n,t] and not (sameas[n,'Dag'] and sameas[origin_waste,'DK'])) "Exported waste - both danish waste and reexported waste (in kilo ton)"
    qWasteD_ex[origin_waste,g_waste,n,t]$(d1qWasteD_ex[origin_waste,g_waste,n,t])                 "Exported waste mass disposed (in kilo ton)"
    qWasteW_ex[origin_waste,g_waste,n,t]$(d1qWasteQ_ex[origin_waste,g_waste,n,t])                 "Exported waste mass burned, utilized or recycled (in kilo ton)"
    qWasteE_ex[origin_waste,g_waste,n,t]$(d1qWasteE_ex[origin_waste,g_waste,n,t])                 "Exported waste mass burned or utilized (in kilo ton)"
    qWasteE_utilize_ex[origin_waste,g_waste,n,t]$(d1qWasteE_ex[origin_waste,g_waste,n,t])         "Exported waste mass utilized (in kilo ton)"
    qWasteE_burn_ex[origin_waste,g_waste,n,t]$(d1qWasteE_ex[origin_waste,g_waste,n,t])            "Exported waste mass burned (in kilo ton)"
    qWasteR_ex[origin_waste,g_waste,n,t]$(d1qWasteR_ex[origin_waste,g_waste,n,t])                 "Exported waste mass send to recycling divided by group and fraction"
    qWasteR_bar_ex[origin_waste,g_waste,n,t]$(d1qWasteR_ex[origin_waste,g_waste,n,t])             "Exported waste mass that is actually recycled (in kilo ton)"    
;


# ----------------------------------------------------------------------------------------------------------------------
# Quantities from other modules (Links to CGE-model)
# ----------------------------------------------------------------------------------------------------------------------
$GROUP G_links_waste
    # Variables from other modules that is endogenized and recalculated in the waste module
    uEmmProdE[s,t,emm,energy19]$(sum(purpose,d1EmmProdE[s,t,emm,purpose,energy19]) and d1uEmmWaste[s,t,emm] and sameas(energy19,"waste"))
    qM_CET[energy19,s,t]$(sameas(out,"waste") and sameas(s,"19000")) 
    qRENEWABLE[energy19,t]$(sameas(energy19,"waste"))                  

    # The amount of exported and imported waste of the fraction 'Dag' (restaffald) is determined based on the value of qREgj (comes from the energy module) 
    qWasteQ_ex_im[t] "Net import of 'Restaffald'"
    qWasteQ_im[g_waste,n,t]$(d1qWasteQ_bar_dom['Import',g_waste,n,t] and sameas[n,'Dag'])
    qWasteQ_ex[origin_waste,g_waste,n,t]$(d1qWasteQ_ex[origin_waste,g_waste,n,t] and sameas[origin_waste,'DK'] and sameas[n,'Dag'])
;

# ----------------------------------------------------------------------------------------------------------------------
# Waste quantities without residual waste (to DTU/EASETECH)
# ----------------------------------------------------------------------------------------------------------------------
$GROUP G_wasteTreatment_quantities_ExclResWaste
    qWasteQ_bar_dom_ExclResWaste[origin_waste,g_waste,n,t]$(d1qWasteQ_bar_dom[origin_waste,g_waste,n,t]) "Waste mass treated in DK (both danish and imported) excluding residual waste and without separately calibration of 'Dag' (in kilo ton)"
    qWasteQ_ex_ExclResWaste[origin_waste,g_waste,n,t]$(d1qWasteQ_ex[origin_waste,g_waste,n,t])           "Exported waste mass without separately calibration of 'Dag'"
    qWasteD_ExclResWaste[origin_waste,g_waste,n,t]$(d1qWasteD[origin_waste,g_waste,n,t])                 "Waste mass disposed excluding residual waste (in kilo ton)"
    qWasteE_ExclResWaste[origin_waste,g_waste,n,t]$(d1qWasteE[origin_waste,g_waste,n,t])                 "Waste mass burned or utilized excluding residual waste (in kilo ton)"
    qWasteE_utilize_ExclResWaste[origin_waste,g_waste,n,t]$(d1qWasteE[origin_waste,g_waste,n,t])         "Waste mass utilized exluding residual waste (in kilo ton)"
    qWasteE_burn_ExclResWaste[origin_waste,g_waste,n,t]$(d1qWasteE[origin_waste,g_waste,n,t])            "Waste mass burned exluding residual waste (in kilo ton)"
    qWasteR_ExclResWaste[origin_waste,g_waste,n,t]$(d1qWasteR[origin_waste,g_waste,n,t])                 "Waste mass send to recycling excluding residual waste (in kilo ton)"

    # Report variabels to DTU
    qWasteQ_bar_dom_ExclResWaste_tot[n,t]$(sum(origin_waste, (sum(g_waste, d1qWasteQ_bar_dom[origin_waste,g_waste,n,t])))) "REPORT VARIABLE - Total waste mass treated in DK excluding residual waste (in kilo ton)"
    qWasteQ_im_ExclResWaste_tot[n,t]$(sum(g_waste, d1qWasteQ_bar_dom['Import',g_waste,n,t]))                               "REPORT VARIABLE - Total imported waste treated in DK excluding residual waste (in kilo ton)"
    qWasteQ_ex_ExclResWaste_tot[n,t]$(sum(origin_waste, sum(g_waste, d1qWasteQ_ex[origin_waste,g_waste,n,t])))             "REPORT VARIABLE - Total exported waste excluding residual waste (in kilo ton)"
    qWasteD_ExclResWaste_tot[n,t]$(sum(origin_waste, sum(g_waste, d1qWasteD[origin_waste,g_waste,n,t])))                   "REPORT VARIABLE - Total waste mass disposed excluding residual waste (in kilo ton)"
    qWasteE_ExclResWaste_tot[n,t]$(sum(origin_waste, sum(g_waste, d1qWasteE[origin_waste,g_waste,n,t])))                   "REPORT VARIABLE - Total waste mass burned or utilized excluding residual waste (in kilo ton)"
    qWasteE_utilize_ExclResWaste_tot[n,t]$(sum(origin_waste, sum(g_waste, d1qWasteE[origin_waste,g_waste,n,t])))           "REPORT VARIABLE - Total waste mass utilized excluding residual waste (in kilo ton)"
    qWasteE_burn_ExclResWaste_tot[n,t]$(sum(origin_waste, sum(g_waste, d1qWasteE[origin_waste,g_waste,n,t])))              "REPORT VARIABLE - Total waste mass burned excluding residual waste (in kilo ton)"
    qWasteR_ExclResWaste_tot[n,t]$(sum(origin_waste, sum(g_waste, d1qWasteR[origin_waste,g_waste,n,t])))                   "REPORT VARIABLE - Total waste mass send to recycling excluding residual waste (in kilo ton)"
    qWasteQ_R_out_in_tot[n,nn,t]$(sum(origin_waste, sum(g_waste, sum(gg_waste, d1WasteResidual[origin_waste,g_waste,n,gg_waste,nn,t])))) "REPORT VARIABLE - total mass of residual waste of fraction nn from recycling waste of fraction n (in kilo ton)"
;

# ----------------------------------------------------------------------------------------------------------------------
# Quantities for report module
# ----------------------------------------------------------------------------------------------------------------------
$GROUP G_report_waste
    # Generated waste
    qWasteQ_GEN_tot[t]$(sum(g_waste, sum(sec, sum(n, d1qWasteQ_GEN[sec,g_waste,n,t]))))                           "REPORT VARIABLE - Total generated waste (in kilo ton)"
    qWasteQ_GEN_fraktion[n,t]$(sum(g_waste, sum(sec, d1qWasteQ_GEN[sec,g_waste,n,t])))                            "REPORT VARIABLE - Total generated waste of each fraction (in kilo ton)"
    qWasteQ_GEN_type[g_waste,t]$(sum(n, sum(sec, d1qWasteQ_GEN[sec,g_waste,n,t])))                                "REPORT VARIABLE - Total generated waste of each type (in kilo ton)"
    qWasteQ_GEN_MWhus[t]$(sum(n, d1qWasteQ_GEN['hus','Municipal Waste',n,t]))                                     "REPORT VARIABLE - Total generated municipal waste from households (in kilo ton)"
    qWasteQ_GEN_MWerhv[t]$(sum(n, sum(sec, d1qWasteQ_GEN[sec,'Municipal Waste',n,t])))                            "REPORT VARIABLE - Total generated municipal waste from sectors (in kilo ton)"
    qWasteQ_GEN_MW[n,t]$(sum(sec, d1qWasteQ_GEN[sec,'Municipal Waste',n,t]))                                      "REPORT VARIABLE - Total generated municipal waste of each fraction (in kilo ton)"
    qWasteQ_GEN_tot_sec[origin_waste,g_waste,n,t]$(sum(sec, d1qWasteQ_GEN[sec,g_waste,n,t]) and sameas[origin_waste,'DK']) ""
    # Sorted waste
    qWasteQ_SORT_tot[t]$(sum(g_waste, sum(sec, sum(n, d1qWasteQ[sec,g_waste,n,t]))))                              "REPORT VARIABLE - Total sorted waste without 'Dag' (in kilo ton)"
    qWasteQ_SORT_fraktion[n,t]$(sum(g_waste, sum(sec, d1qWasteQ[sec,g_waste,n,t])))                               "REPORT VARIABLE - Total sorted waste of each fraction (in kilo ton)"
    qWasteQ_SORT_type[g_waste,n,t]$(tx0[t] and sum(sec,d1qWasteQ[sec,g_waste,n,t]))                                                                                ""
    qWasteQ_SORT_tot_sec[origin_waste,g_waste,n,t]$(sum(sec, d1qWasteQ[sec,g_waste,n,t]) and sameas[origin_waste,'DK']) ""
    qWasteRestaffald_tot[t]$(sum(g_waste, sum(sec, sum(n, d1qWasteQ_GEN[sec,g_waste,n,t]))))                      "REPORT VARIABLE - Total amount of 'restaffald' (in kilo ton)"
    qWasteRestaffald_fraktion[n,t]$(sum(g_waste, sum(sec, d1qWasteQ_GEN[sec,g_waste,n,t])))                       "REPORT VARIABLE - Total amount of each fraction in 'restaffaldet' (in kilo ton)"
    # Waste treatment
    qWasteQ_bar_dom_tot[t]$(sum(origin_waste, sum(g_waste, sum(n, d1qWasteQ_bar_dom[origin_waste,g_waste,n,t])))) "REPORT VARIABLE - Total waste mass treated in DK (in kilo ton)"
    qWasteQ_bar_dom_fraktion[n,t]$(sum(origin_waste, sum(g_waste,d1qWasteQ_bar_dom[origin_waste,g_waste,n,t])))   "REPORT VARIABLE - Total waste mass of each fraction treated in DK (in kilo ton)"
    qWasteD_tot[t]$(sum(origin_waste, sum(g_waste, sum(n, d1qWasteD[origin_waste,g_waste,n,t]))))                 "REPORT VARIABLE - Total waste mass disposed in DK (in kilo ton)"
    qWasteD_fraktion[n,t]$(sum(origin_waste, sum(g_waste,d1qWasteD[origin_waste,g_waste,n,t])))                   "REPORT VARIABLE - Total waste mass of each fraction disposed in DK (in kilo ton)"
    qWasteE_utilize_tot[t]$(sum(origin_waste, sum(g_waste, sum(n, d1qWasteE[origin_waste,g_waste,n,t]))))         "REPORT VARIABLE - Total waste mass utilized in DK (in kilo ton)"
    qWasteE_utilize_fraktion[n,t]$(sum(origin_waste, sum(g_waste, d1qWasteE_utilize[origin_waste,g_waste,n,t])))          "REPORT VARIABLE - Total waste mass of each fraction utilized in DK (in kilo ton)"
    qWasteE_burn_tot[t]$(sum(origin_waste, sum(g_waste, sum(n, d1qWasteE_burn[origin_waste,g_waste,n,t]))))       "REPORT VARIABLE - Total waste mass burned in DK (in kilo ton)"      
    qWasteE_burn_fraktion[n,t]$(sum(origin_waste, sum(g_waste, d1qWasteE_burn[origin_waste,g_waste,n,t])))        "REPORT VARIABLE - Total waste mass of each fraction burned in DK (in kilo ton)"     
    qWasteR_bar_tot[t]$(sum(origin_waste, sum(g_waste, sum(n, d1qWasteR[origin_waste,g_waste,n,t]))))             "REPORT VARIABLE - Total waste mass actually recycled in DK (in kilo ton)"
    qWasteR_bar_fraktion[n,t]$(sum(origin_waste, sum(g_waste,d1qWasteR[origin_waste,g_waste,n,t])))               "REPORT VARIABLE - Total waste mass of each fraction actually recycled in DK (in kilo ton)"
    qWasteQ_R_out_tot[t]$(sum(origin_waste, sum(g_waste, sum(n, sum(gg_waste, sum(nn, d1WasteResidual[origin_waste,g_waste,n,gg_waste,nn,t])))))) "REPORT VARIABLE - Total residual waste that goes out from the recycling process (in kilo ton)"
    qWasteQ_R_out_fraktion[n,t]$(sum(origin_waste, sum(g_waste, sum(gg_waste, sum(nn, d1WasteResidual[origin_waste,g_waste,n,gg_waste,nn,t])))))  "REPORT VARIABLE - Total residual waste of each fraction that goes out from the recycling process (in kilo ton)"
    qWasteM_R_bar_tot[t]$(sum(origin_waste, sum(g_waste, sum(n, d1qWasteR[origin_waste,g_waste,n,t]))))           "REPORT VARIABLE - Total mass of emissions from recycling (in kilo ton)"
    qWasteM_R_bar_fraktion[n,t]$(sum(origin_waste, sum(g_waste,d1qWasteR[origin_waste,g_waste,n,t])))             "REPORT VARIABLE - Total mass of emissions from recycling each fraction (in kilo ton)"
    qWasteQ_ex_tot[t]$(sum(origin_waste, sum(g_waste, sum(n, d1qWasteQ_ex[origin_waste,g_waste,n,t]))))           "REPORT VARIABLE - Total exported waste - both danish and reexported (in kilo ton)"
    qWasteQ_ex_fraktion[n,t]$(sum(origin_waste, sum(g_waste, d1qWasteQ_ex[origin_waste,g_waste,n,t])))            "REPORT VARIABLE - Total exported waste of each fraction - both danish and reexported (in kilo ton)"
    qWasteQ_im_tot[t]$(sum(g_waste, sum(n, d1qWasteQ_bar_dom['Import',g_waste,n,t])))                             "REPORT VARIABLE - Total imported waste treated in DK (in kilo ton)" 
    qWasteQ_im_fraktion[n,t]$(sum(g_waste, d1qWasteQ_bar_dom['Import',g_waste,n,t]))                              "REPORT VARIABLE - Total imported waste of each fraction treated in DK (in kilo ton)"
    qWasteQ_ex_Restaffald[t]$(sum(g_waste, d1qWasteQ_ex['DK',g_waste,'Dag',t]))                                   "REPORT VARIABLE - Total exported 'restaffald' ('Dag') (in kilo ton)"    
    qWasteQ_im_Restaffald[t]$(sum(g_waste, d1qWasteQ_bar_dom['Import',g_waste,'Dag',t]))                          "REPORT VARIABLE - Total imported 'restaffald' ('Dag') (in kilo ton)"   

    # Check of implementation of the effects from the climate plan
    qWasteQ_GEN_KlimaplanCheck_MWhus[n,t]$(d1WasteKlimaplan_GEN['hus','Municipal Waste',n,t])                                   "REPORT VARIABLE - Check of implementation of the effects from the climate plan"
    qWasteQ_KlimaplanCheck_MWhus[n,t]$(d1WasteKlimaplan_SORT['hus','Municipal Waste',n,t])                                      "REPORT VARIABLE - Check of implementation of the effects from the climate plan"
    qWasteQ_KlimaplanCheck_erhv[g_waste,n,t]$(sum(sec, d1WasteKlimaplan_SORT[sec,g_waste,n,t] and not sameas[sec,'hus']))       "REPORT VARIABLE - Check of implementation of the effects from the climate plan"

    uWaste_GEN_KlimaplanCheck_MWhus[n,t]$(d1WasteKlimaplan_GEN['hus','Municipal Waste',n,t])                                    "REPORT VARIABLE - Check of implementation of the effects from the climate plan"
    uWaste_SORT_KlimaplanCheck_MWhus[n,t]$(d1WasteKlimaplan_SORT['hus','Municipal Waste',n,t])                                  "REPORT VARIABLE - Check of implementation of the effects from the climate plan"
    uWaste_SORT_KlimaplanCheck_erhv[g_waste,n,t]$(sum(sec, d1WasteKlimaplan_SORT[sec,g_waste,n,t] and not sameas[sec,'hus']))   "REPORT VARIABLE - Check of implementation of the effects from the climate plan"

    Genanvendelsesprocent_MW[n,t]$(sum(sec,d1qWasteQ_GEN[sec,'Municipal Waste',n,t]) and (d1qWasteR['DK','Municipal Waste',n,t] or d1qWasteR_ex['DK','Municipal Waste',n,t]))                           "REPORT VARIABLE - Recycle percentage for Municipal waste"
    Genanvendelsesprocent_MW_tot[t]$(sum(n, sum(sec,d1qWasteQ_GEN[sec,'Municipal Waste',n,t])) and (sum(n, d1qWasteR['DK','Municipal Waste',n,t]) or sum(n, d1qWasteR_ex['DK','Municipal Waste',n,t]))) "REPORT VARIABLE - Total recycle percentage for Municipal waste"

    qWasteQ_bar_dom_check[t]$(sum(origin_waste, sum(g_waste, sum(n, d1qWasteQ_bar_dom[origin_waste,g_waste,n,t]))))             "REPORT VARIABLE - Check of mass balance in treatment sector"

    qWasteQ_bar_dom_POT[origin_waste,g_waste,n,t]$(tx0[t] and (d1qWasteQ_bar_dom[origin_waste,g_waste,n,t] or d1qWasteQ_ex[origin_waste,g_waste,n,t]) and sameas[origin_waste,'DK'])      "REPORT VARIABLE - Potential danish waste treated in Denmark"
    qWasteD_POT[origin_waste,g_waste,n,t]$(tx0[t] and (d1qWasteD[origin_waste,g_waste,n,t] or d1qWasteD_ex[origin_waste,g_waste,n,t]) and sameas[origin_waste,'DK'])                      "REPORT VARIABLE - Potential danish waste disposed in Denmark"
    qWasteE_burn_POT[origin_waste,g_waste,n,t]$(tx0[t] and (d1qWasteE_burn[origin_waste,g_waste,n,t] or d1qWasteE_ex[origin_waste,g_waste,n,t]) and sameas[origin_waste,'DK'])            "REPORT VARIABLE - Potential danish waste burned in Denmark"
;

$GROUP G_report_COWI
    MW_Primary[n,t]$(tx0[t] and sum(sec, d1qWasteQ[sec,'Municipal Waste',n,t]) and nCOWI[n])    "REPORT VARIABLE - Comparison with COWI"
    MW_Primary_tot[t]$(sum(sec, sum(n, d1qWasteQ[sec,'Municipal Waste',n,t])))                  "REPORT VARIABLE - Comparison with COWI"
    MW_PrimaryRecycling[n,t]$(tx0[t] and d1qWasteR_ex['DK','Municipal Waste',n,t] and nCOWI[n]) "REPORT VARIABLE - Comparison with COWI"
    MW_PrimaryRecycling_tot[t]$(sum(n, d1qWasteR['DK','Municipal Waste',n,t]))                  "REPORT VARIABLE - Comparison with COWI"
    MW_FinalRecycling[n,t]$(tx0[t] and d1qWasteR_ex['DK','Municipal Waste',n,t] and nCOWI[n])   "REPORT VARIABLE - Comparison with COWI"
    MW_FinalRecycling_tot[t]$(sum(n, d1qWasteR['DK','Municipal Waste',n,t]))                    "REPORT VARIABLE - Comparison with COWI"
    MW_PrimaryUtilization[n,t]$(d1qWasteE_utilize['DK','Municipal Waste',n,t])                  "REPORT VARIABLE - Comparison with COWI"
    MW_PrimaryUtilization_tot[t]$(sum(n, d1qWasteE_utilize['DK','Municipal Waste',n,t]))        "REPORT VARIABLE - Comparison with COWI"
    MW_FinalUtilization[n,t]$(d1qWasteE_utilize['DK','Municipal Waste',n,t])                    "REPORT VARIABLE - Comparison with COWI"
    MW_FinalUtilization_tot[t]$(sum(n, d1qWasteE_utilize['DK','Municipal Waste',n,t]))          "REPORT VARIABLE - Comparison with COWI"
    MW_PrimaryBurn[n,t]$(tx0[t] and d1qWasteE_burn['DK','Municipal Waste',n,t] and nCOWI[n])    "REPORT VARIABLE - Comparison with COWI"
    MW_PrimaryBurn_tot[t]$(sum(n, d1qWasteE_burn['DK','Municipal Waste',n,t]))                  "REPORT VARIABLE - Comparison with COWI"
    MW_FinalBurn[n,t]$(tx0[t] and d1qWasteE_burn['DK','Municipal Waste',n,t] and nCOWI[n])      "REPORT VARIABLE - Comparison with COWI"
    MW_FinalBurn_tot[t]$(sum(n, d1qWasteE_burn['DK','Municipal Waste',n,t]))                    "REPORT VARIABLE - Comparison with COWI"
    MW_PrimaryLandfill[n,t]$(tx0[t] and (d1qWasteD['DK','Municipal Waste',n,t] or d1qWasteD_ex['DK','Municipal Waste',n,t]) and nCOWI[n])   "REPORT VARIABLE - Comparison with COWI"
    MW_PrimaryLandfill_tot[t]$(sum(n, d1qWasteD['DK','Municipal Waste',n,t]))                   "REPORT VARIABLE - Comparison with COWI"
    MW_FinalLandfill[n,t]$(tx0[t] and (d1qWasteD['DK','Municipal Waste',n,t] or d1qWasteD_ex['DK','Municipal Waste',n,t]) and nCOWI[n])     "REPORT VARIABLE - Comparison with COWI"
    MW_FinalLandfill_tot[t]$(sum(n, d1qWasteD['DK','Municipal Waste',n,t]))                     "REPORT VARIABLE - Comparison with COWI"
;
$ENDIF

$IF %stage% == "groupCompilation":

$GROUP G_waste_exo
    G_waste_param
    
    # Variables from other modules that is used as exogenous variables in the waste module
    qRxE[r_,t]$(tx0[t] and d1Waste_qRxE[r_,t])
    qCHH[c_,t]$(tx0[t] and (sameas[c_,'cNonFood'] or sameas[c_,'cFood'] or sameas[c_,'cGoo']))   
    qREgj$(d1qREgj[purpose,energy19,r,t] and sameas[energy19,'waste'] and tx0[t])

    # Adjustment terms related to variables from other modules
    jqRENEWABLEWaste[t]$(tx0[t])                                                                                    "Adjustment term to ensure that energy from burning waste matches data"
    jwaste_qREgj[t]$(tx0[t])                                                                                        "Adjustment term to ensure that burned waste matches data for qREgj in historic years"
    jEmmProdWaste[s,t,emm]$(tx0[t] and sum(purpose, d1EmmProdE[s,t,emm,purpose, "waste"]) and d1uEmmWaste[s,t,emm]) "Additive adjustment term to ensure that emissions coefficient matches emissions data for each sector"
    jWaste_restaffald_export[t]$(tx0[t])                                                                            "Additive adjustment term to ensure that exported burned 'restaffald' matches historic data"
    jWaste_restaffald_export_MW[t]$(tx0[t])                                                                         "Additive adjustment term to ensure that exported burned 'restaffald' matches historic data for MW"

;

$GROUP G_waste_endo
    G_wasteGeneration_quantities 
    G_wasteSorting_quantities
    G_wasteTreatment_quantities
    G_waste_export  
    G_links_waste
    G_wasteTreatment_quantities_ExclResWaste
    G_report_waste      
    G_report_COWI                                                      
;

$GROUP G_waste_endo G_waste_endo$(tx0[t]);

$GROUP G_waste_data
    qWasteQ_GEN_ARIMA[sec,g_waste,n,t]$(d1qWasteQ_GEN[sec,g_waste,n,t]) 
    qWasteQ_ARIMA[sec,g_waste,n,t]$(d1qWasteQ_ARIMA[sec,g_waste,n,t]) # Previous difference is not zero for the fraction 'Dag', because the waste is redistributed between 'Manufacturing Waste' and 
                                                                      # 'Municipal Waste' based on the sorting of the other fractions. The sum of 'Manufacturing Waste' and 'Municipal Waste' is the same.
    qWasteQ_im[g_waste,n,t]$(d1qWasteQ_bar_dom['Import',g_waste,n,t])

    # The data check is performed using the treatment variables exclusive residual waste, because the data doesn't include residual waste
    qWasteR_ExclResWaste[origin_waste,g_waste,n,t]$(d1qWasteR[origin_waste,g_waste,n,t])                 
    qWasteE_ExclResWaste[origin_waste,g_waste,n,t]$(d1qWasteE[origin_waste,g_waste,n,t]) # previous difference is not zero for the fraction 'Dag' (see above comment)                    
    qWasteD_ExclResWaste[origin_waste,g_waste,n,t]$(d1qWasteD[origin_waste,g_waste,n,t]) # previous difference is not zero for the fraction 'Dag' (see above comment)             

    qWasteQ_ex[origin_waste,g_waste,n,t]$(d1qWasteQ_ex[origin_waste,g_waste,n,t]) # previous difference is not zero for the fraction 'Dag' (see above comment)
    qWasteR_ex[origin_waste,g_waste,n,t]$(d1qWasteR_ex[origin_waste,g_waste,n,t])
    qWasteE_ex[origin_waste,g_waste,n,t]$(d1qWasteE_ex[origin_waste,g_waste,n,t])
    qWasteD_ex[origin_waste,g_waste,n,t]$(d1qWasteD_ex[origin_waste,g_waste,n,t]) # previous difference is not zero for the fraction 'Dag' (see above comment)
;

$PGROUP PGROUP_Waste_NonFlat_Dummies
  d1qWasteQ_GEN[sec,g_waste,n,t]   
  d1qWasteQ_ARIMA[sec,g_waste,n,t]                                     
  d1qWasteQ_bar[g_waste,n,t]                      
  d1qWasteQ_bar_dom[origin_waste,g_waste,n,t]     
  d1qWasteD[origin_waste,g_waste,n,t]             
  d1qWasteE[origin_waste,g_waste,n,t]             
  d1qWasteE_burn[origin_waste,g_waste,n,t]    
  d1qWasteE_utilize[origin_waste,g_waste,n,t]    
  d1qWasteR[origin_waste,g_waste,n,t]     
  d1WasteResidual[origin_waste,g_waste,n,gg_waste,nn,t]    
  d1WasteCET[origin_waste,g_waste,n,t] 
 
  d1qWasteQ_ex[origin_waste,g_waste,n,t]          
  d1qWasteD_ex[origin_waste,g_waste,n,t]          
  d1qWasteE_ex[origin_waste,g_waste,n,t]          
  d1qWasteR_ex[origin_waste,g_waste,n,t]      
  d1WasteCET_ex[origin_waste,g_waste,n,t] 

  d1qWaste_adjustExport_D[g_waste,n,t]                  
  d1qWaste_adjustExport_R[g_waste,n,t]                  
  d1qWaste_adjustExport_E_burn[g_waste,n,t]             
  d1qWaste_adjustExport_E_utilize[g_waste,n,t]          

  d1qWaste_reexport_R[g_waste,n,t]                      
  d1qWaste_reexport_D[g_waste,n,t]                      
  d1qWaste_reexport_burn[g_waste,n,t]                   
  d1qWaste_reexport_utilize[g_waste,n,t]             
;

$PGROUP PGROUP_WasteKlimaplan_NonFlat_Dummies
  d1WasteKlimaplan_GEN[sec,g_waste,n,t]
  d1WasteKlimaplan_SORT[sec,g_waste,n,t]          
  d1WasteKlimaplan_Chi[origin_waste,g_waste,n,t]
  d1qWasteQ[sec,g_waste,n,t]
;

$GROUP G_waste_2014_2020  
  # Parameters calculated bases on waste data
  uWasteD,  uWasteChi,  uWasteChi_E,  uWaste_MWshare_im,  uWaste_im,
  uWaste_ex,  uWasteD_ex,  uWasteChi_ex,  uWasteChi_E_ex

  # Waste data
  qWasteD_DK,               qWasteR_DK,  qWasteE_utilize_DK,  qWasteE_burn_DK,  #qWasteE_DK, akb: Den her er ikke nogen steder?
  qWasteD_im,               qWasteR_im,  qWasteE_utilize_im,  qWasteE_burn_im,  #qWasteE_im, akb: See above
  qWasteD_ex_data,  qWasteR_ex_data,  qWasteE_utilize_ex_data,  qWasteE_burn_ex_data

  # Waste generation variables
  qWasteQ_GEN_ARIMA,  qWasteQ_GEN,  qWasteQ_ARIMA,  qWasteQ,  qWasteRestaffald

  # Waste treatment variables
  qWasteQ_bar,  qWasteQ_im,  qWasteQ_bar_dom,  qWasteW,  qWasteD,  qWasteE,
  qWasteE_utilize,  qWasteE_burn,  qWasteR,  qWasteR_bar,  qWasteM_R_bar,
  qWasteQ_R_out,  qWasteQ_R_out_in,  qWasteQ_R_in, qWasteM_R_bar_emissions
  qWasteM_R_bar_AEM

  # Waste export variables
  qWasteQ_ex,  qWasteW_ex,  qWasteD_ex,  qWasteE_ex,  qWasteE_utilize_ex,
  qWasteE_burn_ex,  qWasteR_ex,  qWasteR_bar_ex 

  # Variables for DTU
  qWasteQ_bar_dom_ExclResWaste,  qWasteQ_ex_ExclResWaste,  qWasteD_ExclResWaste,
  qWasteE_ExclResWaste,  qWasteE_utilize_ExclResWaste,  qWasteE_burn_ExclResWaste,
  qWasteR_ExclResWaste,  qWasteQ_bar_dom_ExclResWaste_tot,  qWasteQ_im_ExclResWaste_tot,
  qWasteQ_ex_ExclResWaste_tot,  qWasteD_ExclResWaste_tot,  qWasteE_ExclResWaste_tot,
  qWasteE_utilize_ExclResWaste_tot,  qWasteE_burn_ExclResWaste_tot,
  qWasteR_ExclResWaste_tot,  qWasteQ_R_out_in_tot


  # Waste report variables
  qWasteQ_GEN_tot,  qWasteQ_GEN_fraktion,  qWasteQ_GEN_type,  qWasteQ_GEN_MWhus,
  qWasteQ_GEN_MWerhv,  qWasteQ_GEN_MW,  qWasteQ_SORT_tot,  qWasteQ_SORT_fraktion, qWasteQ_SORT_type,
  qWasteRestaffald_tot,  qWasteRestaffald_fraktion,  qWasteQ_bar_dom_tot,
  qWasteQ_bar_dom_fraktion,  qWasteD_tot,  qWasteD_fraktion,  qWasteE_utilize_tot,
  qWasteE_utilize_fraktion,  qWasteE_burn_tot,  qWasteE_burn_fraktion,  qWasteR_bar_tot,
  qWasteR_bar_fraktion,  qWasteQ_R_out_tot,  qWasteQ_R_out_fraktion,  qWasteM_R_bar_tot,
  qWasteM_R_bar_fraktion,  qWasteQ_ex_tot,  qWasteQ_ex_fraktion,  qWasteQ_im_tot,
  qWasteQ_im_fraktion,  qWasteQ_ex_Restaffald,  qWasteQ_im_Restaffald
  qWasteQ_bar_dom_POT, qWasteD_POT, qWasteE_burn_POT

  Genanvendelsesprocent_MW,  Genanvendelsesprocent_MW_tot

  # Waste report variables to compare with the COWI-model
  MW_Primary, MW_Primary_tot, MW_PrimaryRecycling, MW_PrimaryRecycling_tot, MW_FinalRecycling,
  MW_FinalRecycling_tot, MW_PrimaryUtilization, MW_PrimaryUtilization_tot, MW_FinalUtilization,
  MW_FinalUtilization_tot, MW_PrimaryBurn, MW_PrimaryBurn_tot, MW_FinalBurn, MW_FinalBurn_tot,
  MW_PrimaryLandfill, MW_PrimaryLandfill_tot, MW_FinalLandfill, MW_FinalLandfill_tot
;

$GROUP G_waste_projection_data_arima  
  uWaste_arima_GEN
  uWaste_arima_SORT
;

$GROUP G_waste_klimaplan_virkemidler
  uWasteKlimaplan_GEN
  uWasteKlimaplan_SORT
  uWasteKlimaplan_Chi
;

$GROUP G_waste_CET_function
  uWasteOmega
  uWasteGamma
  uWasteEpsilon
  uWasteXi_E
  uWasteXi_R   
;
    
$ENDIF



# ======================================================================================================================
# Equations 
# ======================================================================================================================
$IF %stage% == "equations":
# ------------------------------------------------------------------------------------------------------------------------
# Waste generation (seen as exogenous in the partial waste model)
# ------------------------------------------------------------------------------------------------------------------------
    $BLOCK B_waste_GEN_ARIMA
    # FORECAST OF GENERATED WASTE FOR SECTORS - BASED ON ARIMA-COEFFICIENTS AND MATERIALINPUT
    E_Waste_WasteGeneration_arima_sec[sec,g_waste,n,t]$(tx0[t] and (not sameas[sec,'hus']) and d1qWasteQ_GEN[sec,g_waste,n,t])..                   
        qWasteQ_GEN_ARIMA[sec,g_waste,n,t]$(not sameas[sec,'hus']) =E= uWaste_MWshare[sec,g_waste,n,t]*uWaste_adjust_GEN[sec,g_waste,n,t]*uWaste_adjust_GEN_2020[sec,g_waste,n,t]
                                                                                *uWaste_arima_GEN[sec,n,t]*sum(r$(sec2r(r,sec)), qRxE[r,t])/growth_factor[t];

    # ARIMA FORECAST OF GENERATED WASTE FOR HOUSEHOLDS - BASED ON ARIMA-COEFFICIENTS AND PRIVATE CONSUMPTION
    E_Waste_WasteGeneration_arima_hus_NonFood[sec,g_waste,n,t]$(tx0[t] and sameas[sec,'hus'] and d1qWasteQ_GEN[sec,g_waste,n,t] and n_cNonFood(n))..                                
        qWasteQ_GEN_ARIMA[sec,g_waste,n,t]$(sameas[sec,'hus'] and n_cNonFood(n)) =E= uWaste_MWshare[sec,g_waste,n,t]*uWaste_adjust_GEN[sec,g_waste,n,t]*uWaste_adjust_GEN_2020[sec,g_waste,n,t]
                                                                                *UWaste_arima_hus_adjust[t]*uWaste_arima_GEN[sec,n,t]*qCHH['cNonFood',t]/growth_factor[t];                                                                                

    E_Waste_WasteGeneration_arima_hus_Food[sec,g_waste,n,t]$(tx0[t] and sameas[sec,'hus'] and d1qWasteQ_GEN[sec,g_waste,n,t] and n_cFood(n))..                                
        qWasteQ_GEN_ARIMA[sec,g_waste,n,t]$(sameas[sec,'hus'] and n_cFood(n)) =E= uWaste_MWshare[sec,g_waste,n,t]*uWaste_adjust_GEN[sec,g_waste,n,t]*uWaste_adjust_GEN_2020[sec,g_waste,n,t]
                                                                                *UWaste_arima_hus_adjust[t]*uWaste_arima_GEN[sec,n,t]*qCHH['cFood',t]/growth_factor[t];

    E_Waste_WasteGeneration_arima_hus_Good[sec,g_waste,n,t]$(tx0[t] and sameas[sec,'hus'] and d1qWasteQ_GEN[sec,g_waste,n,t] and n_cGood(n))..                                
        qWasteQ_GEN_ARIMA[sec,g_waste,n,t]$(sameas[sec,'hus'] and n_cGood(n)) =E= uWaste_MWshare[sec,g_waste,n,t]*uWaste_adjust_GEN[sec,g_waste,n,t]*uWaste_adjust_GEN_2020[sec,g_waste,n,t]
                                                                                *UWaste_arima_hus_adjust[t]*uWaste_arima_GEN[sec,n,t]*qCHH['cGoo',t]/growth_factor[t];   

    # FORECAST OF GENERATED WASTE WITH THE POSSIBLE EFFECTS FROM THE CLIMATE PLAN
    E_Waste_WasteGeneration_virkemidler[sec,g_waste,n,t]$(tx0[t] and d1qWasteQ_GEN[sec,g_waste,n,t])..                   
        qWasteQ_GEN[sec,g_waste,n,t] =E= (1-(uWasteKlimaplan_GEN[sec,g_waste,n,t])$(d1WasteKlimaplan_GEN[sec,g_waste,n,t]))*qWasteQ_GEN_ARIMA[sec,g_waste,n,t];
    $ENDBLOCK

# ------------------------------------------------------------------------------------------------------------------------
# Waste sorting (seen as exogenous in the partial waste model)
# ------------------------------------------------------------------------------------------------------------------------
    $BLOCK B_waste_SORT_ARIMA
    # FORECAST OF SORTED WASTE FOR ALL OTHER FRACTIONS THAN 'Dag' (restaffald) 
    E_Waste_WasteSorting_arima[sec,g_waste,n,t]$(tx0[t] and (not sameas[n,'Dag']) and d1qWasteQ_ARIMA[sec,g_waste,n,t])..                   
        qWasteQ_ARIMA[sec,g_waste,n,t]$(not sameas[n,'Dag']) =E= uWaste_arima_SORT[sec,n,t]*qWasteQ_GEN[sec,g_waste,n,t];        

    # FORECAST OF SORTED WASTE FOR 'DAG' BASED ON THE GENERATED AMOUNT OF 'DAG' AND THE SORTING OF THE OTHER FRACTIONS 
    E_Waste_WasteSorting_arima_dag[sec,g_waste,n,t]$(tx0[t] and sameas[n,'Dag'] and d1qWasteQ_ARIMA[sec,g_waste,n,t])..                   
        qWasteQ_ARIMA[sec,g_waste,n,t]$(sameas[n,'Dag']) =E= qWasteQ_GEN[sec,g_waste,'Dag',t] 
                                                                        + sum(nn$((not sameas[nn,'Dag']) and d1qWasteQ_GEN[sec,g_waste,nn,t]), 
                                                                                (1-uWaste_arima_SORT[sec,nn,t])*qWasteQ_GEN[sec,g_waste,nn,t]);
                                                             

    # FORECAST OF SORTED WASTE FOR ALL OTHER FRACTIONS THAN 'DAG' WITH THE POSSIBLE EFFECTS FROM THE CLIMATE PLAN
    E_Waste_WasteSorting_virkemidler[sec,g_waste,n,t]$(tx0[t] and (not sameas[n,'Dag']) and d1qWasteQ[sec,g_waste,n,t])..                   
        qWasteQ[sec,g_waste,n,t]$(not sameas[n,'Dag']) =E= qWasteQ_ARIMA[sec,g_waste,n,t]$(d1qWasteQ_ARIMA[sec,g_waste,n,t])
                                                                + uWasteKlimaplan_SORT[sec,g_waste,n,t]$(d1WasteKlimaplan_SORT[sec,g_waste,n,t])
                                                                    *(qWasteQ_GEN[sec,g_waste,n,t]$(d1qWasteQ_GEN[sec,g_waste,n,t])-qWasteQ_ARIMA[sec,g_waste,n,t]$(d1qWasteQ_ARIMA[sec,g_waste,n,t]));
        
    # FORECAST OF SORTED WASTE FOR 'DAG' (RESTAFFALD) - WITH THE EFFECTS FROM THE CLIMATE PLAN
    E_Waste_WasteSorting_virkemidler_Dag[sec,g_waste,n,t]$(tx0[t] and sameas[n,'Dag'] and d1qWasteQ_ARIMA[sec,g_waste,n,t])..                   
        qWasteQ[sec,g_waste,n,t]$(sameas[n,'Dag']) =E= qWasteQ_ARIMA[sec,g_waste,n,t]-(sum(nn$(not sameas[nn,'Dag'] and d1WasteKlimaplan_SORT[sec,g_waste,nn,t]), uWasteKlimaplan_SORT[sec,g_waste,nn,t]
                                                                    *(qWasteQ_GEN[sec,g_waste,nn,t]$(d1qWasteQ_GEN[sec,g_waste,nn,t])-qWasteQ_ARIMA[sec,g_waste,nn,t]$(d1qWasteQ_ARIMA[sec,g_waste,nn,t]))));

    # AMOUNT OF EACH WASTE FRACTION THAT IS NOT SORTED AND ENDS UP IN 'RESTAFFALDET' 
    E_waste_restaffald[sec,g_waste,n,t]$(tx0[t] and d1qWasteQ_GEN[sec,g_waste,n,t])..
        qWasteRestaffald[sec,g_waste,n,t] =E= qWasteQ_GEN[sec,g_waste,n,t]-qWasteQ[sec,g_waste,n,t]$(d1qWasteQ[sec,g_waste,n,t] and not sameas[n,'Dag']);

    $ENDBLOCK    

# ------------------------------------------------------------------------------------------------------------------------
# Start of the partial waste model 
# ------------------------------------------------------------------------------------------------------------------------
    # ------------------------------------------------------------------------------------------------------------------------
    # The waste treatment sector
    # --------------------------------------------------------------------------------------------------------------------s----
    $BLOCK B_waste_treatment
    # DOMESTICALLY GENERATED WASTE INCLUDING RESIDUAL WASTE
    E_Waste_DomesticWaste[g_waste,n,t]$(tx0[t] and d1qWasteQ_bar[g_waste,n,t])..                    
        qWasteQ_bar[g_waste,n,t] =E= sum(sec$(d1qWasteQ[sec,g_waste,n,t]), qWasteQ[sec,g_waste,n,t])
         + qWasteQ_R_in['DK',g_waste,n,t]$(sum((gg_waste,nn), d1WasteResidual['DK',gg_waste,nn,g_waste,n,t]));

    # DOMESTIC WASTE FOR DOMESTIC TREATMENT (SUBTRACTING EXPORTED WASTE)
    E_Waste_WasteForDomTREAT_DK[origin_waste,g_waste,n,t]$(tx0[t] and d1qWasteQ_bar_dom[origin_waste,g_waste,n,t] and sameas[origin_waste,'DK'])..                    
        qWasteQ_bar_dom['DK',g_waste,n,t] =E= qWasteQ_bar[g_waste,n,t]-qWasteQ_ex['DK',g_waste,n,t]$(d1qWasteQ_ex['DK',g_waste,n,t]); 

    # IMPORTED WASTE FOR DOMESTIC TREATMENT FOR ALL OTHER FRACTIONS THAN 'RESTAFFALD' 
    E_Waste_Waste_Import[g_waste,n,t]$(tx0[t] and d1qWasteQ_bar_dom['Import',g_waste,n,t] and not sameas[n,'Dag'])..                    
        qWasteQ_im[g_waste,n,t] =E= uWaste_im[g_waste,n,t]*(sum(sec$(d1qWasteQ[sec,g_waste,n,t]), qWasteQ[sec,g_waste,n,t]));

    # IMPORTED WASTE FOR DOMESTIC TREATMENT INCLUDING RESIDUAL WASTE
    E_Waste_WasteForDomTREAT_Import[origin_waste,g_waste,n,t]$(tx0[t] and d1qWasteQ_bar_dom[origin_waste,g_waste,n,t] and sameas[origin_waste,'Import'])..                    
        qWasteQ_bar_dom['Import',g_waste,n,t] =E= qWasteQ_im[g_waste,n,t] + qWasteQ_R_in['Import',g_waste,n,t]$(sum((gg_waste,nn), d1WasteResidual['Import',gg_waste,nn,g_waste,n,t]));                                                 

    # DISPOSED WASTE (LANDFILL)
    E_Waste_LandfillWaste[origin_waste,g_waste,n,t]$(tx0[t] and d1qWasteD[origin_waste,g_waste,n,t])..                    
        qWasteD[origin_waste,g_waste,n,t] =E= uWasteD[origin_waste,g_waste,n,t]*qWasteQ_bar_dom[origin_waste,g_waste,n,t]; 

    # WASTE FOR RECYLING, BURNING OR UTILIZATION
    E_Waste_RecyclableWaste[origin_waste,g_waste,n,t]$(tx0[t] and (d1qWasteE[origin_waste,g_waste,n,t] or d1qWasteR[origin_waste,g_waste,n,t]))..                    
        qWasteW[origin_waste,g_waste,n,t] =E= (1-uWasteD[origin_waste,g_waste,n,t])*qWasteQ_bar_dom[origin_waste,g_waste,n,t]; 

    # WASTE FOR BURNING OR UTILIZATION - WITHOUT EFFECTS FROM THE CLIMATE PLAN
    E_Waste_WasteTreatment[origin_waste,g_waste,n,t]$(tx0[t] and d1qWasteE[origin_waste,g_waste,n,t])..                    
        qWasteE[origin_waste,g_waste,n,t] =E= (1-uWasteChi[origin_waste,g_waste,n,t]-uWasteKlimaplan_Chi[origin_waste,g_waste,n,t]$(d1WasteKlimaplan_Chi[origin_waste,g_waste,n,t]))
                                                    *qWasteW[origin_waste,g_waste,n,t];

    # OTHER UTILIZED WASTE
    E_Waste_OtherUtilized[origin_waste,g_waste,n,t]$(tx0[t] and d1qWasteE_utilize[origin_waste,g_waste,n,t])..                     
        qWasteE_utilize[origin_waste,g_waste,n,t] =E= (1-uWasteChi_E[origin_waste,g_waste,n,t])*qWasteE[origin_waste,g_waste,n,t]; 

    # BURNED WASTE
    E_Waste_Burned[origin_waste,g_waste,n,t]$(tx0[t] and d1qWasteE_burn[origin_waste,g_waste,n,t])..                     
        qWasteE_burn[origin_waste,g_waste,n,t] =E= uWasteChi_E[origin_waste,g_waste,n,t]*qWasteE[origin_waste,g_waste,n,t];

    #  WASTE SEND TO RECYLING
    E_Waste_WasteHierarchy[origin_waste,g_waste,n,t]$(tx0[t] and d1qWasteR[origin_waste,g_waste,n,t])..                     
        qWasteR[origin_waste,g_waste,n,t] =E= (uWasteChi[origin_waste,g_waste,n,t]+uWasteKlimaplan_Chi[origin_waste,g_waste,n,t]$(d1WasteKlimaplan_Chi[origin_waste,g_waste,n,t]))
                                                    *qWasteW[origin_waste,g_waste,n,t];  

    # REEL RECYCLED WASTE DETERMINED BY THE RECYCLING TECHNOLOGY (REPRESENTED BY THE CET-FUNCTIONS)
    E_Waste_CET[origin_waste,g_waste,n,t]$(tx0[t] and d1WasteCET[origin_waste,g_waste,n,t] and not d1Waste_Hardcoded_recycling)..        
        qWasteW[origin_waste,g_waste,n,t] =E= uWasteOmega[g_waste,n,t]*(
            (uWasteGamma[g_waste,n,t]**(1/uWasteEpsilon[g_waste,n,t]))*(qWasteR_bar[origin_waste,g_waste,n,t]**((uWasteEpsilon[g_waste,n,t]-1)/uWasteEpsilon[g_waste,n,t]))
            +(((1-uWasteGamma[g_waste,n,t])**(1/uWasteEpsilon[g_waste,n,t]))*((qWasteE[origin_waste,g_waste,n,t])**((uWasteEpsilon[g_waste,n,t]-1)/uWasteEpsilon[g_waste,n,t])))$(d1qWasteE[origin_waste,g_waste,n,t])
                                                                            )**(uWasteEpsilon[g_waste,n,t]/(uWasteEpsilon[g_waste,n,t]-1)) 
            + uWasteXi_E[g_waste,n,t]*qWasteE[origin_waste,g_waste,n,t]$(d1qWasteE[origin_waste,g_waste,n,t])
            + uWasteXi_R[g_waste,n,t]*qWasteR_bar[origin_waste,g_waste,n,t];

    # HARDCODED DEGREE OF RECYCLING: REEL RECYCLED WASTE  DETERMINED BY HARDCODED DEGREE OF RECYCLING (REPLACES THE CET-FUNCTION)
    E_Waste_Recycling_Hardcoded[origin_waste,g_waste,n,t]$(tx0[t] and d1WasteCET[origin_waste,g_waste,n,t] and d1Waste_Hardcoded_recycling)..
        qWasteR_bar[origin_waste,g_waste,n,t] =E= uWasteR[g_waste,n,t]*qWasteR[origin_waste,g_waste,n,t];

    # RESIDUAL WASTE OF FRACTION 'nn' OG TYPE 'gg_waste' FROM THE RECYCLING PROCESS OF FRACTION 'n' OF TYPE 'g_waste' 
    E_Waste_ResWaste[origin_waste,g_waste,n,gg_waste,nn,t]$(tx0[t] and d1WasteResidual[origin_waste,g_waste,n,gg_waste,nn,t])..
        qWasteQ_R_out_in[origin_waste,g_waste,n,gg_waste,nn,t] =E= uWastePhi_R[g_waste,n,gg_waste,nn,t]*uWasteBeta_R[g_waste,n,t]*(qWasteR[origin_waste,g_waste,n,t]-qWasteR_bar[origin_waste,g_waste,n,t])$(sum((ggg_waste,nnn), d1WasteResidual[origin_waste,g_waste,n,ggg_waste,nnn,t]));

    # RESIDUAL WASTE FROM THE RECYCLING PROCESS
    E_Waste_ResWasteAgg[origin_waste,g_waste,n,t]$(tx0[t] and sum((gg_waste,nn), d1WasteResidual[origin_waste,g_waste,n,gg_waste,nn,t]))..
        qWasteQ_R_out[origin_waste,g_waste,n,t] =E= sum((gg_waste,nn)$(d1WasteResidual[origin_waste,g_waste,n,gg_waste,nn,t]), qWasteQ_R_out_in[origin_waste,g_waste,n,gg_waste,nn,t]);

     # EMISSIONS FROM RECYLING TO ENSURE MASS BALANCE IN THE RECYCLING PROCESS
    E_Waste_MassBalance[origin_waste,g_waste,n,t]$(tx0[t] and d1qWasteR[origin_waste,g_waste,n,t])..           
        qWasteM_R_bar[origin_waste,g_waste,n,t] =E= qWasteR[origin_waste,g_waste,n,t]-qWasteR_bar[origin_waste,g_waste,n,t] 
                - (qWasteQ_R_out[origin_waste,g_waste,n,t])$(sum((gg_waste,nn), d1WasteResidual[origin_waste,g_waste,n,gg_waste,nn,t]));

    # RESIDUAL WASTE GOING BACK INTO THE TREATMENT SECTOR
    E_Waste_ResWasteToCollection[origin_waste,g_waste,n,t]$(tx0[t] and sum((gg_waste,nn), d1WasteResidual[origin_waste,gg_waste,nn,g_waste,n,t]))..
        qWasteQ_R_in[origin_waste,g_waste,n,t] =E= sum((gg_waste,nn)$(d1WasteResidual[origin_waste,gg_waste,nn,g_waste,n,t]), qWasteQ_R_out_in[origin_waste,gg_waste,nn,g_waste,n,t]);
    
    E_Waste_Emissions_recycling[origin_waste,g_waste,n,t]$(tx0[t] and d1qWasteR[origin_waste,g_waste,n,t] and (sameas[n,'Org'] or sameas[n,'Have']))..           
        qWasteM_R_bar_emissions[origin_waste,g_waste,n,t] =E= qWasteM_R_bar[origin_waste,g_waste,n,t];    

    E_Waste_AEM_recycling[origin_waste,g_waste,n,t]$(tx0[t] and d1qWasteR[origin_waste,g_waste,n,t] and (sameas[n,'byg'] or sameas[n,'Rest'] or sameas[n,'Tekst']))..           
        qWasteM_R_bar_AEM[origin_waste,g_waste,n,t] =E= qWasteM_R_bar[origin_waste,g_waste,n,t];    

    # (NY LIGNING) EMISSIONS FROM RECYCLING - Er ikke slået til endnu, da vi mangler data for uWastePsi_M
    #  E_Waste_EmisRecycling[emm,g_waste,n,t]$(tx0[t] and d1qWasteR[g_waste,n,t])..
    #      qWasteM_R[emm,g_waste,n,t] =E= uWastePsi_M[emm,g_waste,n,t]*qWasteM_R_bar[g_waste,n,t];
    $ENDBLOCK

    # ------------------------------------------------------------------------------------------------------------------------
    # Export equations
    # ------------------------------------------------------------------------------------------------------------------------
    $BLOCK B_waste_export
    # EXPORTED WASTE FOR ALL OTHER FRACTIONS THAN 'RESTAFFALD'
    E_Waste_WasteGeneration_Export[origin_waste,g_waste,n,t]$(tx0[t] and d1qWasteQ_ex[origin_waste,g_waste,n,t] and not (sameas[n,'Dag'] and sameas[origin_waste,'DK']))..                         
        qWasteQ_ex[origin_waste,g_waste,n,t] =E= uWaste_ex[origin_waste,g_waste,n,t]*(sum(sec$(d1qWasteQ[sec,g_waste,n,t]), qWasteQ[sec,g_waste,n,t]));

    # EXPORTED DISPOSED WASTE
    E_Waste_LandfillWaste_Export[origin_waste,g_waste,n,t]$(tx0[t] and d1qWasteD_ex[origin_waste,g_waste,n,t])..                    
        qWasteD_ex[origin_waste,g_waste,n,t] =E= uWasteD_ex[origin_waste,g_waste,n,t]*qWasteQ_ex[origin_waste,g_waste,n,t];

    # EXPORTED WASTE FOR RECYLING, BURNING OR UTILIZATION
    E_Waste_RecyclableWaste_Export[origin_waste,g_waste,n,t]$(tx0[t] and d1qWasteQ_ex[origin_waste,g_waste,n,t])..                    
        qWasteW_ex[origin_waste,g_waste,n,t] =E= (1-uWasteD_ex[origin_waste,g_waste,n,t])*qWasteQ_ex[origin_waste,g_waste,n,t]; 

    # EXPORTED WASTE FOR BURNING OR UTILIZATION
    E_Waste_WasteTreatment_Export[origin_waste,g_waste,n,t]$(tx0[t] and d1qWasteE_ex[origin_waste,g_waste,n,t])..                    
        qWasteE_ex[origin_waste,g_waste,n,t] =E= (1-uWasteChi_ex[origin_waste,g_waste,n,t])*qWasteW_ex[origin_waste,g_waste,n,t];

    # EXPORTED UTILIZED WASTE
    E_Waste_OtherUtilized_Export[origin_waste,g_waste,n,t]$(tx0[t] and d1qWasteE_ex[origin_waste,g_waste,n,t])..                     
        qWasteE_utilize_ex[origin_waste,g_waste,n,t] =E= (1-uWasteChi_E_ex[origin_waste,g_waste,n,t])*qWasteE_ex[origin_waste,g_waste,n,t];

    # EXPORTED BURNED WASTE
    E_Waste_Burned_Export[origin_waste,g_waste,n,t]$(tx0[t] and d1qWasteE_ex[origin_waste,g_waste,n,t])..                     
        qWasteE_burn_ex[origin_waste,g_waste,n,t] =E= uWasteChi_E_ex[origin_waste,g_waste,n,t]*qWasteE_ex[origin_waste,g_waste,n,t];

    # EXPORTED WASTE SEND TO RECYCLING
    E_Waste_WasteHierarchy_Export[origin_waste,g_waste,n,t]$(tx0[t] and d1qWasteR_ex[origin_waste,g_waste,n,t])..                      
        qWasteR_ex[origin_waste,g_waste,n,t] =E= uWasteChi_ex[origin_waste,g_waste,n,t]*qWasteW_ex[origin_waste,g_waste,n,t];

    # EXPORTED REEL RECYCLED WASTE DETERMINED BY THE RECYCLING TECHNOLOGY (REPRESENTED BY THE CET-FUNCTIONS)
    E_Waste_CET_Export[origin_waste,g_waste,n,t]$(tx0[t] and d1WasteCET_ex[origin_waste,g_waste,n,t])..          
        qWasteW_ex[origin_waste,g_waste,n,t] =E= uWasteOmega[g_waste,n,t]*(
            (uWasteGamma[g_waste,n,t]**(1/uWasteEpsilon[g_waste,n,t]))*(qWasteR_bar_ex[origin_waste,g_waste,n,t]**((uWasteEpsilon[g_waste,n,t]-1)/uWasteEpsilon[g_waste,n,t]))
            +(((1-uWasteGamma[g_waste,n,t])**(1/uWasteEpsilon[g_waste,n,t]))*((qWasteE_ex[origin_waste,g_waste,n,t])**((uWasteEpsilon[g_waste,n,t]-1)/uWasteEpsilon[g_waste,n,t])))$(d1qWasteE_ex[origin_waste,g_waste,n,t])
                                                                )**(uWasteEpsilon[g_waste,n,t]/(uWasteEpsilon[g_waste,n,t]-1)) 
            + uWasteXi_E[g_waste,n,t]*qWasteE_ex[origin_waste,g_waste,n,t]$(d1qWasteE_ex[origin_waste,g_waste,n,t]) 
            + uWasteXi_R[g_waste,n,t]*qWasteR_bar_ex[origin_waste,g_waste,n,t];
    $ENDBLOCK

    # ------------------------------------------------------------------------------------------------------------------------
    # Links to the rest of the CGE-model
    # ------------------------------------------------------------------------------------------------------------------------
    $BLOCK B_links_waste
    # THE NET IMPORT OF 'RESTAFFALD' (qWaste_ex_im) CLEARS THE MARKET FOR BURNED WASTE. 
    # THE LEFT SIDE IS THE DEMAND FOR BURNED WASTE FROM THE ENERGY MODULE (qREgj) MEASURED IN ENERGY VALUE (PJ).
    # THE RIGHT SIDE IS THE SUPPLY OF BURNED WASTE FROM THE WASTE MODULE MEASURED IN ENERGY VALUE (PJ)
    #    ( BURNED DK WASTE IN DK OF ALL OTHER FRACTIONS THAN 'DAG'
    #    + BURNED DK WASTE IN DK OF THE FRACTION 'DAG' + EXPORTED BURNED DK WASTE OF THE FRACTION 'DAG' (= TOTAL BURNED DK WASTE OF THE FRACTION 'DAG')
    #    + BURNED IMPORTED WASTE OF ALL OTHER FRACTIONS THAN 'DAG'
    #    + NET IMPORT OF BURNED WASTE OF THE FRACTION 'DAG') 
    # SO THE EQUATION DETERMINES THE VARIABLE qWasteQ_ex_im[t]
    E_Waste_DemandForBurnedWaste[t]$(tx0[t])..                    
        sum((purpose,s)$(d1qREgj[purpose,"waste",s,t]), qREgj[purpose,"waste",s,t]) =E= jwaste_qREgj[t]*
                                  ((sum((g_waste,n)$(d1uWasteEnergyValue[n,t] and d1qWasteE_burn['DK',g_waste,n,t] and not sameas[n,'Dag']), 
                                    uWasteEnergyValue[n,t]/(10**3)*qWasteE_burn['DK',g_waste,n,t]))*growth_factor[t]
                                 + (sum((g_waste,n)$(d1uWasteEnergyValue[n,t] and d1qWasteE_burn['DK',g_waste,n,t] and sameas[n,'Dag']), 
                                    uWasteEnergyValue[n,t]/(10**3)*(qWasteE_burn['DK',g_waste,n,t]+qWasteE_burn_ex['DK',g_waste,n,t])))*growth_factor[t]
                                 + (sum((g_waste,n)$(d1uWasteEnergyValue[n,t] and d1qWasteE_burn['Import',g_waste,n,t] and not sameas[n,'Dag']), 
                                    uWasteEnergyValue[n,t]/(10**3)*qWasteE_burn['Import',g_waste,n,t]))*growth_factor[t]
                                 + (uWasteEnergyValue['Dag',t]/(10**3)*qWasteQ_ex_im[t])*growth_factor[t]); 

    # NET IMPORT OF BURNED 'RESTAFFALD' (THE EQUATION DETERMINES THE VARIABLE qWasteE_burn_ex['DK','Municipal Waste','Dag',t])
    E_Waste_netto_export_dag[t]$(tx0[t])..
        qWasteQ_ex_im[t] =E= sum(g_waste, qWasteE_burn['Import',g_waste,'Dag',t] -  (qWasteE_burn_ex['DK',g_waste,'Dag',t]+jWaste_restaffald_export_MW[t]));

    # THE TOTAL IMPORTED BURNED 'RESTAFFALD'
    # IF NET IMPORT > 0 => IMPORTED 'RESTAFFALD' = NET IMPORT 
    #                      AND EXPORTED 'RESTAFFALD' = 0
    # IF NET IMPORT < 0 => IMPORTED 'RESTAFFALD' = RESIDUALT RESTAFFALD FROM THE RECYLING OF IMPORTED WASTE
    #                      AND EXPORTED 'RESTAFFALD' = NET IMPORT + RESIDUALT RESTAFFALD FROM THE RECYLING OF IMPORTED WASTE
    # THE EQUATION DETERMINES THE VARIABLE qWasteE_burn['Import','Municipal Waste','Dag',t]
    E_Waste_import_dag[t]$(tx0[t])..
        sum(g_waste, qWasteE_burn['Import',g_waste,'Dag',t]) =E= @cdfNorm(qWasteQ_ex_im[t],0,0.5)*qWasteQ_ex_im[t]
                                         +((1-@cdfNorm(uWaste_MWshare_im['Manufacturing Waste','Dag',t]*qWasteQ_ex_im[t]-qWasteQ_R_in['Import','Manufacturing Waste','Dag',t],0,0.5))
                                                *qWasteQ_R_in['Import','Manufacturing Waste','Dag',t]);

    # DISTRIBUTION BETWEEN 'MANUFACTURING WASTE' AND 'MUNICIPAL WASTE' FOR IMPORTED 'RESTAFFALD'
    # THE EQUATION DETERMINES THE VARIABLE qWasteE_burn['Import','Manufacturing Waste','Dag',t]
    E_Waste_import_dag_Manufacturing[t]$(tx0[t])..
        qWasteQ_im['Manufacturing Waste','Dag',t] =E= uWaste_MWshare_im['Manufacturing Waste','Dag',t]*sum(g_waste, qWasteQ_im[g_waste,'Dag',t]) ;                                                   

    # DISTRIBUTION BETWEEN 'MANUFACTURING WASTE' AND 'MUNICIPAL WASTE' FOR EXPORTED 'RESTAFFALD'
    # THE EQUATION DETERMINES THE VARIABLE qWasteE_burn_ex['DK','Manufacturing Waste','Dag',t]
    E_Waste_WasteForExport_dag[t]$(tx0[t])..
        qWasteE_burn_ex['DK','Manufacturing Waste','Dag',t] =E= (qWasteE_burn['DK','Manufacturing Waste',"Dag",t]/sum(g_waste, qWasteE_burn['DK',g_waste,"Dag",t]))
                                                                    *sum(gg_waste, qWasteE_burn_ex['DK',gg_waste,'Dag',t]) + jWaste_restaffald_export[t];

    # THE ENERGY VALUE OF DOMESTIC GENERATED BURNED WASTE (IN PJ). Note: We re-adjust with growth factor here, since energy is measured in growth-adjusted terms
    E_waste_qburn[t]$(tx0[t])..
        qRENEWABLE["waste",t] =E= jqRENEWABLEWaste[t]*(sum((g_waste,n)$(d1uWasteEnergyValue[n,t] and d1qWasteE_burn['DK',g_waste,n,t]), 
                                    uWasteEnergyValue[n,t]/(10**3)*qWasteE_burn['DK',g_waste,n,t]))*growth_factor[t]; 
                                    # uWasteEnergyValue is dividede with 10^3 to get the result in PJ 

    # TOTAL IMPORT OF BURNED WASTE MEASURED IN ENERGY VALUE (IN PJ)
    E_waste_qburn_import[t]$(tx0[t]).. 
        qM_CET["waste",'19000',t] =E= (sum((g_waste,n)$(d1uWasteEnergyValue[n,t] and d1qWasteE_burn['Import',g_waste,n,t]), 
                                    uWasteEnergyValue[n,t]/(10**3)*qWasteE_burn['Import',g_waste,n,t]))*growth_factor[t];

    # ENDOGENOUS EMISSION COEFFICIENT FOR WASTE THAT DEPENDS ON THE COMPOSITION OF BURNED WASTE 
    # (NOTE: imported waste is ignored, or composition is assumed to follow domestic waste)
    E_waste_uEmmProdWaste[s,t,emm]$(tx0[t] and sum(purpose,d1EmmProdE[s,t,emm,purpose, "waste"]) and d1uEmmWaste[s,t,emm])..
        uEmmProdE[s,t,emm,"waste"] =E= (sum(n$(d1WasteEmissionValue[n,emm,t]), uWasteEmissionCoefficient[n,emm,t] 
                                         *(sum((origin_waste,g_waste)$(d1qWasteE_burn[origin_waste,g_waste,n,t]), qWasteE_burn[origin_waste,g_waste,n,t]))))
                                         /(sum((origin_waste,g_waste,n)$(d1qWasteE_burn[origin_waste,g_waste,n,t]), qWasteE_burn[origin_waste,g_waste,n,t])) + jEmmProdWaste[s,t,emm];

    #  Lock production from the recycling sector to the amount of recycling waste of fractions that are turned into new materials (i.e., not organic waste for recycling) 
    #  E_recycle_production[t]$(tx0[t] and tx1[t])..
    #          qY_CET['out_other','38394',t] =E= qY_CET['out_other','38394',t-1]*g_waste_factor[t];
    $ENDBLOCK


    #  ------------------------------------------------------------------------------------------------------------------------
    #  Waste treatment equations without residual waste (used as input to EASETECH (DTU))
    #  ------------------------------------------------------------------------------------------------------------------------
    $BLOCK B_waste_treatment_ExclResWaste
    
    E_Waste_WasteForDomTREAT_DK_ExclResWaste[origin_waste,g_waste,n,t]$(tx0[t] and d1qWasteQ_bar_dom[origin_waste,g_waste,n,t] and sameas[origin_waste,'DK'])..                    
        qWasteQ_bar_dom_ExclResWaste['DK',g_waste,n,t] =E= sum(sec$(d1qWasteQ[sec,g_waste,n,t]), qWasteQ[sec,g_waste,n,t])-qWasteQ_ex['DK',g_waste,n,t]$(d1qWasteQ_ex['DK',g_waste,n,t]); 

    E_Waste_WasteForDomTREAT_Import_ExclResWaste[origin_waste,g_waste,n,t]$(tx0[t] and d1qWasteQ_bar_dom[origin_waste,g_waste,n,t] and sameas[origin_waste,'Import'])..                    
        qWasteQ_bar_dom_ExclResWaste['Import',g_waste,n,t] =E= uWaste_im[g_waste,n,t]*(sum(sec$(d1qWasteQ[sec,g_waste,n,t]), qWasteQ[sec,g_waste,n,t])); 

    E_Waste_WasteGeneration_Export_ExclResWaste[origin_waste,g_waste,n,t]$(tx0[t] and d1qWasteQ_ex[origin_waste,g_waste,n,t])..                         
        qWasteQ_ex_ExclResWaste[origin_waste,g_waste,n,t] =E= uWaste_ex[origin_waste,g_waste,n,t]*(sum(sec$(d1qWasteQ[sec,g_waste,n,t]), qWasteQ[sec,g_waste,n,t]));

    E_Waste_Landfill_ExclResWaste[origin_waste,g_waste,n,t]$(tx0[t] and d1qWasteD[origin_waste,g_waste,n,t])..           
        qWasteD_ExclResWaste[origin_waste,g_waste,n,t] =E= uWasteD[origin_waste,g_waste,n,t]*qWasteQ_bar_dom_ExclResWaste[origin_waste,g_waste,n,t];

    E_Waste_WasteTreatment_ExclResWaste[origin_waste,g_waste,n,t]$(tx0[t] and d1qWasteE[origin_waste,g_waste,n,t])..               
        qWasteE_ExclResWaste[origin_waste,g_waste,n,t] =E= (1-uWasteChi[origin_waste,g_waste,n,t])*((1-uWasteD[origin_waste,g_waste,n,t])*qWasteQ_bar_dom_ExclResWaste[origin_waste,g_waste,n,t]);

    E_Waste_WasteHierarchy_ExclResWaste[origin_waste,g_waste,n,t]$(tx0[t] and d1qWasteR[origin_waste,g_waste,n,t])..                 
        qWasteR_ExclResWaste[origin_waste,g_waste,n,t] =E= uWasteChi[origin_waste,g_waste,n,t]*((1-uWasteD[origin_waste,g_waste,n,t])*qWasteQ_bar_dom_ExclResWaste[origin_waste,g_waste,n,t]);

    E_Waste_OtherUtilized_ExclResWaste[origin_waste,g_waste,n,t]$(tx0[t] and d1qWasteE[origin_waste,g_waste,n,t])..
        qWasteE_utilize_ExclResWaste[origin_waste,g_waste,n,t] =E= (1-uWasteChi_E[origin_waste,g_waste,n,t])*qWasteE_ExclResWaste[origin_waste,g_waste,n,t];

    E_Waste_Burned_ExclResWaste[origin_waste,g_waste,n,t]$(tx0[t] and d1qWasteE[origin_waste,g_waste,n,t])..
        qWasteE_burn_ExclResWaste[origin_waste,g_waste,n,t] =E= uWasteChi_E[origin_waste,g_waste,n,t]*qWasteE_ExclResWaste[origin_waste,g_waste,n,t];

    # Report variabels to DTU
    E_Waste_WasteForDomTREAT_ExclResWaste_tot[n,t]$(tx0[t] and sum((origin_waste,g_waste), d1qWasteQ_bar_dom[origin_waste,g_waste,n,t]))..                    
        qWasteQ_bar_dom_ExclResWaste_tot[n,t] =E= sum((origin_waste, g_waste)$(d1qWasteQ_bar_dom[origin_waste,g_waste,n,t]), qWasteQ_bar_dom_ExclResWaste[origin_waste,g_waste,n,t]); 

    E_Waste_WasteImport_ExclResWaste_tot[n,t]$(tx0[t] and sum(g_waste, d1qWasteQ_bar_dom['Import',g_waste,n,t]))..
        qWasteQ_im_ExclResWaste_tot[n,t] =E= sum(g_waste$(d1qWasteQ_bar_dom['Import',g_waste,n,t]), qWasteQ_bar_dom_ExclResWaste['Import',g_waste,n,t]);

    E_Waste_WasteGeneration_Export_ExclResWaste_tot[n,t]$(tx0[t] and sum((origin_waste,g_waste), d1qWasteQ_ex[origin_waste,g_waste,n,t]))..                         
        qWasteQ_ex_ExclResWaste_tot[n,t] =E= sum((origin_waste,g_waste)$(d1qWasteQ_ex[origin_waste,g_waste,n,t]), qWasteQ_ex_ExclResWaste[origin_waste,g_waste,n,t]);

    E_Waste_Landfill_ExclResWaste_tot[n,t]$(tx0[t] and sum((origin_waste,g_waste), d1qWasteD[origin_waste,g_waste,n,t]))..           
        qWasteD_ExclResWaste_tot[n,t] =E= sum((origin_waste, g_waste)$(d1qWasteD[origin_waste,g_waste,n,t]), qWasteD_ExclResWaste[origin_waste,g_waste,n,t]);

    E_Waste_WasteTreatment_ExclResWaste_tot[n,t]$(tx0[t] and sum((origin_waste,g_waste), d1qWasteE[origin_waste,g_waste,n,t]))..               
        qWasteE_ExclResWaste_tot[n,t] =E= sum((origin_waste, g_waste)$(d1qWasteE[origin_waste,g_waste,n,t]), qWasteE_ExclResWaste[origin_waste,g_waste,n,t]);

    E_Waste_WasteHierarchy_ExclResWaste_tot[n,t]$(tx0[t] and sum((origin_waste,g_waste), d1qWasteR[origin_waste,g_waste,n,t]))..                 
        qWasteR_ExclResWaste_tot[n,t] =E= sum((origin_waste, g_waste)$(d1qWasteR[origin_waste,g_waste,n,t]), qWasteR_ExclResWaste[origin_waste,g_waste,n,t]);

    E_Waste_OtherUtilized_ExclResWaste_tot[n,t]$(tx0[t] and sum((origin_waste,g_waste), d1qWasteE[origin_waste,g_waste,n,t]))..
        qWasteE_utilize_ExclResWaste_tot[n,t] =E= sum((origin_waste, g_waste)$(d1qWasteE[origin_waste,g_waste,n,t]), qWasteE_utilize_ExclResWaste[origin_waste,g_waste,n,t]);

    E_Waste_Burned_ExclResWaste_tot[n,t]$(tx0[t] and sum((origin_waste,g_waste), d1qWasteE[origin_waste,g_waste,n,t]))..
        qWasteE_burn_ExclResWaste_tot[n,t] =E= sum((origin_waste, g_waste)$(d1qWasteE[origin_waste,g_waste,n,t]), qWasteE_burn_ExclResWaste[origin_waste,g_waste,n,t]);

    E_qWasteQ_R_out_in_tot[n,nn,t]$(tx0[t] and sum((origin_waste,g_waste,gg_waste), d1WasteResidual[origin_waste,g_waste,n,gg_waste,nn,t]))..
        qWasteQ_R_out_in_tot[n,nn,t] =E= sum((origin_waste,g_waste,gg_waste)$(d1WasteResidual[origin_waste,g_waste,n,gg_waste,nn,t]), qWasteQ_R_out_in[origin_waste,g_waste,n,gg_waste,nn,t]);
    $ENDBLOCK


    #  ---------------------------------------------------------------------------------------------------------------------
    #  Variables for reporting
    #  ---------------------------------------------------------------------------------------------------------------------
    $BLOCK B_report_waste
    # Generated waste
    E_qWasteQ_GEN_tot[t]$(tx0[t] and sum((sec,g_waste,n), d1qWasteQ_GEN[sec,g_waste,n,t]))..                   
        qWasteQ_GEN_tot[t] =E= sum((sec,g_waste,n)$(d1qWasteQ_GEN[sec,g_waste,n,t]), qWasteQ_GEN[sec,g_waste,n,t]);

    E_qWasteQ_GEN_fraktion[n,t]$(tx0[t] and sum((sec,g_waste), d1qWasteQ_GEN[sec,g_waste,n,t]))..                   
        qWasteQ_GEN_fraktion[n,t] =E= sum((sec,g_waste)$(d1qWasteQ_GEN[sec,g_waste,n,t]), qWasteQ_GEN[sec,g_waste,n,t]);

    E_qWasteQ_GEN_type[g_waste,t]$(tx0[t] and sum((sec,n), d1qWasteQ_GEN[sec,g_waste,n,t]))..                   
        qWasteQ_GEN_type[g_waste,t] =E= sum((sec,n)$(d1qWasteQ_GEN[sec,g_waste,n,t]), qWasteQ_GEN[sec,g_waste,n,t]);

    E_qWasteQ_GEN_MWhus[t]$(tx0[t] and sum(n, d1qWasteQ_GEN['hus','Municipal Waste',n,t]))..                   
        qWasteQ_GEN_MWhus[t] =E= sum(n$(d1qWasteQ_GEN['hus','Municipal Waste',n,t]), qWasteQ_GEN['hus','Municipal Waste',n,t]);

    E_qWasteQ_GEN_MWerhv[t]$(tx0[t] and sum((sec,n)$(not sameas[sec,'hus']), d1qWasteQ_GEN[sec,'Municipal Waste',n,t]))..                   
        qWasteQ_GEN_MWerhv[t] =E= sum((sec,n)$(d1qWasteQ_GEN[sec,'Municipal Waste',n,t] and not sameas[sec,'hus']), qWasteQ_GEN[sec,'Municipal Waste',n,t]);

    E_qWasteQ_GEN_MW[n,t]$(tx0[t] and sum(sec, d1qWasteQ_GEN[sec,'Municipal Waste',n,t]))..                   
        qWasteQ_GEN_MW[n,t] =E= sum(sec$(d1qWasteQ_GEN[sec,'Municipal Waste',n,t]), qWasteQ_GEN[sec,'Municipal Waste',n,t]);

    E_qWastQ_GEN_tot_sec[origin_waste,g_waste,n,t]$(tx0[t] and sum(sec, d1qWasteQ_GEN[sec,g_waste,n,t]) and sameas[origin_waste,'DK'])..
        qWasteQ_GEN_tot_sec['DK',g_waste,n,t] =E= sum(sec$(d1qWasteQ_GEN[sec,g_waste,n,t]), qWasteQ_GEN[sec,g_waste,n,t]);

    # Sorted waste
    E_qWasteQ_SORT_tot[t]$(tx0[t] and sum((sec,g_waste,n)$(not sameas[n,'Dag']), d1qWasteQ[sec,g_waste,n,t]))..                   
        qWasteQ_SORT_tot[t] =E= sum((sec,g_waste,n)$((d1qWasteQ[sec,g_waste,n,t]) and not sameas[n,'Dag']), qWasteQ[sec,g_waste,n,t]);

    E_qWasteQ_SORT_fraktion[n,t]$(tx0[t] and sum((sec,g_waste), d1qWasteQ[sec,g_waste,n,t]))..                   
        qWasteQ_SORT_fraktion[n,t] =E= sum((sec,g_waste)$(d1qWasteQ[sec,g_waste,n,t]), qWasteQ[sec,g_waste,n,t]);

    E_qWasteQ_SORT_type[g_waste,n,t]$(tx0[t] and sum(sec, d1qWasteQ[sec,g_waste,n,t]))..                   
        qWasteQ_SORT_type[g_waste,n,t] =E= sum(sec$(d1qWasteQ[sec,g_waste,n,t]), qWasteQ[sec,g_waste,n,t]);

    E_qWastQ_SORT_tot_sec[origin_waste,g_waste,n,t]$(tx0[t] and sum(sec, d1qWasteQ[sec,g_waste,n,t]) and sameas[origin_waste,'DK'])..
        qWasteQ_SORT_tot_sec['DK',g_waste,n,t] =E= sum(sec$(d1qWasteQ[sec,g_waste,n,t]), qWasteQ[sec,g_waste,n,t]);

    E_qWasteRestaffald_tot[t]$(tx0[t] and sum((sec,g_waste,n), d1qWasteQ_GEN[sec,g_waste,n,t]))..                   
        qWasteRestaffald_tot[t] =E= sum((sec,g_waste,n)$(d1qWasteQ_GEN[sec,g_waste,n,t]), qWasteRestaffald[sec,g_waste,n,t]);

    E_qWasteRestaffald_fraktion[n,t]$(tx0[t] and sum((sec,g_waste), d1qWasteQ_GEN[sec,g_waste,n,t]))..                   
        qWasteRestaffald_fraktion[n,t] =E= sum((sec,g_waste)$(d1qWasteQ_GEN[sec,g_waste,n,t]), qWasteRestaffald[sec,g_waste,n,t]);

    # Waste treatment
    E_qWasteQ_bar_dom_tot[t]$(tx0[t] and sum((g_waste,origin_waste,n), d1qWasteQ_bar_dom[origin_waste,g_waste,n,t]))..                   
        qWasteQ_bar_dom_tot[t] =E= sum((g_waste,origin_waste,n)$(d1qWasteQ_bar_dom[origin_waste,g_waste,n,t]), qWasteQ_bar_dom[origin_waste,g_waste,n,t]);

    E_qWasteQ_bar_dom_fraktion[n,t]$(tx0[t] and sum((g_waste,origin_waste), d1qWasteQ_bar_dom[origin_waste,g_waste,n,t]))..                   
        qWasteQ_bar_dom_fraktion[n,t] =E= sum((g_waste,origin_waste)$(d1qWasteQ_bar_dom[origin_waste,g_waste,n,t]), qWasteQ_bar_dom[origin_waste,g_waste,n,t]);

    E_qWasteD_tot[t]$(tx0[t] and sum((g_waste,origin_waste,n), d1qWasteD[origin_waste,g_waste,n,t]))..                   
        qWasteD_tot[t] =E= sum((g_waste,origin_waste,n)$(d1qWasteD[origin_waste,g_waste,n,t]), qWasteD[origin_waste,g_waste,n,t]);

    E_qWasteD_fraktion[n,t]$(tx0[t] and sum((g_waste,origin_waste), d1qWasteD[origin_waste,g_waste,n,t]))..                   
        qWasteD_fraktion[n,t] =E= sum((g_waste,origin_waste)$(d1qWasteD[origin_waste,g_waste,n,t]), qWasteD[origin_waste,g_waste,n,t]);

    E_qWasteE_utilize_tot[t]$(tx0[t] and sum((g_waste,origin_waste,n), d1qWasteE_utilize[origin_waste,g_waste,n,t]))..                   
        qWasteE_utilize_tot[t] =E= sum((g_waste,origin_waste,n)$(d1qWasteE_utilize[origin_waste,g_waste,n,t]), qWasteE_utilize[origin_waste,g_waste,n,t]);

    E_qWasteE_utilize_fraktion[n,t]$(tx0[t] and sum((g_waste,origin_waste), d1qWasteE_utilize[origin_waste,g_waste,n,t]))..                   
        qWasteE_utilize_fraktion[n,t] =E= sum((g_waste,origin_waste)$(d1qWasteE_utilize[origin_waste,g_waste,n,t]), qWasteE_utilize[origin_waste,g_waste,n,t]);

    E_qWasteE_burn_tot[t]$(tx0[t] and sum((g_waste,origin_waste,n), d1qWasteE_burn[origin_waste,g_waste,n,t]))..                   
        qWasteE_burn_tot[t] =E= sum((g_waste,origin_waste,n)$(d1qWasteE_burn[origin_waste,g_waste,n,t]), qWasteE_burn[origin_waste,g_waste,n,t]);

    E_qWasteE_burn_fraktion[n,t]$(tx0[t] and sum((g_waste,origin_waste), d1qWasteE_burn[origin_waste,g_waste,n,t]))..                   
        qWasteE_burn_fraktion[n,t] =E= sum((g_waste,origin_waste)$(d1qWasteE_burn[origin_waste,g_waste,n,t]), qWasteE_burn[origin_waste,g_waste,n,t]);

    E_qWasteR_bar_tot[t]$(tx0[t] and sum((g_waste,origin_waste,n), d1qWasteR[origin_waste,g_waste,n,t]))..                   
        qWasteR_bar_tot[t] =E= sum((g_waste,origin_waste,n)$(d1qWasteR[origin_waste,g_waste,n,t]), qWasteR_bar[origin_waste,g_waste,n,t]);

    E_qWasteR_bar_fraktion[n,t]$(tx0[t] and sum((g_waste,origin_waste), d1qWasteR[origin_waste,g_waste,n,t]))..                   
        qWasteR_bar_fraktion[n,t] =E= sum((g_waste,origin_waste)$(d1qWasteR[origin_waste,g_waste,n,t]), qWasteR_bar[origin_waste,g_waste,n,t]);

    E_qWasteQ_R_out_tot[t]$(tx0[t] and sum((origin_waste,g_waste,n,gg_waste,nn), d1WasteResidual[origin_waste,g_waste,n,gg_waste,nn,t]))..                   
        qWasteQ_R_out_tot[t] =E= sum((g_waste,n,origin_waste)$(sum((gg_waste,nn), d1WasteResidual[origin_waste,g_waste,n,gg_waste,nn,t])), qWasteQ_R_out[origin_waste,g_waste,n,t]);

    E_qWasteQ_R_out_fraktion[n,t]$(tx0[t] and sum((origin_waste,g_waste,gg_waste,nn), d1WasteResidual[origin_waste,g_waste,n,gg_waste,nn,t]))..                   
        qWasteQ_R_out_fraktion[n,t] =E= sum((g_waste,origin_waste)$(sum((gg_waste,nn), d1WasteResidual[origin_waste,g_waste,n,gg_waste,nn,t])), qWasteQ_R_out[origin_waste,g_waste,n,t]);

    E_qWasteM_R_bar_tot[t]$(tx0[t] and sum((g_waste,origin_waste,n), d1qWasteR[origin_waste,g_waste,n,t]))..                   
        qWasteM_R_bar_tot[t] =E= sum((g_waste,origin_waste,n)$(d1qWasteR[origin_waste,g_waste,n,t]), qWasteM_R_bar[origin_waste,g_waste,n,t]);

    E_qWasteM_R_bar_fraktion[n,t]$(tx0[t] and sum((g_waste,origin_waste), d1qWasteR[origin_waste,g_waste,n,t]))..                   
        qWasteM_R_bar_fraktion[n,t] =E= sum((g_waste,origin_waste)$(d1qWasteR[origin_waste,g_waste,n,t]), qWasteM_R_bar[origin_waste,g_waste,n,t]);

    E_qWasteQ_ex_tot[t]$(tx0[t] and sum((origin_waste,g_waste,n), d1qWasteQ_ex[origin_waste,g_waste,n,t]))..
        qWasteQ_ex_tot[t] =E= sum((origin_waste,g_waste,n)$(d1qWasteQ_ex[origin_waste,g_waste,n,t]), qWasteQ_ex[origin_waste,g_waste,n,t]);

    E_qWasteQ_ex_fraktion[n,t]$(tx0[t] and sum((origin_waste,g_waste), d1qWasteQ_ex[origin_waste,g_waste,n,t]))..
        qWasteQ_ex_fraktion[n,t] =E= sum((origin_waste,g_waste)$(d1qWasteQ_ex[origin_waste,g_waste,n,t]), qWasteQ_ex[origin_waste,g_waste,n,t]);  

    E_qWasteQ_im_tot[t]$(tx0[t] and sum((g_waste,n), d1qWasteQ_bar_dom['Import',g_waste,n,t]))..
        qWasteQ_im_tot[t] =E= sum((g_waste,n)$(d1qWasteQ_bar_dom['Import',g_waste,n,t]), qWasteQ_im[g_waste,n,t]);

    E_qWasteQ_im_fraktion[n,t]$(tx0[t] and sum(g_waste, d1qWasteQ_bar_dom['Import',g_waste,n,t]))..
        qWasteQ_im_fraktion[n,t] =E= sum(g_waste$(d1qWasteQ_bar_dom['Import',g_waste,n,t]), qWasteQ_im[g_waste,n,t]);  

    E_qWasteQ_ex_Restaffald[t]$(tx0[t]and sum(g_waste, d1qWasteQ_ex['DK',g_waste,'Dag',t]))..
        qWasteQ_ex_Restaffald[t] =E= sum(g_waste$(d1qWasteQ_ex['DK',g_waste,'Dag',t]), qWasteQ_ex['DK',g_waste,'Dag',t]);

    E_qWasteQ_im_Restaffald[t]$(tx0[t] and sum(g_waste, d1qWasteQ_bar_dom['Import',g_waste,'Dag',t]))..
        qWasteQ_im_Restaffald[t] =E= sum(g_waste$(d1qWasteQ_bar_dom['Import',g_waste,'Dag',t]), qWasteQ_im[g_waste,'Dag',t]);

    E_KlimaplanCheck_qGEN_MWhus[n,t]$(tx0[t] and d1WasteKlimaplan_GEN['hus','Municipal Waste',n,t])..
        qWasteQ_GEN_KlimaplanCheck_MWhus[n,t] =E= qWasteQ_GEN_ARIMA['hus','Municipal Waste',n,t]-qWasteQ_GEN['hus','Municipal Waste',n,t];

    E_KlimaplanCheck_uGEN_MWhus[n,t]$(tx0[t] and d1WasteKlimaplan_GEN['hus','Municipal Waste',n,t])..
        uWaste_GEN_KlimaplanCheck_MWhus[n,t] =E= (qWasteQ_GEN_ARIMA['hus','Municipal Waste',n,t]-qWasteQ_GEN['hus','Municipal Waste',n,t])/qWasteQ_GEN_ARIMA['hus','Municipal Waste',n,t];

    E_KlimaplanCheck_qSORT_MWhus[n,t]$(tx0[t] and d1WasteKlimaplan_SORT['hus','Municipal Waste',n,t])..
        qWasteQ_KlimaplanCheck_MWhus[n,t] =E= qWasteQ['hus','Municipal Waste',n,t]-qWasteQ_ARIMA['hus','Municipal Waste',n,t];

    E_KlimaplanCheck_uSORT_MWhus[n,t]$(tx0[t] and d1WasteKlimaplan_SORT['hus','Municipal Waste',n,t])..
        uWaste_SORT_KlimaplanCheck_MWhus[n,t] =E= ((qWasteQ_GEN['hus','Municipal Waste',n,t]-qWasteQ_ARIMA['hus','Municipal Waste',n,t])-(qWasteQ_GEN['hus','Municipal Waste',n,t]-qWasteQ['hus','Municipal Waste',n,t]))/(qWasteQ_GEN['hus','Municipal Waste',n,t]-qWasteQ_ARIMA['hus','Municipal Waste',n,t]);

    E_KlimaplanCheck_qSORT_erhv[g_waste,n,t]$(tx0[t] and sum(sec$(not sameas[sec,'hus']), d1WasteKlimaplan_SORT[sec,g_waste,n,t]))..
        qWasteQ_KlimaplanCheck_erhv[g_waste,n,t] =E= sum(sec$(not sameas[sec,'hus'] and d1qWasteQ[sec,g_waste,n,t] and d1WasteKlimaplan_SORT[sec,g_waste,n,t]), 
                                                                qWasteQ[sec,g_waste,n,t]-qWasteQ_ARIMA[sec,g_waste,n,t]$(d1qWasteQ_ARIMA[sec,g_waste,n,t])); 

    E_KlimaplanCheck_uSORT_erhv[g_waste,n,t]$(tx0[t] and sum(sec$(not sameas[sec,'hus']), d1WasteKlimaplan_SORT[sec,g_waste,n,t]))..
        uWaste_SORT_KlimaplanCheck_erhv[g_waste,n,t] =E= sum(sec$(not sameas[sec,'hus'] and d1qWasteQ[sec,g_waste,n,t] and d1WasteKlimaplan_SORT[sec,g_waste,n,t]), 
                                                                (qWasteQ_GEN[sec,g_waste,n,t]-qWasteQ_ARIMA[sec,g_waste,n,t]$(d1qWasteQ_ARIMA[sec,g_waste,n,t]))-(qWasteQ_GEN[sec,g_waste,n,t]-qWasteQ[sec,g_waste,n,t]))
                                                            /sum(sec$(not sameas[sec,'hus'] and d1qWasteQ[sec,g_waste,n,t] and d1WasteKlimaplan_SORT[sec,g_waste,n,t]),
                                                                  (qWasteQ_GEN[sec,g_waste,n,t]-qWasteQ_ARIMA[sec,g_waste,n,t]$(d1qWasteQ_ARIMA[sec,g_waste,n,t]))); 
    
    


    E_genanvendelsesprocent_MW[n,t]$(tx0[t] and sum(sec,d1qWasteQ_GEN[sec,'Municipal Waste',n,t]) and (d1qWasteR['DK','Municipal Waste',n,t] or d1qWasteR_ex['DK','Municipal Waste',n,t]))..
        Genanvendelsesprocent_MW[n,t] =E= (qWasteR_bar['DK','Municipal Waste',n,t]$(d1qWasteR['DK','Municipal Waste',n,t])+qWasteR_bar_ex['DK','Municipal Waste',n,t]$(d1qWasteR_ex['DK','Municipal Waste',n,t]))
                                            /sum(sec$(d1qWasteQ_GEN[sec,'Municipal Waste',n,t]), qWasteQ_GEN[sec,'Municipal Waste',n,t]);
        
    E_genanvendelsesprocent_MW_tot[t]$(tx0[t] and sum((sec,n),d1qWasteQ_GEN[sec,'Municipal Waste',n,t]) and (sum(n, d1qWasteR['DK','Municipal Waste',n,t]) or sum(n,d1qWasteR_ex['DK','Municipal Waste',n,t])))..
        Genanvendelsesprocent_MW_tot[t] =E= sum(n, qWasteR_bar['DK','Municipal Waste',n,t]$(d1qWasteR['DK','Municipal Waste',n,t])+qWasteR_bar_ex['DK','Municipal Waste',n,t]$(d1qWasteR_ex['DK','Municipal Waste',n,t]))
                                            /sum((sec,n)$(d1qWasteQ_GEN[sec,'Municipal Waste',n,t]), qWasteQ_GEN[sec,'Municipal Waste',n,t]);
    
    E_qWasteQ_bar_dom_check[t]$(tx0[t] and sum((g_waste,origin_waste,n), d1qWasteQ_bar_dom[origin_waste,g_waste,n,t]))..
        qWasteQ_bar_dom_check[t] =E= qWasteD_tot[t] + qWasteE_burn_tot[t] + qWasteE_utilize_tot[t] + qWasteR_bar_tot[t] + qWasteQ_R_out_tot[t] + qWasteM_R_bar_tot[t];

    E_qWasteQ_bar_dom_POT_dag[origin_waste,g_waste,n,t]$(tx0[t] and (d1qWasteQ_bar_dom[origin_waste,g_waste,n,t] or d1qWasteQ_ex[origin_waste,g_waste,n,t]) and sameas[origin_waste,'DK'])..
        qWasteQ_bar_dom_POT['DK',g_waste,n,t] =E= qWasteQ_bar_dom['DK',g_waste,n,t]$(d1qWasteQ_bar_dom['DK',g_waste,n,t])+qWasteQ_ex['DK',g_waste,n,t]$(d1qWasteQ_ex['DK',g_waste,n,t]);

    E_qWasteD_POT_dag[origin_waste,g_waste,n,t]$(tx0[t] and (d1qWasteD[origin_waste,g_waste,n,t] or d1qWasteD_ex[origin_waste,g_waste,n,t]) and sameas[n,'Dag'] and sameas[origin_waste,'DK'])..
        qWasteD_POT['DK',g_waste,n,t] =E= qWasteD['DK',g_waste,n,t]$(d1qWasteD['DK',g_waste,n,t])+uWasteD['DK',g_waste,n,t]*qWasteQ_ex['DK',g_waste,n,t];

    E_qWasteD_POT[origin_waste,g_waste,n,t]$(tx0[t] and (d1qWasteD[origin_waste,g_waste,n,t] or d1qWasteD_ex[origin_waste,g_waste,n,t]) and not sameas[n,'Dag'] and sameas[origin_waste,'DK'])..
        qWasteD_POT['DK',g_waste,n,t] =E= qWasteD['DK',g_waste,n,t]$(d1qWasteD['DK',g_waste,n,t])+qWasteD_ex['DK',g_waste,n,t]$(d1qWasteD_ex['DK',g_waste,n,t]);

    E_qWasteE_burn_POT_dag[origin_waste,g_waste,n,t]$(tx0[t] and (d1qWasteE_burn[origin_waste,g_waste,n,t] or d1qWasteE_ex[origin_waste,g_waste,n,t]) and sameas[n,'Dag'] and sameas[origin_waste,'DK'])..
        qWasteE_burn_POT['DK',g_waste,n,t] =E= qWasteQ_bar_dom_POT['DK',g_waste,n,t]-qWasteD_POT['DK',g_waste,n,t];

    E_qWasteE_burn_POT[origin_waste,g_waste,n,t]$(tx0[t] and (d1qWasteE_burn[origin_waste,g_waste,n,t] or d1qWasteE_ex[origin_waste,g_waste,n,t]) and not sameas[n,'Dag'] and sameas[origin_waste,'DK'])..
        qWasteE_burn_POT['DK',g_waste,n,t] =E= qWasteE_burn['DK',g_waste,n,t]$(d1qWasteE_burn['DK',g_waste,n,t])+qWasteE_burn_ex['DK',g_waste,n,t]$(d1qWasteE_ex['DK',g_waste,n,t]);

    $ENDBLOCK

    $BLOCK B_report_COWI
    E_MW_Primary[nCOWI,t]$(tx0[t] and sum(sec, d1qWasteQ[sec,'Municipal Waste',nCOWI,t]))..
        MW_Primary[nCOWI,t] =E= sum(sec$(d1qWasteQ[sec,'Municipal Waste',nCOWI,t]), qWasteQ[sec,'Municipal Waste',nCOWI,t]);

    E_MW_Primary_tot[t]$(tx0[t])..
        MW_Primary_tot[t] =E= sum((sec,n)$(d1qWasteQ[sec,'Municipal Waste',n,t]), qWasteQ[sec,'Municipal Waste',n,t]);

    E_MW_PrimaryRecycling[nCOWI,t]$(tx0[t] and d1qWasteR_ex['DK','Municipal Waste',nCOWI,t])..        
        MW_PrimaryRecycling[nCOWI,t] =E= qWasteR_ExclResWaste['DK','Municipal Waste',nCOWI,t]$(d1qWasteR['DK','Municipal Waste',nCOWI,t]) + qWasteR_ex['DK','Municipal Waste',nCOWI,t];

    E_MW_PrimaryRecycling_tot[t]$(tx0[t])..
        MW_PrimaryRecycling_tot[t] =E= sum(n$(d1qWasteR_ex['DK','Municipal Waste',n,t]), qWasteR_ExclResWaste['DK','Municipal Waste',n,t]$(d1qWasteR['DK','Municipal Waste',n,t]) + qWasteR_ex['DK','Municipal Waste',n,t]);

    E_MW_FinalRecycling[nCOWI,t]$(tx0[t] and d1qWasteR_ex['DK','Municipal Waste',nCOWI,t])..
        MW_FinalRecycling[nCOWI,t] =E= qWasteR_bar['DK','Municipal Waste',nCOWI,t]$(d1qWasteR['DK','Municipal Waste',nCOWI,t]) + qWasteR_bar_ex['DK','Municipal Waste',nCOWI,t];

    E_MW_FinalRecycling_tot[t]$(tx0[t])..
        MW_FinalRecycling_tot[t] =E= sum(n$(d1qWasteR_ex['DK','Municipal Waste',n,t]), qWasteR_bar['DK','Municipal Waste',n,t]$(d1qWasteR['DK','Municipal Waste',n,t]) + qWasteR_bar_ex['DK','Municipal Waste',n,t]);

    E_MW_PrimaryUtilization[nCOWI,t]$(tx0[t] and d1qWasteE_utilize['DK','Municipal Waste',nCOWI,t])..
        MW_PrimaryUtilization[nCOWI,t] =E= qWasteE_utilize_ExclResWaste['DK','Municipal Waste',nCOWI,t] + qWasteE_utilize_ex['DK','Municipal Waste',nCOWI,t];

    E_MW_PrimaryUtilization_tot[t]$(tx0[t] and sum(n,d1qWasteE_utilize['DK','Municipal Waste',n,t]))..
        MW_PrimaryUtilization_tot[t] =E= sum(n$(d1qWasteE_utilize['DK','Municipal Waste',n,t]), qWasteE_utilize_ExclResWaste['DK','Municipal Waste',n,t] + qWasteE_utilize_ex['DK','Municipal Waste',n,t]);

    E_MW_FinalUtilization[nCOWI,t]$(tx0[t] and d1qWasteE_utilize['DK','Municipal Waste',nCOWI,t])..
        MW_FinalUtilization[nCOWI,t] =E= qWasteE_utilize['DK','Municipal Waste',nCOWI,t] + qWasteE_utilize_ex['DK','Municipal Waste',nCOWI,t];

    E_MW_FinalUtilization_tot[t]$(tx0[t] and sum(n,d1qWasteE_utilize['DK','Municipal Waste',n,t]))..
        MW_FinalUtilization_tot[t] =E= sum(n$(d1qWasteE_utilize['DK','Municipal Waste',n,t]), qWasteE_utilize['DK','Municipal Waste',n,t] + qWasteE_utilize_ex['DK','Municipal Waste',n,t]);

    E_MW_PrimaryBurn[nCOWI,t]$(tx0[t] and d1qWasteE_burn['DK','Municipal Waste',nCOWI,t])..
        MW_PrimaryBurn[nCOWI,t] =E= qWasteE_burn_ExclResWaste['DK','Municipal Waste',nCOWI,t] + (qWasteE_burn_ex['DK','Municipal Waste',nCOWI,t])$(d1qWasteE_ex['DK','Municipal Waste',nCOWI,t]);

    E_MW_PrimaryBurn_tot[t]$(tx0[t])..
        MW_PrimaryBurn_tot[t] =E= sum(n$(d1qWasteE_burn['DK','Municipal Waste',n,t]), qWasteE_burn_ExclResWaste['DK','Municipal Waste',n,t] + (qWasteE_burn_ex['DK','Municipal Waste',n,t])$(d1qWasteE_ex['DK','Municipal Waste',n,t])); 

    E_MW_FinalBurn[nCOWI,t]$(tx0[t] and d1qWasteE_burn['DK','Municipal Waste',nCOWI,t])..
        MW_FinalBurn[nCOWI,t] =E= qWasteE_burn['DK','Municipal Waste',nCOWI,t] + (qWasteE_burn_ex['DK','Municipal Waste',nCOWI,t])$(d1qWasteE_ex['DK','Municipal Waste',nCOWI,t]);

    E_MW_FinalBurn_tot[t]$(tx0[t])..
        MW_FinalBurn_tot[t] =E= sum(n$(d1qWasteE_burn['DK','Municipal Waste',n,t]), qWasteE_burn['DK','Municipal Waste',n,t] + (qWasteE_burn_ex['DK','Municipal Waste',n,t])$(d1qWasteE_ex['DK','Municipal Waste',n,t])); 
        
    E_MW_PrimaryLandfill[nCOWI,t]$(tx0[t] and (d1qWasteD['DK','Municipal Waste',nCOWI,t] or d1qWasteD_ex['DK','Municipal Waste',nCOWI,t]))..
        MW_PrimaryLandfill[nCOWI,t] =E= qWasteD_ExclResWaste['DK','Municipal Waste',nCOWI,t]$(d1qWasteD['DK','Municipal Waste',nCOWI,t]) + (qWasteD_ex['DK','Municipal Waste',nCOWI,t])$(d1qWasteD_ex['DK','Municipal Waste',nCOWI,t]);

    E_MW_PrimaryLandfill_tot[t]$(tx0[t])..
        MW_PrimaryLandfill_tot[t] =E= sum(n$(d1qWasteD['DK','Municipal Waste',n,t] or d1qWasteD_ex['DK','Municipal Waste',n,t]), qWasteD_ExclResWaste['DK','Municipal Waste',n,t]$(d1qWasteD['DK','Municipal Waste',n,t]) + (qWasteD_ex['DK','Municipal Waste',n,t])$(d1qWasteD_ex['DK','Municipal Waste',n,t]));

    E_MW_FinalLandfill[nCOWI,t]$(tx0[t] and (d1qWasteD['DK','Municipal Waste',nCOWI,t] or d1qWasteD_ex['DK','Municipal Waste',nCOWI,t]))..
        MW_FinalLandfill[nCOWI,t] =E= qWasteD['DK','Municipal Waste',nCOWI,t]$(d1qWasteD['DK','Municipal Waste',nCOWI,t]) + (qWasteD_ex['DK','Municipal Waste',nCOWI,t])$(d1qWasteD_ex['DK','Municipal Waste',nCOWI,t]);

    E_MW_FinalLandfill_tot[t]$(tx0[t])..
        MW_FinalLandfill_tot[t] =E= sum(n$(d1qWasteD['DK','Municipal Waste',n,t] or d1qWasteD_ex['DK','Municipal Waste',n,t]), qWasteD['DK','Municipal Waste',n,t]$(d1qWasteD['DK','Municipal Waste',n,t]) + (qWasteD_ex['DK','Municipal Waste',n,t])$(d1qWasteD_ex['DK','Municipal Waste',n,t]));

    $ENDBLOCK

$MODEL M_waste
    B_waste_GEN_ARIMA
    B_waste_SORT_ARIMA
    B_waste_treatment
    B_waste_export
    B_links_waste
    B_waste_treatment_ExclResWaste
    B_report_waste
    B_report_COWI
    ;
$ENDIF


# ======================================================================================================================
# Exogenous variables and data assignment
# ======================================================================================================================
$IF %stage% == "exogenous_values":
#1) DATA ADJUSTMENTS 
    # ===========================================================================================================      
    # ASSUMPTION: 'Jord' can not be recycled (Recycle -> Utilize) (only relevant for exported and imported waste)      
    # ===========================================================================================================    
    dataUtilize_ex[sec,n,t]$(sameas[n,'Jord'])           = dataUtilize_ex[sec,n,t]+dataRecy_ex[sec,n,t];
    dataRecy_ex[sec,n,t]$(sameas[n,'Jord'])              = 0;
    dataUtilize_im[n,t]$(sameas[n,'Jord'])               = dataUtilize_im[n,t]+dataRecy_im[n,t];
    dataRecy_im[n,t]$(sameas[n,'Jord'])                  = 0;

    # ===========================================================================================================      
    # ASSUMPTION: 'Rest' can not be burned (Burn -> Landfill)
    # ===========================================================================================================   
    dataLand[sec,n,t]$(sameas[n,'Rest'])                 = dataLand[sec,n,t]+dataBurn[sec,n,t];
    dataBurn[sec,n,t]$(sameas[n,'Rest'])                 = 0;
    dataLand_ex[sec,n,t]$(sameas[n,'Rest'])              = dataLand_ex[sec,n,t]+dataBurn_ex[sec,n,t];
    dataBurn_ex[sec,n,t]$(sameas[n,'Rest'])              = 0;
    dataLand_im[n,t]$(sameas[n,'Rest'])                  = dataLand_im[n,t]+dataBurn_im[n,t];
    dataBurn_im[n,t]$(sameas[n,'Rest'])                  = 0;

    # ===========================================================================================================      
    # ASSUMPTION: Only 'Byg', 'Rest' and 'Jord' can be utilized in other ways (Utilize -> Recycle)      
    # ===========================================================================================================   
    dataRecy[sec,n,t]$(not (sameas[n,'Byg'] or sameas[n,'Rest'] or sameas[n,'Jord']))       
                                                         = dataRecy[sec,n,t]+dataUtilize[sec,n,t];
    dataUtilize[sec,n,t]$(not (sameas[n,'Byg'] or sameas[n,'Rest'] or sameas[n,'Jord']))    
                                                         = 0;
    dataRecy_ex[sec,n,t]$(not (sameas[n,'Byg'] or sameas[n,'Rest'] or sameas[n,'Jord']))    
                                                         = dataRecy_ex[sec,n,t]+dataUtilize_ex[sec,n,t];
    dataUtilize_ex[sec,n,t]$(not (sameas[n,'Byg'] or sameas[n,'Rest'] or sameas[n,'Jord'])) 
                                                         = 0;
    dataRecy_im[n,t]$(not (sameas[n,'Byg'] or sameas[n,'Rest'] or sameas[n,'Jord']))        
                                                         = dataRecy_im[n,t]+dataUtilize_im[n,t];
    dataUtilize_im[n,t]$(not (sameas[n,'Byg'] or sameas[n,'Rest'] or sameas[n,'Jord']))     
                                                         = 0;
    
    # ===========================================================================================================
    # ASSUMPTION: 'Dag' can not be recycled (Recycle -> Burn)
    # ===========================================================================================================
    dataBurn[sec,n,t]$(sameas[n,'Dag'])                  = dataBurn[sec,n,t]+dataRecy[sec,n,t];
    dataRecy[sec,n,t]$(sameas[n,'Dag'])                  = 0;
    dataBurn_ex[sec,n,t]$(sameas[n,'Dag'])               = dataBurn_ex[sec,n,t]+dataRecy_ex[sec,n,t];
    dataRecy_ex[sec,n,t]$(sameas[n,'Dag'])               = 0;
    dataBurn_im[n,t]$(sameas[n,'Dag'])                   = dataBurn_im[n,t]+dataRecy_im[n,t];
    dataRecy_im[n,t]$(sameas[n,'Dag'])                   = 0;
      
    # ===========================================================================================================      
    # ASSUMPTION: 'Dep' can not be recycled or burned (Recycle + Burn -> Landfill)     
    # ===========================================================================================================      
    dataLand[sec,n,t]$(sameas[n,'Dep'])                  = dataLand[sec,n,t]+dataBurn[sec,n,t]+dataRecy[sec,n,t];
    dataRecy[sec,n,t]$(sameas[n,'Dep'])                  = 0;
    dataBurn[sec,n,t]$(sameas[n,'Dep'])                  = 0;
    dataLand_ex[sec,n,t]$(sameas[n,'Dep'])               = dataLand_ex[sec,n,t]+dataBurn_ex[sec,n,t]+dataRecy_ex[sec,n,t];
    dataRecy_ex[sec,n,t]$(sameas[n,'Dep'])               = 0;
    dataBurn_ex[sec,n,t]$(sameas[n,'Dep'])               = 0;
    dataLand_im[n,t]$(sameas[n,'Dep'])                   = dataLand_im[n,t]+dataBurn_im[n,t]+dataRecy_im[n,t];
    dataRecy_im[n,t]$(sameas[n,'Dep'])                   = 0;
    dataBurn_im[n,t]$(sameas[n,'Dep'])                   = 0;                                                         

#2) READ DATA                                           
    # ==================================================
    # Share of municipal waste
    # ==================================================
        uWaste_MWshare.l[sec,'Manufacturing Waste',n,t]$(tWaste_dst[t])  
                                                         = 1-MW_share[sec,n];
        uWaste_MWshare.l[sec,'Municipal Waste',n,t]$(tWaste_dst[t]) 
                                                         = MW_share[sec,n];

    # ==================================================
    # Danish generated waste data
    # ==================================================
        # Total waste 
        qWasteQ_GEN.l[sec,g_waste,n,t]                  = uWaste_MWshare.l[sec,g_waste,n,t]*dataGen_Waste[sec,n,t];

    # ==================================================
    # Danish sorted waste data
    # ==================================================
        # Total waste 
        qWasteQ.l[sec,g_waste,n,t]                      = uWaste_MWshare.l[sec,g_waste,n,t]
                                                            *(dataLand[sec,n,t]+dataBurn[sec,n,t]+dataRecy[sec,n,t]+dataUtilize[sec,n,t]);
        # Split meat production sector into 2 additional 
        qWasteQ.l['10012',g_waste,n,t]                  = sYS['10012']*qWasteQ.l['10011',g_waste,n,t];
        qWasteQ.l['10013',g_waste,n,t]                  = sYS['10013']*qWasteQ.l['10011',g_waste,n,t];
        qWasteQ.l['10011',g_waste,n,t]                  = sYS['10011']*qWasteQ.l['10011',g_waste,n,t];
        qWasteQ.l['23001',g_waste,n,t]                  = sYS_cement['23001']*qWasteQ.l['23001',g_waste,n,t];
        qWasteQ.l['23002',g_waste,n,t]                  = sYS_cement['23002']*qWasteQ.l['23001',g_waste,n,t];


        # Danish produced waste treatment data (landfill, recycle, burn, utilize)
        qWasteD_DK.l[g_waste,n,t]                       = sum(sec, uWaste_MWshare.l[sec,g_waste,n,t]*dataLand[sec,n,t]);
        qWasteR_DK.l[g_waste,n,t]                       = sum(sec, uWaste_MWshare.l[sec,g_waste,n,t]*dataRecy[sec,n,t]); 
        qWasteE_burn_DK.l[g_waste,n,t]                  = sum(sec, uWaste_MWshare.l[sec,g_waste,n,t]*dataBurn[sec,n,t]);
        qWasteE_utilize_DK.l[g_waste,n,t]               = sum(sec, uWaste_MWshare.l[sec,g_waste,n,t]*dataUtilize[sec,n,t]);

    
    # ==================================================
    # Imported waste data
    # ==================================================
        # Waste group shares for danish produced waste used to assign waste groups to imported waste
        uWaste_MWshare_im.l[g_waste,n,t]$(sum(sec,qWasteQ.l[sec,g_waste,n,t]))
                                                        = (sum(sec,qWasteQ.l[sec,g_waste,n,t]))
                                                                /sum(gg_waste,(sum(sec,qWasteQ.l[sec,gg_waste,n,t])));
        # Imported waste treatment data (landfill, recycle, burn, utilize)
        qWasteD_im.l[g_waste,n,t]                       = uWaste_MWshare_im.l[g_waste,n,t]*dataLand_im[n,t];
        qWasteR_im.l[g_waste,n,t]                       = uWaste_MWshare_im.l[g_waste,n,t]*dataRecy_im[n,t];
        qWasteE_burn_im.l[g_waste,n,t]                  = uWaste_MWshare_im.l[g_waste,n,t]*dataBurn_im[n,t];
        qWasteE_utilize_im.l[g_waste,n,t]               = uWaste_MWshare_im.l[g_waste,n,t]*dataUtilize_im[n,t];


    # ==================================================
    # Exported waste data
    # ==================================================
        # Exported waste treatment data (landfill, recycle, burn, utilize)
        qWasteD_ex_data.l[g_waste,n,t]                  = sum(sec, uWaste_MWshare.l[sec,g_waste,n,t]*dataLand_ex[sec,n,t]);
        qWasteR_ex_data.l[g_waste,n,t]                  = sum(sec, uWaste_MWshare.l[sec,g_waste,n,t]*dataRecy_ex[sec,n,t]); 
        qWasteE_utilize_ex_data.l[g_waste,n,t]          = sum(sec, uWaste_MWshare.l[sec,g_waste,n,t]*dataUtilize_ex[sec,n,t]);
        qWasteE_burn_ex_data.l[g_waste,n,t]             = sum(sec, uWaste_MWshare.l[sec,g_waste,n,t]*dataBurn_ex[sec,n,t]); 

        # ===========================================================================================================      
        # ASSUMPTION: We remove som exported waste, if the exported waste is bigger than the 
        #             total danish produced and imported waste
        # ===========================================================================================================
        # Dummy to check if exported waste is bigger than total danish produced and imported waste
        d1qWaste_adjustExport_D[g_waste,n,t]            = yes$(qWasteD_ex_data.l[g_waste,n,t]>(qWasteD_DK.l[g_waste,n,t]+qWasteD_im.l[g_waste,n,t]));
        d1qWaste_adjustExport_R[g_waste,n,t]            = yes$(qWasteR_ex_data.l[g_waste,n,t]>(qWasteR_DK.l[g_waste,n,t]+qWasteR_im.l[g_waste,n,t]));
        d1qWaste_adjustExport_E_burn[g_waste,n,t]       = yes$(qWasteE_burn_ex_data.l[g_waste,n,t]>(qWasteE_burn_DK.l[g_waste,n,t]+qWasteE_burn_im.l[g_waste,n,t]));
        d1qWaste_adjustExport_E_utilize[g_waste,n,t]    = yes$(qWasteE_utilize_ex_data.l[g_waste,n,t]>(qWasteE_utilize_DK.l[g_waste,n,t]+qWasteE_utilize_im.l[g_waste,n,t]));

        # Adjustment of export data
        qWasteD_ex_data.l[g_waste,n,t]$(d1qWaste_adjustExport_D[g_waste,n,t])   
                                                        = qWasteD_DK.l[g_waste,n,t]+qWasteD_im.l[g_waste,n,t];
        qWasteR_ex_data.l[g_waste,n,t]$(d1qWaste_adjustExport_R[g_waste,n,t])   
                                                        = qWasteR_DK.l[g_waste,n,t]+qWasteR_im.l[g_waste,n,t];
        qWasteE_burn_ex_data.l[g_waste,n,t]$(d1qWaste_adjustExport_E_burn[g_waste,n,t])   
                                                        = qWasteE_burn_DK.l[g_waste,n,t]+qWasteE_burn_im.l[g_waste,n,t];   
        qWasteE_utilize_ex_data.l[g_waste,n,t]$(d1qWaste_adjustExport_E_utilize[g_waste,n,t])   
                                                        = qWasteE_utilize_DK.l[g_waste,n,t]+qWasteE_utilize_im.l[g_waste,n,t]; 

        # ==================================================
        # Reexport
        # ==================================================
        # Dummy to check if there is reexport of waste for each treatment type
        d1qWaste_reexport_R[g_waste,n,t]                = yes$((qWasteR_DK.l[g_waste,n,t]-qWasteR_ex_data.l[g_waste,n,t])<0);
        d1qWaste_reexport_D[g_waste,n,t]                = yes$((qWasteD_DK.l[g_waste,n,t]-qWasteD_ex_data.l[g_waste,n,t])<0);
        d1qWaste_reexport_burn[g_waste,n,t]             = yes$((qWasteE_burn_DK.l[g_waste,n,t]-qWasteE_burn_ex_data.l[g_waste,n,t])<0);
        d1qWaste_reexport_utilize[g_waste,n,t]          = yes$((qWasteE_utilize_DK.l[g_waste,n,t]-qWasteE_utilize_ex_data.l[g_waste,n,t])<0);


    # ==================================================
    # Waste treatment data (4 streams of waste: DK->DK, IM->DK, DK->EXP, IM->EXP)
    # ==================================================
    # Landfill waste 
        # If there is no reexport
        qWasteD.l['DK',g_waste,n,t]$(not d1qWaste_reexport_D[g_waste,n,t])
                                                   = qWasteD_DK.l[g_waste,n,t]-qWasteD_ex_data.l[g_waste,n,t]; # (DK->DK)
        qWasteD.l['Import',g_waste,n,t]$(not d1qWaste_reexport_D[g_waste,n,t])            
                                                   = qWasteD_im.l[g_waste,n,t];                                # (IM->DK)
        qWasteD_ex.l['DK',g_waste,n,t]$(not d1qWaste_reexport_D[g_waste,n,t])             
                                                   = qWasteD_ex_data.l[g_waste,n,t];                           # (DK->EXP)
        qWasteD_ex.l['Import',g_waste,n,t]$(not d1qWaste_reexport_D[g_waste,n,t])             
                                                   = 0;                                                        # (IM->EXP)
        # If there is reexport                                                    
        qWasteD.l['DK',g_waste,n,t]$(d1qWaste_reexport_D[g_waste,n,t])
                                                   = 0;                                                        # (DK->DK)
        qWasteD.l['Import',g_waste,n,t]$(d1qWaste_reexport_D[g_waste,n,t])
                                                   = qWasteD_im.l[g_waste,n,t]-(qWasteD_ex_data.l[g_waste,n,t] 
                                                                                -qWasteD_DK.l[g_waste,n,t]);   # (IM->DK)
        qWasteD_ex.l['DK',g_waste,n,t]$(d1qWaste_reexport_D[g_waste,n,t])
                                                   = qWasteD_DK.l[g_waste,n,t];                                # (DK->EXP)
        qWasteD_ex.l['Import',g_waste,n,t]$(d1qWaste_reexport_D[g_waste,n,t])
                                                   = qWasteD_ex_data.l[g_waste,n,t]-qWasteD_DK.l[g_waste,n,t]; # (IM->EXP)


    # Recycled waste 
        # If there is no reexport
        qWasteR.l['DK',g_waste,n,t]$(not d1qWaste_reexport_R[g_waste,n,t])
                                                   = qWasteR_DK.l[g_waste,n,t]-qWasteR_ex_data.l[g_waste,n,t]; # (DK->DK) 
        qWasteR.l['Import',g_waste,n,t]$(not d1qWaste_reexport_R[g_waste,n,t])            
                                                   = qWasteR_im.l[g_waste,n,t];                                # (IM->DK)
        qWasteR_ex.l['DK',g_waste,n,t]$(not d1qWaste_reexport_R[g_waste,n,t])             
                                                   = qWasteR_ex_data.l[g_waste,n,t];                           # (DK->EXP)
        qWasteR_ex.l['Import',g_waste,n,t]$(not d1qWaste_reexport_R[g_waste,n,t])             
                                                   = 0;                                                        # (IM->EXP)
        # If there is reexport  
        qWasteR.l['DK',g_waste,n,t]$(d1qWaste_reexport_R[g_waste,n,t])
                                                   = 0;                                                        # (DK->DK) 
        qWasteR.l['Import',g_waste,n,t]$(d1qWaste_reexport_R[g_waste,n,t])
                                                   = qWasteR_im.l[g_waste,n,t]-(qWasteR_ex_data.l[g_waste,n,t] 
                                                                                -qWasteR_DK.l[g_waste,n,t]);   # (IM->DK)
        qWasteR_ex.l['DK',g_waste,n,t]$(d1qWaste_reexport_R[g_waste,n,t])
                                                   = qWasteR_DK.l[g_waste,n,t];                                # (DK->EXP)
        qWasteR_ex.l['Import',g_waste,n,t]$(d1qWaste_reexport_R[g_waste,n,t])
                                                   = qWasteR_ex_data.l[g_waste,n,t]-qWasteR_DK.l[g_waste,n,t]; # (IM->EXP)


        qWasteR.l[origin_waste,g_waste,n,t]$(abs(qWasteR.l[origin_waste,g_waste,n,t])<1.0e-10) = 0;

    # Burned waste 
        # If there is no reexport
        qWasteE_burn.l['DK',g_waste,n,t]$(not d1qWaste_reexport_burn[g_waste,n,t])
                                                   = qWasteE_burn_DK.l[g_waste,n,t]
                                                        -qWasteE_burn_ex_data.l[g_waste,n,t];                  # (DK->DK)
        qWasteE_burn.l['Import',g_waste,n,t]$(not d1qWaste_reexport_burn[g_waste,n,t])            
                                                   = qWasteE_burn_im.l[g_waste,n,t];                           # (IM->DK)
        qWasteE_burn_ex.l['DK',g_waste,n,t]$(not d1qWaste_reexport_burn[g_waste,n,t])             
                                                   = qWasteE_burn_ex_data.l[g_waste,n,t];                      # (DK->EXP)
        qWasteE_burn_ex.l['Import',g_waste,n,t]$(not d1qWaste_reexport_burn[g_waste,n,t])             
                                                   = 0;                                                        # (IM->EXP)
        # If there is reexport
        qWasteE_burn.l['DK',g_waste,n,t]$(d1qWaste_reexport_burn[g_waste,n,t])
                                                   = 0;                                                        # (DK->DK)
        qWasteE_burn.l['Import',g_waste,n,t]$(d1qWaste_reexport_burn[g_waste,n,t])
                                                   = qWasteE_burn_im.l[g_waste,n,t]
                                                        -(qWasteE_burn_ex_data.l[g_waste,n,t]
                                                            -qWasteE_burn_DK.l[g_waste,n,t]);                  # (IM->DK) 
        qWasteE_burn_ex.l['DK',g_waste,n,t]$(d1qWaste_reexport_burn[g_waste,n,t])
                                                   = qWasteE_burn_DK.l[g_waste,n,t];                           # (DK->EXP)
        qWasteE_burn_ex.l['Import',g_waste,n,t]$(d1qWaste_reexport_burn[g_waste,n,t])
                                                   = qWasteE_burn_ex_data.l[g_waste,n,t]
                                                            -qWasteE_burn_DK.l[g_waste,n,t];                   # (IM->EXP)

    # Utilized waste 
        # If there is no reexport
        qWasteE_utilize.l['DK',g_waste,n,t]$(not d1qWaste_reexport_utilize[g_waste,n,t])
                                                   = qWasteE_utilize_DK.l[g_waste,n,t]
                                                        -qWasteE_utilize_ex_data.l[g_waste,n,t];               # (DK->DK)
        qWasteE_utilize.l['Import',g_waste,n,t]$(not d1qWaste_reexport_utilize[g_waste,n,t])            
                                                   = qWasteE_utilize_im.l[g_waste,n,t];                        # (IM->DK)
        qWasteE_utilize_ex.l['DK',g_waste,n,t]$(not d1qWaste_reexport_utilize[g_waste,n,t])             
                                                   = qWasteE_utilize_ex_data.l[g_waste,n,t];                   # (DK->EXP)
        qWasteE_utilize_ex.l['Import',g_waste,n,t]$(not d1qWaste_reexport_utilize[g_waste,n,t])             
                                                   = 0;                                                        # (IM->EXP)
        # If there is reexport
        qWasteE_utilize.l['DK',g_waste,n,t]$(d1qWaste_reexport_utilize[g_waste,n,t])
                                                   = 0;                                                        # (DK->DK)
        qWasteE_utilize.l['Import',g_waste,n,t]$(d1qWaste_reexport_utilize[g_waste,n,t])
                                                   = qWasteE_utilize_im.l[g_waste,n,t]
                                                        -(qWasteE_utilize_ex_data.l[g_waste,n,t]
                                                            -qWasteE_utilize_DK.l[g_waste,n,t]);               # (IM->DK)
        qWasteE_utilize_ex.l['DK',g_waste,n,t]$(d1qWaste_reexport_utilize[g_waste,n,t])
                                                   = qWasteE_utilize_DK.l[g_waste,n,t];                        # (DK->EXP)
        qWasteE_utilize_ex.l['Import',g_waste,n,t]$(d1qWaste_reexport_utilize[g_waste,n,t])
                                                   = qWasteE_utilize_ex_data.l[g_waste,n,t]
                                                            -qWasteE_utilize_DK.l[g_waste,n,t];                # (IM->EXP)
    

#3) EXOGENOUS VALUES
    # ==================================================
    # ARIMA estimates (Generation coefficients)
    # ==================================================
    uWaste_arima_GEN.l[sec,n,t]                               = arima_GEN[sec,n,t];
    uWaste_arima_GEN.l[sec,n,t]$(not uWaste_arima_GEN.l[sec,n,t])        
                                                              = 0;                                                   

    # ==================================================
    # ARIMA estimates (Sorting coefficients)
    # ==================================================
    uWaste_arima_SORT.l[sec,n,t]                              = arima_SORT[sec,n,t];
    uWaste_arima_SORT.l[sec,n,t]$(not uWaste_arima_SORT.l[sec,n,t])
                                                              = 0;
    
    # ==================================================
    # Exogenous adjustment of household generation coefficients 
    # ==================================================    
    # The households generations coefficients are adjusted with 1.2427 pct per year from the 2020-value                                                          
    uWaste_arima_hus_adjust.l[tForecast]$(not sameas[tForecast,'2019'])
                                                              = (1-0.012427)**(tForecast.val - 2020);  
    uWaste_arima_hus_adjust.l[t]$(sameas[t,'2018'] or sameas[t,'2019'])
                                                              = 1;  
    # The households generations coefficients are set constant to the 2020-value in the forecast
    # such that it is the 2020-value that is adjusted with the above trend                                                              
    uWaste_arima_GEN.l['hus',n,tForecast]$(not sameas[tForecast,'2019'])
                                                              = uWaste_arima_GEN.l['hus',n,'2020'];                                                               

    # ==================================================
    # CET parameters
    # ==================================================
    uWasteOmega.l[g_waste,n,t]$(tWaste_CET[t])                = omega_w[g_waste,n];
    uWasteGamma.l[g_waste,n,t]$(tWaste_CET[t])                = gamma_w[g_waste,n];
    uWasteEpsilon.l[g_waste,n,t]$(tWaste_CET[t])              = epsilon_w[g_waste,n];
    uWasteXi_E.l[g_waste,n,t]$(tWaste_CET[t])                 = xiE_w[g_waste,n];
    uWasteXi_R.l[g_waste,n,t]$(tWaste_CET[t])                 = xiR_w[g_waste,n];

    # ==================================================
    # Hardcoded degree of recycling
    # ==================================================
    d1Waste_Hardcoded_recycling                               = 0;
    uWasteR.l[g_waste,n,t]$(tWaste_dst[t])                    = uWasteR_DATA[g_waste,n];


    # ==================================================
    # Residual waste 
    # ==================================================
    # Residual waste share coefficients (divided by 100 because data is measured as percentage)
    uWastePhi_R.l[g_waste,n,gg_waste,nn,t]$(tWaste_dst[t])                    = 0 ;
    uWastePhi_R.l[g_waste,n,g_waste,"Metal",t]$(tWaste_dst[t])  = dataRESMetal[g_waste,n]/100 ; 
    uWastePhi_R.l[g_waste,n,g_waste,"Dag",t]$(tWaste_dst[t])    = dataRESDag[g_waste,n]/100 ;
    uWastePhi_R.l[g_waste,n,g_waste,"Dep",t]$(tWaste_dst[t])    = dataRESDep[g_waste,n]/100 ;
    uWastePhi_R.l[g_waste,n,g_waste,"Farlig",t]$(tWaste_dst[t]) = dataRESFarlig[g_waste,n]/100 ;
    uWastePhi_R.l[g_waste,n,g_waste,"Plast",t]$(tWaste_dst[t])  = dataRESPlast[g_waste,n]/100 ;
    uWastePhi_R.l[g_waste,n,g_waste,"Glas",t]$(tWaste_dst[t])   = dataRESGlas[g_waste,n]/100 ;
    
    # Residual waste level coefficient
    uWasteBeta_R.l[g_waste,n,t]$(tWaste_dst[t])               = dataBetaLevel[g_waste,n] ;

    # ==================================================
    # Emissions and energy coefficients from burning waste
    # ==================================================
    uWasteEnergyValue.l[n,tx0]                                = energy_coef[n];
    uWasteEmissionValue.l[n,emm,tx0]                          = emission_coef[n,emm];
    uWasteEmissionCoefficient.l[n,emm,tx0]$(uWasteEnergyValue.l[n,tx0])   
                                                              = uWasteEmissionValue.l[n,emm,tx0]/uWasteEnergyValue.l[n,tx0]*(10**3); 
                                                              # The fraction is multiplied with 10^3 to change the measure from 'kg/MJ' (='kilo ton/TJ') to 'kilo ton/PJ'

    # ================================================================================
    # Effects from the climate plan (Effekter af virkemidlerne fra klimaplanen - MST) 
    # ================================================================================
    # Dummy to switch on/off the implementation of the effects from the climate plan
    d1WasteKlimaplan                                          = 1;

    # Effects on generated waste
    uWasteKlimaplan_GEN.l[sec,g_waste,n,t]$(not sameas[t,'2020'])                  
                                                              = virkemiddel_GEN[sec,g_waste,n,t];

    qWasteRestaffald.l[sec,g_waste,n,t]                       = qWasteQ_GEN.l[sec,g_waste,n,t]-qWasteQ.l[sec,g_waste,n,t]$(not sameas[n,'Dag']);

    # Effects on sorted waste for households                                                        
    uWasteKlimaplan_SORT.l[sec,g_waste,n,t]$(qWasteRestaffald.l[sec,g_waste,n,'2020']) 
                                                              = virkemiddel_SORT_hus[sec,g_waste,n,t];

    # Effects on sorted waste for the sectors                                                             
    uWasteKlimaplan_SORT.l[sec,g_waste,n,t]$(not sameas[sec,'hus'] and qWasteRestaffald.l[sec,g_waste,n,'2020'])
                                                              = virkemiddel_SORT_erhv[g_waste,n,t];                                                

    # Effects that moves waste from burning/utilization to recycling 
    uWasteKlimaplan_Chi.l['DK',g_waste,n,t]                     = virkemiddel_affaldshierarki[g_waste,n,t];  


    # Effects on the recycling process of 'Plast' is implemented in the CET-parameters
    uWasteOmega.l['Municipal Waste','Plast','2025']$(d1WasteKlimaplan) 
                                                              = omega_klimaplan['Municipal Waste','Plast'];
    uWasteGamma.l['Municipal Waste','Plast','2025']$(d1WasteKlimaplan) 
                                                              = gamma_klimaplan['Municipal Waste','Plast'];
    uWasteEpsilon.l['Municipal Waste','Plast','2025']$(d1WasteKlimaplan) 
                                                              = epsilon_klimaplan['Municipal Waste','Plast'];
    uWasteXi_E.l['Municipal Waste','Plast','2025']$(d1WasteKlimaplan) 
                                                              = xiE_klimaplan['Municipal Waste','Plast'];
    uWasteXi_R.l['Municipal Waste','Plast','2025']$(d1WasteKlimaplan) 
                                                              = xiR_klimaplan['Municipal Waste','Plast'];

    # ========================================================================================================================
    # Temorary handling of the electricity distribution sector. Should be fixed with next years waste forecast (Dec. 2025)
    # ========================================================================================================================
    # Before split between sectors, 35012 was merged with 35011 so we assign the same waste fractions as in 35011 
    uWaste_MWshare.l['35012',g_waste,n,t]           = uWaste_MWshare.l['35011',g_waste,n,t]; 
    uWaste_arima_SORT.l['35012',n,t]                = uWaste_arima_SORT.l['35011',n,t];
    uWaste_arima_GEN.l['35012',n,t]                 = uWaste_arima_GEN.l['35011',n,t];   

    # The amount of waste gen. in 35012
    qWasteQ_GEN.l['35012',g_waste,n,t]$(qWasteQ.l['35012',g_waste,n,t]) = qWasteQ.l['35012',g_waste,n,t]/(qWasteQ.l['35012',g_waste,n,t]+qWasteQ.l['35011',g_waste,n,t])*qWasteQ_GEN.l['35011',g_waste,n,t];
    # Waste gen. in 35012 is then deducted from 35011
    qWasteQ_GEN.l['35011',g_waste,n,t]                                  = qWasteQ_GEN.l['35011',g_waste,n,t]-qWasteQ_GEN.l['35012',g_waste,n,t];

#4) INITIAL VALUES                           
    qWasteE.l[origin_waste,g_waste,n,t]                       = qWasteE_utilize.l[origin_waste,g_waste,n,t]+qWasteE_burn.l[origin_waste,g_waste,n,t];
    qWasteE.l[origin_waste,g_waste,n,t]                       = abs(qWasteE.l[origin_waste,g_waste,n,t]); #£: Til Rikke: Her har jeg haft brug for absolut værdi i udvidelsen med cementbranche, d.20.7.2024
    qWasteE_ex.l[origin_waste,g_waste,n,t]                    = qWasteE_utilize_ex.l[origin_waste,g_waste,n,t]+qWasteE_burn_ex.l[origin_waste,g_waste,n,t];

    qWasteQ_bar.l[g_waste,n,t]                                = sum(sec,qWasteQ.l[sec,g_waste,n,t]);
    qWasteQ_bar_dom.l[origin_waste,g_waste,n,t]               = qWasteD.l[origin_waste,g_waste,n,t]+qWasteE.l[origin_waste,g_waste,n,t]
                                                                                                    +qWasteR.l[origin_waste,g_waste,n,t];

    qWasteW.l[origin_waste,g_waste,n,t]                       = qWasteE.l[origin_waste,g_waste,n,t]+qWasteR.l[origin_waste,g_waste,n,t];
    qWasteW_ex.l[origin_waste,g_waste,n,t]                    = qWasteE_ex.l[origin_waste,g_waste,n,t]+qWasteR_ex.l[origin_waste,g_waste,n,t];
                                                                                                        
    qWasteQ_im.l[g_waste,n,t]                                 = qWasteQ_bar_dom.l['Import',g_waste,n,t];  
    qWasteQ_ex.l[origin_waste,g_waste,n,t]                    = qWasteD_ex.l[origin_waste,g_waste,n,t]+qWasteE_ex.l[origin_waste,g_waste,n,t]
                                                                                                    +qWasteR_ex.l[origin_waste,g_waste,n,t];
    # Variables without residual waste
    qWasteD_ExclResWaste.l[origin_waste,g_waste,n,t]          = qWasteD.l[origin_waste,g_waste,n,t];
    qWasteE_ExclResWaste.l[origin_waste,g_waste,n,t]          = qWasteE.l[origin_waste,g_waste,n,t];                                
    qWasteR_ExclResWaste.l[origin_waste,g_waste,n,t]          = qWasteR.l[origin_waste,g_waste,n,t];           

    # Necessary initial value for the CET-function in the static calibration in case qWasteE is zero
    qWasteR_bar.l[origin_waste,g_waste,n,t]                   = qWasteR.l[origin_waste,g_waste,n,t]; 
    qWasteR_bar_ex.l[origin_waste,g_waste,n,t]                = qWasteR_ex.l[origin_waste,g_waste,n,t]; 

    qWasteM_R_bar.l[origin_waste,g_waste,n,t]                 = qWasteR.l[origin_waste,g_waste,n,t]-qWasteR_bar.l[origin_waste,g_waste,n,t] ;
    
    uWaste_adjust_GEN.l[sec,g_waste,n,t]$(tWaste_dst[t])      = 1;
    uWaste_adjust_GEN_2020.l[sec,g_waste,n,t]$(tWaste_dst[t]) = 1;

    qWasteQ_ARIMA.l[sec,g_waste,n,t]                          = qWasteQ.l[sec,g_waste,n,t];
    qWasteQ_GEN_ARIMA.l[sec,g_waste,n,t]                      = qWasteQ_GEN.l[sec,g_waste,n,t];

    # Recalculating the MW share for imported waste, because it can have changed due to reexport 
    uWaste_MWshare_im.l[g_waste,n,t]$(qWasteQ_im.l[g_waste,n,t])
                                                              = qWasteQ_im.l[g_waste,n,t]/sum(gg_waste,qWasteQ_im.l[gg_waste,n,t]);

#5) COMPUTATIONS 
    # =======================================================================
    # Waste treatment parameters for danish and imported waste treated in DK
    # =======================================================================
    #  Fractions going to landfill
    uWasteD.l[origin_waste,g_waste,n,t]$(qWasteD.l[origin_waste,g_waste,n,t])    
                                                    = qWasteD.l[origin_waste,g_waste,n,t]/qWasteQ_bar_dom.l[origin_waste,g_waste,n,t];
    uWasteD.l['Import',g_waste,'Dep',t]$(tWaste_dst[t]) 
                                                    = 1; # In data there is no imported landfill waste, which means that uWasteD = 0. 
                                                         # The recycle process of the imported waste will produce residual landfill waste.
                                                         # In order for this landfill waste to be treated in the model, uWasteD has to be equal to 1
                                                         # (this is in accordance with the assumption that all landfill waste ends up in landfill).                                                   

    # Fraction net of landfill going to recycling 
    uWasteChi.l[origin_waste,g_waste,n,t]$(qWasteR.l[origin_waste,g_waste,n,t])  
                                                    = qWasteR.l[origin_waste,g_waste,n,t]
                                                        /(qWasteR.l[origin_waste,g_waste,n,t]+qWasteE.l[origin_waste,g_waste,n,t]);
    uWasteChi.l['Import','Manufacturing Waste','Metal',t]$(sameas[t,'2014'] or sameas[t,'2015'] or sameas[t,'2017'])
                                                    = 1;
    uWasteChi.l['Import','Municipal Waste','Metal',t]$(sameas[t,'2014'] or sameas[t,'2015'])
                                                    = 1;
                                                         # In 2014, 2015 (and 2017 for manufacturing waste) all imported metal waste for recycling is reexported.
                                                         # This means that there is not treated any imported metal waste in DK in 2014, 2015 (and 2017), 
                                                         # which implies that all the waste treatment parameters are 0. 
                                                         # The recycle process of the imported waste will produce residual metal waste.
                                                         # In order for this metal waste to be treated in the model, uWasteChi is set equal to 1 for this waste 
                                                         # (this is in accordance with data, where all imported metal waste is recycled).     

    # Fraction net of landfill and recycled waste going to burning
    uWasteChi_E.l[origin_waste,g_waste,n,t]$(qWasteE.l[origin_waste,g_waste,n,t])
                                                    = qWasteE_burn.l[origin_waste,g_waste,n,t]/qWasteE.l[origin_waste,g_waste,n,t];

    
    # ==================================================
    # Import parameters
    # ==================================================
    # Imported waste treated in DK as share of danish generated waste
    uWaste_im.l[g_waste,n,t]$(qWasteQ_bar_dom.l['Import',g_waste,n,t])    
                                                    = qWasteQ_bar_dom.l['Import',g_waste,n,t]/qWasteQ_bar.l[g_waste,n,t];  

    # ==================================================
    # Export parameters
    # ==================================================
    # Exported waste (both danish and reexported waste) as share of danish generated waste
    uWaste_ex.l[origin_waste,g_waste,n,t]$(qWasteQ_ex.l[origin_waste,g_waste,n,t])                  
                                                    = qWasteQ_ex.l[origin_waste,g_waste,n,t]/qWasteQ_bar.l[g_waste,n,t];
    # Fractions going to landfill for exported waste                                               
    uWasteD_ex.l[origin_waste,g_waste,n,t]$(qWasteD_ex.l[origin_waste,g_waste,n,t])                 
                                                    = qWasteD_ex.l[origin_waste,g_waste,n,t]/qWasteQ_ex.l[origin_waste,g_waste,n,t];
    # Fraction net of landfill going to recycling for exported waste
    uWasteChi_ex.l[origin_waste,g_waste,n,t]$(qWasteR_ex.l[origin_waste,g_waste,n,t])     
                                                    = qWasteR_ex.l[origin_waste,g_waste,n,t]
                                                        /(qWasteR_ex.l[origin_waste,g_waste,n,t]+qWasteE_ex.l[origin_waste,g_waste,n,t]);   
    # Fraction net of landfill and recycling going to burning for exported waste
    uWasteChi_E_ex.l[origin_waste,g_waste,n,t]$(qWasteE_ex.l[origin_waste,g_waste,n,t])   
                                                    = qWasteE_burn_ex.l[origin_waste,g_waste,n,t]/qWasteE_ex.l[origin_waste,g_waste,n,t];


#6) DUMMIES 
    d1WasteKlimaplan_GEN[sec,g_waste,n,t]           = yes$(d1WasteKlimaplan and uWasteKlimaplan_GEN.l[sec,g_waste,n,t]);
    d1WasteKlimaplan_SORT[sec,g_waste,n,t]          = yes$(d1WasteKlimaplan and uWasteKlimaplan_SORT.l[sec,g_waste,n,t]);
    d1WasteKlimaplan_Chi[origin_waste,g_waste,n,t]  = yes$(d1WasteKlimaplan and uWasteKlimaplan_Chi.l[origin_waste,g_waste,n,t]);

    d1qWasteQ_GEN[sec,g_waste,n,t]                  = yes$(qWasteQ_GEN.l[sec,g_waste,n,t]);
    d1qWasteQ_ARIMA[sec,g_waste,n,t]                = yes$(qWasteQ.l[sec,g_waste,n,t]);
    d1qWasteQ[sec,g_waste,n,t]                      = yes$(d1qWasteQ_ARIMA[sec,g_waste,n,t]);
    d1qWasteQ[sec,g_waste,n,tKlimaplan]             = yes$(d1qWasteQ_ARIMA[sec,g_waste,n,'2020'] or d1WasteKlimaplan_SORT[sec,g_waste,n,tKlimaplan]);
    d1qWasteD[origin_waste,g_waste,n,t]             = yes$(qWasteD.l[origin_waste,g_waste,n,t] or (sameas[origin_waste,'Import'] and
                                                                                                   sameas[n,'Dep'])); # Allowing that there can be residual imported landfill waste
    d1qWasteE_burn[origin_waste,g_waste,n,t]        = yes$(qWasteE_burn.l[origin_waste,g_waste,n,t]);
    d1qWasteE_utilize[origin_waste,g_waste,n,t]     = yes$(qWasteE_utilize.l[origin_waste,g_waste,n,t]);    
    d1qWasteE[origin_waste,g_waste,n,t]             = yes$(d1qWasteE_burn[origin_waste,g_waste,n,t] or d1qWasteE_utilize[origin_waste,g_waste,n,t]);
    d1qWasteR[origin_waste,g_waste,n,t]             = yes$(qWasteR.l[origin_waste,g_waste,n,t] or (sameas[origin_waste,'Import'] and
                                                                                                   sameas[n,'Metal'] and
                                                                                                  (sameas[t,'2014'] or sameas[t,'2015'] or sameas[t,'2017'])));
                                                                                                  # Allowing that there can be residual imported metal waste
    d1WasteCET[origin_waste,g_waste,n,t]            = yes$(uWasteOmega.l[g_waste,n,t] and d1qWasteR[origin_waste,g_waste,n,t]); # dummy for missing parameters and other fractions we want to leave out of the CET equation.
    d1WasteResidual[origin_waste,g_waste,n,gg_waste,nn,t]        
                                                    = yes$(uWastePhi_R.l[g_waste,n,gg_waste,nn,t] and d1qWasteR[origin_waste,g_waste,n,t]);
    d1qWasteQ_bar[g_waste,n,t]                      = yes$(sum(sec,d1qWasteQ[sec,g_waste,n,t])
                                                            or sum((gg_waste,nn),d1WasteResidual['DK',gg_waste,nn,g_waste,n,t])); 
    d1qWasteQ_bar_dom[origin_waste,g_waste,n,t]     = yes$(d1qWasteD[origin_waste,g_waste,n,t] 
                                                        or d1qWasteE[origin_waste,g_waste,n,t] 
                                                        or d1qWasteR[origin_waste,g_waste,n,t] 
                                                        or sum((gg_waste,nn),d1WasteResidual[origin_waste,gg_waste,nn,g_waste,n,t])); 

    # Export dummies
    d1qWasteQ_ex[origin_waste,g_waste,n,t]          = yes$(qWasteQ_ex.l[origin_waste,g_waste,n,t]);
    d1qWasteD_ex[origin_waste,g_waste,n,t]          = yes$(qWasteD_ex.l[origin_waste,g_waste,n,t]);
    d1qWasteE_ex[origin_waste,g_waste,n,t]          = yes$(qWasteE_ex.l[origin_waste,g_waste,n,t]);
    d1qWasteR_ex[origin_waste,g_waste,n,t]          = yes$(qWasteR_ex.l[origin_waste,g_waste,n,t]);
    d1WasteCET_ex[origin_waste,g_waste,n,t]         = yes$(uWasteOmega.l[g_waste,n,t] and d1qWasteR_ex[origin_waste,g_waste,n,t]);

    d1waste_module[energy19,t]                      = yes$(sameas(energy19,"waste")); # Used to switch off some equations elsewhere when the waste module is activated
    d1xpRE[purpose,"waste",s,t]                     = yes$(qREgj.l[purpose,"waste",s,t]); # Set dummy where we model energy demand as proportional to other types of input demand, even though there is no price
    d1WasteEmissionValue[n,emm,t]                   = yes$(uWasteEmissionValue.l[n,emm,t]);
    d1uWasteEnergyValue[n,t]                        = yes$(uWasteEnergyValue.l[n,t]);
    d1uEmmWaste[s,t,emm]                            = yes$(uEmmProdE.l[s,t,emm,"waste"]>0 and sum(n, uWasteEmissionValue.l[n,emm,t]));

    d1Waste_qRxE[r,t]                               = yes$(sum(sec$(sec2r[r,sec]),sum(g_waste,sum(n,d1qWasteQ_GEN[sec,g_waste,n,t]))));

$ENDIF


# ======================================================================================================================
# Static calibration
# ======================================================================================================================
$IF %stage% == "static_calibration":

$GROUP G_waste_static_calibration
    G_waste_endo

        # Variables in G_waste
        -qWasteQ_GEN$(tx0[t] and d1qWasteQ_GEN[sec,g_waste,n,t]), uWaste_adjust_GEN$(tx0[t] and d1qWasteQ_GEN[sec,g_waste,n,t])
        #  -qWasteD$(tx0[t] and d1qWasteD[g_waste,origin_waste,n,t]), uWasteD$(tx0[t] and d1qWasteD[g_waste,origin_waste,n,t])
        #  -qWasteD_ExclResWaste$(tx0[t] and d1qWasteD[origin_waste,g_waste,n,t]), uWasteD$(tx0[t] and d1qWasteD[origin_waste,g_waste,n,t])    
        #  -qWasteR$(tx0[t] and d1qWasteR[origin_waste,g_waste,n,t]), uWasteChi$(tx0[t] and d1qWasteR[origin_waste,g_waste,n,t])
        #  -qWasteR_ExclResWaste$(tx0[t] and d1qWasteR[origin_waste,g_waste,n,t]), uWasteChi$(tx0[t] and d1qWasteR[origin_waste,g_waste,n,t])

        # Variables in G_waste_export
        #  -qWasteQ_ex$(tx0[t] and d1qWasteQ_ex[g_waste,n,t]), uWaste_ex$(tx0[t] and d1qWasteQ_ex[g_waste,n,t])
        #  -qWasteD_ex$(tx0[t] and d1qWasteD_ex[g_waste,n,t]), uWasteD_ex$(tx0[t] and d1qWasteD_ex[g_waste,n,t])
        #  -qWasteR_ex$(tx0[t] and d1qWasteR_ex[g_waste,n,t]), uWasteChi_ex$(tx0[t] and d1qWasteR_ex[g_waste,n,t])

        # Variables in G_links_waste
        -qRENEWABLE$(tx0[t] and sameas(energy19,"waste")), jqRENEWABLEWaste   
        -qWasteQ_im$(tx0[t] and sameas[n,'Dag'] and sameas[g_waste,'Manufacturing Waste']), jwaste_qREgj
        -qWasteQ_ex$(tx0[t] and sameas[origin_waste,'DK'] and sameas[n,'Dag'] and sameas[g_waste,'Manufacturing Waste']), jWaste_restaffald_export   
        -qWasteQ_ex$(tx0[t] and sameas[origin_waste,'DK'] and sameas[n,'Dag'] and sameas[g_waste,'Municipal Waste']), jWaste_restaffald_export_MW     
        -uEmmProdE$(tx0[t] and sum(purpose,d1EmmProdE[s,t,emm,purpose, "waste"]) and d1uEmmWaste[s,t,emm]), jEmmProdWaste$(tx0[t] and sum(purpose,d1EmmProdE[s,t,emm,purpose, "waste"]) and  d1uEmmWaste[s,t,emm])
;

$GROUP G_waste_static_calibration_exo
    G_waste_exo
    G_waste_param_calib

        # Variables in G_waste
        qWasteQ_GEN$(tx0[t] and d1qWasteQ_GEN[sec,g_waste,n,t]), -uWaste_adjust_GEN$(tx0[t] and d1qWasteQ_GEN[sec,g_waste,n,t])
        #  qWasteD$(tx0[t] and d1qWasteD[origin_waste,g_waste,n,t]), -uWasteD$(tx0[t] and d1qWasteD[origin_waste,g_waste,n,t])
        #  qWasteD_ExclResWaste$(tx0[t] and d1qWasteD[origin_waste,g_waste,n,t]), -uWasteD$(tx0[t] and d1qWasteD[origin_waste,g_waste,n,t])
        #  qWasteR$(d1qWasteR[origin_waste,g_waste,n,t]), -uWasteChi$(d1qWasteR[origin_waste,g_waste,n,t])
        #  qWasteR_ExclResWaste$(d1qWasteR[origin_waste,g_waste,n,t]), -uWasteChi$(d1qWasteR[origin_waste,g_waste,n,t])


        # Variables in G_waste_export
        #  qWasteQ_ex$(tx0[t] and d1qWasteQ_ex[g_waste,n,t]), -uWaste_ex$(tx0[t] and d1qWasteQ_ex[g_waste,n,t])
        #  qWasteD_ex$(tx0[t] and d1qWasteD_ex[g_waste,n,t]), -uWasteD_ex$(tx0[t] and d1qWasteD_ex[g_waste,n,t])
        #  qWasteR_ex$(tx0[t] and d1qWasteR_ex[g_waste,n,t]), -uWasteChi_ex$(tx0[t] and d1qWasteR_ex[g_waste,n,t])

        # Variables in G_links_waste
        qRENEWABLE$(tx0[t] and sameas(energy19,"waste")), -jqRENEWABLEWaste 
        qWasteQ_im$(tx0[t] and sameas[n,'Dag'] and sameas[g_waste,'Manufacturing Waste']), -jwaste_qREgj
        qWasteQ_ex$(tx0[t] and sameas[origin_waste,'DK'] and sameas[n,'Dag'] and sameas[g_waste,'Manufacturing Waste']), -jWaste_restaffald_export
        qWasteQ_ex$(tx0[t] and sameas[origin_waste,'DK'] and sameas[n,'Dag'] and sameas[g_waste,'Municipal Waste']), -jWaste_restaffald_export_MW
        uEmmProdE$(tx0[t] and sum(purpose,d1EmmProdE[s,t,emm,purpose, "waste"]) and d1uEmmWaste[s,t,emm]), -jEmmProdWaste$(tx0[t] and sum(purpose,d1EmmProdE[s,t,emm,purpose, "waste"]) and d1uEmmWaste[s,t,emm])
  ;


$MODEL M_waste_static_calibration
    M_waste
;

# ======================================================================================================================
# Model to calculate the variables in the treatment-block, export-block and report-block for historic years (2014-2020)
# ======================================================================================================================
# The variables from the waste generation block is taken as exogenous from the historic data
# The export and import of 'restaffald' is also taken as exogenous from the historic data instead of being determined from the links to the rest of the model   
set_time_periods(2013,2020);
$MODEL M_waste_2014_2020
    B_waste_SORT_ARIMA
    B_waste_treatment
    B_waste_export
    B_report_waste
    B_waste_treatment_ExclResWaste
    B_report_COWI
;
$GROUP g_waste_2014_2020_endo
    G_wasteSorting_quantities
    G_wasteTreatment_quantities
    G_waste_export
    G_report_waste
    G_wasteTreatment_quantities_ExclResWaste
    G_report_COWI
;
$GROUP g_waste_2014_2020_exo
    G_waste_param
    qWasteQ_GEN_ARIMA$(d1qWasteQ_GEN[sec,g_waste,n,t]) 
    qWasteQ_GEN$(d1qWasteQ_GEN[sec,g_waste,n,t])
    qWasteQ_ARIMA$(d1qWasteQ_ARIMA[sec,g_waste,n,t])
    qWasteQ_im[g_waste,n,t]$(d1qWasteQ_bar_dom['Import',g_waste,n,t] and sameas[n,'Dag'])
    qWasteQ_ex[origin_waste,g_waste,n,t]$(d1qWasteQ_ex[origin_waste,g_waste,n,t] and sameas[origin_waste,'DK'] and sameas[n,'Dag'])
;
$FIX g_waste_2014_2020_exo;
$UNFIX g_waste_2014_2020_endo;
execute_unload 'output\pre.gdx';
@SOLVE(M_waste_2014_2020);

set_time_periods(%cal_start%, %cal_end%);

$ENDIF


# ======================================================================================================================
# Dynamic calibration
# ======================================================================================================================
$IF %stage% == "dynamic_calibration":

# Production of recycling sector is determined from amount of recycling waste in forecast; instead, we let exports of recycling sector output clear goods balance.
#  d1X_y[x_,s,t]$(sameas(x_,'xOth') and sameas(s,'38394') and tx1[t]) = yes;

# Setting the J-ternm for qRENEWABLEWaste equal to one in the forecast period
jqRENEWABLEWaste.l[tForecast] = 1; 

# =============================================================
# Calibrating ARIMA-coefficients
# =============================================================
# Recalibration the ARIMA-estimated generation and sorting coefficients in cases where the coefficient is 0 in 2020 
# even though the 2020-data shows that there is waste in 2020
uWaste_arima_GEN.l[sec,n,tForecast]$(sum(g_waste, qWasteQ_GEN.l[sec,g_waste,n,tForecast]) and (not uWaste_arima_GEN.l[sec,n,tForecast]) and (not sameas[tForecast,'2019'])
                                            and (not sameas[sec,'hus']))
                                                    = sum(g_waste, qWasteQ_GEN.l[sec,g_waste,n,'2020'])/(sum(r$(sec2r(r,sec)), qrxe.l[r,'2020'])/growth_factor['2020']);
uWaste_arima_GEN.l[sec,n,tForecast]$(sum(g_waste, qWasteQ_GEN.l[sec,g_waste,n,tForecast]) and not uWaste_arima_GEN.l[sec,n,tForecast] and not sameas[tForecast,'2019']
                                            and (sameas[sec,'hus']))
                                                    = sum(g_waste, qWasteQ_GEN.l[sec,g_waste,n,'2020'])/(qCHH.l['ctot','2020']/growth_factor['2020']); 
uWaste_arima_SORT.l[sec,n,tForecast]$(sum(g_waste, qWasteQ_ARIMA.l[sec,g_waste,n,tForecast]) and not uWaste_arima_SORT.l[sec,n,tForecast] and not sameas[tForecast,'2019'])
                                                    = sum(g_waste, qWasteQ.l[sec,g_waste,n,'2020'])/sum(g_waste, qWasteQ_GEN.l[sec,g_waste,n,'2020']);

# =============================================================
# Calibrating adjustment terms
# =============================================================
$BLOCK B_waste_dynamic
    # The adjustment term that links estimation and model activity data in the waste generation is set equal to the value in 2019 for the years 2020-2099
    E_waste_WasteGeneration_adjustment_term[sec,g_waste,n,t]$((tForecastWaste_dst[t] or sameas[t,'2020']) and d1qWasteQ_GEN[sec,g_waste,n,'2019'])..                   
        uWaste_adjust_GEN[sec,g_waste,n,t] =E= uWaste_adjust_GEN[sec,g_waste,n,'2019'];

    # The adjustment term that links estimation and model activity data in the waste generation is set equal to the value in 2019 for the years 2020-2099
    E_waste_WasteGeneration_adjustment_term2[sec,g_waste,n,t]$((tForecastWaste_dst[t] or sameas[t,'2020']) and not d1qWasteQ_GEN[sec,g_waste,n,'2019'])..                   
        uWaste_adjust_GEN[sec,g_waste,n,t] =E= 1;

    # The adjustment term that fits the model to 2020 waste data is set equal to the value in 2020 for the years 2021-2099
    E_waste_WasteGeneration_adjustment_term_2020[sec,g_waste,n,t]$(tx0[t] and (tForecastWaste_dst[t]) and d1qWasteQ_GEN[sec,g_waste,n,t])..                   
        uWaste_adjust_GEN_2020[sec,g_waste,n,t] =E= uWaste_adjust_GEN_2020[sec,g_waste,n,t-1];

    # The adjustment term that links energy data and waste data is set equal to the value in 2020 for the years 2021-2099
    E_waste_burned_adjustment_term[t]$(tx0[t] and tForecastWaste_dst[t])..                   
        jwaste_qREgj[t] =E= jwaste_qREgj[t-1];

    E_waste_burned_export_adjustment_term[t]$(tx0[t] and tForecastWaste_dst[t])..                   
        jWaste_restaffald_export[t] =E= 0;

    E_waste_burned_export_MW_adjustment_term[t]$(tx0[t] and tForecastWaste_dst[t])..                   
        jWaste_restaffald_export_MW[t] =E= 0;

$ENDBLOCK


$GROUP G_waste_calib
    G_waste_endo
 
    # Endogenizes the adjustment term in 2020-2099 to be determined by the equation E_waste_WasteGeneration_adjustment_term
    uWaste_adjust_GEN$((tForecastWaste_dst[t] or sameas[t,'2020']) and d1qWasteQ_GEN[sec,g_waste,n,t])
    # The adjustment term is endogenized in 2019 such that the model fits the waste data in 2019 
    uWaste_adjust_GEN$(tx0[t] and sameas[t,'2019'] and d1qWasteQ_GEN[sec,g_waste,n,t]), -qWasteQ_GEN$(tx0[t] and sameas[t,'2019'] and d1qWasteQ_GEN[sec,g_waste,n,t])
    
    # Endogenizes the adjustment term in 2021-2099 to be determined by the equation E_waste_WasteGeneration_adjustment_term_2020
    uWaste_adjust_GEN_2020$(tx0[t] and tForecastWaste_dst[t] and d1qWasteQ_GEN[sec,g_waste,n,t])
    # The adjustment term is endogenized in 2020 such that the model fits the waste data in 2020
    uWaste_adjust_GEN_2020$(tx0[t] and sameas[t,'2020'] and d1qWasteQ_GEN[sec,g_waste,n,t]), -qWasteQ_GEN$(tx0[t] and sameas[t,'2020'] and d1qWasteQ_GEN[sec,g_waste,n,t])

    # Endogenizes the adjustment term in 2021-2099 to be determined by the equation E_waste_burned_adjustment_term
    jwaste_qREgj$(tx0[t] and tForecastWaste_dst[t])
    # The adjustment term is endogenized in 2018-2020 such that the model fits the data for imported 'restaffald' in 2018-2020
    jwaste_qREgj$(tx0[t] and (tForecastWaste_dst_inc[t] or t1[t])), -qWasteQ_im$(tx0[t] and (tForecastWaste_dst_inc[t] or t1[t]) and (sameas[n,'Dag'] and sameas[g_waste,'Manufacturing Waste']))

    
    jWaste_restaffald_export$(tx0[t] and tForecastWaste_dst[t])
    jWaste_restaffald_export$(tx0[t] and (tForecastWaste_dst_inc[t] or t1[t])), -qWasteQ_ex$(tx0[t] and (tForecastWaste_dst_inc[t] or t1[t]) and (sameas[n,'Dag'] and sameas[origin_waste,'DK'] and sameas[g_waste,'Manufacturing Waste']))

    jWaste_restaffald_export_MW$(tx0[t] and tForecastWaste_dst[t])
    jWaste_restaffald_export_MW$(tx0[t] and (tForecastWaste_dst_inc[t] or t1[t])), -qWasteQ_ex$(tx0[t] and (tForecastWaste_dst_inc[t] or t1[t]) and (sameas[n,'Dag'] and sameas[origin_waste,'DK'] and sameas[g_waste,'Municipal Waste']))
;

$GROUP G_waste_calib_exo
    G_waste_exo

    -uWaste_adjust_GEN$((tForecastWaste_dst[t] or sameas[t,'2020']) and d1qWasteQ_GEN[sec,g_waste,n,t])
    -uWaste_adjust_GEN$(tx0[t] and sameas[t,'2019'] and d1qWasteQ_GEN[sec,g_waste,n,t]), qWasteQ_GEN$(tx0[t] and sameas[t,'2019'] and d1qWasteQ_GEN[sec,g_waste,n,t])

    -uWaste_adjust_GEN_2020$(tx0[t] and tForecastWaste_dst[t] and d1qWasteQ_GEN[sec,g_waste,n,t])
    -uWaste_adjust_GEN_2020$(tx0[t] and sameas[t,'2020'] and d1qWasteQ_GEN[sec,g_waste,n,t]), qWasteQ_GEN$(tx0[t] and sameas[t,'2020'] and d1qWasteQ_GEN[sec,g_waste,n,t])

    -jwaste_qREgj$(tx0[t] and tForecastWaste_dst[t])
    -jwaste_qREgj$(tx0[t] and (tForecastWaste_dst_inc[t] or t1[t])), qWasteQ_im$(tx0[t] and (tForecastWaste_dst_inc[t] or t1[t]) and (sameas[n,'Dag'] and sameas[g_waste,'Manufacturing Waste']))

    -jWaste_restaffald_export$(tx0[t] and tForecastWaste_dst[t])
    -jWaste_restaffald_export$(tx0[t] and (tForecastWaste_dst_inc[t] or t1[t])), qWasteQ_ex$(tx0[t] and (tForecastWaste_dst_inc[t] or t1[t]) and (sameas[n,'Dag'] and sameas[origin_waste,'DK'] and sameas[g_waste,'Manufacturing Waste']))

    -jWaste_restaffald_export_MW$(tx0[t] and tForecastWaste_dst[t])
    -jWaste_restaffald_export_MW$(tx0[t] and (tForecastWaste_dst_inc[t] or t1[t])), qWasteQ_ex$(tx0[t] and (tForecastWaste_dst_inc[t] or t1[t]) and (sameas[n,'Dag'] and sameas[origin_waste,'DK'] and sameas[g_waste,'Municipal Waste']))

;

$MODEL M_waste_calib
    M_waste
    B_waste_dynamic 
;


$ENDIF
