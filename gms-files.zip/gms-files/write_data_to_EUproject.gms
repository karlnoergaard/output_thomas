$GROUP G_EUproject_data
	#Energimængder
	qREgj 
	qCE 
	qXE 
	qLE 
	qTL

	#Energipriser
	pRE_base
	pCE_base 
	pXE_base 
	pLE_base 
	pREown
	pEtot
	qEtot
	pREgj
	pCE 
	pLE 
	pXE 
	pL

	#Afgifter på energi
	vtVAT_RE
	vtCO2_RE 
	vtEAFG_RE 
	vtSO2_RE 
	vtPSO_RE
	vtNOx_RE

	vtVAT_CE
	vtCO2_CE 
	vtEAFG_CE 
	vtSO2_CE 
	vtPSO_CE
	vtNOx_CE

	#Marignale afgiftssatser
	tCO2_REmarg
	tEAFG_REmarg 
	tCO2_ETS 
	tCO2_ETS2

	#Gratiskvoter
	qEmmProdE_dedETS
	vtCO2_ETS

	#Avancer på energi 
	vDAV_RE
	vCAV_RE
	vEAV_RE
	vDAV_CE 
	vCAV_CE
	vEAV_CE 

	#Emissioner 
	qEmmProdE 
	qEmmProdxE 
	qEmmConsE 
	qEmmConsxE 
	qEmmBorderTrade
	sBioNatGasAvgAdj
	qEmmLULUCF 
	qEmmTot
	qEmmLULUCF5
	GWP


	tvRE
	tqRE 
	tLE 
	tXE_ 
	tCE


	#Produktion og import
	qY_CET 
	qY_CETgross
	pY_CET 
	qM_CET 
	pM_CET 

	qL
	qK 
	qI_s

	#IO
	qRxE_y 
	qRxE_m 
	qC_y 
	qC_m 
	qX_y 
	qX_m 
	qG_y 
	qG_m 
	qI_y 
	qI_m
	qFin_y
	qFin_m 

	qRxE 
	pRxE

	pK

	#Punktafgifter og moms
	tDuty_C_y
	tVAT_C_y
	tDuty_C_m
	tCus_C_m
	tVAT_C_m

	tDuty_G_y
	tVAT_G_y
	tDuty_G_m
	tCus_G_m
	tVAT_G_m

	tDuty_I_y
	tVAT_I_y
	tDuty_I_m
	tCus_I_m
	tVAT_I_m

	tDuty_Fin_y
	tVAT_Fin_y
	tDuty_Fin_m
	tCus_Fin_m
	tVAT_Fin_m

	tDuty_RxE_y
	tVAT_RxE_y
	tDuty_RxE_m
	tCus_RxE_m
	tVAT_RxE_m

	#Produktionsskatter-og subsidier
	vtLand 
	vtFirmsWeight
	vtLAM 
	vtLSubsidy
	vtLPayRoll
	vtNetProductionRest
	vtCAP_top


	#Labormarket 
	w
	u 
	nLaborForce 
	nEmployed
	nPop
	uLaborForce #Andel af nPop i arbejdsstyrke

	vPrimIncome 

	#Nedenstående giver samlede direkte afgifter af forbrugeren
	vtAM
	vtSource 
	vtMedia 
	vtChurch
	vtCarWeight 
	vtPersIncRest 
	vtPAL 
	vtBequest

	#Offentlig balance 
	vGovBudget 
	vGovPrimBalance 
	vGovNetInterest 
	vGovRev 
	vGovExp 
	vG 
	vTrans 
	vGovInv 
	vGovSub 
	vGovExpRest 
	vtIndirect 
	vtDirect 
	vGovRevRest 
	vLumpsum 

	vtVAT 
	vtDuty 
	vtProduction 
	vtCus 
	vtEU 
	jvtIndirect 

	vtProductionRest
	vtCUS 
	vtSource 
	vtCorp 
	vtAM 
	vtMEDIA 
	vtPersIncRest 
	vtCarWeight 
	vtPAL 
	vPersAllowance
	jvPersallowance 
	vtCORP 
	vtCorpNorth 
	vtAM 
	vHH 
	vGovProfit 
	vGovRent 
	vGovReceiveF 
	vGovReceiveHH 
	vGovReceiveFirms 
	vtBequest 
	vBequest 
	vtChurch 
	vCont 
	vGovInv 
	vGovNetInterest
	vInterestGovAssets 
	vInterestGovDebt 
	vGovAssets 
	vGovNetWealth 
	vGovSub 
	vSubProdution 
	vSubprodutionRest 
	vSubEU 
	vGovExpRest
	vGovLand 
	vGov2Foreign 
	vGov2HH 
	vGov2Firms 
	vPublicSales

;

#  execute_unload 'output\EU_GR_data.gdx' $LOOP G_EUproject_data: {name}.l $ENDLOOP s s_ r r_ k i_ i k_ k g g_ out energy19 purpose c taxd accounts emm_eq emm portfolio uEmmHardcoded;
execute_unload 'P:\akg\Til_EU_projekt\EU_GR_data.gdx' $LOOP G_EUproject_data: {name}.l $ENDLOOP s s_ r r_ k i_ i k_ k g g_ c x out energy19 purpose c taxd accounts accounts_all land5 emm_eq emm portfolio uEmmHardcoded, vIOxE_y vIOxE_m vIOxE_a s56_ IO_56_c_ a_rows_, vIO_y, vIO_m, vIO_a;


