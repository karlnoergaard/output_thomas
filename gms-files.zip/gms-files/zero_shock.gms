#====================================================================================================================================================================================================================#
# A COUPLE OF ZERO-SHOCKS TO THE MODEL. ONE WITH BASE-YEAR AS STARTING YEAR AND ONE WHERE START YEAR IS MOVED TO 2021
# - IF THE MODEL DOES NOT PASS THE ZERO-SHOCK TEST REVIEW YOUR CHANGES TO THE MODEL.
#====================================================================================================================================================================================================================#

# #GVA-test after calibration is still work in progress, and need to be appropriately updated
$SETGLOBAL testGVA 0

Sets s_DK[sp] "brancher hvor danskejerskab er sat eksogent" / 01011, 01012, 01020, 01031, 01032, 01051, 01052, 01061, 01062, 02000, 10011, 10012, 10013, 10030, 68203/; 

	$GROUP G_shockEndo
	correction_rHH[t] ""
	vWealth_shockCorrection[t] ""
  	sEquityDKownedEndo[t] "Hvor stor en del af virksomhederne (uden eksogen antagelse om ejerskab) der af danskejet"
	;

	$GROUP G_shockExo
	#  vEquity_baseline[s_,t] "Virksomhedsværdier i grundforløbet"
  	sEquityDKownedExo[sp,t] "Andelen af branchen som er danskejet"
  	sDomesticEquity$(t0[t]) #Tilføjet ifm. endo-exo (Rasmus)
  	vEquity_baseline[sp,t] ""
	;

	vEquity_baseline.l[sp,t] = vEquity.l[sp,t];

$SETGLOBAL setKFbaselinevalues 1 #Set Climate Outlook anchored baseline values
$IMPORT create_baseline_values.gms;
$SETGLOBAL setKFbaselinevalues 0 #Setting off. Climate Outlook anchored baseline values should not be changed when setting baseline-values after this point

  $BLOCK B_shock_a

    E_vBoP_shock[t]$(tx0[t])..       vBoP[t] =E= vNFE[t] - (vForeignWealth[t] - vForeignWealth[t-1]/fv) + vGovReval[t] + JvWealth[t] + correction_rHH[t]
                                         
                                           ;


    E_vHHxAfk_shock[t]$(tx0[t])..         vHHxAfk[t] =E=  rBonds['71000',t] * (1-sDomesticEquity[t]-sForeignEquity[t]) * vWealth[t-1]/fv
                                                          #  + sum(agri_sectors, (rBonds[agri_sectors,t]-rBonds['71000',t]) * vFirmDebt[agri_sectors,t-1]/fv)
                                                          + sum(sp,rInvestor[sp,t]*vEquity[sp,t])/sum(sp,vEquity[sp,t]) 
                                                             * (sDomesticEquity[t]+sForeignEquity[t]) * vWealth[t-1]/fv
                                                          + correction_rHH[t]
                                                        ; 


    E_vWealth_shock[t]$(tx0[t])..              vWealth[t] =E= vWealth[t-1]/fv + vPersIncome[t] - vC['ctot',t] + JvWealth[t] + vWealth_shockCorrection[t-1]/fv;

	E_vWealth_shockCorrection1[t]$(tx0[t])..    vWealth_shockCorrection[t] =E=  0;
    E_vWealth_shockCorrection2[t]$(t0[t])..     vWealth_shockCorrection[t] =E=  (sum(sp,vEquity[sp,t])-sum(sp,vEquity_baseline[sp,t]))*sEquityDKownedEndo[t] + sum(s_DK, (vEquity[s_DK,t]-vEquity_baseline[s_DK,t])*(sEquityDKownedExo[s_DK,t]-sEquityDKownedEndo[t]));

  	E_sEquityDKownedEndo[t]$(tEndo[t])..  sEquityDKownedEndo[t] =E= (sDomesticEquity[t]*vWealth[t-1]/fv-sum(s_DK,sEquityDKownedExo[s_DK,t]*vEquity_baseline[s_DK,t])) / (sum(sp,vEquity_baseline[sp,t])-sum(s_DK,sEquityDKownedExo[s_DK,t]*vEquity_baseline[s_DK,t]));

  $ENDBLOCK 

  $BLOCK B_shock_b
    E_qC_shock[c,t]$(tx0[t]).. qC[c,t] * pC_baseline[c,t-1] =E= pCHh_baseline[c,t-1] * qCHh[c,t] + pCtourist_baseline[c,t-1] * qCtourist[c,t]$(d1CTourist[c,t]);

    E_qC_tot_shock[t]$(tx0[t])..   qC['cTot',t] * pC_baseline['cTot',t-1] =E= sum(c$d1C[c,t], pC_baseline[c,t-1]$d1C[c,t] * qC[c,t] - pCtourist_baseline[c,t-1] * qCtourist[c,t]$(d1CTourist[c,t]));

    E_qX_tot_shock[t]$(tx0[t]).. qX['xtot',t]*pX_baseline['xtot',t-1] =E= sum(s$(d1X_y['xoth',s,t]), pX_y_baseline['xoth',s,t-1]$(d1X_y['xoth',s,t]) * qX_y['xoth',s,t])
                                           +sum(s$(d1X_m['xoth',s,t]), pX_m_baseline['xoth',s,t-1]$(d1X_m['xoth',s,t]) * qX_m['xoth',s,t])
                                           +sum((purpose,energy19)$(d1vXE[purpose,energy19,t] and d1vXE[purpose,energy19,t]), pXE_baseline[purpose,energy19,t-1] * qXE[purpose,energy19,t])
                                           +pX_baseline['xTur',t-1]*qX['xTur',t]
                                           +(pXE_ElNl_baseline[t-1]*qXE_ElNl[t])$(t.val <=2019) #�rsted
                                           ;

    E_qX_s_shock[s,t]$(tx0[t] and d1x_s[s,t]).. 
      pX_s_baseline[s,t-1]*qX_s[s,t] =E= (pX_y_baseline['xOth',s,t-1]*qX_y['xOth',s,t])$(d1x_y['xOth',s,t] and d1x_y['xOth',s,t]) + (pX_s_baseline[s,t-1]*qX_y['xOth',s,t])$(d1x_y['xOth',s,t] and not d1x_y['xOth',s,t])
                                + sum(energy19$(d1vXE['unspecified',energy19,t] and d1Xe_y[energy19,s,t]), pXE_baseline['unspecified',energy19,t-1] *qXE['unspecified',energy19,t] *qY[s,t]/sum(ss$d1Xe_y[energy19,ss,t], qY[ss,t]))
                                + (pXE_ElNl_baseline[t-1]*qXE_ElNl[t])$(sameas[s,'35011'] and t.val <=2019)  #�rsted
                                ;


  $ENDBLOCK

#Baseline landbrugsproduktivitet 
TFPPlant_baseline_zeroshockagr.l[plant_sectors,t]  = TFPPlant.l[plant_sectors,t];
TFPPlant_baseline_zeroshockagr.l[plant_sectors,t0] = TFPPlant_baseline_zeroshockagr.l[plant_sectors,t1];
qLandUdtag_tot_zeroshock_agr.l[t]                  = qLandUdtag_tot.l[t];
margDBII_2CGE_act_zeroshockagr.l[t]                = margDBII_2CGE_act.l[t];





#Setting up model
$MODEL M_zeroshock
	M_base
	,-B_leakage

  #Landbrugsintegration...
	-E_pY_CET0
	-E_qY
	E_pY_CET0_notagri  
	E_qY_notagri     

	#Fjerner udvaskning 
	-B_udvaskning

	#  M_energy 
	#  B_CGE_ENERGY_LINK

	B_shock_a, -E_vBoP, -E_vHHxAfk, -E_vWealth
	#  B_shock_b, -E_qC, -E_qC_tot, -E_qX_tot, -E_qX_s

	-E_vPersIncome_t0 #Tilføjet ifm. endo-exo (Rasmus)

	M_endolandlinks

	#Tilføjer nye installationsomkostningsligninger
	$LOOP M_instcost_calib_loop:
	-{name}
	{name}_new 
	$ENDLOOP
;


$GROUP G_endo 
	G_endo
	#  G_CGE_ENERGY_LINK_ENDO
	G_endolandlinks_endo
	G_shockEndo, vWealth_shockCorrection$(t0[t]), -rHHxAfk

	-qY$(agri_sectors_s_[s_])
	-pY0_CET$(agri_sectors_[s])

	-rForeignWealth$(t1[t])
	-vPersIncome$(t0[t]) #Tilføjet ifm. endo-exo (Rasmus)

	#Fjerner udvaskning
	-G_udvaskning_endo

;

$GROUP G_exo 
	G_exo 
	#  G_CGE_ENERGY_LINK_EXO
	G_endolandlinks_exo
	pLand$(t0[t])
	G_shockExo, -G_shockEndo, rHHxAfk

	#  G_energy_endo 
	#  G_CGE_ENERGY_LINK_ENDO
	G_endolandlinks_endo
	qY$(agri_sectors_s_[s_])
	pY0_CET$(agri_sectors_[s])
	vEquity_baseline
    
	pC_baseline
	pCtourist_baseline
	pCHh_baseline
  	pX_baseline
  	pX_y_baseline
  	pX_m_baseline
  	pX_s_baseline
  	pXE_ElNl_baseline
  	pXE_baseline	

  	rForeignWealth$(t1[t])

  	vWealth$(t.val <= t0.val) #Tilføjet ifm. endo-exo (Rasmus)
  	vPersIncome$(t0[t])       #Tilføjet ifm. endo-exo (Rasmus)

  	#Tilføjer j-led for højere installationsomkostninger til exo-gruppe
  	$LOOP M_instcost_calib_loop:
  		{name}_j
  	$ENDLOOP
;

#Re-defining endoAndExo to be the model endo and exo groups (not the calibration endo- and exo-groups as it is set to in calib_installation_costs.gms)
$GROUP G_EndoAndExo 
	G_endo 
	G_exo
	-sigmaID #Fungerer ikke ordentligt med gamY (prøv igen med fremtidig gamY-version, AKB 27.6.2024)
	-sEquityDKownedEndo
	-qX
	-eAGG
;

sEquityDKownedExo.l[s_DK,t]$(tx0[t]) = 1;

#Save variable values to have something to compare with after shock
@save(G_EndoAndExo);

#  $SETGLOBAL start_shock_year 2022 #Year where we start the 0-shock
#  set_time_periods(%start_shock_year%,%terminal_year%);
#Zero-shock, unchanged b
$FIX G_exo;
$UNFIX G_endo;
@SOLVE(M_zeroshock);


#Now we move start year to 2021 
$SETGLOBAL start_shock_year 2022 #Year where we start the 0-shock
set_time_periods(%start_shock_year%,%terminal_year%);
#  t_BU_start[t] = yes$(t.val =%start_shock_year%+1);
#  t_BU_xStart[t] = yes$(t_BU[t] and t.val > t_BU_Start.val and tx1[t]);

$FIX G_exo;
$UNFIX G_endo;
@save(G_EndoAndExo);
@SOLVE(M_zeroshock);
@assert_no_difference(G_EndoAndExo,1e-8);
$import sanitycheck.gms;


#Now we move start year to 2035
$SETGLOBAL start_shock_year 2034 #Year where we start the 0-shock
set_time_periods(%start_shock_year%,%terminal_year%);
#  t_BU_start[t] = yes$(t.val =%start_shock_year%+1);
#  t_BU_xStart[t] = yes$(t_BU[t] and t.val > t_BU_Start.val and tx1[t]);

$FIX G_exo;
$UNFIX G_endo;
@save(G_EndoAndExo);
@SOLVE(M_zeroshock);
@assert_no_difference(G_EndoAndExo,1e-8);
$import sanitycheck.gms;


pU.l[t] = 1; #staringvalue
#  $IMPORT create_baseline_values.gms;
#  $IMPORT report.gms;
#  $IMPORT create_baseline_values.gms;
$IMPORT sanitycheck.gms

#Write baseline
$IMPORT Report_and_steps\report.gms;
$IMPORT create_baseline_values.gms;
execute_unload 'Output\Zero_shock.gdx';
